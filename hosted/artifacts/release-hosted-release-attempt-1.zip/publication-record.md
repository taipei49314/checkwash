# v0.12.0 publication verification

GitHub Release v0.12.0 was published at 2026-11-07T15:06:03Z and PyPI 0.12.0
at 2026-11-07T16:06:14Z (23:06 on 2026-11-07 and 00:06 on 2026-11-08,
Asia/Taipei), under the pre-1.0 delegation in [RELEASING](../RELEASING.md#v0120-checked-publication-and-pin-promotion-2026-11-08).
[GitHub Release](https://github.com/taipei49314/checkwash/releases/tag/v0.12.0) ·
[PyPI 0.12.0](https://pypi.org/project/checkwash/0.12.0/).

Every stage's product execution ran once on LAPTOP-01AGNPJU, Windows,
CPython 3.11.9, recorded as `HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`. Hosted
jobs only captured native metadata, verified the published receipts, published
check runs, attached assets and uploaded to PyPI. Linux, macOS and other
Python versions are NOT_RUN as release evidence; the missing-platform
acceptance sealed into the release-event receipt covers this release only,
and the supplementary six-leg batch RELEASING records is not a release
receipt. This is maintainer-backed evidence, not hardware attestation.

## Fixed source and tag

PR [#592](https://github.com/taipei49314/checkwash/pull/592) merged qualified
head R = `dfa934519b3639dea689056d3b3ab08a92e45d1c` with a merge commit,
M = `ffaf4ed86ecc2baeb8cc008487a44d8495da9177`. M's first parent is the
reviewed base `e27eec6b2e56a05be33ce8b45f398482740d234b`, and its tree equals
R's, `516dde6dac193a641c59792ae6a08de777fdfb93`. R's parent is the release's
Action commit A = `532f74ab070a924b23e2cc70e5d0091a05d8401d`; `git diff A M`
changes only `_OWN_ACTION_PIN` in `src/checkwash/doctor.py`, from v0.11.0's
Action commit to A (D-194). It is the first tag made under D-200: annotated
tag object `6f8b8b7a95f8c6070a0c4bfb1e3ea5a9cb534fe2` (tagger Claude,
unsigned) peels to A, tree `97381f3be614c4c2dca5a464fb2902197b0d873a`, and
its message, after the title, is the one line
`Release-Merge: ffaf4ed86ecc2baeb8cc008487a44d8495da9177`. Before the push,
`tools/own_action_pin.py check --stage tag` passed on the local tag. Only
that tag was pushed; no public tag was moved or deleted.

## Stage evidence

Each collection started from fresh clean checkouts and a fresh runtime equal
to the 41-package lock `a6f42266`. Each receipt is an immutable orphan commit
on an `evidence/v0120-*` branch, read back byte for byte from a fresh clone
before dispatch, and each dispatch followed a local dry run of the trusted
verifier against the published receipt.

| Stage | Native capture | Collector | Receipt commit / manifest | Verification run | Verifier | Stage check |
| --- | --- | --- | --- | --- | --- | --- |
| PR #592 head R | [42347966755](https://github.com/taipei49314/checkwash/actions/runs/42347966755) | `e27eec6b` | `dc70102a` / `886b51f12456` | [42351361937](https://github.com/taipei49314/checkwash/actions/runs/42351361937) | `e27eec6b` | 128340770337 |
| M on main | [42376175053](https://github.com/taipei49314/checkwash/actions/runs/42376175053) | `e27eec6b` | `daaeb5c3` / `25b56d738028` | [42380167201](https://github.com/taipei49314/checkwash/actions/runs/42380167201) | `e27eec6b` | 128426634501 |
| Tag v0.12.0 | [42380588324](https://github.com/taipei49314/checkwash/actions/runs/42380588324) | `e27eec6b` | `12532c5e` / `c8a603c4630b` | [42384368633](https://github.com/taipei49314/checkwash/actions/runs/42384368633) | `e27eec6b` | 128439342497 |
| Release event | [42384715859](https://github.com/taipei49314/checkwash/actions/runs/42384715859) | `e27eec6b` | `312035e2` / `e40749dabf91` | [42388724734](https://github.com/taipei49314/checkwash/actions/runs/42388724734) | `e27eec6b` | 128452298440 |
| Public visitor | [42389734518](https://github.com/taipei49314/checkwash/actions/runs/42389734518) | `e27eec6b` | `a6715473` / `c70a692e6d31` | [42394116596](https://github.com/taipei49314/checkwash/actions/runs/42394116596) | `e27eec6b` | 128468638162 |

`e27eec6b` is the reviewed ref `review/collector-d-012-20261107`, cut from
main after #591 merged. M and A hold the same `.github/` and `tools/` as that
ref, so the release-event capture, which runs at A (below), ran the same
code. The PR stage also published the four required contexts (`checkwash`
128340763857 and the three candidate assertion contracts 128340765734,
128340766916 and 128340768481), each bound to its manifest. Each later
stage's receipt admits the previous stage's verified report and check: main
admits the PR head's `checkwash` check 128340763857, tag admits main's
128426634501, the release event admits the tag's 128439342497 and the public
visitor the release event's 128452298440.

In every stage the full suite completed with 22,854 tests and 67 subtests
reported (22,921 rows), 0 failures, 0 errors and 25 skipped. Source, wheel
and pyz qualification each passed 283 of 283 cases, and every collected
command exited 0, among them the inventories, `twine check`, both composite
Action replays and the advertised v0.11.0 visitor. The 185-case verdict gate
(159 T1, 26 T3), against the v0.11.0 baseline, passed with zero failures in
every stage and reported one case, i198/S1, which the v0.11.0 baseline
passes and the candidate blocks (`pass-to-block`; it was labelled `pass`
then, and #594 relabelled it `block`, [D-202](../../DECISIONS.md);
[RELEASING](../RELEASING.md#v0120-checked-publication-and-pin-promotion-2026-11-08));
the other 184 kept their verdicts (160 block, 24 pass). The `own_action_pin`
record of every stage names A as the release's Action commit, v0.11.0's
`257150319fca15235185fc629d8b9c21c17166ca` as the previous pin and R as the
release pull request's head.

From the tag stage on, the tag source check found the remote tag object
`6f8b8b7a` peeling to A with tree `97381f3b`, and the tag visitor installed
`git+https://github.com/taipei49314/checkwash.git@v0.12.0`, which resolved
to A: version 0.12.0, 218 members equal to A's `src/checkwash`, which differ
from M's only in `doctor.py`. From the tag stage on, the verdict gate's tag
rule also checked that the pushed tag points at A and names M, re-read the
published releases and tags through the GitHub API, and found its baseline,
v0.11.0, the highest other published release merged into M.

Every stage was collected once and dispatched once; each verification run
is attempt 1. One local step failed and was repeated: the PR stage's first
dry run was pointed at the readback directory instead of a checkout of the
receipt commit and could not read the Git evidence; on the checkout it
verified. Nothing was dispatched from the failed run.

The release event's receipt also seals the release authorization
(`release/release-authorization.json`, `dc35d6d9`) and the missing-platform
acceptance (`release/platform-acceptance.json`, `4eab2aa1`), and its dispatch
admission names both. The trusted `publication_authority` accepted them on
the collection's inputs, before the collection. For 0.11.0 Claude had also
run it on the published receipt before dispatch; for 0.12.0 it did not, and
it ran it on the published receipt's readback only on 2026-11-07, after
publication, where it accepted both. The verification and stage-check reports say
`publication_authorized: false`, as verify mode always does; the
`publish-assets` report and the `pypi` job's handoff, which check the
authorization again before acting, say `true`.

The release event was GitHub's own: the Release was published at
2026-11-07T15:06:03Z, and run 42384715859, which the event started at the
commit the tag points to, A, read M from the tag's message, confirmed that
`M^2^1` is A and captured M as the head (D-200).

The public-visitor stage ran after both publications: its native capture
(run 42389734518, 2026-11-07T16:08:00Z) came after the PyPI upload, and its
receipt admits the release event's verified stage-check report (`2a94f83e`)
and check 128452298440.

One other check run on M failed, and it is not a release check: Dependabot's
npm security update (128413682300, 2026-11-07T13:14Z) could not raise
`minimatch` past the constraint of jest 30.5.2 in
`tools/measure428/empty-tables/`, as on v0.11.0's M. That directory is #428's
measurement tool, run only by a manually dispatched measurement workflow; its
`package.json` and lock ship in the sdist, but the CLI, the Action and the
hooks never use them.

## Release assets and PyPI

The Release was created without assets. Run 42388724734's `publish-assets`
job attached the exact receipt artifacts and read them back:

| File | Asset ID | Bytes | SHA256 |
| --- | --- | --- | --- |
| `checkwash-0.12.0-py3-none-any.whl` | 721168235 | 1,036,789 | `1b7d259e88046b92139219bce07939e87b1aa3302dee91e1b87f8df075b6d2bf` |
| `checkwash-0.12.0.tar.gz` | 721168298 | 5,474,165 | `d53bad586652a9e3573009d82cec12ba338aafcbae445f8ff24a9161d7c8b79c` |
| `checkwash.pyz` | 721168390 | 1,013,508 | `4ef6eda2d4ff5b378c12874f43b825be3ce2d8ef97c2f1c5f44bfae06ee18cb2` |

The wheel and sdist are byte-identical to the ones every earlier stage built
from R's tree. The pyz files of the stages hold the same members with
identical contents; only the zip entries' build timestamps differ, so the
pyz bytes differ between builds (RELEASING, "pyz reproducibility").
The same run's `pypi` job waited for the `pypi` environment review from
2026-11-07T16:00:45Z. Claude did not try to approve it: its session logs
show only reads of the run's approvals and pending deployments. GitHub
records an approval by the account taipei49314 (state approved, no
comment), which Claude's `gh` also uses, and the deployment was queued at
16:04:18Z, before Nelson answered that he had approved it on the run page
(RELEASING). The job re-read the source and the actual GitHub asset
bytes with the trusted `verify-assets`, exported the wheel and sdist, and
uploaded them through trusted publishing with attestations; `twine check`
passed for both, and the job succeeded at 16:06:22Z. PyPI serves both files,
not yanked, with the SHA256 values above, and each file's provenance names
the publisher `taipei49314/checkwash`, workflow `release.yml`, environment
`pypi`.

The check that [RELEASING](../RELEASING.md#check-the-public-package-page)
asks for before publishing, of the candidate wheel's metadata and of every
link in its description, was not run before the upload this time. What ran
before it was each stage's `twine check`. After the upload, PyPI's JSON API
gave name `checkwash`, version 0.12.0, `Requires-Python >=3.11`, license
expression Apache-2.0, the project URL `Homepage` =
`https://github.com/taipei49314/checkwash` and a description equal to M's
README byte for byte, and the project page and the 0.12.0 page were read
in a browser; both answer a non-browser request with a JavaScript client
challenge, which passed without interaction. The 0.12.0 page shows
`pip install checkwash==0.12.0`, marks it the latest release and shows
Python >=3.11, license Apache-2.0, the homepage and provenance for both
files; the project page lists 0.12.0 first, with full provenance, and
renders the same description.
The rendered description holds 60 links. Its eight in-page anchors resolve
on PyPI. Each of the 38 links to a file in this repository (29 distinct)
names a file that exists at M, main when checked, with any anchor matching a
heading there, and each of the other 14 (13 distinct: the CI workflow, the
PyPI project, the GitHub README, the v0.11.0 pyz download, six issue and
pull-request links, the issue list and the two sibling repositories)
returned HTTP 200. As that README says, its install commands and Action pin
name v0.11.0; this follow-up moves the GitHub README to 0.12.0. The wheel and
sdist downloaded from PyPI are byte-identical to the GitHub assets.

## Public visitor

The public-visitor collection read everything over the network after its
native capture (2026-11-07T16:08:00Z):

- The Release metadata (ID 437647350, not draft or prerelease, three uploaded
  assets with matching sizes and `sha256:` digests).
- The three GitHub downloads, from the canonical
  `releases/download/v0.12.0/` URLs.
- The PyPI version metadata and its two files from `files.pythonhosted.org`,
  neither yanked. Each PyPI file equals the GitHub copy byte for byte.

Four fresh virtual environments each installed one public file (GitHub wheel,
GitHub sdist, PyPI wheel, PyPI sdist) with `--no-deps`. Each reported version
0.12.0, recorded the downloaded file's SHA256 in `direct_url.json`, installed
package members equal to M's `src/checkwash` (218 files), passed `pip check`,
ran `demo`, and checked `e27eec6b..M` with `--fail-on high` (verdict pass,
one WARN: `CI_WORKFLOW_TOUCHED` on `pyproject.toml`). The downloaded pyz
passed the zipapp qualification, ran `demo` and the same check. All exits
were 0. Before publishing the stage check, the verifier checked the Release
metadata, the PyPI metadata and every download against the receipt's raw
network reads, and re-read the live tag and Release through the GitHub API.

## Limits

These are Windows/CPython 3.11.9 results from one host. The follow-up that
adds this record advances the advertised pins to v0.12.0: the CLI commands
to 0.12.0 and the Action pin to A, the commit the tag points to, which no
release stage replayed; the Action runs only `checkwash check`, which never
imports `doctor`, the one file in which A and M differ. `doctor` 0.11.0
rejects that pin (exit 1); `doctor` 0.12.0 accepts it and v0.11.0's. A CLI
installed through Git from the tag is A's, and its `doctor` rejects the pin;
the README installs the CLI only from PyPI and the pyz. Downstream re-pins
need their own authorization. The disclosed costs and known issues are in
the [release guide](v0.12.0-public-launch.md) and
[KNOWN-ISSUES-v0.12.0](../KNOWN-ISSUES-v0.12.0.md). 1.0 remains NOT_MET.
