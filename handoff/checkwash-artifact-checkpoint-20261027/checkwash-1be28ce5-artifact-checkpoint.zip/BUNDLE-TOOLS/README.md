# Private completed-artifact preservation plan

Candidate/source: `1be28ce5de72dcb617818077aaf11e3b1cf7a976` (0.10.0 / IR3).
Previous verified evidence checkpoint:
`815dc12b7786783a7f6004d5360640d37ee49309`; its inherited product root is not
this separate candidate. This tool does not publish or contact remote refs.
Any later backup publisher must freshly verify its own remote parent.

The fixed eligible list has 112 originals / 17,411,520 bytes, SHA256
`bed93c947942edebd3836ced59b3af5af9ee16fa019eecaefc3a10e86c6fe901`.
Nine selected source-bound native jobs have actual terminal exit0: source
sealing, build-source preparation, wheel/sdist build, pyz build, wheel runtime
preparation, wheel install, artifact identity, wheel console smoke and pyz
process smoke. Original stdout/stderr, command, source/input maps and times are
included. Their bounded results are not qualification or release acceptance.

Four raw artifacts are retained byte-for-byte:

| Artifact | Bytes | SHA256 |
| --- | ---: | --- |
| Source ZIP | 5,972,055 | `75525d80efa6052aa493ce30461c88f256616f841ab7961189871d09cb521554` |
| Wheel | 966,064 | `f03725f152165b6f6a525d59ed43c840e8e3300cd1d0a5fe2881347a19b9499a` |
| Sdist | 4,663,415 | `663be3ce65dccabedfe1cad8b00c6afb16d52423b826ccd461372dce89825c01` |
| Pyz | 944,675 | `526807199ebf7fbc948327c1fb2c4bed51c0ba0abde94c13f090ce7354fc8f9e` |

Archive members are read, never extracted/installed/executed. Fresh read-only
checks require the complete 3087-file source ZIP, all 3087 tracked sdist files
plus only generated PKG-INFO, all 213 source package members in wheel and pyz,
valid wheel RECORD rows and Name/Version metadata, and the exact generated
zipapp entry. Each regular source member must match the pinned source seal;
artifact hashes must also match the terminal identity record. The inherited
privacy scanner recursively scans original ZIP/whl/pyz/tar bytes, regular/link
types, path safety, bounded expansion, global-memory fingerprints, key shapes
and authenticated URLs. Its default is unchanged and no payload exception is
used. A refusal stops rather than silently omitting a selected original.

Source guard requires exact 1be, clean checkout, required trusted 1ffe object,
fixed stage9 seal SHA256
`46989bcecf9657281cdb4cea640f554a3cd7d9a35abd3260ad489c7c52859945`,
all 3087 tracked physical bytes and Git blob identities. It is repeated around
planning/packing together with original input, controller, artifact closure and
selected terminal-receipt checks. No Git write, test, model or product call is
made. No host-global runtime/security setting changes.

The tool is derived from the reviewed stage5 packer `ab1ab82c...2a08928`.
Its raw original and exact diff are preserved. Privacy/key/archive checker,
strict regular-file reads, Git read wrapper, denied hashes and deterministic
ZIP writer retain their original function bodies. Source-guard changes only
select the new exact namespace/PIN and add seal/count pins. Selection is now
explicit rather than walking live outputs. The old global-terminal qualifier
contract is not repurposed: this new bundle kind is specifically
`COMPLETED_ARTIFACT_SNAPSHOT_WITH_LIVE_QUALIFICATIONS_EXCLUDED`, and its terminal
state concerns only the nine selected jobs.

As in the original packer, controller provenance is handled separately from
ordinary payload: stable text, key-pattern and complete global-header-line
refusal, plus an exact hash for the original scanner source. Those files contain
scanner marker literals, not private global instructions. The archive payload
privacy checker is unchanged; arbitrary source/data does not receive this
controller provenance treatment. Independent review must verify the exact
derived controller and original before any pack.

All three assertion-qualification output trees and their outer captures are
excluded, even if later terminal. Mutable STATUS/status history, full-suite
output, runtimes, caches, temporary/build trees and prior evidence ZIPs are not
inputs. Only the qualification reader/controller **source** is included for
restoration; it is not run by this packer and carries no qualification result.
The seven stage10 #263 files are frozen read-only / NOT_IMPLEMENTED analysis.
The old fixture has no supplied producer implementation; do not infer `a+b`
or discard class/self without the documented closed proof obligations.

Default invocation creates only the plan under this work directory. After root
and independent review, a single `--pack --expect-plan-sha256 <exact digest>`
may create `outputs/checkwash-artifact-checkpoint-20261027/` containing the ZIP,
sidecar and entry. Fresh files only; existing bytes/plans/receipts are preserved.
The ZIP uses sorted paths, fixed1980 timestamps, regular0644 and Deflate9.
Readback verifies every member hash and CRC. No product publication occurs.

The repair goal is incomplete. Prior integration self-check remains BLOCK;
full-suite/qualification workers are outside this snapshot. This private
checkpoint is not PyPI/GitHub Release, a merge, a new 1.0 grant or a PASS for
unperformed checks. Nelson must decide before 1.0. Privacy checks are bounded,
not a universal secret-free assurance.
