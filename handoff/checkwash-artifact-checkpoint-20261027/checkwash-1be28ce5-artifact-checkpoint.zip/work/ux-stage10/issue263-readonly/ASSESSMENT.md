# #263: exact remaining obligations after the inactive-fixture repair

**A safe automatic repair is feasible as a separate bounded proof. Capability migration alone is necessary and insufficient.** This packet changes no product, test, expected value or previous evidence. It makes no new analyzer/pytest/subject/model calls. The fixed candidate examined is `1be28ce5de72dcb617818077aaf11e3b1cf7a976`; its full-suite/qualification jobs are outside this read-only task.

## Verified source and existing observations

The complete `tests/test_issue263_string_conditions.py` bytes in fbc and exact Git 1be are identical, SHA-256 `5a1b78dad3cb54bbb9b37cb966c06d60ff625058187b6bb5bdcfb7e3f311a60b`. The existing PASS assertions are unchanged. Its `outcome` caller supplies neither strict readers nor search/path/batch capabilities. The constructor moves two plain functions into `TestAdd`, adds an unused leading `self`, and introduces a class `pytestmark` referring to `old_python = pytest.mark.skipif("sys.version_info < (2,6)")`.

Two already captured fbc static API arms exactly match these before/after fixture bytes:

| Existing arm | Actual outcome | Captured proof state |
| --- | --- | --- |
| `263-original` | BLOCK, two `TEST_DISABLED/high`, no de-escalator | Both startup contexts unknown; all unit proofs empty |
| `263-closed-root` | Same BLOCK and two high findings | Startup known; both plain-function proofs present; both class-arrival proofs empty |

The latter snapshot contains only the changed test module. It supplies **no `app/calc.py` or `app/__init__.py` implementation**. These observations belong to fbc, not 1be. Their complete findings, fingerprints, source hashes and proof fields are retained in `source-and-diagnostics.json`. This reader verified their raw hashes against the existing results index and the fixture strings against restricted literal AST construction; it did not call a constructor or analyzer.

## What can be done safely now

The ordinary caller can be migrated to an explicit complete snapshot while preserving every assertion: strict reader, content search with complete empty-needle Python inventory, full raw path inventory and its paired batch reader. Changed BASE/HEAD bytes must remain side-correct through `FileChange`. Apply this narrowly to the relocation control, or give the helper an explicit optional snapshot parameter; do not silently treat all callers as complete repositories.

That is an ordinary capability correction, **not an expected-PASS fix**. The existing closed-root arm already shows that the resulting after-side proof remains unavailable. To make this control a complete normal case, the test also needs an explicit inert `app` package and source for `add`. Supplying `def add(a, b): return a + b` would be a new, stated synthetic input/context completion, not a discovery about the old fixture. It may preserve the old PASS intent and assertions, but must be identified separately from callback plumbing. Never infer that implementation from the imported function's name.

## The smallest useful product proof

Implement a separate optional passive-pytest-class certificate, leaving D-179's requirement for a complete declaration/binding/control context intact. The normalization would apply only to certified methods and their matched plain-function obligations. It needs all of the following:

1. **Complete side-correct repository authority.** Require the same bounded read/search/raw-path capabilities used for source-bound proofs, reconstruct actual changed sides, and retain producer/initializer byte identities in the certificate. Check ancestor and nonancestor conftests, collectable siblings, package initializers, startup modules, configs, distribution plugin metadata and case/prefix aliases. Unknown or exhausted input withholds credit. A HEAD callback must not silently supply changed BASE source.
2. **A passive class, not generic class erasure.** Admit only one plain top-level `Test*` class with no bases, keywords, decorators, nested classes, constructor, setup/teardown/protocol methods, helper methods or mutable class state. Its body contains only selected ordinary test methods and the single admitted `pytestmark` binding (plus optional inert doc/pass). Reject unknown module/class declarations rather than dropping them from the environment.
3. **A genuinely inactive marker.** Resolve the unique `old_python` store and its sole class-`pytestmark` load, with canonical unshadowed `pytest` authority and valid literal factory arguments. The current string parses to a pure version comparison and is false for every version in the declared Python 3.11–3.14 × three-platform matrix. This is stronger than D6's “runs somewhere” compatibility classification. A Windows-only skip, unknown string, different marker, rebound alias or arbitrary factory must not be projected away. Even a false skip condition still introduces marker metadata: setup/plugin code that can observe it must be absent or independently proved harmless.
4. **A plain unused receiver.** Require the exact leading positional `self`, with no annotation/default/variadics, and no receiver load, capture, attribute use or reflective access in any admitted method. Remove only this certified parameter from the proof representation; do not normalize arbitrary `self`/`cls` signatures, inheritance or dispatch. Preserve the actual IR and ordinary frontend output.
5. **Closed source-bound call effects and values.** Every admitted assertion/prefix/suffix must use bounded literal primitive operations and uniquely resolved repository producers. Check exact source identities on both sides, inert import parents, valid positional/keyword/default binding and compiler-reserved names. For this fixture, literal `add(1,2)`/`add(2,2)` with a closed arithmetic definition is a feasible first domain. A frame/locals/name observer, unknown helper, import side effect, callee rebinding or mismatched source earns no proof. Two separate `pure=True` booleans do not establish the same function or value.
6. **Matched context and counted obligations.** Only after those checks may the certified wrapper/marker alias, class-name component and unused receiver be represented by a common passive-wrapper identity. Keep the rest of the declaration/module/startup context and all assertion operands, expected values, prefix/suffix and multiplicity. This fixture's two different assertions must stay two obligations. D1/D3 repair evidence remains independent; do not alter gates, strength or generic move-credit rules.

These are source-proof obligations that can be implemented and reviewed automatically within the existing bounded model; they do not require changing the existing expected PASS or handing every decision to a maintainer. A successful implementation still needs a new source identity and actual red/green/negative validation. None was performed or predicted as PASS here.

## Why 1be still lacks this proof

The 1be `_python_context` implementation is source-bound for the newly admitted inactive fixture, selected only when `request` occurs. #263 has no such fixture and is outside that new domain. Its environment builder still refuses the Call-valued `old_python` assignment. If that rejection were removed alone, the residual class/alias environment, `class_name`, full args and function declaration would still differ. If those were all discarded without a certificate, an opaque `add` could inspect caller locals or a class/marker-dependent setup could alter reachability.

There is therefore no sound “one-line ignore class/self” fix supported by the original inputs. The concrete safe next work is the caller/context completion plus the narrowly certified class domain above. Unknown producer semantics and absent full context are explicit reasons to retain UNKNOWN until those prerequisites are supplied; they are not reasons to relabel the old ordinary fixture or broaden the inactive-fixture proof.

The 12-environment statement above is a literal-source analysis of the declared matrix, not native execution on 12 platforms. External ambient import/plugin behavior remains subject to the existing frontend's trust model; this proposal must not invent guarantees beyond that model.

`source-and-diagnostics.json` SHA-256: `8a98d177c44cbc61f38159d9ca99c338560d4806061eb6bb2c51f1390e10f6a7`. Exact fixture and test source copies accompany it. All new files are confined to this read-only analysis directory.
