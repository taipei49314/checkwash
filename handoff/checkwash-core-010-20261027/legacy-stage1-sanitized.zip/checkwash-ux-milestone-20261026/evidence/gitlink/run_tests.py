"""Preserve native stdout/stderr and exact local test provenance."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import socket
import subprocess
import sys

root = Path(__file__).resolve().parents[2] / "work/checkwash-ux"
out = Path(__file__).resolve().parent
name = sys.argv[1]
command = [sys.executable, "-B", "-m", "pytest", "-p", "no:cacheprovider",
           "--basetemp", str(out / f"{name}-fixtures"), *sys.argv[2:]]
env = {**os.environ, "PYTHONPATH": str(root / "src"), "PYTHONDONTWRITEBYTECODE": "1", "PYTHONUTF8": "1"}
start = datetime.datetime.now(datetime.timezone.utc).isoformat()
result = subprocess.run(command, cwd=root, env=env, capture_output=True, timeout=900)
(out / f"{name}.stdout").write_bytes(result.stdout)
(out / f"{name}.stderr").write_bytes(result.stderr)
diff = subprocess.run(["git", "diff", "--binary"], cwd=root, capture_output=True, check=True).stdout
meta = {"provenance": "HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL", "hostname": socket.gethostname(),
        "platform": platform.platform(), "python": sys.version, "executable": sys.executable,
        "git": subprocess.run(["git", "--version"], capture_output=True, check=True).stdout.decode().strip(),
        "pytest": __import__("pytest").__version__, "source_sha": subprocess.run(
            ["git", "rev-parse", "HEAD"], cwd=root, capture_output=True, check=True).stdout.decode().strip(),
        "git_diff_sha256": hashlib.sha256(diff).hexdigest(), "started_utc": start,
        "owned_file_sha256": {p: hashlib.sha256((root / p).read_bytes()).hexdigest() for p in (
            "src/checkwash/gitio/git.py", "tests/test_gitlink_snapshot.py")},
        "finished_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "command": command,
        "cwd": str(root), "exit_code": result.returncode,
        "stdout_sha256": hashlib.sha256(result.stdout).hexdigest(),
        "stderr_sha256": hashlib.sha256(result.stderr).hexdigest(),
        "fixture_execution": "No analyzed fixture Python is executed; fixture repositories are Git/static inputs."}
(out / f"{name}.json").write_text(json.dumps(meta, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"name": name, "exit": result.returncode,
                  "summary": result.stdout.decode("utf-8", "replace").splitlines()[-4:]}, ensure_ascii=False))
sys.exit(result.returncode)
