"""One preserved static input through native JSON and Stop-hook entrypoints."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import socket
import subprocess
import sys

out = Path(__file__).resolve().parent
root = out.parent / "checkwash-ux"
stage = sys.argv[1]
case = out / "native-case"
repo = case / "parent"
if stage == "before":
    case.mkdir()
    spec = importlib.util.spec_from_file_location("gitlink_fixture", root / "tests/test_gitlink_snapshot.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    repo = module.submodule_repo.__wrapped__(case)
    module.dirty(repo, "tracked")
    (repo / "tests/test_total.py").write_bytes(module.TEST.replace(b"== 78.75", b"== 75"))
env = {**os.environ, "PYTHONPATH": str(root / "src"), "PYTHONDONTWRITEBYTECODE": "1", "PYTHONUTF8": "1"}
context = repo / "vendor/lib/context.py"
saved_context = context.read_bytes()
neighbor = repo / "tests/test_total.py"
saved_neighbor = neighbor.read_bytes()
if stage == "clean-control":
    context.write_bytes(b"ANSWER = 78.75\n")
if stage == "dirty-only":
    neighbor.write_bytes(b"from pkg import total\n\ndef test_total():\n    assert total() == 78.75\n")
rows = []
for fmt in ("json", "hook-json"):
    command = [sys.executable, "-B", "-m", "checkwash", "check", "--repo", str(repo), "--format", fmt]
    result = subprocess.run(command, cwd=root, env=env, capture_output=True, timeout=60)
    stem = f"native-{stage}-{fmt}"
    (out / f"{stem}.stdout").write_bytes(result.stdout)
    (out / f"{stem}.stderr").write_bytes(result.stderr)
    rows.append({"format": fmt, "command": command, "exit": result.returncode,
                 "stdout_sha256": hashlib.sha256(result.stdout).hexdigest(),
                 "stderr_sha256": hashlib.sha256(result.stderr).hexdigest()})
meta = {"provenance": "HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL", "hostname": socket.gethostname(),
        "runtime": sys.version, "repo": str(repo), "fixture_execution": "Static inputs only; no fixture code run",
        "source_sha": subprocess.run(["git", "rev-parse", "HEAD"], cwd=root, capture_output=True,
                                     check=True).stdout.decode().strip(),
        "owned_source_sha256": hashlib.sha256((root / "src/checkwash/gitio/git.py").read_bytes()).hexdigest(),
        "input_sha": subprocess.run(["git", "rev-parse", "HEAD"], cwd=repo, capture_output=True,
                                    check=True).stdout.decode().strip(), "results": rows}
(out / f"native-{stage}.json").write_text(json.dumps(meta, indent=2) + "\n", encoding="utf-8")
context.write_bytes(saved_context)
neighbor.write_bytes(saved_neighbor)
print(json.dumps(rows))
