# Registered gitlink changed-file reader repair

Scope: handoff cluster `B2-worktree-renames-submodules`, claims `#9-1`, `#9-2`, `#9-3`, `#9-4`, `#9-7`.

Actual host: `LAPTOP-01AGNPJU`; `HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`.
Runtime: Windows, Python 3.11.9, pytest 9.1.1, Git 2.55.0.windows.3.
Original analysis baseline: `1ffe283d7d947fecc426dea99323b0a2620a9482`.

## Reproduced behavior

Native porcelain v1 reports modified/untracked-content/unstaged-pointer submodule dirt as uppercase ` M vendor/lib`, and a staged pointer as `M  vendor/lib`. There is no lowercase-`m` parser defect here (`#9-2` remains refuted).

Before the fix, the changed-file adapter asks its regular-file reader to open this registered gitlink directory. A neighboring expected-value rewrite consequently returns JSON exit 2 and no ordinary verdict; the Stop-hook format exits 0 with a NOT_ANALYSED message and no blocking decision. These original bytes are in `native-before-{json,hook-json}.{stdout,stderr}`.

The new 22-case regression module initially recorded **18 failures / 4 passes**, exit 1 (`before.*`). The already-working controls included a committed pointer in session mode, a gitlink replaced by a regular file, an unregistered nested repository's refusal, and ordinary files under a new directory.

## Narrow implementation

Only `src/checkwash/gitio/git.py` and new `tests/test_gitlink_snapshot.py` are owned by this repair.

An actual directory at a changed path is treated as a pointer rather than a regular after-side file only when native Git returns exactly one complete, exact-path, stage-0 mode-160000 index entry. The query uses literal pathspecs. Ordinary directories, symlinks and unregistered nested repositories receive no such exemption. A regular before-side file replaced by a gitlink retains its removal evidence.

`WorkingTreeSnapshot` is unchanged. Checked-out submodule contents remain readable as context under D-123; there is no new blanket opacity or `.git` heuristic. The regression module explicitly checks that context remains listed/readable.

## Validation

- New regression module: **22 passed**, exit 0, 248.43 seconds (`after.stdout`, `after.stderr`, `after.json`).
- The same native neighboring rewrite after the fix returns JSON exit 1 with `EXPECTED_VALUE_CHANGED/high`; Stop-hook JSON exits 0 with `decision: block`. Original bytes and commands are in `native-after.*`.
- A clean-submodule control keeps the same neighboring rewrite: both JSON and hook output bytes are identical to the dirty-submodule candidate (`native-clean-control.*`). Its finding fingerprint remains `EXPECTED_VALUE_CHANGED/tests/test_total.py/test_total/v2:1c5be6ff58baf65473ca9ae4c66a32eb2839bad841a1c6f1133f40fcca0e2958`.
- Dirty-submodule-only native control with no neighboring edit: JSON exit 0/pass and hook-json exit 0/`{}` (`native-dirty-only.*`).
- Existing `test_git_input_failures.py`, `test_issue335_opaque_submodules.py`, `test_issue414_worktree_directory_symlinks.py`, and `test_strict_snapshot.py`: **191 passed / 9 skipped**, exit 0, 322.74 seconds (`regressions.stdout`, `regressions.stderr`, `regressions.json`). Skips are retained and are not counted as passes.

The before/after targeted runs occurred on a shared integration checkout while unrelated atomic CLI/quality work advanced. They establish this owned reader defect and its controls, not immutable whole-tree release qualification. The original owned `git.py` SHA-256 is `fc681042e800a8818a4bef21973f85ead1a0ad434659ffd8f9bc93d1fd759e9b` and matches the baseline. `native-before.json` records it; after receipts record both owned-file hashes. Root will bind the final candidate commit to its complete suite.

No protected policy, frozen contract, existing fixture expectation, version metadata, tag, release or downstream pin was changed. No analyzed fixture Python was executed. Non-Windows platforms, other Python versions and release qualification were not run by this task.

Root integrated this named defect as commit `08a96b15` after the targeted run. This task did not commit, push or merge.
