"""Four single synthetic commit comparisons; no historical corpus or fixture execution."""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import platform
import socket
import subprocess
import sys

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent / "rename" / "source-v091" / "src"
SHA = "1ffe283d7d947fecc426dea99323b0a2620a9482"
ENV = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", PYTHONUTF8="1", PYTHONPATH=str(SOURCE))

def call(cmd, repo, *, data=None):
    return subprocess.run(cmd, cwd=repo, env=ENV, input=data, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=90)

def git(args, repo, *, data=None):
    p = call(["git", *args], repo, data=data)
    if p.returncode:
        raise RuntimeError(p.stderr.decode("utf-8", "replace"))
    return p.stdout.decode("ascii").strip()

def write(repo, path, text):
    p = repo / path
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(text.encode())

def main():
    rows = []
    for case in ("regular_pytest_config", "symlink_pytest_config", "malformed_check_config", "malformed_check_allow"):
        repo = HERE / "repos" / case
        repo.mkdir(parents=True, exist_ok=False)
        git(["init", "-q"], repo)
        git(["config", "core.autocrlf", "false"], repo)
        git(["config", "user.name", "Synthetic Comparison"], repo)
        git(["config", "user.email", "synthetic-comparison@example.invalid"], repo)
        test = "from calc import calc\n\ndef test_calc():\n    assert calc(1) == 2\n"
        write(repo, "tests/test_calc.py", test)
        write(repo, "calc.py", "def calc(x):\n    return x * 2\n")
        target = "pytest.ini" if case == "regular_pytest_config" else "cfg/pytest-settings.ini"
        if "pytest_config" in case:
            write(repo, target, "[pytest]\ntestpaths = tests\n")
        elif case == "malformed_check_config":
            write(repo, ".greenwash/config.toml", "[broken\n")
        else:
            write(repo, ".greenwash/allow.toml", "[broken\n")
        git(["add", "."], repo)
        if case == "symlink_pytest_config":
            oid = git(["hash-object", "-w", "--stdin"], repo, data=b"cfg/pytest-settings.ini")
            git(["update-index", "--add", "--cacheinfo", f"120000,{oid},pytest.ini"], repo)
        git(["-c", "core.hooksPath=NUL", "commit", "-qm", "base"], repo)
        base = git(["rev-parse", "HEAD"], repo)
        if "pytest_config" in case:
            write(repo, target, "[pytest]\ntestpaths = tests\naddopts = --deselect tests/test_calc.py::test_calc\n")
            git(["add", target], repo)
        else:
            write(repo, "tests/test_calc.py", test + "\n# harmless formatting-only change\n")
            git(["add", "tests/test_calc.py"], repo)
        git(["-c", "core.hooksPath=NUL", "commit", "-qm", "candidate"], repo)
        head = git(["rev-parse", "HEAD"], repo)
        for entry in ("range", "sweep"):
            command = [sys.executable, "-B", "-m", "checkwash"]
            command += (["check", base + ".." + head, "--format", "json"] if entry == "range"
                        else ["sweep", head, "--limit", "1"])
            command += ["--repo", str(repo)]
            p = call(command, repo)
            raw = HERE / "raw" / case
            raw.mkdir(parents=True, exist_ok=True)
            (raw / (entry + ".stdout")).write_bytes(p.stdout)
            (raw / (entry + ".stderr")).write_bytes(p.stderr)
            try:
                payload = json.loads(p.stdout)
            except ValueError:
                payload = None
            row = {"case": case, "entry": entry, "base": base, "head": head,
                "source_sha": SHA, "command": command, "cwd": str(repo), "exit": p.returncode,
                "stdout_sha256": hashlib.sha256(p.stdout).hexdigest(),
                "stderr_sha256": hashlib.sha256(p.stderr).hexdigest(), "payload": payload,
                "stdout": str((raw / (entry + ".stdout")).relative_to(HERE)),
                "stderr": str((raw / (entry + ".stderr")).relative_to(HERE))}
            (raw / (entry + ".meta.json")).write_text(json.dumps(row, ensure_ascii=False, indent=2), encoding="utf-8")
            rows.append(row)
            print(case, entry, p.returncode, json.dumps(payload, ensure_ascii=True), flush=True)
    result = {"marker": "HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL", "hostname": socket.gethostname(),
        "platform": platform.platform(), "python": sys.version, "python_executable": sys.executable,
        "source_sha": SHA, "source_path": str(SOURCE), "scope": "4 synthetic commits, one per fixture; 8 static CLI calls",
        "fixture_execution": "NOT_RUN; only CheckWash statically analyzes fixture source",
        "symlink_creation": "Git 120000 blob/index only; no host symlink or privilege change",
        "rows": rows}
    (HERE / "results.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")

if __name__ == "__main__":
    main()
