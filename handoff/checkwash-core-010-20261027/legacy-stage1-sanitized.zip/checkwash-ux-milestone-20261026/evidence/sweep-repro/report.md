# Sweep input parity：單一 synthetic commit 證據

日期：2026-10-26（Asia/Taipei）。主機 LAPTOP-01AGNPJU；標記 `HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`。

固定改前來源 `1ffe283d7d947fecc426dea99323b0a2620a9482`，使用 `work/rename/source-v091/src` 的 exact Git archive。Python 3.11.9。只建立四個 synthetic Git 倉，每倉比較同一個 candidate commit 的 `check base..head --format json` 和 `sweep head --limit 1`；共八次 CLI。不跑歷史語料、不執行 fixture 的 Python/pytest 程式。

## 改前觀察

| 最小案例 | range check | sweep（同一 commit） | 結論 |
|---|---|---|---|
| regular root pytest.ini 新增 --deselect | exit1；CI_WORKFLOW_TOUCHED high/BLOCK | exit0；commits_analysed=1、commits_blocked=1、相同 high rule | 正常控制一致；sweep CLI 的 exit0 是其既有回報契約，不能把它當成 verdict PASS |
| mode120000 pytest.ini 指向 cfg/pytest-settings.ini，僅 target 新增 --deselect | exit1；physical target 的 CI_WORKFLOW_TOUCHED high/BLOCK，保留 logical alias 與 blob 證據 | exit0；commits_analysed=1、commits_blocked=0、engine_errors=0、findings_by_rule={} | 實測漏抓，並非只有 exception 統計不透明 |
| base .greenwash/config.toml malformed，head 只加 harmless comment | exit0/PASS；config_errors 有 parse error，stderr 有診斷 | exit0；commits_analysed=1、engine_errors=0；無 parse 診斷 | 診斷被丟棄；本 fixture 兩入口 exit 相同，不能誤寫成 range exit2 |
| base .greenwash/allow.toml malformed，head 只加 harmless comment | exit0/PASS；config_errors 有 parse error，stderr 有診斷 | exit0；commits_analysed=1、engine_errors=0；無 parse 診斷 | 診斷被丟棄；不表示有效豁免 |

Git symlink 只透過 Git 120000 blob/index 建立，沒有 host symlink、權限或安全設定變更。完整 source/runtime、command、cwd、base/head SHA、exit、stdout/stderr SHA-256 與 payload 在 `results.json`；原始 bytes 在 `raw/`。

## 窄修邊界

只補 sweep 的 `PairedPytestConfigs(GitSnapshot(base), head_snapshot)` 輸入，並對齊 range 的 head_snapshot reader。新增獨立四格 parity regression：regular/Git-symlink × comment-only/deselect，核對同一 commit 的 range findings、rule/severity 計數、blocked commit 身份與詳細 findings。實作與測試終態另列後續 validation 收據。

不更動 JSON schema、exit、config/allow parse-error 的既有處置、exception 計數或 protected gating；malformed 診斷是獨立未修問題。

## 每個 commit 的 diagnostics 提案（未實作）

可另議新增可省略的 `commit_diagnostics` array，只在有診斷時出現。每列固定完整 `commit`，已知時加 `parent`，再有 `phase`（load_config / load_allowlist / analyze）、`kind`（config_parse_error / config_warning / allow_parse_error / analysis_exception）、`message`；exception 列另有 `exception_type`。未知 parent 省略而不捏造；每筆保留實際階段與原始訊息。

此方案保留既有數值計數及所有原始 raw。parse-error 診斷不假裝成已發生的 analysis exception，未分析的 commit 不混入 PASS 分母。格式新增欄位仍需檢查現有 strict consumer，並把一次完整的例子交 maintainer 審查；本輪不實作或宣稱接受。

未執行：其他 OS/Python、歷史 sweep、正式發版 qualification、模型/標註批次。這是工具入口 parity 的 synthetic regression，不是新的 block-rate 或 false-positive 成效量測。

## 窄修驗證終態

新增四格 parity regression 在固定改前 archive 上為3通過/1失敗，唯一失敗是 alias target 的 deselect 漏抓。補齊輸入後，四格全部通過；連同相關既有 config/nested/sweep-error 回歸，原始退出碼0，27個選中案例為26通過/1跳過。原始 -qq 未列出跳過原因，因此此收據不宣稱該跳過路徑已執行。

產品變更只在 src/checkwash/sweep.py：import PairedPytestConfigs，建立paired base/head context，傳給analyze，並把head_reader對齊既有head snapshot。測試檔為新增 tests/test_sweep_input_parity.py。兩檔已交root固定，不再由本agent更動。完整命令、runtime、native exit與SHA-256在 validation.json；此為有明確檔案hash的working-tree targeted驗證，最終commit的full suite仍由root另行執行。
