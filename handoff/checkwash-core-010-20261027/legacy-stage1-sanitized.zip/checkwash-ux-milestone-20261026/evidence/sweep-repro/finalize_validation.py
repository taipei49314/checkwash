from __future__ import annotations
import datetime
import hashlib
import json
from pathlib import Path
import platform
import socket
import sys

HERE = Path(__file__).resolve().parent
REPO = HERE.parent / "checkwash-ux"

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

summary_line = (HERE / "test-after.stdout").read_text(encoding="utf-8").splitlines()[0].split()[0]
assert summary_line.count(".") == 26 and summary_line.count("s") == 1
assert (HERE / "test-after.exit").read_text().strip() == "0"
before_line = (HERE / "test-before.stdout").read_text(encoding="utf-8").splitlines()[0].split()[0]
assert before_line == "...F"
owned = {
    "src/checkwash/sweep.py": digest(REPO / "src/checkwash/sweep.py"),
    "tests/test_sweep_input_parity.py": digest(REPO / "tests/test_sweep_input_parity.py"),
}
assert owned["src/checkwash/sweep.py"] == "444ba8bb0714a030a68c857d887583e5678739e1500a477f2685fad9f1c43a48"
assert owned["tests/test_sweep_input_parity.py"] == "cfc1a4406289484f99df5634a36c3dcf72376847dfc3733eab5de84fd4ff8ae2"
meta = {
    "marker": "HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL",
    "hostname": socket.gethostname(), "platform": platform.platform(),
    "python": sys.version, "python_executable": sys.executable,
    "observed_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "basis": "Targeted working-tree validation, not formal release or full-suite qualification",
    "baseline_sha": "1ffe283d7d947fecc426dea99323b0a2620a9482",
    "owned_file_sha256": owned,
    "before": {
        "engine_source": str(HERE.parent / "rename/source-v091/src"),
        "command": [sys.executable, "-B", "-m", "pytest", "-q", str(REPO / "tests/test_sweep_input_parity.py"),
                    "-o", "cache_dir=" + str(HERE / "pytest-cache-before"), "--basetemp=" + str(HERE / "pytest-before")],
        "cwd": str(HERE), "exit": 1, "passed": 3, "failed": 1,
        "failure": "test_single_commit_sweep_keeps_range_pytest_config_evidence[deselect-git-symlink]",
    },
    "after": {
        "engine_source": str(REPO / "src"),
        "command": [sys.executable, "-B", "-m", "pytest", "-q", "tests/test_sweep_input_parity.py",
                    "tests/test_issue346_config_reads.py", "tests/test_config_dirs.py", "tests/test_git_input_failures.py",
                    "-k", "sweep or config or nested", "-o", "cache_dir=" + str(HERE / "pytest-cache-after"),
                    "--basetemp=" + str(HERE / "pytest-after")],
        "cwd": str(REPO), "exit": 0, "selected": 27, "passed": 26, "skipped": 1,
        "count_basis": "Native pytest progress characters; -qq suppresses its textual count summary",
        "new_parity_tests": "all four passed (Git-tree symlink fixtures require no host symlink privileges)",
        "skip_limit": "The native -qq output preserves one skip but not its reason; do not claim that skipped path was executed",
    },
    "receipts_sha256": {name: digest(HERE / name) for name in (
        "test-before.stdout", "test-before.stderr", "test-after.stdout", "test-after.stderr", "test-after.exit")},
    "not_changed": ["sweep JSON schema", "sweep CLI exit semantics", "config/allow parse diagnostics disposition",
                    "exception counting", "protected gating", "existing fixture expectations"],
}
(HERE / "validation.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
with (HERE / "report.md").open("a", encoding="utf-8") as handle:
    handle.write("\n## 窄修驗證終態\n\n"
                 "新增四格 parity regression 在固定改前 archive 上為3通過/1失敗，唯一失敗是 alias target 的 deselect 漏抓。"
                 "補齊輸入後，四格全部通過；連同相關既有 config/nested/sweep-error 回歸，原始退出碼0，27個選中案例為26通過/1跳過。"
                 "原始 -qq 未列出跳過原因，因此此收據不宣稱該跳過路徑已執行。\n\n"
                 "產品變更只在 src/checkwash/sweep.py：import PairedPytestConfigs，建立paired base/head context，"
                 "傳給analyze，並把head_reader對齊既有head snapshot。測試檔為新增 tests/test_sweep_input_parity.py。"
                 "兩檔已交root固定，不再由本agent更動。完整命令、runtime、native exit與SHA-256在 validation.json；"
                 "此為有明確檔案hash的working-tree targeted驗證，最終commit的full suite仍由root另行執行。\n")
print(json.dumps({"after": meta["after"], "owned_file_sha256": owned}, indent=2))
