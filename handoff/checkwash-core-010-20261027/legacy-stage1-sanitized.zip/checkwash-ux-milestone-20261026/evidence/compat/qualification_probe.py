"""Four existing CLI-contract cases to estimate the bounded source-only run."""
import importlib.util
import json
import os
from pathlib import Path
import sys
import time

out = Path(__file__).resolve().parent
source = out / "source"
temporary = out / "qualification-temp"
temporary.mkdir(exist_ok=True)
os.environ["TEMP"] = os.environ["TMP"] = str(temporary)
sys.path.insert(0, str(source / "tools"))
from assertion_contract import mutation_cases, foundation_mutation_cases
spec = importlib.util.spec_from_file_location("qualification", source / "tools/qualify_assertions.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
cases = [*mutation_cases(), *foundation_mutation_cases()]
start = time.monotonic()
receipt = module.qualify(source=source, distribution="source", command=[sys.executable], cases=cases[:4])
elapsed = time.monotonic() - start
receipt["probe_elapsed_seconds"] = elapsed
receipt["all_case_count"] = len(cases)
receipt["linear_estimate_seconds"] = elapsed * len(cases) / 4
(out / "qualification-probe.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
print(json.dumps({key: receipt[key] for key in ("status", "summary", "errors", "probe_elapsed_seconds",
                                              "all_case_count", "linear_estimate_seconds")}))
raise SystemExit(0 if receipt["status"] == "passed" else 1)
