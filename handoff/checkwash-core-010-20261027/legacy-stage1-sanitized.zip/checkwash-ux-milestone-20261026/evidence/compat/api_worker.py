"""Analyze the same saved demo inputs with one isolated source package."""
import dataclasses
import datetime
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(sys.argv[1]) / "src"))
import checkwash
from checkwash.cases import case_snapshot, case_to_changes, parse_case
from checkwash.config import Config
from checkwash.contract import Contract, parse_contract
from checkwash.engine import analyze
from checkwash.gitio.snapshot import search_source_mapping

cases = json.loads(Path(sys.argv[2]).read_text(encoding="utf-8"))
rows = []
for saved in cases:
    case = parse_case(saved["text"])
    contract = parse_contract(case.task) if case.task else Contract()
    head = {path: data.encode("utf-8") for path, data in case.head.items()}
    snapshot = case_snapshot(case)
    ir, findings, verdict = analyze(
        case_to_changes(case), Config(), contract, [], datetime.date(2026, 1, 1),
        head_reader=head.get, root_reader=snapshot.get,
        root_searcher=lambda needles: search_source_mapping(snapshot, needles),
        root_path_lister=lambda: sorted(snapshot),
        root_batch_reader=lambda paths: {path: snapshot.get(path) for path in paths})
    rows.append({"id": saved["id"], "verdict": verdict,
                 "existing_expected": case.expect,
                 "findings": sorted([{key: getattr(finding, key) for key in (
                     "rule", "severity", "path", "unit", "fingerprint")} for finding in findings],
                     key=lambda row: json.dumps(row, sort_keys=True))})
print(json.dumps({"loaded_package": checkwash.__file__, "version": checkwash.__version__,
                  "findings_schema": checkwash.FINDINGS_VERSION, "ir_schema": checkwash.IR_VERSION,
                  "cases": rows}, indent=2, sort_keys=True))
