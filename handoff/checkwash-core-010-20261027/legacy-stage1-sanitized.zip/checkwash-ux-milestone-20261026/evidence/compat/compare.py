"""Bounded three-source API/CLI comparison; no analyzed fixture code runs."""
import hashlib
import io
import json
import os
from pathlib import Path
import platform
import socket
import subprocess
import sys
import time
import zipfile

HERE = Path(__file__).resolve().parent
SESSION = HERE.parents[1]
GIT_REPO = SESSION / "work/checkwash-ux"
SOURCES = {
    "v090": ("d6eda4f695fabb8e7d138f7a87b099d2028f0294", SESSION / "work/rename/source-v090"),
    "v091": ("1ffe283d7d947fecc426dea99323b0a2620a9482", SESSION / "work/rename/source-v091"),
    "candidate": ("08a96b1542f1ff14c1876f0714e961860ee8c398", HERE / "source"),
}
ENV = {key: value for key, value in os.environ.items()
       if not key.startswith(("PYTHON", "GIT_", "CHECKWASH_", "GREENWASH_"))}
ENV.update({"GIT_CONFIG_GLOBAL": os.devnull, "GIT_CONFIG_NOSYSTEM": "1", "GIT_TERMINAL_PROMPT": "0",
            "GIT_AUTHOR_NAME": "compatibility fixture", "GIT_AUTHOR_EMAIL": "fixture@example.invalid",
            "GIT_COMMITTER_NAME": "compatibility fixture", "GIT_COMMITTER_EMAIL": "fixture@example.invalid",
            "GIT_AUTHOR_DATE": "2026-01-01T00:00:00Z", "GIT_COMMITTER_DATE": "2026-01-01T00:00:00Z",
            "GREENWASH_TODAY": "2026-01-01", "NO_COLOR": "1"})
records = []


def digest(data):
    return hashlib.sha256(data).hexdigest()


def run(command, cwd, stem, *, check=False):
    before = time.monotonic()
    result = subprocess.run(command, cwd=cwd, env=ENV, capture_output=True, timeout=90)
    raw = HERE / "raw" / stem
    raw.parent.mkdir(parents=True, exist_ok=True)
    raw.with_suffix(".stdout").write_bytes(result.stdout)
    raw.with_suffix(".stderr").write_bytes(result.stderr)
    meta = {"command": command, "cwd": str(cwd), "exit": result.returncode,
            "elapsed_seconds": time.monotonic() - before,
            "stdout_sha256": digest(result.stdout), "stderr_sha256": digest(result.stderr),
            "stdout": str(raw.with_suffix(".stdout").relative_to(HERE)),
            "stderr": str(raw.with_suffix(".stderr").relative_to(HERE))}
    raw.with_suffix(".meta.json").write_text(json.dumps(meta, indent=2) + "\n", encoding="utf-8")
    records.append(meta)
    if check and result.returncode:
        raise RuntimeError(f"{stem}: {result.stderr.decode('utf-8', 'replace')}")
    return result


def git(repo, *args):
    result = subprocess.run(["git", "-c", "core.autocrlf=false", "-c", "commit.gpgsign=false", *args],
                            cwd=repo, env=ENV, capture_output=True, timeout=30, check=True)
    return result.stdout.decode("ascii").strip()


def package_files(source):
    return {path.relative_to(source).as_posix(): digest(path.read_bytes())
            for path in sorted((source / "src/checkwash").rglob("*"))
            if path.is_file() and "__pycache__" not in path.parts and path.suffix != ".pyc"}


def native_json(source, repo, arguments, stem):
    bootstrap = f"import sys;sys.path.insert(0,{str(source / 'src')!r});from checkwash.cli import main;raise SystemExit(main())"
    result = run([sys.executable, "-I", "-B", "-X", "utf8", "-c", bootstrap, *arguments], repo, stem)
    payload = json.loads(result.stdout) if result.stdout else None
    return {"exit": result.returncode, "schema": payload.get("checkwash_findings_version") if payload else None,
            "verdict": payload.get("verdict") if payload else None,
            "config_errors": payload.get("config_errors") if payload else None,
            "skipped_files": payload.get("skipped_files") if payload else None,
            "findings": [{key: row.get(key) for key in ("rule", "severity", "path", "unit", "fingerprint")}
                         for row in payload.get("findings", [])] if payload else None,
            "raw_stdout_sha256": digest(result.stdout), "raw_stderr_sha256": digest(result.stderr)}


def fixture(repo):
    repo.mkdir(parents=True)
    git(repo, "init", "-b", "main")
    (repo / "tests").mkdir()
    (repo / "calc.py").write_bytes(b"def calc(x):\n    return 2 * x\n")
    (repo / "tests/test_calc.py").write_bytes(b"from calc import calc\n\ndef test_calc():\n    assert calc(10) == 20\n")
    git(repo, "add", ".")
    git(repo, "commit", "-m", "base")
    return git(repo, "rev-parse", "HEAD")


started = time.monotonic()
sources = {}
for label, (sha, source) in SOURCES.items():
    archive = run(["git", "archive", "--format=zip", sha, "src/checkwash"], GIT_REPO,
                  f"{label}-git-archive", check=True).stdout
    (HERE / f"{label}-package.zip").write_bytes(archive)
    with zipfile.ZipFile(io.BytesIO(archive)) as saved:
        expected = {name: digest(saved.read(name)) for name in sorted(saved.namelist()) if not name.endswith("/")}
    actual = package_files(source)
    if actual != expected:
        raise RuntimeError(f"{label} source snapshot differs from commit archive")
    sources[label] = {"commit": sha, "path": str(source), "package_files": actual,
                      "archive_sha256": digest(archive),
                      "package_manifest_sha256": digest(json.dumps(actual, sort_keys=True).encode())}

saved_cases = [{"id": path.name, "text": path.read_text(encoding="utf-8")}
               for path in sorted((SOURCES["v091"][1] / "src/checkwash/demo_cases").glob("*.gwcase"))]
(HERE / "demo-inputs.json").write_text(json.dumps(saved_cases, indent=2) + "\n", encoding="utf-8")
api = {}
cli = {}
range_repo, worktree_repo = HERE / "repos/range", HERE / "repos/worktree"
range_base = fixture(range_repo)
(range_repo / "tests/test_calc.py").write_bytes(b"from calc import calc\n\ndef test_calc():\n    assert calc(10) > 0\n")
git(range_repo, "add", ".")
git(range_repo, "commit", "-m", "weakened oracle")
range_head = git(range_repo, "rev-parse", "HEAD")
worktree_base = fixture(worktree_repo)
(worktree_repo / "tests/test_calc.py").write_bytes(b"from calc import calc\n\ndef test_calc():\n    assert calc(10) > 0\n")
dirty_repo = SESSION / "work/gitlink/native-case/parent"
dirty_state = {"head": git(dirty_repo, "rev-parse", "HEAD"),
               "test_sha256": digest((dirty_repo / "tests/test_total.py").read_bytes()),
               "submodule_file_sha256": digest((dirty_repo / "vendor/lib/context.py").read_bytes())}
for label, (_sha, source) in SOURCES.items():
    result = run([sys.executable, "-I", "-B", "-X", "utf8", str(HERE / "api_worker.py"), str(source),
                  str(HERE / "demo-inputs.json")], HERE, f"{label}-demo-api", check=True)
    api[label] = json.loads(result.stdout)
    bootstrap = f"import sys;sys.path.insert(0,{str(source / 'src')!r});from checkwash.cli import main;raise SystemExit(main())"
    demo = run([sys.executable, "-I", "-B", "-X", "utf8", "-c", bootstrap, "demo"], HERE,
               f"{label}-demo-cli")
    cli[label] = {"demo": {"exit": demo.returncode, "stdout_sha256": digest(demo.stdout),
                           "stderr_sha256": digest(demo.stderr)},
                  "clean_range": native_json(source, range_repo, ["check", "HEAD..HEAD", "--format", "json"],
                                              f"{label}-clean-range"),
                  "weak_range": native_json(source, range_repo, ["check", f"{range_base}..{range_head}", "--format", "json"],
                                             f"{label}-weak-range"),
                  "weak_worktree": native_json(source, worktree_repo, ["check", "--format", "json"],
                                                f"{label}-weak-worktree"),
                  "dirty_gitlink_neighbor": native_json(source, dirty_repo, ["check", "--format", "json"],
                                                         f"{label}-dirty-gitlink-neighbor")}
for label, (_sha, source) in SOURCES.items():
    if package_files(source) != sources[label]["package_files"]:
        raise RuntimeError(f"{label} package bytes changed during regression")
if dirty_state != {"head": git(dirty_repo, "rev-parse", "HEAD"),
                   "test_sha256": digest((dirty_repo / "tests/test_total.py").read_bytes()),
                   "submodule_file_sha256": digest((dirty_repo / "vendor/lib/context.py").read_bytes())}:
    raise RuntimeError("shared gitlink fixture changed during comparison")
comparison = {}
for label in ("v090", "candidate"):
    comparison[label] = {"demo_api_observations_equal_v091": api[label]["cases"] == api["v091"]["cases"],
                         "schemas_equal_v091": (api[label]["findings_schema"], api[label]["ir_schema"]) == (
                             api["v091"]["findings_schema"], api["v091"]["ir_schema"]),
                         "cli": {}}
    for case in ("clean_range", "weak_range", "weak_worktree"):
        keys = ("exit", "schema", "verdict", "config_errors", "skipped_files", "findings")
        comparison[label]["cli"][case] = all(cli[label][case][key] == cli["v091"][case][key] for key in keys)
receipt = {"provenance": "HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL", "hostname": socket.gethostname(),
           "runtime": sys.version, "executable": sys.executable, "platform": platform.platform(),
           "git_version": git(GIT_REPO, "--version"), "elapsed_seconds": time.monotonic() - started,
           "sources": sources, "api": api, "cli": cli, "comparison": comparison,
           "dirty_gitlink_input": dirty_state, "commands": records,
           "fixture_execution": "Only checkwash, Git and trusted drivers execute; all analyzed fixture Python is static input",
           "full_source_assertion_qualification": "NOT_RUN: root instruction; separate four-case official harness probe only"}
(HERE / "results.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"demo_api_cases_per_source": len(saved_cases), "comparison": comparison,
                  "dirty_gitlink_neighbor": {label: {key: row["dirty_gitlink_neighbor"][key] for key in (
                      "exit", "schema", "verdict", "findings")} for label, row in cli.items()},
                  "elapsed_seconds": receipt["elapsed_seconds"]}, indent=2))
