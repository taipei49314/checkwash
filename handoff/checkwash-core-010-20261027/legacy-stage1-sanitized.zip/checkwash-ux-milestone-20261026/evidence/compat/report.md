# Bounded three-source compatibility check

Host `LAPTOP-01AGNPJU`, Python 3.11.9, Git 2.55.0.windows.3, Windows; `HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`.
The comparison completed in 56.313 seconds. Every checkwash invocation uses an explicit source path with `-I -B -X utf8`.

## Fixed sources and byte identity

| Source | Exact commit | Package file count | Package manifest SHA-256 |
|---|---|---:|---|
| Public v0.9.0 | `d6eda4f695fabb8e7d138f7a87b099d2028f0294` | 210 | `81e44240d13af9f6a31b4a13f49ff237d0af932d23e09eb20a6738a012a5c3f0` |
| Unpublished v0.9.1 | `1ffe283d7d947fecc426dea99323b0a2620a9482` | 210 | `c8c1a17dcc7e8b32198c559df31ced01da652f8217b2c18cf60a345ca147c99c` |
| Narrow-fix candidate | `08a96b1542f1ff14c1876f0714e961860ee8c398` | 210 | `94577aad8772885f9a615c6ce7ab986636958bbb99ce3b74b1df16a6c61e590b` |

For each source, the complete `src/checkwash` file map was compared byte-for-byte with a fresh `git archive` of the named commit. All maps matched; all package bytes were unchanged at completion. The v0.9.0/v0.9.1 source snapshots remained read-only. The candidate is a separate detached worktree. Archive bytes, individual file hashes and archive hashes are retained in `results.json` and `*-package.zip`.

## Observed compatibility

The same nine existing demo inputs from v0.9.1 were supplied to all three isolated package APIs. Each source reports eight BLOCK cases and one preserving PASS, with eight findings total. The complete observed `(rule, severity, path, unit, fingerprint)` records and verdicts are identical across all three sources. Findings and IR schemas remain version 2. Native `checkwash demo` exits 0 on all three; UTF-8 output bytes are identical, with empty stderr.

Three native CLI controls were also identical across all sources, comparing exit, findings schema, verdict, config/skipped-file diagnostics and every finding's identity:

| Same static input | v0.9.0 | v0.9.1 | Candidate |
|---|---|---|---|
| Clean committed range | exit 0 / PASS / no findings | same | same |
| Equality weakened to a positive bound, range | exit 1 / BLOCK / `ASSERT_WEAKENED/high` | same | same |
| Same weakening, worktree | exit 1 / BLOCK / `ASSERT_WEAKENED/high` | same | same |

The weakening fingerprint is unchanged: `ASSERT_WEAKENED/tests/test_calc.py/test_calc/v2:292a31edb600f535ae85519d11facd23148cca4c5fe3e391d6e5a43208c67a18`.

The dirty registered-gitlink case deliberately differs. On the exact same retained fixture, both old sources exit 2 with the directory-reader error and no ordinary findings report. The candidate exits 1/BLOCK with schema 2 and the neighboring `EXPECTED_VALUE_CHANGED/high`. This is recovery from NOT_ANALYSED, not movement of an existing old finding. Its identity equals the earlier clean-submodule candidate control (`work/gitlink/native-clean-control.*`). Fixture HEAD and the test/submodule input bytes were rechecked unchanged across the three calls.

## Bounded qualification probe and limits

The unchanged official `tools/qualify_assertions.py` API exercised only the first four existing assertion-contract cases at fixed candidate `08a96b15`: **4 executed / 4 passed / 0 failed**, with no harness errors and a clean source package. The saved official receipt is `qualification-probe.json`; its `summary.total` is **4**, not 283. The probe took 25.297 seconds. A simple linear extrapolation is approximately 1,790 seconds; that is an estimate, not a measured complete-run duration.

The complete 283-case source run was **NOT_RUN** under root's instruction to keep this milestone bounded and avoid contention with the final full suite. Wheel/pyz qualifications and the formal release collector were also **NOT_RUN** and remain separate future work. There was no historical sweep, model batch, fixture expectation edit, protected-policy change, merge, tag or publication. No analyzed fixture Python was executed.

These observations support compatibility for this small group. They do not establish every existing exemption, all source cases, other runtimes/platforms, or release acceptance. Any later source commit must retain its own validation binding; this report is bound to `08a96b15`.

## Evidence

- `results.json`: source maps, environment, all case observations, native commands, exits, stdout/stderr hashes and source-after checks.
- `raw/*`: original stdout/stderr and command metadata for each archive, isolated demo API and native CLI invocation.
- `demo-inputs.json`: exact common existing demo inputs.
- `qualification-probe.json`: official four-case source-only receipt.
- `compare.py`, `api_worker.py`, `qualification_probe.py`: reproducible trusted drivers; analyzed fixture sources are only static input.
