# #8 CRLF-only 搬移：配對差異重現，誤擋未重現

2026-10-26（Asia/Taipei）；`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`。

使用固定 `1ffe283d7d947fecc426dea99323b0a2620a9482` 的獨立 `source-v091` archive；主機 LAPTOP-01AGNPJU、Python 3.11.9。四個 synthetic Git 倉，每倉兩個 CLI（worktree/range），共八個 CLI，單次 timeout=60s；driver exit0。未修改產品工作樹或全域 Git 設定，未執行 fixture 的 Python/pytest 程式。

每個 base 的 Git blob 都以實際 `git show` 驗明為 LF。唯一 diff 是把 `tests/test_before.py` 純搬到 `tests/test_after.py`，新檔 disk bytes 刻意控制為 LF 或 CRLF。`core.autocrlf` 僅在該 fixture repo 的 `.git/config` 設為 false/true，`git check-attr -a` 沒有有效 attributes。LF-disk/true 是刻意保留 LF bytes 的控制，不宣稱它代表 Git checkout 的慣常行為。

| repo-local autocrlf | 新檔 disk | worktree reader 的實際 changes | worktree CLI | Git range 實際 rename entry | range CLI |
|---|---|---|---|---|---|
| false | LF | 單筆 modified，old_path=test_before.py | exit0/PASS；零 findings | R100 | exit0/PASS；零 findings |
| false | CRLF | old deleted + new added，均無 old_path | exit0/PASS；TEST_DISABLED info / ASSERTION_MOVED | R094 | exit0/PASS；零 findings |
| true | LF | 單筆 modified，old_path=test_before.py | exit0/PASS；零 findings | R100 | exit0/PASS；零 findings |
| true | CRLF | old deleted + new added，均無 old_path | exit0/PASS；TEST_DISABLED info / ASSERTION_MOVED | R100 | exit0/PASS；零 findings |

Git 的 worktree porcelain 都確實列出 old path 的 deletion 和 new path 的 untracked entry。工具在 LF 情境自行把 raw-byte 相等的兩半配成 rename；CRLF 情境沒有配對。range 使用 Git similarity rename，四格都配成一筆。autocrlf=false/CRLF 的新 blob 保持 CRLF；autocrlf=true/CRLF 的新 blob 正規化回 LF，以上都讀回原始 bytes 確認。

兩格 CRLF worktree 的唯一 finding fingerprint 相同：

`TEST_DISABLED/tests/test_before.py/test_calc/v2:c2032e9e82999ce2b40b409290079f74016187979849085e76065af51b7839e1`

這是相對 LF 控制新增的 info finding，不是既有 finding key 已被移動的證據。八個 CLI 都 PASS，config_errors/skipped_files 皆空，stderr 皆空。**因此 raw-byte 配對不一致已重現；此最小純搬移案例沒有重現使用者所述誤擋。** 也不能把它推廣為任意搬移／重寫都安全；另存的跨檔 decorator 改動案例確實有 worktree/range verdict 差異，但不是本輪 CRLF-only 控制的結果。

`results.json` 保存 source/runtime、每格 base/head、原始 base/disk/head bytes 的 SHA-256 與 LF/CRLF 計數、直接 reader 的 changes、Git status/rename/config/attributes、完整 findings/fingerprint 及 CLI command/exit。`raw/**` 保存 Git 和 CLI 的 stdout/stderr bytes 與每格 metadata；`reproduce.py` 可重建形狀。

未執行其他 OS/Python、hook protocol、正式 release qualification 或歷史語料。此次只補重現台帳，不實作 CRLF reader 修復、不修改 protected 政策或現有指紋契約。
