"""Eight fixed-source CLI controls for raw newline rename pairing."""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import platform
import socket
import subprocess
import sys

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent / "rename/source-v091/src"
SOURCE_SHA = "1ffe283d7d947fecc426dea99323b0a2620a9482"
sys.path.insert(0, str(SOURCE))
from checkwash.gitio import list_range_changes, list_worktree_changes

ENV = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", PYTHONUTF8="1", PYTHONPATH=str(SOURCE))
TEXT = b"from calc import calc\n\ndef test_calc():\n    assert calc(10) == 20\n"

def git(repo, *args, required=True):
    p = subprocess.run(["git", "-C", str(repo), *args], env=ENV, capture_output=True, timeout=60)
    if required and p.returncode:
        raise RuntimeError(p.stderr.decode("utf-8", "replace"))
    return p

def digest(data):
    return hashlib.sha256(data).hexdigest()

def bytes_meta(data):
    if data is None:
        return None
    return {"size": len(data), "sha256": digest(data), "crlf_count": data.count(b"\r\n"),
            "lf_count": data.count(b"\n"), "text": data.decode("utf-8")}

def changes_meta(changes):
    return [{"path": change.path, "old_path": change.old_path, "status": change.status,
             "before": bytes_meta(change.before), "after": bytes_meta(change.after)} for change in changes]

def raw_git(repo, raw, label, *args):
    p = git(repo, *args)
    (raw / (label + ".stdout")).write_bytes(p.stdout)
    (raw / (label + ".stderr")).write_bytes(p.stderr)
    return {"command": ["git", "-C", str(repo), *args], "exit": p.returncode,
            "stdout_sha256": digest(p.stdout), "stderr_sha256": digest(p.stderr),
            "decoded_stdout": p.stdout.decode("utf-8", "replace")}

def cli(repo, raw, entry, base, head):
    command = [sys.executable, "-B", "-m", "checkwash", "check"]
    if entry == "range":
        command.append(base + ".." + head)
    command += ["--repo", str(repo), "--format", "json"]
    p = subprocess.run(command, cwd=repo, env=ENV, capture_output=True, timeout=60)
    (raw / (entry + ".stdout")).write_bytes(p.stdout)
    (raw / (entry + ".stderr")).write_bytes(p.stderr)
    payload = json.loads(p.stdout)
    receipt = {"command": command, "cwd": str(repo), "timeout_seconds": 60, "exit": p.returncode,
               "stdout_sha256": digest(p.stdout), "stderr_sha256": digest(p.stderr), "payload": payload}
    (raw / (entry + ".meta.json")).write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding="utf-8")
    return receipt

def main():
    rows = []
    for autocrlf in (False, True):
        for newline in ("LF", "CRLF"):
            label = f"autocrlf-{str(autocrlf).lower()}-disk-{newline}"
            repo = HERE / "repos" / label
            raw = HERE / "raw" / label
            repo.mkdir(parents=True, exist_ok=False)
            raw.mkdir(parents=True)
            git(repo, "init", "-q", "-b", "main")
            git(repo, "config", "user.name", "newline rename control")
            git(repo, "config", "user.email", "newline-control@example.invalid")
            git(repo, "config", "commit.gpgsign", "false")
            git(repo, "config", "core.autocrlf", str(autocrlf).lower())
            (repo / "tests").mkdir()
            (repo / "tests/test_before.py").write_bytes(TEXT)
            (repo / "calc.py").write_bytes(b"def calc(x):\n    return x * 2\n")
            git(repo, "add", ".")
            git(repo, "-c", "core.hooksPath=NUL", "commit", "-qm", "base LF blob")
            base = git(repo, "rev-parse", "HEAD").stdout.decode().strip()
            blob = git(repo, "show", base + ":tests/test_before.py").stdout
            assert blob == TEXT
            (repo / "tests/test_before.py").unlink()
            disk = TEXT if newline == "LF" else TEXT.replace(b"\n", b"\r\n")
            (repo / "tests/test_after.py").write_bytes(disk)
            before_commit_entries = raw_git(repo, raw, "status-worktree", "status", "--porcelain=v1", "-z", "--untracked-files=all")
            local_config = raw_git(repo, raw, "config-autocrlf", "config", "--show-origin", "--get", "core.autocrlf")
            attrs = raw_git(repo, raw, "attributes", "check-attr", "-a", "--", "tests/test_after.py")
            raw_diff = raw_git(repo, raw, "diff-no-renames", "diff", "--raw", "--no-renames", "HEAD")
            worktree_changes = changes_meta(list_worktree_changes(str(repo)))
            worktree = cli(repo, raw, "worktree", base, None)
            git(repo, "add", "-A")
            git(repo, "-c", "core.hooksPath=NUL", "commit", "-qm", "move with disk newline control")
            head = git(repo, "rev-parse", "HEAD").stdout.decode().strip()
            committed_blob = git(repo, "show", head + ":tests/test_after.py").stdout
            range_entries = raw_git(repo, raw, "diff-range-renames", "diff", "--name-status", "--find-renames=50%", base, head)
            range_changes = changes_meta(list_range_changes(str(repo), base, head))
            ranged = cli(repo, raw, "range", base, head)
            row = {"label": label, "source_sha": SOURCE_SHA, "autocrlf": autocrlf, "disk_newline": newline,
                   "base": base, "head": head, "base_blob": bytes_meta(blob), "disk_new_file": bytes_meta(disk),
                   "head_blob": bytes_meta(committed_blob), "git_status": before_commit_entries, "git_diff_no_renames": raw_diff,
                   "git_config": local_config, "attributes": attrs, "git_range_entries": range_entries,
                   "worktree_changes": worktree_changes, "range_changes": range_changes,
                   "worktree_cli": worktree, "range_cli": ranged}
            rows.append(row)
            (raw / "case.json").write_text(json.dumps(row, ensure_ascii=False, indent=2), encoding="utf-8")
            print(label, "worktree", worktree["exit"], [(c["path"], c["old_path"]) for c in worktree_changes],
                  "range", ranged["exit"], [(c["path"], c["old_path"]) for c in range_changes], flush=True)
    manifest = {"marker": "HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL", "hostname": socket.gethostname(),
                "platform": platform.platform(), "python": sys.version, "source_sha": SOURCE_SHA,
                "source_path": str(SOURCE), "fixture_execution": "NOT_RUN; static analysis only", "cli_calls": 8,
                "source_git_py_sha256": digest((SOURCE / "checkwash/gitio/git.py").read_bytes()), "rows": rows}
    (HERE / "results.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")

if __name__ == "__main__":
    main()
