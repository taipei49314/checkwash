from __future__ import annotations
from collections import defaultdict
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
main = json.loads((HERE / "results.json").read_text(encoding="utf-8"))
extra = json.loads((HERE / "supplement" / "results.json").read_text(encoding="utf-8"))
assert len(main["results"]) == 64
assert len(extra["results"]) == 8
rows = main["results"] + extra["results"]
groups = defaultdict(dict)
for row in rows:
    groups[row["case"], row["oracle_freeze"], row["entry"]][row["source_label"]] = row
observed = ("exit", "verdict", "findings", "config_errors", "skipped_files")
differences = []
for key, pair in groups.items():
    if any(pair["v090"][field] != pair["v091"][field] for field in observed):
        differences.append(key)

def brief(row):
    fs = "; ".join(f'{f["rule"]} {f["severity"]} / {",".join(f["deescalators"]) or ",".join(f["escalators"])}' for f in row["findings"])
    return f'{row["verdict"].upper()} ({row["exit"]})' + ("; " + fs if fs else "; no findings")

table = ["| Minimal case | default worktree | default range | freeze worktree | freeze range |",
         "|---|---|---|---|---|"]
names = list(dict.fromkeys(row["case"] for row in rows))
for name in names:
    entries = [brief(groups[name, freeze, entry]["v091"]) for freeze, entry in ((False, "worktree"), (False, "range"), (True, "worktree"), (True, "range"))]
    table.append("| " + " | ".join([name, *entries]) + " |")

report = f'''# Rename / oracle：固定來源重現與待裁決項目

採證日期：2026-10-26（Asia/Taipei）。標記：`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`。

## 已完成的事實

- 主機 `{main['hostname']}`；`{main['platform']}`；Python `{main['python'].splitlines()[0]}`；`{main['git']}`。
- 未公開 v0.9.1 來源 `1ffe283d7d947fecc426dea99323b0a2620a9482`，公開 v0.9.0 來源 `d6eda4f695fabb8e7d138f7a87b099d2028f0294`。從 exact Git commit 的 `src/` archive 解出獨立來源，不匯入共享工作樹。
- 8 個主要差異形狀 × 2 來源 × 有無 oracle_freeze × range/worktree = 64 次 CLI；另有 1 個跨檔 param-only 差異形狀的同規格 8 次 CLI。共 72 次靜態分析，36 個來源版本配對觀察；版本間 exit/verdict/findings（含 fingerprint）/config_errors/skipped_files 差異 **{len(differences)}**。
- 被分析 fixture 的 Python／pytest 程式 **沒有執行**，因此不聲稱其 runtime 測試會通過。Git 設定 `core.autocrlf=false`，本矩陣刻意隔離 CRLF 因素。
- 沒有修改產品、protected policy、既有 expected fixture、tag、發版或下游 pin。

這些是依交接主張建立的最小重建；完整原始使用者 fixture 不在交接包，不能宣稱 byte-identical 重播其原始終端環境。

## 觀察表

兩個版本的觀察一致；表列 v0.9.1。每格括號為原始 exit。

{chr(10).join(table)}

## 原始主張對照

- `D-rename-evasion/#7-A`、`#7-2d`：**重現**。`test_calc` 的三列 parametrize 改成 `test_checkout`、locals x=10/expected=999999，保留 `assert calc(x) == expected`。兩入口都是 info/ASSERTION_MOVED/PASS，包含 base-side TASK.md 正確設 `oracle_freeze: true`。
- `D-rename-evasion/#7-B`、`#7-3c`、`#7-3d`：**重現**。三個 duplicate `(0,0)` rows 加 `res=calc(x); assert res==0`，default warn/RESTRUCTURED/PASS；freeze high/ORACLE_FREEZE/BLOCK。B 分別從原始 base 和 A 的 head 形狀重建，default 結果一致。RESTRUCTURED-held default finding 沒有 `NO_PROD_CHANGE_IN_DIFF`，符合 critic 的更正。
- `D-rename-evasion/#7-N`：**未重現其預測逃逸**。直接 literal unroll 成 `calc(10)==25`／`calc(20)==45`／`calc(30)==65`，兩入口、兩版本都產生三個 high `EXPECTED_VALUE_CHANGED` 並 BLOCK。既有 concrete-table projection 生成 `test_concrete_*` units；不能把原分析的 UNCLEAR 升格為已證實 PASS。
- `D-rename-evasion/#7-1b` 的限定：純跨檔搬移控制兩入口都 PASS；但在跨檔搬移時只改 decorator 的 expectation，range 以 similarity rename 保持配對，給 `EXPECTATION_DEFINITION_CHANGED` high/BLOCK；worktree 變成分離的刪增，再由 D2 body/assertion move credit 給 info/PASS，freeze 也不補上 E2。這證實 critic 所指出的入口差異，不能說所有整檔 rename 都配對。
- 合法單純改名、保持期望的 literal unroll、純跨檔搬移都 PASS。保留名稱而改成 A 的弱化形狀會 BLOCK，因而把 detector 正常能力和 identity 逃逸隔離開。

## 政策提案（未實作、未授權）

1. **先決定 E2 的語意**：是否讓 D2 的 assertion-text 路徑在 `oracle_freeze=true` 時也套用 E2，而不立即 `continue`？這是小型、可審查的 ordering 修正；A 將由 info/PASS 轉 high/BLOCK。它不處理 default A/B，亦不自動關閉跨檔 decorator 變更的 body-hash route。若採用，SPEC §5、gating policy、DECISIONS 及專門正反例要一起審查，版本走 minor。
2. **D2 的「同一 oracle」不能只用 body/text**：目前 Python `body_hash` 是 `text.seg(func)` 的 normalized digest，並未綁住 decorator；`moved_assertion_texts` 亦不綁 reaching definitions／param rows／import subject。具體選項是讓 arriving credit 綁住可比較的輸入期望表與 reaching definitions，或對明知相關但 context 不同的單位保留可見診斷再交 E1/E2。需要明訂未知 context 的處置；不能把所有未知都當等價。
3. **不建議全面取消 D5 的 test-only compensation**：這會傷到合法拆分／整併，且目前合法 concrete unroll 能被正確辨識。duplicate-row 去重可擋 B 的一種 padding，但不是完整等價證明。交接 F4 所稱跨單位 expectation 比較也不是全新空白：本輪 literal N 已由既有 projection 攔住；後續提案應只延伸已證實缺的形狀。
4. **#419 repair credit 是獨立邊界**：本矩陣沒有加入 production edit，也沒有重跑其已記錄 Route A。不能據此聲稱任何 D2/D5 修正能阻止一併修改 called symbol 的案例。這部分維持原已記 residual，實作前另做其 exact controls。

建議人類第一個精確決定為：「是否核可針對 D2 assertion-text credit 的 oracle_freeze ordering 修改，並以 minor contract change 交付？」更廣泛 D2 identity／D5 等價性方案分開審查；目前僅已授權體驗窄修不涵蓋這些政策改動。

## 證據與限制

- `reproduce.py` / `supplement.py`：完整 fixture 字串、命令與固定來源。
- `results.json` / `supplement/results.json`：hostname/runtime、source archive SHA-256、所有 source SHA、fixture base/head、原始 exit、finding/fingerprint 與 receipt 路徑。
- `raw/**` / `supplement/raw/**`：每次 CLI 的原始 stdout/stderr bytes、SHA-256 與 command/cwd；run.stdout 只是進度摘要。
- 未執行：其他 OS／Python、正式 release qualification、歷史 cohort／sweep、模型／標註批次、重構成本估計。這些72次靜態控制不構成外部有效性或使用成本數據。
'''
(HERE / "report.md").write_text(report, encoding="utf-8")
summary = {"cli_calls": len(rows), "paired_observations": len(groups), "baseline_differences": differences,
           "all_stderr_empty": all((HERE / ("supplement" if row in extra["results"] else "") / row["receipt"]["stderr"]).stat().st_size == 0 for row in rows),
           "all_config_errors_empty": all(not row["config_errors"] for row in rows),
           "all_skipped_files_empty": all(not row["skipped_files"] for row in rows),
           "driver_sha256": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (HERE / "reproduce.py", HERE / "supplement.py")}}
(HERE / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps(summary, ensure_ascii=False, indent=2))
