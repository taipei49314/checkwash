# 交付包獨立只讀核對

範圍：`outputs/checkwash-ux-milestone-20261026/` 的 report、problem ledger
JSON／CSV、claim register、copy provenance 及主要 raw／receipt。沒有修改產品，
沒有重跑 CheckWash、pytest 或其他測試負載；只解析檔案、核對複製 hash。

結論：**未發現主要實測結果、來源邊界或編碼的阻擋錯誤。發現一個補充主張的
traceability 小缺口，已回報 root 並獲採納修法；最終 export 尚待反映。**
fullsuite-r3 尚在執行，不將其未生成 receipt／JUnit 或 MANIFEST 視為已完成，
亦不將這些 pending 連結列為此輪失敗。

## 實際發現與精確修法

`claim-register.json` 的九筆補充 claim 都寫：

```json
"empirical_status": "SEE_PROBLEM_LEDGER_NOT_A_CLAIM_LEVEL_PASS"
```

但它們沒有出現在任何一筆 `problem-ledger.json` 的 `original_claim_refs`。
因此「SEE_PROBLEM_LEDGER」對這九筆沒有可循的 numbered-problem 目的地。
原始 claim 本身沒有遺失，也沒有被標成 PASS。

初次核對的九個 top-level `claim_id` 所在行與完整 key：

| claim-register 行 | 完整 key |
|---:|---|
| 184 | `B1-paths-junction-usage-errors/X-1` |
| 196 | `B1-paths-junction-usage-errors/X-2` |
| 208 | `B1-paths-junction-usage-errors/X-3` |
| 220 | `B1-paths-junction-usage-errors/X-4` |
| 628 | `C1-policy-files-hook-upgrade/#e-1` |
| 640 | `C1-policy-files-hook-upgrade/#e-2` |
| 652 | `C1-policy-files-hook-upgrade/#e-3` |
| 664 | `C1-policy-files-hook-upgrade/#b-1` |
| 676 | `C1-policy-files-hook-upgrade/#U-1` |

建議且 root 已明確採納的修法：各 register row 加
`numbered_problem_refs`／`original_analysis_pointer`；未映射的九筆明標
`SUPPLEMENTARY_STATIC_ONLY_SEE_ORIGINAL_ANALYSIS`，另輸出
`supplementary-claims.json`。保留原 cluster＋id 和原文，不硬把 cross-cutting
論述歸為某一個已實測問題，也不替它們新增 PASS。更新後重新 export／MANIFEST。
本報告描述初次審查版本，行號在重新 export 後會移動。

## 結構、複製與編碼

- 原始分析 127 claims，register 127 rows；`(cluster, claim_id)` 全部唯一，
  key set 與原分析完全一致，所有 `original` claim objects 結構／文字完全相同。
- 單用 id 的確有 `#12-4` 重複兩次；兩個不同 cluster 均保留，沒有碰撞。
- 14 個 ledger JSON rows 與 14 個 CSV rows 的問題號、status、claim refs、
  `claim_level_pass_claimed` 全部一致，該 PASS flag 全為 false；沒有不存在的
  claim refs。118 個 numbered refs 有映射；上述九筆是 supplementary 差異。
- `original-analysis.json` 與原交接 `evidence/wf-result.json` 的 SHA-256 相同：
  `e8b552e9acb178a6008d32dd105f262eaf509c7fb6cd3c0d9ff140ccd6cb8b3a`。
- 775 筆 copy provenance，共 18,248,462 bytes；所有 destination 原始 bytes
  與記錄 hash 相符，沒有 missing destination 或重複目的地。
- 初次 audit 的所有 source bytes 亦與 recorded hash 相符。後續 root 正在更新
  export／report helpers，第二次 audit 觀察到 `work/export_evidence.py` 和
  `work/finalize_report.py` 相對早期複本已改；**這是已知最終 re-export 待刷新**，
  不是 raw receipt 被改寫。現有 destination 仍全部符合其 provenance hash。
- 受查五個主檔均可嚴格 UTF-8 解碼，沒有新增 U+FFFD replacement character。
  register 保留原分析中被引述的編碼文字，不把原材料的例子誤判為 export 壞字。
- report 的實際相對檔案／目錄連結存在。待生成的是 r3 的 `receipt.json`、
  `junit.xml` 及頂層 `MANIFEST.json`，依本次審查指示保留 pending。

機械核對結果保存於 `work/quality/evidence-audit.json`；只讀 driver 為
`work/quality/evidence_audit.py`。該 JSON 中九筆 `omitted_refs` 表示尚未映射到
14 個 numbered problems，**不表示原分析或 register 遺失九筆**。

## 主要主張對原始資料

| 項目 | 核對結果 |
|---|---|
| **#7-N 反例** | `evidence/rename/results.json` 八筆 `N_unroll_changed`（兩來源×兩入口×freeze）全部 exit 1／block，各三個 `EXPECTED_VALUE_CHANGED` high。report 說「預測逃逸未重現」正確，沒有寫成所有 unroll 都逃逸。 |
| **#2 main junction** | `evidence/main-junction/manifest.json` 與 raw 保留四次 CLI、實際 tracked alias Git status。inside／regular 是 exit 1、同 finding／fingerprint；outside JSON exit 2 且 stdout 空；outside hook-json exit 0，但 payload 只有未分析 systemMessage、沒有 decision。report 的內外 target 邊界與未測 repo-root／跨磁碟限制正確。 |
| **#8 CRLF-only rename** | `evidence/rename-crlf/results.json` 四格×兩入口共八次全部 exit 0／pass。LF worktree 單筆 rename／零 finding；CRLF worktree 為刪增，只有 `TEST_DISABLED` info／`ASSERTION_MOVED`，兩格 key 相同；range 四格零 finding。report 正確區分配對不一致與未重現誤擋。 |
| **#10 tightening** | `evidence/remaining-probes/quality-tightening-quality.stdout` 是 base mode=report、exit 0／`reported`，帶 critical `QW_POLICY_CHANGED`；check stdout 為 critical guardrail／block。report 明說不是 clean，沒有用 exit 0 假稱 PASS。 |
| **08a 與 f86** | compat report／results 與四案例 qualification receipt 綁 `08a96b15`。主 report 明說不是 f86 正式資格，並指出兩者產品差異是 sweep 輸入。最終候選／Action diff 是 f86，不把舊兩版 rename 比較當作新候選相容性全證。 |
| **283 qualification** | `evidence/compat/qualification-probe.json` 確實只有 `summary.total=4`、`executed=4`、`failed=0`，source commit=08a；compat report 明記完整283 source及wheel/pyz NOT_RUN。主 report 沒有冒稱283全PASS。 |
| **公開 pinned Action** | replay 與 check-receipt 明記 action SHA=d6eda4f6／version0.9.0、base=1ffe、head=f86、high、comment_pr=false、兩步 exit0。原 engine stdout 為 pass／零 findings；主 report 正確稱 PJU local composite replay，沒有冒稱 hosted check 或 candidate-engine qualification。 |
| **舊失敗與 r2** | 原 r1 stdout 只有進度／E、未完整收尾；termination 是 ABORTED_ENVIRONMENT、receipt exit1／source unchanged。另存 long-TEMP probe 明確 1 failed／1 error，含 WinError206 copytree 與 Git add 128；相同短 TEMP 控制2PASS。r2 原 stderr 為 `unrecognized arguments: -n --dist worksteal`，receipt exit4、stdout空。report 均揭露，沒有改寫成完整 suite PASS。 |

上述核對只確認已存在的證據與主張相符。fullsuite-r3 的最終 exit、完整結果、
JUnit reconciliation、候選終態 source stability 與最終 MANIFEST 尚未由本輪
review 簽認；應在 root 收到真實終態後另核對並 export，不推算通過數。
