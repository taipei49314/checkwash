# Quality #12 development evidence

Provenance: `HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`.

- Host: `LAPTOP-01AGNPJU`; Windows; Python 3.11.9; pytest 9.1.1.
- Source base: `1ffe283d7d947fecc426dea99323b0a2620a9482`.
- Checkout: `work/checkwash-ux`; branch `fix/ux-repairs-20261026`.
- These are defect regressions, not release qualification or acceptance.
- The new defect fixtures statically analyze subject file bytes. The native
  fixture uses Git and creates/removes only its own junction directory entry;
  its target remains. Existing Action regressions retain their trusted,
  synthetic runtime and pollution controls.

## Separate named defects

### CRLF-only quality source mismatch

Original analysis: `E-quality-realworld-and-cli-output` claims `#12-1A`,
`#12-1B`, `#12-1C`, `#12-1D`, `#12-1E`. The static mechanism is now reproduced.

Before: `crlf-before-corrected-controls/receipt.json` and original
`stdout.txt` / `stderr.txt`; exit 1, **8 failed / 12 passed**. The six
policy/allow/version-file cases in both LF/CRLF directions differ from identical
sources; a real threshold weakening acquires spurious policy/incomplete output;
a clean native Git CRLF worktree gives exit 2 while `HEAD..HEAD` gives exit 0.
The version source explains that exit 2; policy-only / allow-only cases give
exit 1. Source modification patch was empty at this baseline run.

The earlier `crlf-before/` receipt is preserved as development history. It had
two unsuitable controls: a malformed lone-CR allow file was assumed valid, and
the manually rewritten CRLF checkout needed a Git index stat refresh. Those
controls were corrected before the definitive baseline above. The product
source was unchanged throughout those baseline runs.

Fix ownership: `src/checkwash/quality/engine.py` and new
`tests/test_quality_crlf.py`. Policy, allow, and declared version sources compare
only CRLF-normalized bytes; absence stays distinct. Comment/order edits and
real version edits remain visible; no parsed-TOML equivalence is introduced.
The existing source digest, fingerprint construction, schemas, severity model,
and exit-code mapping are unchanged.

### Quality junction inventory on Python 3.11

Original analysis: `B1-paths-junction-usage-errors`, claim `#12-4` (this is the
cluster-qualified id; other clusters can use the same id).

Before: `junction-before/receipt.json`, exit 1, **2 failed / 4 passed**.
Native `mklink /J` fixtures targeting inside and outside the repository both
lack a `linked: 120000` entry. Python 3.11.9 traverses the junction instead.

Fix ownership: `src/checkwash/quality/snapshot.py` and new
`tests/test_quality_junction.py`. Use `lstat().st_reparse_tag` and the exact
`IO_REPARSE_TAG_MOUNT_POINT` value, matching the junction predicate available
on later supported Python versions. Other directory reparse tags remain normal
directories. A source under a detected junction is refused before the strict
reader is called, preserving `EXTERNAL_SOURCE` with incomplete status.

## Validation status

The combined development run `fixes-after` completed with exit 1,
**7 failed / 328 passed** in 216.08 seconds. Both new defect modules passed.
All seven failures were existing Action tests:

- Three bootstrap and three PATH-canary controls selected the WSL launcher
  `C:\Windows\system32\bash.exe`, whose `/bin/bash` is unavailable. The
  existing Git Bash at `C:\Program Files\Git\bin\bash.exe` was not selected.
- The `report-incomplete` Action case returned an original receipt with
  `installed Checkwash content differs from pinned Action source`. Root's CLI
  changed between that test's package copy and its protected wrapper check.
  That is the wrapper's intended source-identity refusal, not a changed
  quality verdict.

The complete original failures remain in `fixes-after/`. Root will rerun
Action integration on a fixed final source with the process-local Git Bash
path selected; no global PATH or host setup change is proposed.

`focused-after` completed with exit 0, **273 passed** in 25.39 seconds after
adding a valid existing-exemption CRLF control. It covers both new modules and existing `test_quality.py`,
`test_quality_setup.py`, and `test_quality_profiles.py`. Individual receipts
record commands, exits, native stdout/stderr hashes, test hashes, and the
engine/snapshot patch hash. Final integration still needs a fixed final commit.

The new tests total 27 cases (21 CRLF, 6 junction). CRLF-only changes preserve
the complete quality payload for both clean comparisons and real threshold
losses, including fingerprint and a matching, valid base-side exemption.
Native junction fixtures pass for inside/outside targets; ordinary directories,
non-mount-point reparse tags, and directories without Windows metadata retain
their regular inventory.

Actual macOS/Linux and Python 3.12/3.13 runs: **NOT_RUN** in this subtask.
The native junction evidence is Windows/Python 3.11.9 only. No whole-project,
published-v0.9.0 compatibility, history sweep, model batch, or release gate is
claimed by these receipts.
