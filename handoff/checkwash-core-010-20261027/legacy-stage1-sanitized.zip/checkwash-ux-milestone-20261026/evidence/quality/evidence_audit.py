"""Read-only structural and copy-integrity audit of the milestone package."""
from collections import Counter
import csv
import hashlib
import json
from pathlib import Path
import re
from urllib.parse import unquote

SESSION = Path(__file__).resolve().parents[2]
OUT = SESSION / "outputs/checkwash-ux-milestone-20261026"
original = json.loads((OUT / "original-analysis.json").read_text(encoding="utf-8"))
claims = json.loads((OUT / "claim-register.json").read_text(encoding="utf-8"))
ledger = json.loads((OUT / "problem-ledger.json").read_text(encoding="utf-8"))
provenance = json.loads((OUT / "copy-provenance.json").read_text(encoding="utf-8"))
flat = {(group["cluster"], claim["id"]): claim for group in original["results"] for claim in group["claims"]}
keys = [(row["cluster"], row["claim_id"]) for row in claims]
rows = list(csv.DictReader((OUT / "problem-ledger.csv").read_text(encoding="utf-8-sig").splitlines()))
checks = {"claim_count": len(claims), "original_flat_count": len(flat),
          "cluster_id_duplicates": [list(key) for key, count in Counter(keys).items() if count > 1],
          "id_only_duplicates": {key: count for key, count in Counter(row["claim_id"] for row in claims).items() if count > 1},
          "claim_key_set_matches": set(keys) == set(flat),
          "original_claim_objects_preserved": all(row["original"] == flat[(row["cluster"], row["claim_id"])] for row in claims),
          "empirical_labels": sorted({row["empirical_status"] for row in claims}),
          "ledger_count": len(ledger), "csv_count": len(rows),
          "ledger_claim_pass_flags": sorted({row["claim_level_pass_claimed"] for row in ledger}),
          "csv_mismatches": [], "orphan_refs": [], "omitted_refs": [],
          "copy_rows": len(provenance), "copy_bytes": 0, "copy_missing": [], "copy_hash_mismatches": [],
          "source_missing": [], "source_hash_mismatches": [], "destination_collisions": [],
          "report_links_missing": [], "utf8_decode_errors": [], "replacement_character_files": []}
all_refs = {cluster + "/" + cid for cluster, cid in flat}
ledger_refs = [ref for row in ledger for ref in row["original_claim_refs"]]
checks["orphan_refs"] = sorted(set(ledger_refs) - all_refs)
checks["omitted_refs"] = sorted(all_refs - set(ledger_refs))
for left, right in zip(ledger, rows):
    if not (str(left["problem"]) == right["problem"] and left["status"] == right["status"]
            and "; ".join(left["original_claim_refs"]) == right["original_claim_refs"]
            and str(left["claim_level_pass_claimed"]) == right["claim_level_pass_claimed"]):
        checks["csv_mismatches"].append(left["problem"])
destinations = [row["destination"] for row in provenance]
checks["destination_collisions"] = [p for p, n in Counter(destinations).items() if n > 1]
for row in provenance:
    target = OUT / row["destination"]
    source = Path(row["source"])
    if not target.is_file():
        checks["copy_missing"].append(row["destination"])
    else:
        data = target.read_bytes()
        checks["copy_bytes"] += len(data)
        if hashlib.sha256(data).hexdigest() != row["sha256"]:
            checks["copy_hash_mismatches"].append(row["destination"])
    if not source.is_file():
        checks["source_missing"].append(str(source))
    elif hashlib.sha256(source.read_bytes()).hexdigest() != row["sha256"]:
        checks["source_hash_mismatches"].append(str(source))
for name in ("report.md", "problem-ledger.csv", "problem-ledger.json", "claim-register.json", "copy-provenance.json"):
    try:
        content = (OUT / name).read_text(encoding="utf-8")
    except UnicodeDecodeError:
        checks["utf8_decode_errors"].append(name)
        continue
    if "\ufffd" in content:
        checks["replacement_character_files"].append(name)
report = (OUT / "report.md").read_text(encoding="utf-8")
for target in re.findall(r"\]\(([^\n)]+)\)", report):
    if re.match(r"[a-zA-Z]+://", target) or target.startswith("#"):
        continue
    path = unquote(target.split("#", 1)[0])
    if not (OUT / path).exists():
        checks["report_links_missing"].append(path)
(SESSION / "work/quality/evidence-audit.json").write_text(json.dumps(checks, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps(checks, ensure_ascii=False, indent=2))
