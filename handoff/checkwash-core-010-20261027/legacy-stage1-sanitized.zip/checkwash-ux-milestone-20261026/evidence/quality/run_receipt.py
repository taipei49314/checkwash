"""Capture native regression stdout/stderr without rewriting the tested inputs."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT / "checkwash-ux"
label, *targets = sys.argv[1:]
out = Path(__file__).resolve().parent / label
out.mkdir(parents=True, exist_ok=False)
env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", PYTHONPATH=str(REPO / "src"))
command = [sys.executable, "-B", "-m", "pytest", "-p", "no:cacheprovider", *targets]
result = subprocess.run(command, cwd=REPO, env=env, capture_output=True)
(out / "stdout.txt").write_bytes(result.stdout)
(out / "stderr.txt").write_bytes(result.stderr)
diff = subprocess.run(["git", "diff", "--", "src/checkwash/quality/engine.py", "src/checkwash/quality/snapshot.py"],
                      cwd=REPO, check=True, capture_output=True).stdout
(out / "source.patch").write_bytes(diff)
meta = {"provenance": "HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL",
        "hostname": platform.node(), "runtime": sys.version,
        "timestamp_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "executable": sys.executable,
        "source_sha": subprocess.run(["git", "rev-parse", "HEAD"], cwd=REPO, check=True, capture_output=True, text=True).stdout.strip(),
        "source_patch_sha256": hashlib.sha256(diff).hexdigest(),
        "command": command, "cwd": str(REPO), "exit_code": result.returncode,
        "test_sha256": {p: hashlib.sha256((REPO / p).read_bytes()).hexdigest() for p in targets if (REPO / p).is_file()},
        "stdout_sha256": hashlib.sha256(result.stdout).hexdigest(),
        "stderr_sha256": hashlib.sha256(result.stderr).hexdigest()}
(out / "receipt.json").write_text(json.dumps(meta, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"label": label, "exit_code": result.returncode, "path": str(out)}))
print(result.stdout.decode("utf-8", errors="backslashreplace")[-8000:])
sys.exit(result.returncode)
