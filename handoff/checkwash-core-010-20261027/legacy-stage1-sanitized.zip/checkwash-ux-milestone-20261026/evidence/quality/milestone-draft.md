# 第一里程碑草稿：窄修候選、重現台帳與待決策項

整理日期：2026-10-26（Asia/Taipei）。這是給 root 整合的草稿，不修改產品，
不要求 Nelson 現在回覆，也不暫停仍可獨立完成的窄修。

目前建議：**保留 0.9.2 作為窄修候選；若要一併修正已重現的 D2／D5／
oracle_freeze 裁決問題，另準備 0.10.0 的具體受保護變更包。** 尚未 bump
版本；這兩個版本號都是條件式建議，均沒有發布授權。r65 的 v0.9.1 發版
暫停繼續有效，既有 tag 與失敗收據保留。

## 基線與證據口徑

| 項目 | 已核對／本稿使用的來源 |
|---|---|
| 主機 | `LAPTOP-01AGNPJU`；`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL` |
| OS／runtime | Windows `10.0.26200`、Python 3.11.9；rename 收據記 Git `2.55.0.windows.3`；shell 版本由 root 的最終基線表補入 |
| 問題重現基線 | 未公開 v0.9.1 source `1ffe283d7d947fecc426dea99323b0a2620a9482` |
| 公開升級基線 | v0.9.0 source `d6eda4f695fabb8e7d138f7a87b099d2028f0294`；不能用未公開 v0.9.1 取代它 |
| 已整合窄修 checkpoint | 本稿讀取時為 `08a96b1542f1ff14c1876f0714e961860ee8c398`；sweep 輸入修補仍開發中，最終候選 SHA／工作樹／整合測試由 root 另行固定 |
| 原分析 | handoff `evidence/wf-result.json` 的 8 群組、127 條子主張是含反駁與限制的靜態分析，不是 127 個實測 PASS |

下列「重現」指工具在自建最小靜態 fixture 的實際輸出。被分析 fixture 的
Python／pytest 程式沒有執行，不能據此宣稱 fixture runtime 綠燈。未測平台、
完整原使用者終端環境與未納入的變體都保留為未測；開發中工作樹測試亦不等於
固定最終來源的 release qualification。

## 14 項狀態草稿

| 項目／群組 | 本輪實測結論 | 已做／目前修復狀態 | 尚未證明或待決策的邊界 |
|---|---|---|---|
| **#1 終端編碼／A** | 受控 cp950、cp1252、ASCII、UTF-8 stream 案例核對了自有裝飾字元與安全 writer 的落差；沒有重播使用者原本完整 shell／管線環境。 | `be8dcca3` 改自有 glyph／dash／dot／ellipsis 的顯示選擇；來源檔名與 evidence 不音譯、不丟棄，machine UTF-8 writer 未改。commit 記 12 個 targeted tests PASS。 | 對原終端環境仍只能說受控重現；不是所有 detector 訊息內排版字元均已處理。 |
| **#2 main reader junction／B1** | 後續補了固定 `1ffe` 來源的 **4 次 bounded CLI**：index stage-0 mode100644 tracked `tests/alias/test_api.py`，Git 三fixture均實際列出該修改。inside target junction 與一般目錄控制都是 **exit 1／ASSERT_WEAKENED high／BLOCK**、相同 finding／fingerprint；outside target junction JSON **exit 2**、stdout空、stderr `strict snapshot path leaves the repository`；同outside hook-json **exit 0、NOT_ANALYSED systemMessage、無decision**。限定越界讀取情境已重現。 | 主 `WorkingTreeSnapshot` 沒有修改；D-134 residual 保留；可另做列出拒絕路徑／入口／原因的診斷切片。這是 main reader 自己的證據，不代用 quality 測試。 | repo root 經 junction、跨磁碟別名、其他 Python／OS 仍未測；不是所有 junction 都失敗，也不是 hook exit0等於clean。此4次是舊基線重現，不是候選全平台驗收。 |
| **#3 新舊政策目錄遮蔽／C1** | 基線 `.greenwash/config.toml` 為 `on_engine_error="block"`；新建優先的 `.checkwash/config.toml` 改成 `pass_with_warning`，check **exit 0／PASS**，僅 `GUARDRAIL_TOUCHED` warn／`GUARDRAIL_CREATED`。建立候選 shadowing 未被視為對有效舊政策的放寬，已重現。 | 已建立原始 stdout／stderr／manifest，未改 precedence 或政策比較方式。 | 未執行「提交新設定後下一次錯誤處置」完整流程，也未測合法逐檔遷移；若修改 effective-base 比較或 precedence，須先具體決策。 |
| **#4 相對 --task／B1** | cwd 在 repo 外、指定 `--repo <repo> --task TASK.md` 得 **exit 2**，stderr 指 `../TASK.md` 越出 repo，stdout 空。相同 fixture 改用絕對 task 路徑得 **exit 1／BLOCK**，含 `ASSERT_WEAKENED` high、`ORACLE_FREEZE`，另有 `SCOPE_DRIFT` warn。語義落差已重現。 | 已建立相對／絕對控制；未換路徑解析基準。 | 跨磁碟、repo 子目錄與 junction 別名未測；不能靠改 help 成 cwd-relative 隱藏 SPEC 的 repo-relative 定義。 |
| **#5 hook 自我升級阻擋／C1** | 本輪只直接改 tracked `.claude/settings.json`，得到 **exit 1／BLOCK、GUARDRAIL_TOUCHED critical**。證明 tracked settings 的保護行為。 | 已保留控制收據，未新增 managed-upgrade 豁免。 | **沒有實際執行 doctor 重裝／升級流程**；不得寫成自動升級失敗已重現。是否為工具管理的最小改動設例外，是信任／gating 決策。 |
| **#6 quality 輸出／E** | 部分 usage error 在指定 JSON／SARIF 時輸出純文字的缺陷已重現並修補；review 發現 setup JSON 不應變成 review verdict，已再修正。 | `645f04d8`＋`23798e33` 保持 exit 2；review errors 使用既有 quality envelope，init／doctor JSON 使用既有 advisory setup envelope。root 記 reviewed targeted 45 PASS。 | **整項仍 PARTIAL**：成功 `explain` 的 JSON／SARIF 仍純文字、`profiles --format term` 仍 JSON、draft 保存指引與 init 補救訊息尚未修。PowerShell 5.1 UTF-16 重導陷阱沒有本輪實測。 |
| **#7 rename／oracle／D** | 72 次固定來源 CLI、36 個 v0.9.0／v0.9.1 配對觀察，版本間 exit／verdict／findings（含 fingerprint）差異 0。A 在 default 與 freeze 都 **info／ASSERTION_MOVED／PASS**；B／B_from_A default **warn／RESTRUCTURED／PASS**，freeze **high／BLOCK**。逃逸形狀有實證。相反，literal N unroll 弱化在兩版本兩入口皆 **3 個 EXPECTED_VALUE_CHANGED high／BLOCK**，其預測逃逸未重現。 | 僅重現與提案，沒有改 D2／D5／E2、repair credit、alignment、strength 或 protected files。合法改名、保持期望的 unroll、純跨檔搬移均 PASS。 | 不可寫「所有 rename／unroll 都逃逸」。E2 ordering、D2 identity、D5 等價性各須精確裁決；production cochange／#419 Route A 未包含於此矩陣。 |
| **#8 worktree／range rename／B2** | 已有 **LF、core.autocrlf=false** 的部分入口差異：跨檔搬移並只改 param decorator，worktree **info／ASSERTION_MOVED／PASS**（freeze 也 PASS），range **EXPECTATION_DEFINITION_CHANGED high／BLOCK**。純跨檔搬移控制兩者 PASS。 | 未改 rename pairing 或 fingerprint；本例與 #7 身份問題交疊。 | **CRLF 破壞 raw-byte rename pairing 的主張仍未實測**，不能把 #12 quality CRLF 修補當成本項已修。更廣 rename 相似度／身份策略須另比較既有指紋。 |
| **#9 registered gitlink／B2** | 原生 dirty tracked／untracked／pointer 案例重現 directory snapshot error。鄰接真弱化原先 JSON **exit 2**；hook **exit 0、NOT_ANALYSED、無 decision**。小寫 m 解析缺陷未成立，porcelain v1 是 uppercase M。 | `08a96b15` 僅對實際目錄＋exact stage-0 mode-160000 index entry 避免一般檔讀取。新 22-case module **18 failed／4 passed → 22 passed**；既有相關 **191 passed／9 skipped**。修後鄰接弱化 JSON **exit 1／BLOCK**、hook **exit 0／decision:block**，與 clean-submodule 控制的 output／fingerprint 相同。 | D-123 checked-out submodule context 保留；不略過任意目錄／nested repo／.git 路徑。這些 targeted 開發證據不是最終全平台驗收。 |
| **#10 quality 政策／allow 自我阻擋／C2** | 已實測 report→enforce：check **exit 1／GUARDRAIL_TOUCHED critical／BLOCK**；quality 仍用 base report，**exit 0／reported**，帶 critical `QW_POLICY_CHANGED`，不是 clean。 | `9cf6ea59` 修「已知 QW key 被 check allow 寫錯 ledger 卻似成功」：現在 exit 2、給 quality ledger／target_id 指引、寫前拒絕。 | tightening 及多筆 quality allow 的 gate 政策未改；第二筆 allow 的 main-check 自我阻擋未在本輪另做原生重現。不能把整個 quality 目錄移出 guardrail。 |
| **#11 未知 fingerprint／C2** | 已用 future namespace 控制確認 key 可被保留且具有 expiry eligibility，但這不代表當前引擎會產生能匹配的 finding。 | `7dfdb462` 加 writer／reader／doctor advisory；說明 unknown／wrong ledger 與 active-count 意義，保留未來規則相容性。診斷顯示轉義 LF／ESC／U+202e，ledger 原字串未改；root 記 15 targeted PASS。 | 不把 unknown 一律列為無效，不硬拒絕全部 `QW_` 前綴，不宣稱 active count 等於實際生效數。 |
| **#12 quality CRLF／junction／Ruff／E、B1** | CRLF corrected controls 改前 **8 failed／12 passed**；policy／allow CRLF-only 會誤報，version file 會 unresolved；實際 clean CRLF Git worktree 與 `HEAD..HEAD` 不一致。Python 3.11 native `mklink /J` 內／外 target 改前 **2 failed／4 passed**。 | `074e1fe6` None-safe CRLF-only byte 比較，保留 comment／order／lone-CR／真版本變更；`9978995a` quality 專用 exact mount-point tag junction 判別。focused 後 **273 PASS**，含 21 CRLF＋6 junction；真弱化完整 payload／fingerprint／有效 base allow 相同。 | **整組仍 PARTIAL**：Ruff 支援範圍／gitignore／unsupported keys／preview incomplete 未擴大；沒有新 profile qualification，也沒有把 incomplete 放行。main reader junction 不在此修補範圍。 |
| **#13 TASK parser／F** | **只完成 parser variants 觀察**：canonical present=true／freeze=true／scope=`tests/**`；BOM→present=false／freeze=false／scope空；inline-comment、quoted-true→freeze=false；flow-list→scope空而 freeze=true。 | 未擴充語言、未變空 list／unknown／fail-closed 語義，未加 runtime dependency。 | 沒有執行對應任務／hook／range 的逃逸案例；不能把 parser 差異寫成 runtime 任務逃逸已證實。quoted string 是否應接受為 boolean 也要先定義，不先替所有變體貼錯誤標籤。 |
| **#14 sweep 不等價／F** | 4 個 synthetic commits、8 次 CLI：regular pytest config 控制 range BLOCK／sweep 計 blocked=1；Git symlink pytest config 案例 range **CI_WORKFLOW_TOUCHED high／BLOCK**，sweep **blocked=0、無 finding**。另外 malformed check config／allow 在 range 的 `config_errors` 可見，sweep 輸出卻丟失，均 `engine_errors=0`。 | pytest_configs 漏接的窄修**開發中**，root 將另固定來源與回歸；本稿不宣稱已合格。 | **diagnostic 丟失仍未修**；exception 計數欠 commit 身份也未完成驗證／修補。sweep CLI 的 exit 0 是輸出統計，不表示每個 commit 都 PASS。舊 sweep 數據不追認成新來源證據。 |

## 待決策表草稿

以下是可審查的選項，不是本稿發出的批准請求。對應項目的最小案例與控制已保留；
需要更多資料的部分先列明，不用抽象「修完全部」取得 blanket policy 授權。

| 決策點 | 可明確選擇的範圍 | 各選項的實際後果與建議 |
|---|---|---|
| **D1：freeze 是否可以被 D2 提早抵銷？** | A：核可只針對 assertion-text D2 credit 的 E2 ordering 變更，連同 SPEC／gating／DECISIONS／正反例，以 minor 交付。B：本輪只出窄修，保留 #7 residual，另審較完整 identity 設計。 | A 可使已重現 A 在 freeze 下由 info／PASS 變 high／BLOCK；不解決 default A／B，也不自動關閉跨檔 body-hash route。若目標包含修逃逸，建議先形成 A 的 exact diff 再決定，不宣稱一招解決所有 #7。 |
| **D2：D2／D5 的等價證明要涵蓋什麼？** | A：要求 arriving credit 綁定可比較的 param rows／reaching definitions／subject context，並明訂 unknown。B：保留原策略但逐形狀加拒絕／診斷。 | 兩者都需合法 rename／unroll／整併控制及身份比較，涉及 protected policy。**不建議全面取消 D5 test-only compensation**；已測合法 unroll 與 concrete projection 的成功行為必須保留。 |
| **D3：政策遮蔽與合法遷移怎麼比較？** | A：先保留逐檔 precedence，只加 effective-policy 來源／影響診斷。B：提案讓新優先檔與 base 實際有效政策比較，並定義合法 migration 的處理。 | A 是可繼續的小診斷切片，不能關閉已重現的 warn／PASS 放寬風險。B 改政策比較基準，需補下一次生效／合法遷移控制及 frozen 契約審查。 |
| **D4：相對 --task 的權威定義** | A：依現行 SPEC 的 repo-relative 意圖準備精確解析修補，保留 absolute／base-tree 讀取與錯誤分類控制。B：若要採 cwd-relative，必須明文變更契約與 migration，而非只改 help。 | 尚未改基準。先補 cwd=repo／子目錄／跨磁碟／junction 別名及錯誤 payload 控制。若行為變更涉及 frozen 語義／身份，走 minor；不能因 patch 名稱就省略決策。 |
| **D5：工具管理檔案與 quality tightening／append 是否有窄例外？** | A：維持既有 prior-base reviewed exemption 流程，先改善預覽／補救訊息。B：另定能證明最小工具管理改動或安全 tightening／append 的例外。 | A 可先做；B 是 gating／trust 設計。不得豁免整份 settings 或 quality globs，也不得信任任意本機 bootstrap 自述。doctor 真升級及第二筆 allow 的原生重現先補齊。 |
| **D6：TASK 語言／unknown 的處理** | A：先文件化目前接受 subset 並診斷無法理解的輸入，保留既有裁決。B：擴大語法或 fail-closed，提供版本化遷移。 | A 可先準備；B 可能啟用過去忽略的 scope／freeze，改變裁決與指紋，先受保護契約審查。不得悄悄加 PyYAML runtime dependency，破壞零相依契約。 |
| **D7：是否擴充 Ruff preview profile？** | A：本輪只修 CRLF／quality junction 與 unsupported 理由。B：另提 equal-context／ignore model 等 profile 方案與 qualification。 | 建議本輪採 A。B 是獨立能力與證據工作，不以手邊 273 個 regression tests 取代 native qualification，也不因此啟動新自然 cohort／模型批次。 |

這些待決策項不阻擋已授權且互不相依的診斷、輸出、reader、輸入漏接窄修；
root 目前可繼續完成 sweep 修補、固定整合來源、必要檢查與 self dogfood。

## 版本建議與進入下一階段的條件

**0.9.2 窄修候選**可涵蓋自有終端符號、已知 QW 錯 ledger 拒絕、未知 key
診斷、quality usage 的正確既有 envelope、quality CRLF／3.11 junction、registered
gitlink，以及經獨立回歸證明的 sweep pytest_configs 漏接。判斷依據應是：

1. 沒改 severity／strength／alignment／D2／D5／repair credit 或 protected policy。
2. 既有 finding 身份、有效 exemptions、既有 schema 意義和 exit-code 類別保持。
   新修讀取／漏接缺陷會令原先 engine error 或漏 finding 的輸入得到可分析結果；
   這需具體比較與控制，不能只憑 diff 小就判 patch。
3. 機器格式修補沿用既有 review／advisory／SARIF envelope，沒有把 setup 提升為
   review authority；診斷只改顯示，不改 ledger 原 key 或匹配。
4. 最終 SHA 自己通過適用必過檢查與 self dogfood。所有開發時失敗與 skipped
   原樣保留，不換 expected labels 取得綠燈。

「exit-code 類別保持」不是說每個錯誤輸入的數字都不變：已知 QW key 投錯
check ledger 會由假成功 0 改為用法錯誤 2；registered gitlink 會由讀取錯誤 2
改為完成分析後的 0／1；CRLF-only 誤擋／unresolved 會消失。這些轉換必須逐項
披露並用合法相鄰控制證明，不能寫成「所有舊輸出皆 byte-identical」。

**0.10.0** 應用於受保護 D2／D5／E2／repair-credit 變更，或任何使既有
fingerprint 不再匹配、改 frozen CLI／config 語義、required schema 含義的範圍。
版本號不代替 maintainer 對 exact protected diff 的核可，也不代替正式驗證。

目前 rename 的 36 個配對觀察只證明兩個**舊基線彼此一致**，並不證明新候選
對它們都相容。最終比較必須分開保留：

- 公開使用者路徑：`v0.9.0 → 新候選 SHA`。
- 開發增量：`未公開 v0.9.1 → 新候選 SHA`。

正式 baseline 工具即使自動選到既有 v0.9.1 tag，也不代表使用者已安裝它；
不在本輪默默改掉正式 baseline 規則。舊 60 案可作回歸，但不構成新的重構成本、
1.0 門檻或外部有效性證據。發布、automation 恢復、tag、PyPI、下游 pin 仍待
後續明確指示；r65 暫停與 consumed grants 不因這份候選草稿而改變。

## 整合時使用的證據索引

- 原 scope／version 邊界：handoff `01-修復範圍與優先序.md`、
  `02-驗收與版本決策.md`；原始 `evidence/wf-result.json` 要連同 notes／反駁讀取。
- `work/remaining-probes/manifest.json`：固定基線、runtime、每個命令與 exit；
  同目錄 `task-relative-outside.stderr`、`task-absolute-control.stdout`、
  `policy-shadow-check.stdout`、`tracked-hook-settings-check.stdout`、
  `quality-tightening-{check,quality}.stdout`、`task-parser.json`。
- `work/rename/report.md`、`summary.json`、`results.json`、
  `supplement/results.json` 與 raw：72 次 static CLI、36 個基線配對觀察。
- `work/sweep-repro/results.json` 的 `rows`：4 個 synthetic commits 的 8 次
  range／sweep CLI，含原命令、base/head、退出碼、payload、stdout/stderr hashes。
- `work/gitlink/report.md` 與 native before／after／clean controls：reader defect 與
  context／鄰接真 finding 回歸。
- `work/main-junction/report.md`、`manifest.json`、`summary.json` 與 raw：#2 的
  4 次 bounded CLI、實際 Git status/index、inside/outside／regular 控制。
- `work/quality/report.md`、`focused-after/`、兩份 before 收據與
  `root-review.md`／`root-review-probe.json`：quality 兩窄修及獨立 review 修正。
- root 的 `work/root-receipts/`：其他 named defects 的 before／after／reviewed
  targeted 收據；最終整合測試結果與 SHA 由 root 在成品表另行填入。
