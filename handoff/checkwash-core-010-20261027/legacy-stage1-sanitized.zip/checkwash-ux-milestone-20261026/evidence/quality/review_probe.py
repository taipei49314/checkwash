"""Small, source-read-only review probes; all results live beside this script."""
import contextlib
import datetime
import hashlib
import importlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
from types import SimpleNamespace
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
REPO = HERE.parent / "checkwash-ux"
sys.path.insert(0, str(REPO / "src"))
sources = ["src/checkwash/allowlist.py", "src/checkwash/cli.py", "src/checkwash/doctor.py",
           "src/checkwash/quality/cli.py", "src/checkwash/gitio/git.py",
           "src/checkwash/report/textio.py", "src/checkwash/report/term.py", "src/checkwash/demo.py"]

def hashes():
    return {p: hashlib.sha256((REPO / p).read_bytes()).hexdigest() for p in sources}

result = {"source_sha": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=REPO).decode().strip(),
          "source_before": hashes(), "runtime": sys.version,
          "provenance": "HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL"}
from checkwash.allowlist import AllowEntry, active_fingerprints, namespace_diagnostics
from checkwash.quality.cli import run

payloads = {}
for command, flags in [("doctor", {"root": "."}), ("init", {"rule": "extra"})]:
    args = SimpleNamespace(range=command, rule=None, format="json", repo=str(REPO),
                           root=None, paths=None, tool=None, details=False)
    vars(args).update(flags)
    text, code = run(args, datetime.date(2026, 10, 26))
    payload = json.loads(text)
    assert code == 2 and payload["checkwash_quality_setup_version"] == 1
    assert payload["authority"] == "advisory_only" and "verdict" not in payload
    payloads[command] = {"exit_code": code, "payload": payload}
result["setup_usage"] = payloads

unknowns = ["FUTURE_CHECK_RULE/tests/a.py/test_a/0123456789ab",
            "QW_FUTURE_RULE/main/q2:" + "a" * 64]
today = datetime.date.today()
rows = [AllowEntry(key, key.split("/")[0], "reviewed", "reviewer", today.isoformat(),
                   (today + datetime.timedelta(days=30)).isoformat()) for key in unknowns]
assert active_fingerprints(rows, today) == set(unknowns)
result["unknown_namespaces"] = {"active_keys_preserved": sorted(active_fingerprints(rows, today)),
                                "diagnostics": namespace_diagnostics(rows)}
injected = AllowEntry("FUTURE_RULE/path\nFORGED-OUTPUT\x1b[2J", "FUTURE_RULE", "reviewed", "reviewer",
                      today.isoformat(), (today + datetime.timedelta(days=30)).isoformat())
message = namespace_diagnostics([injected])[0]
result["namespace_control_display"] = {"message": message,
                                       "raw_newline": "\n" in message,
                                       "raw_escape": "\x1b" in message}

from checkwash.gitio.git import _indexed_gitlink
cases = {
    "exact_stage0": (b"160000 " + b"a" * 40 + b" 0\tvendor/[lib]\0", "vendor/[lib]", True),
    "sha256_stage0": (b"160000 " + b"a" * 64 + b" 0\tvendor/[lib]\0", "vendor/[lib]", True),
    "prefix": (b"160000 " + b"a" * 40 + b" 0\tvendor/[lib]/child\0", "vendor/[lib]", False),
    "wrong_path": (b"160000 " + b"a" * 40 + b" 0\tvendor/lib\0", "vendor/[lib]", False),
    "stage1": (b"160000 " + b"a" * 40 + b" 1\tvendor/[lib]\0", "vendor/[lib]", False),
    "unmerged_stages": (b"160000 " + b"a" * 40 + b" 2\tvendor/[lib]\0" + b"160000 " + b"b" * 40 + b" 3\tvendor/[lib]\0", "vendor/[lib]", False),
    "regular_mode": (b"100644 " + b"a" * 40 + b" 0\tvendor/[lib]\0", "vendor/[lib]", False),
    "two_records": ((b"160000 " + b"a" * 40 + b" 0\tvendor/[lib]\0") * 2, "vendor/[lib]", False),
}
checked = {}
for name, (raw, path, expected) in cases.items():
    with patch("checkwash.gitio.git._run", return_value=raw) as query:
        actual = _indexed_gitlink("fixture", path)
        assert actual is expected
        assert query.call_args.args[1] == ["--literal-pathspecs", "ls-files", "--stage", "-z", "--", path]
        checked[name] = actual
result["gitlink_exact_boundary"] = checked

orders = {}
env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", PYTHONPATH=str(REPO / "src"))
for module in ["checkwash.allowlist", "checkwash.gating", "checkwash.engine", "checkwash.doctor", "checkwash.cli"]:
    command = [sys.executable, "-B", "-c", "import " + module + "; from checkwash.allowlist import namespace_diagnostics; assert namespace_diagnostics([]) == []"]
    native = subprocess.run(command, env=env, cwd=HERE, capture_output=True, timeout=30)
    assert native.returncode == 0, native.stderr
    orders[module] = {"exit_code": native.returncode, "stdout": native.stdout.decode("utf-8"),
                      "stderr": native.stderr.decode("utf-8")}
result["import_orders"] = orders
result["source_after"] = hashes()
result["owned_sources_unchanged_during_probe"] = result["source_before"] == result["source_after"]
(HERE / "root-review-probe.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"setup_usage": "fixed", "imports": "all five pass",
                  "gitlink": checked, "namespace_controls": result["namespace_control_display"],
                  "sources_stable": result["owned_sources_unchanged_during_probe"]}, ensure_ascii=True))
