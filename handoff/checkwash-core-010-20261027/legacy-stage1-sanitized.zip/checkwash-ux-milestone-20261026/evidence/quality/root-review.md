# Independent read-only review of root's narrow repairs

Reviewer: `quality_fix`. No checkout files were edited for this review.
Review result at `08a96b1542f1ff14c1876f0714e961860ee8c398`: **no remaining
blocking finding in the reviewed slices**. This is source review plus small
development probes, not product acceptance or release qualification.

Host/runtime: `LAPTOP-01AGNPJU`, Windows/Python 3.11.9,
`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`.

## Findings raised and resolved during review

1. **Setup JSON usage errors initially used the review envelope.** Original
   `645f04d8` routed `quality init/doctor --format json` usage errors through
   `new_payload`, adding `checkwash_quality_version` and `verdict`. This
   contradicted `docs/quality-adoption.md:67–71`: setup JSON has its own
   `checkwash_quality_setup_version`, advisory authority and false verification
   flags, and is not a review verdict. Fixed in `23798e33`: the setup JSON
   branch now uses existing `base_result` / `add_issue` / `render` with
   `state="error"`, keeping exit 2 and omitting `verdict`. The final independent
   probe confirmed both `doctor --root .` and `init extra` with JSON. SARIF
   rejection uses the existing error projection with unsuccessful invocation.

2. **Unknown-key diagnostics initially inserted raw fingerprint controls.**
   The pending namespace diagnostic interpolated complete repository-owned
   fingerprints without display quoting. Existing future-namespace
   compatibility allows keys containing TOML-escaped LF/ESC, so the new stderr
   warning could create forged lines or terminal escape sequences. Root fixed
   the displayed key with `!r` in `7dfdb462`; the stored key and eligibility
   are unchanged. The independent probe's key containing LF and ESC produces
   visible escapes and no raw LF/ESC in the message. Root also added a
   regression preserving the stored LF/ESC/U+202e key while quoting display.

## Reviewed compatibility and boundaries

- **Known quality ledger rejection (`9cf6ea59`).** Only exact current quality
  rule IDs from `quality.model.RULES` are rejected by `checkwash allow`, with
  exit 2 before any directory or ledger write. A prefix-wide `QW_` prohibition
  was not introduced. Unknown check rule IDs and hypothetical future quality
  IDs retain read-side key/expiry eligibility and receive an advisory warning;
  this version does not claim to emit a matching finding. No fingerprint
  identity, active-key filtering or existing exemption matching was changed.
- **No observed helper circular import.** Namespace dependencies are imported
  inside the function after `allowlist` initialization. Five fresh processes
  imported `allowlist`, `gating`, `engine`, `doctor`, and `cli` first, then
  successfully invoked `namespace_diagnostics([])`. The setup error helper's
  late import of `setup` likewise succeeds when used from the quality CLI.
- **Machine output.** Namespace notices use stderr and do not alter check's
  JSON/SARIF payload construction. Review usage errors use schema-1 quality
  error envelopes; setup JSON usage errors now retain their separate advisory
  envelope. Exit 2 remains unchanged. Existing fixture labels were not edited;
  the changed setup test asserts the requested machine-format rejection.
- **Owned decoration (`be8dcca3`).** The shared encoding decision matches
  `write_text`'s existing Unicode/legacy split. Changes select owned symbols
  and the bounded evidence truncation marker; source strings, finding objects,
  fingerprints and the UTF-8 machine writer are not rewritten. ASCII `...`
  occupies three display characters within the existing 160-character bound,
  so that view retains two fewer source characters than Unicode ellipsis;
  full evidence remains in the unchanged machine payload.
- **Registered gitlink (`08a96b15`).** `_indexed_gitlink` uses literal pathspecs,
  `--` argument termination and a full exact single-record match. Only mode
  `160000`, stage 0, the exact path and a complete 40/64-hex OID match. Prefixes,
  pathspec metacharacters matching another path, conflict stages, other modes
  and multiple records do not qualify. The bypass also requires `lstat` to
  report an actual directory, so a symlink or regular-file replacement keeps
  going through the strict reader. A base regular file replaced by a gitlink
  retains its deletion. Checked-out submodule context is untouched because
  `WorkingTreeSnapshot` and its context APIs are not changed. Existing new
  tests cover dirty tracked/untracked content, pointer changes, session mode,
  neighboring real findings, ordinary directories and unregistered nested
  repositories.

## Independent probe evidence

`root-review-probe.json` records source SHA, eight source hashes before/after,
the native Python runtime, complete setup error payloads, future-key active
sets, escaped diagnostic text, five fresh import-process outputs, and eight
exact gitlink matcher cases. Command:

```powershell
python -B work/quality/review_probe.py
```

All probe assertions passed; source hashes were stable for the entire probe.
`git diff --check` on the reviewed files also passed. Root's reported targeted
45 setup and 15 namespace/writer test passes were inspected but not rerun by
this reviewer. No broad suite or additional history/model batch was launched.

## Residuals outside these named repair slices

- A successful `quality explain RULE --format json|sarif` still returns plain
  explanatory text. `profiles --format term` still prints JSON. These are
  pre-existing subcommand format inconsistencies, not regressions introduced
  by the usage-error slice. The overall handoff issue #6 should remain partial
  until they are separately resolved or deliberately documented.
- Unknown future `QW_` keys remain accepted with an advisory compatibility
  warning; they are not claimed to be useful in check's ledger by this version.
- Source review does not establish macOS/Linux behavior or other Python
  versions. Those platforms are NOT_RUN here. No merge, version bump, tag or
  publication approval is implied.
