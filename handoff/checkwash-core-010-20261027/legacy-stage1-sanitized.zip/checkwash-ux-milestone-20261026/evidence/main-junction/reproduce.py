"""Four bounded, trusted main-reader junction controls; no fixture code runs."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import stat
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
WORK = ROOT.parent
SOURCE = WORK / "rename/source-v091"
SHA = "1ffe283d7d947fecc426dea99323b0a2620a9482"
GIT_REPO = WORK / "checkwash-ux"
RAW = ROOT / "raw"
RAW.mkdir(exist_ok=False)
FIXTURES = ROOT / "fixtures"
FIXTURES.mkdir(exist_ok=False)
env = dict(os.environ, PYTHONPATH=str(SOURCE / "src"), PYTHONDONTWRITEBYTECODE="1", PYTHONUTF8="1")
for key in ("GITHUB_TOKEN", "GH_TOKEN", "OPENAI_API_KEY"):
    env.pop(key, None)
manifest = {"marker": "HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL", "hostname": platform.node(),
            "platform": platform.platform(), "runtime": sys.version, "executable": sys.executable,
            "source_sha": SHA, "source_root": str(SOURCE),
            "scope": "at most four CLI calls, each with a 60-second timeout",
            "fixture_execution": "NOT_RUN: fixture Python is only statically analyzed",
            "started_utc": datetime.now(timezone.utc).isoformat(), "records": [], "fixtures": {},
            "source_files": {}, "cleanup": []}

def persist():
    (ROOT / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")

def capture(label, command, cwd, *, data=None, timeout=30, expected=0):
    started = time.monotonic()
    try:
        native = subprocess.run(command, cwd=cwd, env=env, input=data, capture_output=True, timeout=timeout)
        code, stdout, stderr, timed_out = native.returncode, native.stdout, native.stderr, False
    except subprocess.TimeoutExpired as exc:
        code, stdout, stderr, timed_out = None, exc.stdout or b"", exc.stderr or b"", True
    (RAW / (label + ".stdout")).write_bytes(stdout)
    (RAW / (label + ".stderr")).write_bytes(stderr)
    row = {"label": label, "command": command, "cwd": str(cwd), "exit_code": code,
           "timeout_seconds": timeout, "timed_out": timed_out, "seconds": round(time.monotonic() - started, 4),
           "stdout": "raw/" + label + ".stdout", "stderr": "raw/" + label + ".stderr",
           "stdout_sha256": hashlib.sha256(stdout).hexdigest(), "stderr_sha256": hashlib.sha256(stderr).hexdigest(),
           "source_sha": SHA}
    manifest["records"].append(row)
    persist()
    if expected is not None and code != expected:
        raise RuntimeError(label + " returned " + str(code) + ": " + repr(stderr))
    return stdout, row

listed = subprocess.run(["git", "-C", str(GIT_REPO), "ls-tree", "-r", "-z", SHA, "--", "src"],
                        check=True, capture_output=True).stdout
for record in listed.split(b"\0"):
    if not record:
        continue
    meta, raw_path = record.split(b"\t", 1)
    mode, kind, oid = meta.split()
    assert kind == b"blob" and mode in {b"100644", b"100755"}
    relative = raw_path.decode("utf-8")
    source = SOURCE / relative
    content = source.read_bytes()
    actual = hashlib.sha1(b"blob " + str(len(content)).encode("ascii") + b"\0" + content).hexdigest()
    assert actual == oid.decode("ascii"), relative
    manifest["source_files"][relative] = {"git_blob": actual, "sha256": hashlib.sha256(content).hexdigest()}
expected_sources = set(manifest["source_files"])
actual_sources = {p.relative_to(SOURCE).as_posix() for p in (SOURCE / "src").rglob("*") if p.is_file()}
assert actual_sources == expected_sources, sorted(actual_sources ^ expected_sources)
manifest["source_verification"] = "all source archive members match exact Git blobs; no extra files"
manifest["git"] = subprocess.check_output(["git", "--version"]).decode("ascii").strip()
manifest["git_executable"] = shutil.which("git")
persist()

BEFORE = b"from pkg import api\n\ndef test_api():\n    assert api() == 1\n"
AFTER = b"from pkg import api\n\ndef test_api():\n    assert api() > 0\n"
PROD = b"def api():\n    return 1\n"
PATH = "tests/alias/test_api.py"
junctions = []

def fixture(name, kind):
    repo = FIXTURES / name
    repo.mkdir()
    serial = 0
    def git(*args, data=None):
        nonlocal serial
        serial += 1
        return capture(name + "-git-" + str(serial), ["git", "-c", "core.hooksPath=nul", "-c", "core.autocrlf=false", *args],
                       repo, data=data)[0]
    git("init", "-q", "-b", "main")
    git("config", "user.name", "Owned junction regression")
    git("config", "user.email", "junction-fixture@example.invalid")
    git("config", "commit.gpgsign", "false")
    for path, content in (("pkg.py", PROD), (PATH, BEFORE)):
        oid = git("hash-object", "-w", "--stdin", data=content).decode("ascii").strip()
        git("update-index", "--add", "--cacheinfo", "100644," + oid + "," + path)
    tree = git("write-tree").decode("ascii").strip()
    base = git("commit-tree", tree, "-m", "owned static junction base").decode("ascii").strip()
    git("update-ref", "refs/heads/main", base)
    (repo / "pkg.py").write_bytes(PROD)
    (repo / "tests").mkdir()
    alias = repo / "tests/alias"
    if kind == "regular":
        alias.mkdir()
        target = alias
    else:
        target = repo / "owned-target" if kind == "inside" else FIXTURES / (name + "-owned-target")
        target.mkdir()
        (target / "test_api.py").write_bytes(AFTER)
        if kind == "inside":
            (repo / ".git/info/exclude").write_text("/owned-target/\n", encoding="utf-8")
        capture(name + "-mklink", ["cmd", "/c", "mklink", "/J", str(alias), str(target)], ROOT)
        assert alias.lstat().st_reparse_tag == stat.IO_REPARSE_TAG_MOUNT_POINT
        assert not alias.is_symlink()
        junctions.append((alias, target))
    (target / "test_api.py").write_bytes(AFTER)
    index, _ = capture(name + "-index", ["git", "ls-files", "--stage", "-z"], repo)
    status, _ = capture(name + "-status", ["git", "-c", "core.autocrlf=false", "status", "--porcelain", "-z", "--untracked-files=all", "--no-renames"], repo)
    manifest["fixtures"][name] = {"kind": kind, "repo": str(repo), "base_commit": base,
                                "tree": tree, "alias": str(alias), "target": str(target),
                                "alias_resolved": str(alias.resolve()),
                                "target_inside_repository": target.resolve().is_relative_to(repo.resolve()),
                                "index_utf8": index.decode("utf-8"), "status_utf8": status.decode("utf-8"),
                                "git_lists_changed_alias_file": PATH.encode("utf-8") in status,
                                "before_source": BEFORE.decode("utf-8"), "after_source": AFTER.decode("utf-8")}
    persist()
    print(json.dumps({"fixture": name, "status": status.decode("utf-8"), "alias_listed": PATH.encode("utf-8") in status}), flush=True)
    return repo

def check(name, repo, fmt):
    command = [sys.executable, "-B", "-m", "checkwash", "check", "--repo", str(repo), "--format", fmt]
    stdout, row = capture(name, command, ROOT, timeout=60, expected=None)
    try:
        payload = json.loads(stdout)
    except (ValueError, UnicodeError):
        payload = None
    row["payload"] = payload
    row["entrypoint"] = fmt
    persist()
    print(json.dumps({"cli": name, "exit": row["exit_code"], "payload": payload}, ensure_ascii=True), flush=True)

try:
    inside = fixture("inside-junction", "inside")
    check("inside-json", inside, "json")
    outside = fixture("outside-junction", "outside")
    check("outside-json", outside, "json")
    check("outside-hook-json", outside, "hook-json")
    regular = fixture("regular-directory", "regular")
    check("regular-json", regular, "json")
finally:
    for alias, target in junctions:
        owner = ROOT.resolve()
        alias_absolute = Path(os.path.abspath(alias))
        resolved = alias.resolve(strict=True)
        assert alias_absolute.is_relative_to(owner) and resolved.is_relative_to(owner)
        assert target.resolve(strict=True).is_relative_to(owner)
        assert alias.lstat().st_reparse_tag == stat.IO_REPARSE_TAG_MOUNT_POINT
        before = (target / "test_api.py").read_bytes()
        alias.rmdir()  # Non-recursive: remove only this verified owned junction entry.
        assert (target / "test_api.py").read_bytes() == before
        manifest["cleanup"].append({"alias_absolute": str(alias_absolute), "verified_resolved_target": str(resolved),
                                     "within_owner": str(owner), "operation": "nonrecursive junction rmdir",
                                     "target_content_preserved": True})
    manifest["ended_utc"] = datetime.now(timezone.utc).isoformat()
    manifest["cli_calls"] = sum("entrypoint" in row for row in manifest["records"])
    persist()
