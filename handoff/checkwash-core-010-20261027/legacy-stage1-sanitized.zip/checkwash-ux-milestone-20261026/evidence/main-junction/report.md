# #2 main-reader junction：有界原生重現

本輪已在固定未公開 v0.9.1 來源重現一個限定情境：**repo 內的 junction 指向
repo 外、Git 實際列出其下方 tracked 變更檔時，主讀取器拒絕越界，JSON exit 2；
hook-json exit 0 但明說未分析，沒有 pass 或 block decision。**

這是 main reader 的證據，不是 quality junction 測試的代用。指向 repo 內部的
junction 與一般目錄控制均完成分析並擋住相同 assertion 弱化。因此不能寫成
「任何 junction 都失敗」或「hook exit 0 就是 clean」。本輪沒有修產品。

## 來源、環境與限制

- `HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`；`LAPTOP-01AGNPJU`。
- Windows `10.0.26200`、Python 3.11.9、Git `2.55.0.windows.3`。
- 固定 source：`1ffe283d7d947fecc426dea99323b0a2620a9482`，來自獨立
  `work/rename/source-v091/src` archive；所有 archive members 與該 Git commit
  blob OID 逐一相同，且沒有額外檔案，逐檔 SHA-256／OID 記在 manifest。
- 可信自有 fixture 全在 `work/main-junction`。每個 CLI 最多 60 秒，
  **共 4 次 CLI**，實際約 1.2–5.64 秒，全部未逾時。
- 被分析的 Python／pytest fixture **沒有執行**。只執行固定 CheckWash 自身、
  Git、native `mklink /J`，沒有改主機設定、候選 checkout 或使用者資料。
- 這些是基線來源的靜態工具重現，不是候選最終來源、其他 OS／Python 或
  repo-root junction／跨磁碟別名的驗證。未納入情境仍為 NOT_RUN。

## 最小案例與 Git 觀察

以 Git blob/index／`commit-tree` 建立同一 base tree：

```python
# pkg.py: unchanged
def api():
    return 1

# tests/alias/test_api.py: base
from pkg import api

def test_api():
    assert api() == 1
```

工作樹只把 assertion 改為 `assert api() > 0`。三個 fixture 的 base tree 相同，
`tests/alias/test_api.py` 都是 **index stage-0 mode100644**；沒有 mode160000
gitlink，沒有以 Git symlink 取代 junction。

1. `inside-junction`：`tests/alias` 是 `mklink /J` 建立、native mount-point tag
   已核對的 junction，指向該 fixture repo 內的 `owned-target`。實體 target 目錄
   只在 fixture 自身 `.git/info/exclude` 排除，避免另列 untracked copy。
2. `outside-junction`：相同 alias 指向該 fixture repo 外的自有 target；target
   仍在本輪 `work/main-junction` 範圍，不接觸其他資料。
3. `regular-directory`：相同 path／bytes，使用一般目錄，不使用 junction。

每個 fixture 在執行 CheckWash **之前**，原生 `git ls-files --stage -z` 與
`git status --porcelain -z --untracked-files=all --no-renames` 已保存。三者 status
均實際列出：

```text
 M tests/alias/test_api.py\0
```

因此外部 target 的失敗不能歸因於「Git 沒有列出該路徑」，也沒有以任意未追蹤
整個目錄的案例代替 tracked file 情境。

## 四次 CLI 的原始結果

| label／入口 | 原始 exit | 結果 |
|---|---|---|
| `inside-json`／check json | 1 | `ASSERT_WEAKENED` high／`NO_PROD_CHANGE_IN_DIFF`；verdict `block`；stderr 空 |
| `outside-json`／check json | 2 | stdout 空；stderr `checkwash engine error: EngineError: strict snapshot path leaves the repository` |
| `outside-hook-json`／check hook-json | 0 | JSON 只有 `systemMessage`，明說 change was not analysed、neither passed nor blocked；**沒有 `decision`**；stderr 同樣記 engine error |
| `regular-json`／check json | 1 | 相同 `ASSERT_WEAKENED` high／BLOCK；stderr 空 |

inside-junction 與一般目錄控制的 finding objects 完全相同，fingerprint 都是：

```text
ASSERT_WEAKENED/tests/alias/test_api.py/test_api/v2:9a27f17761c9a9d310ac9a4f194d6d80a67c640be4be5e1d17d97bef3619f399
```

完整 payload 的 run.base 因 fixture commit 時間不同而不同；不把兩份 stdout
說成 byte-identical。finding／verdict 比較結果與相同 base-tree 證明見 summary。

## 原主張對照與待做範圍

- `B1-paths-junction-usage-errors/#2-1` 的限定機制：**已重現**。越界讀取被拒絕，
  但現有錯誤沒有列出被拒絕的具體路徑；可另做診斷切片。
- `#2-2` repo root 本身經 junction 的路線：本輪 **NOT_RUN**，不推論一律失敗。
- `#2-3` 主讀取器 junction 能力／各 Python 差異：本輪只在 Python 3.11.9
  觀察到上述內／外 target 差異；不冒充 3.12／3.13 或所有 reparse-point 的證據。
- 沒有用 quality 的 EXTERNAL_SOURCE／incomplete 來描述這裡的主引擎結果。
- 沒有為改 reader 路由、放寬越界或移動 protected residual 作決策。

## 證據與自有 junction 清理

`reproduce.py` 保存 fixture bytes、準備步驟與四次 CLI；`manifest.json` 保存
source/runtime、原命令／cwd／exit／timeout、Git index/status、stdout/stderr
路徑與 SHA-256。`raw/` 保留所有原始 bytes，`summary.json` 保存比較結果與
driver SHA-256。

兩個自有 junction 均在採證後只移除 directory entry，未遞迴刪除：移除前
分別核對 lexical absolute path、resolved target 都在 `work/main-junction`，
核對 native junction tag，再 `rmdir`，並確認 target 檔案 bytes 保持。
manifest 的 cleanup rows 保存這些已解析絕對路徑。一般 fixture 與 target 原件保留。
