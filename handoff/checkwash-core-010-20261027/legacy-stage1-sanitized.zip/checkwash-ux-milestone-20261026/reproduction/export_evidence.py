"""Preserve bounded UX receipts as user-facing deliverables; leave originals intact."""
from datetime import datetime, timezone
import csv
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import re
import shutil
import socket
import subprocess
import sys
import tomllib
import urllib.request

ROOT = Path(__file__).resolve().parent.parent
WORK = ROOT / "work"
REPO = WORK / "checkwash-ux"
OUT = ROOT / "outputs/checkwash-ux-milestone-20261026"
OUT.mkdir(parents=True, exist_ok=True)
HANDOFF = Path(r"C:\Users\nelson\Documents\Codex\2026-10-26\new-chat\outputs\checkwash-next-session-handoff-20261026")
copies = []
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def copy(source, target):
    if not source.is_file():
        return
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
    assert sha(source) == sha(target)
    copies.append(dict(source=str(source), destination=str(target.relative_to(OUT)), sha256=sha(target)))
def tree(source, target):
    if not source.is_dir():
        return
    for base, dirs, files in os.walk(source):
        dirs[:] = [d for d in dirs if d not in {"environment", ".git", "__pycache__", ".pytest_cache", "pytest-cache"}
                   and not (d.startswith("candidate-fullsuite") and not (Path(base, d) / "receipt.json").is_file())]
        for name in files:
            item = Path(base, name)
            copy(item, target / item.relative_to(source))

for folder in ("crlf-before", "crlf-before-corrected-controls", "fixes-after", "focused-after", "junction-before"):
    tree(WORK / "quality" / folder, OUT / "evidence/quality" / folder)
for folder in ("root-receipts", "action-dogfood"):
    tree(WORK / folder, OUT / "evidence" / folder)
for group in ("quality", "gitlink", "rename", "sweep-repro", "compat", "remaining-probes", "rename-crlf", "main-junction"):
    source = WORK / group
    if not source.is_dir():
        continue
    for item in source.iterdir():
        if item.is_file():
            copy(item, OUT / "evidence" / group / item.name)
    for child in ("raw", "supplement/raw"):
        tree(source / child, OUT / "evidence" / group / child)
    if group == "rename":
        for name in ("results.json", "reproduce.py", "supplement.py"):
            copy(source / "supplement" / name, OUT / "evidence/rename/supplement" / name)

copy(HANDOFF / "evidence/wf-result.json", OUT / "original-analysis.json")
copy(HANDOFF / "evidence/v091/pause-r65.json", OUT / "release-pause-r65.json")
copy(Path(r"C:\Users\nelson\.codex\AGENTS.md"), OUT / "global-AGENTS.snapshot.md")
copy(REPO / "AGENTS.md", OUT / "repository-AGENTS.snapshot.md")
copy(REPO / "docs/ux-repair-candidate-2026-10-26.md", OUT / "candidate-scope.md")
for name in ("run_capture.py", "probe_remaining.py", "export_evidence.py", "finalize_report.py", "package_outputs.py"):
    copy(WORK / name, OUT / "reproduction" / name)
for name in ("test-runtime-install.json", "test-runtime-distributions.json"):
    copy(WORK / name, OUT / "reproduction" / name)
copy(WORK / "test-runtime/pyvenv.cfg", OUT / "reproduction/test-runtime-pyvenv.cfg")

queries = []
def command(label, args):
    result = subprocess.run(args, cwd=REPO, capture_output=True, timeout=90)
    (OUT / (label + ".stdout")).write_bytes(result.stdout)
    (OUT / (label + ".stderr")).write_bytes(result.stderr)
    queries.append(dict(label=label, command=args, exit_code=result.returncode))
    return result.stdout.decode("utf-8", errors="replace").strip()
head = command("candidate-head", ["git", "rev-parse", "HEAD"])
tree_sha = command("candidate-tree", ["git", "rev-parse", "HEAD^{tree}"])
command("candidate-status", ["git", "status", "--porcelain=v1", "--untracked-files=all"])
command("remote-refs", ["git", "ls-remote", "origin", "refs/heads/main", "refs/heads/fix/ux-repairs-20261026", "refs/tags/v0.9.0", "refs/tags/v0.9.0^{}", "refs/tags/v0.9.1", "refs/tags/v0.9.1^{}"])
command("release-latest", ["gh", "api", "repos/taipei49314/checkwash/releases/latest", "--jq", "{tag_name,published_at,html_url}"])
command("pr-state", ["gh", "api", "repos/taipei49314/checkwash/pulls/566", "--jq", "{number,state,draft,merged,head:.head.sha,base:.base.sha,html_url}"])
command("github-check-runs", ["gh", "api", f"repos/taipei49314/checkwash/commits/{head}/check-runs", "--jq", "{total_count,checks:[.check_runs[]|{name,status,conclusion}]}"])
command("protected-files-diff", ["git", "diff", "--name-only", "1ffe283d7d947fecc426dea99323b0a2620a9482", head, "--", "SPEC.md", "THREATMODEL.md", "DECISIONS.md", "DECISIONS-archive-*.md", "tests/gates", "src/checkwash/gating.py", "src/checkwash/ir/strength.py"])
command("ec-policy-identity", ["gh", "api", "repos/taipei49314/estate-consolidation/contents/POLICY.md?ref=12ec19fa84ee8a536772c16f753a08c6b99cb06e", "--jq", "{sha,html_url}"])
patch = subprocess.run(["git", "diff", "1ffe283d7d947fecc426dea99323b0a2620a9482", head, "--binary"], cwd=REPO, capture_output=True, check=True).stdout
(OUT / "candidate.patch").write_bytes(patch)
try:
    with urllib.request.urlopen("https://pypi.org/pypi/checkwash/json", timeout=30) as response:
        raw = response.read()
    data = json.loads(raw)
    pypi = dict(url="https://pypi.org/pypi/checkwash/json", response_sha256=hashlib.sha256(raw).hexdigest(),
                version=data["info"]["version"], has_091="0.9.1" in data["releases"])
except Exception as exc:
    pypi = dict(status="NOT_VERIFIED", error=type(exc).__name__ + ": " + str(exc))

baseline = dict(observed_utc=datetime.now(timezone.utc).isoformat(), host=socket.gethostname(), platform=platform.platform(),
                provenance="HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL", python=sys.version, python_executable=sys.executable,
                pytest=importlib.metadata.version("pytest"), pyyaml=importlib.metadata.version("PyYAML"),
                shell="PowerShell 7.6.5", git="2.55.0.windows.3", candidate=head, candidate_tree=tree_sha,
                public_base="d6eda4f695fabb8e7d138f7a87b099d2028f0294", unpublished_base="1ffe283d7d947fecc426dea99323b0a2620a9482",
                pull_request="https://github.com/taipei49314/checkwash/pull/566", pypi=pypi, native_queries=queries)
baseline["automations"] = {}
for automation in ("checkwash-tag", "checkwash-main"):
    config = Path(r"C:\Users\nelson\.codex\automations") / automation / "automation.toml"
    data = tomllib.loads(config.read_text(encoding="utf-8"))
    baseline["automations"][automation] = {key:data.get(key) for key in ("name", "status")}
trusted = WORK / "trusted/replay_pju_action.py"
original = subprocess.run(["git", "show", "1ffe283d7d947fecc426dea99323b0a2620a9482:tools/replay_pju_action.py"], cwd=REPO, capture_output=True, check=True).stdout
baseline["action_replayer"] = dict(source="1ffe283d7d947fecc426dea99323b0a2620a9482:tools/replay_pju_action.py", sha256=sha(trusted), exact_base_bytes=trusted.read_bytes()==original)
(OUT / "baseline.json").write_text(json.dumps(baseline, indent=2), encoding="utf-8")
(OUT / "copy-provenance.json").write_text(json.dumps(copies, indent=2), encoding="utf-8")
analysis = json.loads((OUT / "original-analysis.json").read_text(encoding="utf-8"))
claim_rows = []
for cluster_index, cluster in enumerate(analysis["results"]):
    for claim_index, claim in enumerate(cluster["claims"]):
        numbered = re.match(r"^#(\d+)(?:\D|$)", claim["id"])
        number = int(numbered.group(1)) if numbered and 1 <= int(numbered.group(1)) <= 14 else None
        claim_rows.append(dict(cluster=cluster["cluster"], claim_id=claim["id"], original=claim,
                               numbered_problem_refs=[number] if number else [],
                               original_analysis_pointer=f"/results/{cluster_index}/claims/{claim_index}",
                               empirical_status="SEE_PROBLEM_LEDGER_NOT_A_CLAIM_LEVEL_PASS" if number else
                               "SUPPLEMENTARY_STATIC_ONLY_SEE_ORIGINAL_ANALYSIS"))
(OUT / "claim-register.json").write_text(json.dumps(claim_rows, ensure_ascii=False, indent=2), encoding="utf-8")
(OUT / "supplementary-claims.json").write_text(json.dumps([r for r in claim_rows if not r["numbered_problem_refs"]], ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps(dict(output=str(OUT), copied_files=len(copies), claims=len(claim_rows), candidate=head, pypi=pypi), indent=2))
