"""Assemble the first milestone from preserved source-backed records."""
import csv
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "outputs/checkwash-ux-milestone-20261026"
WORK = ROOT / "work"
baseline = json.loads((OUT / "baseline.json").read_text(encoding="utf-8"))
source = (WORK / "quality/milestone-draft.md").read_text(encoding="utf-8")
source = source[source.index("目前建議："):]
source = source.replace("## 14 項狀態草稿", "## 14 項實測與修復台帳").replace("## 待決策表草稿", "## 待決策提案")
source = source.replace("shell 版本由 root 的最終基線表補入", "PowerShell 7.6.5")
lines = source.splitlines()
replacements = {
    "| 已整合窄修 checkpoint |": f"| 最終窄修候選 | `{baseline['candidate']}`；工作樹乾淨，草稿 [PR #566](https://github.com/taipei49314/checkwash/pull/566)；8 個 named-defect 切片，10 個提交 |",
    "| **#2 ": "| **#2 main reader junction／B1** | 固定1ffe、4次CLI：Git均實列 modified regular tracked test path。inside junction及regular control均exit1／ASSERT_WEAKENED high／BLOCK，fingerprint相同；outside junction JSON exit2，hook-json exit0但只有NOT_ANALYSED訊息，無decision。 | 已重現外部目標的strict snapshot拒讀，沒有修改main reader或D-134政策；品質模組junction修補不代用於本項。 | repo-root／跨磁碟等其他形狀仍未測；不能說全部junction失敗。需保留路徑／入口／拒絕原因並另審診斷切片。 |",
    "| **#8 ": "| **#8 worktree／range rename／B2** | LF decorator cochange案例仍有worktree PASS／range BLOCK。另補8次CLI（autocrlf false/true × disk LF/CRLF × 兩入口）：LF worktree配rename零finding；CRLF worktree為D+A、TEST_DISABLED info／ASSERTION_MOVED，fingerprint一致；range四格零finding。所有純搬移控制exit0／PASS。 | raw-byte配對差異已重現，純CRLF搬移誤擋在此案例未重現；未改pairing或fingerprint。 | 不能把quality CRLF修補視為rename修補，也不能從這個未誤擋控制推論所有變體安全。更廣相似度／身份策略仍需minor契約審查。 |",
}
for index, line in enumerate(lines):
    for prefix, replacement in replacements.items():
        if line.startswith(prefix):
            lines[index] = replacement
            break
source = "\n".join(lines)
source = source.replace("pytest_configs 漏接的窄修**開發中**，root 將另固定來源與回歸；本稿不宣稱已合格。",
                        "`5fba4afc` 已補 PairedPytestConfigs／head snapshot reader。改前4格3PASS／1FAIL，改後26PASS／1SKIP，四個新parity cases全PASS；未改sweep JSON／exit／歷史數據。")
source = source.replace("root 目前可繼續完成 sweep 修補、固定整合來源、必要檢查與 self dogfood。",
                        "本輪已完成sweep輸入窄修、固定候選與self dogfood；正式required-check橋接與發布仍是獨立後續關卡。")
source = source.replace("## 整合時使用的證據索引", "## 證據索引")
suite_path = WORK / "root-receipts/candidate-fullsuite-r3/receipt.json"
suite = json.loads(suite_path.read_text(encoding="utf-8")) if suite_path.exists() else None
suite_stdout = (WORK / "root-receipts/candidate-fullsuite-r3/stdout.bin").read_bytes().decode("utf-8", errors="replace")
summary = next((line.strip() for line in reversed(suite_stdout.splitlines()) if re.search(r"\b\d+ passed\b", line)), "仍在執行；沒有先宣稱PASS")
action = json.loads((WORK / "action-dogfood/replay.json").read_text(encoding="utf-8"))
header = f"""# CheckWash 第一里程碑：候選、實測台帳與版本建議

日期：2026-10-26（Asia/Taipei）。已實作8個具名窄修並建立[草稿PR #566](https://github.com/taipei49314/checkwash/pull/566)。固定候選 `{baseline['candidate']}`，tree `{baseline['candidate_tree']}`，main仍是`1ffe283d`。版本metadata維持0.9.1；公開GitHub／PyPI仍為0.9.0。r65發布暫停保留，沒有合併、移動tag、發布、改下游pin或恢復automation。

## 固定候選驗證

| 驗證 | 實際結果 |
|---|---|
| 完整source suite | {summary}；原始exit：{suite['exit_code'] if suite else 'RUNNING'} |
| 來源穩定性 | {'tracked/input manifest前後完全相同' if suite and suite['source_files_unchanged'] else '完整套件結束後核對'} |
| 實際公開Action self-dogfood | `{action['status']}`；v0.9.0 exact Action，base1ffe／headf86，install/check皆exit0，high門檻、comment_pr=false；PJU local composite replay，非GitHub-hosted測試 |
| 候選CLI self-dogfood | 同一exact range的f86 source CLI exit0／PASS，findings空、config_errors空、skipped_files空；既有retired-exemption stderr通知保留，沒有用新豁免讓它通過 |
| Collection | 20,738 tests collected，僅為收集分母 |
| 開發窄修 | 保留before紅／after綠與review發現後修正，見各receipt；不將重疊測試數相加 |
| 有界版本相容性 | v0.9.0／v0.9.1／08a96b15：9個既有demo、clean range、weak range/worktree的既有finding身份／fingerprint／schema／exit一致；證據綁08a，而非冒稱f86正式資格。08a至f86的產品差異僅sweep輸入補接 |
| 獨立review | root的setup envelope／control escaping兩問題已修；後續f86 sweep及文件只讀review無剩餘blocking finding，非人類驗收 |
| 未執行／未建立 | 其他OS／Python、跨平台byte比較、完整283 source/wheel/pyz資格、正式release collector／tag驗證、receipt-bridge必過檢查；均不以本地targeted結果假綠 |

完整suite r3：[原始stdout](evidence/root-receipts/candidate-fullsuite-r3/stdout.bin)、[原始stderr](evidence/root-receipts/candidate-fullsuite-r3/stderr.bin)、[收據](evidence/root-receipts/candidate-fullsuite-r3/receipt.json)、[原始JUnit](evidence/root-receipts/candidate-fullsuite-r3/junit.xml)。Action：[replay](evidence/action-dogfood/replay.json)、[原始engine output](evidence/action-dogfood/runtime-receipts/stdout.txt)。

最終source suite使用Python3.11.9、pytest9.1.1及本案隔離venv的pytest-xdist3.8.0／execnet2.1.2，受控無憑證process環境明確指向既有Git Bash，plugin明確以`-p xdist.plugin`載入、雙worker/worksteal。沒有改主機全域PATH或long-path設定；[相依安裝report](reproduction/test-runtime-install.json)保留wheel來源／hash，[環境版本](reproduction/test-runtime-distributions.json)保留實際套件。

第一輪完整suite使用過深TEMP，Action fixture在copytree明確WinError206、compare Git add也失敗；已停止並記[ABORTED_ENVIRONMENT](evidence/root-receipts/candidate-fullsuite/termination.json)，原始不完整stdout／exit1／source不變收據均保留，沒有稱整套完成。用相同來源改短TEMP的兩個控制都PASS，[長路徑診斷](evidence/root-receipts/diagnose-long-temp/stdout.bin)與[短路徑控制](evidence/root-receipts/diagnose-short-temp/receipt.json)成對保留。r2因controlled environment停用plugin自動載入，`-n/--dist`未辨識而exit4、沒有執行測試；r3才是明確載入所釘plugin的完整嘗試，沒有覆寫r1/r2。早期Action開發回歸另有7個失敗（6個WSL Bash選路、1個同時改源的identity拒絕），保留在[evidence/quality/fixes-after](evidence/quality/fixes-after)。

所有PJU結果標記`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`。127條原主張中118條可依原編號連到14項問題；另外9條X-/e-/b-/U-補充主張另列[supplementary register](supplementary-claims.json)，標為靜態資料、未硬歸類或聲稱實測。每條register保留原分析JSON pointer。未跑的檢查與政策決策仍保留；本包不作正式發布驗收。

"""
compat_note = "\n## 相容性證據的精確範圍\n\n[三來源比較](evidence/compat/report.md)保留公開升級路徑與未公開開發增量；[rename 72次矩陣](evidence/rename/report.md)只比較兩個舊版，不充當新候選資格。[CRLF rename控制](evidence/rename-crlf/report.md)及[main junction控制](evidence/main-junction/report.md)各記自己的固定來源、Git entry和限制。\n\n[基線](baseline.json)、[原始分析](original-analysis.json)、[127條主張register](claim-register.json)、[逐項台帳CSV](problem-ledger.csv)、[candidate patch](candidate.patch)、[複製雜湊](copy-provenance.json)、[全包檔案雜湊](MANIFEST.json)。\n"
(OUT / "report.md").write_text(header + source + compat_note, encoding="utf-8")

statuses = {1:"REPRODUCED_BOUNDED_REPAIR",2:"REPRODUCED_RESIDUAL",3:"REPRODUCED_POLICY_PENDING",4:"REPRODUCED_CONTRACT_PENDING",5:"PARTIAL_MECHANISM_ONLY",6:"PARTIAL_REPAIRED",7:"REPRODUCED_POLICY_PENDING_WITH_REFUTED_VARIANT",8:"PAIRING_REPRODUCED_FALSE_BLOCK_NOT_REPRODUCED",9:"REPRODUCED_REPAIRED",10:"PARTIAL_REPAIRED_POLICY_PENDING",11:"ADVISORY_REPAIR_COMPATIBILITY_PRESERVED",12:"PARTIAL_REPAIRED_RUFF_PENDING",13:"PARSER_ONLY_CONTRACT_PENDING",14:"PARTIAL_REPAIRED_DIAGNOSTICS_PENDING"}
claims = json.loads((OUT / "claim-register.json").read_text(encoding="utf-8"))
rows = []
for number in range(1, 15):
    refs = [c["cluster"] + "/" + c["claim_id"] for c in claims if re.match(r"^#" + str(number) + r"(?:\D|$)", c["claim_id"])]
    rows.append(dict(problem=number, status=statuses[number], original_claim_refs=refs,
                     evidence="report.md#14-項實測與修復台帳", claim_level_pass_claimed=False))
(OUT / "problem-ledger.json").write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")
with (OUT / "problem-ledger.csv").open("w", encoding="utf-8-sig", newline="") as stream:
    writer = csv.DictWriter(stream, fieldnames=("problem", "status", "original_claim_refs", "claim_level_pass_claimed"))
    writer.writeheader()
    for row in rows:
        writer.writerow({k:("; ".join(row[k]) if k=="original_claim_refs" else row[k]) for k in writer.fieldnames})
print(json.dumps(dict(report=str(OUT / "report.md"), fullsuite_exit=suite.get("exit_code") if suite else None, summary=summary)))
