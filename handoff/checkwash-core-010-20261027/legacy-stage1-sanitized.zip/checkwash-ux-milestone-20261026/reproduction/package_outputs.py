"""Validate and package the completed milestone without rewriting native receipts."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "outputs/checkwash-ux-milestone-20261026"
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
receipt = json.loads((OUT / "evidence/root-receipts/candidate-fullsuite-r3/receipt.json").read_text(encoding="utf-8"))
assert receipt["exit_code"] == 0 and receipt["source_files_unchanged"]
assert receipt["source_sha"] == "f86aabbbe7e61891d8b93cb2c043b9bcae44f88a"
original = json.loads((OUT / "original-analysis.json").read_text(encoding="utf-8"))
claims = json.loads((OUT / "claim-register.json").read_text(encoding="utf-8"))
assert len(claims) == len({(r["cluster"], r["claim_id"]) for r in claims}) == 127
for row in claims:
    parts = row["original_analysis_pointer"].strip("/").split("/")
    observed = original[parts[0]][int(parts[1])][parts[2]][int(parts[3])]
    assert observed == row["original"]
supplement = json.loads((OUT / "supplementary-claims.json").read_text(encoding="utf-8"))
assert len(supplement) == 9
assert all(r["empirical_status"] == "SUPPLEMENTARY_STATIC_ONLY_SEE_ORIGINAL_ANALYSIS" for r in supplement)
copies = json.loads((OUT / "copy-provenance.json").read_text(encoding="utf-8"))
assert len({row["destination"] for row in copies}) == len(copies)
for row in copies:
    assert sha(OUT / row["destination"]) == row["sha256"], row["destination"]

report = (OUT / "report.md").read_text(encoding="utf-8")
assert "\ufffd" not in report
missing = []
for target in re.findall(r"\]\(([^)]+)\)", report):
    if "://" in target or target.startswith("#"):
        continue
    if target == "MANIFEST.json":
        continue  # Generated below, after derived summaries are saved.
    if not (OUT / target.split("#", 1)[0]).exists():
        missing.append(target)
assert not missing, missing
xml = ET.parse(OUT / "evidence/root-receipts/candidate-fullsuite-r3/junit.xml")
cases = list(xml.iter("testcase"))
metrics = dict(testcase_nodes=len(cases), skipped_nodes=sum(c.find("skipped") is not None for c in cases),
               failed_nodes=sum(c.find("failure") is not None for c in cases),
               error_nodes=sum(c.find("error") is not None for c in cases),
               native_suite_attributes=[node.attrib for node in xml.iter("testsuite")])
assert metrics["failed_nodes"] == metrics["error_nodes"] == 0
metrics["passed_testcase_nodes"] = metrics["testcase_nodes"] - metrics["skipped_nodes"]
metrics["basis"] = "Read-only native XML counts; no rewriting/reconciliation of original producer bytes. Native tests totals may include passed subtests."
(OUT / "native-suite-summary.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
for name in ("stdout", "stderr"):
    path = OUT / f"evidence/root-receipts/candidate-fullsuite-r3/{name}.bin"
    (path.parent / (name + ".txt")).write_bytes(path.read_bytes())

files = [dict(path=str(path.relative_to(OUT)).replace("\\", "/"), bytes=path.stat().st_size, sha256=sha(path))
         for path in sorted(OUT.rglob("*")) if path.is_file() and path.name != "MANIFEST.json"]
manifest = dict(created_utc=datetime.now(timezone.utc).isoformat(), candidate=receipt["source_sha"],
                provenance="HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL", files=files,
                note="This manifest excludes itself; the ZIP sidecar hashes the complete archive.")
(OUT / "MANIFEST.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
archive = OUT.parent / (OUT.name + ".zip")
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zipped:
    for path in sorted(OUT.rglob("*")):
        if path.is_file():
            zipped.write(path, OUT.name + "/" + str(path.relative_to(OUT)).replace("\\", "/"))
digest = sha(archive)
(archive.parent / (archive.name + ".sha256")).write_text(digest + "  " + archive.name + "\n", encoding="ascii")
print(json.dumps(dict(archive=str(archive), archive_sha256=digest, manifest_files=len(files),
                      copy_hashes_verified=len(copies), claims=127, native=metrics), indent=2))
