"""Small static fixtures for unresolved UX contract decisions; never run subjects."""
from dataclasses import asdict
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import platform
import socket
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "remaining-probes"
OUT.mkdir(exist_ok=False)
SOURCE = ROOT / "rename/source-v091"
env = dict(os.environ, PYTHONPATH=str(SOURCE / "src"), PYTHONDONTWRITEBYTECODE="1")
env.pop("GITHUB_TOKEN", None)
env.pop("GH_TOKEN", None)
sys.path.insert(0, str(SOURCE / "src"))
from checkwash.contract import parse_contract

records = []
def run(label, cwd, command):
    result = subprocess.run(command, cwd=cwd, env=env, capture_output=True, timeout=90)
    (OUT / (label + ".stdout")).write_bytes(result.stdout)
    (OUT / (label + ".stderr")).write_bytes(result.stderr)
    row = dict(label=label, cwd=str(cwd), command=command, exit_code=result.returncode,
               source_sha="1ffe283d7d947fecc426dea99323b0a2620a9482")
    records.append(row)
    return result

def repo(name, files):
    root = OUT / name
    root.mkdir()
    for path, data in files.items():
        target = root / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(data, encoding="utf-8", newline="\n")
    def git(*args):
        return run(name + "-git-" + str(len(records)), root,
                   ["git", "-c", "core.autocrlf=false", "-c", "core.hooksPath=nul", *args])
    git("init")
    git("config", "user.name", "UX static fixture")
    git("config", "user.email", "fixture@example.invalid")
    git("add", ".")
    git("-c", "commit.gpgsign=false", "commit", "-m", "owned static baseline")
    return root, git

task = "---\ncheckwash:\n  oracle_freeze: true\n  scope:\n    allow:\n      - tests/**\n---\n"
root, git = repo("task-relative", {"TASK.md": task, "test_api.py": "def test_api():\n    assert api() == 1\n"})
(root / "test_api.py").write_text("def test_api():\n    assert api() > 0\n", encoding="utf-8")
run("task-relative-outside", OUT, [sys.executable, "-B", "-m", "checkwash", "check", "--repo", str(root), "--task", "TASK.md", "--format", "json"])
run("task-absolute-control", OUT, [sys.executable, "-B", "-m", "checkwash", "check", "--repo", str(root), "--task", str(root / "TASK.md"), "--format", "json"])

variants = {"canonical": task, "bom": "\ufeff" + task,
            "inline-comment": task.replace("true", "true # freeze tests"),
            "quoted-true": task.replace("true", '"true"'),
            "flow-list": task.replace("    allow:\n      - tests/**", "    allow: [tests/**]")}
(OUT / "task-parser.json").write_text(json.dumps({name: {"input": text, "parsed": asdict(parse_contract(text))}
                                               for name, text in variants.items()}, indent=2), encoding="utf-8")

root, git = repo("policy-shadow", {".greenwash/config.toml": '[gate]\non_engine_error="block"\n'})
(root / ".checkwash").mkdir()
(root / ".checkwash/config.toml").write_text('[gate]\non_engine_error="pass_with_warning"\n', encoding="utf-8")
run("policy-shadow-check", root, [sys.executable, "-B", "-m", "checkwash", "check", "--format", "json"])

root, git = repo("tracked-hook-settings", {".claude/settings.json": '{"hooks":{}}\n'})
(root / ".claude/settings.json").write_text('{"hooks":{"Stop":[]}}\n', encoding="utf-8")
run("tracked-hook-settings-check", root, [sys.executable, "-B", "-m", "checkwash", "check", "--format", "json"])

policy = ('schema_version=1\nmode="report"\n[[targets]]\nid="coverage"\ntool="coverage"\nroot="."\n'
          'config="pyproject.toml"\nprofile="coverage-7.16.0-q1"\npaths=["src/"]\n')
root, git = repo("quality-tightening", {".checkwash/quality.toml": policy,
    "pyproject.toml": "[tool.coverage.report]\nfail_under=85\n", "src/api.py": "answer = 1\n"})
(root / ".checkwash/quality.toml").write_text(policy.replace('mode="report"', 'mode="enforce"'), encoding="utf-8")
run("quality-tightening-check", root, [sys.executable, "-B", "-m", "checkwash", "check", "--format", "json"])
run("quality-tightening-quality", root, [sys.executable, "-B", "-m", "checkwash", "quality", "--format", "json"])

manifest = dict(host=socket.gethostname(), provenance="HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL",
                python=sys.version, platform=platform.platform(), observed_utc=datetime.now(timezone.utc).isoformat(),
                source_sha="1ffe283d7d947fecc426dea99323b0a2620a9482", source_root=str(SOURCE), records=records)
(OUT / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
print(json.dumps([r for r in records if "-git-" not in r["label"]], indent=2))
