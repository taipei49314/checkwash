"""Record an ordinary local regression command without normalizing its output."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import socket
import subprocess
import sys
import importlib.util
import tempfile
from datetime import datetime, timezone

p = argparse.ArgumentParser()
p.add_argument("label")
p.add_argument("cwd")
p.add_argument("command", nargs=argparse.REMAINDER)
a = p.parse_args()
out = Path(__file__).resolve().parent / "root-receipts" / a.label
out.mkdir(parents=True, exist_ok=False)
cwd = Path(a.cwd).resolve()
env = dict(os.environ, PYTHONPATH=str(cwd / "src"), PYTHONDONTWRITEBYTECODE="1")
git_bash = Path(r"C:\Program Files\Git\bin")
if (git_bash / "bash.exe").is_file():
    env["PATH"] = str(git_bash) + os.pathsep + env.get("PATH", "")
for token in ("GH_TOKEN", "GITHUB_TOKEN", "GITHUB_ENTERPRISE_TOKEN", "GH_ENTERPRISE_TOKEN"):
    env.pop(token, None)
if a.label in {"candidate-fullsuite", "diagnose-long-temp", "candidate-fullsuite-r2", "candidate-fullsuite-r3", "diagnose-short-temp"}:
    spec = importlib.util.spec_from_file_location("trusted_replay", cwd / "tools/replay_pju_action.py")
    replay = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(replay)
    if a.label in {"candidate-fullsuite-r2", "candidate-fullsuite-r3", "diagnose-short-temp"}:
        temporary = Path(tempfile.gettempdir()) / ("cw566-f86a-r3" if a.label.endswith("r3") else "cw566-f86a-r2")
    else:
        temporary = (out if a.label == "candidate-fullsuite" else out.parent / "candidate-fullsuite") / "environment"
    temporary.mkdir(exist_ok=True)
    env = replay.clean_environment(Path(sys.executable), Path(r"C:\Program Files\Git\cmd\git.exe"),
                                   git_bash / "bash.exe", temporary)
    env["PYTHONPATH"] = str(cwd / "src")
    env["PYTHONDONTWRITEBYTECODE"] = "1"
def git(*args):
    return subprocess.run(["git", *args], cwd=cwd, capture_output=True, check=True).stdout
start = datetime.now(timezone.utc).isoformat()
head = git("rev-parse", "HEAD").decode().strip()
diff = git("diff", "HEAD", "--binary")
(out / "source.diff").write_bytes(diff)
paths = git("ls-files", "-c", "-o", "--exclude-standard", "-z").decode("utf-8").split("\0")
hashes = {name: hashlib.sha256((cwd / name).read_bytes()).hexdigest()
          for name in sorted(set(paths)) if name and (cwd / name).is_file()}
manifest = json.dumps(hashes, sort_keys=True, indent=2).encode("utf-8")
(out / "input-hashes.json").write_bytes(manifest)
(out / "git-status.txt").write_bytes(git("status", "--short"))
with (out / "stdout.bin").open("wb") as stdout, (out / "stderr.bin").open("wb") as stderr:
    result = subprocess.run(a.command, cwd=cwd, env=env, stdout=stdout, stderr=stderr)
after_hashes = {name: hashlib.sha256((cwd / name).read_bytes()).hexdigest()
                for name in hashes if (cwd / name).is_file()}
record = {"label": a.label, "host": socket.gethostname(), "provenance": "HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL",
          "platform": platform.platform(), "python": sys.version, "executable": sys.executable,
          "source_sha": head, "source_diff_sha256": hashlib.sha256(diff).hexdigest(),
          "input_manifest_sha256": hashlib.sha256(manifest).hexdigest(),
          "process_env": {k: env.get(k) for k in ("PYTHONPATH", "PYTHONDONTWRITEBYTECODE", "PATH")},
          "source_files_unchanged": hashes == after_hashes,
          "changed_source_files": [name for name in hashes if hashes[name] != after_hashes.get(name)],
          "cwd": str(cwd), "command": a.command, "started_utc": start,
          "ended_utc": datetime.now(timezone.utc).isoformat(), "exit_code": result.returncode}
(out / "receipt.json").write_text(json.dumps(record, indent=2), encoding="utf-8")
print(json.dumps(record, indent=2))
print((out / "stdout.bin").read_bytes().decode("utf-8", errors="backslashreplace")[-4500:].encode("ascii", errors="backslashreplace").decode("ascii"))
print((out / "stderr.bin").read_bytes().decode("utf-8", errors="backslashreplace")[-1500:].encode("ascii", errors="backslashreplace").decode("ascii"))
sys.exit(result.returncode)
