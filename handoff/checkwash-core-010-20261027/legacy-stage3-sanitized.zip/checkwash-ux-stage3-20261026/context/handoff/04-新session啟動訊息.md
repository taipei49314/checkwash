# 可貼給新 session 的訊息

模型與模式由 Nelson 在 UI 選 GPT-6.1 sol／ultra／Code。以下是供人類貼上的任務文字；本檔本身不會啟動工作或授權發布。

---

請接手 CheckWash 的體驗問題修復。交接包在：

`C:\Users\nelson\Documents\Codex\2026-10-26\new-chat\outputs\checkwash-next-session-handoff-20261026\00-START-HERE.md`

先依現行 AGENTS 讀 STATE，確認遠端來源、工作樹與 r65 發版暫停狀態，再按交接包閱讀順序工作。原始分析已保存為包內 evidence/wf-result.json；CONFIRMED 多半是靜態核對，請逐項建立最小重現、正常控制與可追蹤收據。

本 session 可以在獨立分支實作、測試不改受保護裁決或 frozen 契約的窄修，一次一個 named defect，依倉內流程準備可審查的提交／PR。優先處理 registered gitlink、quality CRLF／Python 3.11 junction、輸出與 ledger 診斷，同時提早重現 rename／oracle 逃逸，避免遺漏重要問題。需要變更受保護政策或 fingerprint 契約的項目，先完成具體提案與證據再請我決定，其他互不相依的修復繼續。

PJU 是已獲授權的預設執行主機，不再問位置，也不要調查離線 pool；按現行 POLICY 記實際 hostname／SHA／runtime／原始收據。這不解除 r65 發版暫停、不復活 consumed grant、不授權新的付費或模型評測／標註批次。

不要先 bump 0.9.2。請以修復範圍與相容性證據判斷 0.9.2 或 0.10.0。保留既有 v0.9.1 tag 與失敗收據，分別比較公開 v0.9.0 與未公開 v0.9.1。重構成本、optional 分類及比較先導是獨立後續工作，本輪不直接實作或開跑。不要恢復 automation、合併、tag、發布或改下游 pin；完成候選與驗證方案後由我另行決定發布。

第一個里程碑請交付：固定基線、逐項重現台帳、已完成窄修及回歸結果、待政策裁決項目、版本建議。不要只回報計畫；在上述範圍內持續完成可做的修復。

---

