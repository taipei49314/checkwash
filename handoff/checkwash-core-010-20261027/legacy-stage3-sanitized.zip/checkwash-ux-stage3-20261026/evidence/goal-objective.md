# Active goal objective

持續推進 CheckWash UX 與剩餘核心缺陷修復，沿用草稿 PR #566、固定候選 9a5a27f44c895ba2fdee8c83a6313baf0e120873 與兩批已保全證據。以既有授權直接完成可獨立實作的窄修、逐項最小重現與正常控制、相容性及適用驗證、原始收據和獨立審查，提交可審查的候選並更新逐項台帳。對 policy shadowing、相對 TASK 路徑、rename/oracle 等涉及受保護裁決或 frozen 契約的項目，完成精確差異、正反例、預期影響與成本／殘餘界線；僅按明確核可的具體範圍實作，不將本 goal 視為 blanket policy 授權。PJU 是已授權預設主機，不重問位置、不調查離線 pool，真實標記 HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL，未跑記 NOT_RUN。保全第一批 f86aabbb、第二批 9a5a27f4、既有 v0.9.1 tag 及失敗收據；r65 發布暫停持續有效。不自行合併、bump、tag、發布、改下游 pin、恢復 automation，或啟動未核可的歷史／付費模型／標註批次。以完成可驗收修復候選與具體剩餘決策包為目標，不以再擴寫泛泛規劃取代實作。

This is the objective captured before the final completion audit; it does not grant additional protected or publication authority.
