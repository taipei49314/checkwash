"""Preserve prior inert packet and pin the immutable native evidence bytes."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import platform

HERE = Path(__file__).resolve().parent
DEST = HERE/'revision-ir3'
assert not DEST.exists(), 'one-time preservation must not overwrite earlier bytes'
(DEST/'original').mkdir(parents=True)
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
originals = {}
for path in HERE.iterdir():
    if path.is_file():
        raw = path.read_bytes()
        (DEST/'original'/path.name).write_bytes(raw)
        originals[path.name] = dict(sha256=hashlib.sha256(raw).hexdigest(), size=len(raw))
immutable = [HERE/name for name in ('journal.json','receipt.json','observations.json','input-manifests.json',
              'case-definitions.json','source.zip','run.py')]
for directory in ('raw','source','fixtures'):
    immutable.extend(p for p in (HERE/directory).rglob('*') if p.is_file())
manifest = {p.relative_to(HERE).as_posix(): dict(sha256=sha(p), size=p.stat().st_size) for p in immutable}
value = dict(host=platform.node(), marker='HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL',
     frozen_source='9a5a27f44c895ba2fdee8c83a6313baf0e120873', created=datetime.now(timezone.utc).isoformat(),
     native_cli_count=len(json.loads((HERE/'observations.json').read_text())),
     native_command_count=len(json.loads((HERE/'journal.json').read_text())),
     preserved_original_packet=originals, immutable_native_evidence=manifest)
(DEST/'before.json').write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(preserved=len(originals), immutable=len(manifest), cli=value['native_cli_count'], commands=value['native_command_count'])))
