"""Capture trusted text-authoring tools, then recheck all original native bytes."""
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import subprocess
import sys

HERE=Path(__file__).resolve().parent
SESSION=HERE.parents[2]
REV=HERE/'revision-ir3'
attempt=1
while (REV/('authoring-'+str(attempt))).exists():
    attempt+=1
OUT=REV/('authoring-'+str(attempt))
OUT.mkdir()
TEMP=OUT/'tmp'
TEMP.mkdir()
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path,value):
    path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8',newline='\n')

spec=importlib.util.spec_from_file_location('trusted_clean_environment',SESSION/'work/trusted/replay_pju_action.py')
trusted=importlib.util.module_from_spec(spec)
spec.loader.exec_module(trusted)
env=trusted.clean_environment(Path(sys.executable),Path(r'C:\Program Files\Git\cmd\git.exe'),
                              Path(r'C:\Program Files\Git\bin\bash.exe'),TEMP)
commands=[]
for name in ('prepare_packet.py','prepare_contract_patch.py','prepare_consumer_patch.py','summarize.py','audit_packet.py'):
    argv=[sys.executable,'-I','-B','-X','utf8',str(HERE/name)]
    start=datetime.now(timezone.utc).isoformat()
    p=subprocess.run(argv,cwd=SESSION,env=env,stdin=subprocess.DEVNULL,capture_output=True,timeout=150)
    (OUT/(name+'.stdout')).write_bytes(p.stdout)
    (OUT/(name+'.stderr')).write_bytes(p.stderr)
    commands.append(dict(command=argv,script_sha256=sha(HERE/name),begin=start,end=datetime.now(timezone.utc).isoformat(),
        exit_code=p.returncode,stdout_sha256=hashlib.sha256(p.stdout).hexdigest(),stderr_sha256=hashlib.sha256(p.stderr).hexdigest()))
    save(OUT/'commands.json',commands)
    assert p.returncode==0,(name,p.stderr.decode('utf-8','replace'))

before=json.loads((REV/'before.json').read_text())
for name,meta in before['immutable_native_evidence'].items():
    p=HERE/name
    assert p.stat().st_size==meta['size'] and sha(p)==meta['sha256'],name
for name,meta in before['preserved_original_packet'].items():
    assert sha(REV/'original'/name)==meta['sha256'],name

git=Path(r'C:\Program Files\Git\cmd\git.exe')
repo=SESSION/'work/checkwash-ux'
head=subprocess.run([str(git),'-C',str(repo),'rev-parse','HEAD'],check=True,capture_output=True,env=env).stdout.decode().strip()
delta=subprocess.run([str(git),'-C',str(repo),'diff','--name-only',
    '9a5a27f44c895ba2fdee8c83a6313baf0e120873',head,'--','src','tools','tests','action','pyproject.toml'],
    check=True,capture_output=True,env=env).stdout
assert delta==b'', 'runtime/tool/test/action source differs from the frozen object'
status=subprocess.run([str(git),'-C',str(repo),'status','--porcelain'],check=True,capture_output=True,env=env).stdout
packet_names=['implementation.patch','patch-manifest.json','protected-contract.patch','protected-contract-manifest.json',
    'consumer-migration.patch','consumer-migration-manifest.json','PROTECTED-SPEC-DRAFT.md','PROTECTED-DECISIONS-DRAFT.md',
    'IR3-MIGRATION.md','summary.json','report.md','movements.json','audit.json','prepare_packet.py',
    'prepare_contract_patch.py','prepare_consumer_patch.py','summarize.py','audit_packet.py','finish_ir3_revision.py']
completion=dict(marker='HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL',hostname=platform.node(),runtime=sys.version,
    executable=sys.executable,original_source='9a5a27f44c895ba2fdee8c83a6313baf0e120873',observed_current_head=head,
    runtime_tool_test_action_blobs_same_as_original=True,current_product_status=status.decode(),
    original_cli_calls=before['native_cli_count'],original_command_count=before['native_command_count'],
    immutable_native_files_checked=len(before['immutable_native_evidence']),immutable_native_files_unchanged=True,
    preserved_original_packet_files=len(before['preserved_original_packet']),
    original_ir_version=2,proposed_ir_version=3,findings_version=2,
    proposed_proof_slot_required=True,future_controls='NOT_EXECUTED',product_calls_in_revision=0,
    patch_applied=False,modified_source_imported=False,modified_source_compiled=False,modified_judge_executed=False,
    packet_hashes={name:sha(HERE/name) for name in packet_names},
    preservation_manifest_sha256=sha(REV/'before.json'),static_authoring_receipts=str(OUT.relative_to(HERE)),
    finished=datetime.now(timezone.utc).isoformat())
save(REV/'completion.json',completion)
print(json.dumps(dict(complete=True,immutable_files=len(before['immutable_native_evidence']),
    product_calls=0,packet_hashes={n:completion['packet_hashes'][n] for n in ('implementation.patch','protected-contract.patch','consumer-migration.patch')})))
