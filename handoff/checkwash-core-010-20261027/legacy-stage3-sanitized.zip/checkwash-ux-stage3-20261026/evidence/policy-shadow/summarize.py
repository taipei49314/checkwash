"""Read receipts and author a bounded decision report; imports no judge."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
def read(name):
    return json.loads((HERE / name).read_text(encoding='utf-8'))
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
obs, receipt, ledger = read('observations.json'), read('receipt.json'), read('journal.json')
assert len(obs) == receipt['cli_calls'] == 24 and receipt['cases'] == 12
assert receipt['source_unchanged'] and receipt['product_clean']
assert not receipt['fixture_programs_executed'] and not receipt['modified_judge_executed']
by_case = {}
for row in obs:
    raw_name = row['raw_name']
    command = next(c for c in ledger if c['name'] == raw_name)
    stdout = HERE / 'raw' / (raw_name + '.stdout')
    stderr = HERE / 'raw' / (raw_name + '.stderr')
    assert sha(stdout) == command['stdout_sha256'] and sha(stderr) == command['stderr_sha256']
    assert json.loads(stdout.read_bytes()) == row['payload']
    assert command['exit'] == row['exit']
    assert row['payload']['checkwash_findings_version'] == 2
    assert row['payload']['config_errors'] == [] and row['payload']['skipped_files'] == []
    assert row['exit'] == (0 if row['payload']['verdict'] == 'pass' else 1)
    by_case.setdefault(row['case'], []).append(row)

seed = by_case['00-seed'][0]['payload']['findings']
keys = {f['rule']: f['fingerprint'] for f in seed}
for rows in by_case.values():
    for row in rows:
        for f in row['payload']['findings']:
            if f['rule'] in keys:
                assert f['fingerprint'] == keys[f['rule']], 'seed approval identity drift'

forecast = {
'00-seed': ('unchanged: A+B high/BLOCK in both worktree/range; exact finding fingerprints unchanged', 'No policy path changes; seed captures real A/B keys used in later fixtures.'),
'01-strict-to-loose': ('policy-review warn/PASS → critical/META/BLOCK; GUARDRAIL key moves', 'BASE block→pass_with_warning weakens the actual config/allow parse-error handling policy. The followup is ordinary test weakening, not a measured parse-error counterfactual.'),
'02-equivalent-migration': ('policy-review critical/BLOCK → warn/GUARDRAIL_CREATED/PASS; GUARDRAIL key moves', 'Legitimate identical-policy copy retaining the legacy file becomes nonblocking. Full copy-plus-delete or Git rename is outside this patch and untested.'),
'03-tightened-migration': ('policy-review critical/BLOCK → warn/GUARDRAIL_CREATED/PASS; GUARDRAIL key moves', 'New disabled set is a strict subset of the effective BASE set. B stays intentionally disabled; A remains enabled and blocks in next-base.'),
'04-fresh-relaxation': ('unchanged critical/META/BLOCK; GUARDRAIL key unchanged', 'No effective BASE config exists; original defaults comparison catches the first disabled detector.'),
'05-empty-base': ('unchanged warn/GUARDRAIL_CREATED/PASS severity/verdict; GUARDRAIL key moves', 'An existing zero-byte legacy config is present, distinct from None. New empty priority config is equivalent; provenance binds the empty BASE bytes.'),
'06-inactive-lower-config': ('unchanged critical/META/BLOCK; GUARDRAIL key unchanged', 'Adding lower-priority legacy config does not displace an existing priority config. The conservative existing creation cost is deliberately not repaired.'),
'07-config-independent-allow': ('policy-review warn/PASS → critical/META/BLOCK; GUARDRAIL key moves', 'Config shadow is the real relaxation; allow selection remains the independent legacy ledger. Next-base A remains allowlisted; B remains high.'),
'08-equivalent-allow': ('policy-review EXEMPTION_ADDED warn → no finding; PASS remains PASS', 'A was already approved in the effective BASE ledger; equivalent migration adds no entry. Duplicate EXEMPTION_ADDED key disappears rather than being translated.'),
'09-replaced-allow': ('policy-review EXEMPTION_ADDED warn/PASS → GUARDRAIL critical/META/BLOCK; new GUARDRAIL key', 'Replacing A with B is not append-only. Actual next-base A no longer matches and B matches. The proposal retains protected ledger-rewrite cost even when revocation tightens one rule.'),
'10-empty-allow': ('policy-review zero findings/PASS → GUARDRAIL critical/META/BLOCK; new GUARDRAIL key', 'A new zero-byte priority ledger hides a nonempty BASE ledger. Revocation is protected maintenance under §6, even though future findings become stricter.'),
'11-allow-independent-config': ('policy-review two EXEMPTION_ADDED warnings → one warning for B; PASS remains PASS; retained B key unchanged', 'Compare the effective A ledger to A+B: only B is appended. Existing priority config still disables B; next-base A is allowlisted, giving PASS. Config and allow do not share a directory-presence switch.'),
}
movements = []
lines = []
for name, rows in sorted(by_case.items()):
    first, second = rows
    current = ', '.join(f["rule"] + ':' + f['severity'] + ('[allowed]' if f['allowlisted'] else '')
                        for f in first['payload']['findings']) or 'none'
    after = ', '.join(f["rule"] + ':' + f['severity'] + ('[allowed]' if f['allowlisted'] else '')
                      for f in second['payload']['findings']) or 'none'
    lines.append(f'| {name} | {current}; {first["payload"]["verdict"]}/{first["exit"]} | {after}; {second["payload"]["verdict"]}/{second["exit"]} |')
    movement, cost = forecast[name]
    movements.append(dict(case=name, current_first=first, current_second=second,
        proposed_judge_status='NOT_EXECUTED', proposed_first_movement=movement,
        proposed_second_movement='Expected unchanged finding dicts/verdict/exit; NOT_EXECUTED (IR version changes independently).',
        cost_or_boundary=cost, proposed_new_fingerprints='NOT_COMPUTED_NOT_OBSERVED'))

for movement in movements:
    movement['proposed_path_spelling_contract'] = 'Engine lexical backslash-to-slash rule before policy classification; API alias-parity controls NOT_EXECUTED, not part of native24.'

(HERE / 'movements.json').write_text(json.dumps(movements, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
passes = sum(row['exit'] == 0 for row in obs)
summary = dict(source_sha=receipt['source_sha'], marker=receipt['marker'], cases=12, cli_calls=24,
    completed=24, pass_observations=passes, block_observations=24-passes, engine_errors=0,
    config_error_observations=0, skipped_file_observations=0, source_unchanged=True,
    fixture_programs_executed=False, modified_judge_executed=False,
    readonly_raw_hashes_verified=True, seed_fingerprints=keys,
    findings_schema=2, actual_version=obs[0]['payload']['run']['checkwash_version'],
    receipt_sha256=sha(HERE/'receipt.json'), observations_sha256=sha(HERE/'observations.json'),
    implementation_patch_raw_sha256=sha(HERE/'implementation.patch'),
    protected_patch_raw_sha256=sha(HERE/'protected-contract.patch'),
    consumer_migration_patch_raw_sha256=sha(HERE/'consumer-migration.patch'),
    required_ir3_proof_slot=True, future_consumer_migrations='NOT_EXECUTED',
    backslash_counterexample='SOURCE_LEVEL_PREVIOUS_INERT_PATCH_NOT_EXECUTED',
    added_backslash_api_controls='NOT_EXECUTED_NOT_NATIVE_CLI25',
    generated=datetime.now(timezone.utc).isoformat())
(HERE / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8', newline='\n')
report = f'''# Policy-shadow decision packet — current judge measured; proposal inert

Source `{receipt['source_sha']}`. {receipt['marker']}. Actual host `{receipt['hostname']}`; Python `{receipt['python'].splitlines()[0]}`; runtime `{receipt['executable']}`. Run control source, raw command/exit receipts and exact inputs are adjacent. No fixture Python, proposed module, modified judge, model call or history sweep was executed.

12 native cases completed exactly 24/24 CheckWash CLI invocations, the fixed cap. {passes} PASS observations and {24-passes} BLOCK observations describe current behavior, not correctness labels. Zero engine errors, zero config_errors and zero skipped_files in these runs. Both source archive byte identities and clean product HEAD were verified before and after. All commands use trusted clean_environment with owned empty HOME/TEMP, -I -B, bytecode off and pinned GREENWASH_TODAY=2026-10-26. Git commands create/read only owned fixture repositories or read the frozen product; their raw receipts are also preserved.

Each non-seed control first reviews only the policy creation with BASE policy, then commits that policy in the **fixture only**, and reviews the same two adjacent real weakenings against the new BASE. A fixture commit after a BLOCK is setup for measuring future policy, never an acceptance or a product commit. The seed first measures both real findings, then measures their committed range; its real keys supply the allow entries. Per-case manifests are sealed immediately before each CLI, with file hashes checked unchanged afterwards. Seed-derived ledger contents are explicit in case-definitions.json, not retrospectively invented expected outputs.

| Case | Current policy review (seed: worktree) | Current next BASE (seed: range) |
|---|---|---|
{chr(10).join(lines)}

A is EXPECTED_VALUE_CHANGED at tests/test_total.py/test_total; B is ASSERT_WEAKENED at tests/test_bound.py/test_bound. Full actual finding dictionaries (including complete v2 keys, unit, evidence, allowlisted flags, escalators and deescalators) are in observations.json and the raw JSON stdout. Every emitted A/B key equals its measured seed identity. Allowlisted findings are retained at warn, as the table shows; they were not counted as absent. The seed A key is `{keys['EXPECTED_VALUE_CHANGED']}`; B is `{keys['ASSERT_WEAKENED']}`.

The named defect is the physical-file versus effective-policy mismatch. _created_config_loosens compares a new path with defaults, while read_base_config_file already selects the existing legacy file by filename. _classify_allowlist_change likewise compares new priority bytes with an absent physical path. This accounts for the observed strict-to-loose warn/PASS, identical and tightened migrations critical/BLOCK, replacement-ledger warn/PASS and hidden-ledger zero findings/PASS. The config branch here concerns config/allow parse errors; generic engine errors retain their separate exit2/hook behavior. No measured old-error→new-error handling outcome is claimed.

The proposed main decision is in PROTECTED-SPEC-DRAFT.md / PROTECTED-DECISIONS-DRAFT.md. implementation.patch is exact against the frozen source and is **INERT: NOT_APPLIED / NOT_IMPORTED / NOT_COMPILED / NOT_EXECUTED**. protected-contract.patch is an external human decision draft against the exact frozen SPEC/DECISIONS Git blobs, with its top declaration consistently Spec3 / IR3 / findings2. consumer-migration.patch gives exact external validator/adapter/schema-test/documentation changes; IR3-MIGRATION.md lists precise target behavior, old-IR2 handling and mandatory unrun controls. No protected product byte or existing fixture expectation changed.

The patch compares only a newly winning priority creation with an existing selected legacy BASE predecessor, with raw byte/path provenance passed from the CLI/sweep reads that already occur. It does not replace the BASE config or exemptions used to judge the current diff, change read admission, or infer a shared directory preference. Config comparison admits equal roles, a subset disable set, no threshold rise and no block→pass_with_warning change; differences it cannot establish stay critical. Ledger comparison uses the same effective BASE parsed prefix and preserves the deliberate critical cost of rewrites/revocations. An equal ledger adds no exemption; A→A+B adds B only. Inactive lower-priority behavior stays unchanged. Creation-to-defaults logic is retained only outside this bounded shadow case and is not claimed as the repair.

Per-control future movements and costs are in movements.json: **all are NOT_EXECUTED**, with no calculated or observed new fingerprint masquerading as a receipt. Expected material shifts include config false blocks→warn, actual relaxation warn→critical, ledger replacements/empty shadows→critical, equivalent-ledger warnings removed and append warnings restricted to the true suffix. Next-base A/B behavior is forecast unchanged because BASE lookup/exemptions remain unchanged by the proposal. Existing current observations are never replaced with these forecasts.

This is a frozen-contract decision, not a 0.9.x UX change. docs/stability.md freezes severity/config semantics and same-minor exemption matching. Shadow GUARDRAIL keys must bind the selected BASE path/digest and transition kind; existing approvals need re-review. The candidate targets a separately authorized next minor, provisionally 0.10.0. IR_VERSION3 follows the decision that globals.policy_shadows is a **required proof slot**, present even when empty, not a general claim that optional shape additions need a bump. Findings envelope2 and its object field set stay unchanged. IR2 remains historical IR2 without inferred proof; no historical byte is upgraded or rewritten. The inert version text does not authorize a real bump or release. Direct build_ir/analyze callers creating priority policy without relevant PolicyBase provenance refuse with EngineError instead of assuming absence. Exact API adapters use explicit BASE before declarations and retain head-only policy as unknown by filename; only a relevant new priority creation refuses. Test-only cases and the other filename's creation retain admission. Config()/allow_entries=[] fixture semantics remain, and case_snapshot's AFTER contents never become authority. Current-source collector requires IR3/map; the historical comparator retains IR2 and every typed schema delta. The external diffs are authored, but migration/qualification is **NOT_EXECUTED**.

Remaining boundaries and costs: role-table changes/value warnings/TOML parse errors are conservative shadow guards; existing loader exceptions remain errors. A→empty allow is a tightening yet remains protected revocation under §6. Copy-plus-delete and Git-detected rename migration retain existing critical maintenance cost. Existing BASE role overrides that exclude guardrails, malformed/ignored allow records, simultaneous changes to both ledgers sharing one historical ledger_path, and inactive-file false blocks remain unresolved. Only seed has worktree/range parity here; hook, all other range combinations, malformed-policy counterfactuals, CLI fail_on overrides, missing-provenance direct API behavior, symlink/nonregular paths, cross-platform behavior, cost rates, wheels/pyz and release collectors are NOT_RUN. The budget is exhausted; it was not expanded.

Adoption requires explicit protected-policy/minor-interface decisions, independent review and separately authorized implementation/qualification. New regressions may be added; existing corpus/golden labels must not be rewritten to force acceptance. No suite, post-patch PASS, historical sweep, 283-case source qualification, wheel/pyz qualification, merge or publication is claimed. r65 publication remains paused.

Receipt hashes: observations `{summary['observations_sha256']}`; implementation patch raw `{summary['implementation_patch_raw_sha256']}`; protected draft patch raw `{summary['protected_patch_raw_sha256']}`. Raw filenames, complete argv/cwd/UTC timestamps/stdout/stderr/exit and hashes are in journal.json; full source hashes/hostname/runtime/owned environment keys are in receipt.json. Actual source/input bytes remain inspectable in source/, fixtures/, source.zip, case-definitions.json and input-manifests.json.

IR3 correction: pre-correction packet bytes/hashes are retained under revision-ir3/original and before.json. Original 24 CLI / 186 commands / raw/source/fixture files are immutable and rechecked in revision-ir3/completion.json; this correction adds no product call. Consumer patch raw `{summary['consumer_migration_patch_raw_sha256']}`. No old verdict, golden/corpus expected label or IR2 receipt was modified.

Subsequent static correction: independent source review found the previous inert helper compared raw backslash paths after the engine had normalized them. The external helper now uses the engine's identical lexical slash spelling before membership/name/suffix tests; explicit BASE paths and mapping/case keys follow that same rule. Ambiguous aliases stay unknown by filename, with refusal only for a related new priority creation. STATIC-BACKSLASH-CORRECTION.md describes the source-level counterexample, exact correction and new FileChange-keyword API controls. All added controls are NOT_EXECUTED, not an observed finding/fingerprint or CLI25. The already-reviewed protected IR3 contract is unchanged. Current derived hashes and preserved pre-correction packet are recorded in revision-backslash/before.json and completion.json; the original native24/186 records remain unchanged.
'''
(HERE / 'report.md').write_text(report, encoding='utf-8', newline='\n')
print(json.dumps(summary, indent=2))
