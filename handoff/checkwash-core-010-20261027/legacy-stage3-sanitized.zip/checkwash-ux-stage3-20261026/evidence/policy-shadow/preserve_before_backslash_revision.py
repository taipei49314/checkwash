"""One-time byte preservation before the static backslash correction."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import platform

HERE = Path(__file__).resolve().parent
DEST = HERE/'revision-backslash'
assert not DEST.exists()
(DEST/'original').mkdir(parents=True)
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
native = json.loads((HERE/'revision-ir3/before.json').read_text())
for name, meta in native['immutable_native_evidence'].items():
    p = HERE/name
    assert digest(p) == meta['sha256'] and p.stat().st_size == meta['size'], name
preserved = {}
for p in HERE.iterdir():
    if p.is_file():
        raw = p.read_bytes()
        (DEST/'original'/p.name).write_bytes(raw)
        preserved[p.name] = dict(sha256=hashlib.sha256(raw).hexdigest(), size=len(raw))
for name in ('completion.json','before.json'):
    p = HERE/'revision-ir3'/name
    raw = p.read_bytes()
    (DEST/'original'/('ir3-'+name)).write_bytes(raw)
    preserved['ir3-'+name] = dict(sha256=hashlib.sha256(raw).hexdigest(),size=len(raw))
value = dict(hostname=platform.node(),marker='HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL',
    created=datetime.now(timezone.utc).isoformat(),
    native_manifest='revision-ir3/before.json',native_manifest_sha256=digest(HERE/'revision-ir3/before.json'),
    native_files_verified=len(native['immutable_native_evidence']),native_cli_calls=24,native_commands=186,
    preserved_packet=preserved)
(DEST/'before.json').write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(preserved_packet_files=len(preserved),native_files_verified=value['native_files_verified'])))
