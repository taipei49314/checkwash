"""Author only inert IR3 consumer diffs from frozen Git text; imports no product."""
import difflib
import hashlib
import json
from pathlib import Path
import re
import subprocess

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2]/'work/checkwash-ux'
SHA = '9a5a27f44c895ba2fdee8c83a6313baf0e120873'
changes = {}
def frozen(name):
    return subprocess.run([r'C:\Program Files\Git\cmd\git.exe','-C',str(REPO),'show',SHA+':'+name],
                          check=True,capture_output=True,timeout=30).stdout.decode('utf-8')
def replace(name, old, new, count=1):
    before, after = changes.get(name, (None, None))
    if before is None:
        before = after = frozen(name)
    assert after.count(old) == count, (name, after.count(old), old)
    changes[name] = before, after.replace(old, new)

# Keep the provisional inert next-minor metadata consistent with __version__;
# this does not touch actual release metadata, tags, advertised pins or files.
replace('pyproject.toml', 'version = "0.9.1"', 'version = "0.10.0"')

validator = '''def _valid_policy_shadows(ir):
    """IR3 requires a typed proof slot; IR2 never receives an inferred one."""
    globals_ = ir.get("globals")
    if not isinstance(globals_, dict) or not isinstance(globals_.get("policy_shadows"), dict):
        return False
    predecessors = {".checkwash/config.toml": ".greenwash/config.toml",
                    ".checkwash/allow.toml": ".greenwash/allow.toml"}
    kinds = {".checkwash/config.toml": {"config_relaxation", "config_nonweakening", "config_uncomparable"},
             ".checkwash/allow.toml": {"allow_append", "allow_rewrite"}}
    for path, proof in globals_["policy_shadows"].items():
        if (path not in predecessors or not isinstance(proof, dict)
                or set(proof) != {"base_path", "base_sha256", "kind"}):
            return False
        if (proof["base_path"] != predecessors[path]
                or not isinstance(proof["base_sha256"], str)
                or re.fullmatch(r"[0-9a-f]{64}", proof["base_sha256"]) is None
                or not isinstance(proof["kind"], str) or proof["kind"] not in kinds[path]):
            return False
    return True


'''
replace('tools/corpus_artifacts.py', 'def validate_payload(data, names):', validator+'def validate_payload(data, names):')
replace('tools/corpus_artifacts.py', '''        require(ir.get("version") == 2 and isinstance(ir.get("files"), list)
                and isinstance(ir.get("globals"), dict), f"invalid IR envelope for {name}")''',
'''        require(type(ir.get("version")) is int and ir["version"] == 3
                and isinstance(ir.get("files"), list) and _valid_policy_shadows(ir),
                f"invalid IR3 envelope or required policy proof slot for {name}")''')
replace('tests/test_corpus_artifacts.py', 'def payload(names=None, *, label="before"):',
        'def payload(names=None, *, label="before", ir_version=3, policy_shadows=None):')
replace('tests/test_corpus_artifacts.py', '    ir = {"version": 2, "base": label, "head": "after", "files": [], "globals": {}}',
'''    globals_ = {"policy_shadows": policy_shadows or {}} if ir_version == 3 else {}
    ir = {"version": ir_version, "base": label, "head": "after", "files": [], "globals": globals_}''')
replace('tests/test_corpus_artifacts.py', '''data.replace(b'"version": 2', b'"version": 2, "version": 2')''',
        '''data.replace(b'"version": 3', b'"version": 3, "version": 3')''')
test_additions = '''

def test_current_collector_rejects_historical_ir2_without_rewriting_it():
    old = payload(ir_version=2)
    original = bytes(old)
    with pytest.raises(ValueError, match="IR3"):
        ARTIFACTS.validate_payload(old, context()["case_names"])
    assert old == original


@pytest.mark.parametrize("replacement", [b'null', b'[]', b'"unknown"'])
def test_ir3_requires_its_proof_slot_even_when_no_shadow_is_reported(replacement):
    data = payload().replace(b'"policy_shadows": {}', b'"policy_shadows": ' + replacement)
    with pytest.raises(ValueError, match="IR3"):
        ARTIFACTS.validate_payload(data, context()["case_names"])
    missing = payload().replace(b'"policy_shadows": {}', b'"unrelated": {}')
    with pytest.raises(ValueError, match="IR3"):
        ARTIFACTS.validate_payload(missing, context()["case_names"])


def test_ir3_proof_has_only_fixed_paths_digest_and_transition_kind():
    proof = {"base_path": ".greenwash/config.toml", "base_sha256": "a" * 64,
             "kind": "config_nonweakening"}
    data = payload(policy_shadows={".checkwash/config.toml": proof})
    ARTIFACTS.validate_payload(data, context()["case_names"])
    for broken in ({**proof, "base_path": "/external/secret"},
                   {**proof, "base_sha256": "short"}, {**proof, "kind": []},
                   {**proof, "kind": "allow_rewrite"}, {**proof, "extra": "value"}):
        with pytest.raises(ValueError, match="IR3"):
            ARTIFACTS.validate_payload(payload(policy_shadows={".checkwash/config.toml": broken}),
                                       context()["case_names"])
'''
before, after = changes['tests/test_corpus_artifacts.py']
changes['tests/test_corpus_artifacts.py'] = before, after+test_additions
replace('tests/test_fingerprint_scope.py', '    assert IR_VERSION == FINDINGS_VERSION == ir.version == 2',
        '    assert IR_VERSION == ir.version == 3\n    assert FINDINGS_VERSION == 2\n    assert to_jsonable(ir.globals)["policy_shadows"] == {}')

# Full-corpus and case-backed adapters receive explicit BASE provenance;
# their existing Config()/[] semantics and fixture expectations are untouched.
case_adapters = ['tools/emit_corpus.py','src/checkwash/demo.py','tests/test_cases_runner.py',
                 'tests/test_demo_command.py','tests/test_determinism.py','tests/test_detector_coverage.py',
                 'tests/test_findings_schema.py','tests/test_expected_value_definition.py',
                 'tests/test_param_row_expectations.py','tests/test_finding_shape.py',
                 'tests/test_snapshot_inventory_adapters.py']
adapter_counts = {}
for name in case_adapters:
    before = frozen(name)
    after = before.replace('from checkwash.cases import ', 'from checkwash.cases import case_policy_base, ', 1)
    assert after != before
    after, count = re.subn(r'(?m)^([ ]*)root_reader=snapshot\.get,',
        r'\1policy_base=case_policy_base(case),\n\1root_reader=snapshot.get,', after)
    assert count > 0, name
    changes[name] = before, after
    adapter_counts[name] = count
replace('tools/assertion_contract.py', '    from checkwash.engine import FileChange, analyze\n',
        '    from checkwash.engine import FileChange, analyze\n    from checkwash.policy_shadow import PolicyBase\n')
replace('tools/assertion_contract.py', '        Config(), Contract(), [], datetime.date(2026, 9, 23),\n',
        '        Config(), Contract(), [], datetime.date(2026, 9, 23),\n        policy_base=PolicyBase.from_mapping({case["path"]: case["before"].encode("utf-8")}),\n')
replace('tools/reliability_r1_trace.py', '    from checkwash.engine import analyze\n',
        '    from checkwash.engine import analyze\n    from checkwash.policy_shadow import PolicyBase\n')
replace('tools/reliability_r1_trace.py', '        known_modules={"app"}, self_modules={"app"},\n',
        '        known_modules={"app"}, self_modules={"app"},\n        policy_base=PolicyBase.from_mapping(before),\n')

# Keep every existing IR2 historical synthetic artifact unchanged by default.
replace('tests/test_release_compatibility_record.py',
        'def artifact(version="0.3.3", *, names=("a.gwcase",), optional=False, verdict="pass"):',
        'def artifact(version="0.3.3", *, names=("a.gwcase",), optional=False, verdict="pass", ir_version=2, proof=None):')
replace('tests/test_release_compatibility_record.py',
        '        ir = {"version": 2, "files": [], "globals": {"optional": False} if optional else {}}',
'''        globals_ = {"optional": False} if optional else {}
        if proof is not None:
            globals_["policy_shadows"] = proof
        ir = {"version": ir_version, "files": [], "globals": globals_}''')
before, after = changes['tests/test_release_compatibility_record.py']
changes['tests/test_release_compatibility_record.py'] = before, after+'''


def test_ir2_to_ir3_transition_keeps_required_proof_and_version_deltas_explicit():
    old = artifact()
    outputs = {"baseline": old, "candidate": artifact("0.10.0", ir_version=3, proof={})}
    parsed, deltas = compare.transition_deltas(outputs)
    assert outputs["baseline"] == old
    assert parsed["baseline"]["a.gwcase"]["ir"]["version"] == 2
    assert "policy_shadows" not in parsed["baseline"]["a.gwcase"]["ir"]["globals"]
    paths = {(d["artifact"], d["path"]): d for d in deltas}
    assert paths[("ir", "/version")]["before"] == {"present": True, "value": 2}
    assert paths[("ir", "/version")]["after"] == {"present": True, "value": 3}
    assert paths[("ir", "/globals/policy_shadows")]["before"] == {"present": False}
    assert paths[("ir", "/globals/policy_shadows")]["after"] == {"present": True, "value": {}}
    assert len(paths) == 3  # IR version, required proof slot, package version.
'''

new_tests = '''"""IR3 adapter controls. No fixture program is imported or executed."""
import datetime
import pytest

from checkwash import IR_VERSION, FINDINGS_VERSION
from checkwash.cases import Case, case_policy_base, case_to_changes
from checkwash.change import EngineError, FileChange
from checkwash.config import Config
from checkwash.contract import Contract
from checkwash.engine import analyze
from checkwash.ir.model import IR, to_jsonable
from checkwash.policy_shadow import PolicyBase


def test_new_ir3_always_serializes_the_required_slot_even_when_empty():
    ir = to_jsonable(IR("base", "head"))
    assert IR_VERSION == ir["version"] == 3 and FINDINGS_VERSION == 2
    assert ir["globals"]["policy_shadows"] == {}


def test_base_mapping_selection_is_per_filename_and_preserves_empty_priority():
    base = PolicyBase.from_mapping({".checkwash/config.toml": b"",
        ".greenwash/config.toml": b'[gate]\\non_engine_error="block"\\n',
        ".greenwash/allow.toml": b"# legacy ledger"})
    assert (base.config_path, base.config_data) == (".checkwash/config.toml", b"")
    assert (base.allow_path, base.allow_data) == (".greenwash/allow.toml", b"# legacy ledger")


def test_case_head_priority_addition_does_not_replace_explicit_legacy_base():
    case = Case(before={".greenwash/config.toml": '[gate]\\non_engine_error="block"\\n'},
                after={".checkwash/config.toml": '[gate]\\non_engine_error="pass_with_warning"\\n'})
    base = case_policy_base(case)
    assert base.config_path == ".greenwash/config.toml"
    assert b'"block"' in base.config_data
    assert base.allow_data is None


def test_case_head_only_policy_context_is_never_inferred_as_base_or_allowance():
    case = Case(after={".checkwash/allow.toml": ""},
                head={".greenwash/allow.toml": "# HEAD alone is not BASE proof"})
    with pytest.raises(EngineError, match="HEAD-only"):
        case_policy_base(case)


def test_test_only_case_with_head_ledger_keeps_its_original_api_admission():
    case = Case(before={"tests/test_x.py": "def test_x():\\n    assert 1 == 1\\n"},
                after={"tests/test_x.py": "def test_x():\\n    assert True\\n"},
                head={".greenwash/allow.toml": "# irrelevant unknown policy context"})
    base = case_policy_base(case)
    assert "allow.toml" not in base.known_names
    ir, _findings, _verdict = analyze(case_to_changes(case), Config(), Contract(), [],
                                    datetime.date(2026, 1, 1), policy_base=base)
    assert ir.version == 3


@pytest.mark.parametrize("name,unrelated", [("config.toml", "allow.toml"), ("allow.toml", "config.toml")])
def test_new_priority_only_needs_its_own_filename_base_provenance(name, unrelated):
    case = Case(after={f".checkwash/{name}": ""}, head={f".greenwash/{unrelated}": "# unknown"})
    base = case_policy_base(case)
    assert name in base.known_names and unrelated not in base.known_names
    ir, _findings, _verdict = analyze(case_to_changes(case), Config(), Contract(), [],
                                    datetime.date(2026, 1, 1), policy_base=base)
    assert ir.version == 3


def test_case_after_only_priority_file_has_explicit_absent_base_provenance():
    base = case_policy_base(Case(after={".checkwash/config.toml": ""}))
    assert base.config_data is None and base.allow_data is None


def test_direct_priority_creation_without_base_context_refuses_instead_of_guessing():
    change = FileChange(".checkwash/config.toml", "added", None, b"")
    with pytest.raises(EngineError, match="BASE policy provenance"):
        analyze([change], Config(), Contract(), [], datetime.date(2026, 1, 1))
'''
changes['tests/test_policy_shadow_ir3_consumers.py'] = '', new_tests

replace('docs/stability.md', 'installations retain their broad keys. IR and findings versions are 2 since\nv0.3.0 and 1 in v0.2.13.',
        'installations retain their broad keys. IR and findings versions became 2 in\nv0.3.0 and were 1 in v0.2.13. The separately proposed policy-shadow minor\nrequires IR3 proof (`globals.policy_shadows`, present even when empty);\nfindings remains 2.')
replace('docs/stability.md', 'IR and findings versions stay 2. The\n',
        'Those changes alone keep IR/findings versions 2; the separately proposed\npolicy-shadow minor moves IR to 3 and keeps findings at 2. The\n')
replace('docs/stability.md', 'v0.2.13** and **2 since v0.3.0**. The envelope keys\n',
        'v0.2.13** and became **2 in v0.3.0**. The proposed policy-shadow minor\nuses IR3 with a required policy proof slot and findings2 unchanged. Historical\nIR2 remains IR2 without an inferred empty proof. The envelope keys\n')
replace('docs/stability.md', 'key on `version` inside the payload, not on field order.\n',
'''key on `version` inside the payload, not on field order.
The proposed IR3 requires `globals.policy_shadows` as a map in every payload,
even when empty. Its keys are winning `.checkwash/config.toml` or
`.checkwash/allow.toml`; each entry requires exactly `base_path` (the matching
legacy filename), `base_sha256` (64 lowercase hexadecimal characters) and
`kind` (the bounded config/ledger transition enum in SPEC §6). Missing or
invalid IR3 proof is an unsupported document, not no shadow. An old IR2
document has no newly trusted proof; keep its original bytes and version.
An IR2-only consumer refuses IR3 until explicitly migrated, rather than
silently discarding this required meaning. See embedding.md's IR guidance.
''')
replace('docs/stability.md', 'A shape change bumps the number; see the pre-rename compatibility note below.',
        'A required-key or existing-field contract change bumps the affected number; optional additions follow the rules below. See the pre-rename compatibility note below.')
replace('docs/embedding.md', '## Check the document\n',
'''## IR payloads (proposed policy-shadow minor)

The findings envelope stays version2; `--emit-ir` is a separate IR3 document.
Select the decoder from the payload's `version`, never the package string.
An IR3 decoder requires the `globals.policy_shadows` proof map, even if empty,
and validates the fixed paths, digest and transition kind in stability.md.
An IR2-only consumer must refuse IR3, while a historical reader keeps IR2 as
IR2 with no shadow-proof assertion. Do not insert an empty map, relabel old
documents or reserialize old receipts to make them look current. Config and
exemptions remain BASE-side; fixture HEAD context never grants authority.

## Check the document
''')
before = frozen('docs/remediation-upgrade.md')
changes['docs/remediation-upgrade.md'] = before, before+'''

## Proposed policy-shadow minor: IR3, findings2

The earlier version2 migration above is historical and remains unchanged.
The proposed policy-shadow minor adds a required IR3 proof slot at
`globals.policy_shadows`, present even when empty, and keeps findings2.
Upgrade IR decoders and current-source artifact validators explicitly;
keep old IR2 evidence and its pinned reader unchanged. A missing IR3 slot
refuses rather than being treated as no shadow. Re-review the moved shadow
GUARDRAIL approvals; there is no mechanical approval translation. Publication
and this protected policy proposal require separate maintainer decisions.
'''

patch = ''.join(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),
                     fromfile='a/'+name if before else '/dev/null',tofile='b/'+name))
                for name,(before,after) in sorted(changes.items()))
dest=HERE/'consumer-migration.patch'
dest.write_text(patch,encoding='utf-8',newline='\n')
manifest=dict(source_sha=SHA,status='INERT_NOT_APPLIED_NOT_IMPORTED_NOT_COMPILED_NOT_EXECUTED',
    raw_sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),case_adapter_calls=adapter_counts,
    files={name:dict(before_sha256=hashlib.sha256(before.encode()).hexdigest() if before else None,
                    after_text_sha256=hashlib.sha256(after.encode()).hexdigest())
           for name,(before,after) in sorted(changes.items())})
(HERE/'consumer-migration-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(inert_consumer_files=len(changes),adapters=adapter_counts,raw_sha256=manifest['raw_sha256'])))
