"""Bounded native CURRENT-judge controls. Never execute fixture source or a proposal."""
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import zipfile

HERE = Path(__file__).resolve().parent
SESSION = HERE.parents[2]
REPO = SESSION / 'work/checkwash-ux'
EXPECTED = '9a5a27f44c895ba2fdee8c83a6313baf0e120873'
SOURCE = HERE / 'source'
GIT = Path(r'C:\Program Files\Git\cmd\git.exe')
BASH = Path(r'C:\Program Files\Git\bin\bash.exe')
MARKER = 'HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL'
assert sys.argv[1:] == [EXPECTED]
assert platform.node() == 'LAPTOP-01AGNPJU'
assert not (HERE / 'receipt.json').exists() and not SOURCE.exists()

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def save(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2, sort_keys=True) + '\n', encoding='utf-8')

spec = importlib.util.spec_from_file_location('trusted_pju_environment', SESSION / 'work/trusted/replay_pju_action.py')
trusted = importlib.util.module_from_spec(spec)
spec.loader.exec_module(trusted)
temp = HERE / 'tmp'
temp.mkdir()
env = trusted.clean_environment(Path(sys.executable), GIT, BASH, temp)
env['GREENWASH_TODAY'] = '2026-10-26'
env['GIT_AUTHOR_NAME'] = env['GIT_COMMITTER_NAME'] = 'Static Control'
env['GIT_AUTHOR_EMAIL'] = env['GIT_COMMITTER_EMAIL'] = 'static@example.invalid'
env['GIT_AUTHOR_DATE'] = env['GIT_COMMITTER_DATE'] = '2026-10-26T00:00:00+00:00'
(HERE / 'raw').mkdir()
journal = []

def run(argv, cwd, name):
    begin = datetime.now(timezone.utc).isoformat()
    proc = subprocess.run([str(arg) for arg in argv], cwd=cwd, env=env, stdin=subprocess.DEVNULL,
                          capture_output=True, timeout=100)
    (HERE / 'raw' / (name + '.stdout')).write_bytes(proc.stdout)
    (HERE / 'raw' / (name + '.stderr')).write_bytes(proc.stderr)
    journal.append(dict(name=name, command=[str(a) for a in argv], cwd=str(cwd), begin=begin,
                        end=datetime.now(timezone.utc).isoformat(), exit=proc.returncode,
                        stdout_sha256=sha(proc.stdout), stderr_sha256=sha(proc.stderr)))
    save(HERE / 'journal.json', journal)
    return proc

git_sequence = 0
def git(repo, *args):
    global git_sequence
    git_sequence += 1
    p = run([GIT, '-c', 'core.hooksPath=NUL', '-c', 'core.autocrlf=false', '-c', 'core.fsmonitor=false',
             '-C', repo, *args], HERE, 'git-' + str(git_sequence).zfill(3))
    assert p.returncode == 0, p.stderr.decode('utf-8', 'replace')
    return p.stdout

assert git(REPO, 'rev-parse', 'HEAD').decode().strip() == EXPECTED
assert git(REPO, 'status', '--porcelain') == b''
archive = git(REPO, 'archive', '--format=zip', EXPECTED, 'src')
(HERE / 'source.zip').write_bytes(archive)
import io
with zipfile.ZipFile(io.BytesIO(archive)) as z:
    z.extractall(SOURCE)
tree = git(REPO, 'ls-tree', '-r', '-z', EXPECTED, '--', 'src')
expected_blobs = {}
for row in tree.split(b'\0'):
    if row:
        metadata, path = row.split(b'\t', 1)
        mode, kind, oid = metadata.split()
        assert mode in (b'100644', b'100755') and kind == b'blob'
        expected_blobs[path.decode()] = oid.decode()

def source_hashes():
    files = {p.relative_to(SOURCE).as_posix(): p.read_bytes() for p in (SOURCE / 'src').rglob('*') if p.is_file()}
    assert files.keys() == expected_blobs.keys()
    for path, raw in files.items():
        assert hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == expected_blobs[path]
    return {path: sha(raw) for path, raw in files.items()}

source_before = source_hashes()
A_BEFORE = 'from product import value\n\ndef test_total():\n    assert value() == 78.75\n'
A_AFTER = 'from product import value\n\ndef test_total():\n    assert value() == 75\n'
B_BEFORE = 'from product import value\n\ndef test_bound():\n    assert value() > 0\n'
B_AFTER = 'from product import value\n\ndef test_bound():\n    assert value()\n'
BASE_FILES = {'tests/test_total.py': A_BEFORE, 'tests/test_bound.py': B_BEFORE,
              'product.py': 'def value():\n    return 78.75\n'}
weak_files = {'tests/test_total.py': A_AFTER, 'tests/test_bound.py': B_AFTER}
inputs = {}
observations = []
cli_count = 0
bootstrap = f'import sys;sys.path.insert(0,{str(SOURCE / "src")!r});from checkwash.cli import main;raise SystemExit(main())'

def put(repo, files):
    for name, text in files.items():
        p = repo / name
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(text.encode('utf-8'))

def manifest(repo):
    return {p.relative_to(repo).as_posix(): sha(p.read_bytes()) for p in repo.rglob('*')
            if p.is_file() and '.git' not in p.relative_to(repo).parts}

def commit(repo, label):
    git(repo, 'add', '-A')
    git(repo, 'commit', '-m', label)
    return git(repo, 'rev-parse', 'HEAD').decode().strip()

def check(name, repo, phase, extra=()):
    global cli_count
    assert cli_count < 24
    cli_count += 1
    key = name + '/' + phase
    fixed = dict(files=manifest(repo), head=git(repo, 'rev-parse', 'HEAD').decode().strip(),
                 diff_sha256=sha(git(repo, 'diff', 'HEAD')), status_sha256=sha(git(repo, 'status', '--porcelain')))
    inputs[key] = fixed
    save(HERE / 'input-manifests.json', inputs)
    p = run([sys.executable, '-I', '-B', '-X', 'utf8', '-c', bootstrap, 'check', *extra,
             '--repo', repo, '--format', 'json'], HERE, 'cli-' + str(cli_count).zfill(2) + '-' + name + '-' + phase)
    assert manifest(repo) == fixed['files'], 'fixture source changed during static analysis'
    try:
        payload = json.loads(p.stdout)
    except (ValueError, UnicodeDecodeError):
        payload = None
    row = dict(case=name, phase=phase, cli_number=cli_count, exit=p.returncode, payload=payload,
               raw_name=journal[-1]['name'], input_manifest_sha256=sha(json.dumps(fixed, sort_keys=True).encode()))
    observations.append(row)
    save(HERE / 'observations.json', observations)
    return row

def setup(name, base_policy):
    repo = HERE / 'fixtures' / name
    repo.mkdir(parents=True)
    git(repo, 'init', '-q')
    put(repo, {**BASE_FILES, **base_policy})
    return repo, commit(repo, 'base')

# The seed is an actual frozen-judge observation, not an invented allow key.
seed, seed_base = setup('00-seed', {})
put(seed, weak_files)
seed_obs = check('00-seed', seed, 'worktree')
seed_head = commit(seed, 'static weakening seed')
check('00-seed', seed, 'range', [seed_base + '..' + seed_head])
findings = seed_obs['payload']['findings']
A = next(f for f in findings if f['rule'] == 'EXPECTED_VALUE_CHANGED')['fingerprint']
B = next(f for f in findings if f['rule'] == 'ASSERT_WEAKENED')['fingerprint']

def allow(*pairs):
    return ''.join('[[allow]]\nfingerprint = ' + json.dumps(fp) + '\nrule = ' + json.dumps(rule) +
                   '\nreason = "static control approval"\nauthor = "fixture"\ncreated = "2026-10-26"\nexpires = "2026-11-26"\n'
                   for fp, rule in pairs)

allow_a = allow((A, 'EXPECTED_VALUE_CHANGED'))
allow_b = allow((B, 'ASSERT_WEAKENED'))
allow_ab = allow((A, 'EXPECTED_VALUE_CHANGED'), (B, 'ASSERT_WEAKENED'))
strict_error = '[gate]\non_engine_error = "block"\n'
loose_error = '[gate]\non_engine_error = "pass_with_warning"\n'
disabled_b = '[detectors]\ndisable = ["ASSERT_WEAKENED"]\n'
disabled_b_removed = '[detectors]\ndisable = ["ASSERT_WEAKENED", "ASSERT_REMOVED"]\n'
CASES = [
 ('01-strict-to-loose', {'.greenwash/config.toml': strict_error}, {'.checkwash/config.toml': loose_error}),
 ('02-equivalent-migration', {'.greenwash/config.toml': disabled_b}, {'.checkwash/config.toml': disabled_b}),
 ('03-tightened-migration', {'.greenwash/config.toml': disabled_b_removed}, {'.checkwash/config.toml': disabled_b}),
 ('04-fresh-relaxation', {}, {'.checkwash/config.toml': disabled_b}),
 ('05-empty-base', {'.greenwash/config.toml': ''}, {'.checkwash/config.toml': ''}),
 ('06-inactive-lower-config', {'.checkwash/config.toml': strict_error}, {'.greenwash/config.toml': disabled_b}),
 ('07-config-independent-allow', {'.greenwash/config.toml': strict_error, '.greenwash/allow.toml': allow_a},
                                 {'.checkwash/config.toml': loose_error}),
 ('08-equivalent-allow', {'.greenwash/allow.toml': allow_a}, {'.checkwash/allow.toml': allow_a}),
 ('09-replaced-allow', {'.greenwash/allow.toml': allow_a}, {'.checkwash/allow.toml': allow_b}),
 ('10-empty-allow', {'.greenwash/allow.toml': allow_a}, {'.checkwash/allow.toml': ''}),
 ('11-allow-independent-config', {'.checkwash/config.toml': disabled_b, '.greenwash/allow.toml': allow_a},
                                {'.checkwash/allow.toml': allow_ab}),
]
save(HERE / 'case-definitions.json', dict(seed=dict(before=BASE_FILES, after=weak_files),
    allow_keys=dict(A=A, B=B), cases=[dict(name=n, base=b, head_edit=h, followup_edit=weak_files) for n,b,h in CASES],
    methodology='The first seed observation supplies real fingerprints to later sealed fixture inputs; all later cases were predeclared in this fixed runner.'))
for name, baseline, delta in CASES:
    repo, _ = setup(name, baseline)
    put(repo, delta)
    check(name, repo, 'policy-review')
    # Fixture commits do not assert that CheckWash approved the preceding policy.
    commit(repo, 'candidate policy for next-base observation only')
    put(repo, weak_files)
    check(name, repo, 'next-base')

assert cli_count == len(observations) == 24
assert git(REPO, 'rev-parse', 'HEAD').decode().strip() == EXPECTED
assert git(REPO, 'status', '--porcelain') == b''
source_after = source_hashes()
assert source_after == source_before
save(HERE / 'receipt.json', dict(marker=MARKER, hostname=platform.node(), python=sys.version,
     executable=sys.executable, source_sha=EXPECTED, source_archive_sha256=sha(archive),
     source_files=source_before, source_unchanged=True, product_clean=True, cli_calls=cli_count,
     cases=12, environment_keys=sorted(env), environment_helper_sha256=sha(Path(spec.origin).read_bytes()),
     runner_sha256=sha(Path(__file__).read_bytes()), input_manifests_sha256=sha((HERE/'input-manifests.json').read_bytes()),
     fixture_programs_executed=False, modified_judge_executed=False, finished=datetime.now(timezone.utc).isoformat()))
print(json.dumps(dict(cli_calls=cli_count, cases=12, completed=True, marker=MARKER)))
