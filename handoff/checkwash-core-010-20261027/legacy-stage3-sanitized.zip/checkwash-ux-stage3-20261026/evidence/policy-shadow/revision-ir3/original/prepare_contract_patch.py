"""Inert protected text diff, read directly from the frozen Git object."""
import difflib
import hashlib
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2] / 'work/checkwash-ux'
SHA = '9a5a27f44c895ba2fdee8c83a6313baf0e120873'
GIT = r'C:\Program Files\Git\cmd\git.exe'
def frozen(name):
    return subprocess.run([GIT, '-C', str(REPO), 'show', SHA + ':' + name], check=True,
                          stdin=subprocess.DEVNULL, capture_output=True, timeout=30).stdout

spec_raw, decisions_raw = frozen('SPEC.md'), frozen('DECISIONS.md')
spec, decisions = spec_raw.decode('utf-8'), decisions_raw.decode('utf-8')
rows = spec.splitlines(True)
hits = [i for i, text in enumerate(rows) if text.startswith('| `GUARDRAIL_TOUCHED` |')]
assert len(hits) == 1
rows[hits[0]] = rows[hits[0]].rstrip('\n')[:-1] + (' Next-minor policy-shadow exception: a newly winning '
    '`.checkwash/config.toml` over an existing selected BASE `.greenwash/config.toml` compares '
    'against that effective BASE policy, not defaults; see §6 policy-shadow transitions. |\n')
body = (HERE / 'PROTECTED-SPEC-DRAFT.md').read_text(encoding='utf-8')
body = body[body.index('Proposed replacement/addition'):]
new_spec = ''.join(rows).replace('## 6. Exemptions\n', '## 6. Exemptions\n\n### Policy-shadow transitions (next minor, proposed)\n\n' + body + '\n', 1)
assert new_spec != spec
new_decisions = decisions + '\n\n' + (HERE / 'PROTECTED-DECISIONS-DRAFT.md').read_text(encoding='utf-8')
changes = {'SPEC.md': (spec_raw, spec, new_spec), 'DECISIONS.md': (decisions_raw, decisions, new_decisions)}
patch = ''.join(''.join(difflib.unified_diff(old.splitlines(True), new.splitlines(True),
                    fromfile='a/' + name, tofile='b/' + name))
                for name, (_raw, old, new) in changes.items())
dest = HERE / 'protected-contract.patch'
dest.write_text(patch, encoding='utf-8', newline='\n')
(HERE / 'protected-contract-manifest.json').write_text(json.dumps(dict(
    source_sha=SHA, status='INERT_HUMAN_DECISION_DRAFT_NOT_APPLIED',
    patch_raw_sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),
    files={name: dict(before_git_blob=hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest(),
                     before_raw_sha256=hashlib.sha256(raw).hexdigest(),
                     after_text_sha256=hashlib.sha256(new.encode()).hexdigest())
           for name, (raw, _old, new) in changes.items()}), indent=2) + '\n', encoding='utf-8', newline='\n')
print('protected diff authored outside checkout; not applied')
