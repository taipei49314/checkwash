"""Create an inert diff from frozen text; do not apply, import or compile it."""
import difflib
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
SOURCE = HERE / 'source'
changes = {}

def replace(path, old, new, count=1):
    before, after = changes.get(path, (None, None))
    if before is None:
        before = (SOURCE / path).read_text(encoding='utf-8')
        after = before
    assert after.count(old) == count, (path, after.count(old), old)
    changes[path] = (before, after.replace(old, new))

module = '''"""Effective BASE policy for newly winning priority-file creations.

This is policy provenance, never a replacement for the BASE configuration
or exemptions used to judge the diff. No HEAD file is loaded as authority.
"""
from dataclasses import dataclass
import hashlib

from checkwash.change import EngineError
from checkwash.config import SEVERITY_ORDER, load_config


@dataclass(frozen=True)
class PolicyBase:
    config_path: str = ".greenwash/config.toml"
    config_data: bytes | None = None
    allow_path: str = ".greenwash/allow.toml"
    allow_data: bytes | None = None


def shadow_baseline(change, policy_base):
    """A new winning priority file's selected BASE predecessor, or None.

    Inactive lower-priority creations, ordinary edits, deletes and renames
    keep their old treatment. Empty bytes are an existing policy file.
    """
    if change.before is not None or change.after is None:
        return None
    if change.path not in (".checkwash/config.toml", ".checkwash/allow.toml"):
        return None
    if policy_base is None:
        raise EngineError("priority policy creation needs selected BASE policy provenance")
    config = change.path.endswith("/config.toml")
    path = policy_base.config_path if config else policy_base.allow_path
    data = policy_base.config_data if config else policy_base.allow_data
    expected = ".greenwash/config.toml" if config else ".greenwash/allow.toml"
    if path != expected or data is None:
        return None
    return data, {"base_path": path, "base_sha256": hashlib.sha256(data).hexdigest()}


def config_transition(before, after):
    """A bounded partial order; incomparable role changes remain guarded."""
    old, old_error, old_warnings = load_config(before)
    new, new_error, new_warnings = load_config(after)
    if old_error or new_error or old_warnings or new_warnings or old.roles != new.roles:
        return "config_uncomparable"
    if (not set(new.disabled_detectors).issubset(old.disabled_detectors)
            or SEVERITY_ORDER[new.fail_on] > SEVERITY_ORDER[old.fail_on]
            or (old.on_engine_error == "block" and new.on_engine_error != "block")):
        return "config_relaxation"
    return "config_nonweakening"
'''
changes['src/checkwash/policy_shadow.py'] = ('', module)
replace('src/checkwash/cli.py', 'from checkwash.engine import analyze',
        'from checkwash.policy_shadow import PolicyBase\nfrom checkwash.engine import analyze')
replace('src/checkwash/cli.py', '        pytest_configs=pytest_configs,\n    )\n    return _Run',
        '        pytest_configs=pytest_configs,\n        policy_base=PolicyBase(config_path, config_data, allow_path, allow_data),\n    )\n    return _Run')
replace('src/checkwash/sweep.py', 'from checkwash.engine import analyze',
        'from checkwash.policy_shadow import PolicyBase\nfrom checkwash.engine import analyze')
replace('src/checkwash/sweep.py', '                pytest_configs=pytest_configs,\n            )',
        '                pytest_configs=pytest_configs,\n                policy_base=PolicyBase(config_path, config_data, allow_path, allow_data),\n            )')
replace('src/checkwash/engine.py', 'from checkwash.config import Config',
        'from checkwash.config import Config\nfrom checkwash.policy_shadow import config_transition, shadow_baseline')
replace('src/checkwash/engine.py', '    pytest_configs=None,\n) -> IR:',
        '    pytest_configs=None,\n    policy_base=None,\n) -> IR:')
replace('src/checkwash/engine.py', '    pytest_configs=None,\n) -> tuple[IR, list[Finding], str]:',
        '    pytest_configs=None,\n    policy_base=None,\n) -> tuple[IR, list[Finding], str]:')
replace('src/checkwash/engine.py', '        pytest_configs=pytest_configs,\n    )\n    findings = run_detectors',
        '        pytest_configs=pytest_configs,\n        policy_base=policy_base,\n    )\n    findings = run_detectors')
replace('src/checkwash/engine.py', '''        elif role == "guardrail":
            if path in (".checkwash/allow.toml", ".greenwash/allow.toml"):
                appended = _classify_allowlist_change(change.before, change.after)
                if appended is not None:
                    g.exemptions_added.extend(appended)
                    g.exemption_ledger_path = path
                else:
                    g.guardrail_files_changed.append(path)
            else:
                g.guardrail_files_changed.append(path)
            if not change.before:
                g.guardrail_files_created.append(path)
                if path in _OWN_CONFIG_PATHS and _created_config_loosens(change.after):
                    g.guardrail_configs_created_loosening.append(path)
''', '''        elif role == "guardrail":
            shadow = shadow_baseline(change, policy_base)
            if path in (".checkwash/allow.toml", ".greenwash/allow.toml"):
                before_policy = shadow[0] if shadow is not None else change.before
                appended = _classify_allowlist_change(before_policy, change.after)
                if shadow is not None:
                    g.policy_shadows[path] = {
                        **shadow[1], "kind": "allow_append" if appended is not None else "allow_rewrite",
                    }
                if appended is not None:
                    g.exemptions_added.extend(appended)
                    g.exemption_ledger_path = path
                else:
                    g.guardrail_files_changed.append(path)
            else:
                g.guardrail_files_changed.append(path)
                if shadow is not None:
                    g.policy_shadows[path] = {
                        **shadow[1], "kind": config_transition(shadow[0], change.after),
                    }
            if not change.before:
                g.guardrail_files_created.append(path)
                if shadow is None and path in _OWN_CONFIG_PATHS and _created_config_loosens(change.after):
                    g.guardrail_configs_created_loosening.append(path)
''')
replace('src/checkwash/ir/model.py', '    scope_allow: list[str] = field(default_factory=list)  # contract globs ([] = SCOPE_DRIFT off)',
        '    policy_shadows: dict[str, dict[str, str]] = field(default_factory=dict)  # winning priority file -> selected BASE path/digest and transition kind\n    scope_allow: list[str] = field(default_factory=list)  # contract globs ([] = SCOPE_DRIFT off)')
replace('src/checkwash/gating.py', '                if created and not loosening:\n',
        '                shadow_kind = ir.globals.policy_shadows.get(f.path, {}).get("kind")\n                shadow_guarded = shadow_kind in {"config_relaxation", "config_uncomparable", "allow_rewrite"}\n                if created and not loosening and not shadow_guarded:\n')
replace('src/checkwash/detectors/globals_rules.py', 'def _guardrail_message(ir: IR, path: str) -> str:\n',
        '''def _guardrail_message(ir: IR, path: str) -> str:
    shadow = ir.globals.policy_shadows.get(path)
    if shadow is not None:
        descriptions = {
            "config_relaxation": "relaxes the effective BASE policy",
            "config_uncomparable": "changes policy whose nonweakening cannot be established",
            "config_nonweakening": "preserves or tightens the effective BASE policy",
            "allow_rewrite": "rewrites or revokes the effective BASE exemption ledger",
        }
        return (f"guardrail file created ({path}) shadows {shadow['base_path']}: "
                + descriptions[shadow["kind"]])
''')
replace('src/checkwash/detectors/globals_rules.py', '                    "created_loosening": path in ir.globals.guardrail_configs_created_loosening,\n',
        '                    "created_loosening": path in ir.globals.guardrail_configs_created_loosening,\n                    **({"policy_shadow": ir.globals.policy_shadows[path]} if path in ir.globals.policy_shadows else {}),\n')
replace('src/checkwash/__init__.py', 'IR_VERSION = 2', 'IR_VERSION = 3')
replace('src/checkwash/__init__.py', '__version__ = "0.9.1"', '__version__ = "0.10.0"')

patch = ''
manifest = {}
for name, (before, after) in sorted(changes.items()):
    patch += ''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True),
                       fromfile='a/' + name if before else '/dev/null', tofile='b/' + name))
    manifest[name] = dict(before_sha256=hashlib.sha256(before.encode()).hexdigest() if before else None,
                          after_text_sha256=hashlib.sha256(after.encode()).hexdigest())
(HERE / 'implementation.patch').write_text(patch, encoding='utf-8', newline='\n')
(HERE / 'patch-manifest.json').write_text(json.dumps(dict(source_sha='9a5a27f44c895ba2fdee8c83a6313baf0e120873',
     mode='INERT_NOT_APPLIED_NOT_IMPORTED_NOT_COMPILED_NOT_EXECUTED', files=manifest,
     patch_sha256=hashlib.sha256(patch.encode()).hexdigest()), indent=2) + '\n', encoding='utf-8')
print('inert patch written; no modified module imported, compiled or executed')
