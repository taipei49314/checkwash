"""Read-only text/receipt audit. Does not reconstruct or execute the proposed source."""
import hashlib
import json
from pathlib import Path
import re
import subprocess

HERE = Path(__file__).resolve().parent
SESSION = HERE.parents[2]
SOURCE = HERE / 'source'
SHA = '9a5a27f44c895ba2fdee8c83a6313baf0e120873'
def digest(raw):
    return hashlib.sha256(raw).hexdigest()
def read(name):
    return json.loads((HERE / name).read_text(encoding='utf-8'))

patches = {}
for name in ('implementation.patch', 'protected-contract.patch'):
    raw = (HERE / name).read_bytes()
    assert b'\r' not in raw, 'raw patch must be LF, matching its text digest'
    lines = raw.decode().splitlines(True)
    i = 0
    checks = []
    while i < len(lines):
        assert lines[i].startswith('--- '), lines[i]
        old_path = lines[i][4:].strip()
        new_path = lines[i+1][4:].strip()
        assert lines[i+1].startswith('+++ ')
        member = new_path.removeprefix('b/')
        if old_path == '/dev/null':
            base = []
            assert not (SOURCE / member).exists()
        elif member.startswith('src/'):
            base = (SOURCE / member).read_text(encoding='utf-8').splitlines(True)
        else:
            proc = subprocess.run([r'C:\Program Files\Git\cmd\git.exe', '-C', str(SESSION/'work/checkwash-ux'),
                                   'show', SHA + ':' + member], check=True, capture_output=True, timeout=30)
            base = proc.stdout.decode().splitlines(True)
        i += 2
        hunks = 0
        while i < len(lines) and not lines[i].startswith('--- '):
            match = re.fullmatch(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@\n', lines[i])
            assert match, lines[i]
            start = int(match[1]); count = int(match[2] or 1)
            new_count = int(match[4] or 1)
            i += 1; old_rows = []; new_rows_count = 0
            while i < len(lines) and not lines[i].startswith(('@@ ', '--- ')):
                line = lines[i]
                assert line[:1] in {' ', '+', '-'}
                if line[:1] in {' ', '-'}:
                    old_rows.append(line[1:])
                if line[:1] in {' ', '+'}:
                    new_rows_count += 1
                i += 1
            assert len(old_rows) == count and new_rows_count == new_count
            assert old_rows == base[max(0, start-1):max(0, start-1)+count], member
            hunks += 1
        checks.append(dict(file=member, old_hunks_match_frozen_source=True, hunks=hunks))
    patches[name] = dict(raw_sha256=digest(raw), files=checks)

manifest = read('patch-manifest.json')
assert patches['implementation.patch']['raw_sha256'] == manifest['patch_sha256']
assert patches['protected-contract.patch']['raw_sha256'] == read('protected-contract-manifest.json')['patch_raw_sha256']
assert read('summary.json')['implementation_patch_raw_sha256'] == manifest['patch_sha256']

prior = SESSION / 'work/remaining-probes'
prior_paths = [prior/'manifest.json', prior/'policy-shadow-check.stdout', prior/'policy-shadow-check.stderr',
               prior/'policy-shadow/.greenwash/config.toml', prior/'policy-shadow/.checkwash/config.toml']
prior_hashes = {p.relative_to(SESSION).as_posix(): digest(p.read_bytes()) for p in prior_paths}
audit = dict(source_sha=SHA, mode='READ_ONLY_NO_PATCH_APPLY_OR_JUDGE_EXECUTION', patches=patches,
             all_existing_hunks_match=True, prior_evidence_readonly_hashes=prior_hashes,
             summary_raw_sha256=digest((HERE/'summary.json').read_bytes()),
             report_raw_sha256=digest((HERE/'report.md').read_bytes()),
             controls_complete=read('summary.json')['completed'], cli_budget_exhausted=True)
(HERE/'audit.json').write_text(json.dumps(audit, indent=2)+'\n', encoding='utf-8', newline='\n')
print(json.dumps(dict(all_existing_hunks_match=True, controls=24, patches=patches), indent=2))
