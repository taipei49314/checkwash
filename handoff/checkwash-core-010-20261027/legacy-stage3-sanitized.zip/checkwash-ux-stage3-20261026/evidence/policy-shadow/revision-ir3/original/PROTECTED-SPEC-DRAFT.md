# INERT HUMAN DECISION DRAFT — DO NOT APPLY

Baseline: `9a5a27f44c895ba2fdee8c83a6313baf0e120873`. This is outside the product. The patch is an unexecuted implementation candidate, not an accepted judge or release authorization.

Proposed replacement/addition to SPEC §4 GUARDRAIL_TOUCHED / §5 E4:

Existing guardrail edits remain critical, except for the §6 append-only ledger case. Existing fresh-file defaults comparison remains in force when no effective BASE predecessor exists. Inactive lower-priority creations retain their existing treatment. This decision adds one bounded exception for a newly created `.checkwash/config.toml` that becomes the selected config while BASE selected an existing `.greenwash/config.toml`:

- Compare parsed policies against that selected BASE config, including an existing zero-byte config; absence is `None`, not falsey bytes.
- A new disabled-rule name, a rise in the `fail_on` severity threshold, or `on_engine_error: block` becoming `pass_with_warning` makes the new config critical.
- If both policies parse without warnings, their role tables are equal, the new disable set is a subset of the old one, its threshold does not rise, and its engine-error policy does not weaken, keep the created config at warn. This covers an equal-policy copy and a bounded tightening. No assertion about arbitrary glob-language inclusion is made.
- Parse errors, value warnings or differing role tables make this shadow transition uncomparable and critical. This is a conservative policy cost, not a proof of malicious intent. Exceptions thrown by the existing loader remain engine errors; this proposal does not replace the TOML loader.
- Config and allow precedence are resolved independently by filename. The presence of `.checkwash/config.toml` does not cause `.checkwash/allow.toml` to exist, or vice versa. Evaluation still uses selected BASE policy throughout the reviewed diff.

Proposed addition to SPEC §6:

For a newly created `.checkwash/allow.toml` that becomes selected over an existing BASE `.greenwash/allow.toml`, apply the existing parsed-entry append-only comparison against the **effective BASE ledger**, not an empty ledger at the new path. An equal ledger has no appended entries. A preserved prefix followed by new entries emits EXEMPTION_ADDED only for that suffix. A rewritten or removed existing entry, including an empty new priority file hiding a nonempty BASE ledger, is GUARDRAIL_TOUCHED critical even though the physical priority file is new. This preserves the deliberate cost that revoking an exemption is protected ledger maintenance, even when it tightens the gate. The existing permissive treatment of ignored invalid TOML records is not widened or repaired by this proposal.

Proposed addition to the fingerprint / machine contract:

GUARDRAIL_TOUCHED findings for these shadow transitions retain their content-bound v2 outer form, but their event context additionally binds the selected BASE policy's repository-relative fixed path, full SHA256 of its raw bytes, and the bounded transition kind. Their exact keys change. Physical before/after source identity remains present. No old approval is automatically translated. EXEMPTION_ADDED retains its existing key formula for actual appended entries; duplicate visibility for already-existing migrated entries disappears.

IR gains `globals.policy_shadows`, a map from the new winning path to `base_path`, `base_sha256`, and `kind`; no policy values or arbitrary target path are copied. Its shape change requires IR_VERSION 3. FINDINGS_VERSION remains 2 because its envelope and finding-object fields do not change. JSON consumer migration and IR-schema qualification are required. Exit meanings remain 0 pass, 1 block and 2 engine error.

Proposed source/API boundary:

The CLI and sweep pass the selected BASE path/raw bytes they already read. They do not add a HEAD read or broaden reader admission. Direct build_ir/analyze callers that create a priority policy file must supply explicit PolicyBase provenance, including explicit no-file provenance when BASE has neither file. An omitted context refuses with EngineError rather than assuming defaults. This is an intentional API compatibility cost requiring fixture/demo/tool adapter audit before adoption; no existing fixture label is silently rewritten. Direct API cases without such a priority creation keep their existing calls.

Out of scope: changing actual directory precedence; moving policy authority from BASE to HEAD; existing-file or Git-detected rename policy; copy-plus-delete migration that still modifies the old protected file; ordinary lower-priority creations; arbitrary role-glob ordering; HEAD-only exemptions granting authority during their own diff; multiple changed ledgers sharing the historical single exemption_ledger_path; BASE roles that already exclude policy paths; oracle findings, D2/E2/default A/B/body-hash semantics; reader admission; hook engine-error behavior.

Version: target a separately reviewed next minor, provisionally 0.10.0 after public 0.9.0. This changes frozen severity/config interpretation and GUARDRAIL fingerprints and cannot be a 0.9.x UX patch. The inert implementation shows that target version and IR3 solely to make the decision concrete. It grants no authority to edit the protected spec, severity table, expected labels, package version or release metadata. The r65 publication pause remains.
