# INERT HUMAN DECISION DRAFT — D-number unassigned

## Newly winning priority policy files compare with the effective BASE predecessor

Proposed, not accepted. Baseline `9a5a27f44c895ba2fdee8c83a6313baf0e120873`; native PJU current-judge receipts in the adjacent directory. HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL. No fixture program, model call, historical sweep or modified judge was executed.

Problem: config/allow file lookup already chooses `.checkwash/` over `.greenwash/` independently for each filename. Guardrail change classification instead compares each physical new path against its own absent before side. The config helper compares against defaults, so a BASE block-on-config-error policy can be shadowed by a newly created pass-with-warning priority config and receive only warn/PASS. Conversely, copying an unchanged disabled-detector policy, or tightening its disable set, can receive critical/BLOCK because the new file is compared against defaults. A new priority ledger can hide a different existing legacy ledger and be treated as additions to an empty ledger.

Decision candidate: only newly winning priority creations with an existing selected legacy predecessor compare against that effective BASE predecessor. Use the bounded config partial order and effective parsed-ledger prefix rules in PROTECTED-SPEC-DRAFT.md. Equal-policy config migration and provable tightening retain the normal created-file warn behavior; unknown comparisons stay guarded. Ledger rewrite/revocation remains critical under §6, including a tightening revocation. Raw BASE provenance is explicit and content-bound, without changing which policy judges this diff.

Alternatives rejected for this packet:

1. Compare every creation to defaults: this is the existing defect and cannot establish equivalence to effective policy.
2. Make all new policy files critical: it catches shadowing but preserves false blocks for identical migrations and simple tightening, and expands the fresh-empty/inactive-file cost without this bounded decision.
3. Treat the mere presence of a `.checkwash/` directory as selecting all files: contradicts independent per-filename lookup and can erase the other filename's actual BASE authority.
4. Use HEAD config/allow to judge the current diff: permits the change to authorize itself.
5. Ignore new priority ledgers or auto-translate old GUARDRAIL approvals: hides authority transitions or grants a new source context an old approval.

Compatibility: this is a frozen policy change and GUARDRAIL fingerprint movement; target the next minor (provisionally 0.10.0), with IR3 for the new globals provenance shape and findings envelope2 unchanged. Existing shadow GUARDRAIL approvals require human review, not mechanical migration. Relevant native control movements are forecasts in report.md/movements.json, explicitly NOT_EXECUTED on the patch. Current receipts are observations, not reclassified fixture labels. Config-error handling is only the existing config/allow parse-error branch; this does not claim to change or repair general engine-error handling.

Costs and residuals: conservative blocks for role-table differences, warning-bearing configurations and ledger revocation; legacy direct API callers creating priority policy now need explicit BASE provenance; copy-plus-delete and Git rename maintenance retain existing protected-file costs. Invalid schema edge cases, inactive lower-priority false blocks, multiple-ledger attribution, existing-file role/guardrail exclusions, and all modes/platforms not exercised remain separate work. No historical false-positive rate, cross-platform determinism, wheel/pyz qualification or post-patch PASS is claimed.

Adoption requires a maintainer decision on the protected SPEC/DECISIONS/severity changes, interface migration and new minor, followed by a separate authorized implementation and independent source review; new static regression fixtures without rewriting old expected outputs; current-judge versus proposed-judge controlled comparison; source/wheel/pyz and all required release qualifications; and separate release authorization. Nothing in this draft lifts the publication pause or authorizes any of those unrun stages.
