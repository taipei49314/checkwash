"""Capture only static path-correction authoring; never execute a judge."""
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import subprocess
import sys

HERE=Path(__file__).resolve().parent
SESSION=HERE.parents[2]
REV=HERE/'revision-backslash'
OUT=REV/'authoring'
assert not OUT.exists()
OUT.mkdir()
TEMP=OUT/'tmp'
TEMP.mkdir()
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path,value):
    path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8',newline='\n')
spec=importlib.util.spec_from_file_location('trusted_clean_environment',SESSION/'work/trusted/replay_pju_action.py')
trusted=importlib.util.module_from_spec(spec)
spec.loader.exec_module(trusted)
env=trusted.clean_environment(Path(sys.executable),Path(r'C:\Program Files\Git\cmd\git.exe'),
                              Path(r'C:\Program Files\Git\bin\bash.exe'),TEMP)
commands=[]
for name in ('prepare_packet.py','prepare_consumer_patch.py','summarize.py','audit_packet.py'):
    argv=[sys.executable,'-I','-B','-X','utf8',str(HERE/name)]
    start=datetime.now(timezone.utc).isoformat()
    p=subprocess.run(argv,cwd=SESSION,env=env,stdin=subprocess.DEVNULL,capture_output=True,timeout=150)
    (OUT/(name+'.stdout')).write_bytes(p.stdout)
    (OUT/(name+'.stderr')).write_bytes(p.stderr)
    commands.append(dict(command=argv,script_sha256=sha(HERE/name),begin=start,
        end=datetime.now(timezone.utc).isoformat(),exit_code=p.returncode,
        stdout_sha256=hashlib.sha256(p.stdout).hexdigest(),stderr_sha256=hashlib.sha256(p.stderr).hexdigest()))
    save(OUT/'commands.json',commands)
    assert p.returncode==0,(name,p.stderr.decode('utf-8','replace'))
before=json.loads((REV/'before.json').read_text())
native=json.loads((HERE/before['native_manifest']).read_text())
assert sha(HERE/before['native_manifest'])==before['native_manifest_sha256']
for name,meta in native['immutable_native_evidence'].items():
    path=HERE/name
    assert path.stat().st_size==meta['size'] and sha(path)==meta['sha256'],name
for name,meta in before['preserved_packet'].items():
    assert sha(REV/'original'/name)==meta['sha256'],name
assert sha(HERE/'protected-contract.patch')==before['preserved_packet']['protected-contract.patch']['sha256']
git=r'C:\Program Files\Git\cmd\git.exe'
repo=SESSION/'work/checkwash-ux'
head=subprocess.run([git,'-C',str(repo),'rev-parse','HEAD'],check=True,capture_output=True,env=env).stdout.decode().strip()
delta=subprocess.run([git,'-C',str(repo),'diff','--name-only','9a5a27f44c895ba2fdee8c83a6313baf0e120873',head,
    '--','src','tools','tests','action','pyproject.toml'],check=True,capture_output=True,env=env).stdout
assert delta==b''
status=subprocess.run([git,'-C',str(repo),'status','--porcelain'],check=True,capture_output=True,env=env).stdout.decode()
names=['implementation.patch','patch-manifest.json','consumer-migration.patch','consumer-migration-manifest.json',
    'protected-contract.patch','protected-contract-manifest.json','report.md','summary.json','movements.json','audit.json',
    'IR3-MIGRATION.md','STATIC-BACKSLASH-CORRECTION.md','static-path-normalization-audit.json','prepare_packet.py',
    'prepare_consumer_patch.py','summarize.py','audit_packet.py','finish_backslash_revision.py']
completion=dict(marker='HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL',hostname=platform.node(),runtime=sys.version,
    executable=sys.executable,source='9a5a27f44c895ba2fdee8c83a6313baf0e120873',observed_current_head=head,
    runtime_tool_test_action_blobs_same=True,current_product_status=status,
    original_native_cli_calls=24,original_native_commands=186,native_files_checked=1062,native_files_unchanged=True,
    preserved_before_packet_files=len(before['preserved_packet']),protected_contract_unchanged=True,
    product_calls_in_correction=0,modified_judge_executed=False,patch_applied=False,
    proposed_source_imported=False,proposed_source_compiled=False,
    added_api_controls='NOT_EXECUTED_NOT_NATIVE_CLI25',counterexample_kind='SOURCE_LEVEL_PREVIOUS_INERT_PATCH',
    packet_hashes={name:sha(HERE/name) for name in names},
    preservation_manifest_sha256=sha(REV/'before.json'),finished=datetime.now(timezone.utc).isoformat())
save(REV/'completion.json',completion)
print(json.dumps(dict(complete=True,product_calls=0,native_files_unchanged=1062,
    patch_hashes={name:completion['packet_hashes'][name] for name in ('implementation.patch','consumer-migration.patch','protected-contract.patch')})))
