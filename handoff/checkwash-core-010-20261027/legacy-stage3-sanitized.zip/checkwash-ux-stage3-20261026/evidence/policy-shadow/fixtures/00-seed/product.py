def value():
    return 78.75
