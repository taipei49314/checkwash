from product import value

def test_bound():
    assert value()
