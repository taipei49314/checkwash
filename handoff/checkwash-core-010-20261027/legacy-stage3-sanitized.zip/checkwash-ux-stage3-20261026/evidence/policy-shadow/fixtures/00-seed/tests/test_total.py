from product import value

def test_total():
    assert value() == 75
