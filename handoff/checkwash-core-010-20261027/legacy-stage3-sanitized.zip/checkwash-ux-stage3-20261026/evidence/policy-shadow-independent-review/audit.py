"""Read-only native-evidence and frozen-hunk audit; never build a proposed judge."""
import hashlib
import json
from pathlib import Path
import re
import socket
import subprocess
import sys
import zipfile

HERE = Path(__file__).resolve().parent
PACKET = HERE.parent / "policy-shadow"
REPO = HERE.parents[2] / "work/checkwash-ux"
BASE = "9a5a27f44c895ba2fdee8c83a6313baf0e120873"
FINAL_PATCH_HASHES = {
    "implementation.patch": "7ab91501aecaa05ed47a130d2f2d61cb27a96139a63ec1be49c138270385abdf",
    "consumer-migration.patch": "6f5458ecdfcf0651968e9fef16993faf1e26b6da2235364065c3e5656973958b",
    "protected-contract.patch": "8ad77c27e78122889a251af189a130f7f173292415868c1139d813fe5ed4e7ab",
}
def digest(raw):
    return hashlib.sha256(raw).hexdigest()
def read(name):
    return json.loads((PACKET / name).read_text(encoding="utf-8"))
def git(*args):
    return subprocess.check_output(["git", *args], cwd=REPO)

receipt, observations, journal = read("receipt.json"), read("observations.json"), read("journal.json")
summary, movements, inputs = read("summary.json"), read("movements.json"), read("input-manifests.json")
definitions = read("case-definitions.json")
assert receipt["source_sha"] == summary["source_sha"] == BASE
assert receipt["source_unchanged"] and receipt["cli_calls"] == len(observations) == 24
assert len({row["case"] for row in observations}) == 12
assert digest((PACKET / "receipt.json").read_bytes()) == summary["receipt_sha256"]
assert digest((PACKET / "observations.json").read_bytes()) == summary["observations_sha256"]
assert digest((PACKET / "input-manifests.json").read_bytes()) == receipt["input_manifests_sha256"]
assert digest((PACKET / "run.py").read_bytes()) == receipt["runner_sha256"]
command_by_name = {row["name"]: row for row in journal}
assert len(command_by_name) == len(journal)
for row in journal:
    for stream in ("stdout", "stderr"):
        assert digest((PACKET / "raw" / (row["name"] + "." + stream)).read_bytes()) == row[stream + "_sha256"], row["name"]
for row in observations:
    command = command_by_name[row["raw_name"]]
    assert command["exit"] == row["exit"]
    assert json.loads((PACKET / "raw" / (row["raw_name"] + ".stdout")).read_bytes()) == row["payload"]
    assert row["payload"]["config_errors"] == row["payload"]["skipped_files"] == []
    fixed = inputs[row["case"] + "/" + row["phase"]]
    assert digest(json.dumps(fixed, sort_keys=True).encode()) == row["input_manifest_sha256"]
    assert row["exit"] in (0, 1)
    for finding in row["payload"]["findings"]:
        if finding["rule"] in summary["seed_fingerprints"]:
            assert finding["fingerprint"] == summary["seed_fingerprints"][finding["rule"]]
assert sum(row["exit"] == 0 for row in observations) == 8
assert sum(row["exit"] == 1 for row in observations) == 16
for movement in movements:
    assert movement["current_first"] in observations and movement["current_second"] in observations
    assert movement["proposed_judge_status"] == "NOT_EXECUTED"
    assert movement["proposed_new_fingerprints"] == "NOT_COMPUTED_NOT_OBSERVED"

tree = git("ls-tree", "-r", "-z", BASE, "--", "src")
members = 0
with zipfile.ZipFile(PACKET / "source.zip") as archive:
    assert digest((PACKET / "source.zip").read_bytes()) == receipt["source_archive_sha256"]
    for record in tree.split(b"\0"):
        if not record:
            continue
        metadata, name = record.split(b"\t", 1)
        mode, kind, oid = metadata.split()
        assert kind == b"blob"
        name = name.decode()
        raw = archive.read(name)
        assert hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest().encode() == oid
        assert (PACKET / "source" / name).read_bytes() == raw
        assert digest(raw) == receipt["source_files"][name]
        assert (REPO / name).read_bytes() == raw, "working product source differs from frozen judge: " + name
        members += 1

def check_patch(name):
    raw = (PACKET / name).read_bytes()
    assert b"\r" not in raw
    lines = raw.decode().splitlines(True)
    index, checks = 0, []
    while index < len(lines):
        assert lines[index].startswith("--- ") and lines[index + 1].startswith("+++ ")
        old_path, new_path = lines[index][4:].strip(), lines[index + 1][4:].strip()
        member = new_path.removeprefix("b/")
        old = [] if old_path == "/dev/null" else git("show", BASE + ":" + member).decode().splitlines(True)
        index += 2
        hunks = []
        while index < len(lines) and not lines[index].startswith("--- "):
            match = re.fullmatch(r"@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@\n", lines[index])
            assert match
            start, count, new_start, new_count = [int(value) if value is not None else 1 for value in match.groups()]
            index += 1
            body = []
            while index < len(lines) and not lines[index].startswith(("@@ ", "--- ")):
                body.append(lines[index]); index += 1
            prior = [line[1:] for line in body if line.startswith((" ", "-"))]
            assert len(prior) == count and sum(line.startswith((" ", "+")) for line in body) == new_count
            assert old[max(0, start - 1):max(0, start - 1) + count] == prior
            hunks.append({"old_start": start, "old_count": count, "new_count": new_count, "context_matches": True})
        checks.append({"file": member, "hunks": hunks})
    return {"raw_sha256": digest(raw), "files": checks}
patches = {name: check_patch(name) for name in ("implementation.patch", "protected-contract.patch", "consumer-migration.patch")}
assert {name: value["raw_sha256"] for name, value in patches.items()} == FINAL_PATCH_HASHES
assert patches["implementation.patch"]["raw_sha256"] == read("patch-manifest.json")["patch_sha256"] == summary["implementation_patch_raw_sha256"]
assert patches["protected-contract.patch"]["raw_sha256"] == read("protected-contract-manifest.json")["patch_raw_sha256"] == summary["protected_patch_raw_sha256"]
assert patches["consumer-migration.patch"]["raw_sha256"] == read("consumer-migration-manifest.json")["raw_sha256"]
revision = PACKET / "revision-ir3"
before_revision = json.loads((revision / "before.json").read_text())
completion = json.loads((revision / "completion.json").read_text())
path_revision = PACKET / "revision-backslash"
path_before = json.loads((path_revision / "before.json").read_text())
path_completion = json.loads((path_revision / "completion.json").read_text())
for name, meta in before_revision["immutable_native_evidence"].items():
    raw = (PACKET / name).read_bytes()
    assert len(raw) == meta["size"] and digest(raw) == meta["sha256"], name
for name, meta in before_revision["preserved_original_packet"].items():
    assert digest((revision / "original" / name).read_bytes()) == meta["sha256"], name
for name, expected_hash in completion["packet_hashes"].items():
    # The prior IR3 packet is historical after the path correction.
    assert digest((path_revision / "original" / name).read_bytes()) == expected_hash, name
assert digest((revision / "before.json").read_bytes()) == completion["preservation_manifest_sha256"]
assert completion["original_cli_calls"] == 24 and completion["original_command_count"] == 186
assert completion["product_calls_in_revision"] == 0 and not completion["modified_judge_executed"]
initial_audit = json.loads((HERE / "audit.before-ir3-correction.json").read_text())
for name in ("implementation.patch", "protected-contract.patch"):
    assert digest((revision / "original" / name).read_bytes()) == initial_audit["patches"][name]["raw_sha256"]
for name, meta in path_before["preserved_packet"].items():
    raw = (path_revision / "original" / name).read_bytes()
    assert len(raw) == meta["size"] and digest(raw) == meta["sha256"], name
for name, expected_hash in path_completion["packet_hashes"].items():
    assert digest((PACKET / name).read_bytes()) == expected_hash, name
assert digest((revision / "before.json").read_bytes()) == path_before["native_manifest_sha256"]
assert digest((path_revision / "before.json").read_bytes()) == path_completion["preservation_manifest_sha256"]
assert path_completion["original_native_cli_calls"] == 24 and path_completion["original_native_commands"] == 186
assert path_completion["native_files_checked"] == len(before_revision["immutable_native_evidence"]) == 1062
assert path_completion["product_calls_in_correction"] == 0 and not path_completion["modified_judge_executed"]
assert not any(path_completion[key] for key in ("patch_applied", "proposed_source_imported", "proposed_source_compiled"))
assert path_completion["added_api_controls"] == "NOT_EXECUTED_NOT_NATIVE_CLI25"
assert path_completion["protected_contract_unchanged"]

# Independent text-only semantic readback. Do not build/compile/import any after file.
implementation = (PACKET / "implementation.patch").read_text(encoding="utf-8")
shadow = implementation.split("+def shadow_baseline(change, policy_base):", 1)[1].split("+def config_transition", 1)[0]
engine_line = next(line.strip() for line in git("show", BASE + ":src/checkwash/engine.py").decode().splitlines()
                   if line.strip().startswith("path = change.path.replace("))
assert "+    " + engine_line in shadow
assert shadow.index(engine_line) < shadow.index("if path not in") < shadow.index("name = path.rsplit") < shadow.index("config = path.endswith")
assert 'selected_path = (policy_base.config_path if config else policy_base.allow_path).replace("\\\\", "/")' in shadow
mapping = implementation.split("+def _policy_mapping(snapshot):", 1)[1].split("+@dataclass", 1)[0]
assert mapping.index('path = path.replace("\\\\", "/")') < mapping.index("if path not in own_paths")
assert 'ambiguous.add(path.rsplit("/", 1)[1])' in mapping
assert "known_names = frozenset(known_names) - ambiguous" in implementation
case = implementation.split("+def case_policy_base(case: Case):", 1)[1].split(" def case_to_changes", 1)[0]
assert all("_policy_mapping(case." + name + ")" in case for name in ("before", "after", "head"))
assert "if needed & unknown:" in case and "known_names=frozenset(names - unknown)" in case
consumer = (PACKET / "consumer-migration.patch").read_text(encoding="utf-8")
assert 'FileChange(path=path, status="added", before=None,' in consumer
assert 'FileChange(path=r".checkwash\\allow.toml", status="added", before=None, after=b"")' in consumer
assert all(name in consumer for name in (
    "test_priority_config_backslash_api_never_falls_back_to_fresh_defaults",
    "test_backslash_mapping_and_case_base_provenance_match_canonical_fingerprint",
    "test_normalized_policy_alias_conflict_is_unknown_only_for_its_filename"))
assert "NOT_EXECUTED" in (PACKET / "STATIC-BACKSLASH-CORRECTION.md").read_text(encoding="utf-8")
head = git("rev-parse", "HEAD").decode().strip()
head_changes = git("diff", "--name-only", BASE, "HEAD").decode().splitlines()
assert not any(path.startswith(("src/", "tests/", "tools/", "action/")) for path in head_changes)
result = {"scope": "read-only source/raw/context checks; no proposed source constructed or executed",
          "review_state": "PASS_NO_REMAINING_BLOCKERS",
          "remaining_blocking_findings": [],
          "marker": "HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL", "hostname": socket.gethostname(),
          "runtime": sys.version, "executable": sys.executable,
          "final_patch_hashes": FINAL_PATCH_HASHES,
          "path_normalization_correction": {
              "status": "RESOLVED_BY_INDEPENDENT_SOURCE_REVIEW",
              "counterexample_kind": "source-only NOT_EXECUTED; previous inert patch",
              "engine_expression": engine_line,
              "normalization_precedes_fixed_membership_name_and_suffix": True,
              "selected_base_and_mapping_case_spelling_consistent": True,
              "alias_unknown_is_per_filename_relevant_only": True,
              "new_api_controls": "NOT_EXECUTED_NOT_NATIVE_CLI25",
              "prior_packet_files_preserved": len(path_before["preserved_packet"]),
              "latest_packet_hashes_verified": len(path_completion["packet_hashes"]),
              "preservation_manifest_sha256": path_completion["preservation_manifest_sha256"]},
          "source_sha": BASE, "current_product_head": head, "head_changes_from_frozen": head_changes,
          "source_members_match_git_archive_and_working_bytes": members,
          "native_observations": 24, "cases": 12, "raw_commands_verified": len(journal),
          "pass_observations": 8, "block_observations": 16,
          "proposed_movements_are_not_executed": len(movements), "patches": patches,
          "ir3_correction_preservation": {"immutable_files": len(before_revision["immutable_native_evidence"]),
                                         "preserved_original_packet_files": len(before_revision["preserved_original_packet"]),
                                         "updated_packet_hashes": len(completion["packet_hashes"]),
                                         "original_ir_version": completion["original_ir_version"],
                                         "proposed_ir_version": completion["proposed_ir_version"],
                                         "new_control_execution": completion["future_controls"]},
          "modified_judge_executions": 0, "errors": []}
(HERE / "audit.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps({key: value for key, value in result.items() if key != "patches"}, indent=2))
