# Independent read-only review — policy shadow

Review state: **PASS_NO_REMAINING_BLOCKERS** for the final inert packet.
Original evidence, IR3 contract/consumer correction and the lexical
path-normalization correction have been independently read back.
No proposed source has been applied, compiled, imported or executed.

Reviewer `/root/quality_fix`; LAPTOP-01AGNPJU;
HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL. `audit.py` uses ordinary file/Git reads,
standard-library JSON/ZIP/hash parsing and existing old-line hunk checks only.
It does not construct executable proposed files. Product, old packages and
original native raw were not changed by this reviewer.

## Source and native evidence

All judge observations remain bound to frozen
`9a5a27f44c895ba2fdee8c83a6313baf0e120873`, package version 0.9.1 and
findings envelope2. All 210 archived/extracted source members match Git blob
identities and the current product's physical source bytes. At review HEAD
is `5f0af4b40cdc6ed2f20414c76dd748549de67109`; its diff from 9a5a names only
`docs/quality-adoption.md` and `docs/ux-repair-candidate-2026-10-26.md`.
That document commit is not a new judge execution or changed runtime source.

Independent checks cover 186 native command stdout/stderr hash pairs, all
24 JSON payload/exit records, 24 sealed input-manifest identities and all
12 movement entries pointing at their actual first/second observations.
There are 8 native pass and 16 native block observations, zero engine-error
observations and no config_errors/skipped_files in these controls. All A/B
finding identities match the measured seed keys. The current artifacts and
exact old/context lines of all three patches match their manifests and frozen
Git sources. No forecast fingerprint or after-result is treated as observed.

The seed has worktree/range parity; the other controls are policy-only
worktree review followed by an owned fixture commit and another worktree
review against that new BASE. A fixture commit after a block only prepares
the next observation. It does not show review acceptance, a successful merge,
a same-PR bypass or an actual maintainer-approved exemption.

## What the observations establish

- 01/07 establish that the current new-priority config is reported at warn
  while changing the effective config's block-on-config/allow-parse-error
  policy. The later control is ordinary oracle weakening, not an observed
  parse-error exploit. The report explicitly preserves that distinction.
- 02/03 demonstrate conservative critical maintenance blocks on an identical
  disabled-set migration and a strict-subset tightening. They support the
  proposed bounded comparison, not a general proof of arbitrary policy safety.
- 08, A→A, is duplicate EXEMPTION_ADDED visibility. Its pass is not a new
  unsafe authorization; the effective future ledger is unchanged.
- 09, A→B, shows physical-file append classification despite an effective
  ledger replacement. Its next-BASE behavior (B eligible, A not eligible) is
  ordinary BASE matching. The proposed critical rewrite finding is a review
  policy choice aligned with §6, not proof that next-BASE matching is defective.
- 10, A→empty, revokes an entry and makes future analysis stricter. Its pass
  is not an authorization escape. Charging critical protected-maintenance
  cost to that tightening is an explicitly retained policy cost.
- 11's pass follows the actual independent BASE config/allow selection:
  B is disabled by the selected config and A remains allowlisted. The report
  does not claim all pass results are vulnerabilities. Only B is a true new
  suffix entry; the duplicate A warning is a visibility/attribution defect.
- 06 retains the existing conservative cost of an inactive lower-priority
  creation. It is not silently included in the repair.

## Implementation reading

The new helper has no circular dependency: it depends on change/config,
which do not depend on engine or the proposed helper. CLI/sweep pass the
selected path/raw bytes they already read, separately per filename. No
HEAD policy replaces the config/exemptions that judge the current diff, and
no new snapshot path, link, size or source-read admission is introduced.

Shadow recognition uses `before is None`, not falsey bytes, and requires an
existing selected legacy predecessor. Empty BASE bytes remain distinct from
absence. The bounded config order compares all current effective Config
fields: equal roles, disabled-set subset, non-rising threshold, and no
block→pass_with_warning transition. Warnings, parse errors and differing
roles are guarded conservatively; pre-existing loader exceptions still fail
through the existing error path. This is not a glob-inclusion algorithm.

The ledger helper reuses the effective parsed BASE prefix, retaining the
existing parser's permissive invalid-record boundaries. Equal ledger adds
no entries; a true suffix preserves EXEMPTION_ADDED identity; rewrites stay
guardrail changes. The single historical exemption_ledger_path attribution
for multiple changed ledgers remains a disclosed residual.

GUARDRAIL fingerprints bind physical change evidence plus selected BASE
path/raw digest/transition kind. Shadow keys intentionally change; automatic
old-approval translation would be wrong. Oracle A/B identity functions and
actual BASE exemption inputs are unchanged. The future finding-dictionary
forecasts are source-level forecasts, not new measured identities. Run version
and IR version will of course move independently under the illustrative bump.

No additional unsafe comparison condition was found in the reviewed hunks.
This is an inert, incomplete implementation candidate, not an apply-ready
release: direct API/fixture adapters, machine validators, version metadata,
new tests, all required qualifications and acceptance remain future work.

## IR3 contract finding and required correction

The initial implementation patch sets IR_VERSION=3, while the original
protected patch left SPEC.md:9's current top-level IR payload version at 2.
Its added subsection simultaneously claimed IR3. This creates an internally
contradictory protected contract if adopted. Root/author were informed
immediately; the minimal correction belongs only in the inert packet.

`docs/stability.md:123–128` explicitly allows optional field additions without
a version bump. Therefore IR3 must be an explicit new required provenance
slot/semantic boundary, not justified merely by saying every new field is
a shape change. The map can be empty when no shadow transition exists, but
an IR3 consumer must not silently treat a missing/malformed slot as trusted
empty provenance or retrofit that declaration onto historical IR2.

Concrete migration targets found independently:

- `tools/corpus_artifacts.py:117` hard-requires IR2; accepting enum3 alone
  would not check the required map, allowed path pairs/kinds or digest shape.
- `tests/test_fingerprint_scope.py:77` couples IR and FINDINGS to 2; a future
  contract test should split expected IR3 and findings2 without relabeling
  existing oracle fixtures.
- `tools/emit_corpus.py:48` directly calls analyze without PolicyBase, and
  existing priority-policy cases exercise the new refusal. Its adapter must
  provide actual BASE provenance, not a universal empty PolicyBase.
- `case_snapshot()` in `src/checkwash/cases.py:109` is explicitly an AFTER
  snapshot. It must not become the source of BASE PolicyBase. Head-only ledger
  fixture data is explicitly not an active exemption under the existing
  `.gwcase` contract; preserve the golden runner's separate allow inputs.
- Audit `src/checkwash/demo.py:64`, `tests/test_demo_command.py:31`,
  `tools/assertion_contract.py:197`, `tools/reliability_r1_trace.py:68` and
  other direct analysis callers. Some are unaffected modified-only cases;
  listing them does not claim each currently fails.
- `tools/compare_quality_legacy.py:84` currently accepts integer IR versions
  and records every differing leaf. Its old IR2 artifacts and
  `tests/test_release_compatibility_record.py` historical IR2 test data must
  remain untouched; a new IR3 arm is not a reason to edit or green old evidence.
- Distinguish current/future notes in stability/embedding from historical
  v0.3/v0.6/v0.8 release records. Do not globally replace every `2` with `3`.

Necessary new negatives include missing/malformed required map under IR3,
unsupported or mismatched map path pairs/kinds/digests, IR2 mislabeled as new
proof, HEAD data presented as BASE, missing direct-caller provenance and
explicit absence versus zero bytes. Keep normal current-source versus future
source arm identity and receipt separation; do not widen a validator merely
to get a green comparison.

IR3 plus a next-minor decision is a defensible explicit breaking-contract
choice once those required semantics are stated. Findings envelope2 can stay
because its closed object/envelope fields do not change; moved fingerprints,
severity interpretation and removed duplicate warnings still require the
minor compatibility/review accounting already called out by the packet.

## IR3 correction readback

The corrected main/protected/consumer patches now align the top SPEC header,
runtime constants, provisional project metadata and IR model title with the
explicit proposed IR3/findings2 decision. The current-source corpus validator
requires exactly integer IR3 plus the typed map, fixed path pairs, digest and
kind; it rejects IR2 instead of manufacturing proof. Historical comparison
parser behavior and the release-record helper's default IR2 stay unchanged.
The new transition test records package/IR-version/required-slot deltas without
rewriting the original baseline document. Those new tests remain NOT_EXECUTED.

The before-only case adapter preserves unknown provenance per filename through
known_names, refuses only the relevant new-priority creation, keeps unrelated
HEAD policy context from causing a new refusal, and retains Config()/[] in
golden/demo callers. It does not read case_snapshot as BASE or activate a HEAD
ledger. The new unit controls document both directions of filename independence.

All three corrected patches have valid frozen old-line contexts/counts. The
revision preserves all 22 original packet files, including the exact old patch
hashes captured by this review, and all 1,062 immutable native/source/fixture
files match the recorded original hashes. All 19 updated packet artifact hashes
match the historical IR3 completion.json and preserved pre-path-correction
copies. Original 24 CLI/186-command results remain IR2 and were not rerun or
relabeled. The IR3 clarification finding is resolved.

## Historical source-level blocker — normalization, now resolved

The original engine normalizes each FileChange path with
`change.path.replace('\\', '/')` before role matching (engine.py:1181).
The previous inert shadow_baseline instead tested the raw change.path against its
fixed forward-slash paths. For a direct caller supplying the existing supported
backslash spelling `.checkwash\\config.toml`, an added loose-error config and
actual PolicyBase with a strict legacy config, the engine enters its guardrail
branch but the new helper returns None at membership. It falls back to the
fresh/default comparison, which does not classify pass_with_warning as loosening.
The source-level forecast is a warn instead of the proposed critical transition.

This is a proposed-code reasoning counterexample, **not a native after-result**;
no modified judge was invoked. Official Git CLI paths are forward slash, so
none of the original 24 observations is invalidated. Root/author were notified
immediately. The minimal correction is to use the engine's existing lexical
slash normalization consistently in helper path/name/filename checks, and to
make the new BASE mapping/case adapter boundary equally explicit. Do not add
realpath, native filesystem case folding or a general path-admission exception.
A new inert direct-API backslash control should document the requirement.

The final patch resolves that counterexample. `shadow_baseline` now uses
the identical frozen-engine lexical replacement before its fixed-path
membership, filename extraction and suffix checks. Explicit selected-BASE
paths are normalized before comparison with the matching fixed legacy path.
The BASE mapping and before/after/head case-key adapters use the same lexical
rule; they do not add filesystem resolution, case folding or new path admission.
Colliding spellings mark only that filename unknown. Only a new priority
creation requiring that unknown filename refuses, preserving independent
config/allow context and test-only admission. No HEAD data grants BASE authority.

The new API controls use actual `FileChange(path=..., status=..., before=...,
after=...)` fields. They spell out canonical/backslash change and selected-BASE
paths, strict-to-loose critical/META/BLOCK behavior, canonical proof paths,
equal fingerprints across spellings, and relevant-only ambiguity refusal.
All are explicitly **NOT_EXECUTED_NOT_NATIVE_CLI25**. Their assertions are
future expected behavior, not an observed after-result or a successful test run.
The previously reviewed required IR3 slot/typed validator, historical IR2
handling, per-filename caller provenance and separate active exemption inputs
remain consistent; this correction adds no enum-only migration shortcut.

Final exact patch SHA256 values independently checked:

- implementation.patch: `7ab91501aecaa05ed47a130d2f2d61cb27a96139a63ec1be49c138270385abdf`
- consumer-migration.patch: `6f5458ecdfcf0651968e9fef16993faf1e26b6da2235364065c3e5656973958b`
- protected-contract.patch: `8ad77c27e78122889a251af189a130f7f173292415868c1139d813fe5ed4e7ab`

The final read-only audit exited 0. It verified all 18 latest packet hashes,
the 30 preserved pre-path-correction packet files, the 22 original pre-IR3
packet files and all 1,062 immutable source/native/fixture files. Historical
review audits, including the explicit pending state, remain separate files.
The final audit explicitly records `PASS_NO_REMAINING_BLOCKERS`,
`remaining_blocking_findings=[]`, the resolved correction and these exact hashes.
This closes the proposal-review blocker; adoption, changed-judge execution,
qualification, protected-policy acceptance and publication remain separate.

## Remaining scope limits

The packet does not qualify hook/range permutations beyond the seed, malformed
policy/error counterfactuals, CLI fail_on overrides, direct API refusal costs,
cross-platform behavior, natural-history costs, wheel/pyz or release collectors.
Copy-plus-delete and genuine Git rename maintenance retain existing critical
cost; they are not proved equivalent full migrations by the copy controls.
Existing role overrides, falsey physical-before edge cases and loader/schema
gaps are not closed by this bounded new-priority decision.

The budget remains exhausted at 24 product CLI calls. No additional CLI,
fixture program, changed judge, model or historical sweep was run in review.
r65 remains paused; version text inside a draft is not publication authority.
