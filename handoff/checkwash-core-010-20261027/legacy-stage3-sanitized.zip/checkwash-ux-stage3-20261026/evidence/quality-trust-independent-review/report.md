# Independent review — quality-trust decision packet

No blocking issue found. This review is independent of the packet author
`/root/quality_fix` and covers the fixed-source evidence and inert proposals;
it does not accept or implement either policy choice.

`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`; actual host LAPTOP-01AGNPJU,
Windows 10.0.26200, Python 3.11.9. The 18 original native CLI calls remain
bound to `9a5a27f44c895ba2fdee8c83a6313baf0e120873`. This review made zero
new product CLI calls and did not import, apply, compile or execute a changed
judge. Only standard-library reads and bounded native Git reads were used.

The independent audit finished with exit0, 402 assertions and no errors.
These are evidence-integrity assertions, not 402 product tests. All 124
original command stdout/stderr hashes and all 18 payload/exit/receipt pairs
match. All 210 extracted source members match both the archived bytes and
their actual frozen Git tree/blob identities. All seven proposal artifact
hashes and three protected original-file hashes match. The three patch hunk
contexts match frozen source; the gating hunk adds comments only. All 466
original source/raw/package files checked remained byte-identical.

The measured semantics support the report:

- In both report and enforce mode, an actual one-entry BASE ledger becomes
  a two-entry HEAD ledger with its first entry unchanged. Main `check`
  retains a critical GUARDRAIL_TOUCHED block/1; quality reports a complete
  QW_POLICY_CHANGED warning with `reported`/0. Quality exit0 is not clean
  and does not establish a main-check pass.
- The existing valid exact BASE quality entry leaves its high finding
  visible with `allowlisted=true`. The second key exists only at HEAD in
  the cochange control and does not exempt that current weakening.
- The actual expired BASE row and the strictly shaped other-target BASE
  row produce complete, unallowlisted blocks. Unknown-rule BASE and
  malformed HEAD rows produce POLICY_INVALID/error2, not normal nonmatches.
  The report correctly distinguishes these outcomes.
- Choice A retains the prior-BASE review boundary and both independent
  required checks. The exact main guardrail key must use the existing main
  exemption process; a QW key does not become a main allow key. The packet
  explicitly says that synthetic BASE commits, schema validity, author/tool
  labels and Git commits are not proof of actual human review.
- Choice B is neither recommended, adopted nor implemented. Its predicate
  binds admitted bytes and BASE policy but explicitly cannot prove a human
  review or a real event merely from a well-shaped hash. Its movement table
  is prediction only. Current expired/wrong-target controls are BASE-entry
  eligibility controls, not tests of B's proposed HEAD predicate. The
  acceptance plan correctly requires those future controls and protected,
  schema and version decisions before implementation.

One nonblocking editorial improvement was sent to the author: replace the
single `Existing exact BASE approval ... new HEAD approval` phrase with
`entry`. The surrounding disclaimers already prevent an actual-approval
inference; the change would make the sentence independently precise.

The parent is concurrently preparing nonprotected adoption/candidate docs.
Current HEAD/status/delta are recorded in `audit.json`; the review allows
only those documented Markdown deltas and still compares every judge source
member to frozen 9a5a. A docs-only HEAD advance is not a new judge run.

The first audit-driver attempt used the wrong parent-directory index and
stopped before any Git/product command with WinError267. Its script and
stdout/stderr/exit are preserved under `attempt-01/`. After correcting only
that owned review-driver path, the completed audit exited0. This is a review
driver correction, not a product failure or repeated judge result.

`audit.json` contains the full checks, actual fixture Git inputs, full
observations, current docs delta, immutable hashes and read-command receipts.
`audit.stdout`, `audit.stderr`, `audit.exit` and `audit-command.json` retain
the completed audit command. Historical cost, other OS/Python, actual tool or
model execution, a complete review/migration lifecycle and changed-judge
acceptance remain NOT_RUN. r65 remains paused; no real PR exemption,
protected edit, version bump, merge, tag or publication is authorized.


Editorial follow-up: the author replaced the two approval phrases with entry
phrases (including articles). Reversing exactly these two phrases matches
the original draft byte hash; the new proposal manifest matches every current
proposal file. All 466 original source/raw files remain unchanged. Six
follow-up integrity checks pass, with no additional CLI calls. The editorial
note is resolved; no blocking issue remains. See editorial-followup.json.
The first follow-up driver assumed only the two nouns had changed, so its
reconstruction assertion failed before finalization. It is preserved under
attempt-followup-01/; correcting the expected two phrase strings yields exit0.
