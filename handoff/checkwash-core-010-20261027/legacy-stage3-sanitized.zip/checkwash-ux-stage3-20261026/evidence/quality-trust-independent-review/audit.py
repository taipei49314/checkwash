"""Independent read-only evidence audit. No product/proposal import or execution."""
import datetime
import hashlib
import json
import os
import platform
import re
import socket
import subprocess
import sys
import tomllib
import zipfile
from pathlib import Path

HERE = Path(__file__).parent
PACKAGE = HERE.parent / "quality-trust"
PRODUCT = HERE.parents[1] / "checkwash-ux"
SOURCE_SHA = "9a5a27f44c895ba2fdee8c83a6313baf0e120873"
GIT = Path(r"C:\Program Files\Git\cmd\git.exe")
RAW = HERE / "raw"
RAW.mkdir(exist_ok=True)
HOOKS = HERE / "empty-hooks"
HOOKS.mkdir(exist_ok=True)
env = {key: value for key, value in os.environ.items()
       if key.upper() in {"SYSTEMROOT", "WINDIR", "SYSTEMDRIVE", "COMSPEC", "TEMP", "TMP", "PATHEXT"}}
env.update({"GIT_CONFIG_NOSYSTEM": "1", "GIT_CONFIG_GLOBAL": "NUL", "GIT_TERMINAL_PROMPT": "0",
            "GCM_INTERACTIVE": "Never", "GIT_OPTIONAL_LOCKS": "0", "PYTHONDONTWRITEBYTECODE": "1"})
commands, checks, errors = [], [], []

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def js(path):
    return json.loads(path.read_text(encoding="utf-8"))

def save(path, data):
    path.write_bytes((json.dumps(data, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))

def check(name, passed, detail=None):
    checks.append({"check": name, "passed": bool(passed), "detail": detail})
    if not passed:
        errors.append(name)

def git_read(label, repo, *args, input_bytes=None):
    command = [str(GIT), "--no-optional-locks", "--no-replace-objects", "-c", "core.fsmonitor=false",
               "-c", "core.hooksPath=" + str(HOOKS), "--literal-pathspecs", *args]
    result = subprocess.run(command, cwd=repo, env=env, input=input_bytes, capture_output=True, timeout=60)
    out, err = RAW / (label + ".stdout.bin"), RAW / (label + ".stderr.bin")
    out.write_bytes(result.stdout)
    err.write_bytes(result.stderr)
    commands.append({"label": label, "command": command, "cwd": str(repo), "exit": result.returncode,
                     "stdout": str(out.relative_to(HERE)), "stdout_sha256": sha(result.stdout),
                     "stderr": str(err.relative_to(HERE)), "stderr_sha256": sha(result.stderr),
                     "stdin_sha256": sha(input_bytes) if input_bytes is not None else None})
    check("git-read-exit:" + label, result.returncode == 0)
    return result.stdout

manifest = js(PACKAGE / "manifest.json")
validation = js(PACKAGE / "validation.json")
proposal = js(PACKAGE / "proposal/proposal-manifest.json")
immutable = [PACKAGE / name for name in ("manifest.json", "validation.json", "command-journal.json",
              "results-journal.json", "source-9a5a.zip", "reproduce.py", "validate_and_propose.py", "finalize_packet.py")]
immutable += [p for parent in (PACKAGE / "raw", PACKAGE / "source-9a5a")
              for p in sorted(parent.rglob("*")) if p.is_file()]
original_hashes = {str(p.relative_to(PACKAGE)).replace("\\", "/"): sha(p.read_bytes()) for p in immutable}

head_before = git_read("product-head-before", PRODUCT, "rev-parse", "HEAD").decode().strip()
status_before = git_read("product-status-before", PRODUCT, "status", "--porcelain=v1", "--untracked-files=all")
delta_before = git_read("product-delta-before", PRODUCT, "diff", "--name-only", SOURCE_SHA, "--").decode().splitlines()
def permitted_root_docs(paths):
    protected = {"SPEC.md", "DECISIONS.md", "THREATMODEL.md"}
    return all(path.endswith(".md") and path not in protected and not path.startswith("DECISIONS-archive-") for path in paths)
untracked_before = [line[3:] for line in status_before.decode().splitlines() if line.startswith("?? ")]
check("current-root-delta-nonprotected-docs-only-before", permitted_root_docs(delta_before + untracked_before),
      {"current_head": head_before, "tracked_delta": delta_before, "untracked": untracked_before})
check("recorded-source-freeze", manifest["source_sha"] == manifest["ending_sha"] == SOURCE_SHA and manifest["source_unchanged"])
check("recorded-native-cli-count", manifest["cli_calls"] == manifest["maximum_cli_calls"] == 18)
check("recorded-source-before-after", manifest["source_files_before"] == manifest["source_files_after"])
check("recorded-no-modified-judge", manifest["modified_judge_executions"] == 0 and manifest["fixture_program_execution"] == "NOT_RUN")
check("journals-match-manifest", js(PACKAGE / "command-journal.json") == manifest["commands"]
      and js(PACKAGE / "results-journal.json") == manifest["results"])
check("archive-raw-hash", sha((PACKAGE / "source-9a5a.zip").read_bytes()) == manifest["source_archive_sha256"])

tree = git_read("source-tree", PRODUCT, "ls-tree", "-r", SOURCE_SHA, "--", "src").decode().splitlines()
git_tree = {line.split("\t", 1)[1]: line.split()[2] for line in tree}
source_checks = []
with zipfile.ZipFile(PACKAGE / "source-9a5a.zip") as archive:
    for path, record in manifest["source_files_before"].items():
        raw = (PACKAGE / "source-9a5a" / path).read_bytes()
        oid = hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
        passed = sha(raw) == record["sha256"] and oid == record["git_blob"] == git_tree[path] and raw == archive.read(path)
        source_checks.append({"path": path, "sha256": sha(raw), "git_blob": oid, "passed": passed})
check("all-source-members-native-git-and-archive", all(row["passed"] for row in source_checks), len(source_checks))

check("raw-command-count", len(manifest["commands"]) == 124)
for command in manifest["commands"]:
    for stream in ("stdout", "stderr"):
        check("recorded-raw-hash:" + command["label"] + ":" + stream,
              sha((PACKAGE / command[stream]).read_bytes()) == command[stream + "_sha256"])
cli = [command for command in manifest["commands"] if command["cli"]]
check("exactly-18-recorded-cli-receipts", len(cli) == len(manifest["results"]) == 18)
for result in manifest["results"]:
    receipt = result["receipt"]
    check("result-receipt:" + receipt["label"], receipt in cli and receipt["exit_code"] == result["exit_code"]
          and json.loads((PACKAGE / receipt["stdout"]).read_bytes()) == result["payload"]
          and (PACKAGE / receipt["stderr"]).read_bytes() == b"")
    argv = receipt["command"]
    check("fixed-original-cli:" + receipt["label"], all(flag in argv for flag in ("-I", "-B", "-X"))
          and str(PACKAGE / "source-9a5a/src").replace("\\", "\\\\") in argv[argv.index("-c") + 1])

rows = {(row["case"], row["command"]): row for row in manifest["results"]}
def row(case, lane):
    return rows[(case, lane)]
def finding(case, lane, rule):
    return next(f for f in row(case, lane)["payload"]["findings"] if f["rule"] == rule)
for mode in ("report", "enforce"):
    case = mode + "-append-only"
    main, quality = row(case, "check"), row(case, "quality")
    check("append-main-block:" + mode, main["exit_code"] == 1 and main["payload"]["verdict"] == "block"
          and finding(case, "check", "GUARDRAIL_TOUCHED")["severity"] == "critical")
    check("append-quality-warning:" + mode, quality["exit_code"] == 0 and quality["payload"]["verdict"] == "reported"
          and quality["payload"]["analysis_status"] == "complete" and quality["payload"]["run"]["mode"] == mode
          and finding(case, "quality", "QW_POLICY_CHANGED")["severity"] == "warn")
q = row("enforce-existing-valid", "quality")
check("existing-base-entry-matches", q["exit_code"] == 0 and q["payload"]["verdict"] == "no_blocking_finding"
      and finding("enforce-existing-valid", "quality", "QW_THRESHOLD_LOWERED")["allowlisted"])
check("head-new-entry-not-current-authority", row("enforce-head-not-authority", "quality")["exit_code"] == 1
      and not finding("enforce-head-not-authority", "quality", "QW_THRESHOLD_LOWERED")["allowlisted"])
for case in ("enforce-expired-base", "enforce-wrong-target"):
    q = row(case, "quality")
    check("ineligible-not-error:" + case, q["exit_code"] == 1 and q["payload"]["analysis_status"] == "complete"
          and q["payload"]["diagnostics"] == [] and not finding(case, "quality", "QW_THRESHOLD_LOWERED")["allowlisted"])
for case in ("enforce-unknown-rule", "enforce-malformed-head"):
    q = row(case, "quality")
    check("strict-error-not-nonmatch:" + case, q["exit_code"] == 2 and q["payload"]["analysis_status"] == "error"
          and q["payload"]["findings"] == [] and any(d["kind"] == "error" and d["code"] == "POLICY_INVALID" for d in q["payload"]["diagnostics"]))

# Independently read actual committed fixture inputs, without executing them.
fixture_inputs = {}
for case in sorted({result["case"] for result in manifest["results"]}):
    first = next(result for result in manifest["results"] if result["case"] == case)
    repo = PACKAGE / "repos" / case
    specs = [(side, path, first[side] + ":" + path) for side in ("base", "head")
             for path in (".checkwash/quality.toml", ".checkwash/quality-allow.toml", "pyproject.toml")]
    stream = git_read("fixture-" + case, repo, "cat-file", "--batch",
                      input_bytes=("\n".join(spec for _, _, spec in specs) + "\n").encode())
    offset, parsed = 0, {}
    for side, path, spec in specs:
        end = stream.index(b"\n", offset)
        header = stream[offset:end].decode()
        offset = end + 1
        if header.endswith(" missing"):
            parsed[(side, path)] = None
            continue
        oid, kind, size = header.split()
        raw = stream[offset:offset + int(size)]
        offset += int(size) + 1
        check("fixture-git-blob:" + case + ":" + side + ":" + path,
              kind == "blob" and oid == hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest())
        parsed[(side, path)] = tomllib.loads(raw.decode("utf-8"))
    fixture_inputs[case] = {side + ":" + path: value for (side, path), value in parsed.items()}

for mode in ("report", "enforce"):
    data = fixture_inputs[mode + "-append-only"]
    before, after = data["base:.checkwash/quality-allow.toml"]["allow"], data["head:.checkwash/quality-allow.toml"]["allow"]
    check("actual-second-append:" + mode, len(before) == 1 and len(after) == 2 and after[:1] == before
          and data["base:.checkwash/quality.toml"]["mode"] == mode
          and data["base:pyproject.toml"] == data["head:pyproject.toml"])
today = datetime.date(2026, 10, 26)
expired = fixture_inputs["enforce-expired-base"]["base:.checkwash/quality-allow.toml"]["allow"][0]
wrong = fixture_inputs["enforce-wrong-target"]["base:.checkwash/quality-allow.toml"]["allow"][0]
check("actual-expired-base-entry", datetime.date.fromisoformat(expired["expires"]) < today)
check("actual-other-target-base-entry", wrong["target_id"] != "coverage-main"
      and wrong["fingerprint"].startswith(wrong["rule"] + "/" + wrong["target_id"] + "/q1:"))
base_entry = fixture_inputs["enforce-head-not-authority"]["base:.checkwash/quality-allow.toml"]["allow"]
head_entry = fixture_inputs["enforce-head-not-authority"]["head:.checkwash/quality-allow.toml"]["allow"]
current_fp = finding("enforce-head-not-authority", "quality", "QW_THRESHOLD_LOWERED")["fingerprint"]
check("actual-head-key-only", current_fp in {entry["fingerprint"] for entry in head_entry}
      and current_fp not in {entry["fingerprint"] for entry in base_entry})

for name, expected in proposal["files"].items():
    check("proposal-raw-hash:" + name, sha((PACKAGE / "proposal" / name).read_bytes()) == expected)
protected = {}
for path, expected in proposal["protected_source_sha256"].items():
    raw = git_read("protected-" + path.replace("/", "--"), PRODUCT, "show", SOURCE_SHA + ":" + path)
    protected[path] = raw
    check("protected-git-source-hash:" + path, sha(raw) == expected)
hunks = []
for patch_name, source_name in (("01-SPEC-retain-base-review.patch", "SPEC.md"),
                                ("02-gating-clarification-only.patch", "src/checkwash/gating.py"),
                                ("03-DECISIONS-proposed.patch", "DECISIONS.md")):
    lines = (PACKAGE / "proposal" / patch_name).read_text(encoding="utf-8").splitlines()
    source_lines = protected[source_name].decode("utf-8").splitlines()
    i = 0
    while i < len(lines):
        match = re.match(r"@@ -(\d+),(\d+) \+(\d+),(\d+) @@", lines[i])
        if not match:
            i += 1
            continue
        start, count, new_start, new_count = map(int, match.groups())
        i += 1
        old, added, removed = [], [], []
        while i < len(lines) and not lines[i].startswith("@@"):
            line = lines[i]
            if line.startswith((" ", "-")):
                old.append(line[1:])
            if line.startswith("+"):
                added.append(line[1:])
            if line.startswith("-"):
                removed.append(line[1:])
            i += 1
        matches = len(old) == count and old == source_lines[start - 1:start - 1 + count]
        check("inert-hunk-original-context:" + patch_name, matches)
        if source_name.endswith("gating.py"):
            check("gating-hunk-only-comments", not removed and all(line.lstrip().startswith("#") or not line.strip() for line in added))
        hunks.append({"patch": patch_name, "old_start": start, "old_count": count, "context_matches": matches,
                      "added_count": len(added), "removed_count": len(removed)})
check("inert-proposal-status", proposal["not_adopted"] and not proposal["applied"] and proposal["modified_judge_executions"] == 0)

head_after = git_read("product-head-after", PRODUCT, "rev-parse", "HEAD").decode().strip()
status_after = git_read("product-status-after", PRODUCT, "status", "--porcelain=v1", "--untracked-files=all")
delta_after = git_read("product-delta-after", PRODUCT, "diff", "--name-only", SOURCE_SHA, "--").decode().splitlines()
untracked_after = [line[3:] for line in status_after.decode().splitlines() if line.startswith("?? ")]
check("current-root-delta-nonprotected-docs-only-after", permitted_root_docs(delta_after + untracked_after),
      {"current_head": head_after, "tracked_delta": delta_after, "untracked": untracked_after})
after_hashes = {str(p.relative_to(PACKAGE)).replace("\\", "/"): sha(p.read_bytes()) for p in immutable}
check("original-package-source-raw-unchanged", original_hashes == after_hashes, len(original_hashes))

observations = [{"case": r["case"], "command": r["command"], "exit": r["exit_code"],
                 "verdict": r["payload"]["verdict"], "analysis_status": r["payload"].get("analysis_status"),
                 "findings": [{key: finding.get(key) for key in ("rule", "severity", "allowlisted", "fingerprint")}
                              for finding in r["payload"]["findings"]]} for r in manifest["results"]]
audit = {"marker": "HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL", "source_sha": SOURCE_SHA,
         "reviewer": "/root/rename_repro; independent of quality-trust author /root/quality_fix",
         "hostname": socket.gethostname(), "runtime": sys.version, "platform": platform.platform(),
         "reviewed_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
         "scope": "Read-only packet/Git source/raw review; zero new product CLI calls; no proposal import/apply/execution",
         "recorded_native_cli_calls": 18, "recorded_raw_commands": 124, "new_product_cli_calls": 0,
         "modified_judge_executions": 0, "errors": errors, "checks": checks, "observations": observations,
         "current_product_root_owned_docs_delta": {"head_before": head_before, "head_after": head_after,
             "delta_vs_frozen_before": delta_before, "delta_vs_frozen_after": delta_after,
             "status_before": status_before.decode(), "status_after": status_after.decode(),
             "note": "Parent root independently editing nonprotected adoption/candidate docs; observations remain bound to frozen 9a5a source, not those docs."},
         "source_members": source_checks, "protected_hunks": hunks, "git_read_receipts": commands,
         "original_package_hashes_before_and_after": original_hashes,
         "fixture_inputs_from_read_only_git_blobs": fixture_inputs,
         "decision": "No blocking issue found" if not errors else "BLOCKED: inspect errors",
         "nonblocking_editorial_note": "00-decision.md calls synthetic exact BASE/HEAD entries approvals once; surrounding text explicitly disclaims actual human review. Prefer entry wording.",
         "limits": ["No changed judge accepted or executed", "No actual human approval inferred",
                    "Option B not adopted or tested; expired/wrong-target current controls are BASE entries, not B HEAD predicates",
                    "No historical cost, other platform, migration, tool/model execution or release acceptance measured"]}
save(HERE / "audit.json", audit)
save(HERE / "manifest.json", {"source_sha": SOURCE_SHA, "scope": audit["scope"], "errors": errors,
     "files": {name: sha((HERE / name).read_bytes()) for name in ("audit.py", "audit.json")},
     "original_packet_immutable_files_checked": len(original_hashes), "original_packet_unchanged": original_hashes == after_hashes})
print(json.dumps({"decision": audit["decision"], "checks": len(checks), "errors": errors,
                  "source_members": len(source_checks), "raw_commands": 124, "native_cli_calls_reviewed": 18,
                  "new_product_cli_calls": 0, "immutable_files_checked": len(original_hashes),
                  "audit_sha256": sha((HERE / "audit.json").read_bytes())}, indent=2))
sys.exit(0 if not errors else 1)
