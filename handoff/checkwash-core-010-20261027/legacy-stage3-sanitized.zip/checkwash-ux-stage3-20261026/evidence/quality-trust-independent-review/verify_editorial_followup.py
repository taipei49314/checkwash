"""Verify author's two-phrase draft correction; standard-library reads only."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).parent
PACKAGE = HERE.parent / "quality-trust"
def sha(raw):
    return hashlib.sha256(raw).hexdigest()
def js(path):
    return json.loads(path.read_text(encoding="utf-8"))
audit = js(HERE / "audit.json")
manifest = js(PACKAGE / "proposal/proposal-manifest.json")
raw = (PACKAGE / "proposal/00-decision.md").read_bytes()
old = raw.replace(b"An existing exact BASE entry still works;", b"Existing exact BASE approval still works;")
old = old.replace(b"a new HEAD entry does not excuse", b"new HEAD approval does not excuse")
checks = {
    "updated_decision_hash_matches_author": sha(raw) == "22a8598a61b29704649de1f8beb4dc18e868f0b90e2f7bf8c38740ab0d25e4ed",
    "two_phrase_reversal_matches_original_raw_hash": sha(old) == "1581bbae580c76392bd9609223b0be2d65f2a599ce1cc9a086ed0babfe7b39e8",
    "updated_proposal_manifest_hash_matches_author": sha((PACKAGE / "proposal/proposal-manifest.json").read_bytes()) == "60272aa5c0da87eff86f4b4e145ae2d379856d53b21071fe82f140740cafc8dc",
    "all_current_proposal_file_hashes_match_manifest": all(sha((PACKAGE / "proposal" / name).read_bytes()) == expected for name, expected in manifest["files"].items()),
    "all_466_original_source_raw_files_still_unchanged": all(sha((PACKAGE / name).read_bytes()) == expected for name, expected in audit["original_package_hashes_before_and_after"].items()),
    "proposal_remains_not_adopted_unapplied_unexecuted": manifest["not_adopted"] and not manifest["applied"] and manifest["modified_judge_executions"] == 0,
}
record = {"marker": "HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL", "source_sha": audit["source_sha"],
          "scope": "Author's two-phrase editorial follow-up only; zero new CLI or modified-judge executions",
          "checks": checks, "errors": [name for name, passed in checks.items() if not passed],
          "new_decision_sha256": sha(raw), "new_proposal_manifest_sha256": sha((PACKAGE / "proposal/proposal-manifest.json").read_bytes())}
(HERE / "editorial-followup.json").write_bytes((json.dumps(record, indent=2) + "\n").encode())
assert all(checks.values()), record["errors"]
report = (HERE / "report.md").read_bytes()
report += b"\n\nEditorial follow-up: the author replaced the two approval phrases with entry\nphrases (including articles). Reversing exactly these two phrases matches\nthe original draft byte hash; the new proposal manifest matches every current\nproposal file. All 466 original source/raw files remain unchanged. Six\nfollow-up integrity checks pass, with no additional CLI calls. The editorial\nnote is resolved; no blocking issue remains. See editorial-followup.json.\nThe first follow-up driver assumed only the two nouns had changed, so its\nreconstruction assertion failed before finalization. It is preserved under\nattempt-followup-01/; correcting the expected two phrase strings yields exit0.\n"
(HERE / "report.md").write_bytes(report)
files = [p for p in sorted(HERE.rglob("*")) if p.is_file() and p.name != "manifest.json"]
(HERE / "manifest.json").write_bytes((json.dumps({
    "source_sha": audit["source_sha"], "scope": "Independent read-only review with resolved editorial note",
    "blocking_findings": [], "new_product_cli_calls": 0, "modified_judge_executions": 0,
    "audit_assertions": 402, "followup_integrity_checks": 6, "original_immutable_files_checked": 466,
    "artifact_sha256": {str(p.relative_to(HERE)).replace("\\", "/"): sha(p.read_bytes()) for p in files},
}, indent=2) + "\n").encode())
print(json.dumps({"decision": "No blocking issue; editorial note resolved", "checks": checks,
                  "review_report_sha256": sha(report), "editorial_followup_sha256": sha((HERE / "editorial-followup.json").read_bytes())}, indent=2))
