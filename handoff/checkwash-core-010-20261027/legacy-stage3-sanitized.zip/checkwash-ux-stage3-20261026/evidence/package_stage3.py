"""Validate the completed stage-3 deliverable and preserve the original raw files."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import zipfile

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'outputs/checkwash-ux-stage3-20261026'
HEAD = '5f0af4b40cdc6ed2f20414c76dd748549de67109'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

baseline = json.loads((OUT / 'baseline.json').read_text(encoding='utf-8'))
assert baseline['candidate'] == HEAD and baseline['pr']['head'] == HEAD
assert baseline['pr']['draft'] and not baseline['pr']['merged']
equivalence = json.loads((OUT / 'evidence/source-equivalence.json').read_text(encoding='utf-8'))
assert equivalence['candidate'] == HEAD and equivalence['runtime_tests_tools_action_git_members_identical']
assert equivalence['members'] == 1972 and not equivalence['physical_runtime_mismatch']
cli = json.loads((OUT / 'evidence/root/final-cli-selfdogfood/receipt.json').read_text(encoding='utf-8'))
assert cli['source_sha'] == cli['ending_sha'] == HEAD
assert cli['exit_code'] == 0 and cli['source_files_unchanged']
candidate = json.loads((OUT / 'evidence/root/final-cli-selfdogfood/stdout.txt').read_text(encoding='utf-8'))
assert candidate['verdict'] == 'pass' and candidate['summary'] == {'critical': 0, 'high': 0, 'info': 0, 'warn': 4}
assert not candidate['config_errors'] and not candidate['skipped_files']
action = json.loads((OUT / 'evidence/final-action/replay.json').read_text(encoding='utf-8'))
assert action['head_sha'] == HEAD and action['status'] == 'completed' and not action['errors']
assert all(step['exit_code'] == 0 for step in action['steps'])
assert 'summary: critical=0 high=0 warn=4 info=0 verdict=pass' in (
    OUT / 'evidence/final-action/runtime-receipts/stdout.txt').read_text(encoding='utf-8')
requirements = json.loads((OUT / 'evidence/completion-review/requirements.json').read_text(encoding='utf-8'))
assert sorted(row['problem'] for row in requirements['problem_requirements']) == list(range(1, 15))
assert len(requirements['required_deliverables']) == 5
assert all(row.get('authoritative_evidence') and row.get('delivery_status') and row.get('product_status')
           and row.get('residual_status') for row in requirements['problem_requirements'])
readback = json.loads((ROOT / 'work/ux-stage3/final-readback.json').read_text(encoding='utf-8'))
assert readback['candidate'] == HEAD and readback['policy_packet_complete_and_reviewed']
assert readback['all_goal_delivery_requirements_satisfied']
assert len(readback['requirements']) == 14 and all(
    row['delivery_status'].startswith('SATISFIED_') for row in readback['requirements'])
assert not readback['protected_proposals_applied'] and not readback['publication_resumed']
(OUT / 'final-readback.json').write_bytes((ROOT / 'work/ux-stage3/final-readback.json').read_bytes())
draft = (ROOT / 'work/ux-stage3/report-draft.md').read_text(encoding='utf-8')
report = draft.replace('{{POLICY_REVIEW}}', '[最終獨立複核](evidence/policy-shadow-independent-review/report.md)已核對原24觀察、修訂後header與required-proof／consumer遷移；新IR3程式及其驗收仍未執行。')
assert '{{' not in report and '\ufffd' not in report
(OUT / 'report.md').write_text(report, encoding='utf-8', newline='')
copies = json.loads((OUT / 'copy-provenance.json').read_text(encoding='utf-8'))
assert len({row['destination'] for row in copies}) == len(copies)
for row in copies:
    assert sha(OUT / row['destination']) == row['sha256'], row['destination']
for target in re.findall(r'\]\(([^)]+)\)', report):
    if '://' not in target and target != 'MANIFEST.json':
        assert (OUT / target.split('#', 1)[0]).is_file(), target
files = [{'path': path.relative_to(OUT).as_posix(), 'bytes': path.stat().st_size, 'sha256': sha(path)}
    for path in sorted(OUT.rglob('*')) if path.is_file() and path != OUT / 'MANIFEST.json']
(OUT / 'MANIFEST.json').write_text(json.dumps({'created_utc': datetime.now(timezone.utc).isoformat(),
    'candidate': HEAD, 'runtime_suite_source': '9a5a27f44c895ba2fdee8c83a6313baf0e120873',
    'provenance': 'HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL', 'files': files,
    'note': 'Excludes this manifest; ZIP sidecar hashes the complete archive.'}, indent=2), encoding='utf-8', newline='')
archive = OUT.with_suffix('.zip')
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zipped:
    for path in sorted(OUT.rglob('*')):
        if path.is_file():
            zipped.write(path, OUT.name + '/' + path.relative_to(OUT).as_posix())
digest = sha(archive)
archive.with_suffix('.zip.sha256').write_text(digest + '  ' + archive.name + '\n', encoding='ascii', newline='')
print(json.dumps({'output': str(OUT), 'archive': str(archive), 'sha256': digest,
    'manifest_files': len(files), 'copy_hashes_verified': len(copies)}, indent=2))
