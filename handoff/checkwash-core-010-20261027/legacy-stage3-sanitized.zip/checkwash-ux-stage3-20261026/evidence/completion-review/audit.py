"""Read-only requirement/evidence inventory. Does not import or execute product."""
import datetime
import hashlib
import json
import os
import platform
import re
import socket
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).parent
ROOT = HERE.parents[2]
PRODUCT = ROOT / "work/checkwash-ux"
HANDOFF = ROOT.parent / "new-chat/outputs/checkwash-next-session-handoff-20261026"
SOURCE = "9a5a27f44c895ba2fdee8c83a6313baf0e120873"
DOCS = "5f0af4b40cdc6ed2f20414c76dd748549de67109"
GIT = Path(r"C:\Program Files\Git\cmd\git.exe")
RAW = HERE / "raw"
RAW.mkdir(exist_ok=True)
commands, checks, errors = [], [], []
def sha(data):
    return hashlib.sha256(data).hexdigest()
def js(path):
    return json.loads(path.read_text(encoding="utf-8"))
def save(path, value):
    path.write_bytes((json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))
def check(label, value, detail=None):
    checks.append({"check": label, "passed": bool(value), "detail": detail})
    if not value:
        errors.append(label)
env = {key: value for key, value in os.environ.items() if key.upper() in {"SYSTEMROOT", "WINDIR", "SYSTEMDRIVE", "COMSPEC", "TEMP", "TMP", "PATHEXT"}}
env.update({"GIT_CONFIG_NOSYSTEM": "1", "GIT_CONFIG_GLOBAL": "NUL", "GIT_OPTIONAL_LOCKS": "0", "GIT_TERMINAL_PROMPT": "0", "GCM_INTERACTIVE": "Never", "PYTHONDONTWRITEBYTECODE": "1"})
def read_git(label, *args):
    command = [str(GIT), "--no-optional-locks", "--no-replace-objects", "-c", "core.fsmonitor=false", "--literal-pathspecs", *args]
    result = subprocess.run(command, cwd=PRODUCT, env=env, stdin=subprocess.DEVNULL, capture_output=True, timeout=30)
    (RAW / (label + ".stdout.bin")).write_bytes(result.stdout)
    (RAW / (label + ".stderr.bin")).write_bytes(result.stderr)
    commands.append({"label": label, "command": command, "cwd": str(PRODUCT), "exit": result.returncode,
                     "stdout_sha256": sha(result.stdout), "stderr_sha256": sha(result.stderr)})
    check("read-only-git-exit:" + label, result.returncode == 0)
    return result.stdout

source_paths = [HANDOFF / name for name in ("00-START-HERE.md", "01-修復範圍與優先序.md", "02-驗收與版本決策.md", "04-新session啟動訊息.md", "05-決策與授權狀態.md")]
sealed_checks = []
for package in ("checkwash-ux-milestone-20261026", "checkwash-ux-stage2-20261026"):
    directory = ROOT / "outputs" / package
    manifest = js(directory / "MANIFEST.json")
    source_paths.append(directory / "MANIFEST.json")
    for record in manifest["files"]:
        name = record["path"]
        selected = name in {"report.md", "baseline.json", "native-suite-summary.json", "problem-ledger.json", "claim-register.json"}
        selected = selected or ("candidate-fullsuite-r3/" in name or "final-fullsuite-r2/" in name) and name.endswith(("receipt.json", "stdout.bin", "stdout.txt", "junit.xml"))
        if selected:
            path = directory / name
            actual = path.read_bytes()
            passed = len(actual) == record["bytes"] and sha(actual) == record["sha256"]
            check("sealed-selected-byte-hash:" + package + ":" + name, passed)
            sealed_checks.append({"package": package, "path": name, "sha256": sha(actual), "bytes": len(actual), "matches": passed})
            source_paths.append(path)

additional = [
    "work/rename/report.md", "work/rename/results.json", "work/rename/supplement/results.json",
    "work/rename-crlf/report.md", "work/ux-stage2/proposals/00-D2-E2-proposal.md",
    "work/ux-stage2/proposals/proposal-manifest.json", "work/ux-stage2/proposals-review/report.md",
    "work/ux-stage2/proposals-review/audit.json", "work/ux-stage2/final-compat/report.md",
    "work/ux-stage2/final-compat/comparison.json", "work/ux-stage2/hook-maintenance/report.md",
    "work/ux-stage2/quality/task-review.md", "work/ux-stage2/ruff/report.md", "work/ux-stage2/sweep/report.md",
    "work/ux-stage3/root-junction/results.json", "work/ux-stage3/powershell/report.md",
    "work/ux-stage3/quality-trust/report.md", "work/ux-stage3/quality-trust/proposal/00-decision.md",
    "work/ux-stage3/quality-trust-independent-review/report.md", "work/ux-stage3/quality-trust-independent-review/editorial-followup.json",
    "work/ux-stage3/task-authority/report.md", "work/ux-stage3/task-authority/decision-proposal.md",
    "work/ux-stage3/task-authority/validation.json", "work/ux-stage3/task-authority-independent-review/report.md",
    "work/ux-stage3/policy-shadow/report.md", "work/ux-stage3/policy-shadow/audit.json",
    "work/ux-stage3/policy-shadow-independent-review/audit.json", "work/ux-stage3/source-equivalence.json",
    "work/ux-stage3/root/docs-after/receipt.json", "work/ux-stage3/root/docs-after/stdout.txt",
    "work/ux-stage3/root/final-cli-selfdogfood/receipt.json", "work/ux-stage3/root/final-cli-selfdogfood/stdout.txt",
    "work/ux-stage3/final-action/replay.json", "work/ux-stage3/final-action/runtime-receipts/check-receipt.json",
    "work/ux-stage3/final-action/runtime-receipts/stdout.txt",
]
source_paths += [ROOT / name for name in additional]
snapshot = {str(p): {"sha256": sha(p.read_bytes()), "bytes": p.stat().st_size} for p in source_paths}

head = read_git("current-head", "rev-parse", "HEAD").decode().strip()
status = read_git("current-status", "status", "--porcelain=v1", "--untracked-files=all")
delta = read_git("docs-delta", "diff", "--name-only", SOURCE, "HEAD").decode().splitlines()
runtime_delta = read_git("runtime-delta", "diff", "--name-only", SOURCE, "HEAD", "--", "src", "tests", "tools", "action", "pyproject.toml")
check("current-head-is-documented-docs-candidate", head == DOCS)
check("current-worktree-clean", status == b"")
check("only-two-nonprotected-docs-changed", delta == ["docs/quality-adoption.md", "docs/ux-repair-candidate-2026-10-26.md"] and runtime_delta == b"")

stage1 = js(ROOT / "outputs/checkwash-ux-milestone-20261026/native-suite-summary.json")
stage2 = js(ROOT / "outputs/checkwash-ux-stage2-20261026/native-suite-summary.json")
check("sealed-native-suite-counts", stage1["passed_testcase_nodes"] == 20713 and stage2["passed_testcase_nodes"] == 20833
      and stage1["failed_nodes"] == stage1["error_nodes"] == stage2["failed_nodes"] == stage2["error_nodes"] == 0
      and stage1["skipped_nodes"] == stage2["skipped_nodes"] == 25)
compat = js(ROOT / "work/ux-stage2/final-compat/comparison.json")
check("candidate-rename-36-calls-72-comparisons-zero-differences", compat["cli_calls"] == 36 and compat["comparison_count"] == 72 and compat["differing_pairs"] == 0)
d2 = js(ROOT / "work/ux-stage2/proposals/proposal-manifest.json")
check("d2-exact-inert-draft", d2["modified_judge_executions"] == 0 and sum(item["observations"] for item in d2["evidence"]) == 72 and d2["prediction_counts"] == {"changed": 4, "unchanged": 68})
for name, expected in d2["files"].items():
    check("d2-packet-hash:" + name, sha((ROOT / "work/ux-stage2/proposals" / name).read_bytes()) == expected)
equivalence = js(ROOT / "work/ux-stage3/source-equivalence.json")
check("1972-runtime-members-equivalent", equivalence["candidate"] == DOCS and equivalence["sealed_runtime_source"] == SOURCE
      and equivalence["members"] == 1972 and equivalence["runtime_tests_tools_action_git_members_identical"] and not equivalence["physical_runtime_mismatch"])
cli_receipt = js(ROOT / "work/ux-stage3/root/final-cli-selfdogfood/receipt.json")
cli_payload = js(ROOT / "work/ux-stage3/root/final-cli-selfdogfood/stdout.txt")
check("fresh-candidate-cli-complete", cli_receipt["source_sha"] == cli_receipt["ending_sha"] == DOCS and cli_receipt["exit_code"] == 0
      and cli_receipt["source_files_unchanged"] and cli_payload["verdict"] == "pass" and cli_payload["summary"]["warn"] == 4
      and cli_payload["summary"]["high"] == cli_payload["summary"]["critical"] == 0 and cli_payload["config_errors"] == cli_payload["skipped_files"] == [])
action = js(ROOT / "work/ux-stage3/final-action/replay.json")
check("fresh-public-action-complete", action["status"] == "completed" and action["errors"] == []
      and action["action_sha"] == "d6eda4f695fabb8e7d138f7a87b099d2028f0294" and action["base_sha"] == "1ffe283d7d947fecc426dea99323b0a2620a9482"
      and action["head_sha"] == DOCS and all(step["exit_code"] == 0 for step in action["steps"]) and action["comment_pr"] is False)
docs_receipt = js(ROOT / "work/ux-stage3/root/docs-after/receipt.json")
check("docs-working-diff-four-tests-not-relabeled-fullsuite", docs_receipt["exit_code"] == 0 and docs_receipt["source_sha"] == SOURCE
      and docs_receipt["source_diff_sha256"] != sha(b"") and b"4 passed" in (ROOT / "work/ux-stage3/root/docs-after/stdout.txt").read_bytes())

original_ledger = js(ROOT / "outputs/checkwash-ux-milestone-20261026/problem-ledger.json")
report = (HERE / "report.md").read_text(encoding="utf-8")
problem_rows = []
for line in report.splitlines():
    match = re.match(r"\| \*\*(\d+) — (.*?) \| (.*?) \| (.*?) \|$", line)
    if match:
        number = int(match[1])
        original = next(item for item in original_ledger if item["problem"] == number)
        problem_rows.append({"problem": number, "requirement": match[2].replace("**", ""), "evidence_and_result": match[3],
                             "current_delivery_status_and_residual": match[4], "original_claim_refs": original["original_claim_refs"],
                             "product_bug_closed_claimed": False, "all_subclaims_pass_claimed": False})
check("all-14-requirements-and-original-refs-present", [item["problem"] for item in problem_rows] == list(range(1, 15)) and all(item["original_claim_refs"] for item in problem_rows))
deliverables = []
for line in report.splitlines():
    match = re.match(r"\| \*\*([1-5]) (.*?)\*\* \| (.*?) \|$", line)
    if match:
        deliverables.append({"id": int(match[1]), "requirement": match[2], "evidence_status": match[3]})
check("all-five-deliverables-present", [item["id"] for item in deliverables] == list(range(1, 6)))
save(HERE / "requirements.json", {"scope_source": "requirements-source.md", "source_sha": SOURCE, "docs_candidate": DOCS,
     "problem_requirements": problem_rows, "required_deliverables": deliverables,
     "number7_minimal_case_and_exact_proposal_requirement_satisfied": True, "number7_product_escape_fixed": False,
     "pending_current_requirements": ["Policy-shadow IR3 header/consumer final packet correction and independent readback",
                                       "Final stage3 deliverable/PR ledger integration and candidate remote readback"],
     "fresh_action_pending_resolved": True,
     "not_added_as_current_requirements": ["Natural cohort/cost measurement", "New model/adjudication/history batch", "Official release collector/qualification", "Apply unapproved protected patches", "Merge/bump/tag/publish/repin/resume automations"]})
save(HERE / "evidence-audit.json", {"marker": "HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL", "hostname": socket.gethostname(),
     "runtime": sys.version, "platform": platform.platform(), "audited_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
     "scope": "Read-only completion/evidence audit, no product/fixture/model execution", "current_head": head,
     "checks": checks, "errors": errors, "selected_sealed_files_verified": sealed_checks,
     "source_report_and_raw_snapshot": snapshot, "read_only_git_commands": commands,
     "policy_shadow_packet_status": "PENDING_IR3_HEADER_CONSUMER_REVISION_PER_ROOT; earlier audit not final signoff",
     "new_product_cli_calls": 0, "modified_judge_executions": 0})
print(json.dumps({"checks": len(checks), "errors": errors, "selected_sealed_files_verified": len(sealed_checks),
                  "source_files_snapshotted": len(snapshot), "requirements": len(problem_rows), "deliverables": len(deliverables),
                  "current_head": head, "number7_delivery": "SATISFIED_EXACT_PROPOSAL_NOT_PRODUCT_FIXED"}, indent=2))
sys.exit(0 if not errors else 1)
