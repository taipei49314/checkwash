"""Enrich derived 14-row ledger; standard-library reads, no product execution."""
import datetime
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).parent
ROOT = HERE.parents[2]
def sha(raw):
    return hashlib.sha256(raw).hexdigest()
def save(path, data):
    path.write_bytes((json.dumps(data, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))
path = HERE / "requirements.json"
before = path.read_bytes()
(HERE / "requirements.pre-structured.json").write_bytes(before)
data = json.loads(before)
assert [item["problem"] for item in data["problem_requirements"]] == list(range(1, 15))
evidence = {
  1: ["outputs/checkwash-ux-milestone-20261026/report.md", "work/root-receipts/human-decoration-after/receipt.json"],
  2: ["outputs/checkwash-ux-stage2-20261026/report.md", "work/ux-stage3/root-junction/results.json"],
  3: ["work/ux-stage3/policy-shadow/report.md", "work/ux-stage3/policy-shadow/implementation.patch", "work/ux-stage3/policy-shadow/protected-contract.patch", "work/ux-stage3/policy-shadow-independent-review/audit.json"],
  4: ["work/ux-stage3/task-authority/report.md", "work/ux-stage3/task-authority/decision-proposal.md", "work/ux-stage3/task-authority/validation.json", "work/ux-stage3/task-authority-independent-review/report.md"],
  5: ["work/ux-stage2/hook-maintenance/report.md", "work/ux-stage2/hook-maintenance/native-validation.json"],
  6: ["outputs/checkwash-ux-stage2-20261026/report.md", "work/ux-stage3/powershell/report.md", "work/ux-stage3/powershell/results.json"],
  7: ["work/rename/report.md", "work/rename/results.json", "work/rename/supplement/results.json", "work/ux-stage2/proposals/00-D2-E2-proposal.md", "work/ux-stage2/proposals/01-gating-proposed.patch", "work/ux-stage2/proposals/02-SPEC-proposed.patch", "work/ux-stage2/proposals/proposal-manifest.json", "work/ux-stage2/proposals-review/report.md", "work/ux-stage2/final-compat/comparison.json"],
  8: ["work/rename-crlf/report.md", "work/rename/report.md"],
  9: ["outputs/checkwash-ux-milestone-20261026/report.md", "outputs/checkwash-ux-stage2-20261026/report.md"],
  10: ["outputs/checkwash-ux-milestone-20261026/report.md", "work/ux-stage3/quality-trust/report.md", "work/ux-stage3/quality-trust/proposal/00-decision.md", "work/ux-stage3/quality-trust/proposal/05-option-B-predicate.md", "work/ux-stage3/quality-trust-independent-review/report.md"],
  11: ["outputs/checkwash-ux-milestone-20261026/report.md", "work/root-receipts/namespace-reviewed/receipt.json"],
  12: ["outputs/checkwash-ux-milestone-20261026/report.md", "work/ux-stage2/ruff/report.md", "work/ux-stage2/ruff/validation.json"],
  13: ["work/ux-stage2/quality/task-review.md", "work/ux-stage2/quality/task-review-probe.json", "work/checkwash-ux/docs/task-input.md"],
  14: ["work/sweep-repro/report.md", "work/ux-stage2/sweep/report.md", "work/ux-stage2/sweep/validation.json"],
}
delivery = {
  1: "SATISFIED_BOUNDED_REPAIR", 2: "SATISFIED_DIAGNOSTICS_AND_BOUNDED_CONTROLS",
  3: "PENDING_EXACT_IR3_PACKET_CORRECTION_AND_INDEPENDENT_READBACK",
  4: "SATISFIED_UNAPPLIED_EXACT_CONTRACT_PROPOSAL", 5: "SATISFIED_BOUNDED_DIAGNOSTIC_REPAIR_AND_NATIVE_MECHANISM",
  6: "SATISFIED_BOUNDED_OUTPUT_AND_DOCUMENTATION_REPAIR", 7: "SATISFIED_MINIMAL_REPRODUCTION_AND_UNAPPLIED_EXACT_PROPOSAL",
  8: "SATISFIED_PAIRING_REPRODUCTION_FALSE_BLOCK_NOT_REPRODUCED", 9: "SATISFIED_BOUNDED_IMPLEMENTED_READER_REPAIR",
  10: "SATISFIED_WRITER_REPAIR_AND_UNAPPLIED_TRUST_DECISION_PACKET", 11: "SATISFIED_COMPATIBLE_ADVISORY_REPAIR",
  12: "SATISFIED_BOUNDED_CRLF_JUNCTION_REPAIR_AND_RUFF_DIAGNOSTICS", 13: "SATISFIED_DOCUMENTED_SUBSET_AND_NONMUTATING_DIAGNOSTICS",
  14: "SATISFIED_IMPLEMENTED_INPUT_PARITY_AND_SAFE_COMMIT_DIAGNOSTICS",
}
product = {
  1: "Owned decoration fallback implemented; entire original terminal environment not reproduced.",
  2: "Refusal diagnostics implemented; external traversal admission unchanged and rejected.",
  3: "Effective-source diagnostic implemented; effective-policy shadowing semantic defect remains unfixed.",
  4: "Lookup diagnostic implemented; cwd-versus-repo wrong-BASE authority selection remains unfixed.",
  5: "Tracked-maintenance warning implemented; critical hook guardrail behavior unchanged; no upgrade exemption.",
  6: "Bounded usage/success formats, init guidance and native PowerShell saving documentation implemented.",
  7: "Protected D2/E2 proposal not applied; A/default B/body-context escapes remain observable in current judge.",
  8: "Rename pairing/fingerprint implementation unchanged; measured CRLF pure-move controls pass, alleged false block not reproduced.",
  9: "Exact registered stage0 mode160000 worktree directory reader repair implemented, adjacent true findings retained.",
  10: "Known-QW wrong-ledger writer rejected; existing quality/main BASE trust and second-append critical behavior unchanged.",
  11: "Unknown-key diagnostics implemented; future namespace storage/eligibility retained and not actual-match authority.",
  12: "CRLF-only and Python3.11 exact-junction repairs implemented; Ruff ignore support/qualification unchanged and incomplete.",
  13: "Parser subset docs and diagnostics implemented; parser AST/language and ignored scope/freeze semantics unchanged.",
  14: "Paired pytest input and optional commit diagnostics implemented; counters/exits/analysed denominator retained.",
}
checks = []
for item in data["problem_requirements"]:
    number = item["problem"]
    item["delivery_status"] = delivery[number]
    item["product_status"] = product[number]
    item["residual_status"] = item["current_delivery_status_and_residual"]
    item["authoritative_evidence"] = []
    for relative in evidence[number]:
        file = ROOT / relative
        assert file.is_file(), relative
        item["authoritative_evidence"].append({"path": str(file), "sha256_at_audit": sha(file.read_bytes()),
            "status": "PENDING_IR3_REVISION_SNAPSHOT_NOT_FINAL_SIGNOFF" if number == 3 else "EXISTING_REPORT_RAW_OR_INDEPENDENT_REVIEW",
            "raw_receipt_resolution": "Reports/manifests retain command/stdout/stderr/exit and raw links; a report path is not a fresh product execution."})
    checks.append({"problem": number, "required_fields_present": all(item.get(key) for key in
        ("requirement", "authoritative_evidence", "delivery_status", "product_status", "residual_status", "original_claim_refs")),
        "all_evidence_paths_exist": True, "product_fixed_claimed": False})
assert len(checks) == 14 and all(row["required_fields_present"] for row in checks)
data["status_snapshot_note"] = "Root confirmed fresh Action completed, candidate remote5f0/main1ffe readback exit0; final baseline API snapshot/final integration remains root work. Policy-shadow IR3 packet remains pending."
data["pending_current_requirements"] = ["Policy-shadow IR3 header/consumer final packet correction and independent readback", "Final stage3 deliverable/PR ledger integration with final-baseline snapshot"]
data["structured_completion_audit_checks"] = checks
save(path, data)
initial = HERE / "attempt-01/requirements.json"
record = {"kind": "DERIVED_BOOKKEEPING_CORRECTION_NO_PRODUCT_RUN", "timestamp_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
  "cause": "First Markdown extractor required bold to end at the end of the whole requirement cell; actual bold ended after the label. It produced zero rows and was rejected by the exact1..14 assertion.",
  "original_zero_row_file": str(initial), "original_zero_row_sha256": sha(initial.read_bytes()),
  "original_failed_audit_exit": (HERE / "attempt-01/audit.exit").read_text().strip(),
  "first_fixed_14_row_original": "requirements.pre-structured.json", "first_fixed_14_row_sha256": sha(before),
  "fixed_structured_requirements_sha256": sha(path.read_bytes()), "ids_exactly_1_to_14": [item["problem"] for item in data["problem_requirements"]] == list(range(1, 15)),
  "all_five_deliverables_retained": len(data["required_deliverables"]) == 5,
  "each_row_has_separate_requirement_evidence_delivery_product_residual": all(row["required_fields_present"] for row in checks),
  "product_executions_added": 0, "model_calls_added": 0, "product_or_original_raw_modified": False,
  "scope": "Correct derived audit rows and explicit evidence/status structure only; earlier read-only Git/hash audit rerun executed no product."}
save(HERE / "requirements-correction.json", record)
print(json.dumps({"requirements": len(checks), "ids_exactly_1_to_14": record["ids_exactly_1_to_14"],
                  "separate_status_fields": record["each_row_has_separate_requirement_evidence_delivery_product_residual"],
                  "authoritative_evidence_paths": sum(len(item["authoritative_evidence"]) for item in data["problem_requirements"]),
                  "pending": data["pending_current_requirements"], "requirements_sha256": sha(path.read_bytes())}, indent=2))
