# Goal completion audit — requirements, evidence and remaining work

The bounded repair/decision goal is close to completion, but at this audit
snapshot it still has a concrete pending policy-shadow packet revision and
final delivery work. **This does not mean all 14 product defects are fixed.**
The current objective expressly permits an exact, reviewable decision package
for protected/frozen changes that have not been approved for implementation.
The exact objective and handoff sources are retained in `requirements-source.md`.

`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`. This audit uses existing reports,
raw receipts, manifests and bounded read-only Git operations. It launches no
product CLI, fixture program, test suite, model or historical batch. Product
and original evidence remain read-only. Statuses below distinguish the repair
goal's delivery requirements from product bug closure.

## Source and validation baseline

| Role | Exact source / evidence / limit |
|---|---|
| Public upgrade baseline | v0.9.0 `d6eda4f695fabb8e7d138f7a87b099d2028f0294` remains separate from unpublished v0.9.1 `1ffe283d7d947fecc426dea99323b0a2620a9482`. Existing tag/failure records are preserved. No new remote publication assertion is made by this local audit. |
| First sealed candidate | `f86aabbbe7e61891d8b93cb2c043b9bcae44f88a`, 8 named repairs; 20,713 passed / 25 skipped / 67 passed subtests, exit0; candidate and public Action self-dogfood retained. See `outputs/checkwash-ux-milestone-20261026/`. |
| Second sealed judge | `9a5a27f44c895ba2fdee8c83a6313baf0e120873`, 19 total named repairs; 20,833 passed / 25 skipped / 67 passed subtests, exit0; 20,858 collection is a denominator, not a passed count. See `outputs/checkwash-ux-stage2-20261026/`. |
| Current docs candidate | `5f0af4b40cdc6ed2f20414c76dd748549de67109`; only `docs/quality-adoption.md` and `docs/ux-repair-candidate-2026-10-26.md` differ from 9a5a. Full suite remains attributed to 9a5a judge source, not a new 5f0 suite. |
| New docs verification | `work/ux-stage3/root/docs-after/`: 4 passed, exit0, receipt records 9a5a plus its exact working diff, later committed as docs-only 5f0. |
| Fresh candidate CLI | `work/ux-stage3/root/final-cli-selfdogfood/`: exact 1ffe..5f0 range, source/ending5f0, stable inputs, exit0/pass, 4warn, no high/critical/config errors/skipped files. |
| Fresh public Action | Final `work/ux-stage3/final-action/replay.json` is now `completed`, `errors=[]`, install/check exit0, exact public Action d6eda4f6 on1ffe..5f0, high threshold, comment_pr=false. Local PJU replay, not a GitHub runner or release qualification. |

## Fourteen requirements

Original cluster+claim IDs are preserved without deduplication in the sealed
`problem-ledger.json` / `claim-register.json`; `requirements.json` carries
each row's original references into this current completion ledger. A row's
delivery status is not a claim that every underlying static subclaim is
confirmed or fixed.

| # / requirement | Evidence and present result | Delivery status / precise residual |
|---|---|---|
| **1 — encoding:** controlled stream reproduction, readable owned decorations, evidence/machine encoding retained | Stage1 cp950/cp1252/ASCII/UTF8 controls and 12 targeted tests; source-owned glyph/separator fallback implemented. | **Met, bounded repair.** Original complete user terminal not available/replayed; do not claim all message decorations or shell combinations fixed. No need to invent the absent terminal environment before delivering the repair. |
| **2 — main junction:** actual Git-listed entry, inside/outside controls, safe refusal context | Stage1 4 native CLI prove actual tracked entry and outside refusal / hook NOT_ANALYSED; stage2 reader/nonregular diagnostics; stage3 `root-junction/results.json` has 6 clean/weak JSON/hook controls with full physical/alias payload equality. | **Met, bounded diagnostics and native controls.** External traversal remains refused. Only existing C: root-junction topology is established; cross-drive/file-symlink capabilities remain NOT_RUN. No shared-admission expansion is required or authorized. |
| **3 — policy shadowing:** visible effective source, migration/next-BASE counterexample, exact policy proposal | Doctor source visibility is implemented. Stage3 `policy-shadow/` has 12 cases / 24 native calls, strict→loose, equal/tightened migration, independent config/allow precedence and next-BASE adjacent real findings; exact inert code/SPEC/DECISIONS/movement/cost files exist. | **Pending packet revision/review.** Root reports an IR3 header/consumer consistency revision still being prepared. Complete that exact revision and independent readback, without applying it. Current product shadowing defect remains unimplemented. Other residuals/platforms are disclosed, not silently promoted into current implementation scope. |
| **4 — task authority:** repo-relative semantic mismatch, exact binding/migration with BASE and refusal controls | Stage2 diagnostic implemented. Stage3 `task-authority/` has 20 native calls including wrong-existing-BASE PASS/BLOCK selection, absolute positives, repo/subdirectory/cwd, real junction and #416/#500 boundaries; exact original-`args.repo_given` lexical-join diff and SPEC/DECISIONS text. Independent review accepts corrected raw-vs-LF provenance. | **Met as protected/frozen decision package; semantic fix not applied.** All 20 proposed movements are NOT_RUN forecasts. Root-relative, UNC, drive-relative repo, different-drive combinations and actual file symlink are explicit future acceptance gaps; they do not invalidate the measured wrong-BASE witnesses or require a host change now. |
| **5 — hook maintenance:** actual doctor/reinstall mechanism, adjacent clean, safe preview/review guidance | `ux-stage2/hook-maintenance/`: real tracked legacy Stop→doctor→hook install→critical BLOCK, clean prior control; 42passed/1skip regression and raw validation. Tracked warning implemented. | **Met, bounded diagnostics/mechanism.** No managed-upgrade exception; full historical upgrade/Claude lifecycle not executed. A trust exception needs a separate exact decision; current goal does not authorize it. |
| **6 — quality output:** usage/success requested formats, setup authority and save guidance | Stage1 usage envelope fixes; stage2 explain/profiles/init slices with existing-envelope controls; stage3 7 native PS5.1/7.6 draft-save calls, actual UTF16 failure and explicit UTF8 positive controls, docs fix. | **Met, bounded output/docs repair.** PS5 initial receipt timestamp/map omissions and harness path failure remain disclosed; exact native saved bytes establish the local serialization result. Other terminals/profiles are NOT_RUN. |
| **7 — rename/oracle:** A/B, unroll, legitimate move/refactor controls and exact policy choice with costs | `work/rename/` 72 old CLI (36 paired old-version observations), `ux-stage2/final-compat/` 36 candidate CLI / 72 comparisons / zero differences; `ux-stage2/proposals/` exact two-site D2/E2 gating/SPEC/DECISIONS draft, 72-row forecasts, hashes and independent review. | **Met for this goal's minimum reproduction + exact proposal. Product escape remains unclosed.** See dedicated judgment below. No protected implementation, empirical refactor-cost claim, D5-wide repair or new model/natural cohort is required to complete this bounded proposal delivery. |
| **8 — rename input parity:** isolate disk CRLF vs blobLF and preserve findings/fingerprints | `work/rename-crlf/`: 8 native calls, autocrlf false/true × disk LF/CRLF × worktree/range. Actual pairing differs; all pure-move verdicts PASS. LF decorator cochange still worktree PASS/range BLOCK. | **Met as reproduced pairing / not-reproduced pure-move false-block classification.** Do not say the alleged CRLF-only false block was fixed. Similarity/context/fingerprint redesign remains frozen/minor work; no broad matrix is required by this specific control. |
| **9 — registered gitlink:** exact mode160000 and adjacent real weakening | Stage1 reader fix red18fail/4pass→22pass plus191pass/9skip; pointer/dirty/untracked controls, ordinary directory/nested repo negatives and checked-out context. Adjacent weak JSON/block and hook decision:block retained. | **Met, implemented narrow fix.** Only exact stage0 mode160000 actual-directory treatment; arbitrary directory skip is not authorized. |
| **10 — quality ledger/trust:** reject wrong writer, second append/tightening actual controls and reviewable trust choice | Known QW wrong-ledger rejection implemented. Stage1 report→enforce controls. Stage3 `quality-trust/` 18 native calls cover report/enforce second append, exact valid BASE, HEAD-only key, expired/wrong-target nonmatch, unknown/malformed hard error. A/B exact inert packet independently reviewed, editorial approval→entry resolved. | **Met, bounded writer repair + trust decision package.** A retains prior-BASE/two-lane review; B not recommended/adopted/implemented, existing BASE entries are not proof of human review. Guardrail friction remains. |
| **11 — unknown fingerprint:** explain loaded/recognized/eligible/matched distinction without banning future namespaces | Stage1 writer/reader/doctor advisory, future namespace and valid exemption controls, control-character safe display;15targeted pass. | **Met, implemented advisory repair.** Eligibility still is not actual finding match or approval; forward compatibility is deliberately retained. |
| **12 — quality CRLF/junction/Ruff:** narrow byte boundary, native3.11 junction, incomplete reasons without fake qualification | Stage1 None-safe CRLF and exact junction-tag fixes, true content controls and273focused pass; stage2 Ruff16new +236related,12payload pairs except messages identical,6normal-format byte pairs equal. | **Met, bounded fixes/diagnostics.** No new Ruff ignore/preview profile qualified; comment-only ignores remain incomplete. Support expansion is a separate capability/qualification decision, not a missing required implementation. |
| **13 — TASK parser:** accepted subset documentation and non-mutating ignored-syntax diagnostics | Stage2 `task-input.md`, parser source unchanged,12note/parser controls; dedicated syntax/path tests22pass and independent review, stderr safe/source-specific. | **Met under handoff's narrow A option.** No YAML expansion, empty-list/fail-closed redefinition, dependency or automatic scope activation. Parser probes are not runtime exploit results. A semantic language change requires a new exact decision if requested. |
| **14 — sweep parity/diagnostics:** same commit range vs sweep, stable counters/normal bytes, full commit identity | Stage1 paired pytest configs fixed with4synthetic parity cases; stage2 optional commit_diagnostics20targeted +24synthetic CLI,6before/after controls, normal2summary bytes equal, full SHA/known parent/phase/kind and safe exception type/reason. | **Met, implemented narrow fixes.** Original counters/exit/analysed denominator preserved; historical results are not revalidated and arbitrary exception strings are deliberately not copied. No historical sweep is required or authorized. |

## Explicit #7 judgment

**Yes: the existing packet satisfies the minimum-case and reviewable-proposal
requirement in handoff01/02/04 and the exact active objective.** This judgment
is tied to its narrow named mechanism, not to closing every oracle escape.

The evidence separates original A and B/B-from-A, changed literal unroll,
pure rename, expectation-preserving unroll, same-name weakening, pure
cross-file move and cross-file parameter-only change across both entrances,
freeze settings and both old sources. The candidate's new 36 calls retain
the entire finding dictionaries, fingerprints, verdicts and errors in all
72 old/candidate comparisons. The literal unroll escape prediction was
refuted; that result is retained. Legitimate controls are present, rather
than a matrix scored only on exploit shapes.

The exact proposed edit applies E2 at two assertion-text D2 early returns
while still consuming credit/retaining ASSERTION_MOVED. It preserves prior
allowlist priority and leaves whole-body D2/D10 and D5 unchanged. Exact frozen
patches, six hunk contexts, hashes, SPEC/DECISIONS text, independently resolved
72 raw pointers and a supersession record distinguish it from the discarded
"withhold credit and continue through other gates" alternative. Four A×freeze
movements and68unchanged are clearly predictions, not a tested improvement.

Costs and remaining failures are substantive: honest text-only movement can
be blocked under freeze when body proof is unavailable; that cost is not
empirically measured. ASSERT_REMOVED lacks a direct witness in the retained
matrix; JS/TS and non-default thresholds are not covered. Default A/B,
cross-file whole-body/decorator escape, D5 equivalence, D10/context and #419
production repair routes remain unresolved. These are required acceptance
work **if that protected implementation is adopted**, not conditions that
retroactively turn a permitted unimplemented proposal into a failed current
delivery. The final report must not label #7 simply FIXED or claim complete
oracle protection.

## Five required deliverables

| Handoff02 deliverable | Evidence / assessment |
|---|---|
| **1 Baseline table** | **Met.** Both sealed baselines include host/OS/Python/Git/shell/source/worktree/env/settings. PJU label explicit. Current docs-only5f0 provenance and9a suite attribution must remain separate. |
| **2 Traceable problem table** | **Met for original14 and127 static claims; current update pending final integration.** Sealed claim register preserves cluster+claim pointers, commands/raw exits/entrypoints and NOT_RUN distinctions. This audit supplies the14-row updated matrix, but root must incorporate final policy-shadow/replay outcomes into the user-facing current packet. No claim-level127PASS statement is valid. |
| **3 Repair slices** | **Met.** 19 implemented named repairs plus stage3 docs; protected/frozen, diagnostics and residuals distinguished with controls/compatibility costs. A residual is not automatically a newly authorized implementation task. |
| **4 Version recommendation** | **Met.** No bump. Bounded UX candidate may be0.9.2 subject to applicable compatibility; D2/E2/TASK/shadow semantic and identity/IR changes need explicit minor decisions, provisionally0.10.0. Both public0.9.0 and unpublished0.9.1 upgrade tracks are retained. |
| **5 Completed narrow fixes and regressions** | **Met on9a judge, with5f0docs checks/replay.** Two sealed suites, red/green controls, original failures, bounded compatibility, independent reviews and actual public Action/candidate self-dogfood are present. New5f0CLI and public Action replay both complete successfully. Protected exact packets must finish review but need not be applied under this authorization. |

## Concrete work still required to mark this goal complete

1. Finish policy-shadow's IR3 header/consumer/schema-consistency revision,
   preserve its prior raw evidence, and obtain a clean independent readback
   of the revised inert decision package. This is the remaining exact-package
   defect root has identified; it is not permission to apply the patch.
2. Consolidate current stage3 evidence/decisions and this14×5 status into
   the final reviewable candidate deliverable/PR ledger, including exact
   candidate SHA, suite-source/doc-source distinction, package hashes,
   residuals and unadopted decisions. Preserve the two sealed packages.

No additional authorized independent product repair has been identified as
missing by this audit. Maintainer approval/application of protected edits,
natural-cohort cost measurement, model/adjudication batches, complete release
qualification/collector, formal release check bridges, merge/bump/tag/publish,
downstream repin and automation resume remain distinct future work. They
must not be silently declared done, but they are not added as prerequisites
for this goal's explicitly permitted unimplemented decision delivery.

The fresh Action pending status in the initial snapshot is now resolved:
`replay.json` completed with both steps0 on the exact5f0 range. Root also
records a successful5f0 push to draft PR566 and subsequent native remote
readback exit0 showing candidate5f0/main1ffe. That readback is root's primary
observation, not an independent network query made by this audit; the final
baseline API snapshot will be incorporated in the final integration. No main
movement is inferred from that candidate push. `source-equivalence.json` records1,972 unchanged tracked
runtime/test/tool/action members between9a and5f0; it does not relabel the
9a full suite as a new5f0 whole-suite run.

The remaining pending list is a timestamped snapshot. If root subsequently completes
the exact package/final integration, update these statuses against
their new evidence; do not restart completed matrices or expand scope to
keep the goal open. Conversely, do not mark the goal complete merely because
most work is done while an identified exact-package correction is pending.

## Audit integrity and structured ledger

`requirements.json` has exactly14 problem rows with IDs1..14, original
cluster+claim references, explicit requirement,46 existing absolute evidence
paths/hashes, and separate delivery_status, product_status and residual_status
fields. It also retains all five required deliverables. No row claims all
underlying static subclaims passed, and no row is used to close a product bug.

The read-only metadata audit exits0:38 integrity checks,15 selected sealed
manifest members verified,57 report/raw source files snapshotted. This is
not38 product tests or a fresh all-file audit of every sealed artifact.
Existing detailed raw/source audits are attributed to their independent
review reports. This audit performs no product, fixture or model execution.

The first derived Markdown extractor returned zero problem rows because it
assumed the bold label spanned the entire first table cell. The exact-ID
assertion caught it, so that attempt exited1 rather than accepting an empty
ledger. Original script/requirements/audit/stdout/stderr/exit remain in
`attempt-01/`. The extractor was corrected, its14-row output is preserved
as `requirements.pre-structured.json`, then standard-library-only enrichment
added separate status fields/evidence paths with its own exit0 receipt.
`requirements-correction.json` records exact original/corrected hashes and
the absence of added product runs or changes to product/original raw evidence.
To regenerate derived rows, run the owned metadata audit followed by its
structure_requirements enrichment; neither is a product acceptance run.
