"""Independent byte/metadata readback only; no proposal/product import or run."""
import datetime
import hashlib
import json
import socket
import sys
from pathlib import Path

HERE = Path(__file__).parent
PACKET = HERE.parent / "policy-shadow"
checks, errors = [], []
def sha(raw):
    return hashlib.sha256(raw).hexdigest()
def js(path):
    return json.loads(path.read_text(encoding="utf-8"))
def check(name, passed, detail=None):
    checks.append({"check": name, "passed": bool(passed), "detail": detail})
    if not passed:
        errors.append(name)
def files_match(directory, records, prefix):
    for name, meta in records.items():
        path = directory / name
        raw = path.read_bytes()
        check(prefix + name, len(raw) == meta["size"] and sha(raw) == meta["sha256"])

revision = PACKET / "revision-backslash"
completion = js(revision / "completion.json")
before = js(revision / "before.json")
native_path = PACKET / before["native_manifest"]
native = js(native_path)
check("completion-preservation-manifest-raw-hash", sha((revision / "before.json").read_bytes()) == completion["preservation_manifest_sha256"])
check("native-preservation-manifest-raw-hash", sha(native_path.read_bytes()) == before["native_manifest_sha256"])
check("original-native-counts", len(native["immutable_native_evidence"]) == completion["native_files_checked"] == before["native_files_verified"] == 1062
      and native["native_cli_count"] == completion["original_native_cli_calls"] == before["native_cli_calls"] == 24
      and native["native_command_count"] == completion["original_native_commands"] == before["native_commands"] == 186)
files_match(PACKET, native["immutable_native_evidence"], "native-byte-preservation:")
check("backslash-prerevision-packet-exactly30", len(before["preserved_packet"]) == completion["preserved_before_packet_files"] == 30)
files_match(revision / "original", before["preserved_packet"], "preserved-before-backslash:")
files_match(PACKET / "revision-ir3/original", native["preserved_original_packet"], "preserved-before-ir3:")

journal = js(PACKET / "journal.json")
observations = js(PACKET / "observations.json")
receipt = js(PACKET / "receipt.json")
check("actual-journal186-and-observations24", len(journal) == 186 and len(observations) == receipt["cli_calls"] == 24
      and sorted(row["cli_number"] for row in observations) == list(range(1, 25)))
check("actual-unique-native-command-names", len({item["name"] for item in journal}) == 186)
for item in journal:
    for stream in ("stdout", "stderr"):
        path = PACKET / "raw" / (item["name"] + "." + stream)
        check("original-raw:" + item["name"] + ":" + stream, sha(path.read_bytes()) == item[stream + "_sha256"])
by_name = {item["name"]: item for item in journal}
for row in observations:
    raw = (PACKET / "raw" / (row["raw_name"] + ".stdout")).read_bytes()
    check("original-cli-payload:" + row["raw_name"], json.loads(raw) == row["payload"] and by_name[row["raw_name"]]["exit"] == row["exit"])

expected = {
    "implementation.patch": "7ab91501aecaa05ed47a130d2f2d61cb27a96139a63ec1be49c138270385abdf",
    "consumer-migration.patch": "6f5458ecdfcf0651968e9fef16993faf1e26b6da2235364065c3e5656973958b",
    "protected-contract.patch": "8ad77c27e78122889a251af189a130f7f173292415868c1139d813fe5ed4e7ab",
}
for name, expected_hash in expected.items():
    check("root-requested-final-patch-raw-hash:" + name, sha((PACKET / name).read_bytes()) == completion["packet_hashes"][name] == expected_hash)
for name, expected_hash in completion["packet_hashes"].items():
    check("completion-packet-current-raw-hash:" + name, sha((PACKET / name).read_bytes()) == expected_hash)
check("protected-draft-unchanged-through-backslash-correction", sha((PACKET / "protected-contract.patch").read_bytes()) == before["preserved_packet"]["protected-contract.patch"]["sha256"])
check("metadata-source-boundaries", completion["source"] == "9a5a27f44c895ba2fdee8c83a6313baf0e120873"
      and completion["observed_current_head"] == "5f0af4b40cdc6ed2f20414c76dd748549de67109" and completion["current_product_status"] == ""
      and completion["runtime_tool_test_action_blobs_same"] and completion["native_files_unchanged"])
check("zero-execution-declarations-and-unexecuted-api-controls", completion["product_calls_in_correction"] == 0
      and not any(completion[key] for key in ("modified_judge_executed", "patch_applied", "proposed_source_imported", "proposed_source_compiled"))
      and completion["added_api_controls"] == "NOT_EXECUTED_NOT_NATIVE_CLI25"
      and completion["counterexample_kind"] == "SOURCE_LEVEL_PREVIOUS_INERT_PATCH")
record = {
    "marker": "HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL", "hostname": socket.gethostname(), "runtime": sys.version,
    "reviewed_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "reviewer": "/root/rename_repro; metadata/preservation only; source semantic final review owned by /root/quality_fix",
    "source_runtime": completion["source"], "docs_candidate": completion["observed_current_head"],
    "scope": "Read/hash/parse original bytes and metadata only; no proposed source constructed/applied/imported/compiled/executed; no new product CLI",
    "preservation_status": "PASS" if not errors else "BLOCKED", "errors": errors, "checks": checks,
    "native_files_independently_rehashed": 1062, "original_native_cli_observations": 24,
    "original_native_commands": 186, "original_raw_streams_independently_rehashed": 372,
    "before_backslash_files_independently_rehashed": 30, "before_ir3_files_independently_rehashed": len(native["preserved_original_packet"]),
    "final_patch_raw_sha256": expected,
    "revision_completion_sha256": sha((revision / "completion.json").read_bytes()),
    "preservation_before_sha256": sha((revision / "before.json").read_bytes()),
    "semantics_final_signoff": "NOT_OWNED_BY_THIS_REVIEW; root must resolve with quality_fix final source review",
    "completion_pending_resolution": "Preservation/metadata correction is resolved if PASS; semantic signoff and final artifact integration remain independently required.",
    "new_product_cli_calls_by_this_review": 0, "modified_judge_executions_by_this_review": 0,
    "limits": "Recorded zero-execution declarations are checked as metadata, not independent proof of every historical process. Byte identity proves the recorded original native evidence was preserved."}
(HERE / "policy-final-preservation-readback.json").write_bytes((json.dumps(record, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))
print(json.dumps({"preservation_status": record["preservation_status"], "checks": len(checks), "errors": errors,
                  "native_files": 1062, "original_cli": 24, "original_commands": 186, "preserved_before_backslash": 30,
                  "preserved_before_ir3": len(native["preserved_original_packet"]), "final_patch_raw_sha256": expected,
                  "readback_sha256": sha((HERE / "policy-final-preservation-readback.json").read_bytes())}, indent=2))
sys.exit(0 if not errors else 1)
