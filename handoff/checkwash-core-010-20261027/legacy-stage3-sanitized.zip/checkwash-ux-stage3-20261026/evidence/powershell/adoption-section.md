### Saving drafts in PowerShell

By default, Windows PowerShell 5.1 writes UTF-16LE with `>`; Checkwash's TOML input requires
UTF-8. Use an explicit encoding when saving a draft. Capture the command's exit
code before writing, so a failed initialization does not become a policy file:

```powershell
$draft = checkwash quality init
if ($LASTEXITCODE -ne 0) { throw 'Quality draft generation failed' }
$draft | Set-Content -LiteralPath ./quality-draft.toml -Encoding UTF8
```

The UTF-8 BOM produced by Windows PowerShell 5.1's `Set-Content -Encoding UTF8`
is accepted. PowerShell 7.6 also accepts this recipe. These commands save only
the separate draft; inspect it before installing `.checkwash/quality.toml`.
They do not change your PowerShell profile or encoding defaults. Microsoft
documents the shell's [encoding and redirection behavior](https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_character_encoding?view=powershell-5.1).

With `--format json`, the whole response is an advisory setup envelope, not
TOML. Save its `policy_toml` field instead:

```powershell
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$setup = checkwash quality init --format json | ConvertFrom-Json
if ($LASTEXITCODE -ne 0 -or $setup.state -ne 'draft') { throw 'Quality draft generation failed' }
[System.IO.File]::WriteAllText((Join-Path $PWD 'quality-draft.toml'), $setup.policy_toml, (New-Object System.Text.UTF8Encoding($false)))
```

For native UTF-8 JSON containing non-ASCII metadata, the first line makes the
current PowerShell process decode native output as UTF-8. It does not control
`>` file encoding or change the PowerShell profile.
