# Native PowerShell quality draft saving

Source: `9a5a27f44c895ba2fdee8c83a6313baf0e120873`; host
`LAPTOP-01AGNPJU`, Python 3.11.9;
`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`.

The owned fixture contains coverage configuration and a tracked Unicode-named
Python source. That source is static input only. No coverage tool, fixture
Python, Claude lifecycle, paid/model call or historical sweep runs.

## Observed outcomes

Seven native CheckWash CLI calls completed: one direct reference, three in
Windows PowerShell 5.1.26100.9711 and three in PowerShell 7.6.5. The current
child process Console.OutputEncoding was UTF-8; no profile/host/security
setting was changed. The saved bytes were then read with the unchanged trusted
9a5a quality policy parser.

| Shell / save operation | Actual bytes / result |
|---|---|
| PS5.1 direct `>` | UTF-16LE BOM `fffe`; POLICY_INVALID / Invalid UTF-8 TOML source. |
| PS5.1 `Set-Content -Encoding UTF8` | UTF-8 BOM `efbbbf`; valid, same parsed policy as reference. |
| PS5.1 JSON `policy_toml` via explicit UTF8 WriteAllText | No BOM; valid, same parsed policy. |
| PS7.6.5 direct `>` | UTF-8; valid, same parsed policy. |
| PS7.6.5 explicit UTF8 and JSON extraction | Both valid, same parsed policy. |

The term draft escapes the Unicode path as TOML code-point escapes and the
direct reference is ASCII. The JSON extraction example explicitly sets the
current process native decoder to UTF-8 so non-ASCII metadata is preserved.
These controls establish these exact local shell versions, not all terminals,
profiles or redirection implementations.

`results.json` records shell versions, saved byte prefixes, hashes and parser
outcomes. Original saved TOML and stdout/stderr remain beside it. PS5.1 stderr
contains its module-first-use CLIXML progress stream; it is retained and is
not labeled empty stderr or a product failure.

## Retained driver failure and evidence limit

`run.py` finished the direct reference and PS5.1 group, then stopped exit1
before PS7 because it assumed a Program Files executable that is absent.
`initial-driver-failure.json` records that failure. The existing bundled pwsh
was discovered with Get-Command; `finish.py` ran only the missing PS7 group,
then validated all original saved bytes. The PS5.1 product calls and raw bytes
were not rerun or overwritten.

The initial driver did not persist per-command timestamps or its before-source
map before failing. We do not represent that partial driver as a complete
qualification receipt. PS7 has a full command/time/exit receipt and complete
source maps before/after; product HEAD/status and source bytes remain 9a5a.
The raw PS5.1 observations and later parser validation still directly establish
the local encoding failure and successful draft saves.

## Bounded repair

`adoption-section.md` / `adoption-proposed.patch` add tested exit-checked draft
recipes to the adoption guide. They do not add UTF-16 admission, write a policy
from the tool, change the setup advisory authority, or replace an existing
policy. JSON is extracted from policy_toml rather than saving the whole setup
envelope as TOML. This is a documentation repair for shell serialization.

Microsoft's primary description confirms PS5.1 default redirection is UTF-16LE
and explicit UTF8 creates a BOM; PowerShell 6+ defaults differ:
[about_Character_Encoding](https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_character_encoding?view=powershell-5.1).
