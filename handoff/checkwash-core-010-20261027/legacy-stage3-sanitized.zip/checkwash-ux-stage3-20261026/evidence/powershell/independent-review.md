# Read-only review of PowerShell draft-save adoption

Result: **no blocking finding** in `adoption-section.md` or
`adoption-proposed.patch` against the recorded bounded controls.

HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL; reviewer `/root/quality_fix`.
The review read existing text/JSON/raw bytes and used Python standard-library
hashing, base64 decoding and TOML parsing only. It did not launch PowerShell,
CheckWash, fixture Python, an external quality tool or a modified judge.
No product, existing raw or adoption draft was changed by this reviewer.

## Evidence checked

- All six saved-file lengths, SHA-256 and eight-byte prefixes match
  `results.json`. PS5.1 `>` is UTF-16LE with BOM; its recorded
  POLICY_INVALID/Invalid UTF-8 TOML source is the expected failure.
- The other five files decode as UTF-8 (with or without BOM) and independently
  parse through standard-library TOML to the same object as the unchanged
  `reference.stdout`. This checks the Unicode target path as parsed data,
  rather than claiming raw byte equality across redirection methods.
- The recorded shells are Windows PowerShell 5.1.26100.9711 and PowerShell
  7.6.5, both with the child console decoder set to UTF-8. The docs do not
  generalize these controls into all terminals/profiles/platforms.
- The PS7 receipt has exit0, and decoding its actual EncodedCommand produces
  exactly `decoded_shell_code`. Its before/after source maps are equal.
- The initial failure is retained, not relabeled as a complete receipt. It
  follows the reference/PS5.1 calls and precedes the missing PS7 group. The
  report explicitly preserves the absent initial per-command timestamps and
  before-source-map limitation. No duplicate PS5.1 execution is claimed.
- The adoption patch's one hunk has valid old/new counts and exact unchanged
  context against `9a5a27f4:docs/quality-adoption.md`. This was a line-context
  check; the patch was not applied.

## Recipe and authority review

Both recipes check the native command's exit status before saving; the JSON
form also checks state=draft and extracts `policy_toml`, rather than treating
the complete advisory envelope as TOML. The explicit UTF8/BOM behavior is
consistent with the saved bytes. The term draft is ASCII with TOML Unicode
escapes, so its first recipe does not rely on decoding non-ASCII metadata.

The JSON recipe's Console.OutputEncoding setting applies to the current
PowerShell process's native decoder. The text correctly distinguishes that
from `>` file encoding and from changing a profile. It writes only a separate
draft, requires inspection before installation, adds no UTF-16 admission and
does not convert advisory setup into review authority. The recorded setup
authority remains advisory_only.

The initial-driver/source-map limit means these are native serialization
controls, not complete fixed-artifact qualification or a historical shell
compatibility claim. The proposed documentation respects that limit.

## Need for another PS5.1 run

No additional run is needed to support the bounded draft-saving documentation:
the original saved bytes directly show the UTF-16 failure and explicit UTF-8
success, later unchanged trusted-parser checks establish their policy values,
and the missing initial timestamps/before-map are already disclosed. Requiring
another receipt would only be necessary if the claim were upgraded to complete
source-bound PS5.1 qualification; this documentation makes no such claim.

The seven native calls were one Python module reference plus three module
calls in each shell (`python -B -m checkwash`), not an independently installed
`checkwash.exe` console shim. Using the documented `checkwash` entrypoint is
a source-level equivalence inference for the shell-saving recipe, not a claim
that the shim was exercised. Preserve that distinction in evidence summaries.
The actual PS5.1 stderr starts with CLIXML progress output; it is retained and
must not be described as empty or as a failed product call.
