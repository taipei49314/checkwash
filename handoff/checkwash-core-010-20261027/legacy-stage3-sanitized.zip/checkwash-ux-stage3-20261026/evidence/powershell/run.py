"""Owned native-shell draft-saving controls; no analyzed fixture code executes."""
import base64
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
PRODUCT = ROOT / 'work/checkwash-ux'
HEAD = '9a5a27f44c895ba2fdee8c83a6313baf0e120873'
SPEC = importlib.util.spec_from_file_location('trusted_replay', ROOT / 'work/trusted/replay_pju_action.py')
replay = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(replay)
TEMP = HERE / 'private'
TEMP.mkdir(exist_ok=False)
env = replay.clean_environment(Path(sys.executable), Path(r'C:\Program Files\Git\cmd\git.exe'),
    Path(r'C:\Program Files\Git\bin\bash.exe'), TEMP)
template = TEMP / 'git-template'
template.mkdir()
env.update(PYTHONPATH=str(PRODUCT / 'src'), GIT_TEMPLATE_DIR=str(template), CW_PYTHON=sys.executable)
records = []

def git(*args, cwd=PRODUCT):
    return subprocess.run(['git', *args], cwd=cwd, env=env, capture_output=True, check=True).stdout

assert git('rev-parse', 'HEAD').decode().strip() == HEAD
before = {p.relative_to(PRODUCT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
          for p in (PRODUCT / 'src').rglob('*.py')}
repo = HERE / 'fixture'
repo.mkdir(exist_ok=False)
git('init', '-b', 'main', cwd=repo)
git('config', 'user.name', 'Owned draft fixture', cwd=repo)
git('config', 'user.email', 'fixture@example.invalid', cwd=repo)
git('config', 'core.autocrlf', 'false', cwd=repo)
(repo / 'src').mkdir()
subject = 'src/範例.py'
(repo / subject).write_bytes(b'VALUE = 1\n')
(repo / 'pyproject.toml').write_bytes(b'[tool.coverage.report]\nfail_under=85\n')
git('add', '.', cwd=repo)
git('-c', 'commit.gpgsign=false', 'commit', '-m', 'owned baseline', cwd=repo)
env.update(CW_REPO=str(repo), CW_OUTPUT=str(HERE), CW_SUBJECT=subject)

def run(label, command, *, shell_code=None):
    tick = datetime.now(timezone.utc).isoformat()
    result = subprocess.run(command, cwd=repo, env=env, capture_output=True, timeout=120)
    (HERE / (label + '.stdout')).write_bytes(result.stdout)
    (HERE / (label + '.stderr')).write_bytes(result.stderr)
    records.append({'label': label, 'command': command, 'decoded_shell_code': shell_code,
        'cwd': str(repo), 'started_utc': tick, 'ended_utc': datetime.now(timezone.utc).isoformat(),
        'exit_code': result.returncode, 'stdout_sha256': hashlib.sha256(result.stdout).hexdigest(),
        'stderr_sha256': hashlib.sha256(result.stderr).hexdigest()})
    assert result.returncode == 0, (label, result.returncode)
    return result.stdout

reference = run('reference', [sys.executable, '-B', '-m', 'checkwash', 'quality', 'init',
    '--repo', str(repo), '--tool', 'coverage', '--paths', subject])
assert reference.isascii()
shells = [('ps51', Path(r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe')),
          ('ps7', Path(r'C:\Program Files\PowerShell\7\pwsh.exe'))]
for label, executable in shells:
    code = r'''
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$version = $PSVersionTable.PSVersion.ToString()
& $env:CW_PYTHON -B -m checkwash quality init --repo $env:CW_REPO --tool coverage --paths $env:CW_SUBJECT > (Join-Path $env:CW_OUTPUT 'LABEL-default.toml')
if ($LASTEXITCODE -ne 0) { throw 'default init failed' }
$draft = & $env:CW_PYTHON -B -m checkwash quality init --repo $env:CW_REPO --tool coverage --paths $env:CW_SUBJECT
if ($LASTEXITCODE -ne 0) { throw 'draft init failed' }
$draft | Set-Content -LiteralPath (Join-Path $env:CW_OUTPUT 'LABEL-explicit.toml') -Encoding UTF8
$setup = & $env:CW_PYTHON -B -m checkwash quality init --repo $env:CW_REPO --tool coverage --paths $env:CW_SUBJECT --format json | ConvertFrom-Json
if ($LASTEXITCODE -ne 0 -or $setup.state -ne 'draft') { throw 'JSON init failed' }
[System.IO.File]::WriteAllText((Join-Path $env:CW_OUTPUT 'LABEL-json-extracted.toml'), $setup.policy_toml, (New-Object System.Text.UTF8Encoding($false)))
@{ version=$version; console_encoding=[Console]::OutputEncoding.WebName; setup_authority=$setup.authority } | ConvertTo-Json -Compress
'''.replace('LABEL', label)
    assert executable.is_file(), executable
    run(label, [str(executable), '-NoLogo', '-NoProfile', '-NonInteractive', '-EncodedCommand',
        base64.b64encode(code.encode('utf-16-le')).decode()], shell_code=code)

# Only the trusted policy parser executes, never the fixture's Python source.
sys.path.insert(0, str(PRODUCT / 'src'))
from checkwash.quality.policy import load_policy
from checkwash.quality.model import QualityError
expected = load_policy(reference)
checks = []
for path in sorted(HERE.glob('*.toml')):
    data = path.read_bytes()
    try:
        parsed = load_policy(data)
        valid, error = True, None
    except QualityError as exc:
        valid, parsed, error = False, None, {'code': exc.code, 'message': str(exc)}
    expected_valid = path.name != 'ps51-default.toml'
    assert valid == expected_valid, path.name
    if valid:
        assert parsed == expected, path.name
    checks.append({'path': path.name, 'sha256': hashlib.sha256(data).hexdigest(),
        'prefix_hex': data[:8].hex(), 'bytes': len(data), 'valid': valid, 'error': error,
        'same_policy_as_reference': parsed == expected if valid else False})
after = {p.relative_to(PRODUCT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
         for p in (PRODUCT / 'src').rglob('*.py')}
assert before == after and git('rev-parse', 'HEAD').decode().strip() == HEAD
assert git('status', '--porcelain=v1') == b''
manifest = {'source_sha': HEAD, 'host': platform.node(), 'python': sys.version,
    'provenance': 'HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL', 'records': records,
    'checks': checks, 'source_unchanged': before == after,
    'fixture_execution': 'NOT_RUN; source text only',
    'scope': 'native PS5.1/7 saving only, UTF-8 child process console, no profile/host setting change'}
(HERE / 'results.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({'shells': 2, 'save_controls': checks, 'source_unchanged': True}, indent=2))
