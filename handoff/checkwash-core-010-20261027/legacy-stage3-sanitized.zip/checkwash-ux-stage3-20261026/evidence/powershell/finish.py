"""Run only missing PS7 group; validate original PS5.1 saved bytes without rerun."""
import ast
import base64
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
PRODUCT = ROOT / 'work/checkwash-ux'
HEAD = '9a5a27f44c895ba2fdee8c83a6313baf0e120873'
repo = HERE / 'fixture'
executable = Path(sys.argv[1])
assert executable.is_absolute() and executable.is_file()
spec = importlib.util.spec_from_file_location('trusted_replay', ROOT / 'work/trusted/replay_pju_action.py')
replay = importlib.util.module_from_spec(spec)
spec.loader.exec_module(replay)
temporary = HERE / 'private-r2'
temporary.mkdir(exist_ok=False)
env = replay.clean_environment(Path(sys.executable), Path(r'C:\Program Files\Git\cmd\git.exe'),
    Path(r'C:\Program Files\Git\bin\bash.exe'), temporary)
template = temporary / 'git-template'
template.mkdir()
env.update(PYTHONPATH=str(PRODUCT / 'src'), GIT_TEMPLATE_DIR=str(template), CW_PYTHON=sys.executable,
    CW_REPO=str(repo), CW_OUTPUT=str(HERE), CW_SUBJECT='src/範例.py')

def source_map():
    return {p.relative_to(PRODUCT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in (PRODUCT / 'src').rglob('*') if p.is_file()}

def git(*args):
    return subprocess.run(['git', *args], cwd=PRODUCT, env=env, capture_output=True, check=True).stdout

assert git('rev-parse', 'HEAD').decode().strip() == HEAD and not git('status', '--porcelain=v1')
before = source_map()
original = ast.parse((HERE / 'run.py').read_text(encoding='utf-8'))
loop = next(n for n in original.body if isinstance(n, ast.For) and ast.unparse(n.target) == '(label, executable)')
assignment = next(n for n in loop.body if isinstance(n, ast.Assign) and ast.unparse(n.targets[0]) == 'code')
code = assignment.value.func.value.value.replace('LABEL', 'ps7')
command = [str(executable), '-NoLogo', '-NoProfile', '-NonInteractive', '-EncodedCommand',
    base64.b64encode(code.encode('utf-16-le')).decode()]
started = datetime.now(timezone.utc).isoformat()
result = subprocess.run(command, cwd=repo, env=env, capture_output=True, timeout=120)
(HERE / 'ps7.stdout').write_bytes(result.stdout)
(HERE / 'ps7.stderr').write_bytes(result.stderr)
record = {'command': command, 'decoded_shell_code': code, 'started_utc': started,
    'ended_utc': datetime.now(timezone.utc).isoformat(), 'exit_code': result.returncode, 'cwd': str(repo)}
(HERE / 'ps7-receipt.json').write_text(json.dumps(record, indent=2), encoding='utf-8')
assert result.returncode == 0
sys.path.insert(0, str(PRODUCT / 'src'))
from checkwash.quality.policy import load_policy
from checkwash.quality.model import QualityError
reference = (HERE / 'reference.stdout').read_bytes()
expected = load_policy(reference)
checks = []
for path in sorted(HERE.glob('*.toml')):
    data = path.read_bytes()
    try:
        parsed = load_policy(data)
        valid, error = True, None
    except QualityError as exc:
        valid, parsed, error = False, None, {'code': exc.code, 'message': str(exc)}
    assert valid == (path.name != 'ps51-default.toml'), path.name
    if valid:
        assert parsed == expected, path.name
    checks.append({'path': path.name, 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data),
        'prefix_hex': data[:8].hex(), 'valid': valid, 'error': error,
        'same_policy_as_reference': parsed == expected if valid else False})
after = source_map()
assert before == after and git('rev-parse', 'HEAD').decode().strip() == HEAD
assert not git('status', '--porcelain=v1')
manifest = {'source_sha': HEAD, 'host': platform.node(), 'python': sys.version,
    'provenance': 'HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL', 'ps7_receipt': record, 'checks': checks,
    'shells': {label: json.loads((HERE / (label + '.stdout')).read_text(encoding='utf-8-sig'))
               for label in ('ps51', 'ps7')},
    'source_before_ps7': before, 'source_after_ps7': after, 'source_unchanged_during_ps7': before == after,
    'ps51_receipt_limit': 'Original raw/driver/source identity retained; no initial per-command timestamps or before-map persisted. Initial driver exit1 followed successful PS5.1 group; no rerun.',
    'fixture_execution': 'NOT_RUN; source text only',
    'scope': 'child process Console.OutputEncoding only; no host/profile/security setting changed'}
(HERE / 'results.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({'shells': manifest['shells'], 'checks': checks, 'source_unchanged': True}, indent=2))
