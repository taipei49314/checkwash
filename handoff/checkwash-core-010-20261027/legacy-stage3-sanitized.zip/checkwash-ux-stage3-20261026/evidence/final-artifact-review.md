# Final artifact draft review — read only

Scope: `report-draft.md`, `export_stage3.py`, `package_stage3.py` and the
referenced fixed-source/readback evidence. No product, fixture, test, model,
exporter or packager was run by this review. Product/original raw unchanged.
`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`; reviewer `/root/rename_repro`.

## One packaging correction before export

**P2 — intentional omitted directories are absent from copy-omissions.**
In `export_stage3.py::tree`, the named `.git`, cache, environment and private
directory exclusion branch simply continues. The separate `.git` file branch
also omits without recording. The source inventory currently has29 excluded
ordinary directories:26 fixture `.git` directories and3 private directories
(`powershell/private`, `powershell/private-r2`, `root-junction/private`).
Those exclusions are reasonable; this review does not request copying Git
internals, environments or private state. Their absence should nevertheless
be explicit in the exported omission ledger, with an intentional-exclusion
reason. Currently only reparse/nonregular omissions are listed, so consumers
cannot distinguish the planned exclusions from a complete traversal record.
Record each named exclusion and skipped `.git` file in copy-omissions before
continuing. Root was notified immediately. This is an evidence-packaging
correction, not a product behavior issue or a request for more CLI calls.

## Verified content and scope

- The75 native matrix CLI count is correct: PS7 +root-junction6 +TASK20
  +quality-trust18 +policy-shadow24. The report separately counts fresh
  candidate/public-Action self-dogfood. Parser readback/standard-library
  integrity checks are not miscounted as these75 product calls. Fixture
  Python and models were not executed by those synthetic controls.
- The full suite20,833passed/25skipped/67passed subtests remains attributed
  to9a5a. The5f0candidate contains only two documentation changes,1972
  runtime/test/tool/Action Git members equivalent. Four docs checks and the
  fresh exact1ffe..5f0CLI/actual public-v0.9.0 Action replay validate that
  delta; the draft explicitly disclaims a new5f0exact-head full suite.
- D2/E2, relative TASK, quality trust and policy-shadow code/contract drafts
  remain unapplied/uncompiled/unimported/unexecuted. The current protected
  policy remains unchanged. IR3 is described as a concrete proposed required
  BASE-proof choice, not a claim that every optional field forces a version.
- The report says the core defects retain unimplemented parts. The14-row
  ledger distinguishes implemented narrow repairs from proposal delivery and
  residuals. #7's exact proposal/minimal controls satisfy this bounded goal;
  they do not establish that defaultA/B, D5, whole-body, identity or all oracle
  cases are fixed. Costs/predictions are not new observed improvement rates.
- `{{POLICY_REVIEW}}` is intentionally waiting for the final independent
  policy-shadow readback and is not a bug. The current policy review report
  still says correction pending at this review snapshot; the final package
  must wait for the real final signoff before substituting its success text.
- Both prior ZIP raw hashes were independently read and match exactly:
  stage2 `c39a09b4ee8c0c3747d8ca6d0ce8a61482eb4e972ada640acce035a7a48d85a4`;
  stage1 `e6466727b1eeea9d964bc137b201f57d6e2e23ade4325dd509f373f32c377096`.
  Export asserts these identities and copies stage2 as a new file, preserving
  the nested original first-stage package. It does not rewrite prior ZIPs.
- Export pins clean HEAD5f0, checks protected-file diff empty, main1ffe,
  candidate branch5f0, original annotated/peeledv0.9.1 tag, open/draft/unmerged
  PR566 and publicv0.9.0 observations. It copies ordinary files only and
  checks source/destination hashes; it avoids following fixture aliases.
- Package checks baseline/candidate identities,1972source equivalence,
  stable successful CLI and completed Action outcomes; it requires exact14
  requirement IDs, all5deliverables and separate evidence/delivery/product/
  residual fields. It refuses absent/false final-readback completion flags,
  any applied protected proposal or resumed publication. The pending snapshot
  in the original completion audit is preserved and resolved via a separate
  final-readback, rather than rewritten as earlier success.
- Package validates every exported copy hash, duplicate destination absence,
  relative report links, placeholder removal and replacement-character
  absence, then hashes final files and emits a ZIP SHA256 sidecar. Final
  readback is not yet present at this review snapshot, so these assertions
  have been reviewed as code, not represented as an executed package pass.

## Nonblocking wording and operational notes

Use `合成fixture控制` instead of `模型控制` for manually committed future
BASE controls, to avoid suggesting any model batch ran. For the unexecuted
TASK proposal, `擬保留fully-qualified路徑` is slightly clearer than an
unqualified `保留` compatibility statement; its existing NOT_RUN caveats
already prevent treating the proposal as tested.

The output directory does not exist yet. The export is being reviewed for
the intended fresh destination. If it is retried after a partial failure,
ensure its prior destination cannot contribute stale extra files to the final
manifest; a fresh-directory guard is a useful small hardening, not evidence
of a present stale-file problem. No need to broaden this into new product
validation, release collection, history sweeps or model/cohort work.

After the intentional-omission ledger correction and real policy final
signoff, no further blocking content issue has been identified by this review.
The final exporter/packager exit, raw copy verification and final ZIP readback
must still be recorded by root; this draft code review is not that execution.

## Read-only correction follow-up

Root revised the exporter and this reviewer reread the actual file. The
named excluded-directory branch now appends an intentional-exclusion reason
before continuing; the skipped `.git` file branch likewise records the
metadata-pointer omission. Reparse/symlink directories are still lstat-checked
and excluded before traversal. No rejected source is followed or newly copied.
The packaging P2 is resolved by source review; exporter/packager execution
remains root's later evidence, not an execution made by this reviewer.

Root reports a newly found raw-backslash normalization counterexample in the
policy-shadow proposed API helper. Its author is correcting that external
patch, with the original24observations preserved. The policy packet and its
final independent signoff therefore remain pending. This is not a reason to
reject the existing24native observations or to imply a product change ran.
Do not substitute the pending placeholder with final-success text until that
actual readback has completed. No other packaging/content blocker remains
from this review; the two minor wording suggestions remain optional.
