"""Preserve stage-3 evidence separately, without following fixture aliases."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import urllib.request

ROOT = Path(__file__).resolve().parents[2]
STAGE = ROOT / 'work/ux-stage3'
REPO = ROOT / 'work/checkwash-ux'
OUT = ROOT / 'outputs/checkwash-ux-stage3-20261026'
HEAD = '5f0af4b40cdc6ed2f20414c76dd748549de67109'
BASE = '1ffe283d7d947fecc426dea99323b0a2620a9482'
PRIOR = ROOT / 'outputs/checkwash-ux-stage2-20261026.zip'
HANDOFF = Path(r'C:\Users\nelson\Documents\Codex\2026-10-26\new-chat\outputs\checkwash-next-session-handoff-20261026')
OUT.mkdir(parents=True, exist_ok=True)
copies, omissions, queries = [], [], []

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def copy(source, destination):
    info = source.lstat()
    if not stat.S_ISREG(info.st_mode) or getattr(info, 'st_file_attributes', 0) & 0x400:
        omissions.append({'path': str(source), 'reason': 'not an ordinary file; not followed'})
        return
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)
    assert sha(source) == sha(destination)
    copies.append({'source': str(source), 'destination': destination.relative_to(OUT).as_posix(), 'sha256': sha(destination)})

def tree(source, target):
    for current, dirs, files in os.walk(source):
        current = Path(current)
        kept = []
        for name in dirs:
            item = current / name
            info = item.lstat()
            if stat.S_ISLNK(info.st_mode) or getattr(info, 'st_file_attributes', 0) & 0x400:
                omissions.append({'path': str(item), 'reason': 'reparse/symlink directory; not followed'})
                continue
            if name in {'.git', '__pycache__', '.pytest_cache', 'environment', 'private', 'private-r2'}:
                omissions.append({'path': str(item), 'reason': 'intentional exclusion: Git metadata, runtime/cache or private process environment; original evidence retained at source'})
                continue
            kept.append(name)
        dirs[:] = kept
        for name in files:
            if name == '.git':
                omissions.append({'path': str(current / name), 'reason': 'intentional exclusion: Git worktree metadata pointer'})
                continue
            copy(current / name, target / (current / name).relative_to(source))

def command(label, argv):
    result = subprocess.run(argv, cwd=REPO, capture_output=True, timeout=90)
    (OUT / (label + '.stdout')).write_bytes(result.stdout)
    (OUT / (label + '.stderr')).write_bytes(result.stderr)
    queries.append({'label': label, 'command': argv, 'exit_code': result.returncode})
    assert result.returncode == 0, (label, result.returncode)
    return result.stdout

assert command('candidate-head', ['git', 'rev-parse', 'HEAD']).decode().strip() == HEAD
assert not command('candidate-status', ['git', 'status', '--porcelain=v1', '--untracked-files=all'])
tree(STAGE, OUT / 'evidence')
assert sha(PRIOR) == 'c39a09b4ee8c0c3747d8ca6d0ce8a61482eb4e972ada640acce035a7a48d85a4'
copy(PRIOR, OUT / 'previous-stage2-complete.zip')
for name in ('01-修復範圍與優先序.md', '02-驗收與版本決策.md', '04-新session啟動訊息.md', '05-決策與授權狀態.md'):
    copy(HANDOFF / name, OUT / 'context/handoff' / name)
copy(Path(r'C:\Users\nelson\.codex\AGENTS.md'), OUT / 'context/global-AGENTS.md')
for name in ('AGENTS.md', 'STATE.md', 'docs/quality-adoption.md', 'docs/ux-repair-candidate-2026-10-26.md'):
    copy(REPO / name, OUT / 'context/repository' / name)
command('candidate-patch', ['git', 'diff', BASE, HEAD, '--binary'])
command('stage3-patch', ['git', 'diff', '9a5a27f44c895ba2fdee8c83a6313baf0e120873', HEAD, '--binary'])
command('commit-log', ['git', 'log', '--reverse', '--format=full', BASE + '..' + HEAD])
protected = command('protected-files-diff', ['git', 'diff', '--name-only', BASE, HEAD, '--', 'SPEC.md',
    'THREATMODEL.md', 'DECISIONS.md', 'DECISIONS-archive-*.md', 'tests/gates', 'src/checkwash/gating.py',
    'src/checkwash/ir/strength.py', 'src/checkwash/align.py'])
assert not protected
raw_refs = command('remote-refs', ['git', 'ls-remote', 'origin', 'refs/heads/main',
    'refs/heads/fix/ux-repairs-20261026', 'refs/tags/v0.9.0', 'refs/tags/v0.9.0^{}',
    'refs/tags/v0.9.1', 'refs/tags/v0.9.1^{}'])
refs = dict(line.split()[::-1] for line in raw_refs.decode().splitlines())
assert refs['refs/heads/main'] == BASE and refs['refs/heads/fix/ux-repairs-20261026'] == HEAD
assert refs['refs/tags/v0.9.1'] == '7155c80e57fb0655c521483988ae58905d9b36f1'
assert refs['refs/tags/v0.9.1^{}'] == BASE
pr = json.loads(command('pr-state', ['gh', 'api', 'repos/taipei49314/checkwash/pulls/566', '--jq',
    '{number,state,draft,merged,head:.head.sha,base:.base.sha,html_url}']))
assert pr['state'] == 'open' and pr['draft'] and not pr['merged'] and pr['head'] == HEAD and pr['base'] == BASE
checks = json.loads(command('check-runs', ['gh', 'api', 'repos/taipei49314/checkwash/commits/' + HEAD + '/check-runs',
    '--jq', '{total_count,checks:[.check_runs[]|{name,status,conclusion}]}']))
release = json.loads(command('latest-release', ['gh', 'api', 'repos/taipei49314/checkwash/releases/latest',
    '--jq', '{tag_name,published_at,html_url}']))
assert release['tag_name'] == 'v0.9.0'
with urllib.request.urlopen('https://pypi.org/pypi/checkwash/json', timeout=30) as response:
    raw = response.read()
pypi = json.loads(raw)
assert pypi['info']['version'] == '0.9.0' and '0.9.1' not in pypi['releases']
baseline = {'observed_utc': datetime.now(timezone.utc).isoformat(), 'candidate': HEAD,
    'runtime_suite_source': '9a5a27f44c895ba2fdee8c83a6313baf0e120873', 'main': BASE,
    'pr': pr, 'checks': checks, 'release': release,
    'pypi': {'version': pypi['info']['version'], 'has_091': False,
             'url': 'https://pypi.org/pypi/checkwash/json', 'response_sha256': hashlib.sha256(raw).hexdigest()},
    'native_queries': queries, 'prior_stage2_zip_sha256': sha(PRIOR),
    'prior_stage1_zip_sha256': sha(ROOT / 'outputs/checkwash-ux-milestone-20261026.zip'),
    'provenance': 'HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL', 'publication': 'PAUSED_R65',
    'formal_checks': 'NOT_RUN; local self-dogfood is not a required-check or release waiver'}
assert baseline['prior_stage1_zip_sha256'] == 'e6466727b1eeea9d964bc137b201f57d6e2e23ade4325dd509f373f32c377096'
(OUT / 'baseline.json').write_text(json.dumps(baseline, indent=2), encoding='utf-8', newline='')
(OUT / 'copy-provenance.json').write_text(json.dumps(copies, indent=2), encoding='utf-8', newline='')
(OUT / 'copy-omissions.json').write_text(json.dumps(omissions, indent=2), encoding='utf-8', newline='')
print(json.dumps({'output': str(OUT), 'copies': len(copies), 'omissions': omissions}, indent=2))
