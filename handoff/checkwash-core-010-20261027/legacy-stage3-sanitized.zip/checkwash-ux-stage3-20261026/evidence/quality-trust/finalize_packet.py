"""Read-only raw/hunk checks; refresh only the editable inert packet manifest."""
import base64
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tomllib

HERE = Path(__file__).resolve().parent
PROPOSAL = HERE / "proposal"
SHELL = HERE.parent / "powershell"
REPO = HERE.parents[2] / "work/checkwash-ux"
HEAD = "9a5a27f44c895ba2fdee8c83a6313baf0e120873"

def check_hunks(path, original_path):
    original = subprocess.check_output(["git", "show", HEAD + ":" + original_path], cwd=REPO).decode().splitlines(True)
    lines = path.read_text(encoding="utf-8").splitlines(True)
    checked = []
    index = 2
    while index < len(lines):
        match = re.match(r"@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@", lines[index])
        assert match, (path.name, index)
        old_start, old_count, new_start, new_count = (int(v) if v is not None else 1 for v in match.groups())
        index += 1
        body = []
        while index < len(lines) and not lines[index].startswith("@@"):
            body.append(lines[index])
            index += 1
        old = [line[1:] for line in body if line.startswith((" ", "-"))]
        new_count_actual = sum(line.startswith((" ", "+")) for line in body)
        assert len(old) == old_count and new_count_actual == new_count, path.name
        assert original[old_start - 1:old_start - 1 + old_count] == old, path.name
        checked.append({"old_start": old_start, "old_count": old_count, "new_start": new_start,
                        "new_count": new_count, "old_context_matches": True})
    return checked

hunks = {}
for name, source in (("01-SPEC-retain-base-review.patch", "SPEC.md"),
                     ("02-gating-clarification-only.patch", "src/checkwash/gating.py"),
                     ("03-DECISIONS-proposed.patch", "DECISIONS.md")):
    hunks[name] = check_hunks(PROPOSAL / name, source)
gating_additions = [line[1:].lstrip() for line in (PROPOSAL / "02-gating-clarification-only.patch").read_text().splitlines()
                    if line.startswith("+") and not line.startswith("+++")]
assert gating_additions and all(line.startswith("#") for line in gating_additions)
manifest = json.loads((PROPOSAL / "proposal-manifest.json").read_text())
manifest["files"] = {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(PROPOSAL.iterdir())
                     if path.name != "proposal-manifest.json"}
manifest["hunk_context_checks"] = hunks
manifest["gating_added_lines_are_comments_only"] = True
manifest["modified_judge_executions"] = 0
(PROPOSAL / "proposal-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")

shell_record = json.loads((SHELL / "results.json").read_text(encoding="utf-8"))
assert shell_record["source_sha"] == HEAD and shell_record["source_unchanged_during_ps7"]
assert shell_record["source_before_ps7"] == shell_record["source_after_ps7"]
reference = tomllib.loads((SHELL / "reference.stdout").read_bytes().decode("utf-8-sig"))
for check in shell_record["checks"]:
    raw = (SHELL / check["path"]).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == check["sha256"]
    assert len(raw) == check["bytes"] and raw[:8].hex() == check["prefix_hex"]
    if check["valid"]:
        assert tomllib.loads(raw.decode("utf-8-sig")) == reference
        assert check["same_policy_as_reference"]
    else:
        assert check["path"] == "ps51-default.toml" and raw.startswith(b"\xff\xfe")
        assert check["error"]["code"] == "POLICY_INVALID"
assert shell_record["ps7_receipt"]["exit_code"] == 0
command = shell_record["ps7_receipt"]["command"]
assert base64.b64decode(command[-1]).decode("utf-16-le") == shell_record["ps7_receipt"]["decoded_shell_code"]
shell_hunks = check_hunks(SHELL / "adoption-proposed.patch", "docs/quality-adoption.md")
print(json.dumps({"trust_proposal_hunks": hunks, "gating_comments_only": True,
                  "ps_saved_hashes": len(shell_record["checks"]), "ps_valid_reference_controls": 5,
                  "ps_expected_utf16_invalid": 1, "ps_adoption_hunks": shell_hunks,
                  "product_or_proposed_judge_calls": 0}, indent=2))
