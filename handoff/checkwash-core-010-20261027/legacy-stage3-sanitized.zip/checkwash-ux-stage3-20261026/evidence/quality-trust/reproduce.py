"""Eighteen native static-only controls for the two quality/check trust lanes."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import zipfile

HERE = Path(__file__).resolve().parent
SESSION = HERE.parents[2]
REPO = SESSION / "work/checkwash-ux"
HEAD = "9a5a27f44c895ba2fdee8c83a6313baf0e120873"
SOURCE = HERE / "source-9a5a"
RAW = HERE / "raw"
REPOS = HERE / "repos"
TMP = HERE / "tmp"
TODAY = "2026-10-26"
MAX_CLI = 18
assert HERE.resolve().is_relative_to((SESSION / "work/ux-stage3").resolve())
assert not (HERE / "manifest.json").exists(), "fresh evidence directory required"
for directory in (SOURCE, RAW, REPOS, TMP, HERE / "empty-hooks"):
    directory.mkdir(exist_ok=False)
git_exe = shutil.which("git")
assert git_exe and Path(git_exe).is_absolute() and git_exe.lower().endswith(".exe")
keys = {"SYSTEMROOT", "WINDIR", "SYSTEMDRIVE", "COMSPEC", "PATHEXT", "PATH", "USERPROFILE",
        "LOCALAPPDATA", "APPDATA", "PROGRAMFILES", "PROGRAMFILES(X86)", "PROGRAMW6432"}
env = {key: value for key, value in os.environ.items() if key.upper() in keys}
env.update(GIT_CONFIG_GLOBAL=os.devnull, GIT_CONFIG_NOSYSTEM="1", GIT_OPTIONAL_LOCKS="0",
           GIT_TERMINAL_PROMPT="0", GCM_INTERACTIVE="Never", PYTHONDONTWRITEBYTECODE="1",
           GREENWASH_TODAY=TODAY, TEMP=str(TMP), TMP=str(TMP), PYTHONUTF8="1")
assert not any(key.upper().startswith(("GH_", "GITHUB_", "OPENAI_", "AWS_", "AZURE_")) for key in env)
git_prefix = [git_exe, "--no-optional-locks", "--no-replace-objects", "-c", "core.fsmonitor=false",
              "-c", "core.hooksPath=" + str(HERE / "empty-hooks"), "--literal-pathspecs"]
commands, results = [], []
cli_calls = 0

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def stamp():
    return datetime.now(timezone.utc).isoformat()

def execute(label, command, cwd, *, cli=False):
    global cli_calls
    if cli:
        assert cli_calls < MAX_CLI
        cli_calls += 1
    start = stamp()
    process = subprocess.run(command, cwd=cwd, env=env, stdin=subprocess.DEVNULL,
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60, check=False)
    files = {}
    for kind, raw in (("stdout", process.stdout), ("stderr", process.stderr)):
        path = RAW / (label + "." + kind + ".bin")
        path.write_bytes(raw)
        files[kind] = path.relative_to(HERE).as_posix()
        files[kind + "_sha256"] = digest(raw)
    row = {"label": label, "command": command, "cwd": str(cwd), "started_utc": start,
           "ended_utc": stamp(), "exit_code": process.returncode, "cli": cli, **files}
    commands.append(row)
    (HERE / "command-journal.json").write_text(json.dumps(commands, indent=2) + "\n", encoding="utf-8")
    if cli:
        print(json.dumps({"cli": cli_calls, "label": label, "exit": process.returncode}), flush=True)
    return process, row

def git(label, cwd, *args):
    process, row = execute(label, [*git_prefix, *args], cwd)
    assert process.returncode == 0, label
    return process.stdout, row

head_at_start = git("source-head-before", REPO, "rev-parse", "HEAD")[0].decode().strip()
assert head_at_start == HEAD
assert git("source-status-before", REPO, "status", "--porcelain=v1", "--untracked-files=all")[0] == b""
archive = git("source-archive", REPO, "archive", "--format=zip", HEAD, "src")[0]
(HERE / "source-9a5a.zip").write_bytes(archive)
with zipfile.ZipFile(HERE / "source-9a5a.zip") as zipped:
    assert all(name.startswith("src/") and ".." not in Path(name).parts for name in zipped.namelist())
    zipped.extractall(SOURCE)
tree = git("source-tree", REPO, "ls-tree", "-r", "-z", HEAD, "--", "src")[0]
expected = {}
for record in tree.split(b"\0"):
    if not record:
        continue
    metadata, name = record.split(b"\t", 1)
    mode, kind, oid = metadata.split()
    assert mode in (b"100644", b"100755") and kind == b"blob"
    expected[name.decode()] = oid.decode()

def source_manifest():
    actual = {path.relative_to(SOURCE).as_posix(): path for path in (SOURCE / "src").rglob("*") if path.is_file()}
    assert actual.keys() == expected.keys()
    manifest = {}
    for name, path in actual.items():
        raw = path.read_bytes()
        oid = hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
        assert oid == expected[name], name
        manifest[name] = {"git_blob": oid, "sha256": digest(raw)}
    return manifest

before_source = source_manifest()
BOOTSTRAP = "import sys;sys.path.insert(0," + repr(str(SOURCE / "src")) + ");from checkwash.cli import main;raise SystemExit(main())"

def policy(mode):
    return (f'schema_version = 1\nmode = "{mode}"\n[[targets]]\nid = "coverage-main"\n'
            'tool = "coverage"\nroot = "."\nconfig = "pyproject.toml"\n'
            'profile = "coverage-7.16.0-q1"\npaths = ["src/"]\n').encode()

def config(threshold):
    return f"[tool.coverage.report]\nfail_under = {threshold}\n".encode()

def allowance(key, *, target="coverage-main", rule="QW_THRESHOLD_LOWERED", expired=False, malformed=False):
    created, expires = ("2026-09-01", "2026-10-01") if expired else ("2026-10-01", "2026-11-01")
    body = (f'[[allow]]\nfingerprint = "{key}"\nrule = "{rule}"\ntarget_id = "{target}"\n'
            'reason = "Session-owned synthetic review boundary control; no real approval claimed"\n'
            f'created = "{created}"\nexpires = "{expires}"\n')
    if not malformed:
        body += 'author = "owned-fixture-reviewer"\n'
    return body.encode()

def write(root, path, raw):
    target = root / path
    assert target.resolve().is_relative_to(root.resolve())
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)

def make_case(name, mode, base_allow, head_allow, threshold):
    root = REPOS / name
    root.mkdir()
    git(name + "-init", root, "init", "--quiet")
    git(name + "-autocrlf", root, "config", "core.autocrlf", "false")
    write(root, ".checkwash/quality.toml", policy(mode))
    write(root, "pyproject.toml", config(85))
    write(root, "src/code.py", b"VALUE = 1\n")
    if base_allow is not None:
        write(root, ".checkwash/quality-allow.toml", base_allow)
    def commit(label):
        git(name + "-" + label + "-add", root, "add", "-f", "--all", "--", ".")
        git(name + "-" + label + "-commit", root, "-c", "user.name=Owned fixture",
            "-c", "user.email=fixture@example.invalid", "commit", "--quiet", "--allow-empty", "--no-verify", "-m", label)
        return git(name + "-" + label + "-sha", root, "rev-parse", "HEAD")[0].decode().strip()
    base = commit("base")
    write(root, "pyproject.toml", config(threshold))
    if head_allow is not None:
        write(root, ".checkwash/quality-allow.toml", head_allow)
    head = commit("head")
    git(name + "-status", root, "status", "--porcelain=v1", "--untracked-files=all")
    git(name + "-index", root, "ls-files", "--stage", "-z")
    inputs = {str(path.relative_to(root)).replace("\\", "/"): digest(path.read_bytes())
              for path in [root/".checkwash/quality.toml", root/"pyproject.toml", root/"src/code.py"]}
    if head_allow is not None:
        inputs[".checkwash/quality-allow.toml"] = digest(head_allow)
    return root, base, head, inputs

def cli(name, command, case):
    root, base, head, inputs = case
    argv = [sys.executable, "-I", "-B", "-X", "utf8", "-c", BOOTSTRAP,
            command, base + ".." + head, "--format", "json", "--repo", str(root)]
    process, receipt = execute(name + "-" + command, argv, root, cli=True)
    payload = json.loads(process.stdout)
    row = {"case": name, "command": command, "base": base, "head": head, "inputs_sha256": inputs,
           "exit_code": process.returncode, "payload": payload, "receipt": receipt}
    results.append(row)
    (HERE / "results-journal.json").write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8")
    return payload

fingerprints = {}
for threshold in (50, 40):
    name = "discover-" + str(threshold)
    case = make_case(name, "enforce", None, None, threshold)
    payload = cli(name, "quality", case)
    losses = [f for f in payload["findings"] if f["rule"] == "QW_THRESHOLD_LOWERED"]
    assert len(losses) == 1 and losses[0]["target_id"] == "coverage-main"
    fingerprints[threshold] = losses[0]["fingerprint"]

first, second = allowance(fingerprints[50]), allowance(fingerprints[40])
wrong_key = fingerprints[50].replace("/coverage-main/", "/other-target/")
unknown_key = fingerprints[50].replace("QW_THRESHOLD_LOWERED/", "QW_FUTURE_RULE/")
cases = [
    ("report-append-only", "report", first, first + b"\n" + second, 85),
    ("enforce-append-only", "enforce", first, first + b"\n" + second, 85),
    ("enforce-existing-valid", "enforce", first, first, 50),
    ("enforce-head-not-authority", "enforce", first, first + b"\n" + second, 40),
    ("enforce-expired-base", "enforce", allowance(fingerprints[50], expired=True), allowance(fingerprints[50], expired=True), 50),
    ("enforce-wrong-target", "enforce", allowance(wrong_key, target="other-target"), allowance(wrong_key, target="other-target"), 50),
    ("enforce-unknown-rule", "enforce", allowance(unknown_key, rule="QW_FUTURE_RULE"), allowance(unknown_key, rule="QW_FUTURE_RULE"), 50),
    ("enforce-malformed-head", "enforce", first, first + b"\n" + allowance(fingerprints[40], malformed=True), 85),
]
for name, mode, base_allow, head_allow, threshold in cases:
    case = make_case(name, mode, base_allow, head_allow, threshold)
    cli(name, "check", case)
    cli(name, "quality", case)

after_source = source_manifest()
ending_head = git("source-head-after", REPO, "rev-parse", "HEAD")[0].decode().strip()
ending_status = git("source-status-after", REPO, "status", "--porcelain=v1", "--untracked-files=all")[0]
assert ending_head == HEAD and ending_status == b"" and after_source == before_source
assert cli_calls == MAX_CLI
manifest = {"provenance": "HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL", "host": platform.node(),
            "runtime": sys.version, "executable": sys.executable, "platform": platform.platform(),
            "source_sha": HEAD, "ending_sha": ending_head, "source_unchanged": before_source == after_source,
            "source_archive_sha256": digest(archive), "source_files_before": before_source,
            "source_files_after": after_source, "cli_calls": cli_calls, "maximum_cli_calls": MAX_CLI,
            "today": TODAY, "trusted_env_key_names": sorted(env), "commands": commands,
            "fingerprints": fingerprints, "results": results,
            "scope": "owned native static controls; synthetic BASE represents prior review, no human acceptance claimed",
            "fixture_program_execution": "NOT_RUN", "modified_judge_executions": 0,
            "not_claimed": ["general historical frequency", "tool execution", "Claude lifecycle", "new exemption for this PR", "other platforms"]}
(HERE / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"cli_calls": cli_calls, "source_unchanged": True, "fingerprints": fingerprints}), flush=True)
