# Quality second-exemption native controls

HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL. Host LAPTOP-01AGNPJU,
Windows 10.0.26200, Python 3.11.9. Exact product/archive source
`9a5a27f44c895ba2fdee8c83a6313baf0e120873`; source files verified against Git
blobs before/after, clean product HEAD/status unchanged. The extracted source
is immutable input to 18 top-level native CLI calls, all within the fixed budget.

The fixture BASE commits represent already reviewed policy/one-entry ledgers
for a synthetic control; they are not evidence that a human actually reviewed
or accepted these fixture entries. Packaged `coverage-7.16.0-q1` is used for
static configuration analysis. Coverage, Ruff, mypy, fixture Python, Claude
and models were not executed. No product/test/allow file was edited, no
commit/push occurred in the product, and no old hook/package evidence changed.

## Measured outcomes

Two initial native quality calls produce exact identities for fail_under
85→50 and 85→40. The remaining eight cases each run `check` and `quality`
against the same full BASE..HEAD range. All configuration/ledger files are
native tracked regular files in session-owned repositories.

| Case | Main check | Quality | Meaning |
|---|---|---|---|
| report BASE, valid second append only | critical GUARDRAIL_TOUCHED; block/1 | warn QW_POLICY_CHANGED; complete/reported/0 | Different lane policy; quality exit0 is not clean |
| enforce BASE, valid second append only | critical GUARDRAIL_TOUCHED; block/1 | warn QW_POLICY_CHANGED; complete/reported/0 | Enforce does not escalate a warning into a high block |
| existing matching valid BASE entry, 85→50 | CI_WORKFLOW_TOUCHED/warn; pass/0 | high QW_THRESHOLD_LOWERED remains visible, allowlisted=true; no_blocking_finding/0 | Current exact BASE exemption still works; finding is not erased |
| append second key and 85→40 | critical guardrail plus CI warn; block/1 | unallowlisted high threshold loss plus policy warn; block/1 | The new HEAD key does not exempt the current comparison |
| matching expired BASE entry, 85→50 | CI warn; pass/0 | unallowlisted high threshold loss; block/1 | Expiry makes the matching-shaped entry ineligible |
| other-target BASE entry, 85→50 | CI warn; pass/0 | unallowlisted high threshold loss; block/1 | Strictly shaped other-target row parses but does not match this target |
| unknown QW rule in BASE, 85→50 | CI warn; pass/0 | POLICY_INVALID hard error/2 | Unknown quality rule is rejected by this strict schema, not ignored |
| valid BASE entry, malformed second HEAD row | critical guardrail; block/1 | POLICY_INVALID hard error/2 | HEAD malformed append is not a warn-level normal maintenance event |

The first two rows are the native second-entry self-block reproduction. They
confirm the existing documented split: main E4 guards an existing quality
ledger modification, while quality classifies its valid semantic append at
warn and retains BASE authority. No result proves a blanket quality-glob or
“all tightening” exception would be safe. Expired/wrong-target non-matches
are distinct from the unknown/malformed schema errors. Main pass in the last
quality-error controls is not a claim that main judges quality policy.

## Evidence and provenance

`manifest.json` captures source/archive and every source-member Git/SHA256
identity before/after, host/runtime, pinned date 2026-10-26, allowlisted clean
environment key names, 18 result payloads and all native command receipts.
`raw/` preserves stdout/stderr bytes including native Git setup/index/status;
`command-journal.json` and `results-journal.json` preserve completed progress.
The runner uses absolute Python and native Git, isolated `-I -B -X utf8`,
DEVNULL input, credential-free environment and disabled owned Git hooks.
`validation.json` independently checks every recorded raw hash, payload and
the outcome assertions using only standard-library reads. There were no
product or driver failures in this bounded run. CLI exits 1/2 above are the
intended block/error controls, not harness failures or PASS claims.

## Decision packet

`proposal/00-decision.md` recommends retaining the existing prior-BASE review
boundary (choice A), with exact SPEC/gating-comment/DECISIONS inert diffs.
The gating hunk is comments only and changes no executable policy. Choice B
is a separate, not-recommended append-visibility alternative: its precise
predicate, unproven review intent, costs and required new implementation are
listed, with no applied code or qualification. No proposed judge was executed.

Observed cost is two synthetic append-only main blocks, not a historical
frequency or a measured human-review burden. Existing creation behavior,
policy-shadowing, D2/D5/identity/repair rules and stage-2 hook evidence remain
outside this control set. Other OS/Python, complete upgrade workflows,
natural-history/model batches and release acceptance are NOT_RUN. r65 stays
paused; no exemption was added to make the real PR green.
