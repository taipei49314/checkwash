# Acceptance work if a trust proposal is adopted — NOT_RUN

Choice A is protected clarification plus comments only. Adoption still needs
maintainer approval of exact SPEC/DECISIONS text, an assigned decision, and
the repository's required version/fixture checks. Existing native controls
are bounded evidence, not that future acceptance. No current version bump.

Choice B needs a new exact implementation patch and independent review
before running a changed judge. Fix the predicate, proof schema, visible
metadata and source first; do not retroactively rename these results as B.

Required positives: report/enforce BASE; second and multiple semantic appends;
matching existing BASE exemption; identical content in worktree/range;
main and quality lanes checked separately; high/warn/critical thresholds.

Required negatives: no BASE policy/ledger, unknown policy mode/target/profile,
wrong or newly introduced target, expired/future/overcap dates, malformed TOML
or row schema, unknown/non-strong rule, partial/retired/wrong q1 identity,
existing row mutation/removal/reorder, policy weakening/tightening cochange,
other guardrail cochange, links/size refusals, stale proof hashes, unsupported
quality context/incomplete analysis, attempted tool-managed or author flag.

Retain present exact BASE priority and key binding. A changed after state,
profile, selected source or target must not reuse approval. HEAD additions
must never enter current eligible fingerprints. An info/warn or exit0 must
not be called clean when findings or incomplete/error boundaries remain.

After fixed-source dedicated tests: complete appropriate source suite,
required receipt bridge, relevant artifact qualification and dogfood under
the original product rules. Other OS/Python and natural-history costs remain
NOT_RUN until independently recorded. r65 remains paused; no merge/tag/release,
downstream repin or automation resume follows from either draft.
