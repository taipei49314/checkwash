# Option B — boundary for a separate policy decision, NOT implemented

This is not the recommended choice. It is not an executable implementation
patch or permission to add one. It records the minimum reviewable predicate
if a maintainer deliberately trades the existing critical maintenance block
for visible append warnings. No general “safe tightening” proof is claimed.

## Predicate, all clauses required

1. Exact path is `.checkwash/quality-allow.toml`, with existing regular BASE
   bytes and regular HEAD bytes admitted by the normal bounded snapshot
   reader. No new source/link/size exception. No wildcard or role override.
2. The BASE quality policy exists and passes the current strict schema with
   nonempty declared targets. Its mode and all target declarations remain
   BASE authority; any policy file edit keeps its separate normal finding.
3. Both ledgers parse under the package-owned strict quality schema. BASE
   contains at least one entry. HEAD's parsed entry sequence has BASE as an
   exact prefix, with at least one new record. No prior field, record order,
   target, reason, author, date or expiry may change or disappear. Formatting
   and comments alone do not constitute new authorization.
4. Every appended row has exactly the seven required nonempty string fields,
   one of the existing three strong QW rules, an already declared BASE target
   id, and its matching `rule/target/q1:<64 lowercase hex>` key prefix. Target
   identity cannot be borrowed from another row or introduced by HEAD policy.
5. Each appended row passes the existing reproducible date-window validation
   (creation not in future; 0–180 days through expiry), and is not already
   expired at the run's pinned date. Existing expired rows may remain unchanged
   but retain their existing non-eligibility. Unknown/malformed data declines
   this special predicate; it does not become a default empty list.
6. A package-computed proof is bound to the exact admitted before/after ledger
   hashes and BASE policy hash/target ids. It is not a flag read from user
   settings or a claimed author/tool/generated label. Gating stays a pure
   function of checked IR evidence; no source I/O or quality analyzer is
   invoked inside E4. The necessary proof construction/IR schema plumbing
   requires a separately reviewed exact implementation design.
7. Only this path's main GUARDRAIL_TOUCHED escalation could be replaced by a
   visible warn with an explicit append-maintenance label and the new keys.
   Keep its exact content identity and source evidence. Existing main BASE
   allowances retain their precedence. No other guardrail, policy edit,
   hidden-control event, malformed input, diagnostic, finding or exit rule
   is suppressed. New labels/IR fields require explicit schema accounting.
8. Quality's own BASE-only exemption set is unchanged. Never add HEAD keys
   to eligible fingerprints. No waiver for QW_POLICY_CHANGED or
   QW_ANALYSIS_INCOMPLETE, nor any rule-wide/path-wide exemption.

Clauses 3–5 prove syntax and preservation of old records, **not** that a key's
hash describes a real event, that an author performed review, or that a tool
executed successfully. Proving an actual weakening identity would require
recomputing its full profile/source/discovery-bound quality event, not merely
accepting a 64-hex string. B therefore remains a deliberate visibility policy
tradeoff dependent on external maintainer review, analogous in intent to the
existing main append exception; it is not a cryptographic approval proof.

## Finite predictions and costs, not executed results

On the recorded controls, B could move the two valid append-only main results
from critical/block1 to warn/pass0 at the existing high threshold. The
append+weakening main result could also pass at high, while quality enforce
would still block because its new entry is only at HEAD. Other recorded
quality results do not change. These are predictions, not patched-judge runs.

The current wrong-target and expired controls place those rows at BASE; they
test present eligibility, not B's new HEAD predicate. B would additionally
need explicit wrong-target/expired HEAD appends. `fail_on=warn` would still
block a warn; report-mode quality alone still cannot enforce a high weakening.

Implementation would expand cross-lane parsing/IR surface and create a new
main non-blocking maintenance route. Arbitrary but well-shaped future keys
and dishonest reasons remain possible, and branch review remains load-bearing.
No false-positive rate, no natural-history cost, no timing budget or zero-risk
claim is supported by the 18 existing calls. Require minor-version contract
review, dedicated reverse/negative controls and fixed-source qualification;
do not silently put this in the current 0.9.2 UX candidate.
