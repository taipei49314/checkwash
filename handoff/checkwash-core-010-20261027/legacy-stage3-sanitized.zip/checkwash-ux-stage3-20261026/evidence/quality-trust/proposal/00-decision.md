# Quality trust decision — exact choice A recommended, not adopted

Source: frozen `9a5a27f44c895ba2fdee8c83a6313baf0e120873`.
HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL. This packet is an inert proposal;
it is neither approval nor implemented product behavior. No modified judge
was imported, applied or executed. It does not authorize an exemption for
PR #566, publication, a historical rerun, or a new model batch.

## The concrete decision

**Recommend A: retain prior-BASE review and the two existing trust lanes.**
Main `check` continues treating modification of an existing
`.checkwash/quality-allow.toml` as GUARDRAIL_TOUCHED/critical. Quality continues
reporting a schema-valid semantic append at warn while reading only BASE
exemptions. Require each applicable lane's actual required check; a quality
`reported`/0 is neither clean nor evidence of a main-check pass.

The three `.patch` files clarify SPEC, add comments at the existing E4 branch,
and supply an unassigned DECISIONS draft. The gating diff changes no executable
statement. A maintainer must approve exact protected wording and assign the
decision before application; none is applied by this packet. The repository's
protected SPEC/version/fixture procedure still governs any adoption.

The native evidence proves the friction is real: in both report and enforce
BASE policies, appending the valid second entry alone yields main block/1
and quality reported/0. It does **not** prove either lane is wrong: their
present contracts explicitly differ. An existing exact BASE entry still works;
a new HEAD entry does not excuse the same comparison.

## Review route under A

1. Prepare the precise intended quality loss/ledger change and capture its
   exact q1 quality identity and main GUARDRAIL_TOUCHED v2 identity.
2. Submit the precise maintenance change through the existing maintainer
   process. If the current main-exemption route is used, it must be an exact
   main GUARDRAIL key in a separately accepted prior BASE; a QW key never
   belongs in the main allow ledger. This packet adds no such entry.
3. Land the reviewed quality ledger before a later comparison relies on its
   quality entry, then rerun both actual lanes against their intended ranges.
   Changes in content/profile/source require a fresh exact identity/review.

These are source-derived workflow instructions, not a newly executed
three-step approval lifecycle or evidence that any human accepted these
synthetic fixtures. A Git commit alone is not proof of human review. The
required CI range against the reviewed branch provides the intended boundary;
the local hook's writable session-base record is not that authority.

Measured cost is deliberately narrow: the two append-only controls each
retain one main critical finding. No natural-repository frequency, human
effort, latency or false-positive rate was measured. A retains that friction
and asks the maintainer to accept it explicitly rather than hiding it.

## If the maintainer prefers a different policy

**B: exact semantic-append visibility exception** is an alternative requiring
another protected decision, not the recommendation or an implemented patch.
Its mechanical predicate and limits are in `05-option-B-predicate.md`.
It would change main severity/metadata, so it belongs to a minor candidate
with explicit schema accounting and fixed-source tests. It does not cause
HEAD entries to authorize their own quality weakening.

**Reject C: blanket `.checkwash/quality*` exemptions, all “tightening”, or
tool-managed/generated self-claims.** Those do not establish reviewed BASE
authority. Current configuration adapters have unsupported/unknown contexts;
schema validity and a generator label cannot prove a change is safe or
reviewed. Do not generalize these eight paired controls into such a grant.

Residuals remain explicit: initial creation exceptions are unchanged, policy
shadowing is unresolved, exact profile/source changes alter q1 identities,
unknown/malformed quality policy remains a hard error, incomplete analysis
cannot be exempted, and hook/D2/D5/identity/repair/publication rules are outside
this decision. Stage-2 hook raw and sealed packages are untouched.
