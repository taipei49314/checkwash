"""Resolve timestamped completion-audit pending items from final evidence."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
REPO = ROOT / 'work/checkwash-ux'
HEAD = '5f0af4b40cdc6ed2f20414c76dd748549de67109'
BASE = '9a5a27f44c895ba2fdee8c83a6313baf0e120873'

def read(relative):
    return json.loads((HERE / relative).read_text(encoding='utf-8'))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def git(*args):
    return subprocess.run(['git', *args], cwd=REPO, capture_output=True, check=True).stdout

assert git('rev-parse', 'HEAD').decode().strip() == HEAD
assert not git('status', '--porcelain=v1')
equivalence = read('source-equivalence.json')
assert equivalence['candidate'] == HEAD and equivalence['runtime_tests_tools_action_git_members_identical']
assert git('ls-tree', '-r', '-z', BASE, '--', 'src', 'tests', 'tools', 'action') == git(
    'ls-tree', '-r', '-z', HEAD, '--', 'src', 'tests', 'tools', 'action')
cli = read('root/final-cli-selfdogfood/receipt.json')
assert cli['source_sha'] == cli['ending_sha'] == HEAD and cli['exit_code'] == 0 and cli['source_files_unchanged']
payload = read('root/final-cli-selfdogfood/stdout.txt')
assert payload['summary'] == {'critical': 0, 'high': 0, 'info': 0, 'warn': 4} and payload['verdict'] == 'pass'
prior = json.loads((ROOT / 'work/ux-stage2/root/final-cli-selfdogfood/stdout.txt').read_text(encoding='utf-8'))
assert payload['findings'] == prior['findings']
action = read('final-action/replay.json')
assert action['head_sha'] == HEAD and action['status'] == 'completed' and not action['errors']
assert [r['exit_code'] for r in action['steps']] == [0, 0]
docs = read('root/docs-after/receipt.json')
assert docs['exit_code'] == 0 and docs['source_files_unchanged']
assert docs['input_manifest_sha256'] == cli['input_manifest_sha256']
policy = read('policy-shadow/receipt.json')
assert policy['cli_calls'] == 24 and policy['source_sha'] == BASE and policy['source_unchanged'] and policy['product_clean']
task = read('task-authority/validation.json')
assert task['native_cli_calls'] == 20 and task['driver_exit'] == 0 and task['product_worktree_clean']
quality = read('quality-trust/validation.json')
assert quality['cli_calls'] == 18 and not quality['errors']
junction = read('root-junction/results.json')
assert junction['cli_calls'] == 6 and junction['paired_payloads_identical'] and junction['source_unchanged']
ps = read('powershell/results.json')
assert len(ps['checks']) == 6 and sum(row['valid'] for row in ps['checks']) == 5
policy_review = read('policy-shadow-independent-review/audit.json')
assert policy_review['review_state'] == 'PASS_NO_REMAINING_BLOCKERS'
assert policy_review['remaining_blocking_findings'] == [] and policy_review['errors'] == []
assert policy_review['modified_judge_executions'] == 0
assert policy_review['native_observations'] == 24 and policy_review['raw_commands_verified'] == 186
requirements = read('completion-review/requirements.json')
assert sorted(row['problem'] for row in requirements['problem_requirements']) == list(range(1, 15))
assert len(requirements['required_deliverables']) == 5
assert requirements['number7_minimal_case_and_exact_proposal_requirement_satisfied']
assert requirements['number7_product_escape_fixed'] is False
baseline_path = ROOT / 'outputs/checkwash-ux-stage3-20261026/baseline.json'
baseline = json.loads(baseline_path.read_text(encoding='utf-8'))
assert baseline['candidate'] == baseline['pr']['head'] == HEAD
assert baseline['pr']['draft'] and not baseline['pr']['merged']
assert baseline['main'] == baseline['pr']['base'] == '1ffe283d7d947fecc426dea99323b0a2620a9482'
assert baseline['release']['tag_name'] == 'v0.9.0' and baseline['pypi']['version'] == '0.9.0'
assert all(row['exit_code'] == 0 for row in baseline['native_queries'])
evidence = [
    'source-equivalence.json', 'root/docs-after/receipt.json', 'root/final-cli-selfdogfood/receipt.json',
    'final-action/replay.json', 'task-authority-independent-review/report.md',
    'quality-trust-independent-review/report.md', 'policy-shadow-independent-review/report.md',
    'policy-shadow-independent-review/audit.json', 'policy-shadow/implementation.patch',
    'policy-shadow/protected-contract.patch', 'policy-shadow/consumer-migration.patch',
    'completion-review/requirements.json', 'completion-review/report.md', 'final-artifact-review.md',
    'powershell/independent-review.md']
record = {'observed_utc': datetime.now(timezone.utc).isoformat(), 'candidate': HEAD,
    'goal_delivery_scope': 'Authorized narrow repairs and reviewable candidate, bounded controls and exact unapplied protected decision packets; not all product bugs fixed or release accepted.',
    'runtime_suite_source': BASE, 'runtime_tests_tools_action_same_as_9a': True,
    'policy_packet_complete_and_reviewed': True, 'all_goal_delivery_requirements_satisfied': True,
    'protected_proposals_applied': False, 'product_defects_all_fixed': False,
    'publication_resumed': False, 'new_model_history_batch_run': False,
    'native_reproduction_cli_calls': 75, 'source_cli_selfdog_exit': 0, 'actual_public_action_exit': 0,
    'selfdog_findings': 'same four warn as 9a; no new exemption; original retired-entry notices remain',
    'prior_pending_resolutions': {
        'policy_packet': 'IR3 header, required-proof/consumer migration and lexical path correction independently checked in final review_state',
        'selfdog_action': 'Exact final range completed with steps 0/0',
        'final_ledger_integration': 'report-draft.md has all14 rows plus native/decision/NOT_RUN/source distinctions; copied as report.md by packager',
        'remote_pr_baseline': 'Native exporter readback confirms exact draft head, unchanged main/tag, public GitHub/PyPI0.9.0 and successful query exits; baseline.json carries the actual later observation time'},
    'evidence_sha256': {name: sha(HERE / name) for name in evidence},
    'requirements': [{'problem': row['problem'], 'delivery_status': row['delivery_status'],
                      'product_status': row['product_status'], 'residual_status': row['residual_status']}
                     for row in requirements['problem_requirements']],
    'scope_exclusions_remain_NOT_RUN': ['Other OS/Python/cross-platform equality', 'formal release/283 artifact qualification/required-check bridge',
        'cross-drive and unavailable native file-symlink capability', 'unapproved protected implementation and its future tests']}
for row in record['requirements']:
    row['snapshot_delivery_status'] = row['delivery_status']
    if row['problem'] == 3:
        row['snapshot_residual_status'] = row['residual_status']
        row['delivery_status'] = 'SATISFIED_EXACT_UNAPPLIED_IR3_PACKET_AND_INDEPENDENT_READBACK'
        row['residual_status'] = ('Product shadow behavior remains unchanged. Exact inert IR3/header/consumer/path correction is reviewed; '
            'adoption, future implementation tests and cost acceptance remain unapproved/NOT_EXECUTED.')
        row['current_review_evidence'] = 'policy-shadow-independent-review/audit.json:PASS_NO_REMAINING_BLOCKERS'
record['all_goal_delivery_requirements_satisfied'] = all(
    row['delivery_status'].startswith('SATISFIED_') for row in record['requirements'])
assert record['all_goal_delivery_requirements_satisfied']
record['derived_readback_correction'] = ('The original pending audit is preserved. Current per-item status is separately resolved '
    'from the final review rather than copying its historical PENDING status under an aggregate success flag. '
    'See bookkeeping-originals/final-readback.before-current-resolution.json.')
(HERE / 'final-readback.json').write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding='utf-8', newline='')
print(json.dumps({'candidate': HEAD, 'goal_delivery_requirements': 14, 'required_deliverables': 5,
    'policy_review_state': policy_review['review_state'], 'product_all_fixed': False}, indent=2))
