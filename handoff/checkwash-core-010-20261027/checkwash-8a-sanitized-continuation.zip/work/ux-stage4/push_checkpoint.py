"""Push task-only handoff metadata without changing the sealed product checkout.

The alternate index/commit lives on a handoff branch. No product tag, Release,
main update, workflow dispatch or check publication is performed.
"""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

HERE = Path(__file__).resolve().parent
REPO = HERE.parent / "checkwash-ux"
PIN = (HERE / "final-source-sha.txt").read_text(encoding="utf-8").strip()
BASE = HERE / "remote-checkpoint"
BASE.mkdir(exist_ok=True)
state_path = BASE / "state.json"
previous = json.loads(state_path.read_text(encoding="utf-8")) if state_path.exists() else None
BRANCH = "handoff/core-010-pju-20261027-8a8941dc"
PREFIX = "handoff/checkwash-core-010-20261027"
stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
OUT = BASE / stamp
OUT.mkdir(exist_ok=False)
payload = OUT / "payload"
payload.mkdir()
base_env = {name: value for name, value in os.environ.items() if name not in {
    "GIT_DIR", "GIT_WORK_TREE", "GIT_COMMON_DIR", "GIT_INDEX_FILE", "GIT_OBJECT_DIRECTORY",
    "GIT_ALTERNATE_OBJECT_DIRECTORIES", "GIT_NAMESPACE"}}


def git(*args, input=None, env=None):
    result = subprocess.run(["git", *args], cwd=REPO, env=env or base_env,
                            input=input, capture_output=True)
    if result.returncode:
        raise RuntimeError(result.stderr.decode("utf-8", "backslashreplace"))
    return result.stdout


assert git("rev-parse", "HEAD").decode().strip() == PIN
assert not git("status", "--porcelain", "--untracked-files=all")
assert previous is None or previous["branch"] == BRANCH
parent = previous["checkpoint_commit"] if previous else PIN
remote_before = git("ls-remote", "--heads", "origin", "refs/heads/" + BRANCH).decode().strip()
if previous:
    assert remote_before.split()[0] == parent, "remote checkpoint changed unexpectedly"
else:
    assert not remote_before, "checkpoint branch already belongs to an unknown operation"


def copy(name, source):
    target = payload / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)


copy("source-seal.json", HERE / "seal/source-seal.json")
copy("golden/UNADOPTED-expected-only.patch", HERE / "golden-ruling-proposal/expected-only.patch")
copy("golden/UNADOPTED-README.md", HERE / "golden-ruling-proposal/README.md")
copy("golden/observed-cost-register.json", HERE / "oracle/cost-r4/immutable-cost-register.json")
copy("golden/observed-cost-table.md", HERE / "oracle/cost-r4/cost-table.md")
for name in ("capture_final.py", "qualify_one.py", "build_pyz.py", "seal_source.py"):
    copy("resume-tools/" + name, HERE / name)
copy("resume-tools/trusted-replay_pju_action.py", HERE.parent / "trusted/replay_pju_action.py")
copy("resume-tools/final-source-sha.txt", HERE / "final-source-sha.txt")
copy("completed/corpus-311-312-comparison.json", HERE / "final/corpus-311-312-comparison-r1/comparison.json")
copy("completed/native36-analysis.json", HERE / "native-final-control/analysis.json")
copy("completed/native36-report.md", HERE / "native-final-control/report.md")
copy("completed/oracle-development-summary.json", HERE / "oracle/development-summary.json")
copy("completed/D183-development-summary.json", HERE / "policy/development-summary.json")


def partial_trace(kind):
    folder = HERE / "qualification" / (kind + "-r1")
    raw = folder / "raw"
    ledger_path = raw / "commands.json"
    if not ledger_path.exists():
        return {"state": "NOT_STARTED", "not_a_pass": True}
    for _ in range(5):
        try:
            ledger = json.loads(ledger_path.read_text(encoding="utf-8"))
            break
        except json.JSONDecodeError:
            time.sleep(0.05)
    else:
        return {"state": "RUNNING_LEDGER_WRITE_IN_PROGRESS", "not_a_pass": True}
    destination = payload / "partial-qualification" / kind
    destination.mkdir(parents=True)
    for stream in ("stdout", "stderr"):
        boundary = max((row[stream]["offset"] + row[stream]["bytes"] for row in ledger), default=0)
        with (raw / (stream + ".bin")).open("rb") as source:
            prefix = source.read(boundary)
        assert len(prefix) == boundary
        for row in ledger:
            value = row[stream]
            segment = prefix[value["offset"]:value["offset"] + value["bytes"]]
            assert hashlib.sha256(segment).hexdigest() == value["sha256"]
        (destination / (stream + ".bin")).write_bytes(prefix)
    (destination / "commands.json").write_text(json.dumps(ledger, sort_keys=True, indent=2), encoding="utf-8")
    cases = sum("check" in row["argv"] for row in ledger)
    result = {"state": "RUNNING_PARTIAL_PREFIX_ONLY", "not_a_pass": True,
              "completed_commands": len(ledger), "observed_case_cli_calls": cases,
              "complete_expected_case_count": 283, "raw_prefix_offsets_and_hashes_verified": True}
    if (folder / "qualification.json").exists():
        final = json.loads((folder / "qualification.json").read_text(encoding="utf-8"))
        copy("partial-qualification/" + kind + "/qualification.json", folder / "qualification.json")
        result["state"] = "HELPER_FINISHED_OUTER_READBACK_NOT_IMPLIED"
        result["helper_status"] = final["status"]
        result["helper_summary"] = final["summary"]
    (destination / "SNAPSHOT-STATUS.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    return result


jobs = {kind: partial_trace(kind) for kind in ("source", "wheel", "pyz")}
metadata = {
    "checkpoint_kind": "HANDOFF_BACKUP_NOT_RELEASE_ACCEPTANCE",
    "created_utc": datetime.now(timezone.utc).isoformat(), "code_source_sha": PIN,
    "product_branch": "fix/ux-repairs-20261026", "checkpoint_branch": BRANCH,
    "product_pr": "https://github.com/taipei49314/checkwash/pull/566",
    "golden_disposition_issue": "https://github.com/taipei49314/checkwash/issues/567",
    "golden_proposal_accepted": False, "release_allowed_by_this_checkpoint": False,
    "version": "0.10.0", "IR_VERSION": 3, "FINDINGS_VERSION": 2,
    "collected_parent_tests": 21102, "collection_is_not_pass_count": True,
    "full_suite": "NOT_STARTED_AT_THIS_CHECKPOINT",
    "fixed_source_311_312_corpus": {"case_count": 1117, "raw_bytes_equal": True,
        "bytes_per_arm": 8873976, "sha256": "1305fa51b86ce3a987107603e182920bdcdd02f25b2e5f59ebd4634a64165d54",
        "same_Windows_host_not_cross_OS": True},
    "qualification_snapshot": jobs,
    "preservation": {"global_memory_and_original_nested_archives": "LOCAL_ONLY_NOT_PUBLICLY_UPLOADED",
                     "runtime_venvs_cache_fixture_temporaries": "LOCAL_INTERMEDIATES_NOT_IN_THIS_CHECKPOINT",
                     "original_failed_and_partial_receipts": "PRESERVED_NOT_RECLASSIFIED"},
}
(payload / "checkpoint.json").write_text(json.dumps(metadata, sort_keys=True, indent=2), encoding="utf-8")
readme = f'''# CheckWash 0.10.0 handoff checkpoint

This is a task backup, not a product release or an acceptance receipt.
Snapshot time: {metadata["created_utc"]}. Product work is not being rushed for
the host transition. Read `checkpoint.json` for the state of this snapshot.

## Source to continue

- Product source: `{PIN}` on `fix/ux-repairs-20261026`.
- Review: https://github.com/taipei49314/checkwash/pull/566
- Eight unchanged golden expectations: https://github.com/taipei49314/checkwash/issues/567
- Package 0.10.0, IR3, findings2. No 0.10.0/1.0 tag, Release or PyPI
  publication is performed by this backup. Stop for the maintainer before 1.0.

The handoff branch inherits the source but adds evidence. Check out the exact
product SHA in a clean task checkout before testing; do not label this handoff
commit as tested product source. Keep downloaded evidence outside that checkout.
Read the source's STATE.md, AGENTS.md and docs/repair-integration-0.10.0.md.
Use current host policy and actual hostname/runtime. PJU receipts retain
HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL; copying them never certifies another host.
Do not investigate the stopped pool outage or revive consumed history/model runs.

## Completed and pending

All core repair code is integrated. The 1,117-case full findings+IR corpus is
byte-identical on Windows Python 3.11.9 and 3.12.14; 3.12 focused tests passed.
The final 36 native observations retain 26 explicit assertions and 10 observation
rows; use the report for the exact 24 BLOCK / 12 PASS and baseline differences.
The full 21,102-parent-test run has not started at this snapshot. Artifact
qualifications may still be running; their partial stream prefixes are not PASS.
Other OS/Python 3.13/native file-symlink coverage is not inferred.

The eight golden labels are unchanged and unresolved. `golden/UNADOPTED-*` is
an inert proposal, not a human approval or a modified-judge PASS. Do not apply it
without the individual disposition. No exemptions or acceptance waivers were
added to make this candidate green. Original failed/partial records remain.

## Privacy and continuation

Original local milestone ZIPs contain full global context and nested older ZIPs.
They are preserved locally and are not blindly published. This checkpoint
contains only task-specific source identity, controls, partial raw prefixes and
resume tools. Runtime environments, caches and fixture temporary repositories
are excluded. A later checkpoint can append completed raw evidence and results.

`resume-tools` computes the original task layout from its location. Restore into
an equivalent separate task workspace, inspect absolute interpreter paths, and
create isolated environments appropriate to the authorized host. Historical raw
paths/times must remain historical; do not rewrite them or synthesize missing
results. Interrupted ordinary qualification may be run fresh under a new label,
retaining the partial attempt. This does not resume any consumed once-only batch.
'''
(payload / "00-START-HERE.md").write_text(readme, encoding="utf-8")
members = []
for path in sorted(payload.rglob("*")):
    if path.is_file():
        raw = path.read_bytes()
        members.append({"path": path.relative_to(payload).as_posix(), "bytes": len(raw),
                        "sha256": hashlib.sha256(raw).hexdigest()})
(payload / "MANIFEST.json").write_text(json.dumps({"kind": metadata["checkpoint_kind"],
    "code_source_sha": PIN, "created_utc": metadata["created_utc"], "files": members}, sort_keys=True, indent=2), encoding="utf-8")

index_env = {**base_env, "GIT_INDEX_FILE": str(OUT / "alternate.index"),
             "GIT_AUTHOR_NAME": "Codex checkpoint", "GIT_AUTHOR_EMAIL": "checkpoint@example.invalid",
             "GIT_COMMITTER_NAME": "Codex checkpoint", "GIT_COMMITTER_EMAIL": "checkpoint@example.invalid"}
git("read-tree", parent, env=index_env)
blobs = []
for path in sorted(payload.rglob("*")):
    if not path.is_file():
        continue
    remote_path = PREFIX + "/" + path.relative_to(payload).as_posix()
    raw = path.read_bytes()
    oid = git("hash-object", "-w", "--stdin", input=raw, env=index_env).decode().strip()
    git("update-index", "--add", "--cacheinfo", "100644", oid, remote_path, env=index_env)
    blobs.append({"path": remote_path, "git_blob": oid, "sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw)})
tree = git("write-tree", env=index_env).decode().strip()
message = f"checkpoint: retain {PIN[:8]} handoff progress at {stamp}\n\nTask-only backup; not product acceptance, publication or golden approval.\n"
commit = git("-c", "commit.gpgsign=false", "commit-tree", tree, "-p", parent,
             input=message.encode(), env=index_env).decode().strip()
git("push", "origin", commit + ":refs/heads/" + BRANCH)
remote_after = git("ls-remote", "--heads", "origin", "refs/heads/" + BRANCH).decode().strip()
assert remote_after.split()[0] == commit
assert git("rev-parse", "HEAD").decode().strip() == PIN
assert not git("status", "--porcelain", "--untracked-files=all")
result = {"branch": BRANCH, "checkpoint_commit": commit, "tree": tree, "code_source_sha": PIN,
          "created_utc": metadata["created_utc"], "prefix": PREFIX, "payload": str(payload),
          "files": blobs, "bytes": sum(row["bytes"] for row in blobs), "head_unchanged": True,
          "remote_ref_verified": True, "product_publication_performed": False}
(OUT / "push-receipt.json").write_text(json.dumps(result, sort_keys=True, indent=2), encoding="utf-8")
state_path.write_text(json.dumps(result, sort_keys=True, indent=2), encoding="utf-8")
print(json.dumps({key: value for key, value in result.items() if key != "files"}, indent=2))
