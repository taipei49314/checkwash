"""Read raw final corpus streams without normalizing/reordering any field."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'final' / 'corpus-311-312-comparison-r1'
OUT.mkdir(exist_ok=False)
arms = []
for label in ('corpus-311-r1', 'corpus-312-r1'):
    folder = ROOT / 'final' / label
    raw = (folder / 'stdout.txt').read_bytes()
    stderr = (folder / 'stderr.txt').read_bytes()
    receipt_raw = (folder / 'receipt.json').read_bytes()
    receipt = json.loads(receipt_raw)
    headers = [line[2:].decode('utf-8') for line in raw.splitlines() if line.startswith(b'# ')]
    arms.append({'label': label, 'raw': raw, 'headers': headers,
        'stdout_sha256': hashlib.sha256(raw).hexdigest(), 'stdout_bytes': len(raw),
        'stderr_sha256': hashlib.sha256(stderr).hexdigest(), 'stderr_bytes': len(stderr),
        'receipt_sha256': hashlib.sha256(receipt_raw).hexdigest(), 'receipt': receipt,
        'header_count': len(headers), 'unique_header_count': len(set(headers))})
left, right = arms
equal = left['raw'] == right['raw']
payload = {'marker': 'HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL',
    'comparison': 'RAW_COMPLETE_FINDINGS_PLUS_IR_BYTES_NO_NORMALIZATION_NO_FIELD_REMOVAL',
    'source_sha': '8a8941dc2d7c581715a0f6f196c00da6c55f084b', 'raw_bytes_equal': equal,
    'headers_equal': left['headers'] == right['headers'], 'case_count_from_raw_headers': left['header_count'],
    'source_input_manifests_equal': left['receipt']['input_manifest_sha256'] == right['receipt']['input_manifest_sha256'],
    'arms': [{key: value for key, value in arm.items() if key not in {'raw', 'headers'}} for arm in arms],
    'not_run': ['Python3.13', 'other operating systems'],
    'acceptance_boundary': 'Byte determinism only, not golden-label acceptance; eight #567 failures remain open'}
if not equal:
    first = next((i for i, (a, b) in enumerate(zip(left['raw'], right['raw'])) if a != b),
                 min(len(left['raw']), len(right['raw'])))
    payload['first_different_byte'] = first
    payload['left_context_repr'] = repr(left['raw'][max(0, first-120):first+180])
    payload['right_context_repr'] = repr(right['raw'][max(0, first-120):first+180])
assert all(arm['receipt']['exit_code'] == 0 and arm['receipt']['source_files_unchanged']
           and arm['receipt']['source_sha'] == payload['source_sha']
           and arm['receipt']['ending_sha'] == payload['source_sha'] for arm in arms)
assert left['header_count'] == right['header_count'] == left['unique_header_count'] == right['unique_header_count']
(OUT / 'comparison.json').write_bytes((json.dumps(payload, indent=2) + '\n').encode())
print(json.dumps({key: value for key, value in payload.items() if key != 'arms'}, indent=2))
print(json.dumps([{key: arm[key] for key in ('label', 'stdout_sha256', 'stdout_bytes', 'header_count')}
                  for arm in arms], indent=2))
raise SystemExit(0 if equal and payload['headers_equal'] and payload['source_input_manifests_equal'] else 1)
