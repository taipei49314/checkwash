"""Replay the original 36 static controls on one frozen candidate source.

Uses the original trusted fixture constructor; fixture Python is never run.
Uses the adopted sealed 0.10.0 core contracts; no fixture program runs.
"""
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import re
import subprocess
import sys
import zipfile

HERE = Path(__file__).resolve().parent
SESSION = HERE.parents[2]
REPO = SESSION / "work/checkwash-ux"
OLD = SESSION / "work/rename"
EXPECTED = "8a8941dc2d7c581715a0f6f196c00da6c55f084b"
SOURCE = HERE / "source-candidate"
assert sys.argv[1:] == [EXPECTED], "exact frozen source argument required"
assert not (HERE / "results.json").exists() and not (HERE / "source-candidate.zip").exists(), "fresh attempt required"

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def git_read(*args):
    result = subprocess.run(["git", "-C", str(REPO), *args], env=os.environ,
                            stdin=subprocess.DEVNULL, capture_output=True, timeout=60, check=True)
    return result.stdout

head = git_read("rev-parse", "HEAD").decode().strip()
assert head == EXPECTED and git_read("status", "--porcelain") == b"", "product is not frozen/clean"
tracked_inputs = [OLD / "reproduce.py", OLD / "supplement.py", OLD / "results.json", OLD / "supplement/results.json", SESSION / "work/ux-stage2/final-compat/run.py", SESSION / "work/ux-stage2/final-compat/case-inputs.json", SESSION / "work/ux-stage2/final-compat/comparison.json"]
old_hashes = {str(path.relative_to(SESSION)): digest(path.read_bytes()) for path in tracked_inputs}
archive = git_read("archive", "--format=zip", EXPECTED, "src")
(HERE / "source-candidate.zip").write_bytes(archive)
tree = git_read("ls-tree", "-r", "-z", EXPECTED, "--", "src")
expected_files = {}
for row in tree.split(b"\0"):
    if not row:
        continue
    metadata, path = row.split(b"\t", 1)
    mode, kind, oid = metadata.split()
    assert kind == b"blob" and mode in {b"100644", b"100755"}
    expected_files[path.decode("utf-8")] = {"mode": mode.decode(), "git_blob": oid.decode()}

spec = importlib.util.spec_from_file_location("original_static_fixture_driver", OLD / "reproduce.py")
original = importlib.util.module_from_spec(spec)
spec.loader.exec_module(original)
original.HERE = HERE
original.SOURCES = {"candidate": EXPECTED}
original.CASES = dict(original.CASES)
# This is the identical expression/tuple from the original supplement.py.
original.CASES["cross_file_param_changed"] = (
    original.BASE, original.BASE.replace("(10,20)", "(10,999999)"), True,
    ["D-rename-evasion/#7-1b", "B2-git-worktree/#8"])

case_inputs = {}
for name, (before, after, move, claims) in original.CASES.items():
    for freeze in (False, True):
        key = name + ("/freeze" if freeze else "/default")
        task = "---\ncheckwash:\n  oracle_freeze: " + str(freeze).lower() + "\n---\n"
        case_inputs[key] = {"before_sha256": digest(before.encode()), "after_sha256": digest(after.encode()),
                            "before": before, "after": after, "move": move, "task": task,
                            "task_sha256": digest(task.encode()),
                            "production": "def calc(x):\n    return x * 2\n"}
input_bytes = json.dumps(case_inputs, sort_keys=True, indent=2).encode("utf-8")
assert input_bytes == (SESSION / "work/ux-stage2/final-compat/case-inputs.json").read_bytes(), "original fixture input bytes changed"
(HERE / "case-inputs.json").write_bytes(input_bytes)

def source_files():
    current = {path.relative_to(SOURCE).as_posix(): path.read_bytes()
               for path in (SOURCE / "src").rglob("*") if path.is_file()}
    assert set(current) == set(expected_files), "candidate source member set differs"
    result = {}
    for path, content in current.items():
        blob = hashlib.sha1(b"blob " + str(len(content)).encode("ascii") + b"\0" + content).hexdigest()
        assert blob == expected_files[path]["git_blob"], "source Git blob differs: " + path
        result[path] = {**expected_files[path], "sha256": digest(content)}
    return result

original_run = original.run
journal = []
before_source = None

def recorded_run(command, cwd, env, raw):
    global before_source
    assert len(journal) < 36, "candidate CLI budget exceeded"
    if before_source is None:
        before_source = source_files()
        # Every source member is checked against the exact 8a Git blob map.
        # The former UX-only gating equality is superseded by the adopted core.
        seal = json.loads((SESSION / "work/ux-stage4/seal/source-seal.json").read_bytes())
        assert seal["source_sha"] == EXPECTED and seal["all_tracked_bytes_match_git"]
        seal_files = {row["path"]: row for row in seal["files"] if row["path"].startswith("src/")}
        assert set(seal_files) == set(before_source)
        for path, row in before_source.items():
            assert row["git_blob"] == seal_files[path]["git_blob"]
            assert row["sha256"] == seal_files[path]["sha256"]
    parts = raw.relative_to(HERE / "raw").parts
    _label, name, mode, entry = parts
    prepared = case_inputs[name + "/" + mode]
    after_path = "tests/test_moved.py" if prepared["move"] else "tests/test_calc.py"
    assert (cwd / after_path).read_bytes() == prepared["after"].encode("utf-8")
    assert (cwd / "calc.py").read_bytes() == prepared["production"].encode("utf-8")
    assert (cwd / "TASK.md").read_bytes() == prepared["task"].encode("utf-8")
    assert command[:4] == [sys.executable, "-B", "-m", "checkwash"]
    bootstrap = f"import sys;sys.path.insert(0,{str(SOURCE / 'src')!r});from checkwash.cli import main;raise SystemExit(main())"
    isolated = [sys.executable, "-I", "-B", "-X", "utf8", "-c", bootstrap, *command[4:]]
    # The outer root capture supplies a credential-free allowlist environment.
    allowed_extra = {"PYTHONPATH", "PYTHONDONTWRITEBYTECODE", "PYTHONUTF8"}
    assert not any(key.startswith(("GH_", "GITHUB_", "OPENAI_", "AWS_", "AZURE_")) for key in env)
    result, receipt = original_run(isolated, cwd, env, raw)
    journal.append({"case": name, "freeze": mode == "freeze", "entry": entry,
                    "recorded_utc": datetime.now(timezone.utc).isoformat(), "receipt": receipt,
                    "source_sha": EXPECTED, "case_input_sha256": digest(json.dumps(prepared, sort_keys=True).encode())})
    (HERE / "execution-journal.json").write_text(json.dumps(journal, indent=2), encoding="utf-8")
    return result, receipt

git_journal = []
def recorded_git(arguments, cwd, env):
    command = ["git", *arguments]
    result = subprocess.run(command, cwd=cwd, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
    stem = HERE / "git-raw" / f"{len(git_journal):04d}"
    stem.parent.mkdir(exist_ok=True)
    stdout, stderr = stem.with_suffix(".stdout"), stem.with_suffix(".stderr")
    stdout.write_bytes(result.stdout)
    stderr.write_bytes(result.stderr)
    git_journal.append({"command": command, "cwd": str(cwd), "exit": result.returncode,
                        "stdout": str(stdout.relative_to(HERE)), "stdout_sha256": digest(result.stdout),
                        "stderr": str(stderr.relative_to(HERE)), "stderr_sha256": digest(result.stderr)})
    (HERE / "git-journal.json").write_text(json.dumps(git_journal, indent=2), encoding="utf-8")
    if result.returncode:
        raise RuntimeError(result.stderr.decode("utf-8", "replace"))
    return result.stdout.decode("ascii").strip()

original.git = recorded_git
original.run = recorded_run
started = datetime.now(timezone.utc).isoformat()
original.main()
candidate = json.loads((HERE / "results.json").read_text(encoding="utf-8"))
assert len(candidate["results"]) == len(journal) == 36
after_source = source_files()
assert before_source == after_source
assert git_read("rev-parse", "HEAD").decode().strip() == EXPECTED
assert git_read("status", "--porcelain") == b""
assert old_hashes == {str(path.relative_to(SESSION)): digest(path.read_bytes()) for path in tracked_inputs}, "old evidence/driver changed"

baselines = {}
for path in (OLD / "results.json", OLD / "supplement/results.json"):
    data = json.loads(path.read_text(encoding="utf-8"))
    for row in data["results"]:
        key = (row["source_label"], row["case"], row["oracle_freeze"], row["entry"])
        assert key not in baselines
        baselines[key] = (path, row)
comparisons = []
for row in candidate["results"]:
    for label in ("v090", "v091"):
        path, old = baselines[(label, row["case"], row["oracle_freeze"], row["entry"])]
        candidate_payload = json.loads((HERE / row["receipt"]["stdout"]).read_bytes())
        old_raw = (path.parent / old["receipt"]["stdout"]).read_bytes()
        assert digest(old_raw) == old["receipt"]["stdout_sha256"]
        old_payload = json.loads(old_raw)
        candidate_schema = {key: type(value).__name__ for key, value in candidate_payload.items()}
        baseline_schema = {key: type(value).__name__ for key, value in old_payload.items()}
        fields = ("exit", "verdict", "summary", "config_errors", "skipped_files", "findings")
        differences = [key for key in fields if row[key] != old[key]]
        if candidate_schema != baseline_schema:
            differences.append("payload_schema")
        if candidate_payload["checkwash_findings_version"] != old_payload["checkwash_findings_version"]:
            differences.append("findings_schema")
        new_err = (HERE / row["receipt"]["stderr"]).read_bytes()
        old_err = (path.parent / old["receipt"]["stderr"]).read_bytes()
        assert digest(new_err) == row["receipt"]["stderr_sha256"]
        assert digest(old_err) == old["receipt"]["stderr_sha256"]
        if new_err != old_err:
            differences.append("stderr_bytes")
        comparisons.append({"case": row["case"], "oracle_freeze": row["oracle_freeze"], "entry": row["entry"],
                            "candidate_source": EXPECTED, "baseline_label": label, "baseline_source": old["source_sha"],
                            "differences": differences, "candidate_receipt": row["receipt"], "baseline_receipt": old["receipt"],
                            "candidate_schema": candidate_schema, "baseline_schema": baseline_schema,
                            "candidate_exit": row["exit"], "baseline_exit": old["exit"],
                            "candidate_verdict": row["verdict"], "baseline_verdict": old["verdict"],
                            "candidate_findings": row["findings"], "baseline_findings": old["findings"]})
required_controls = []
for row in candidate["results"]:
    check = None
    if row["oracle_freeze"] and row["case"] in {"A", "B", "cross_file_param_changed"}:
        check = (row["exit"] == 1 and row["verdict"] == "block"
                 and any(f["severity"] in {"high", "critical"} for f in row["findings"]))
    elif row["case"] in {"N_unroll_changed", "control_same_name_changed"}:
        check = row["exit"] == 1 and row["verdict"] == "block"
    elif row["case"] in {"control_rename_only", "control_cross_file_move", "control_unroll_preserved"}:
        check = row["exit"] == 0 and row["verdict"] == "pass" and not row["findings"]
    assert row["config_errors"] == [] and row["skipped_files"] == [], "not an analysed control"
    if check is not None:
        required_controls.append({"case": row["case"], "freeze": row["oracle_freeze"], "entry": row["entry"], "passed": check})
receipt = {"provenance": "HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL", "hostname": platform.node(),
           "python": sys.version, "executable": sys.executable, "source_sha": EXPECTED,
           "started_utc": started, "ended_utc": datetime.now(timezone.utc).isoformat(),
           "archive_sha256": digest(archive), "case_inputs_sha256": digest(input_bytes),
           "case_input_count": len(case_inputs), "cli_calls": len(journal), "source_files_before": before_source,
           "source_files_after": after_source, "source_unchanged": before_source == after_source,
           "old_inputs_unchanged": old_hashes, "candidate_matrix": "original 32 primary + 4 supplemental static CLI controls",
           "comparison_count": len(comparisons), "comparisons": comparisons,
           "differing_pairs": sum(bool(row["differences"]) for row in comparisons),
           "fixture_execution": "NOT_RUN; fixture Python only statically analyzed",
           "adopted_core_contracts": True, "git_command_count": len(git_journal),
           "required_controls": required_controls, "required_control_failures": [row for row in required_controls if not row["passed"]],
           "scope": "bounded single candidate arm; no new historical sweep or model/adjudication batch"}
(HERE / "comparison.json").write_text(json.dumps(receipt, indent=2), encoding="utf-8")
print(json.dumps({key: receipt[key] for key in ("source_sha", "cli_calls", "comparison_count", "differing_pairs", "source_unchanged", "archive_sha256", "case_inputs_sha256")}))
raise SystemExit(1 if receipt["required_control_failures"] else 0)
