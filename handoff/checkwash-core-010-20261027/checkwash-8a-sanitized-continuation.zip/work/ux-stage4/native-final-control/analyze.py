"""Read native streams and committed fixture bytes; no product imports/calls."""
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

HERE = Path(__file__).resolve().parent
EXPECTED = "8a8941dc2d7c581715a0f6f196c00da6c55f084b"
comparison = json.loads((HERE / "comparison.json").read_bytes())
results = json.loads((HERE / "results.json").read_bytes())
capture_path = HERE.parent / "final/native-final-rename-r1/receipt.json"
capture = json.loads(capture_path.read_bytes())
assert comparison["source_sha"] == EXPECTED and comparison["source_unchanged"]
assert capture["source_sha"] == capture["ending_sha"] == EXPECTED
assert capture["exit_code"] == 0 and capture["source_files_unchanged"] and not capture["changed_inputs"]
assert len(results["results"]) == comparison["cli_calls"] == 36
assert comparison["comparison_count"] == len(comparison["comparisons"]) == 72
assert len(comparison["required_controls"]) == 26 and not comparison["required_control_failures"]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


derivation = json.loads((HERE / "derivation.json").read_bytes())
assert sha(HERE / "run.py") == derivation["derived_driver_sha256"]
assert sha(Path(derivation["source_driver"])) == derivation["source_driver_sha256"]
inputs = json.loads((HERE / "case-inputs.json").read_bytes())
before_verified = {}
before_commands = []
for row in results["results"]:
    mode = "freeze" if row["oracle_freeze"] else "default"
    key = row["case"] + "/" + mode
    if key in before_verified:
        continue
    prepared = inputs[key]
    repo = Path(row["receipt"]["cwd"])
    assert repo.resolve().is_relative_to((HERE / "repos").resolve())
    assert re.fullmatch(r"[0-9a-f]{40}", row["base"])
    command = ["git", "show", row["base"] + ":tests/test_calc.py"]
    process = subprocess.run(command, cwd=repo, env=os.environ, capture_output=True, timeout=30)
    raw = HERE / "before-verification" / row["case"] / mode
    raw.parent.mkdir(parents=True, exist_ok=True)
    stdout, stderr = raw.with_suffix(".stdout"), raw.with_suffix(".stderr")
    stdout.write_bytes(process.stdout)
    stderr.write_bytes(process.stderr)
    before_commands.append({"command": command, "cwd": str(repo), "exit": process.returncode,
                            "stdout": str(stdout.relative_to(HERE)), "stdout_sha256": sha(stdout),
                            "stderr": str(stderr.relative_to(HERE)), "stderr_sha256": sha(stderr)})
    (HERE / "before-verification-commands.json").write_text(json.dumps(before_commands, indent=2), encoding="utf-8")
    assert process.returncode == 0 and process.stdout == prepared["before"].encode("utf-8")
    after_path = "tests/test_moved.py" if prepared["move"] else "tests/test_calc.py"
    assert (repo / after_path).read_bytes() == prepared["after"].encode("utf-8")
    assert (repo / "TASK.md").read_bytes() == prepared["task"].encode("utf-8")
    assert (repo / "calc.py").read_bytes() == prepared["production"].encode("utf-8")
    before_verified[key] = {"before_sha256": sha(stdout), "after_sha256": sha(repo / after_path),
                            "task_sha256": sha(repo / "TASK.md"), "production_sha256": sha(repo / "calc.py")}
assert len(before_verified) == len(before_commands) == 18
rows = []
for row in results["results"]:
    receipt = row["receipt"]
    for stream in ("stdout", "stderr"):
        assert sha(HERE / receipt[stream]) == receipt[stream + "_sha256"]
    payload = json.loads((HERE / receipt["stdout"]).read_bytes())
    assert payload["findings"] == row["findings"]
    assert payload["checkwash_findings_version"] == 2
    assert payload["run"]["checkwash_version"] == "0.10.0"
    assert row["config_errors"] == row["skipped_files"] == []
    asserted = any(check["case"] == row["case"] and check["freeze"] == row["oracle_freeze"]
                   and check["entry"] == row["entry"] for check in comparison["required_controls"])
    rows.append({"case": row["case"], "freeze": row["oracle_freeze"], "entry": row["entry"],
                 "exit": row["exit"], "verdict": row["verdict"], "explicit_expected_control": asserted,
                 "findings": row["findings"], "stderr_sha256": receipt["stderr_sha256"]})

by_baseline = {}
for label in ("v090", "v091"):
    pairs = [row for row in comparison["comparisons"] if row["baseline_label"] == label]
    by_baseline[label] = {
        "pairs": len(pairs), "differing_pairs": sum(bool(row["differences"]) for row in pairs),
        "difference_fields": dict(Counter(field for row in pairs for field in row["differences"])),
        "verdict_moves": dict(Counter(row["baseline_verdict"] + " -> " + row["candidate_verdict"]
                                      for row in pairs if row["baseline_verdict"] != row["candidate_verdict"])),
    }

analysis = {
    "source_sha": EXPECTED, "provenance": "HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL",
    "mode": "READ_ONLY_RAW_RECEIPT_ANALYSIS_NO_PRODUCT_IMPORT",
    "capture_receipt": str(capture_path), "capture_receipt_sha256": sha(capture_path),
    "capture_source_manifest_sha256": capture["input_manifest_sha256"],
    "runner_sha256": sha(HERE / "run.py"), "runner_derivation_sha256": sha(HERE / "derivation.json"),
    "analysis_helper_sha256": sha(Path(__file__)),
    "source_archive_sha256": comparison["archive_sha256"],
    "case_inputs_sha256": comparison["case_inputs_sha256"],
    "input_bytes_equal_original_stage2": True,
    "actual_fixture_inputs_verified": before_verified,
    "before_verification_git_commands": len(before_commands),
    "cli_observations": len(rows), "explicit_expected_controls": 26,
    "observation_only_rows": 10, "explicit_expected_failures": [],
    "exit_counts": dict(Counter(str(row["exit"]) for row in rows)),
    "verdict_counts": dict(Counter(row["verdict"] for row in rows)),
    "findings_schema": 2, "reported_checkwash_version": "0.10.0",
    "baseline_comparisons": by_baseline, "observations": rows,
    "comparison_sha256": sha(HERE / "comparison.json"), "results_sha256": sha(HERE / "results.json"),
    "execution_journal_sha256": sha(HERE / "execution-journal.json"),
    "git_journal_sha256": sha(HERE / "git-journal.json"),
    "git_fixture_commands": comparison["git_command_count"],
    "fixture_programs_executed": False,
    "scope_limits": [
        "36 synthetic CLI observations; 26 explicit expected outcome checks and 10 fully observed comparison rows.",
        "Deltas from the two preserved baselines are observations, not an automatic zero-delta acceptance gate.",
        "Eight existing D179 golden expectation costs remain unchanged and separately tracked by root; this native subset does not waive them.",
        "PJU Windows Python 3.11.9 only; no native file-symlink, Python 3.13, other OS, wheel/pyz or release-stage coverage is supplied by this run.",
    ],
}
(HERE / "analysis.json").write_text(json.dumps(analysis, ensure_ascii=False, indent=2), encoding="utf-8")
lines = ["# Final sealed 36 synthetic CLI controls", "",
         "Source: `" + EXPECTED + "`; HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL; Windows Python 3.11.9.", "",
         "The outer capture exited 0 and retained the same sealed HEAD and complete source file map. All 36 CLI streams were read back with exact hashes, findings2 and reported version0.10.0. The 18 before/after/TASK input groups are byte-identical to the original stage2 input JSON (`" + comparison["case_inputs_sha256"] + "`). A further 18 read-only Git show commands verified each actual committed BASE fixture; all actual after/TASK/production bytes also matched the old inputs. Their raw streams are preserved separately. Fixture programs were not executed.", "",
         "There are 26 explicit expected outcome checks: frozen A/B/parameter-change high BLOCK, bad literal controls BLOCK, and pure rename/move/legitimate unroll PASS. All passed. Ten additional rows are fully recorded observations and baseline comparisons; exit0 does not silently turn those into extra preregistered outcome assertions.", "",
         "| Case | Freeze | Entry | Exit | Verdict | Findings | Expected check |",
         "|---|---|---|---:|---|---|---|"]
for row in rows:
    findings = ", ".join(f["rule"] + "/" + f["severity"] for f in row["findings"]) or "none"
    lines.append(f"| {row['case']} | {row['freeze']} | {row['entry']} | {row['exit']} | {row['verdict']} | {findings} | {'yes' if row['explicit_expected_control'] else 'observation only'} |")
lines += ["", "## Two preserved baseline comparisons", ""]
for label, observed in by_baseline.items():
    lines.append(f"- {label}: {observed['pairs']} paired observations, {observed['differing_pairs']} differing pairs; fields={observed['difference_fields']}; verdict moves={observed['verdict_moves']}.")
lines += ["", "comparison.json retains complete candidate and baseline finding dictionaries, including fingerprints, escalators and deescalators, plus schema/exit/stderr deltas and stream references. Deltas are intentionally retained rather than forced to zero. Old producers, fixture definitions, raw evidence and labels were verified unchanged.", "",
          "## Limits", ""]
lines += ["- " + limit for limit in analysis["scope_limits"]]
lines += ["", "The unchanged eight golden expectation costs remain a separate acceptance issue; this bounded run does not claim a passing full suite or release qualification.", ""]
(HERE / "report.md").write_text("\n".join(lines), encoding="utf-8")
print(json.dumps({key: analysis[key] for key in ("source_sha", "cli_observations", "explicit_expected_controls",
    "observation_only_rows", "exit_counts", "verdict_counts", "baseline_comparisons", "case_inputs_sha256")}, indent=2))
