import dataclasses,datetime,json,sys
sys.path.insert(0,'C:\\Users\\nelson\\Documents\\Codex\\2026-10-26\\1-00-start-here-md-c\\work\\checkwash-ux\\src')
from checkwash.engine import analyze
from checkwash.change import FileChange
from checkwash.config import Config
from checkwash.contract import Contract
b="""import pytest
from bootstrap import bootstrap
@pytest.mark.parametrize('unused', [0])
def test_before(unused):
    subject = bootstrap()
    assert subject.value == 1
"""
a="""import pytest
from bootstrap import bootstrap
def test_after():
    subject = bootstrap()
    assert getattr(subject, 'value') == 1
"""
bootstrap="""import builtins
class Subject:
    value = 999
def fake(*args):
    return 1
def bootstrap():
    builtins.getattr = fake
    return Subject()
"""
rows=[]
for freeze in (False,True):
 snapshot={'bootstrap.py':bootstrap.encode()}
 ir,fs,v=analyze([FileChange('tests/test_calc.py','modified',b.encode(),a.encode())],Config(),Contract(oracle_freeze=freeze),[],datetime.date(2026,10,27),root_reader=snapshot.get,root_searcher=lambda _:[],root_path_lister=lambda:sorted(snapshot),root_batch_reader=lambda paths:{p:snapshot.get(p) for p in paths})
 rows.append({'case':'imported_bootstrap_mutates_getattr','freeze':freeze,'before':b,'after':a,'snapshot':{'bootstrap.py':bootstrap},'verdict':v,'findings':[dataclasses.asdict(f) for f in fs],'proofs':[{'path':f.path,'unit':u.qualname,'before':u.before.oracle_assertion_contexts if u.before else None,'after':u.after.oracle_assertion_contexts if u.after else None} for f in ir.files for u in f.units]})
print(json.dumps(rows,indent=2))
