# Independent adversarial oracle-credit review — stage4 working source

Current result: six observed blockers were repaired and independently read
back. The final bounded readback has18expected observations, including three
legitimate PASS controls, with no remaining blocker for these measured shapes.
This is not final-source qualification or a blanket oracle-safety claim.

Reviewer `/root/rename_repro`, independent of implementation owner
`/root/quality_fix`. Actual LAPTOP-01AGNPJU / Python3.11.9,
`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`. Product source/golden labels were not
edited by this review. Closed CheckWash analyzer calls parse the supplied
source strings; no supplied Python/JavaScript fixture program is executed.
No product CLI, model, history/cohort or paid batch is run by this review.

Each probe has stdout/stderr plus a receipt with command, runtime and raw
hashes of oracle_credit.py/engine.py/gating.py before/after. Those maps are
stable for each execution and deliberately identify shared working bytes,
not an uncommitted change falsely attributed to HEAD. Prior raw results
remain unchanged across author fixes and later readbacks.

## P1-1 — removing unknown prior assertions from JS execution context

The original `_javascript_context` removed every preceding assertion from
the prefix used to prove a later assertion's identity. Moving
`expect(advance()).toBe(1); expect(current()).toBe(1)` into two callbacks,
with current first and advance second, therefore retained both spendable
proofs. Actual closed analysis returned PASS and TEST_DISABLED/info with
ASSERTION_MOVED, fingerprint
`TEST_DISABLED/tests/a.test.js/old/v2:73882414dbd6dafa770703b0667182204d5c00e92ef3202ea8f436b2a1219882`.

Unknown calls in an assertion can mutate state used by another assertion.
An inert illustrative subject starts state1, advance sets999 and returns1,
current reads state. This explains the possible weakening; that subject was
not executed, and the review does not claim a runtime pytest/Jest result.
`probe-initial.stdout` retains the actual old analyzer PASS and proof keys.

Author repair retains unknown prior/suffix execution context, allowing only
the deliberately bounded pure-literal case to be omitted. Re-running the
original probe on the changed working source yields high/BLOCK and no credit.
Resolved for this measured shape, recorded in `three-blocker-readback.json`.

## P1-2 — builtin getattr proof despite mutation of the builtin namespace

The original scanner rejected Name/alias/argument shadowing but missed
`builtins.getattr = fake`. `_Concrete` then rewrote a genuinely different
getattr call into attribute access. With one unused literal parameter row
before and no parameter after, the false assertion proofs made the D5 mass
candidate pass at warn/RESTRUCTURED. Actual fingerprint:
`TEST_DISABLED/tests/test_calc.py/test_before/v2:bce941e81b2d8621156856d675ddcfa49f3aa50d1d37204cfe9e8350d0f1a886`.
Both versions already assign the builtin to fake; the changed oracle is the
switch from `subject.value == 1` to `getattr(subject, 'value') == 1`.
Subject.value999/fake-return1 are inert original source constants.

`probe-prefix-and-getattr.stdout` retains the actual PASS and identical
assertion proof0301e41c...7306. The simpler cross-file no-param shape was
already high/BLOCK; it is preserved as a negative rather than mislabeled an
escape. The author now rejects Attribute/Subscript namespace writes,
aliases, dynamic builtin namespace operations and relevant Store/Del shapes.
The exact exploited parameter/restructure case now yields high/BLOCK with
no compensation in the independent original-probe readback. Resolved for
that measured case; author-owned alias/dictionary tests remain separate.

## P1-3 — bare relative side-effect import lost its address

`import './setup'` was absent from both the named-binding import set and the
fallback relative-import regex. Moving an otherwise identical test from
tests/a.test.js to tests/sub/b.test.js with that unchanged specifier changed
the actual setup address, but the whole-unit proof stayed equal. Both default
and oracle_freeze returned info/ASSERTION_MOVED/PASS, fingerprint
`TEST_DISABLED/tests/a.test.js/same/v2:546e05b014f076e1c9643d82d71d0946cc424fdd8b31f89b3e5fc5f14b4557b6`.
The named-import counterpart correctly blocked and is a negative control.

The author added bare-import code-mask/directory identity. All four original
bare/named import controls now return high/BLOCK, including freeze. The
separate legitimate named import adjusted from `./subject` to `../subject`
still passes, as does unchanged ordinary string data `./data` across those
directories. Thus this review checks the source/address boundary without
turning every relative-looking data string into an import.

## P1-4 — package initialization absent from startup proof

The original `engine._relocation_startup` hashed the conftest chain but not the
package `__init__.py` chain that executes when pytest imports a test module.
The corrected closed probe supplies root_reader, root_path_lister and
root_batch_reader with valid unchanged sources:

```python
# common.py
CURRENT = 1
# tests/left/__init__.py
import common
common.CURRENT = 999
# tests/right/__init__.py
import common
common.CURRENT = 1
# identical moved test source
from common import CURRENT
def test_read():
    assert CURRENT == 1
```

Moving only that test from tests/left/test_a.py to tests/right/test_b.py returns
actual info/ASSERTION_MOVED/PASS. The before/after whole-unit proof is the
same3b8951da...af6e; fingerprint
`TEST_DISABLED/tests/left/test_a.py/test_read/v2:456f889e890cd2f2bf55dcc98d6d905635016127fc08f640c4fe90cd7e53f466`.
The different package initializers can change the imported value even though
the function's absolute import text is unchanged. A correct conftest-scope
negative blocks, so that control alone does not establish package startup
equivalence. Original/current branch outcome and all supplied snapshot bytes
are in `probe-controls-and-startup-corrected.stdout` with stable source hashes.

This was sent immediately to author/root. Bind admitted package initializers
into startup identity or decline proof when that scope is unknown; do not
claim the empty conftest list proves the complete startup environment. The
review does not implement that policy or execute the subject code.

The first snapshot-map version accidentally held literal backslash-n in
some supplied module bytes. It is retained as the initial controls probe and
is superseded for snapshot-dependent conclusions. The corrected probe uses
actual newlines and again observes the package-startup PASS; the other valid
conftest control remains BLOCK. This fixture correction is disclosed rather
than using the malformed initial source as a runtime counterexample.

## Controls and credit accounting

The corrected6-control readback confirms three legitimate controls pass:
Python pure rename, ordinary JS relative-looking string data, and a named JS
relative import updated to the same resolved module. Two removals with one
arriving assertion produce only one info credit and leave the second high,
so the analysis blocks. Different conftest startup scopes block. No additional
credit double-spend was reproduced in these bounded controls.

The earlier8-row three-blocker readback is all high/BLOCK and has no errors;
that alone did not resolve the subsequently found package-initializer gap.
Its later resolution is recorded below. No existing fixture label was changed to
turn a counterexample or new conservative cost green. Final whole-suite,
native CLI/Action, other language/runtime coverage and release acceptance
belong to root's later fixed-source validation and are not supplied by this
closed analyzer review.

## Fourth correction and subsequent module-identity blocker

The author added admitted ancestor package initializers to startup identity,
with explicit file/depth/byte bounds and unknown-context refusal. The original
valid package probe now returns high/BLOCK. Re-reading the original first
three probes and corrected6-control group gives14expected outcomes, including
the three legitimate positives and credit/startup negatives. All three source
hashes stayed stable through this readback. These results are retained in
`four-blocker-readback-plus-helper.json`; P1-4 is resolved for that shape.

**P1-5 observed:** context-sensitive names inside an unselected helper
escape the selected-test-only Name scan. The unchanged source:

```python
def identify():
    return __name__

def test_oracle():
    assert identify() == "test_b"
```

is deleted at tests/test_a.py and added at tests/test_b.py. The helper's
module-dependent return changes with module identity, while the current
environment proof hashes the same helper AST without binding that identity.
Actual default and freeze analyses both yield info/ASSERTION_MOVED/PASS,
with equal whole-unit proof4e932920...49a7 and fingerprint
`TEST_DISABLED/tests/test_a.py/test_oracle/v2:abe02ec3b1924f6a0be240697bd487ae725f67bf0907bb8fa789aa393f9c0476`.
The subject was not executed; the observed claim is the analyzer's incorrect
equivalence credit for this context-dependent helper. The raw two observations
are in `probe-helper-module-name.stdout`, with the enclosing stable-source
readback metadata above.

This was reported immediately to author/root. Apply the existing
context-sensitive-name rule to relevant module/helper AST, or bind the actual
module identity when a bounded proof supports it. `__file__`, helper default
expressions and equivalent module-state reads must not become safe merely
because the selected test reaches them through another function. The reviewer
does not change that implementation or silently approve its compatibility
costs. That checkpoint remained OPEN pending this fifth exact fix/readback.

## P1-6 — builtin canonicalization across an imported prior call

Root supplied a narrower extension of P1-2: the test module contains only
`import pytest`, `from bootstrap import bootstrap` and the selected test.
Before, one unused literal parameter row runs `subject = bootstrap()` then
`assert subject.value == 1`. After, the same prefix is followed by
`assert getattr(subject, 'value') == 1` in the unparameterized renamed test.
The complete supplied closed snapshot includes `bootstrap.py`: Subject.value
is 999, fake returns1, and bootstrap assigns `builtins.getattr = fake` before
returning Subject. No supplied program is imported or executed.

Actual analyzer default verdict is PASS with TEST_DISABLED/warn/RESTRUCTURED;
freeze is BLOCK with high/ORACLE_FREEZE, while still carrying RESTRUCTURED.
Both assertion proof keys equal a84497a1...79007. The fingerprint is the same
test-before fingerprint recorded in P1-2. The default PASS therefore depends
on assuming builtin identity across an unknown prior call, even though the
provided import source explicitly contains the mutation. The observation is
not described as a freeze escape or a measured runtime test outcome.

`probe-imported-bootstrap.stdout` retains both full findings, proof keys and
all supplied source strings. Its receipt records stable oracle source
e3c8cdb68bf151159630379ca55788abad61fa427fb57df9b2a4cb3c2529e9a8,
engine f3ad9f34db31dc168a119a788ace37dbea60e8b834cf175b1ca5165384b8096d
and gating 2a84a2018fa5dbcb4f2e0506b10a9e0cb931779c6aab236c4bdbccf3308ad7ec.
The new actual result was sent immediately to author/root. Later product
edits require an independent readback; this receipt is not overwritten.

## Final independent readback and its limits

After the author explicitly froze source, the reviewer reran the six existing
probe scripts once, writing new `.six-final-readback.stdout`/`.stderr` files.
All six child processes exited0. The18observations match their expectations:
the original JS execution-context, builtin mutation, relative import and
package-startup counterexamples block; both helper/module-identity analyses
block; both imported-bootstrap analyses block without RESTRUCTURED.
Python pure rename, ordinary JS relative-looking data and the adjusted named
JS import still pass. Two removals cannot spend one arriving assertion twice.

P1-5 is resolved for the measured helper because the context-sensitive-name
scan now covers the module AST, including helpers/defaults. P1-6 is resolved
by removing the unsafe builtin getattr-to-attribute canonicalization. In its
new raw results, the before assertion proof a84497a1...79007 differs from the
after proof85056a6d...4e8a. This intentionally withholds credit from otherwise
legitimate wrapper modernization where builtin identity is not proved; the
author records that compatibility cost rather than changing existing golden
labels or calling arbitrary imported code safe. Literal parameter substitution
and exact-context relocation remain admitted in the measured normal controls.

`six-blocker-final-readback.json` binds all commands, exits, raw stream/input
hashes and findings. All three watched source hashes remained unchanged:

- oracle_credit.py: dae96be0b17b411dfbdd3e44f03aafbebbfd87ecefbbeacee1d483b44de20155
- engine.py: f3ad9f34db31dc168a119a788ace37dbea60e8b834cf175b1ca5165384b8096d
- gating.py: 2a84a2018fa5dbcb4f2e0506b10a9e0cb931779c6aab236c4bdbccf3308ad7ec

These are working-tree bytes, not a claim that the observed changes belonged
to any earlier HEAD. This readback runs no product CLI, no subject program,
no history, and no model batch. The result is PASS for this bounded independent
review; full-suite, native entry-point, cross-runtime/platform qualification
and final acceptance remain separate root-owned work. It is not proof that
every semantic equivalence or future oracle attack is handled.
