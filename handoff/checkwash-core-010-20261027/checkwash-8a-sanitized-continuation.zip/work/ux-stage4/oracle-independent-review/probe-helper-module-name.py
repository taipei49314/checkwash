import dataclasses,datetime,json,sys
sys.path.insert(0,'C:\\Users\\nelson\\Documents\\Codex\\2026-10-26\\1-00-start-here-md-c\\work\\checkwash-ux\\src')
from checkwash.engine import analyze
from checkwash.change import FileChange
from checkwash.config import Config
from checkwash.contract import Contract
source='def identify():\n    return __name__\n\ndef test_oracle():\n    assert identify() == "test_b"\n'.replace('\\n','\n')
rows=[]
for freeze in (False,True):
 changes=[FileChange('tests/test_a.py','deleted',source.encode(),None),FileChange('tests/test_b.py','added',None,source.encode())]
 ir,fs,v=analyze(changes,Config(),Contract(oracle_freeze=freeze),[],datetime.date(2026,10,27),root_reader=lambda _:None,root_searcher=lambda _:[])
 rows.append({'case':'python_helper_module_identity','freeze':freeze,'source':source,'verdict':v,'findings':[dataclasses.asdict(f) for f in fs],'contexts':[{'path':f.path,'before':u.before.oracle_context if u.before else None,'after':u.after.oracle_context if u.after else None} for f in ir.files for u in f.units]})
print(json.dumps(rows,indent=2))
