"""Capture existing inert-source probes against author-frozen working bytes."""
import datetime
import hashlib
import importlib.util
import json
import pathlib
import platform
import socket
import subprocess
import tempfile

HERE = pathlib.Path(__file__).resolve().parent
SESSION = HERE.parents[2]
PRODUCT = SESSION / 'work' / 'checkwash-ux'
PYTHON = pathlib.Path(r'C:\Users\nelson\AppData\Local\Programs\Python\Python311\python.exe')
GIT = pathlib.Path(r'C:\Program Files\Git\cmd\git.exe')
BASH = pathlib.Path(r'C:\Program Files\Git\bin\bash.exe')
HELPER = SESSION / 'work' / 'trusted' / 'replay_pju_action.py'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def source_hashes():
    return {name: sha(PRODUCT / 'src' / name) for name in (
        'checkwash/oracle_credit.py', 'checkwash/engine.py', 'checkwash/gating.py')}

spec = importlib.util.spec_from_file_location('trusted_cleanenv', HELPER)
trusted = importlib.util.module_from_spec(spec)
spec.loader.exec_module(trusted)
before = source_hashes()
records = []
observations = []
with tempfile.TemporaryDirectory(prefix='cw-o6-') as scratch:
    env = trusted.clean_environment(PYTHON, GIT, BASH, pathlib.Path(scratch))
    for name in ('probe-initial', 'probe-prefix-and-getattr', 'probe-side-effect-import',
                 'probe-controls-and-startup-corrected', 'probe-helper-module-name',
                 'probe-imported-bootstrap'):
        script = HERE / (name + '.py')
        command = [str(PYTHON), '-I', '-B', '-X', 'utf8', str(script)]
        result = subprocess.run(command, cwd=scratch, env=env, capture_output=True, timeout=60)
        stdout = HERE / (name + '.six-final-readback.stdout')
        stderr = HERE / (name + '.six-final-readback.stderr')
        stdout.write_bytes(result.stdout)
        stderr.write_bytes(result.stderr)
        records.append({'command': command, 'script_sha256': sha(script), 'exit': result.returncode,
                        'stdout': stdout.name, 'stdout_sha256': sha(stdout),
                        'stderr': stderr.name, 'stderr_sha256': sha(stderr)})
        if result.returncode:
            raise RuntimeError('Probe child failed; retain raw streams')
        rows = json.loads(result.stdout)
        for row in rows:
            expected = row.get('expected', 'block')
            observations.append({'probe': name, 'case': row.get('case'), 'freeze': row.get('freeze'),
                                 'expected': expected, 'verdict': row['verdict'],
                                 'matches_expected': row['verdict'] == expected,
                                 'findings': row['findings']})
after = source_hashes()
payload = {'marker': 'HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL',
           'source_kind': 'SHARED_WORKING_TREE_NOT_HEAD', 'hostname': socket.gethostname(),
           'runtime': platform.python_version(), 'observed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'source_hashes_before': before, 'source_hashes_after': after,
           'source_unchanged': before == after, 'cleanenv_helper_sha256': sha(HELPER),
           'fixture_programs_executed': False, 'product_cli_calls': 0,
           'scope': 'Existing six review probe scripts only; no new fixture shape, CLI or model batch',
           'commands': records, 'observations': observations,
           'all_expected': all(row['matches_expected'] for row in observations)}
(HERE / 'six-blocker-final-readback.json').write_bytes((json.dumps(payload, indent=2) + '\n').encode())
print(json.dumps({'source_unchanged': payload['source_unchanged'], 'count': len(observations),
                  'all_expected': payload['all_expected'], 'source_hashes': after}, indent=2))
if not payload['source_unchanged'] or not payload['all_expected']:
    raise SystemExit(1)
