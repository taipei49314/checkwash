"""Hash the independent review's retained raw files and derived summary."""
import hashlib
import json
import pathlib
import shutil

HERE = pathlib.Path(__file__).resolve().parent
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

manifest = HERE / 'manifest.json'
prior = HERE / 'manifest-before-final-readback.json'
if prior.exists():
    raise SystemExit('Prior manifest already preserved; do not overwrite')
shutil.copyfile(manifest, prior)
old = json.loads(prior.read_bytes())
checks = []
for name, expected in old['files'].items():
    if name == 'report.md':
        continue
    actual = sha(HERE / name)
    checks.append({'path': name, 'expected': expected, 'actual': actual, 'matches': actual == expected})
readback = json.loads((HERE / 'six-blocker-final-readback.json').read_bytes())
for row in readback['commands']:
    for stream in ('stdout', 'stderr'):
        checks.append({'path': row[stream], 'expected': row[stream + '_sha256'],
                       'actual': sha(HERE / row[stream]),
                       'matches': sha(HERE / row[stream]) == row[stream + '_sha256']})
validation = {'marker': readback['marker'], 'preservation_scope': 'All prior manifest members except intentionally updated report; prior manifest retained byte-exact',
              'raw_hash_checks': checks, 'raw_hashes_match': all(c['matches'] for c in checks),
              'observations': len(readback['observations']), 'all_expected': readback['all_expected'],
              'watched_source_unchanged': readback['source_unchanged'],
              'all_subprocesses_exit0': all(c['exit'] == 0 for c in readback['commands'])}
(HERE / 'validation.json').write_bytes((json.dumps(validation, indent=2) + '\n').encode())
if not all((validation['raw_hashes_match'], validation['all_expected'], validation['watched_source_unchanged'],
            validation['all_subprocesses_exit0'], validation['observations'] == 18)):
    raise SystemExit('Review validation failed; retain raw and derived records')
payload = {'marker': readback['marker'], 'scope': 'Independent working-source oracle review; closed analyzer calls, no CLI/fixture program/model execution',
           'result': 'PASS_BOUNDED_REVIEW_NOT_FINAL_QUALIFICATION',
           'source_kind': readback['source_kind'], 'source_hashes': readback['source_hashes_after'],
           'blockers_resolved': ['JS prior assertion context', 'builtin getattr namespace shadowing',
                                 'bare static relative import identity', 'package __init__ startup identity',
                                 'helper/module identity', 'imported prior-call builtin canonicalization'],
           'blockers_open': [], 'compatibility_cost': 'No getattr-wrapper-to-attribute equivalence credit without proof',
           'files': {p.name: sha(p) for p in sorted(HERE.iterdir()) if p.is_file() and p.name != 'manifest.json'}}
manifest.write_bytes((json.dumps(payload, indent=2) + '\n').encode())
print(json.dumps({'report_sha256': sha(HERE / 'report.md'), 'manifest_sha256': sha(manifest),
                  'readback_sha256': sha(HERE / 'six-blocker-final-readback.json'),
                  'file_count': len(payload['files']), 'raw_checks': len(checks),
                  'validation': validation['raw_hashes_match']}, indent=2))
