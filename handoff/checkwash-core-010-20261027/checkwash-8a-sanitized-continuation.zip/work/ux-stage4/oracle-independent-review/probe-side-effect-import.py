import dataclasses,datetime,json,sys
sys.path.insert(0,'C:\\Users\\nelson\\Documents\\Codex\\2026-10-26\\1-00-start-here-md-c\\work\\checkwash-ux\\src')
from checkwash.engine import analyze
from checkwash.change import FileChange
from checkwash.config import Config
from checkwash.contract import Contract
rows=[]
for named in (False,True):
 source=('import { actual } from "./setup"\n' if named else 'import "./setup"\n')+'test("same", () => { expect(actual()).toBe(42) })\n';source=source.replace('\\n','\n')
 for freeze in (False,True):
  changes=[FileChange('tests/a.test.js','deleted',source.encode(),None),FileChange('tests/sub/b.test.js','added',None,source.encode())]
  ir,fs,v=analyze(changes,Config(),Contract(oracle_freeze=freeze),[],datetime.date(2026,10,27),root_reader=lambda _:None,root_searcher=lambda _:[])
  rows.append({'case':'js_named_relative_import_control' if named else 'js_side_effect_relative_import','freeze':freeze,'before_path':'tests/a.test.js','after_path':'tests/sub/b.test.js','source':source,'verdict':v,'findings':[dataclasses.asdict(f) for f in fs],'contexts':[{'path':f.path,'before':u.before.oracle_context if u.before else None,'after':u.after.oracle_context if u.after else None} for f in ir.files for u in f.units]})
print(json.dumps(rows,indent=2))
