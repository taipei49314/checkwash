import dataclasses,datetime,json,sys
sys.path.insert(0,'C:\\Users\\nelson\\Documents\\Codex\\2026-10-26\\1-00-start-here-md-c\\work\\checkwash-ux\\src')
from checkwash.engine import analyze
from checkwash.change import FileChange
from checkwash.config import Config
from checkwash.contract import Contract
b='from subject import advance, current\ndef test_old():\n    assert advance() == 1\n    assert current() == 1\n'.replace('\\n','\n')
a='from subject import advance, current\ndef test_new1():\n    assert current() == 1\ndef test_new2():\n    assert advance() == 1\n'.replace('\\n','\n')
header='import builtins\nclass Subject:\n    value = 999\n\ndef fake(obj, name):\n    return 1\n'.replace('\\n','\n')
gb=header+'import pytest\n@pytest.mark.parametrize("unused", [0])\ndef test_before(unused):\n    subject = Subject()\n    builtins.getattr = fake\n    assert subject.value == 1\n'.replace('\\n','\n')
ga=header+'def test_after():\n    subject = Subject()\n    builtins.getattr = fake\n    assert getattr(subject, "value") == 1\n'.replace('\\n','\n')
rows=[]
for name,changes in [('python_prior_assertion_prefix',[FileChange('tests/test_a.py','deleted',b.encode(),None),FileChange('tests/test_b.py','added',None,a.encode())]),('python_getattr_shadow_restructure',[FileChange('tests/test_calc.py','modified',gb.encode(),ga.encode())])]:
 ir,fs,v=analyze(changes,Config(),Contract(),[],datetime.date(2026,10,27),root_reader=lambda _:None,root_searcher=lambda _:[])
 rows.append({'case':name,'changes':[dataclasses.asdict(c)|{'before':c.before.decode() if c.before else None,'after':c.after.decode() if c.after else None} for c in changes],'verdict':v,'findings':[dataclasses.asdict(f) for f in fs],'proofs':[{'path':f.path,'unit':u.qualname,'before':u.before.oracle_assertion_contexts if u.before else None,'after':u.after.oracle_assertion_contexts if u.after else None} for f in ir.files for u in f.units]})
print(json.dumps(rows,indent=2))
