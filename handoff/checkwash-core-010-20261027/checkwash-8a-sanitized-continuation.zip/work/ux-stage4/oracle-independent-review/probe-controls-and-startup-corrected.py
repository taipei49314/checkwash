import dataclasses,datetime,json,sys
sys.path.insert(0,'C:\\Users\\nelson\\Documents\\Codex\\2026-10-26\\1-00-start-here-md-c\\work\\checkwash-ux\\src')
from checkwash.engine import analyze
from checkwash.change import FileChange
from checkwash.config import Config
from checkwash.contract import Contract
cases=[]
py='from calc import calc\ndef test_old():\n    assert calc(1) == 2\n'.replace('\\n','\n')
cases.append(('python_pure_rename', [FileChange('tests/test_calc.py','modified',py.encode(),py.replace('test_old','test_new').encode())],{},'pass'))
j='const expected = "./data";\ntest("old", () => { expect(actual()).toBe(expected) })\n'.replace('\\n','\n')
cases.append(('js_relative_literal_data', [FileChange('tests/a.test.js','deleted',j.encode(),None),FileChange('tests/sub/b.test.js','added',None,j.replace('"old"','"new"').encode())],{},'pass'))
j='import { actual } from "./subject"\ntest("old", () => { expect(actual()).toBe(1) })\n'.replace('\\n','\n');a=j.replace('"./subject"','"../subject"').replace('"old"','"new"')
cases.append(('js_named_import_adjusted_to_same_address',[FileChange('tests/a.test.js','deleted',j.encode(),None),FileChange('tests/sub/b.test.js','added',None,a.encode())],{},'pass'))
b=py+'\ndef test_second():\n    assert calc(1) == 2\n'.replace('\\n','\n');a=py.replace('test_old','test_new')
cases.append(('python_two_removals_one_arrival',[FileChange('tests/test_a.py','deleted',b.encode(),None),FileChange('tests/test_b.py','added',None,a.encode())],{},'block'))
cases.append(('python_changed_conftest_scope',[FileChange('tests/left/test_a.py','deleted',py.encode(),None),FileChange('tests/right/test_b.py','added',None,py.encode())],{'tests/left/conftest.py':b'FLAG=1\n','tests/right/conftest.py':b'FLAG=2\n'},'block'))
package_test='from common import CURRENT\ndef test_read():\n    assert CURRENT == 1\n'.replace('\\n','\n')
startup={'common.py':b'CURRENT=1\n','tests/__init__.py':b'','tests/left/__init__.py':b'import common\ncommon.CURRENT=999\n','tests/right/__init__.py':b'import common\ncommon.CURRENT=1\n','tests/right/test_b.py':package_test.encode()}
cases.append(('python_package_initialization_scope',[FileChange('tests/left/test_a.py','deleted',package_test.encode(),None),FileChange('tests/right/test_b.py','added',None,package_test.encode())],startup,'block'))
rows=[]
for name,changes,snapshot,expected in cases:
 snapshot={k:v.replace(bytes([92,110]),bytes([10])) for k,v in snapshot.items()}
 kwargs={'root_reader':snapshot.get,'root_searcher':lambda _:[]}
 if name=='python_package_initialization_scope':kwargs.update(root_path_lister=lambda:sorted(snapshot),root_batch_reader=lambda paths:{p:snapshot.get(p) for p in paths})
 ir,fs,v=analyze(changes,Config(),Contract(),[],datetime.date(2026,10,27),**kwargs)
 rows.append({'case':name,'expected':expected,'verdict':v,'findings':[dataclasses.asdict(f) for f in fs],'snapshot_source':{k:v.decode() for k,v in snapshot.items()},'contexts':[{'path':f.path,'before':u.before.oracle_context if u.before else None,'after':u.after.oracle_context if u.after else None} for f in ir.files for u in f.units]})
print(json.dumps(rows,indent=2))
