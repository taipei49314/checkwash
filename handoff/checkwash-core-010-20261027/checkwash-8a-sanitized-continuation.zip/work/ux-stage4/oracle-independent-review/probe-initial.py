import dataclasses,datetime,json,sys
sys.path.insert(0,'C:\\Users\\nelson\\Documents\\Codex\\2026-10-26\\1-00-start-here-md-c\\work\\checkwash-ux\\src')
from checkwash.engine import analyze
from checkwash.change import FileChange
from checkwash.config import Config
from checkwash.contract import Contract
python_before="""import builtins
class Subject:
    value = 999

def fake(obj, name):
    return 1

def test_obj_attribute():
    subject = Subject()
    builtins.getattr = fake
    assert subject.value == 1
"""
python_after=python_before.replace('assert subject.value == 1','assert getattr(subject, "value") == 1')
js_before='import { advance, current } from "./subject"\n'+'test("old", () => { expect(advance()).toBe(1); expect(current()).toBe(1) })\n'
js_after='import { advance, current } from "./subject"\n'+'test("new1", () => { expect(current()).toBe(1) })\n'+'test("new2", () => { expect(advance()).toBe(1) })\n'
cases=[('python_builtin_getattr_shadow','tests/test_a.py','tests/test_b.py',python_before,python_after),('javascript_prior_assertion_prefix','tests/a.test.js','tests/b.test.js',js_before.replace('\\n','\n'),js_after.replace('\\n','\n'))]
rows=[]
for name,left,right,b,a in cases:
 changes=[FileChange(left,'deleted',b.encode(),None),FileChange(right,'added',None,a.encode())]
 ir,findings,verdict=analyze(changes,Config(),Contract(),[],datetime.date(2026,10,27),root_reader=lambda _:None,root_searcher=lambda _:[])
 rows.append({'case':name,'before':b,'after':a,'verdict':verdict,'findings':[dataclasses.asdict(f) for f in findings],'proofs':[{'path':f.path,'unit':u.qualname,'before_context':u.before.oracle_context if u.before else None,'after_context':u.after.oracle_context if u.after else None,'before_assertions':u.before.oracle_assertion_contexts if u.before else None,'after_assertions':u.after.oracle_assertion_contexts if u.after else None} for f in ir.files for u in f.units]})
print(json.dumps(rows,indent=2))
