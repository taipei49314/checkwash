"""Preserve actual old/new static findings for unchanged historical labels."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys

HERE = Path(__file__).resolve().parent
SESSION = HERE.parents[2]
REPO = SESSION / "work/checkwash-ux"
OUT = HERE / sys.argv[1]
OUT.mkdir(exist_ok=False)
(OUT / "fixtures").mkdir()
(OUT / "raw").mkdir()
OLD = SESSION / "work/ux-stage3/policy-shadow/source"
NEW = OUT / "working-tree-source"
shutil.copytree(REPO / "src", NEW / "src", ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def manifest(root):
    return {path.relative_to(root).as_posix(): digest(path) for path in sorted((root / "src").rglob("*"))
            if path.is_file() and path.suffix != ".pyc" and "__pycache__" not in path.parts}
old_map, new_map = manifest(OLD), manifest(NEW)
assert new_map == manifest(REPO)
cases = ["bare_bound_then_used_neg", "split_rename_genuine_neg", "unittest_keyword_split_neg",
         "test_split_neg", "subject_pairing_other_subject_known_limit_pos",
         "assert_removed_moved_neg", "js_chai_property_moved_neg"]
env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", PYTHONUTF8="1")
env.pop("PYTHONPATH", None)
rows = []
for name in cases:
    source = REPO / "tests/cases" / (name + ".gwcase")
    fixture = OUT / "fixtures" / source.name
    fixture.write_bytes(source.read_bytes())
    original = subprocess.check_output(["git", "show", "9a5a27f44c895ba2fdee8c83a6313baf0e120873:tests/cases/" + source.name], cwd=REPO)
    assert hashlib.sha256(original).hexdigest() == digest(fixture)
    arms = {}
    for label, root in (("frozen-9a", OLD), ("working-tree", NEW)):
        command = [sys.executable, "-B", str(HERE / "cost_arm.py"), str(root), str(fixture)]
        started = datetime.datetime.now(datetime.timezone.utc).isoformat()
        proc = subprocess.run(command, cwd=OUT, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60)
        stem = OUT / "raw" / (name + "." + label)
        Path(str(stem) + ".stdout").write_bytes(proc.stdout)
        Path(str(stem) + ".stderr").write_bytes(proc.stderr)
        assert proc.returncode == 0, proc.stderr.decode("utf-8", "replace")
        arms[label] = {"command": command, "cwd": str(OUT), "api_harness_exit_not_cli_exit": proc.returncode,
            "started": started, "finished": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "stdout_sha256": hashlib.sha256(proc.stdout).hexdigest(), "stderr_sha256": hashlib.sha256(proc.stderr).hexdigest(),
            "payload": json.loads(proc.stdout)}
    rows.append({"case": name, "fixture_sha256": digest(fixture), "arms": arms})
result = {"marker": "HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL", "hostname": socket.gethostname(),
    "runtime": sys.version, "executable": sys.executable, "baseline_source_sha": "9a5a27f44c895ba2fdee8c83a6313baf0e120873",
    "candidate_binding": "COPIED_DEVELOPMENT_WORKING_TREE_BYTES_NOT_HEAD_QUALIFICATION",
    "old_source_files": old_map, "candidate_source_files": new_map,
    "old_source_unchanged": old_map == manifest(OLD), "candidate_source_unchanged": new_map == manifest(NEW),
    "driver_sha256": digest(Path(__file__)), "arm_driver_sha256": digest(HERE / "cost_arm.py"),
    "static_api_calls": len(rows) * 2, "product_cli_calls": 0, "fixtures_executed": False, "rows": rows}
(OUT / "results.json").write_text(json.dumps(result, ensure_ascii=True, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"calls": len(rows) * 2, "unchanged": result["candidate_source_unchanged"],
    "cases": [{"case": row["case"], "old": row["arms"]["frozen-9a"]["payload"]["verdict"],
               "new": row["arms"]["working-tree"]["payload"]["verdict"]} for row in rows]}, indent=2))
