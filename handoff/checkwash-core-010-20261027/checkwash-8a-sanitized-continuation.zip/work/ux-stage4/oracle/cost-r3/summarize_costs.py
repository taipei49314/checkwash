"""Derived immutable cost register; parses captured data only."""
import hashlib
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE / sys.argv[1]
raw = (ROOT / "results.json").read_bytes()
data = json.loads(raw)
reasons = {
    "bare_bound_then_used_neg": "OUTPUT_ORACLE_REMOVED: output invoice_total==105 replaced by input data equality; a different strong assertion is not the same obligation.",
    "split_rename_genuine_neg": "SUBJECT_NORMALIZED: sorted(options(...)) can conceal return container/type/order differences; same expected literal and mass do not prove equivalence.",
    "unittest_keyword_split_neg": "SUBJECT_NORMALIZED: keyword assertEqual operands are supported; the remaining changed sorted subject is not proven equivalent.",
    "test_split_neg": "UNKNOWN_CHANGED_SETUP: make_app() becomes make_app(automatic_options=True) for one moved assertion; no source/default proof is supplied by the fixture.",
    "subject_pairing_other_subject_known_limit_pos": "UNKNOWN_FIXTURE_REWRITE: two warning tests change fixture/setup/input context; the original independent ASSERT_WEAKENED block remains. Static equivalence of the disappeared units is not established.",
    "assert_removed_moved_neg": "UNKNOWN_ASSERTION_EFFECTS: login calls are reordered across test units; absent source/purity proof, the original unknown prior/following assertion calls cannot be erased from execution context.",
    "js_chai_property_moved_neg": "UNKNOWN_ASSERTION_EFFECTS: isPaid/total calls are reordered across callbacks; no implementation/purity proof is supplied, so the old text-only move label is unresolved conservative cost.",
}
rows = []
for row in data["rows"]:
    before, after = (row["arms"][label]["payload"] for label in ("frozen-9a", "working-tree"))
    rows.append({"case": row["case"], "fixture_sha256": row["fixture_sha256"],
        "fixture_labels_unchanged": True, "old_verdict": before["verdict"], "new_verdict": after["verdict"],
        "old_findings": before["findings"], "new_findings": after["findings"],
        "preserved_expectations": before["preserved_fixture_expectations"],
        "old_expectation_mismatch": before["expectation_mismatch"], "new_expectation_mismatch": after["expectation_mismatch"],
        "classification": reasons[row["case"]], "acceptance": "UNRESOLVED_COMPATIBILITY_GATE_NOT_RELABELLED",
        "raw_prefix": ROOT.name + "/raw/" + row["case"]})
register = {"source": ROOT.name + "/results.json", "source_sha256": hashlib.sha256(raw).hexdigest(),
    "marker": data["marker"], "hostname": data["hostname"], "runtime": data["runtime"],
    "baseline_source_sha": data["baseline_source_sha"], "candidate_binding": data["candidate_binding"],
    "static_api_calls": data["static_api_calls"], "product_cli_calls": 0, "rows": rows,
    "finding_keys_recomputed_from_actual_arms": True, "existing_fixture_labels_changed": False,
    "candidate_new_pass_to_block_cases": sum(r["old_verdict"] == "pass" and r["new_verdict"] == "block" for r in rows)}
target = ROOT / "immutable-cost-register.json"
with target.open("x", encoding="utf-8", newline="\n") as stream:
    stream.write(json.dumps(register, ensure_ascii=True, indent=2) + "\n")
lines = ["# Unresolved historical fixture movements — exact old/new observations", "",
    f"HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL. {data['static_api_calls']} static API arms, zero CLI calls; fixture programs were never run.",
    "Old source is frozen 9a5a. Candidate is the copied development working-tree source map in results.json, not a HEAD qualification.",
    "Original .gwcase bytes equal their 9a5a Git blobs. Labels and raw are unchanged; actual per-arm findings and movements are below.", "",
    "| Case | Observed old → new | Why no proof / retained cost |", "|---|---|---|"]
for row in rows:
    lines.append(f"| {row['case']} | {row['old_verdict']} → {row['new_verdict']} | {row['classification']} |")
lines += ["", "Every row retains exact old/new finding dictionaries, fingerprints, escalators/de-escalators, raw stream hashes and original expectations in immutable-cost-register.json/results.json.",
    "These are unresolved compatibility failures, not adopted relabels, reviewer-approved FP rates or release acceptance.",
    "New bad/legitimate controls remain separately in tests/test_oracle_credit_context.py; their passing results do not waive these historical gates.",
    "The earlier cost-r1 pre-execution source-map failure is retained with ABORT.md; it ran no API arm."]
with (ROOT / "cost-table.md").open("x", encoding="utf-8", newline="\n") as stream:
    stream.write("\n".join(lines) + "\n")
print(json.dumps({"register_sha256": hashlib.sha256(target.read_bytes()).hexdigest(), "rows": len(rows)}, indent=2))
