# D-180 — Retain prior-BASE review for quality policy maintenance

Text for root to integrate into protected SPEC/DECISIONS under Nelson's
2026-10-27 instruction to complete the core changes, allowing 0.x version
advancement and requiring another decision before 1.0. This adopts option A
from the preserved stage-3 quality-trust packet; option B remains unadopted.

## DECISIONS text

Quality policy and exemption maintenance retains prior-BASE authority and
the two existing trust lanes. Main `check` continues to classify an edit of
an existing `.checkwash/quality-allow.toml` as GUARDRAIL_TOUCHED/critical.
Quality continues to report a schema-valid append at warn and evaluates
only eligible BASE entries. A new HEAD entry cannot excuse that same
comparison. A quality `reported` result with exit 0 is not a clean result,
does not replace main `check`, and does not establish that main's required
check passed. Each required lane must run against its intended range.

The concrete second-entry friction is deliberately retained: the preserved
18 native controls show append-only report and enforce comparisons with
main BLOCK/1 versus quality reported/0. An existing exact eligible BASE
entry still works. Expired or wrong-target entries do not match; unknown
or malformed quality policy is a hard error. Those observations establish
the lane distinction, not a natural-repository false-positive rate or human
review acceptance of the synthetic fixtures.

The maintenance route remains exact prior review. Capture the intended q1
quality identity and main GUARDRAIL_TOUCHED v2 identity; use the existing
maintainer/BASE review process. If that process uses the main exemption
route, its exact main GUARDRAIL key must already be in a separately accepted
BASE. QW keys never belong in the main ledger. Commit presence alone is
not evidence of human approval. No blanket `quality*` exclusion, broad
"tightening" exemption, generator/ownership self-claim or HEAD self-approval
is introduced. No exemption is added to make this PR pass.

This decision changes protected documentation only, preserving the existing
main and quality executable gate behavior, findings schema, fingerprints,
exit meanings, writers and authority. Initial-creation rules remain their
own contract; D-177's separately bounded main config/allow shadow handling
does not extend to these quality paths. Release/publication acceptance and
the human's pre-1.0 stop remain independent requirements.

## SPEC §6 addition

Main and quality exemption lanes are independent. Edits of existing quality
policy/allow files retain main's guardrail review. Quality `reported`/0 can
include policy warnings and is not a main-check pass. Only eligible entries
in the selected BASE quality policy/ledger can affect that quality comparison;
new HEAD entries and tool-generated ownership claims grant no authority.
Precise maintenance uses the existing prior-BASE review route, without a
blanket quality-path exception or automatic main/quality key translation.

## Evidence and implementation boundary

Original evidence remains `work/ux-stage3/quality-trust/{manifest,validation,
report}.json/md` and its 18 native payloads, plus the independently reviewed
stage-3 packet. No stage-3 raw was rewritten and no native tracked-hook
maintenance lifecycle was repeated. This text claims neither post-change
runtime evidence nor release acceptance; the retained A executable behavior
does not require a new judge path.
