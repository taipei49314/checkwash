# Oracle core implementation handoff

The D2/E2/default A/B/context repair is implemented and the bounded independent
review has no remaining blocker for its six observed counterexample shapes.
Final targeted development tests pass **369/369**. The unchanged historical
golden runner remains **1,111 passed / 8 failed**; those eight compatibility
gates remain open and no `.gwcase` label was changed. This is not release
acceptance or a claim of universal semantic equivalence.

Actual execution: LAPTOP-01AGNPJU, Python 3.11.9,
`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`. Receipts bind physical development
working-tree files through SHA256 maps, commands, raw streams and exits.
They do not claim uncommitted changes were present in HEAD. This child did
not commit/push, call models, run history/cohort batches, execute fixture
programs, repeat the tracked-hook lifecycle or change host configuration.

## What changed

- `oracle_credit.py` provides bounded source-only relocation proofs. Python
  binds literal input/expected pairs, decorators/arguments, module/class/
  import/setup context, prior assertions and following execution. JS/TS
  preserves declaration/execution context and actual static import bindings;
  ordinary strings are data. Unknown callback or module identity, startup,
  syntax or proof resources withhold optional credit.
- `engine.py` attaches those optional proofs and binds conftests plus known
  ancestor package initializers. It uses existing two-sided changed bytes
  and strict snapshot reads, never HEAD as replacement BASE authority.
  Role-expanded old/new paths use their actual expanded source bytes.
- `gating.py` requires context proof for D2/D5. Full-unit arrivals spend
  constituent assertion credit too, preventing body/text double spending.
  Assertion-only credit applies E2 before returning. Known complete-unit
  equality and verified unchanged duplicates retain their early returns.
  Eligible exact BASE exemptions remain first; fail_on meanings remain.
- JS expected provenance now checks a changed resolved local binding even
  when its operand spelling stayed identical. Native tolerance events keep
  their original owner. The existing expected-definition rule/key is used.
- IR3 has optional typed SHA256 context fields. Empty/malformed proof is
  unknown. Stable AST dumping excludes only empty added `type_params` fields;
  nonempty generics do not earn this proof. Historical IR2 is unchanged.

The optional `getattr`→attribute projection was removed after a real imported
bootstrap counterexample. Literal substitution, plain exact-context moves
and ordinary unroll remain. There is no guessed transitive purity closure.
Existing repair evidence, same-unit rewrite, compatibility policies and
other detectors remain separate; no blanket compensation removal or ban
on renaming was introduced.

## Exact tests and preserved review evidence

`final-reviewed-r3/` has pytest exit 0, 369 JUnit tests / 0 failures/errors/
skips, and matching before/after input maps: **89 new controls + 184 existing
consumer/runner/rename controls + 96 provenance controls**. Controls include
direct ASSERT_REMOVED, TEST_DISABLED, Python/JS/TS, default/freeze,
fail_on warn/high/critical, valid/expired BASE entries, legal moves/unroll,
single-use credit, data strings, import resolution, helper identity, package
startup, optional-proof faults and typed/canonical metadata.

`final-corpus-r2/` has pytest exit 1: 1,119 tests, 1,111 passed, eight unchanged
historical labels fail. Their names exactly match
`cost-r4/immutable-cost-register.json`. Its 16 real old/new static API arms
use frozen 9a5a versus a copied working-tree source with an exact input map.
Seven cases move pass→block; the previously blocked fixture remains blocked
with additional findings. The register includes actual full findings/keys,
raw hashes, unchanged fixture bytes and reasons. No waiver or relabel is
implicit in the new contract. Earlier cost-r2/r3 records remain immutable.

The independent `/root/rename_repro` review retained all original red probes
and re-read six scripts / 18 closed observations against the final three
product hashes. All expected results, source stability and raw hashes were
verified. The resolved shapes are unknown assertion side effects, builtin
lookup mutation, bare side-effect import resolution, package startup,
helper module identity and opaque imported bootstrap. Its report expressly
limits the result to those measured shapes, not final qualification.

`native-r1/` contains 24 actual CLI calls: six shapes × default/freeze ×
worktree/range. A/B/B_from_A/cross-file parameter changes block; exact move
and expectation-preserving unroll pass. These bind an **earlier copied
development source**, before the last review corrections, and are not
final-source native qualification. Final native/distribution/full-suite
evidence belongs to root's sealed run.

The first red module is preserved in `original-red-test/`, reconstructed and
hash-identical to red-r1's original 36-case test receipt (24 failures / 12
passes). Its hash is `ea690412591c683848fd2a9002fcb1a148867b8b7892700142c4754fbf530a63`.
Later tests bind their own hashes; an earlier receipt is never relabeled as
having run the later module. The removed getter implementation is likewise
preserved in `pre-getattr-removal/`, explicitly reconstructed, hash-identical
to the independent real red receipt and not imported/compiled/executed.

The old cost-r1 capture stopped on its pre-execution manifest exclusion bug;
its directory/ABORT note remains and it ran zero API arms. Intermediate
failed tests and any shared-tree source movement remain their original
receipts. They are not hidden or called final qualification.

## Reviewable adoption and consumer migration

`D179-oracle-adoption.md` supplies protected decision/spec wording for root.
`D180-quality-A-adoption.md` formally retains prior-BASE review and the
independent main/quality lanes, adding no executable exemption. The old
stage-2/3 proposals and raw remain historical, unmodified artifacts.

Root specifically reviewed the ordinary consumer/test migration in
`D179-cost-ordinary-consumers.md`: owned issue219 snapshots now supply their
strict context with all assertions unchanged; three issue266 ordinary unit
expectations move CREDITED→UNCREDITED for changed/unknown context under
D179/0.10.0. These are not golden/corpus label changes. Unchanged-context
positive controls remain and all 184 existing targeted tests pass.

The eight owned file hashes, full counts, exact readback pointers and
limitations are machine-readable in `development-summary.json`. Product
bytes are frozen for root's atomic integration. No source edit is pending
from this child. Existing bundled Python 3.12.14 is available; its sealed
comparison is pending root. Python 3.13 and other OSes are NOT_RUN. The
human's required stop before 1.0 and all unresolved release gates remain.
