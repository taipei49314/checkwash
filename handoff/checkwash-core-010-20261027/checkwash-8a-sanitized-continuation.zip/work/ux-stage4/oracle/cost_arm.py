"""One synthetic case, static analysis API only; fixture code is never run."""
import dataclasses
import datetime
import json
from pathlib import Path
import sys
sys.path.insert(0, str(Path(sys.argv[1]) / "src"))
from checkwash.cases import parse_case, case_snapshot, case_to_changes, match_expectations
from checkwash.config import Config
from checkwash.contract import Contract, parse_contract
from checkwash.engine import analyze
from checkwash.gitio.snapshot import search_source_mapping
case = parse_case(Path(sys.argv[2]).read_text(encoding="utf-8"))
head = {path: value.encode("utf-8") for path, value in case.head.items()}
snapshot = case_snapshot(case)
ir, findings, verdict = analyze(case_to_changes(case), Config(), parse_contract(case.task) if case.task else Contract(),
    [], datetime.date(2026, 1, 1), head_reader=head.get if head else None,
    head_searcher=(lambda needles: [p for p, data in sorted(head.items()) if any(n.encode() in data for n in needles)]) if head else None,
    root_reader=snapshot.get, root_searcher=lambda needles: search_source_mapping(snapshot, needles))
print(json.dumps({"verdict": verdict, "findings": [dataclasses.asdict(f) for f in findings],
    "preserved_fixture_expectations": case.expect,
    "expectation_mismatch": match_expectations(case.expect, findings),
    "fixture_program_execution": "NOT_RUN_STATIC_API_ANALYSIS_ONLY"}, ensure_ascii=True, indent=2))
