# D-179 ordinary consumer/test migration — root reviewed, not golden relabeling

Root reviewed these exact ordinary unit changes under Nelson's new core
contract authorization. No `.gwcase` bytes or expectations were changed.

| Target | Old setup/assertion | New setup/assertion | Contract reason |
|---|---|---|---|
| test_issue219_python_snapshot_tests.py `run` | owned `HEAD` + `changes.after` snapshot passed only as head_reader | same snapshot additionally passed as root_reader and strict search_source_mapping | supplies the existing explicitly closed fixture context to the new optional proof; all assertions stay identical |
| same module duplicate-survivor API control | same explicit owned snapshot only as head_reader/head_searcher | adds same strict root_reader/root_searcher | same consumer migration, unchanged verdict/label assertions |
| test_issue266 sibling_directory/compat_gate parameterization | both expected CREDITED | sibling remains CREDITED; compat_gate becomes UNCREDITED | deleted unit had no usefixtures; survivor adds fixture execution/conditional skip, so liveness alone is not complete context equivalence |
| changed-conftest second direction | CREDITED after changing startup source and adding fixture execution | UNCREDITED | raw startup context changed; no full-unit oracle equivalence proof; first BLOCK direction stays identical |
| explicit root=False control | CREDITED when strict context is unknown | UNCREDITED with a D179/0.10.0 name/comment | absent proof is unknown, not equality |

Unchanged-context positive controls remain in the original ordinary tests
and new oracle tests. Severity was not lowered, assertions were not relaxed
to allow either result, and no golden/corpus label was edited. The five
recorded immutable historical fixture conflicts remain failing release
compatibility gates, separate from these approved ordinary migrations.
