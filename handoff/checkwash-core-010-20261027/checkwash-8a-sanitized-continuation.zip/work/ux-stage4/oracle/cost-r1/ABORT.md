Capture stopped at the pre-execution source-map equality assertion. No API
arm or product CLI ran. The copied source excludes `__pycache__`/`.pyc`, but
the first manifest function did not exclude them from the shared checkout.
The failed directory remains unchanged. A new label uses the same exclusion
on both maps; no old result is overwritten or called a product failure.
