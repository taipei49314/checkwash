"""Owned test runner: working-tree input hashes, native raw streams and exit."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import socket
import subprocess
import sys

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2] / "work/checkwash-ux"

def hashes():
    paths = sorted((REPO / "src").rglob("*.py")) + sorted(path for path in (REPO / "tests").rglob("*")
        if path.is_file() and path.suffix in {".py", ".gwcase", ".json", ".toml", ".yaml", ".yml"})
    return {path.relative_to(REPO).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest() for path in paths}

label, *targets = sys.argv[1:]
out = HERE / label
out.mkdir(parents=True, exist_ok=False)
env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", PYTHONUTF8="1", PYTHONPATH=str(REPO / "src"))
for key in tuple(env):
    if key.startswith("PYTEST_"):
        env.pop(key)
env["TMP"] = env["TEMP"] = str(HERE / "tmp")
Path(env["TMP"]).mkdir(exist_ok=True)
command = [sys.executable, "-B", "-m", "pytest", *targets, "-q", "--tb=short", "--junitxml", str(out / "junit.xml"), "--basetemp", str(out / "tmp")]
before = hashes()
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
proc = subprocess.run(command, cwd=REPO, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=180)
(out / "stdout").write_bytes(proc.stdout)
(out / "stderr").write_bytes(proc.stderr)
after = hashes()
receipt = {"marker": "HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL", "hostname": socket.gethostname(),
    "runtime": sys.version, "executable": sys.executable, "platform": platform.platform(),
    "started": started, "finished": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "source_binding": "DEVELOPMENT_SHARED_WORKING_TREE_HASHES_NOT_HEAD_QUALIFICATION",
    "runner_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "command": command, "cwd": str(REPO), "exit": proc.returncode,
    "before": before, "after": after, "inputs_unchanged": before == after,
    "stdout_sha256": hashlib.sha256(proc.stdout).hexdigest(), "stderr_sha256": hashlib.sha256(proc.stderr).hexdigest(),
    "fixture_program_execution": "NOT_RUN_STATIC_ANALYSIS_ONLY"}
(out / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
print(proc.stdout.decode("utf-8", "replace"))
print(json.dumps({key: value for key, value in receipt.items() if key not in ("before", "after")}, indent=2))
