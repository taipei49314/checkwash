import json
from pathlib import Path
import sys
import dataclasses
import datetime
sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "work/checkwash-ux/src"))
from checkwash.engine import analyze
from checkwash.config import Config
from checkwash.contract import Contract
from checkwash.change import FileChange
before = b'test("total", () => { const expected = 75; expect(total()).toBe(expected); });\n'
after = b'test("renamed", () => { const expected = 0; expect(total()).toBe(expected); });\n'
for changes in ([FileChange("tests/value.test.js", "modified", before, after)],
                [FileChange("tests/a.test.js", "deleted", before, None), FileChange("tests/b.test.js", "added", None, before)]):
    ir, findings, verdict = analyze(changes, Config(), Contract(), [], datetime.date(2026, 10, 27),
        root_reader=lambda _: None, root_searcher=lambda _: [])
    print(json.dumps({"files": [dataclasses.asdict(f) for f in ir.files], "findings": [dataclasses.asdict(f) for f in findings], "verdict": verdict}, indent=2))
