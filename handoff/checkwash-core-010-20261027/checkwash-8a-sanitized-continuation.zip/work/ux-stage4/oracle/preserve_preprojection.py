"""Reconstruct removed text outside the product; hash-check historical identity.

This never imports, compiles or executes the preserved proposed source.
"""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2] / "work/checkwash-ux"
text = (REPO / "src/checkwash/oracle_credit.py").read_text(encoding="utf-8")
method = '''    def visit_Call(self, node):
        node = self.generic_visit(node)
        if (isinstance(node.func, ast.Name) and node.func.id == "getattr" and not node.keywords
                and len(node.args) == 2 and isinstance(node.args[1], ast.Constant)
                and isinstance(node.args[1].value, str) and node.args[1].value.isidentifier()):
            return ast.Attribute(value=node.args[0], attr=node.args[1].value, ctx=ast.Load())
        return node'''
guard = '''        if any((isinstance(n, ast.Name) and n.id == "getattr" and isinstance(n.ctx, (ast.Store, ast.Del)))
               or (isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)) and n.name == "getattr")
               or (isinstance(n, ast.alias) and (n.asname or n.name.split(".")[0]) == "getattr")
               or (isinstance(n, ast.arg) and n.arg == "getattr")
               or (isinstance(n, ast.Attribute) and n.attr == "getattr" and isinstance(n.ctx, (ast.Store, ast.Del)))
               or (isinstance(n, ast.Subscript) and isinstance(n.ctx, (ast.Store, ast.Del))
                   and isinstance(n.slice, ast.Constant) and n.slice.value == "getattr")
               or (isinstance(n, ast.Name) and n.id in {"globals", "locals", "vars", "__builtins__", "exec", "eval"})
               or (isinstance(n, ast.Call) and ((isinstance(n.func, ast.Name) and n.func.id in {"setattr", "delattr"})
                   or (isinstance(n.func, ast.Attribute) and n.func.attr in {"setattr", "delattr"})))
               for n in ast.walk(tree)):
            rows = []
'''
point = text.index("\ndef _rows(side):")
text = text[:point].rstrip("\n") + "\n\n" + method + "\n\n\n" + text[point + 1:]
text = text.replace("        rows = _rows(side)\n        prefix = []", "        rows = _rows(side)\n" + guard + "        prefix = []")
expected = "e3c8cdb68bf151159630379ca55788abad61fa427fb57df9b2a4cb3c2529e9a8"
candidates = [text.encode(), text.replace("\n", "\r\n").encode()]
matching = [raw for raw in candidates if hashlib.sha256(raw).hexdigest() == expected]
assert len(matching) == 1, [hashlib.sha256(raw).hexdigest() for raw in candidates]
out = HERE / "pre-getattr-removal"
out.mkdir(exist_ok=False)
(out / "oracle_credit.py").write_bytes(matching[0])
(out / "receipt.json").write_text(json.dumps({"preservation_kind": "RECONSTRUCTED_REMOVED_TEXT_HASH_IDENTICAL_TO_ORIGINAL_INDEPENDENT_RECEIPT",
    "sha256": expected, "original_receipt": "../oracle-independent-review/probe-imported-bootstrap-receipt.json",
    "product_modified": False, "source_imported_compiled_or_executed": False}, indent=2) + "\n", encoding="utf-8")
print(expected)
