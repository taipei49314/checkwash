"""Derived immutable cost register; parses captured data only."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE / "cost-r2"
raw = (ROOT / "results.json").read_bytes()
data = json.loads(raw)
reasons = {
    "bare_bound_then_used_neg": "OUTPUT_ORACLE_REMOVED: output invoice_total==105 replaced by input data equality; a different strong assertion is not the same obligation.",
    "split_rename_genuine_neg": "SUBJECT_NORMALIZED: sorted(options(...)) can conceal return container/type/order differences; same expected literal and mass do not prove equivalence.",
    "unittest_keyword_split_neg": "SUBJECT_NORMALIZED: keyword assertEqual operands are supported; the remaining changed sorted subject is not proven equivalent.",
    "test_split_neg": "UNKNOWN_CHANGED_SETUP: make_app() becomes make_app(automatic_options=True) for one moved assertion; no source/default proof is supplied by the fixture.",
    "subject_pairing_other_subject_known_limit_pos": "UNKNOWN_FIXTURE_REWRITE: two warning tests change fixture/setup/input context; the original independent ASSERT_WEAKENED block remains. Static equivalence of the disappeared units is not established.",
}
rows = []
for row in data["rows"]:
    before, after = (row["arms"][label]["payload"] for label in ("frozen-9a", "working-tree"))
    rows.append({"case": row["case"], "fixture_sha256": row["fixture_sha256"],
        "fixture_labels_unchanged": True, "old_verdict": before["verdict"], "new_verdict": after["verdict"],
        "old_findings": before["findings"], "new_findings": after["findings"],
        "preserved_expectations": before["preserved_fixture_expectations"],
        "old_expectation_mismatch": before["expectation_mismatch"], "new_expectation_mismatch": after["expectation_mismatch"],
        "classification": reasons[row["case"]], "acceptance": "UNRESOLVED_COMPATIBILITY_GATE_NOT_RELABELLED",
        "raw_prefix": "cost-r2/raw/" + row["case"]})
register = {"source": "cost-r2/results.json", "source_sha256": hashlib.sha256(raw).hexdigest(),
    "marker": data["marker"], "hostname": data["hostname"], "runtime": data["runtime"],
    "baseline_source_sha": data["baseline_source_sha"], "candidate_binding": data["candidate_binding"],
    "static_api_calls": 10, "product_cli_calls": 0, "rows": rows,
    "finding_keys_recomputed_from_actual_arms": True, "existing_fixture_labels_changed": False,
    "candidate_new_pass_to_block_cases": sum(r["old_verdict"] == "pass" and r["new_verdict"] == "block" for r in rows)}
target = ROOT / "immutable-cost-register.json"
with target.open("x", encoding="utf-8", newline="\n") as stream:
    stream.write(json.dumps(register, ensure_ascii=True, indent=2) + "\n")
lines = ["# Unresolved historical fixture movements — exact old/new observations", "",
    "HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL. Ten static API arms, zero CLI calls; fixture programs were never run.",
    "Old source is frozen 9a5a. Candidate is the copied development working-tree source map in results.json, not a HEAD qualification.",
    "Original .gwcase bytes equal their 9a5a Git blobs. Labels and raw are unchanged. Four cases actually move PASS→BLOCK; the fifth remains BLOCK with additional high findings.", "",
    "| Case | Observed old → new | Why no proof / retained cost |", "|---|---|---|"]
for row in rows:
    lines.append(f"| {row['case']} | {row['old_verdict']} → {row['new_verdict']} | {row['classification']} |")
lines += ["", "Every row retains exact old/new finding dictionaries, fingerprints, escalators/de-escalators, raw stream hashes and original expectations in immutable-cost-register.json/results.json.",
    "These are unresolved compatibility failures, not adopted relabels, reviewer-approved FP rates or release acceptance.",
    "New bad/legitimate controls remain separately in tests/test_oracle_credit_context.py; their passing results do not waive these historical gates.",
    "The earlier cost-r1 pre-execution source-map failure is retained with ABORT.md; it ran no API arm."]
with (ROOT / "cost-table.md").open("x", encoding="utf-8", newline="\n") as stream:
    stream.write("\n".join(lines) + "\n")
print(json.dumps({"register_sha256": hashlib.sha256(target.read_bytes()).hexdigest(), "rows": len(rows)}, indent=2))
