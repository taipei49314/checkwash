# Unresolved historical fixture movements — exact old/new observations

HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL. Ten static API arms, zero CLI calls; fixture programs were never run.
Old source is frozen 9a5a. Candidate is the copied development working-tree source map in results.json, not a HEAD qualification.
Original .gwcase bytes equal their 9a5a Git blobs. Labels and raw are unchanged. Four cases actually move PASS→BLOCK; the fifth remains BLOCK with additional high findings.

| Case | Observed old → new | Why no proof / retained cost |
|---|---|---|
| bare_bound_then_used_neg | pass → block | OUTPUT_ORACLE_REMOVED: output invoice_total==105 replaced by input data equality; a different strong assertion is not the same obligation. |
| split_rename_genuine_neg | pass → block | SUBJECT_NORMALIZED: sorted(options(...)) can conceal return container/type/order differences; same expected literal and mass do not prove equivalence. |
| unittest_keyword_split_neg | pass → block | SUBJECT_NORMALIZED: keyword assertEqual operands are supported; the remaining changed sorted subject is not proven equivalent. |
| test_split_neg | pass → block | UNKNOWN_CHANGED_SETUP: make_app() becomes make_app(automatic_options=True) for one moved assertion; no source/default proof is supplied by the fixture. |
| subject_pairing_other_subject_known_limit_pos | block → block | UNKNOWN_FIXTURE_REWRITE: two warning tests change fixture/setup/input context; the original independent ASSERT_WEAKENED block remains. Static equivalence of the disappeared units is not established. |

Every row retains exact old/new finding dictionaries, fingerprints, escalators/de-escalators, raw stream hashes and original expectations in immutable-cost-register.json/results.json.
These are unresolved compatibility failures, not adopted relabels, reviewer-approved FP rates or release acceptance.
New bad/legitimate controls remain separately in tests/test_oracle_credit_context.py; their passing results do not waive these historical gates.
The earlier cost-r1 pre-execution source-map failure is retained with ABORT.md; it ran no API arm.
