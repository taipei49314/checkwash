"""24 bounded native CLI controls; owned fixture programs are never executed."""
import ast
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import socket
import subprocess
import sys

HERE = Path(__file__).resolve().parent
SESSION = HERE.parents[2]
REPO = SESSION / "work/checkwash-ux"
OUT = HERE / sys.argv[1]
OUT.mkdir(exist_ok=False)
SOURCE = OUT / "source"
shutil.copytree(REPO / "src", SOURCE / "src", ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
def hashes(root):
    return {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted((root / "src").rglob("*")) if p.is_file() and p.suffix != ".pyc" and "__pycache__" not in p.parts}
source_hashes = hashes(SOURCE)
assert source_hashes == hashes(REPO)
tree = ast.parse((SESSION / "work/rename/reproduce.py").read_text(encoding="utf-8"))
fixtures = {node.targets[0].id: ast.literal_eval(node.value) for node in tree.body
    if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name)
    and node.targets[0].id in {"BASE", "A", "B", "UNROLL_BAD"}}
base, a, b = (fixtures[name] for name in ("BASE", "A", "B"))
cases = {
    "A": (base, a, False, "block"), "B": (base, b, False, "block"),
    "B_from_A": (a, b, False, "block"),
    "cross_file_param": (base, base.replace("[(10,20), (20,40), (30,60)]", "[(10,999), (20,40), (30,60)]"), True, "block"),
    "pure_move": (base, base, True, "pass"),
    "unroll_preserved": (base, fixtures["UNROLL_BAD"].replace("== 25", "== 20").replace("== 45", "== 40").replace("== 65", "== 60"), False, "pass"),
}
env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", PYTHONUTF8="1", PYTHONPATH=str(SOURCE / "src"),
           GIT_CONFIG_NOSYSTEM="1", GIT_CONFIG_GLOBAL="NUL", GIT_TERMINAL_PROMPT="0")
(OUT / "tmp").mkdir()
env["TMP"] = env["TEMP"] = str(OUT / "tmp")
(OUT / "raw").mkdir()
journal, results = [], []
def run(name, command, cwd):
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    proc = subprocess.run(command, cwd=cwd, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60)
    for stream in ("stdout", "stderr"):
        (OUT / "raw" / (name + "." + stream)).write_bytes(getattr(proc, stream))
    journal.append({"name": name, "command": command, "cwd": str(cwd), "started": started,
        "finished": datetime.datetime.now(datetime.timezone.utc).isoformat(), "exit": proc.returncode,
        "stdout_sha256": hashlib.sha256(proc.stdout).hexdigest(), "stderr_sha256": hashlib.sha256(proc.stderr).hexdigest()})
    (OUT / "journal.json").write_text(json.dumps(journal, indent=2) + "\n", encoding="utf-8")
    return proc
def write(root, name, text):
    target = root / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(text.encode("utf-8"))
for name, (before, after, moved, expected) in cases.items():
    for freeze in (False, True):
        label = name + ("-freeze" if freeze else "-default")
        owned = OUT / "repos" / label
        owned.mkdir(parents=True)
        def git(suffix, *arguments):
            proc = run(label + "-" + suffix, ["git", *arguments], owned)
            assert proc.returncode == 0, proc.stderr.decode("utf-8", "replace")
            return proc.stdout.decode("ascii").strip()
        git("init", "init", "-q")
        git("config-name", "config", "user.name", "Owned Oracle Controls")
        git("config-email", "config", "user.email", "oracle-controls@example.invalid")
        git("config-eol", "config", "core.autocrlf", "false")
        write(owned, "tests/test_calc.py", before)
        write(owned, "calc.py", "def calc(x):\n    return x * 2\n")
        write(owned, "TASK.md", "---\ncheckwash:\n  oracle_freeze: " + str(freeze).lower() + "\n---\n")
        git("base-add", "add", ".")
        git("base-commit", "-c", "core.hooksPath=NUL", "commit", "-qm", "base fixture")
        base_sha = git("base-sha", "rev-parse", "HEAD")
        if moved:
            old_path = (owned / "tests/test_calc.py").resolve()
            assert old_path.is_relative_to(OUT.resolve())
            old_path.unlink()
            write(owned, "tests/test_moved.py", after)
        else:
            write(owned, "tests/test_calc.py", after)
        for entrance in ("worktree", "range"):
            command = [sys.executable, "-B", "-m", "checkwash", "check"]
            head_sha = None
            if entrance == "range":
                git("head-add", "add", ".")
                git("head-commit", "-c", "core.hooksPath=NUL", "commit", "-qm", "head fixture")
                head_sha = git("head-sha", "rev-parse", "HEAD")
                command.append(base_sha + ".." + head_sha)
            command += ["--repo", str(owned), "--task", str(owned / "TASK.md"), "--format", "json"]
            proc = run(label + "-" + entrance, command, owned)
            payload = json.loads(proc.stdout)
            results.append({"case": name, "freeze": freeze, "entrance": entrance, "base": base_sha,
                "head": head_sha, "exit": proc.returncode, "payload": payload, "expected": expected,
                "fixture_inputs": {p.relative_to(owned).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
                    for p in sorted(owned.rglob("*")) if p.is_file() and ".git" not in p.relative_to(owned).parts}})
            assert payload["verdict"] == expected and proc.returncode == (1 if expected == "block" else 0)
            assert payload["config_errors"] == payload["skipped_files"] == []
            (OUT / "observations.json").write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8")
            print(label, entrance, proc.returncode, payload["verdict"], flush=True)
receipt = {"marker": "HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL", "hostname": socket.gethostname(),
    "runtime": sys.version, "executable": sys.executable, "platform": platform.platform(),
    "source_binding": "COPIED_DEVELOPMENT_WORKING_TREE_HASHES_NOT_HEAD_QUALIFICATION",
    "source_files": source_hashes, "source_unchanged": source_hashes == hashes(SOURCE),
    "driver_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "cli_calls": len(results), "raw_commands": len(journal), "fixtures_executed": False,
    "observations_sha256": hashlib.sha256((OUT / "observations.json").read_bytes()).hexdigest(),
    "journal_sha256": hashlib.sha256((OUT / "journal.json").read_bytes()).hexdigest()}
(OUT / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
print("complete", len(results), receipt["source_unchanged"])
