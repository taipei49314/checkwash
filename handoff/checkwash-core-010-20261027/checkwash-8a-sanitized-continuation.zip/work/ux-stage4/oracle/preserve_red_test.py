"""Preserve the original 36-case red module, checked against its old receipt."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2] / "work/checkwash-ux"
current = (REPO / "tests/test_oracle_credit_context.py").read_text(encoding="utf-8")
body = current[current.index("TODAY = "):current.index('\n\n@pytest.mark.parametrize("freeze", [False, True])\ndef test_proved_text_only_refactor')]
first = body.index("def test_javascript_local_context_change_does_not_earn_relocation_credit")
last = body.index("def test_javascript_exact_live_relocation_is_preserved")
body = body[:first] + body[first:last].replace('f.rule == "EXPECTATION_DEFINITION_CHANGED"', 'f.rule == "TEST_DISABLED"') + body[last:]
header = '''"""Oracle relocation needs the same static obligations, never text/mass alone.

These source strings are parsed by CheckWash and are never executed.
"""
import datetime

import pytest

from checkwash.allowlist import AllowEntry
from checkwash.change import FileChange
from checkwash.config import Config
from checkwash.contract import Contract
from checkwash.engine import analyze
from checkwash.findings import Evidence, Finding
from checkwash.gating import apply_gates
from checkwash.ir.model import IR


'''
raw = (header + body.rstrip() + "\n").encode()
expected = json.loads((HERE / "red-r1/receipt.json").read_text())["before"]["tests/test_oracle_credit_context.py"]
assert hashlib.sha256(raw).hexdigest() == expected, (hashlib.sha256(raw).hexdigest(), expected)
out = HERE / "original-red-test"
out.mkdir(exist_ok=False)
(out / "test_oracle_credit_context.py").write_bytes(raw)
(out / "receipt.json").write_text(json.dumps({"preservation_kind": "RECONSTRUCTED_INITIAL_TEST_HASH_IDENTICAL_TO_RED_RECEIPT",
    "sha256": expected, "original_receipt": "red-r1/receipt.json", "executed_now": False}, indent=2) + "\n", encoding="utf-8")
print(expected)
