"""Oracle relocation needs the same static obligations, never text/mass alone.

These source strings are parsed by CheckWash and are never executed.
"""
import datetime

import pytest

from checkwash.allowlist import AllowEntry
from checkwash.change import FileChange
from checkwash.config import Config
from checkwash.contract import Contract
from checkwash.engine import analyze
from checkwash.findings import Evidence, Finding
from checkwash.gating import apply_gates
from checkwash.ir.model import IR


TODAY = datetime.date(2026, 10, 27)
BASE = '''import pytest
from calc import calc
@pytest.mark.parametrize("x,expected", [(10,20), (20,40), (30,60)])
def test_calc(x, expected):
    assert calc(x) == expected
'''
A = '''from calc import calc
def test_checkout():
    x = 10
    expected = 999999
    assert calc(x) == expected
'''
B = '''import pytest
from calc import calc
@pytest.mark.parametrize("x,expected", [(0,0), (0,0), (0,0)])
def test_checkout_v2(x, expected):
    res = calc(x)
    assert res == 0
'''


def check(before, after, *, freeze=False, fail_on="high", move=False, path="tests/test_calc.py", snapshot=None):
    changes = [FileChange(path, "modified", before.encode(), after.encode())]
    if move:
        changes = [FileChange(path, "deleted", before.encode(), None),
                   FileChange(path.replace("test_calc", "test_moved"), "added", None, after.encode())]
    sources = {"calc.py": b"def calc(x):\n    return x * 2\n", **(snapshot or {})}
    return analyze(changes, Config(fail_on=fail_on), Contract(oracle_freeze=freeze), [], TODAY,
                   root_reader=sources.get, root_searcher=lambda _: [])


@pytest.mark.parametrize("after", [A, B])
@pytest.mark.parametrize("freeze", [False, True])
@pytest.mark.parametrize("fail_on,verdict", [("warn", "block"), ("high", "block"), ("critical", "pass")])
def test_default_and_frozen_renamed_oracle_laundering_has_no_text_or_mass_credit(after, freeze, fail_on, verdict):
    _ir, findings, actual = check(BASE, after, freeze=freeze, fail_on=fail_on)
    disabled = [f for f in findings if f.rule == "TEST_DISABLED"]
    assert disabled and all(f.severity == "high" for f in disabled)
    assert all(not set(f.deescalators) & {"ASSERTION_MOVED", "RESTRUCTURED", "SPLIT_OR_RENAMED"} for f in disabled)
    assert all(("ORACLE_FREEZE" in f.escalators) == freeze for f in disabled)
    assert actual == verdict


@pytest.mark.parametrize("freeze", [False, True])
@pytest.mark.parametrize("replacement", ["[(10,999), (20,40), (30,60)]", "[(0,0), (0,0), (0,0)]"])
def test_cross_file_decorator_change_cannot_borrow_identical_function_body(freeze, replacement):
    _ir, findings, verdict = check(BASE, BASE.replace("[(10,20), (20,40), (30,60)]", replacement),
                                   freeze=freeze, move=True)
    assert verdict == "block"
    assert any(f.rule == "TEST_DISABLED" and f.severity == "high" for f in findings)


@pytest.mark.parametrize("freeze", [False, True])
@pytest.mark.parametrize("move", [False, True])
def test_pure_rename_or_move_preserves_the_original_literal_table(freeze, move):
    _ir, findings, verdict = check(BASE, BASE if move else BASE.replace("test_calc", "test_checkout"),
                                   freeze=freeze, move=move)
    assert verdict == "pass"
    assert not any(f.severity in {"high", "critical"} for f in findings)


@pytest.mark.parametrize("freeze", [False, True])
def test_preserved_literal_unroll_still_passes(freeze):
    after = '''from calc import calc
def test_checkout():
    assert calc(10) == 20
    assert calc(20) == 40
    assert calc(30) == 60
'''
    _ir, findings, verdict = check(BASE, after, freeze=freeze)
    assert verdict == "pass" and not findings


@pytest.mark.parametrize("freeze", [False, True])
def test_module_binding_change_during_move_is_not_equivalence(freeze):
    before = "from calc import calc\nEXPECTED = 20\ndef test_calc():\n    assert calc(10) == EXPECTED\n"
    after = before.replace("EXPECTED = 20", "EXPECTED = 999")
    _ir, findings, verdict = check(before, after, freeze=freeze, move=True)
    assert verdict == "block"
    assert any(f.rule == "TEST_DISABLED" and f.severity == "high" for f in findings)


@pytest.mark.parametrize("freeze", [False, True])
def test_unknown_custom_decorator_is_not_an_oracle_proof(freeze):
    source = "from calc import calc\nfrom helpers import customize\n@customize\ndef test_calc():\n    assert calc(10) == 20\n"
    _ir, findings, verdict = check(source, source, freeze=freeze, move=True)
    assert verdict == "block"
    assert any(f.rule == "TEST_DISABLED" and f.severity == "high" for f in findings)


@pytest.mark.parametrize("freeze", [False, True])
def test_direct_assert_removed_text_credit_without_context_remains_high(freeze):
    ir = IR("base", "head")
    ir.globals.moved_assertion_texts = ["assert calc(x) == expected"]
    finding = Finding("ASSERT_REMOVED", "warn", "removed", "tests/test_calc.py", "test_calc",
                      before=Evidence("assert calc(x) == expected", (0, 26)), fingerprint="synthetic")
    verdict = apply_gates(ir, [finding], Contract(oracle_freeze=freeze), Config(), [], TODAY)
    assert verdict == "block" and finding.severity == "high"
    assert "ASSERTION_MOVED" not in finding.deescalators
    assert ("ORACLE_FREEZE" in finding.escalators) == freeze


@pytest.mark.parametrize("extension", ["js", "ts"])
@pytest.mark.parametrize("freeze", [False, True])
def test_javascript_local_context_change_does_not_earn_relocation_credit(extension, freeze):
    before = 'test("total", () => { const expected = 75; expect(total()).toBe(expected); });\n'
    after = 'test("renamed", () => { const expected = 0; expect(total()).toBe(expected); });\n'
    _ir, findings, verdict = check(before, after, freeze=freeze, path=f"tests/value.test.{extension}")
    assert verdict == "block"
    assert any(f.rule == "TEST_DISABLED" and f.severity == "high" for f in findings)


@pytest.mark.parametrize("extension", ["js", "ts"])
@pytest.mark.parametrize("freeze", [False, True])
def test_javascript_exact_live_relocation_is_preserved(extension, freeze):
    source = 'test("total", () => { expect(total()).toBe(75); });\n'
    before = f"tests/a.test.{extension}"
    changes = [FileChange(before, "deleted", source.encode(), None),
               FileChange(f"tests/b.test.{extension}", "added", None, source.encode())]
    _ir, findings, verdict = analyze(changes, Config(), Contract(oracle_freeze=freeze), [], TODAY,
                                     root_reader=lambda _: None, root_searcher=lambda _: [])
    assert verdict == "pass"
    assert all(f.severity == "info" for f in findings)
