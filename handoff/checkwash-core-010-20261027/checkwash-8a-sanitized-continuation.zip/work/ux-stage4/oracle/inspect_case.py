import dataclasses
import datetime
import json
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "work/checkwash-ux/src"))
from checkwash.cases import parse_case, case_to_changes, case_snapshot
from checkwash.config import Config
from checkwash.contract import Contract
from checkwash.engine import analyze

repo = Path(__file__).resolve().parents[3] / "work/checkwash-ux"
case = parse_case((repo / "tests/cases" / (sys.argv[1] + ".gwcase")).read_text(encoding="utf-8"))
snapshot = case_snapshot(case)
head = {p: v.encode() for p, v in case.head.items()}
ir, findings, verdict = analyze(case_to_changes(case), Config(), Contract(), [], datetime.date(2026, 1, 1),
    root_reader=snapshot.get, root_searcher=lambda _: [], head_reader=head.get, head_searcher=lambda _: list(head))
print(json.dumps({"verdict": verdict, "findings": [dataclasses.asdict(f) for f in findings],
    "units": [{"path": f.path, "units": [{"name": u.qualname,
        "before": dataclasses.asdict(u.before) if u.before else None,
        "after": dataclasses.asdict(u.after) if u.after else None} for u in f.units]} for f in ir.files]}, indent=2))
