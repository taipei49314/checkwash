"""Read-only aggregation of saved receipts plus the final owned file map."""
import hashlib
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2] / "work/checkwash-ux"
REVIEW = HERE.parent / "oracle-independent-review"
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def load(path):
    return json.loads(path.read_text(encoding="utf-8"))
def junit(path):
    suite = ET.parse(path).find("testsuite")
    counts = {name: int(suite.attrib[name]) for name in ("tests", "errors", "failures", "skipped")}
    counts["passed"] = counts["tests"] - counts["errors"] - counts["failures"] - counts["skipped"]
    counts["failed_cases"] = [case.attrib["name"] for case in suite.findall("testcase") if case.find("failure") is not None]
    return counts
owned = ["src/checkwash/oracle_credit.py", "src/checkwash/engine.py", "src/checkwash/gating.py",
    "src/checkwash/ir/model.py", "src/checkwash/frontends/javascript/expected_provenance.py",
    "tests/test_oracle_credit_context.py", "tests/test_issue219_python_snapshot_tests.py",
    "tests/test_issue266_survivor_conftest_chain.py"]
owned_map = {name: sha(REPO / name) for name in owned}
targeted = load(HERE / "final-reviewed-r3/receipt.json")
corpus = load(HERE / "final-corpus-r2/receipt.json")
assert all(owned_map[name] == targeted["after"][name] == corpus["after"][name] for name in owned)
assert targeted["inputs_unchanged"] and corpus["inputs_unchanged"]
assert targeted["exit"] == 0 and corpus["exit"] == 1
counts, costs = junit(HERE / "final-reviewed-r3/junit.xml"), junit(HERE / "final-corpus-r2/junit.xml")
register = load(HERE / "cost-r4/immutable-cost-register.json")
assert {name.removeprefix("test_case[").removesuffix("]") for name in costs["failed_cases"]} == {row["case"] for row in register["rows"]}
independent = load(REVIEW / "six-blocker-final-readback.json")
assert independent["all_expected"] and independent["source_unchanged"]
assert all(owned_map["src/" + name] == value for name, value in independent["source_hashes_after"].items())
for command in independent["commands"]:
    assert command["exit"] == 0
    for stream in ("stdout", "stderr"):
        assert sha(REVIEW / command[stream]) == command[stream + "_sha256"]
native = load(HERE / "native-r1/receipt.json")
assert native["cli_calls"] == 24 and native["source_unchanged"]
assert sha(HERE / "native-r1/observations.json") == native["observations_sha256"]
native_rows = load(HERE / "native-r1/observations.json")
assert all(row["payload"]["verdict"] == row["expected"] for row in native_rows)
assert not subprocess.check_output(["git", "diff", "--name-only", "--", "tests/cases"], cwd=REPO).strip()
result = {"state": "IMPLEMENTED_BOUNDED_REVIEW_PASSED_COMPATIBILITY_GATES_REMAIN_OPEN",
    "marker": targeted["marker"], "hostname": targeted["hostname"], "runtime": targeted["runtime"],
    "source_binding": "SHARED_DEVELOPMENT_WORKING_TREE_BYTES_NOT_HEAD_QUALIFICATION",
    "observed_head_not_source_identity": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=REPO).decode().strip(),
    "owned_files": owned_map, "targeted": {"receipt": "final-reviewed-r3/receipt.json", "pytest_exit": 0, **counts},
    "corpus": {"receipt": "final-corpus-r2/receipt.json", "pytest_exit": 1, **costs},
    "cost_register": {"path": "cost-r4/immutable-cost-register.json", "sha256": sha(HERE / "cost-r4/immutable-cost-register.json"),
        "cases": len(register["rows"]), "old_new_api_arms": 16, "golden_labels_changed": False},
    "independent_review": {"readback": "../oracle-independent-review/six-blocker-final-readback.json",
        "sha256": sha(REVIEW / "six-blocker-final-readback.json"), "all_expected": True,
        "known_counterexample_shapes": 6, "observations": 18, "final_full_qualification": False},
    "native_controls": {"receipt": "native-r1/receipt.json", "calls": 24,
        "blocks": sum(row["exit"] == 1 for row in native_rows), "passes": sum(row["exit"] == 0 for row in native_rows),
        "source_binding": native["source_binding"], "matches_final_owned_files": all(native["source_files"].get(name) == value for name, value in owned_map.items() if name.startswith("src/")),
        "limitation": "earlier captured development source; later six review corrections are bound to targeted/API receipts, not these native observations"},
    "platforms": {"python311_windows": "OBSERVED_DEVELOPMENT_EVIDENCE",
        "python312": "EXISTING_BUNDLED_3.12.14_AVAILABLE_FINAL_SOURCE_COMPARISON_PENDING_ROOT",
        "python313": "NOT_RUN", "other_os": "NOT_RUN"},
    "fixtures_executed": False, "commit_or_push_by_child": False,
    "release_acceptance": "NOT_ESTABLISHED_EIGHT_IMMUTABLE_GOLDEN_GATES_FAIL"}
(HERE / "development-summary.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"targeted": counts, "corpus": costs, "owned_files": owned_map,
                  "summary_sha256": sha(HERE / "development-summary.json")}, indent=2))
