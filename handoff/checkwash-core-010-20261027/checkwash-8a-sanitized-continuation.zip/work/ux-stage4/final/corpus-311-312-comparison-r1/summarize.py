"""Read-only final raw receipt, denominator and focused JUnit cross-check."""
import ast
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent
FINAL = HERE.parent
REPO = HERE.parents[3] / 'work' / 'checkwash-ux'
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
captures = {}
for label in ('corpus-311-r1', 'corpus-312-r1', 'd179-ir3-312-r1'):
    path = FINAL / label
    receipt = json.loads((path / 'receipt.json').read_bytes())
    captures[label] = {'receipt': receipt, 'files': {p.name: sha(p) for p in sorted(path.iterdir()) if p.is_file()}}
    assert receipt['source_sha'] == receipt['ending_sha'] == '8a8941dc2d7c581715a0f6f196c00da6c55f084b'
    assert receipt['exit_code'] == 0 and receipt['source_files_unchanged'] and not receipt['changed_inputs']
    assert not (path / 'source.diff').read_bytes() and not (path / 'git-status.txt').read_bytes()
inputs = json.loads((FINAL / 'corpus-311-r1' / 'input-hashes.json').read_bytes())
fixtures = sorted(Path(name).name for name in inputs if name.startswith('tests/cases/') and name.endswith('.gwcase'))
raw = (FINAL / 'corpus-311-r1' / 'stdout.txt').read_bytes()
headers = [line[2:].decode() for line in raw.splitlines() if line.startswith(b'# ')]
assert headers == fixtures and len(headers) == len(set(headers)) == 1117
assert raw == (FINAL / 'corpus-312-r1' / 'stdout.txt').read_bytes()
assert len(inputs) == 3084
runner = ast.parse((REPO / 'tests' / 'test_cases_runner.py').read_bytes())
extra_tests = [node.name for node in runner.body if isinstance(node, ast.FunctionDef)
               and node.name.startswith('test_') and node.name != 'test_case']
assert extra_tests == ['test_cases_exist', 'test_expectation_definition_package_unrelated_has_no_credit']
suite = ET.parse(FINAL / 'd179-ir3-312-r1' / 'junit.xml').getroot().find('testsuite')
assert suite is not None
counts = {name: int(suite.attrib[name]) for name in ('tests', 'failures', 'errors', 'skipped')}
assert counts == {'tests': 104, 'failures': 0, 'errors': 0, 'skipped': 0}
payload = {'marker': 'HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL', 'result': 'PASS_EXACT_BYTES_AND_REQUESTED_FOCUSED_ONLY',
    'source_sha': '8a8941dc2d7c581715a0f6f196c00da6c55f084b', 'source_members': len(inputs),
    'raw_stdout_bytes': len(raw), 'raw_stdout_sha256': sha(FINAL / 'corpus-311-r1' / 'stdout.txt'),
    'raw_bytes_equal_without_transform': True, 'raw_header_count': len(headers), 'headers_equal_source_fixture_members': True,
    'golden_runner_other_tests_static_readback': extra_tests, 'golden_runner_total_distinct_from_emitter_denominator': len(headers) + len(extra_tests),
    'focused_junit_counts': counts, 'captures': captures,
    'not_run': ['Python3.13', 'other operating systems'], 'golden_eight_failures': 'UNCHANGED_NONPASS_OPEN'}
(HERE / 'verification.json').write_bytes((json.dumps(payload, indent=2) + '\n').encode())
files = {p.name: sha(p) for p in sorted(HERE.iterdir()) if p.is_file() and p.name != 'manifest.json'}
(HERE / 'manifest.json').write_bytes((json.dumps({'marker': payload['marker'], 'files': files,
    'raw_capture_files': {label: row['files'] for label, row in captures.items()}}, indent=2) + '\n').encode())
print(json.dumps({'corpus_cases': len(headers), 'golden_runner_total': len(headers) + len(extra_tests),
    'focused': counts, 'report_sha256': sha(HERE / 'report.md'),
    'verification_sha256': sha(HERE / 'verification.json'), 'manifest_sha256': sha(HERE / 'manifest.json')}, indent=2))
