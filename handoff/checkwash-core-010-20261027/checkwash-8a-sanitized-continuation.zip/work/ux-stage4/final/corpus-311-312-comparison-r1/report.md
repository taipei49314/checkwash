# Fixed 8a corpus bytes and Python3.12 focused verification

The complete raw findings+IR corpus output is byte-identical on the same
Windows PJU host under Python3.11.9 and Python3.12.14. Both emitter processes
exited0. Each original stdout is8,873,976bytes, SHA256:

`1305fa51b86ce3a987107603e182920bdcdd02f25b2e5f59ebd4634a64165d54`

No fields were removed or reordered, and no line endings or AST data were
normalized for this comparison. It directly compares the two original
stdout.txt byte strings. Both streams have1,117unique `# filename.gwcase`
headers in the same order. The source input manifest contains exactly those
1,117 fixture paths. The1,119 number used for the golden pytest runner is a
different denominator:1,117 parametrized case tests plus the runner's two
other tests. This emitter result is not golden-label acceptance.

Python3.12.14/pytest9.1.1 also ran the requested two files:
test_oracle_credit_context.py and test_policy_shadow_ir3_consumers.py.
JUnit records104tests,0failures,0errors,0skips, exit0. The pytest child omits
`-I`, so the capture's PYTHONPATH explicitly selects the fixed repository src.
Both emitters use their absolute interpreter with `-I -B -X utf8` and the
absolute tools/emit_corpus.py path, which inserts its own adjacent src.

All three captures bind exact source and ending SHA
8a8941dc2d7c581715a0f6f196c00da6c55f084b, the same3,084-member input manifest
SHA2563649879bd02d32a9e3d1f868790d7af33d86382300720b072bed0320ad14fe22,
empty source diffs, clean Git status and unchanged input bytes. They use the
root-owned capture_final.py and trusted clean-environment helper. Complete
commands, full runtime strings, exits, input hashes and original stdout/stderr
remain in their independent capture directories:

- ../corpus-311-r1/
- ../corpus-312-r1/
- ../d179-ir3-312-r1/

The Python platform library describes the same Windows build26200 as
Windows10 in the3.11 receipt and Windows11 in the3.12 receipt. Both are actual
raw descriptors from LAPTOP-01AGNPJU; this comparison does not claim two
operating systems or a cross-OS result. All receipts are marked
HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL.

comparison.json and verification.json preserve the raw hash/length/header
checks and focused JUnit readback. Product source/tests/docs, fixture programs,
golden proposal, earlier review records and global host configuration were
not changed. Analyzed corpus source strings were not executed. Python3.13 and
all other operating systems remain NOT_RUN. #567's eight original native
failures remain open; deterministic bytes and the separate104focused passes
do not clear those failures or authorize publication.
