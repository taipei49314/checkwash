"""Relate native failed node IDs to the unchanged cost register; no acceptance."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

here = Path(__file__).resolve().parent
repo = here.parent / "checkwash-ux"
pin = (here / "final-source-sha.txt").read_text(encoding="utf-8").strip()
full = here / "final/full-suite-311-r1"
receipt = json.loads((full / "receipt.json").read_bytes())
audit = json.loads((full / "independent-readback.json").read_bytes())
assert receipt["source_sha"] == receipt["ending_sha"] == pin and receipt["source_files_unchanged"]
assert audit["source_sha"] == pin and audit["audit_exit_code"] == 0
register_path = here / "oracle/cost-r4/immutable-cost-register.json"
register = json.loads(register_path.read_bytes())
baseline = register["baseline_source_sha"]
env = {k: v for k, v in os.environ.items() if not k.upper().startswith("GIT_")}
env.update(GIT_CONFIG_NOSYSTEM="1", GIT_CONFIG_GLOBAL=os.devnull, GIT_TERMINAL_PROMPT="0")

def git(*args):
    return subprocess.run(["git", "--no-optional-locks", "-c", "core.fsmonitor=false", *args],
                          cwd=repo, env=env, capture_output=True, check=True).stdout

assert git("rev-parse", "HEAD").decode().strip() == pin
assert not git("status", "--porcelain", "--untracked-files=all")
actual = set(audit["failure_nodeids"])
rows = []
for cost in register["rows"]:
    name = cost["case"]
    path = "tests/cases/" + name + ".gwcase"
    raw = (repo / path).read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    current = git("show", pin + ":" + path)
    old = git("show", baseline + ":" + path)
    assert raw == current == old and digest == cost["fixture_sha256"], path
    node = "tests/test_cases_runner.py::test_case[" + name + "]"
    rows.append({"case": name, "fixture": path, "fixture_sha256": digest,
                 "current_physical_and_head_bytes_equal_baseline": True,
                 "native_nodeid": node, "observed_failed": node in actual,
                 "registered_old_verdict": cost["old_verdict"], "registered_new_verdict": cost["new_verdict"]})
expected = {row["native_nodeid"] for row in rows}
result = {"kind": "FAILED_SUITE_COST_CLASSIFICATION_NOT_ACCEPTANCE", "source_sha": pin,
          "baseline_source_sha": baseline, "native_suite_exit_code": receipt["exit_code"],
          "suite_passed": receipt["exit_code"] == 0, "failure_nodeids": sorted(actual),
          "known_failure_set_matches_register": actual == expected,
          "unexpected_failure_nodeids": sorted(actual - expected),
          "registered_cases_not_failed_in_native_suite": sorted(expected - actual),
          "cases": rows, "register_sha256": hashlib.sha256(register_path.read_bytes()).hexdigest(),
          "native_audit_sha256": hashlib.sha256((full / "independent-readback.json").read_bytes()).hexdigest(),
          "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          "existing_fixture_labels_modified": False, "golden_patch_applied": False,
          "maintainer_disposition": "OPEN https://github.com/taipei49314/checkwash/issues/567",
          "product_calls": 0, "pytest_calls": 0,
          "interpretation": "Matching tracked costs explains observed failures; it does not clear a failed suite, approve labels or waive release gates."}
target = full / "known-golden-cost-comparison.json"
assert not target.exists(), "preserve the previous analysis; use a new script/result label"
target.write_text(json.dumps(result, sort_keys=True, indent=2), encoding="utf-8")
print(json.dumps({key: value for key, value in result.items() if key != "cases"}, indent=2))
