⚠ checkwash: 10 finding(s), none at or above high

TEST_DISABLED   WARN   tests/test_issue266_survivor_conftest_chain.py :: test_a_survivor_the_chain_does_not_skip_is_credited
  test_a_survivor_the_chain_does_not_skip_is_credited: test unit disappeared
  held at warn by: RESTRUCTURED
  before  assert outcome(head) == CREDITED

TEST_DISABLED   WARN   tests/test_issue266_survivor_conftest_chain.py :: test_without_a_strict_snapshot_the_chain_is_unknown_and_reads_as_before
  test_without_a_strict_snapshot_the_chain_is_unknown_and_reads_as_before: test unit disappeared
  held at warn by: RESTRUCTURED
  before  assert outcome(head, root=False) == CREDITED

EXPECTED_VALUE_CHANGED   WARN   tests/test_fingerprint_scope.py :: test_only_crlf_is_canonicalized_and_ir_contains_digests_not_new_source_copies
  test_only_crlf_is_canonicalized_and_ir_contains_digests_not_new_source_copies: expected value rewritten 2 -> 3 with no change in assertion strength
  held at warn by: REPAIR_EVIDENCE
  before  assert IR_VERSION == FINDINGS_VERSION == ir.version == 2
  after   assert IR_VERSION == ir.version == 3

EXPECTED_VALUE_CHANGED   WARN   tests/test_issue266_survivor_conftest_chain.py :: test_a_conftest_the_diff_changes_is_read_on_its_head_side
  test_a_conftest_the_diff_changes_is_read_on_its_head_side: expected call rewritten to a different call ['CREDITED'] -> ['UNCREDITED'] with no change in assertion strength
  held at warn by: REPAIR_EVIDENCE
  before  assert outcome({**head, "tests/conftest.py": plain}, {"tests/conftest.py": (SKIPPING, plain)}) == CREDITED
  after   assert outcome({**head, "tests/conftest.py": plain}, {"tests/conftest.py": (SKIPPING, plain)}) == UNCREDITED

EXPECTED_VALUE_CHANGED   WARN   tests/test_issue346_config_reads.py :: test_working_tree_batch_refusal_names_the_symlinked_path
  test_working_tree_batch_refusal_names_the_symlinked_path: expected value rewritten 'strict snapshot batch cannot inspect nonregular source requirements/pyproject.toml (a symlink)' -> "strict snapshot batch cannot inspect nonregular source 'requirements/pyproject.toml' (a symlink); side='worktree', entry='worktree/read_many'. Use a repository-owned regular source at this path; a committed range reads committed bytes only." with no change in assertion strength
  held at warn by: REPAIR_EVIDENCE
  before  assert str(caught.value) == (
  after   assert str(caught.value) == (

EXPECTED_VALUE_CHANGED   WARN   tests/test_issue346_config_reads.py :: test_working_tree_refusal_names_a_directory
  test_working_tree_refusal_names_a_directory: expected value rewritten 'strict snapshot cannot inspect nonregular source configs/pytest.ini (a directory)' -> "strict snapshot cannot inspect nonregular source 'configs/pytest.ini' (a directory); side='worktree', entry='worktree/read'. Use a repository-owned regular source at this path; a committed range reads committed bytes only." with no change in assertion strength
  held at warn by: REPAIR_EVIDENCE
  before  assert str(caught.value) == (
  after   assert str(caught.value) == (

CI_WORKFLOW_TOUCHED   WARN   pyproject.toml
  CI configuration changed

BROAD_EXCEPT_ADDED   WARN   src/checkwash/sweep.py
  broad exception handler added (exceptExceptionasexc:#noqa:BLE001-asweepmustsurviveonebadcommit)
  after   exceptExceptionasexc:#noqa:BLE001-asweepmustsurviveonebadcommit

SUPPRESSION_ADDED   WARN   src/checkwash/sweep.py
  lint/type suppression added (except Exception as exc:  # noqa: BLE001 - a sweep must survive one bad commit)
  after   except Exception as exc:  # noqa: BLE001 - a sweep must survive one bad commit

SUPPRESSION_ADDED   WARN   tools/emit_corpus.py
  lint/type suppression added (from checkwash.cases import case_policy_base, case_snapshot, case_to_changes, parse_case  # noqa: E402)
  after   from checkwash.cases import case_policy_base, case_snapshot, case_to_changes, parse_case  # noqa: E402

summary: critical=0 high=0 warn=10 info=0 verdict=pass allow_cap=180d
