"""Make a separate pinned-source capture driver; preserve development drivers."""
from pathlib import Path

HERE = Path(__file__).resolve().parent
target = HERE / "capture_final.py"
assert not target.exists()
text = (HERE / "capture.py").read_text(encoding="utf-8")
text = text.replace('"""Record stage-4 local test commands; preserve original bytes and input identities."""',
                    '"""Record pinned final-source commands; no release checks are published."""')
text = text.replace('parent / "root" / a.label', 'parent / "final" / a.label')
text = text.replace('"cw566-s4-"', '"cwf4-"')
marker = 'head = git("rev-parse", "HEAD").decode().strip()\n'
assert marker in text
text = text.replace(marker, marker + '''expected_head = (Path(__file__).resolve().parent / "final-source-sha.txt").read_text(encoding="utf-8").strip()
assert head == expected_head, "final source moved"
assert not git("status", "--porcelain", "--untracked-files=all"), "final checkout is dirty"
safe_basetemp = temporary / "p"
assert safe_basetemp.resolve().is_relative_to(temporary.resolve()) and not safe_basetemp.exists()
a.command = [str(safe_basetemp) if argument == "__PJU_BASETEMP__" else argument for argument in a.command]
''', 1)
text = text.replace('source_sha=head, ending_sha=', 'expected_source_sha=expected_head, validation_kind="FIXED_SOURCE_NOT_RELEASE_BRIDGE",\n              source_sha=head, ending_sha=')
target.write_text(text, encoding="utf-8", newline="\n")
print(target)
