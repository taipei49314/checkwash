---
checkwash:
  oracle_freeze: true
---
