---
checkwash:
  oracle_freeze: false
---
