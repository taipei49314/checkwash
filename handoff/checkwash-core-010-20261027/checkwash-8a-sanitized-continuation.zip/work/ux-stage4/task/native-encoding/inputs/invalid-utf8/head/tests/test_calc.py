from calc import calc

def test_calc():
    assert calc(2) > 0
