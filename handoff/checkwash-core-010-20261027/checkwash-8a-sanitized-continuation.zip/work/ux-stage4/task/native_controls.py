"""Twenty original shapes plus four bounded native D-178 controls; no subject execution."""
import ctypes
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import socket
import subprocess
import sys
import tempfile

HERE = Path(__file__).parent.resolve()
SESSION = HERE.parents[2]
OUT = HERE / "native"
OUT.mkdir(exist_ok=False)
RAW = OUT / "raw"
RAW.mkdir()
SOURCE = HERE / "after-corrected-r2/snapshot/src"
PYTHON = SESSION / "work/test-runtime/Scripts/python.exe"
GIT = Path(r"C:\Program Files\Git\cmd\git.exe")
BASH = Path(r"C:\Program Files\Git\bin\bash.exe")
FIXTURE_DRIVER = SESSION / "work/ux-stage3/task-authority/controls.py"
TRUSTED = SESSION / "work/trusted/replay_pju_action.py"
def sh(raw):
    return hashlib.sha256(raw).hexdigest()
def save(path, value):
    path.write_bytes((json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))
def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value
temp_root = Path(tempfile.mkdtemp(prefix="cw-t178n-"))
env = module("trusted_env", TRUSTED).clean_environment(PYTHON, GIT, BASH, temp_root / "process")
env.update(PYTHONDONTWRITEBYTECODE="1", GREENWASH_TODAY="2026-10-27", GIT_OPTIONAL_LOCKS="0")
fixture = module("prior_trusted_fixture_constructor", FIXTURE_DRIVER)
fixture.HERE, fixture.ENV = temp_root, env
commands, results, not_run = [], [], []
def execute(label, argv, cwd, data=None):
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    process = subprocess.run(argv, cwd=cwd, env=env, input=data, stdin=None if data is not None else subprocess.DEVNULL,
                             capture_output=True, timeout=60)
    stdout, stderr = RAW / (label + ".stdout"), RAW / (label + ".stderr")
    stdout.write_bytes(process.stdout)
    stderr.write_bytes(process.stderr)
    row = {"label": label, "command": [str(arg) for arg in argv], "cwd": str(cwd), "started_utc": started,
           "ended_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "exit": process.returncode,
           "stdout": str(stdout.relative_to(OUT)), "stderr": str(stderr.relative_to(OUT)),
           "stdout_sha256": sh(process.stdout), "stderr_sha256": sh(process.stderr)}
    commands.append(row)
    save(OUT / "commands.json", commands)
    return process, row
def git(repo, *args, data=None):
    process, row = execute("git-" + str(len(commands)).zfill(3),
        [str(GIT), "-c", "core.hooksPath=NUL", "-c", "core.fsmonitor=false", "--literal-pathspecs", "-C", str(repo), *args], temp_root, data)
    assert process.returncode == 0, row
    return process.stdout.decode("ascii").strip()
fixture.git = git
repo, base, head = fixture.make_repo("repo")
case_repo, case_base, case_head = fixture.make_repo("case", uppercase=True)
outside = temp_root / "outside"
outside.mkdir()
fixture.write(outside, "TASK.md", fixture.LOOSE)
fixture.write(outside, "LOCAL.TASK.md", fixture.LOOSE)
def junction(label, link, target):
    process, row = execute(label, [env["COMSPEC"], "/d", "/c", "mklink", "/J", str(link), str(target)], temp_root)
    return {"exit": process.returncode, "path": str(link), "target": str(target),
            "reparse_tag": getattr(link.lstat(), "st_reparse_tag", None) if link.exists() else None, "receipt": row}
ci = junction("junction-ci", repo / "ci", repo / "pkg")
alias = temp_root / "root-alias"
root_alias = junction("junction-root", alias, repo)
try:
    os.symlink(str(repo / "NOTES.md"), str(temp_root / "file-link-capability"))
    file_link = {"status": "AVAILABLE"}
except OSError as exc:
    file_link = {"status": "NOT_RUN", "exception_type": type(exc).__name__, "reason": str(exc)}
    not_run.append({"case": "actual-file-symlink", **file_link})
drive_mask = ctypes.windll.kernel32.GetLogicalDrives() if os.name == "nt" else 0
drives = [chr(65 + i) + ":" for i in range(26) if drive_mask & (1 << i)]
not_run += [{"case": "cross-volume", "status": "NOT_RUN", "reason": "No second qualified volume configured; no mount/subst/host change attempted", "observed_drive_letters": drives},
            {"case": "UNC", "status": "NOT_RUN", "reason": "No eligible owned UNC share supplied; no service/share or host change attempted"}]
same = (repo, base, head)
cases = [
 ("01-root-root-relative", repo, str(repo), "TASK.md", "json", same, 1, True),
 ("02-outside-root-relative", outside, str(repo), "TASK.md", "json", same, 1, True),
 ("03-sub-root-relative", repo / "pkg", str(repo), "TASK.md", "json", same, 1, True),
 ("04-root-sub-relative", repo, str(repo / "pkg"), "TASK.md", "json", same, 0, False),
 ("05-outside-sub-relative", outside, str(repo / "pkg"), "TASK.md", "json", same, 0, False),
 ("06-sub-sub-relative", repo / "pkg", str(repo / "pkg"), "TASK.md", "json", same, 0, False),
 ("07-outside-root-absolute", outside, str(repo), str(repo / "TASK.md"), "json", same, 1, True),
 ("08-outside-sub-absolute", outside, str(repo / "pkg"), str(repo / "pkg/TASK.md"), "json", same, 0, False),
 ("09-sub-relative-repo-parent", repo / "pkg", "..", "TASK.md", "json", same, 1, True),
 ("10-root-relative-repo-sub", repo, "pkg", "TASK.md", "json", same, 0, False),
 ("11-sub-default-repo", repo / "pkg", None, "TASK.md", "json", same, 0, False),
 ("12-hook-outside-root-relative", outside, str(repo), "TASK.md", "hook-json", same, 0, None),
 ("13-root-case-alias", repo, str(repo), "task.md", "json", same, 2, False),
 ("14-root-base-directory-symlink", repo, str(repo), "ci/TASK.md", "json", same, 2, False),
 ("15-root-base-file-prefix", repo, str(repo), "block/TASK.md", "json", same, 2, False),
 ("16-sub-base-case-miss", case_repo / "PKG", str(case_repo / "PKG"), "TASK.md", "json", (case_repo, case_base, case_head), 2, False),
 ("17-root-genuine-fallback", repo, str(repo), "LOCAL.TASK.md", "json", same, 1, True),
 ("18-sub-genuine-miss-refused", repo / "pkg", str(repo / "pkg"), "LOCAL.TASK.md", "json", same, 2, False),
 ("19-drive-relative-task", repo / "pkg", str(repo), repo.drive + "TASK.md", "json", same, 1, True),
 ("20-root-alias-different-spelling", outside, str(alias), str(repo / "TASK.md"), "json", same, 2, False),
 ("21-drive-relative-repo", repo, repo.drive + "pkg", "TASK.md", "json", same, 0, False),
 ("22-root-relative-task", outside, str(repo), str(repo / "TASK.md")[len(repo.drive):], "json", same, 1, True),
 ("23-outside-root-genuine-fallback", outside, str(repo), "LOCAL.TASK.md", "json", same, 1, True),
 ("24-sub-parent-task", outside, str(repo / "pkg"), "../TASK.md", "json", same, 1, True),
]
source_before = {str(path.relative_to(SOURCE)): sh(path.read_bytes()) for path in sorted(SOURCE.rglob("*")) if path.is_file()}
bootstrap = "import sys;sys.path.insert(0," + repr(str(SOURCE)) + ");from checkwash.cli import main;raise SystemExit(main())"
for name, cwd, given, task, fmt, case, expected_exit, expected_freeze in cases:
    if name.startswith("20-") and root_alias["exit"]:
        not_run.append({"case": name, "status": "NOT_RUN", "reason": "Owned root-junction capability unavailable"})
        continue
    current_repo, left, right = case
    inputs = {path: sh((current_repo / path).read_bytes()) for path in ("TASK.md", "calc.py", "tests/test_calc.py")}
    command = [str(PYTHON), "-I", "-B", "-X", "utf8", "-c", bootstrap, "check", left + ".." + right,
               "--task", task, "--format", fmt]
    if given is not None:
        command += ["--repo", given]
    process, receipt = execute(name, command, cwd)
    payload = json.loads(process.stdout) if process.stdout else None
    frozen = any("ORACLE_FREEZE" in finding.get("escalators", []) for finding in (payload or {}).get("findings", []))
    passed = process.returncode == expected_exit and (expected_freeze is None or frozen == expected_freeze)
    if fmt == "hook-json":
        passed = passed and payload.get("decision") == "block"
    row = {"case": name, "exit": process.returncode, "payload": payload, "oracle_freeze": frozen,
           "expected_exit": expected_exit, "expected_freeze": expected_freeze, "passed": passed,
           "inputs_sha256": inputs, "fixture_base": left, "fixture_head": right, "receipt": receipt}
    assert inputs == {path: sh((current_repo / path).read_bytes()) for path in inputs}
    results.append(row)
    save(OUT / "results-progress.json", results)
    print(name, process.returncode, "PASS" if passed else "UNEXPECTED", flush=True)
source_after = {str(path.relative_to(SOURCE)): sh(path.read_bytes()) for path in sorted(SOURCE.rglob("*")) if path.is_file()}
save(OUT / "results.json", {"marker": "HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL", "hostname": socket.gethostname(), "platform": platform.platform(),
    "runtime": sys.version, "source_kind": "OWNED_WORKING_TREE_SNAPSHOT_NOT_HEAD", "source_directory": str(SOURCE), "source_files": source_before,
    "source_unchanged": source_before == source_after, "fixture_driver_sha256": sh(FIXTURE_DRIVER.read_bytes()),
    "trusted_env_sha256": sh(TRUSTED.read_bytes()), "fixture_root": str(temp_root), "environment_key_names": sorted(env),
    "cli_calls": len(results), "results": results, "not_run": not_run, "capabilities": {"ci_junction": ci, "root_junction": root_alias, "file_symlink": file_link},
    "all_cases_passed": all(row["passed"] for row in results), "fixture_programs_executed": False,
    "new_volume_mount_or_host_changes": False})
assert source_before == source_after and all(row["passed"] for row in results)
print("completed", len(results), "native CLI controls; no subject programs executed")
