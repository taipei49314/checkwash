"""Freeze current working-tree source, then run only selected owned regressions."""
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import shutil
import socket
import subprocess
import sys
import tempfile

HERE = Path(__file__).parent.resolve()
SESSION = HERE.parents[2]
REPO = SESSION / "work/checkwash-ux"
SOURCE_ROOT = Path(os.environ.get("CW_T178_BASELINE_SOURCE", str(REPO)))
PYTHON = SESSION / "work/test-runtime/Scripts/python.exe"
GIT = Path(r"C:\Program Files\Git\cmd\git.exe")
BASH = Path(r"C:\Program Files\Git\bin\bash.exe")
TRUSTED = SESSION / "work/trusted/replay_pju_action.py"
phase = sys.argv[1]
tests = sys.argv[2:] or ["test_task_repo_relative_authority.py"]
out = HERE / phase
out.mkdir(parents=True, exist_ok=False)
snapshot = out / "snapshot"
snapshot.mkdir()
def sh(raw):
    return hashlib.sha256(raw).hexdigest()
def save(path, value):
    path.write_bytes((json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))
source_paths = [p for p in sorted((SOURCE_ROOT / "src").rglob("*")) if p.is_file() and "__pycache__" not in p.parts]
before = {str(p.relative_to(SOURCE_ROOT)).replace("\\", "/"): sh(p.read_bytes()) for p in source_paths}
for path in source_paths:
    destination = snapshot / path.relative_to(SOURCE_ROOT)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(path.read_bytes())
dependencies = ["test_task_repo_relative_authority.py"] if "test_task_source_encoding.py" in tests else []
for name in dict.fromkeys(["conftest.py", *tests, *dependencies]):
    destination = snapshot / "tests" / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes((REPO / "tests" / name).read_bytes())
(snapshot / "README.md").write_bytes((REPO / "README.md").read_bytes())
after = {str(p.relative_to(SOURCE_ROOT)).replace("\\", "/"): sh(p.read_bytes()) for p in source_paths}
assert before == after, "Shared source changed while snapshotting; no tests started"
spec = importlib.util.spec_from_file_location("trusted_capture_environment", TRUSTED)
trusted = importlib.util.module_from_spec(spec)
spec.loader.exec_module(trusted)
temp_root = Path(tempfile.mkdtemp(prefix="cw-t178-"))
env = trusted.clean_environment(PYTHON, GIT, BASH, temp_root)
env.update(GREENWASH_TODAY="2026-10-27", PYTHONDONTWRITEBYTECODE="1")
head = subprocess.run([str(GIT), "-C", str(REPO), "rev-parse", "HEAD"], env=env, capture_output=True, check=True).stdout
status = subprocess.run([str(GIT), "-C", str(REPO), "status", "--porcelain=v1", "--untracked-files=all"], env=env, capture_output=True, check=True).stdout
delta = subprocess.run([str(GIT), "-C", str(REPO), "diff", "--binary"], env=env, capture_output=True, check=True).stdout
(out / "source-head.stdout").write_bytes(head)
(out / "source-status.stdout").write_bytes(status)
(out / "source-working-diff.patch").write_bytes(delta)
args = [*[str(snapshot / "tests" / name) for name in tests], "-o", "addopts=", "-q", "-ra", "--basetemp", str(temp_root / "pytest"), "--junitxml", str(out / "junit.xml")]
bootstrap = "import sys;sys.path.insert(0," + repr(str(snapshot / "src")) + ");import pytest;raise SystemExit(pytest.main(" + repr(args) + "))"
command = [str(PYTHON), "-I", "-B", "-X", "utf8", "-c", bootstrap]
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
save(out / "started.json", {"command": command, "cwd": str(snapshot), "started_utc": started, "source_files": before,
      "source_kind": "WORKING_TREE_SNAPSHOT_NOT_HEAD", "observed_head": head.decode().strip()})
with (out / "stdout.bin").open("wb") as stdout, (out / "stderr.bin").open("wb") as stderr:
    process = subprocess.run(command, cwd=snapshot, env=env, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr, timeout=1800)
frozen_after = {name: sh((snapshot / name).read_bytes()) for name in before}
assert frozen_after == before
inputs = {str(p.relative_to(snapshot)).replace("\\", "/"): sh(p.read_bytes()) for p in sorted((snapshot / "tests").rglob("*")) if p.is_file()}
receipt = {"marker": "HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL", "hostname": socket.gethostname(), "platform": platform.platform(),
    "runtime": sys.version, "python": str(PYTHON), "phase": phase, "source_kind": "WORKING_TREE_SNAPSHOT_NOT_HEAD",
    "observed_head": head.decode().strip(), "working_diff_sha256": sh(delta), "source_files": before,
    "source_input_directory": str(SOURCE_ROOT), "test_input_directory": str(REPO / "tests"),
    "frozen_source_unchanged": True, "test_inputs": inputs, "trusted_environment_helper_sha256": sh(TRUSTED.read_bytes()),
    "environment_key_names": sorted(env), "temp_root": str(temp_root), "command": command, "cwd": str(snapshot),
    "started_utc": started, "ended_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "exit": process.returncode,
    "stdout_sha256": sh((out / "stdout.bin").read_bytes()), "stderr_sha256": sh((out / "stderr.bin").read_bytes()),
    "fixture_programs_executed": False, "scope": "Named TASK path tests only; product fixtures statically analyzed"}
save(out / "receipt.json", receipt)
(out / "exit").write_bytes(str(process.returncode).encode() + b"\n")
print(json.dumps({"phase": phase, "exit": process.returncode, "receipt": str(out / "receipt.json"), "source_files": len(before)}, indent=2))
sys.exit(process.returncode)
