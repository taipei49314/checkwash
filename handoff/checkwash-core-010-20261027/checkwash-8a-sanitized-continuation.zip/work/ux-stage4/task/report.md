# TASK authority / strict source encoding — stage4 implementation

Implemented the authorized D-178 repo-relative TASK path repair and connected
root's D-181 authority loader, including strict UTF8 BASE decoding. No product
commit, push, full suite or release was performed by this agent. Root owns
the atomic integration, SPEC/DECISIONS/docs and final fixed-source validation.
The latest human authorization permits necessary0.x core contract repairs;
the former inert/UX-only boundary is no longer treated as a blocker. Stop
before1.0 for the required human decision.

`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`; actual LAPTOP-01AGNPJU, Windows
10.0.26200, Python3.11.9, pytest9.1.1. Credential-free allowlist environments,
`-I -B -X utf8`, bounded owned temporary prefixes and original stdout/stderr/
exit/input hashes are retained. Fixture Python/pytest bodies and TASK content
are only static analysis inputs, never executed as subject programs.

## Implementation and ownership

- `src/checkwash/cli.py` computes one lexical
  `abspath(join(args.repo_given, args.task))`, with the direct-call `args.repo`
  fallback, and reuses it for Git-relative mapping, the root-only genuine-
  absence open and path context. No realpath/HEAD alias resolution is added.
- BASE still supplies scope/freeze. #416 nonroot misses and #500 task-case/
  proper-prefix file/symlink/gitlink refusals remain. Root-only genuine
  absence still warns that the working copy is controlled by the change.
- Both authority reads now call root's `load_contract`, with exact BASE or
  working-fallback source labels. BASE uses strict UTF8; UnicodeDecodeError
  becomes a fixed safe EngineError requiring UTF8, without TASK value text.
  Fallback retains its strict UTF8 open. NUL/quoted/header/shape refusals are
  owned by root's loader. The historical decoder is not used by this CLI.
- Added `test_task_repo_relative_authority.py` (30 cases) and
  `test_task_source_encoding.py` (15 cases). The existing diagnostic test's
  trigger is now an actually outside-repo task, preserving its refusal/context
  purpose instead of requiring the repaired cwd bug. No `.gwcase` expected
  labels or existing golden verdicts were edited.
- `contract-wording.md` gives the exact D-178 SPEC/DECISIONS/doc paragraph
  for root integration. `D178-cli-path.patch` and `D181-cli-authority.patch`
  separate the two integration slices; `D181-cli-utf8.patch` isolates only
  the strict decode change. These are recorded slices of the implementation,
  not a claim that any old unexecuted patch was tested retrospectively.

CLI ownership was returned to gitlink_fix for D-183 worktree pytest context
after these edits, with raw hash
`1265a98d944819efdd32028837ec29cb0b2edc4a8d69deda209adbdadd495fa4`.
This agent will not overwrite the subsequent D-183 edits. Root's later HEAD
movement/index-only commits do not rewrite these earlier source snapshots.

## Completed focused verification

| Evidence | Actual native result |
|---|---|
| D-178 valid red | `before-corrected/`:30 new cases,21 failed /9passed, exit1. Tests use the preserved pre-repair working-tree source with corrected fixture setup. |
| D-178 green + diagnostic regression | `after-path-focused/`:33passed, exit0,629.82s;30 new cases plus3existing diagnostic cases. |
| Strict encoding red | `encoding-before/`:2failed /13passed, exit1,337.34s. At that source root's NUL/header guards already refused several UTF16/BOM forms, but replacement-decoded invalidUTF8 still silently lost authority. |
| Strict encoding green | `encoding-after/`:15passed, exit0,333.72s. |
| Native path matrix | `native/`:24/24 actual CLI controls pass; source/hash stable. Includes original20 shapes plus C: drive-relative repo, root-relative task, external-cwd genuine fallback and parent task. |
| Native source encoding | `native-encoding/`:12/12 actual CLI controls pass; LE/BE BOM, BOMless UTF16/NUL, invalidUTF8, UTF8BOM and validBASE/invalidHEAD in JSON/hook-json. Fake TASK value never enters error output. |

The new path test bytes are identical between valid red/green, and encoding
test bytes are identical between its red/green. The green tests are48 distinct
selected pytest cases; native36CLI observations are a separate evidence class,
not added into a fictitious test count. Every suite uses an owned complete
working-tree source copy with before/after hashes. They are **not final-HEAD
qualification** and do not claim HEAD already contained those edits.

`native/old20-comparison.json` compares actual new outcomes with the original
20 historical observations. Material exit/verdict/full-finding movement IDs
are exactly02,03,04,05,09,10,12,19, as the reviewed plan predicted. The other
12 full finding outcomes are unchanged. PASS→BLOCK and BLOCK→PASS are both
disclosed; hook12 changes NOT_ANALYSED/no decision to decision:block while
keeping native exit0. Full native payloads/fingerprints and all command bytes
are retained. Original20raw/results were never overwritten.

Sixteen actual BASE/HEAD Git blobs from the two new native fixture repositories
are exported with Git OIDs and SHA256 in `native/fixture-input-export/`.
The encoding cases save every BASE/HEAD input byte under
`native-encoding/inputs/`. The trusted original constructor is identified by
its hash; the new source snapshots are separately identified in each receipt.

## Preserved development failures and limits

The initial new fixture accidentally left HEAD at its already changed commit,
so a worktree leg was clean. That setup was corrected to retain the range
candidate ref while HEAD/index point to BASE and disk contains after bytes.
The original `before/` and `after/` attempts are preserved and superseded;
their apparent worktree failures are not product acceptance results.

Two broad attempts that also included all #416/#500 modules exceeded their
900-second development-driver budget and stopped without a completed suite
receipt. Their partial raw streams remain in `after/` and
`after-corrected-r2/`; neither is called PASS. The related #416/#500 native
boundary controls completed in the24-call matrix. Final whole-source suite
coverage of those legacy modules belongs to root's once-frozen final run.
A separate source-copy attempt in `after-corrected/` detected concurrent
shared-source edits before starting tests and is likewise not a test result.
The eventual focused33-case run completed separately, without overwriting
any of those partial attempts.

Available C: address forms were tested natively. Owned directory junctions
worked and the BASE link-prefix refusal was exercised. An actual file symlink
probe failed WinError1314; no second qualified volume or owned UNC share was
established. Those capabilities remain NOT_RUN. No mount/subst, host-global
runtime/PATH/security/service/permission change or pool investigation occurred.

## Original-scope inventory and remaining review

`remaining-core-inventory.md` rechecks all14 original issues, not just four
decision packets and not127 blanket PASS claims. It identified the concrete
UTF16 BASE gap above, #13 parser and #8 CRLF pairing now owned by root, and
the still-missing worktree/Stop paired pytest context (now assigned D-183 to
gitlink_fix). Ruff ignore/preview/other unqualified settings remain an explicit
capability limit; diagnostic regressions do not qualify a new profile.

This agent has also begun independent adversarial oracle review, with an
actual JS prior-assertion prefix counterexample reported to quality_fix/root.
That separate blocker is not hidden by these TASK passes. Product full-suite,
cross-platform/distribution/release acceptance, historical/model/cohort work
are not inferred from this development slice.
