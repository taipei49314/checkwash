"""Twelve bounded native UTF-8 authority controls; fixture Python never runs."""
import datetime
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import socket
import subprocess
import sys
import tempfile

HERE = Path(__file__).parent.resolve()
SESSION = HERE.parents[2]
OUT = HERE / "native-encoding"
OUT.mkdir(exist_ok=False)
RAW = OUT / "raw"
RAW.mkdir()
SOURCE = HERE / "encoding-after/snapshot/src"
PYTHON = SESSION / "work/test-runtime/Scripts/python.exe"
GIT = Path(r"C:\Program Files\Git\cmd\git.exe")
TEMP = Path(tempfile.mkdtemp(prefix="cw-t181-"))
TRUSTED = SESSION / "work/trusted/replay_pju_action.py"
spec = importlib.util.spec_from_file_location("trusted_environment", TRUSTED)
trusted = importlib.util.module_from_spec(spec)
spec.loader.exec_module(trusted)
env = trusted.clean_environment(PYTHON, GIT, Path(r"C:\Program Files\Git\bin\bash.exe"), TEMP / "process")
env.update(PYTHONDONTWRITEBYTECODE="1", GREENWASH_TODAY="2026-10-27", GIT_OPTIONAL_LOCKS="0")
def sh(raw):
    return hashlib.sha256(raw).hexdigest()
def save(path, data):
    path.write_bytes((json.dumps(data, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))
commands, results, inputs = [], [], []
def call(name, argv, cwd):
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    value = subprocess.run(argv, cwd=cwd, env=env, stdin=subprocess.DEVNULL, capture_output=True, timeout=60)
    stdout, stderr = RAW / (name + ".stdout"), RAW / (name + ".stderr")
    stdout.write_bytes(value.stdout)
    stderr.write_bytes(value.stderr)
    row = {"label": name, "command": [str(v) for v in argv], "cwd": str(cwd), "start": start,
        "end": datetime.datetime.now(datetime.timezone.utc).isoformat(), "exit": value.returncode,
        "stdout": str(stdout.relative_to(OUT)), "stderr": str(stderr.relative_to(OUT)),
        "stdout_sha256": sh(value.stdout), "stderr_sha256": sh(value.stderr)}
    commands.append(row)
    save(OUT / "commands.json", commands)
    return value, row
def git(repo, *args):
    value, _ = call("git-" + str(len(commands)).zfill(3), [str(GIT), "-c", "core.hooksPath=NUL", "-c", "core.fsmonitor=false", "-C", str(repo), *args], TEMP)
    assert value.returncode == 0
    return value.stdout.decode("ascii").strip()
def write(root, path, data):
    target = root / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
FREEZE = b"---\ncheckwash:\n  oracle_freeze: true\n---\n"
LOOSE = b"---\ncheckwash:\n  oracle_freeze: false\n---\n"
text = FREEZE.decode()
cases = [("utf16-le-bom", b"\xff\xfe" + text.encode("utf-16-le"), LOOSE, False),
         ("utf16-be-bom", b"\xfe\xff" + text.encode("utf-16-be"), LOOSE, False),
         ("utf16-without-bom", text.encode("utf-16-le"), LOOSE, False),
         ("invalid-utf8", b"\xffFAKE_TASK_VALUE_SECRET", LOOSE, False),
         ("utf8-bom", b"\xef\xbb\xbf" + FREEZE, LOOSE, False),
         ("valid-base-invalid-head", FREEZE, b"\xff\xfe" + text.encode("utf-16-le"), True)]
source_before = {str(p.relative_to(SOURCE)): sh(p.read_bytes()) for p in sorted(SOURCE.rglob("*")) if p.is_file()}
bootstrap = "import sys;sys.path.insert(0," + repr(str(SOURCE)) + ");from checkwash.cli import main;raise SystemExit(main())"
for case, before_task, after_task, valid_base in cases:
    repo = TEMP / case
    repo.mkdir()
    git(repo, "init", "-q", "-b", "main")
    for key, value in (("user.name", "UTF8 authority control"), ("user.email", "utf8@example.invalid"),
                       ("commit.gpgsign", "false"), ("core.autocrlf", "false")):
        git(repo, "config", key, value)
    before_files = {"TASK.md": before_task, "calc.py": b"def calc(x):\n    return x * 2\n",
                    "tests/test_calc.py": b"from calc import calc\n\ndef test_calc():\n    assert calc(2) == 4\n"}
    after_files = {"TASK.md": after_task, "calc.py": b"def calc(x):\n    return x * 2 + 0\n",
                   "tests/test_calc.py": before_files["tests/test_calc.py"].replace(b"== 4", b"> 0")}
    revisions = {}
    for side, files in (("base", before_files), ("head", after_files)):
        for name, raw in files.items():
            write(repo, name, raw)
            destination = OUT / "inputs" / case / side / name
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(raw)
            inputs.append({"case": case, "side": side, "path": name, "sha256": sh(raw), "bytes": len(raw),
                           "evidence": str(destination.relative_to(OUT))})
        git(repo, "add", ".")
        git(repo, "commit", "-q", "-m", "static " + side)
        revisions[side] = git(repo, "rev-parse", "HEAD")
    for fmt in ("json", "hook-json"):
        name = case + "-" + fmt
        command = [str(PYTHON), "-I", "-B", "-X", "utf8", "-c", bootstrap, "check",
                   revisions["base"] + ".." + revisions["head"], "--repo", str(repo), "--task", "TASK.md", "--format", fmt]
        value, receipt = call(name, command, TEMP)
        payload = json.loads(value.stdout) if value.stdout else None
        if valid_base:
            passed = value.returncode == (0 if fmt == "hook-json" else 1)
            passed = passed and (payload.get("decision") == "block" if fmt == "hook-json" else
                                payload.get("verdict") == "block" and any("ORACLE_FREEZE" in f.get("escalators", []) for f in payload["findings"]))
        else:
            passed = value.returncode == (0 if fmt == "hook-json" else 2)
            passed = passed and (payload is None if fmt == "json" else "decision" not in payload and "systemMessage" in payload)
            passed = passed and (b"UTF-8 required" in value.stderr or b"invalid TASK contract" in value.stderr)
        passed = passed and b"FAKE_TASK_VALUE_SECRET" not in value.stdout + value.stderr
        results.append({"case": case, "format": fmt, "valid_base": valid_base, "revisions": revisions,
                        "exit": value.returncode, "payload": payload, "passed": passed, "receipt": receipt})
        save(OUT / "results-progress.json", results)
        print(name, value.returncode, "PASS" if passed else "UNEXPECTED", flush=True)
source_after = {str(p.relative_to(SOURCE)): sh(p.read_bytes()) for p in sorted(SOURCE.rglob("*")) if p.is_file()}
save(OUT / "inputs.json", inputs)
save(OUT / "results.json", {"marker": "HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL", "hostname": socket.gethostname(), "runtime": sys.version,
    "platform": platform.platform(), "source_kind": "OWNED_WORKING_TREE_SNAPSHOT_NOT_HEAD", "source_directory": str(SOURCE),
    "source_files": source_before, "source_unchanged": source_before == source_after, "cli_calls": len(results), "results": results,
    "all_cases_passed": all(r["passed"] for r in results), "fixture_programs_executed": False, "private_task_value_not_leaked": True,
    "fixture_root": str(TEMP), "environment_key_names": sorted(env), "trusted_environment_helper_sha256": sh(TRUSTED.read_bytes())})
assert source_before == source_after and all(row["passed"] for row in results)
print("completed", len(results), "native UTF8 controls")
