# D-178 TASK authority — wording for root integration

Latest human authorization permits necessary core contracts and0.x version
changes; the prior UX-only/inert restriction no longer applies. Root owns
SPEC/DECISIONS/docs integration. This file supplies exact D-178 wording;
the new strict TASK syntax loader belongs to D-181 and remains distinct.

## SPEC §4c path paragraph

Let R be the directory originally named by `--repo` (default `.`), interpreted
natively relative to invocation cwd if R is relative. Compute
`T = os.path.abspath(os.path.join(R, args.task))` once for lookup. Relative
`--task` therefore belongs to the originally named directory, before Git
re-roots the review; it is not independently resolved against cwd or the
re-rooted Git root. From a subdirectory map T relative to R, prepend Git's
`--show-prefix`, and collapse `.`/`..` lexically. At the root map T relative
to the repository address. Never call realpath or resolve a HEAD-side task
alias to select a BASE contract.

Native address rules remain load-bearing: a fully-qualified path supplies
its own address; on Windows a root-relative task takes its drive/share from
R and a same-drive `C:TASK.md` joins R. These are native lexical operations,
not an implicit drive/share mount or alias-canonicalization feature.
A native relpath failure remains an engine error; it cannot activate fallback.

Read the mapped BASE path even if HEAD rewrites either contract. From a
subdirectory a BASE miss remains an engine error under #416. At the root,
#500's case-insensitive task spelling/proper-prefix checks still refuse an
existing BASE file, symlink or gitlink that the requested disk spelling can
stand for. Only genuine BASE absence permits opening T from the worktree,
with the existing disclosure that the change controls that fallback. It is
not necessary that the path be untracked. The permitted fallback may still
be followed by the OS; it is never used to rescue a refused BASE alias.

## DECISIONS D-178

Bind `--task` once to the original `--repo` directory, using native lexical
join/abspath and retaining `args.repo_given` before Git re-rooting. The old
code passed a raw relative task token to relpath/open, so cwd could choose a
different existing BASE contract; this caused both PASS-instead-of-freeze
and BLOCK-against-the-wrong-contract, not merely lookup errors. The lookup,
root-only genuine-absence fallback and context diagnostic now use the same
T. BASE authority, #416's nonroot miss refusal and #500's case/prefix alias
refusal remain. No HEAD realpath is used to determine authority.

This is a minor contract change even when it corrects the previous SPEC
sentence: actual scope/freeze selection can change both verdict directions
and SCOPE_DRIFT identity. Existing callers relying on cwd-relative behavior
must express a path relative to the intended `--repo` directory, or use a
fully-qualified repository-owned task address. Native Windows rooted/drive-
relative behavior is explicit; untested UNC/cross-volume forms must remain
NOT_RUN rather than inheriting a blanket compatibility claim.

Historical9a observations, forecasts and their corrected raw-vs-LF metadata
remain preserved. Current development receipts identify their own copied
working-tree bytes and do not claim that HEAD already contains those edits.
Native range/worktree controls compare the same intended BASE contract;
the fixture source itself is never executed. Root records final accepted
source and validation separately. D-178 does not authorize a1.0 release or
revive historical/paid/model/adjudication grants.

## docs/task-input.md replacement for the old relative-path discrepancy note

`--task` paths are relative to the directory originally named by `--repo`,
whose default is the invocation directory. For example,
`--repo pkg --task TASK.md` selects `pkg/TASK.md`, even though CheckWash
reviews the whole Git repository after finding its root. Use
`--repo pkg --task ../TASK.md` to select the root contract deliberately, or
use a fully-qualified repository-owned path. Git's BASE copy supplies policy
even when HEAD changes that task. At the root only, a genuinely absent BASE
task may use the working copy with a warning; case/prefix aliases and
subdirectory BASE misses remain refusals. Do not change spelling or resolve
a HEAD symlink to bypass those checks.

On Windows the native path rules also apply: a root-relative task uses the
repo address's drive/share, while same-drive `C:TASK.md` joins that repo
directory. Use fully-qualified paths when portability is important. These
rules do not create a drive mapping or make every symlink/UNC topology a
supported input. The supplied task is still subject to the restricted syntax
validator; a correct lookup is not proof that malformed policy was applied.
