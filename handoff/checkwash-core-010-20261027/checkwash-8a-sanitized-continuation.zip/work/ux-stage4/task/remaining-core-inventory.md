# Stage4 original-scope audit — more than the four policy packets

This ledger uses the original handoff01/02 and cluster+claim references, the
sealed stage1/2/3 reports, current source and the latest human authorization.
It is not a127-claim PASS table. Prior UX-only/inert restrictions no longer
block authorized0.x implementation. No historical/model batch or1.0 release
is inferred. Product/fixture programs have not been executed by this audit;
the small contract probes execute only the trusted CheckWash parser.

| Original item | Concrete current implementation state / needed work |
|---|---|
| 1 terminal encoding | Owned decoration fallback already implemented with legacy/UTF stream controls. The original complete user terminal was not supplied/replayed. No currently reproduced silent-policy defect is hidden under this residual; changing all source/evidence rendering or global encoding would exceed that named repair. |
| 2 main reader junction | Actual tracked-entry inside/outside and C: repo-root junction controls exist. Safe refusal diagnostics implemented. The external source still refuses intentionally; no evidence supports admitting arbitrary external/reparse targets. Different volume/file-symlink native capability gaps remain specific NOT_RUNs. |
| 3 policy shadow | Stage4 policy/IR3 bundle now applied by its owner, with consumer/proof tests in progress. This is no longer merely the old unapplied proposal. Effective predecessor comparison, alias/path normalization and consumer migration require their actual source tests/final integration. |
| 4 TASK path | D-178 helper now binds original repo_given, preserves lexical BASE/#416/#500 and root-only fallback.24 new native shapes pass on an owned working-tree snapshot. Focused regression completion is separate; not final-HEAD qualification. |
| 5 managed hook maintenance | Actual doctor→install→critical block was reproduced. Tracked warning and review guidance implemented. Retaining prior-BASE review rather than a settings-wide managed exception is a deliberate trust choice; no additional exception implementation is silently required. Full historical upgrade/Claude lifecycle remains unrun. |
| 6 quality outputs | Usage and explain/profiles/init envelopes/guidance already implemented; PS5.1/7.6 UTF8 saved-byte controls and docs exist. Setup remains advisory. Unsupported shell/profile combinations remain untested, not new successful results. |
| 7 rename/oracle | Oracle owner is implementing the broader credit/context repair. The old exact E2-only patch is insufficient to claim all escapes closed: defaultA/B, whole-body decorator context, mass compensation, imported/aliased subjects and language boundaries need actual new controls. Independent adversarial review is the next assigned task after this TASK slice. |
| 8 worktree/range CRLF pairing | A genuine core implementation item beyond the original four decision packets. Old controls observed raw pairing differences but did not reproduce a pure-move false block. Root now owns D-182 CRLF-only pairing; semantic byte/content and fingerprint controls are necessary, not a claim that quality CRLF fixed rename pairing. |
| 9 dirty registered gitlink | Exact stage0 mode160000 ordinary-directory reader fix already implemented, with pointer/dirty/untracked/adjacent real finding and ordinary/nested-directory negative controls. No newly unimplemented core in those measured shapes. |
| 10 quality trust/allow | Wrong-ledger known-QW fake success fixed. ChoiceA retains two required lanes and prior-BASE review, with18 native controls and exact trust text. Do not call an entry human approval. ChoiceB is not implicitly demanded by retainingA; neither whole-quality nor whole-settings exemption is a repair requirement. |
| 11 unknown fingerprint | Writer/reader/doctor advisory implemented, future namespace storage/eligibility intentionally retained. Eligibility is not actual finding match. A blanket future-rule rejection would introduce a new compatibility change rather than finish a missing narrow bug fix. |
| 12 quality CRLF/junction/Ruff | CRLF policy/allow/version and exact Python3.11 junction fixes implemented. Ruff diagnostics fixed, but nonempty ignore/preview/target-version/src/per-file contexts remain unsupported under the existing qualified profile. This is a concrete unimplemented capability, not a completed profile expansion. See the qualification distinction below. |
| 13 TASK parser | A genuine core item beyond path binding: root owns D-181 fail-closed authority loader. The quoted-header/tab cases reported during this audit are now refused by actual current-source probes. The original UTF16 BASE loss was still accepted after replacement decoding; CLI now strictly decodes UTF8 and emits safe EngineError. Root handles valid-UTF8 NUL refusal; new encoding tests/native controls are in progress. Historical parse_contract remains a decoder, not a user-policy authority entrance. |
| 14 sweep input/diagnostics | Paired frozen pytest config and safe per-commit diagnostics implemented, with original counters/exits/denominator retained. No old historical numbers were revalidated. An additional worktree pytest-alias capability boundary remains below; do not simply mark every caller equivalent. |

## Concrete #13 gap found and fixed during this stage

Original `F-task-contract-and-sweep/#13-I` was not just cosmetic. BASE used
`data.decode('utf-8', errors='replace')`; UTF16 became a NUL/replacement string
and silently yielded `present=false, freeze=false`, while fallback UTF8 open
was strict. The bounded probe in `inventory/contract-probe-receipt.json` has
stable current-source hashes and proves that exact accepted-empty result.
The new CLI patch uses strict UTF8, wraps UnicodeDecodeError with a fixed
`--task <mapped> (BASE): UTF-8 required` reason, and never copies the task
value. Root's loader supplies NUL/shape rejection and preserves the historical
decoder for non-authority fixture use. The encoding controls separately test
LE/BE BOM, BOMless NUL, invalidUTF8, UTF8BOM and validBASE/invalidHEAD.

## Ruff capability is not new qualification

Original `E-quality-realworld-and-cli-output/#12-2A/B/C` explicitly describes
the current profile's unqualified ignore matching, target-version, src and
other lint interference. The profile itself lists those unsupported cases;
`#12-2D`'s real-repository frequency is UNCLEAR/unmeasured. Stage2 changed
reason text, not these capabilities. Completing an ignore/preview model would
require an exact adapter/profile implementation and its native qualification
controls; it cannot be credited from message regressions or by suppressing
incomplete. The existing limited-preview contract permits explicit incomplete
results, so this inventory does not automatically equate every unsupported
Ruff configuration with a newly proven engine defect or launch a natural
cohort/model measurement. The final0.x report must still say support has not
expanded if that model is not implemented.

## Worktree pytest alias is not frozen-tree parity

Original `F-task-contract-and-sweep/#14-A/E` identifies a further caller
boundary: `_cmd_check` still creates PairedPytestConfigs only in range mode;
worktree/managed Stop usesNone. Current PairedPytestConfigs deliberately
requires GitSnapshot's frozen-tree/config reader and `_tree_entries`; it
cannot safely be wired to WorkingTreeSnapshot as a one-line parity patch.
The stage1 sweep fix closes sweep versus range, not this different route.

This source-level missing capability is concrete, but no new native valid
file-symlink worktree witness was executed here: the available PJU capability
probe reports WinError1314, and a Git120000 blob with an absent/plain stub on
disk would not be a valid runtime symlink control. Do not turn that into a
false measured escape or a PASS. An implementation would need bounded
worktree config provenance/admission and paired target-change semantics;
that must be tested with an actually valid file symlink on an authorized
capable runtime. No new mount, privilege or pool investigation is justified.

## Current coverage accounting

The task is already broader than policy/TASK-path/oracle/qualityA because
D-181 andD-182 are now owned concrete implementation slices. The remaining
Ruff/worktree-pytest capabilities are explicitly disclosed above rather than
erased by the19 old UX repairs. Existing unknown/future fingerprints,
external-source refusal and prior-BASE trust are intentional retained
semantics, not missing blanket bypass features. All measured/unknown/refuted
claims remain tied to their original cluster+id and actual-source receipts.
