"""Run the fixed candidate's ordinary PR self-check with the actual local date."""
from datetime import datetime, timezone, timedelta
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = root.parent / "checkwash-ux"
head = (root / "final-source-sha.txt").read_text(encoding="utf-8").strip()
today = datetime.now(timezone(timedelta(hours=8))).date().isoformat()
env = dict(os.environ)
env["CHECKWASH_TODAY"] = today
env.pop("GREENWASH_TODAY", None)
env["PYTHONPATH"] = str(repo / "src")
command = [sys.executable, "-B", "-m", "checkwash", "check",
           "1ffe283d7d947fecc426dea99323b0a2620a9482.." + head,
           "--repo", str(repo), "--format", "json"]
print(json.dumps({"today": today, "date_zone": "Asia/Taipei (+08:00)",
                  "command": command, "type": "ordinary self-dogfood, not release bridge"}),
      file=sys.stderr, flush=True)
raise SystemExit(subprocess.run(command, cwd=repo, env=env).returncode)
