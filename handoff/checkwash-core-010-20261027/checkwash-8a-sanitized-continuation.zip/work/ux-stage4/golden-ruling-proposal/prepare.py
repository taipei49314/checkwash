"""Prepare an INERT expected-only ruling patch from retained actual receipts.

No product imports, analyzer, CLI, modified judge or subject fixture execution.
The sole optional prediction runs the unchanged pinned matcher function on
stored finding dictionaries; that is not an executed golden acceptance test.
"""
import ast
import copy
import datetime
import difflib
import hashlib
import importlib.util
import json
import pathlib
import platform
import socket
import subprocess
import types

HERE = pathlib.Path(__file__).resolve().parent
SESSION = HERE.parents[2]
REPO = SESSION / 'work' / 'checkwash-ux'
COST = HERE.parent / 'oracle' / 'cost-r4'
BASE = '9a5a27f44c895ba2fdee8c83a6313baf0e120873'
STATUS = 'INERT_NOT_APPLIED_NOT_ACCEPTED_NONPASS_STILL_OPEN'
PYTHON = pathlib.Path(r'C:\Users\nelson\AppData\Local\Programs\Python\Python311\python.exe')
GIT = pathlib.Path(r'C:\Program Files\Git\cmd\git.exe')
BASH = pathlib.Path(r'C:\Program Files\Git\bin\bash.exe')
for name in ('originals', 'git-reads', 'owned-tmp'):
    (HERE / name).mkdir(exist_ok=False)

def sha(data):
    return hashlib.sha256(data).hexdigest()
def blob_id(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
def save_json(path, value):
    path.write_bytes((json.dumps(value, indent=2, ensure_ascii=True) + '\n').encode())

helper_path = SESSION / 'work' / 'trusted' / 'replay_pju_action.py'
spec = importlib.util.spec_from_file_location('trusted_cleanenv', helper_path)
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
env = helper.clean_environment(PYTHON, GIT, BASH, HERE / 'owned-tmp')
git_ledger = []
def git(*args):
    command = [str(GIT), '-c', 'core.hooksPath=NUL', '-c', 'core.fsmonitor=false',
               '-C', str(REPO), *args]
    result = subprocess.run(command, env=env, capture_output=True, timeout=30)
    prefix = 'git-reads/' + str(len(git_ledger)).zfill(3)
    (HERE / (prefix + '.stdout')).write_bytes(result.stdout)
    (HERE / (prefix + '.stderr')).write_bytes(result.stderr)
    git_ledger.append({'command': command, 'exit': result.returncode,
                       'stdout': prefix + '.stdout', 'stdout_sha256': sha(result.stdout),
                       'stderr': prefix + '.stderr', 'stderr_sha256': sha(result.stderr)})
    if result.returncode:
        raise RuntimeError('Read-only Git provenance call failed')
    return result.stdout

register_bytes = (COST / 'immutable-cost-register.json').read_bytes()
results_bytes = (COST / 'results.json').read_bytes()
register = json.loads(register_bytes)
results = json.loads(results_bytes)
assert sha(results_bytes) == register['source_sha256']
assert len(register['rows']) == 8
assert results['candidate_source_unchanged'] and results['old_source_unchanged']
head = git('rev-parse', 'HEAD').decode().strip()

# Extract one unchanged pure matcher; do not import cases.py or engine.py.
cases_path = 'src/checkwash/cases.py'
baseline_cases = git('show', f'{BASE}:{cases_path}')
def matcher_source(raw):
    text = raw.decode('utf-8')
    tree = ast.parse(text)
    function = next(node for node in tree.body if isinstance(node, ast.FunctionDef)
                    and node.name == 'match_expectations')
    return ast.get_source_segment(text, function)
pure_matcher_source = matcher_source(baseline_cases)
assert pure_matcher_source == matcher_source((REPO / cases_path).read_bytes())
namespace = {'json': json}
exec(compile(pure_matcher_source, '<unchanged-pinned-match_expectations>', 'exec'), namespace)
match = namespace['match_expectations']
(HERE / 'pinned-match-expectations.py.txt').write_bytes((pure_matcher_source + '\n').encode())

categories = {
    'bare_bound_then_used_neg': 'DIFFERENT_OBLIGATION_OUTPUT_REPLACED_BY_INPUT_EQUALITY',
    'split_rename_genuine_neg': 'DIFFERENT_SUBJECT_NORMALIZATION_NO_EQUIVALENCE_PROOF',
    'unittest_keyword_split_neg': 'DIFFERENT_SUBJECT_NORMALIZATION_NO_EQUIVALENCE_PROOF',
    'test_split_neg': 'UNKNOWN_CHANGED_SETUP_OR_DEFAULTS',
    'subject_pairing_other_subject_known_limit_pos': 'UNKNOWN_FIXTURE_SETUP_INPUT_REWRITE_WITH_INDEPENDENT_BLOCK_RETAINED',
    'assert_removed_moved_neg': 'UNKNOWN_ASSERTION_SIDE_EFFECT_ORDER',
    'js_chai_property_moved_neg': 'UNKNOWN_ASSERTION_SIDE_EFFECT_ORDER',
    'merged_parametrize_neg': 'UNKNOWN_DYNAMIC_BUILTIN_LOOKUP',
}
patches, rulings = [], []
for row in register['rows']:
    case = row['case']
    path = 'tests/cases/' + case + '.gwcase'
    original = git('show', f'{BASE}:{path}')
    base_oid = git('rev-parse', f'{BASE}:{path}').decode().strip()
    head_bytes = git('show', f'{head}:{path}')
    head_oid = git('rev-parse', f'{head}:{path}').decode().strip()
    working = (REPO / path).read_bytes()
    assert sha(original) == row['fixture_sha256']
    assert original == head_bytes == working
    assert base_oid == head_oid == blob_id(original)
    (HERE / 'originals' / (case + '.gwcase')).write_bytes(original)
    marker = b'=== expect ===\n'
    assert original.count(marker) == 1 and b'\r' not in original
    prefix, expect_raw = original.split(marker)
    old_expect = json.loads(expect_raw)
    assert old_expect == row['preserved_expectations']
    new_expect_raw = expect_raw
    escalator = 'PROD_CHANGE_NOT_EVIDENCE' if case == 'subject_pairing_other_subject_known_limit_pos' else 'NO_PROD_CHANGE_IN_DIFF'
    for severity in ('warn', 'info'):
        new_expect_raw = new_expect_raw.replace(('"severity": "' + severity + '"').encode(), b'"severity": "high"')
    for credit in ('RESTRUCTURED', 'ASSERTION_MOVED'):
        new_expect_raw = new_expect_raw.replace(('"deescalators": ["' + credit + '"]').encode(),
            ('"escalators": ["' + escalator + '"]').encode())
    proposed = prefix + marker + new_expect_raw
    new_expect = json.loads(new_expect_raw)
    assert len(old_expect) == len(new_expect) == len(row['new_findings'])
    for old, new in zip(old_expect, new_expect):
        if old['rule'] == 'ASSERT_WEAKENED':
            assert old == new  # The independent block is never relaxed.
        else:
            assert new['severity'] == 'high' and new['escalators'] == [escalator]
            assert set(new) == (set(old) - {'deescalators'}) | {'escalators'}
            assert {key: value for key, value in old.items() if key not in {'severity', 'deescalators'}} == {
                key: value for key, value in new.items() if key not in {'severity', 'escalators'}}
    actual = [types.SimpleNamespace(**finding) for finding in row['new_findings']]
    original_mismatch = match(old_expect, actual)
    predicted_mismatch = match(new_expect, actual)
    assert original_mismatch is not None and predicted_mismatch is None
    diff = ''.join(difflib.unified_diff(original.decode().splitlines(keepends=True),
        proposed.decode().splitlines(keepends=True), fromfile='a/' + path, tofile='b/' + path, n=2))
    assert diff
    patches.append(diff)
    rulings.append({'case': case, 'status': STATUS, 'category': categories[case],
        'reason': row['classification'], 'path': path, 'original_blob': base_oid,
        'baseline_commit': BASE, 'observed_head': head, 'head_blob': head_oid,
        'original_sha256': sha(original), 'head_and_working_fixture_equal_baseline': True,
        'proposed_bytes_sha256_static_only': sha(proposed),
        'input_prefix_bytes_unchanged': proposed.split(marker)[0] == prefix,
        'before_expected': old_expect, 'proposed_expected': new_expect,
        'actual_old_verdict': row['old_verdict'], 'actual_new_verdict': row['new_verdict'],
        'actual_new_findings_from_receipt': row['new_findings'],
        'static_original_matcher_mismatch': original_mismatch,
        'static_proposed_matcher_mismatch': predicted_mismatch,
        'static_prediction_only': True, 'modified_label_test_execution': 'NOT_RUN',
        'acceptance': 'NOT_ACCEPTED_ISSUE_567_EIGHT_NATIVE_FAILURES_REMAIN_OPEN',
        'original_raw_prefix': row['raw_prefix']})

patch = ''.join(patches).encode()
(HERE / 'expected-only.patch').write_bytes(patch)
save_json(HERE / 'rulings.json', {'status': STATUS, 'rows': rulings})
source_binding = {key: results[key] for key in ('marker', 'hostname', 'runtime', 'executable',
    'baseline_source_sha', 'candidate_binding', 'old_source_files', 'candidate_source_files',
    'old_source_unchanged', 'candidate_source_unchanged', 'static_api_calls', 'product_cli_calls',
    'fixtures_executed', 'driver_sha256', 'arm_driver_sha256')}
source_binding.update(status=STATUS, results_sha256=sha(results_bytes),
    immutable_register_sha256=sha(register_bytes),
    new_product_calls_in_this_proposal=0, matcher_prediction='UNCHANGED_PINNED_MATCHER_ON_RETAINED_DICTIONARIES_ONLY',
    pinned_matcher_module_sha256=sha(baseline_cases), pinned_matcher_function_sha256=sha(pure_matcher_source.encode()))
save_json(HERE / 'source-binding.json', source_binding)
save_json(HERE / 'git-read-receipts.json', git_ledger)
save_json(HERE / 'validation.json', {'status': STATUS, 'hostname': socket.gethostname(),
    'runtime': platform.python_version(), 'observed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'case_count': len(rulings), 'original_blob_head_working_matches': all(row['head_and_working_fixture_equal_baseline'] for row in rulings),
    'all_input_prefixes_unchanged': all(row['input_prefix_bytes_unchanged'] for row in rulings),
    'all_static_predictions_match_retained_findings': all(row['static_proposed_matcher_mismatch'] is None for row in rulings),
    'proposal_applied': False, 'accepted': False, 'product_or_fixture_test_calls': 0,
    'source_inputs_sha256': {'results.json': sha(results_bytes), 'immutable-cost-register.json': sha(register_bytes)},
    'expected_only_patch_sha256': sha(patch), 'git_read_calls': len(git_ledger)})
print(json.dumps({'status': STATUS, 'cases': len(rulings), 'patch_sha256': sha(patch),
                  'head': head, 'old_pass_to_new_block': sum(row['actual_old_verdict'] == 'pass' and row['actual_new_verdict'] == 'block' for row in rulings),
                  'all_original_labels_unchanged': True, 'new_product_or_fixture_test_calls': 0}, indent=2))
