"""Validate the inert diff in memory and hash this proposal; never apply it."""
import hashlib
import json
import pathlib
import re

HERE = pathlib.Path(__file__).resolve().parent
def sha(data):
    return hashlib.sha256(data).hexdigest()
def save_json(path, value):
    path.write_bytes((json.dumps(value, indent=2) + '\n').encode())
rulings = json.loads((HERE / 'rulings.json').read_bytes())
expected = {row['path']: row for row in rulings['rows']}
patch = (HERE / 'expected-only.patch').read_bytes()
assert b'\r' not in patch
lines = patch.decode().splitlines(keepends=True)
index = 0
reconstructed = []
while index < len(lines):
    assert lines[index].startswith('--- a/')
    path = lines[index][6:].rstrip('\n')
    index += 1
    assert lines[index] == '+++ b/' + path + '\n'
    index += 1
    row = expected[path]
    original = (HERE / 'originals' / (row['case'] + '.gwcase')).read_bytes()
    source = original.decode().splitlines(keepends=True)
    output, cursor = [], 0
    while index < len(lines) and lines[index].startswith('@@ '):
        match = re.fullmatch(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@\n', lines[index])
        assert match
        old_start, old_count, new_start, new_count = (int(value) if value is not None else 1 for value in match.groups())
        output.extend(source[cursor:old_start - 1])
        cursor = old_start - 1
        index += 1
        old_used = new_used = 0
        while index < len(lines) and not lines[index].startswith(('@@ ', '--- a/')):
            line = lines[index]
            prefix, content = line[0], line[1:]
            assert prefix in ' +-'
            if prefix in ' -':
                assert source[cursor] == content
                cursor += 1
                old_used += 1
            if prefix in ' +':
                output.append(content)
                new_used += 1
            index += 1
        assert old_used == old_count and new_used == new_count
    output.extend(source[cursor:])
    after = ''.join(output).encode()
    assert sha(after) == row['proposed_bytes_sha256_static_only']
    assert after.split(b'=== expect ===\n')[0] == original.split(b'=== expect ===\n')[0]
    reconstructed.append(path)
assert len(reconstructed) == 8 and set(reconstructed) == set(expected)
validation = json.loads((HERE / 'validation.json').read_bytes())
validation.update(inert_diff_in_memory_reconstruction_only=True, inert_diff_reconstructed_paths=reconstructed,
                  changed_expected_rows=11, unchanged_independent_assert_weakened_rows=1,
                  repository_fixture_writes=0, modified_label_golden_or_cli_execution='NOT_RUN')
save_json(HERE / 'validation.json', validation)
files = {p.relative_to(HERE).as_posix(): sha(p.read_bytes()) for p in sorted(HERE.rglob('*'))
         if p.is_file() and p.name != 'manifest.json'}
save_json(HERE / 'manifest.json', {'status': rulings['status'], 'file_count': len(files), 'files': files,
    'product_or_fixture_test_calls': 0, 'proposal_applied': False, 'acceptance': 'NOT_ACCEPTED',
    'immutable_existing_review_evidence_writes': 0})
print(json.dumps({'status': rulings['status'], 'files': len(files), 'inert_diff_paths': len(reconstructed),
    'patch_sha256': sha(patch), 'readme_sha256': sha((HERE / 'README.md').read_bytes()),
    'manifest_sha256': sha((HERE / 'manifest.json').read_bytes())}, indent=2))
