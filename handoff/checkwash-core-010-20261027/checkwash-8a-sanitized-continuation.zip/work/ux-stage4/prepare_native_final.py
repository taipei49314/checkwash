"""Derive a final-source replay from the preserved static driver; no product imports."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
OLD = HERE.parent / "ux-stage2/final-compat/run.py"
OUT = HERE / "native-final-control"
OUT.mkdir(exist_ok=False)
raw = OLD.read_bytes()
text = raw.decode("utf-8")
text = text.replace('EXPECTED = "9a5a27f44c895ba2fdee8c83a6313baf0e120873"',
                    'EXPECTED = "8a8941dc2d7c581715a0f6f196c00da6c55f084b"')
text = text.replace('Does not apply or import the inert protected-policy proposal.',
                    'Uses the adopted sealed 0.10.0 core contracts; no fixture program runs.')
text = text.replace('tracked_inputs = [OLD / "reproduce.py", OLD / "supplement.py", OLD / "results.json", OLD / "supplement/results.json"]',
                    'tracked_inputs = [OLD / "reproduce.py", OLD / "supplement.py", OLD / "results.json", OLD / "supplement/results.json", SESSION / "work/ux-stage2/final-compat/run.py", SESSION / "work/ux-stage2/final-compat/case-inputs.json", SESSION / "work/ux-stage2/final-compat/comparison.json"]')
needle = '(HERE / "case-inputs.json").write_bytes(input_bytes)'
text = text.replace(needle, '''assert input_bytes == (SESSION / "work/ux-stage2/final-compat/case-inputs.json").read_bytes(), "original fixture input bytes changed"
''' + needle)
needle = '''        gating = (SOURCE / "src/checkwash/gating.py").read_bytes()
        assert gating == git_read("show", "f86aabbbe7e61891d8b93cb2c043b9bcae44f88a:src/checkwash/gating.py"), "protected judge unexpectedly differs"'''
assert needle in text
text = text.replace(needle, '''        # Every source member is checked against the exact 8a Git blob map.
        # The former UX-only gating equality is superseded by the adopted core.
        seal = json.loads((SESSION / "work/ux-stage4/seal/source-seal.json").read_bytes())
        assert seal["source_sha"] == EXPECTED and seal["all_tracked_bytes_match_git"]
        seal_files = {row["path"]: row for row in seal["files"] if row["path"].startswith("src/")}
        assert set(seal_files) == set(before_source)
        for path, row in before_source.items():
            assert row["git_blob"] == seal_files[path]["git_blob"]
            assert row["sha256"] == seal_files[path]["sha256"]''')
needle = 'original.run = recorded_run'
text = text.replace(needle, '''git_journal = []
def recorded_git(arguments, cwd, env):
    command = ["git", *arguments]
    result = subprocess.run(command, cwd=cwd, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
    stem = HERE / "git-raw" / f"{len(git_journal):04d}"
    stem.parent.mkdir(exist_ok=True)
    stdout, stderr = stem.with_suffix(".stdout"), stem.with_suffix(".stderr")
    stdout.write_bytes(result.stdout)
    stderr.write_bytes(result.stderr)
    git_journal.append({"command": command, "cwd": str(cwd), "exit": result.returncode,
                        "stdout": str(stdout.relative_to(HERE)), "stdout_sha256": digest(result.stdout),
                        "stderr": str(stderr.relative_to(HERE)), "stderr_sha256": digest(result.stderr)})
    (HERE / "git-journal.json").write_text(json.dumps(git_journal, indent=2), encoding="utf-8")
    if result.returncode:
        raise RuntimeError(result.stderr.decode("utf-8", "replace"))
    return result.stdout.decode("ascii").strip()

original.git = recorded_git
''' + needle)
needle = '        fields = ("exit", "verdict", "summary", "config_errors", "skipped_files", "findings")'
text = text.replace(needle, '''        candidate_schema = {key: type(value).__name__ for key, value in candidate_payload.items()}
        baseline_schema = {key: type(value).__name__ for key, value in old_payload.items()}
''' + needle)
needle = '        if candidate_payload["checkwash_findings_version"] != old_payload["checkwash_findings_version"]:'
text = text.replace(needle, '''        if candidate_schema != baseline_schema:
            differences.append("payload_schema")
''' + needle)
needle = '                            "differences": differences, "candidate_receipt": row["receipt"], "baseline_receipt": old["receipt"]})'
assert needle in text
text = text.replace(needle, '''                            "differences": differences, "candidate_receipt": row["receipt"], "baseline_receipt": old["receipt"],
                            "candidate_schema": candidate_schema, "baseline_schema": baseline_schema,
                            "candidate_exit": row["exit"], "baseline_exit": old["exit"],
                            "candidate_verdict": row["verdict"], "baseline_verdict": old["verdict"],
                            "candidate_findings": row["findings"], "baseline_findings": old["findings"]})''')
needle = 'receipt = {"provenance":'
assert needle in text
text = text.replace(needle, '''required_controls = []
for row in candidate["results"]:
    check = None
    if row["oracle_freeze"] and row["case"] in {"A", "B", "cross_file_param_changed"}:
        check = (row["exit"] == 1 and row["verdict"] == "block"
                 and any(f["severity"] in {"high", "critical"} for f in row["findings"]))
    elif row["case"] in {"N_unroll_changed", "control_same_name_changed"}:
        check = row["exit"] == 1 and row["verdict"] == "block"
    elif row["case"] in {"control_rename_only", "control_cross_file_move", "control_unroll_preserved"}:
        check = row["exit"] == 0 and row["verdict"] == "pass" and not row["findings"]
    assert row["config_errors"] == [] and row["skipped_files"] == [], "not an analysed control"
    if check is not None:
        required_controls.append({"case": row["case"], "freeze": row["oracle_freeze"], "entry": row["entry"], "passed": check})
receipt = {"provenance":''')
text = text.replace('           "protected_proposal_applied_or_executed": False,',
                    '           "adopted_core_contracts": True, "git_command_count": len(git_journal),\n           "required_controls": required_controls, "required_control_failures": [row for row in required_controls if not row["passed"]],')
text = text.replace('raise SystemExit(1 if receipt["differing_pairs"] else 0)',
                    'raise SystemExit(1 if receipt["required_control_failures"] else 0)')
(OUT / "run.py").write_text(text, encoding="utf-8", newline="\n")
(OUT / "derivation.json").write_text(json.dumps({
    "source_driver": str(OLD), "source_driver_sha256": hashlib.sha256(raw).hexdigest(),
    "derived_driver_sha256": hashlib.sha256((OUT / "run.py").read_bytes()).hexdigest(),
    "product_modified": False, "fixture_definition_modified": False,
    "source_sha": "8a8941dc2d7c581715a0f6f196c00da6c55f084b",
    "execution": "NOT_EXECUTED_BY_PREPARATION",
}, indent=2), encoding="utf-8")
print(OUT / "run.py")
