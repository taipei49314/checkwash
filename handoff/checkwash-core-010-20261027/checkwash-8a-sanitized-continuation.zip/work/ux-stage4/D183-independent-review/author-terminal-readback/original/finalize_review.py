"""Summarize existing independent receipts; no product imports or execution."""
import datetime
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2] / "work/checkwash-ux"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(relative):
    return json.loads((HERE / relative).read_text(encoding="utf-8"))


checks = []
for label in ("rename-consistency-red", "rename-four-red", "rename-four-green", "bounded-r2-capture"):
    receipt = read(f"{label}/receipt.json")
    for stream in ("stdout", "stderr"):
        assert sha(HERE / label / stream) == receipt[f"{stream}_sha256"]
        checks.append(f"{label}/{stream}")
    assert receipt["source_unchanged"]
    assert receipt["source_hashes_before"] == receipt["source_hashes_after"]
    assert not receipt["fixture_programs_executed"] and receipt["product_cli_calls"] == 0
    assert receipt["exit"] == (1 if label.endswith("red") else 0)

for label in ("bounded-r1", "bounded-r2"):
    receipt = read(f"{label}/receipt.json")
    assert receipt["all_expected"] and receipt["source_unchanged"]
    for command in receipt["raw_commands"]:
        assert command["exit"] == 0
        for stream in ("stdout", "stderr"):
            relative = f"{label}/raw/{command['name']}.{stream}"
            assert sha(HERE / relative) == command[f"{stream}_sha256"]
            checks.append(relative)

red = read("rename-four-red/stdout")
green = read("rename-four-green/stdout")
assert sum(row["actual"] != row["expected"] for row in red) == 2
assert all(row["actual"] == row["expected"] for row in green)
final = read("bounded-r2/receipt.json")
rename = read("rename-four-green/receipt.json")
assert final["source_hashes_after"] == rename["source_hashes_after"]
for path, digest in final["source_hashes_after"].items():
    assert sha(REPO / path) == digest

audit = {
    "review_state": "PASS_NO_REMAINING_BLOCKERS",
    "scope": "BOUNDED_D183_INDEPENDENT_REVIEW_NOT_FULL_QUALIFICATION",
    "remaining_blocking_findings": [],
    "resolved_findings": [{
        "id": "D183_RENAME_OLD_PATH_CAPTURED_DIFF_CONSISTENCY",
        "red": "rename-four-red/receipt.json",
        "green": "rename-four-green/receipt.json",
        "observation_kind": "TRUSTED_FAKE_API_CONSISTENCY_NOT_NATIVE_ESCAPE",
        "correction": "Materialize changes once; normalize all explicit after paths first; then bind each different normalized old_path to absence with setdefault.",
        "explicit_old_path_after_preserved": True,
    }],
    "marker": final["marker"],
    "hostname": final["hostname"],
    "runtime": final["runtime"],
    "executable": final["executable"],
    "source_identity": "SHARED_WORKING_TREE_HASHES_NOT_HEAD_OR_FULL_TREE_MANIFEST",
    "final_reviewed_source_hashes": final["source_hashes_after"],
    "final_independent_observations": 8,
    "final_general_observations": final["observations"],
    "final_rename_observations": green,
    "raw_stream_hash_checks": len(checks),
    "raw_streams_checked": checks,
    "raw_commands": {"bounded-r1": 11, "bounded-r2": 11},
    "product_cli_calls": 0,
    "fixture_programs_executed": False,
    "product_files_modified_by_reviewer": [],
    "limits": [
        "Windows/Python 3.11.9 only for this independent readback.",
        "Native file symlink NOT_RUN: author established WinError 1314 capability limitation; trusted fake metadata is labeled separately.",
        "Read-once config evidence does not claim an atomic filesystem snapshot or eliminate TOCTOU.",
        "This review does not rerun the full suite, release qualification, or cross-platform matrix.",
        "Root's sealed Python 3.12.14 comparison remains separate; 3.13 and other OS coverage are not supplied here.",
        "Author's 27+77 regression was still running when this independent readback completed; its terminal receipt is a separate integration gate.",
    ],
    "created_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
}
(HERE / "audit.json").write_text(json.dumps(audit, indent=2) + "\n", encoding="utf-8")

report = """# D183 independent bounded review

Review state: **PASS_NO_REMAINING_BLOCKERS** within the inspected D183 scope. One independently reproduced captured-diff consistency defect was corrected by the author and passed the same independent controls. This is a bounded source/API readback, not full-suite or release qualification.

Host: LAPTOP-01AGNPJU; Python 3.11.9; `HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`. Product source was read only by this reviewer. Test programs represented by fixture bytes were not executed. The probes made zero CheckWash CLI calls; their native Git commands were confined to newly owned repositories under this review directory. No host-global configuration changed.

## Resolved finding

The original `WorktreePytestConfigs` captured only `change.path -> change.after`. A rename's `old_path` therefore lacked its captured absence obligation. A trusted fake working-tree source could report the old config recreated with different narrowing bytes, and the adapter accepted it. `rename-consistency-red` retained the initial two observations, exit 1. `rename-four-red` retained four controls, exit 1: recreation at either slash or backslash old path was wrongly accepted; genuine captured absence and an explicit old-path after change were accepted as expected. These are API consistency observations, not a claim of a native escape or arbitrary filesystem race elimination.

The author's correction materializes the changes iterable, builds all normalized explicit after records, then adds each different normalized old path with `setdefault(old_path, None)`. It consequently preserves explicit old-path after bytes regardless of ordering and supports generators. Independent `rename-four-green` exited 0: both recreated old paths were refused as differing from the captured diff, captured absence remained accepted, and an explicit old-path after record placed before the rename remained accepted. Original failed raw streams and receipts remain unchanged.

## Other inspected obligations

- Capability separation: the adapter calls the ordinary `read_many` even when a supplied trusted source also offers `read_config_many`; the stronger link-reading method received zero calls.
- HEAD/SessionBase pairing: the CLI's primary worktree comparison uses HEAD as its evidence base; `_session_note` creates a fresh pair using SessionBase. A native owned repository independently verified that the primary cache kept its first bytes while a fresh session pair read new bytes and the correct older BASE. Range mode retains two frozen Git snapshots.
- Identity and caching: an actual SHA-256 Git repository's `git hash-object --stdin` result exactly matched the worktree ConfigSource's raw-content OID. `revision='worktree'` claims neither a committed nor a stored object. Read-once caches remain local to one analysis.
- Admission and consistency: source inspection retained recognized-config requests, captured inventory, missing-versus-empty checks, modes checked before and after ordinary data reads, per-source/batch bounds and captured diff byte checks. Paired config deltas remain internal to config consumers, not regular source/provider byte maps.
- Final link admission: `WorkingTreeSnapshot.config_modes` resolves only the parent for containment, then uses final-path `lstat`. The independent trusted-fake metadata control prohibited final `resolve` and all ordinary byte reads, and still received the intended nonregular refusal. This does not count as native file-symlink coverage.

The final independent readback comprises four general observations plus four rename observations, all expected, under identical hashes for the three reviewed source files. `bounded-r2-capture` and `rename-four-green` both exited 0 with no changes to those three files. `audit.json` contains their exact hashes, observations and 52 verified original raw-stream hashes. The earlier `bounded-r1` observations are preserved separately.

## Scope limits

These are shared working-tree hashes, not a claim that HEAD already contained the changes or that every repository dependency was sealed by this reviewer. The source identity covers `cli.py`, `gitio/pytest_configs.py` and `gitio/snapshot.py`; root's final source manifest and complete validation remain separate.

This independent pass ran on Windows/Python 3.11.9. Native file symlink creation remains NOT_RUN because the author recorded WinError 1314; trusted fake metadata is explicitly identified in the evidence. Read-once evidence is not an atomic filesystem snapshot. No full suite, release qualification, other OS or Python 3.13 result is supplied. Root's available Python 3.12.14 sealed comparison is a separate check. The author's 27+77 required regression was still executing at completion of this independent readback; its terminal receipt remains an integration gate rather than an assumed PASS.
"""
(HERE / "report.md").write_text(report, encoding="utf-8", newline="\n")

members = {}
for path in sorted(HERE.rglob("*")):
    relative = path.relative_to(HERE)
    if ".git" in relative.parts or path.name == "manifest.json" or not path.is_file():
        continue
    members[relative.as_posix()] = sha(path)
(HERE / "manifest.json").write_text(json.dumps({
    "scope": "Review files, owned fixture regular files and raw evidence; native Git metadata excluded explicitly.",
    "members": members,
}, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"review_state": audit["review_state"], "raw_stream_hash_checks": len(checks),
                  "report_sha256": sha(HERE / "report.md"), "audit_sha256": sha(HERE / "audit.json"),
                  "manifest_sha256": sha(HERE / "manifest.json"), "members": len(members)}, indent=2))
