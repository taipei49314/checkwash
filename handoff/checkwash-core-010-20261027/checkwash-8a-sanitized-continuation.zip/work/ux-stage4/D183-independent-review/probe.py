"""Independent bounded native/API D183 readback; supplied programs never execute."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import socket
import stat
import subprocess
import sys
from types import SimpleNamespace
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2] / "work/checkwash-ux"
sys.path.insert(0, str(REPO / "src"))
from checkwash.change import EngineError
from checkwash.gitio.git import list_worktree_changes, list_session_changes
from checkwash.gitio.snapshot import GitSnapshot, WorkingTreeSnapshot
from checkwash.gitio.pytest_configs import PairedPytestConfigs, WorktreePytestConfigs

OUT = HERE / sys.argv[1]
OUT.mkdir(exist_ok=False)
(OUT / "raw").mkdir()
env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", PYTHONUTF8="1", GIT_CONFIG_GLOBAL="NUL",
           GIT_CONFIG_NOSYSTEM="1", GIT_TERMINAL_PROMPT="0")
for key in ("PYTHONHOME", "PYTHONPATH", "PYTHONSTARTUP", "PYTEST_ADDOPTS"):
    env.pop(key, None)
names = ("src/checkwash/cli.py", "src/checkwash/gitio/pytest_configs.py", "src/checkwash/gitio/snapshot.py")
def sha(raw):
    return hashlib.sha256(raw).hexdigest()
def sources():
    return {name: sha((REPO / name).read_bytes()) for name in names}
before = sources()
journal, observations = [], []
def command(name, arguments, cwd, data=None):
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    proc = subprocess.run(arguments, cwd=cwd, env=env, input=data, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
    for stream in ("stdout", "stderr"):
        (OUT / "raw" / (name + "." + stream)).write_bytes(getattr(proc, stream))
    journal.append({"name": name, "command": arguments, "cwd": str(cwd), "started": started,
        "finished": datetime.datetime.now(datetime.timezone.utc).isoformat(), "exit": proc.returncode,
        "stdout_sha256": sha(proc.stdout), "stderr_sha256": sha(proc.stderr)})
    assert proc.returncode == 0, proc.stderr.decode("utf-8", "replace")
    return proc.stdout

# Similar-looking interfaces cannot let this adapter borrow frozen-link reads.
class RegularOnly:
    reads = 0
    stronger_reads = 0
    def list_paths(self):
        return ["pytest.ini"]
    def config_modes(self, paths):
        return {path: b"100644" for path in paths}
    def read_many(self, paths):
        self.reads += 1
        return {path: b"[pytest]\naddopts=-q\n" for path in paths}
    def read_config_many(self, _paths):
        self.stronger_reads += 1
        raise AssertionError("stronger Git-link capability was borrowed")
source = RegularOnly()
context = WorktreePytestConfigs(source, SimpleNamespace(_rev=lambda: "a" * 40), [])
record = context.read_config_many(["pytest.ini"])["pytest.ini"]
assert source.reads == 1 and source.stronger_reads == 0 and record.mode == b"100644"
observations.append({"case": "no_structural_borrow_of_link_capability", "regular_reads": source.reads,
    "link_capability_reads": source.stronger_reads, "expected": True})

# Native SHA256 repository identity, not a fake width-only commit.
owned = OUT / "sha256-repo"
owned.mkdir()
def git(label, *args, data=None):
    return command(label, ["git", *args], owned, data)
git("init", "init", "--object-format=sha256", "-q")
git("name", "config", "user.name", "D183 Independent Fixture")
git("email", "config", "user.email", "d183@example.invalid")
git("autocrlf", "config", "core.autocrlf", "false")
path = owned / "pytest.ini"
original = b"[pytest]\naddopts=\n"
path.write_bytes(original)
git("base-add", "add", ".")
git("base-commit", "-c", "core.hooksPath=NUL", "-c", "commit.gpgsign=false", "commit", "-qm", "base")
base = git("base-rev", "rev-parse", "HEAD").decode().strip()
head_bytes = b"[pytest]\naddopts=-q\n"
path.write_bytes(head_bytes)
git("head-add", "add", ".")
git("head-commit", "-c", "core.hooksPath=NUL", "-c", "commit.gpgsign=false", "commit", "-qm", "head")
head = git("head-rev", "rev-parse", "HEAD").decode().strip()
first = b"[pytest]\naddopts=-k keep\n"
path.write_bytes(first)
work = WorkingTreeSnapshot(owned)
head_snapshot = GitSnapshot(owned, head, side="base")
primary = PairedPytestConfigs(head_snapshot, WorktreePytestConfigs(work, head_snapshot,
    list_worktree_changes(str(owned), base=head))).prepare()
assert primary.sources("before", ["pytest.ini"])["pytest.ini"] == head_bytes
assert primary.sources("after", ["pytest.ini"])["pytest.ini"] == first
content_oid = git("native-blob-oid", "hash-object", "--stdin", data=first).strip()
item = primary.records["after"]["pytest.ini"]
assert len(base) == len(head) == len(content_oid) == 64
assert item.oid == item.target_oid == content_oid and item.revision == "worktree"
observations.append({"case": "native_sha256_raw_content_oid", "commit_width": len(head),
    "actual_git_blob_oid": content_oid.decode(), "reported_oid": item.oid.decode(), "revision": item.revision,
    "object_stored_claim": False, "expected": True})

# Read-once primary keeps its own bytes; a fresh session leg selects SessionBase.
second = b"[pytest]\naddopts=-k changed_after_primary\n"
path.write_bytes(second)
base_snapshot = GitSnapshot(owned, base, side="base")
session = PairedPytestConfigs(base_snapshot, WorktreePytestConfigs(work, base_snapshot,
    list_session_changes(str(owned), base))).prepare()
assert primary.sources("after", ["pytest.ini"])["pytest.ini"] == first
assert session.sources("before", ["pytest.ini"])["pytest.ini"] == original
assert session.sources("after", ["pytest.ini"])["pytest.ini"] == second
observations.append({"case": "head_vs_session_base_fresh_pair_and_read_once", "primary_base": head,
    "session_base": base, "primary_after_sha256": sha(first), "session_after_sha256": sha(second), "expected": True})

# Trusted fake metadata only. No native file-symlink creation is attempted.
link_root = OUT / "fake-link-only"
link_root.mkdir()
link = link_root / "pytest.ini"
link.write_bytes(b"owned stand-in, no native symlink")
snapshot = WorkingTreeSnapshot(link_root)
resolve, lstat = Path.resolve, Path.lstat
reads = []
def parent_only(path, *args, **kwargs):
    assert path != link, "final file link target must not resolve"
    return resolve(path, *args, **kwargs)
def fake_link(path, *args, **kwargs):
    return SimpleNamespace(st_mode=stat.S_IFLNK | 0o777) if path == link else lstat(path, *args, **kwargs)
def forbid_read(paths):
    reads.append(list(paths))
    raise AssertionError("link target source bytes were opened")
with patch.object(Path, "resolve", parent_only), patch.object(Path, "lstat", fake_link), patch.object(snapshot, "read_many", forbid_read):
    assert snapshot.config_modes(["pytest.ini"]) == {"pytest.ini": b"120000"}
    try:
        WorktreePytestConfigs(snapshot, SimpleNamespace(_rev=lambda: "a" * 40), []).read_config_many(["pytest.ini"])
    except EngineError as exc:
        assert "not a regular source" in str(exc)
    else:
        raise AssertionError("fake link metadata was silently admitted")
assert not reads
observations.append({"case": "final_link_metadata_never_resolves_or_reads_target", "expected": True,
    "coverage": "TRUSTED_FAKE_METADATA_NOT_NATIVE_OS_LINK", "native_file_link": "NOT_RUN_WINERROR1314_KNOWN_CAPABILITY_LIMIT"})

after = sources()
result = {"marker": "HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL", "hostname": socket.gethostname(),
    "runtime": sys.version, "executable": sys.executable, "source_binding": "SHARED_WORKING_TREE_NOT_HEAD",
    "source_hashes_before": before, "source_hashes_after": after, "source_unchanged": before == after,
    "observations": observations, "all_expected": all(row["expected"] for row in observations),
    "raw_commands": journal, "product_cli_calls": 0, "fixture_programs_executed": False,
    "driver_sha256": sha(Path(__file__).read_bytes())}
assert result["source_unchanged"]
(OUT / "receipt.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps(result, indent=2))
