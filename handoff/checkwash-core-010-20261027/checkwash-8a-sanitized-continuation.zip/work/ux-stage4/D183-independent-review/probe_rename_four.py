"""Four bounded captured-rename obligations; fake source, not native escape."""
import json
from pathlib import Path
import sys
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "work/checkwash-ux/src"))
from checkwash.change import EngineError, FileChange
from checkwash.gitio.pytest_configs import WorktreePytestConfigs

old, new = "old/pytest.ini", "new/pytest.ini"
data = b"[pytest]\naddopts=-k narrow\n"


class Source:
    def __init__(self, old_data):
        self.files = {new: b"old"}
        if old_data is not None:
            self.files[old] = old_data

    def list_paths(self):
        return sorted(self.files)

    def config_modes(self, paths):
        return {path: b"100644" if path in self.files else None for path in paths}

    def read_many(self, paths):
        return {path: self.files.get(path) for path in paths}


rename = FileChange(new, "modified", b"old", b"old", old_path=old)
explicit = FileChange(old, "modified", b"old", data)
controls = [
    ("recreated_old_path_refused", data, [rename], "REFUSED"),
    ("captured_old_absence_accepted", None, [rename], "ACCEPTED"),
    ("explicit_after_before_rename_preserved", data, [explicit, rename], "ACCEPTED"),
    ("backslash_old_path_normalized", data,
     [FileChange(new, "modified", b"old", b"old", old_path="old\\pytest.ini")], "REFUSED"),
]
observations = []
for name, old_data, changes, expected in controls:
    context = WorktreePytestConfigs(Source(old_data), SimpleNamespace(_rev=lambda: "0" * 40), changes)
    try:
        record = context.read_config_many([old])[old]
        actual, error = "ACCEPTED", None
    except EngineError as exc:
        actual, error = "REFUSED", str(exc)
    observations.append({"case": name, "actual": actual, "expected": expected, "error": error,
                         "kind": "TRUSTED_FAKE_SOURCE_CAPTURED_DIFF_CONSISTENCY_NOT_NATIVE_ESCAPE"})
print(json.dumps(observations, indent=2))
assert all(row["actual"] == row["expected"] for row in observations), "captured rename consistency failed"
