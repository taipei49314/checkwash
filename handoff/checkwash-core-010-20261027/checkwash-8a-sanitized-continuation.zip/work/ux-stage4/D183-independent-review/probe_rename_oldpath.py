"""One captured-rename consistency counterexample, plus explicit-after control."""
import json
from pathlib import Path
import sys
from types import SimpleNamespace
sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "work/checkwash-ux/src"))
from checkwash.change import EngineError, FileChange
from checkwash.gitio.pytest_configs import WorktreePytestConfigs

old, new = "old/pytest.ini", "new/pytest.ini"
class CapturedAfter:
    def __init__(self, old_bytes):
        self.files = {old: old_bytes, new: b"old"}
    def list_paths(self):
        return sorted(self.files)
    def config_modes(self, paths):
        return {path: b"100644" if path in self.files else None for path in paths}
    def read_many(self, paths):
        return {path: self.files.get(path) for path in paths}
rename = FileChange(new, "modified", b"old", b"old", old_path=old)
observations = []
for explicit_after in (False, True):
    data = b"[pytest]\naddopts=-k narrow\n"
    changes = [rename]
    if explicit_after:
        changes.append(FileChange(old, "modified", b"old", data))
    context = WorktreePytestConfigs(CapturedAfter(data), SimpleNamespace(_rev=lambda: "0" * 40), changes)
    try:
        record = context.read_config_many([old])[old]
        actual = "ACCEPTED"
        error = None
    except EngineError as exc:
        actual, error = "REFUSED", str(exc)
    observations.append({"explicit_old_path_after": explicit_after, "actual": actual,
        "expected": "ACCEPTED" if explicit_after else "REFUSED", "error": error,
        "kind": "TRUSTED_FAKE_SOURCE_CAPTURED_DIFF_CONSISTENCY_NOT_NATIVE_ESCAPE"})
print(json.dumps(observations, indent=2))
assert all(row["actual"] == row["expected"] for row in observations), "rename old-path absence was not bound to captured diff"
