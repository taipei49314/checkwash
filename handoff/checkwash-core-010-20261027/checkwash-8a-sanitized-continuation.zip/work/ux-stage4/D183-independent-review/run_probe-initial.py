"""Native raw capture of one bounded independent probe; no product edits."""
import hashlib
import json
import os
from pathlib import Path
import socket
import subprocess
import sys

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2] / "work/checkwash-ux"
label, script, *arguments = sys.argv[1:]
out = HERE / label
out.mkdir(exist_ok=False)
names = ("src/checkwash/cli.py", "src/checkwash/gitio/pytest_configs.py", "src/checkwash/gitio/snapshot.py")
def hashes():
    return {name: hashlib.sha256((REPO / name).read_bytes()).hexdigest() for name in names}
before = hashes()
command = [sys.executable, "-I", "-B", "-X", "utf8", str(HERE / script), *arguments]
proc = subprocess.run(command, cwd=HERE, env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"),
                      stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=90)
(out / "stdout").write_bytes(proc.stdout)
(out / "stderr").write_bytes(proc.stderr)
after = hashes()
receipt = {"marker": "HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL", "hostname": socket.gethostname(),
    "runtime": sys.version, "executable": sys.executable, "source_kind": "SHARED_WORKING_TREE_NOT_HEAD",
    "command": command, "cwd": str(HERE), "exit": proc.returncode,
    "source_hashes_before": before, "source_hashes_after": after, "source_unchanged": before == after,
    "script_sha256": hashlib.sha256((HERE / script).read_bytes()).hexdigest(),
    "stdout_sha256": hashlib.sha256(proc.stdout).hexdigest(), "stderr_sha256": hashlib.sha256(proc.stderr).hexdigest(),
    "fixture_programs_executed": False, "product_cli_calls": 0}
(out / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
print(proc.stdout.decode("utf-8", "replace"))
print(proc.stderr.decode("utf-8", "replace"))
print(json.dumps(receipt, indent=2))
