"""Read recorded author terminal results only; never imports product code."""
from collections import Counter
import datetime
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2] / "work/checkwash-ux"
AUTHOR = HERE.parent / "policy/pytest-context-rename-green"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


prior = read(HERE / "manifest.json")
for relative, digest in prior["members"].items():
    assert sha(HERE / relative) == digest, relative
revision = HERE / "author-terminal-readback"
original = revision / "original"
original.mkdir(parents=True, exist_ok=False)
preserved = {}
for name in ("audit.json", "report.md", "manifest.json", "finalize_review.py"):
    source = HERE / name
    (original / name).write_bytes(source.read_bytes())
    assert sha(original / name) == sha(source)
    preserved[name] = sha(source)

receipt = read(AUTHOR / "receipt.json")
assert receipt["exit_code"] == 0 and receipt["source_changed_paths"] == []
for stream in ("stdout", "stderr"):
    assert sha(AUTHOR / stream) == receipt[f"{stream}_sha256"]
for label in ("before", "after"):
    assert sha(AUTHOR / f"source-{label}.json") == receipt[f"source_{label}_manifest_sha256"]
before = read(AUTHOR / "source-before.json")
after = read(AUTHOR / "source-after.json")
assert before == after
tree = ET.parse(AUTHOR / "junit.xml").getroot()
suites = [tree] if tree.tag == "testsuite" else list(tree.iter("testsuite"))
assert sum(int(suite.attrib["tests"]) for suite in suites) == 104
assert all(int(suite.attrib[key]) == 0 for suite in suites for key in ("failures", "errors", "skipped"))
cases = list(tree.iter("testcase"))
classes = Counter(case.attrib["classname"] for case in cases)
assert classes == {"tests.test_worktree_pytest_config_context": 27, "tests.test_config_snapshot": 77}
assert not any(case.find(name) is not None for case in cases for name in ("failure", "error", "skipped"))
audit = read(HERE / "audit.json")
for path, digest in audit["final_reviewed_source_hashes"].items():
    assert before[path] == after[path] == sha(REPO / path) == digest
test = "tests/test_worktree_pytest_config_context.py"
assert before[test] == after[test] == sha(REPO / test) == "f13431d748bd20592f7d977480a4dd5b0592f0aa9084f146384dcb343f30fa77"

readback = {
    "review_state": "PASS_NO_REMAINING_BLOCKERS",
    "mode": "READ_ONLY_AUTHOR_TERMINAL_RECEIPT_NO_PRODUCT_IMPORT_OR_RERUN",
    "marker": receipt["marker"], "hostname": receipt["hostname"], "runtime": receipt["runtime"],
    "receipt": str(AUTHOR / "receipt.json"), "receipt_sha256": sha(AUTHOR / "receipt.json"),
    "junit": str(AUTHOR / "junit.xml"), "junit_sha256": sha(AUTHOR / "junit.xml"),
    "exit_code": receipt["exit_code"], "source_changed_paths": receipt["source_changed_paths"],
    "source_manifest_sha256": receipt["source_before_manifest_sha256"],
    "source_manifest_members": len(before),
    "tests": len(cases), "passed": len(cases), "failures": 0, "errors": 0, "skipped": 0,
    "group_counts": dict(classes), "current_owned_test_sha256": after[test],
    "original_review_member_hashes_verified": len(prior["members"]), "preserved_original_hashes": preserved,
    "prior_raw_files_rewritten": False, "product_calls": 0,
    "readback_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
}
(revision / "readback.json").write_text(json.dumps(readback, indent=2) + "\n", encoding="utf-8")
audit["author_terminal_readback"] = readback
pending = "Author's 27+77 regression was still running when this independent readback completed; its terminal receipt is a separate integration gate."
assert audit["limits"].count(pending) == 1
audit["limits"].remove(pending)
audit["author_terminal_correction"] = {
    "original_review_bytes_preserved": "author-terminal-readback/original",
    "old_pending_state_replaced_by_actual_terminal_receipt": True,
    "product_not_rerun": True,
}
(HERE / "audit.json").write_text(json.dumps(audit, indent=2) + "\n", encoding="utf-8")
report = (HERE / "report.md").read_text(encoding="utf-8")
old = "The author's 27+77 required regression was still executing at completion of this independent readback; its terminal receipt remains an integration gate rather than an assumed PASS."
new = "The author's separate required regression subsequently completed: the original receipt reports exit 0 and no changed source paths; independent standard-library readback of its actual JUnit confirms 104 passed (27 new controls + 77 existing config tests), zero failure/error/skip. Raw stream hashes and identical before/after source-manifest hashes were verified, and the three reviewed source files plus the new test module match those recorded bytes. This is a readback of the author's result, not a reviewer rerun. The earlier pending report, audit and manifest bytes are preserved under `author-terminal-readback/original`; `author-terminal-readback/readback.json` records their hashes and this correction."
assert report.count(old) == 1
(HERE / "report.md").write_text(report.replace(old, new), encoding="utf-8", newline="\n")
members = {}
for path in sorted(HERE.rglob("*")):
    relative = path.relative_to(HERE)
    if ".git" in relative.parts or relative.as_posix() == "manifest.json" or not path.is_file():
        continue
    members[relative.as_posix()] = sha(path)
(HERE / "manifest.json").write_text(json.dumps({
    "scope": "Review files, owned fixture regular files and raw evidence; native Git metadata excluded explicitly.",
    "members": members,
}, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"review_state": audit["review_state"], "passed": len(cases),
                  "audit_sha256": sha(HERE / "audit.json"), "report_sha256": sha(HERE / "report.md"),
                  "manifest_sha256": sha(HERE / "manifest.json"), "readback_sha256": sha(revision / "readback.json")}, indent=2))
