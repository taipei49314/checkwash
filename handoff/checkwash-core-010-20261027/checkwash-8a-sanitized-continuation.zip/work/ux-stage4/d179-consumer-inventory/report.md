# D179 tests/tools consumer inventory

Result: no additional required consumer migration was found beyond the
already reviewed issue219/266 changes. This is a read-only inventory and a
bounded focused test result; it does not replace the upcoming full suite.
No product/test/tool source, existing fixture bytes or expected labels were
modified by this work. Earlier independent oracle-review evidence is untouched.

Actual host LAPTOP-01AGNPJU, Python3.11.9/pytest9.1.1,
HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL. The scan observed shared working-tree
bytes, with HEAD72858bc3b08bf7dab21584aeb1ff2a9fb0b47a9e plus uncommitted
D179/D183 source. The test run used its own copied inputs, never a claim that
HEAD alone contained those changes. No analyzed fixture program, product CLI,
historical/model batch or native Git test was executed.

## Inventory scope

`scan.py` parsed all436 Python files under tests/tools with zero parse errors.
`scan.json` records every scanned file hash and415 relevant calls/metadata
references. Direct constructor counts are IR34, FileIR11, Unit7, UnitSide19,
DiffGlobals20. A text follow-up found no alternate `analyze as` alias,
`engine.analyze` or direct build_ir consumer that escaped this call inventory.

Only the new test_oracle_credit_context.py writes moved_assertion_texts
(line117), deliberately checking that text alone grants no credit. No old
test/tool directly writes moved_unit_hashes or duplicate_unit_hashes. The
former text/body lists remain diagnostic candidates; a consumer must not
manufacture equality merely by populating them. D179 oracle_context and
oracle_assertion_contexts must describe complete admitted source/startup
context. Missing strict context means no proof.

| Consumer group | Concrete files / purpose | Assessment |
| --- | --- | --- |
| Direct IR for alignment/detector primitives | test_duplicate_units.py; test_js_frontend.py; test_js_declarations.py; test_finding_shape.py; test_issue421_assertion_keys.py | Tests pairing, detector findings, shape or keys; does not claim D2/D5 relocation proof. No metadata migration indicated. |
| Direct scalar/fixture evidence | test_js_literal_evidence.py; test_js_scalar_consumers.py; test_issue471_fixture_producers.py; test_issue469_limit_messages.py; test_issue335_opaque_submodules.py; test_standin_installations_main.py; test_standin_source_limits.py | Exercises distinct detector or repair-evidence mechanisms. Adding fabricated relocation proof would change their subject. |
| Direct broad-except gating | test_issue419_narrow_broad_except.py | Its direct IR only sets opaque-repair facts for BROAD_EXCEPT_ADDED. D179 relocation credit is not requested. |
| JSON dataclass reconstruction | test_param_rows.py; test_param_row_expectations.py; test_subject_normalization.py; test_snapshot_expectations.py | UnitSide(**serialized_side) preserves new fields. The two parameter tests deliberately discard globals and call only their local detector; they do not assert gating equivalence. Four round trips passed. |
| Empty/direct report IR | test_documentation_contracts.py; test_findings_schema.py; test_human_decoration.py; test_issue454_unread_output.py; test_sarif_locations.py; test_policy_shadow_ir3_consumers.py | Output/schema tests use empty or unrelated IR facts. No relocation-credit assertion to migrate. |
| Other direct metadata | test_numeric_subject_context.py; test_table_normalization.py; test_param_row_replacements.py; test_fingerprint_scope.py | Native normalization/table shape or missing-evidence refusal tests. Their proof channels are distinct from D179. |
| Already reviewed full-context migrations | test_issue219_python_snapshot_tests.py run + duplicate control; test_issue266_survivor_conftest_chain.py | Current issue219 helper adds its existing closed snapshot as strict root; current issue266 distinguishes changed/unknown context. Keep the reviewed changes and positive controls; this review adds none. |

The scan found17 head_reader calls without an explicit root_reader. Their
concrete disposition is in summary.json, with the source line and function:

- Seven guard helpers in test_body_skips_class_attributes.py, issue196 guard
  and setup files, issue208_209, issue209 effects, issue254 and issue261
  test guard/liveness reporting, not a positive move/duplicate credit.
- issue216's one-hop script test concerns runner vocabulary; issue219's
  remaining direct call concerns weakened collectable code with a custom role.
- issue286's borrowed-oracle removal and issue512's two fingerprint helpers
  expect blocking removals/markers, not equivalent relocation. They pass in
  the focused readback without adding strict-root callbacks.
- issue415's two calls exercise oversized-context refusal; root_oracles'
  two calls deliberately exercise the legacy sibling channel or rename
  refusal; sarif_locations' call records unchanged helper locations.

Do not mechanically upgrade those17 helpers or restore head_reader as the
strict-root fallback. Any future positive relocation/duplicate test must
declare its owned closed snapshot explicitly, as issue219 now does. The
current absence of proof remains a deliberate conservative result.

All tools analyze call sites with head callbacks also pass a strict root
reader in the inventoried source. emit_corpus, assertion_contract,
reliability_r1_trace and the protected corpus runners retain closed snapshots;
this inventory does not rerun the1119 corpus or relabel its known costs.

## Bounded verification

The single focused invocation passed272 tests, with zero failures/errors/
skips and exit0. Inputs in focused-source remained byte-identical. It covers
the direct JS scalar/literal IR consumers, duplicate-name alignment, four
JSON round trips, Finding.shape, issue286 borrowed assertion removal,
issue512 fingerprint/removal helpers, selected JS role/runner moves and
the positive/negative runner relocation control. The one CLI allow test is
explicitly deselected; product_cli_calls is0. Selected overlap with the
author's reviewed-targeted tests is reported in summary.json, so these
numbers are not blindly added to the earlier184+1119 counts.

The raw stdout/stderr/JUnit, command/runtime/input maps and exit are retained
as focused.stdout, focused.stderr, focused-junit.xml and focused-receipt.json.
That receipt labels the owned copy of working bytes, not final-source or
cross-platform qualification. Unselected native/CLI and remaining full-suite
tests are NOT_RUN by this inventory and remain root's fixed-source work.
