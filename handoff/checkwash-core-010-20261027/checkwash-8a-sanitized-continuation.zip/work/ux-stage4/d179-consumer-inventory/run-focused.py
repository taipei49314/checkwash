"""Bounded nonnative test readback of inventoried D179 consumers."""
import datetime
import hashlib
import importlib.util
import json
import pathlib
import shutil
import socket
import subprocess
import sys

HERE = pathlib.Path(__file__).resolve().parent
SESSION = HERE.parents[2]
REPO = SESSION / 'work' / 'checkwash-ux'
PYTHON = SESSION / 'work' / 'test-runtime' / 'Scripts' / 'python.exe'
GIT = pathlib.Path(r'C:\Program Files\Git\cmd\git.exe')
BASH = pathlib.Path(r'C:\Program Files\Git\bin\bash.exe')
targets = ['tests/test_duplicate_units.py', 'tests/test_js_literal_evidence.py',
           'tests/test_js_scalar_consumers.py', 'tests/test_issue286_lent_tolerance_calls.py',
           'tests/test_issue512_test_disabled_keys.py',
           'tests/test_param_rows.py::test_json_round_trip_pairs_the_same_rows_and_reports_the_same_finding',
           'tests/test_param_row_expectations.py::test_json_round_trip_reports_the_same_expectation_findings',
           'tests/test_subject_normalization.py::test_json_array_proof_records_preserve_findings_after_dataclass_reconstruction',
           'tests/test_snapshot_expectations.py::test_snapshot_detection_uses_roundtrippable_ir_evidence',
           'tests/test_finding_shape.py',
           'tests/test_js_paths.py::test_collection_preserving_and_production_moves_remain_benign',
           'tests/test_js_runner_evidence.py::test_a_move_its_runner_still_collects_stays_benign',
           'tests/test_js_runner_evidence.py::test_a_unit_moved_into_a_file_its_runner_does_not_collect_earns_no_move_credit']
SNAPSHOT = HERE / 'focused-source'
SNAPSHOT.mkdir(exist_ok=False)
for name in ('src', 'tests'):
    shutil.copytree(REPO / name, SNAPSHOT / name, ignore=shutil.ignore_patterns('__pycache__', '*.pyc', '.pytest_cache'))
shutil.copyfile(REPO / 'pyproject.toml', SNAPSHOT / 'pyproject.toml')
def hashes():
    return {p.relative_to(SNAPSHOT).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(SNAPSHOT.rglob('*')) if p.is_file()}
before = hashes()
helper_path = SESSION / 'work' / 'trusted' / 'replay_pju_action.py'
spec = importlib.util.spec_from_file_location('trusted_cleanenv', helper_path)
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
scratch = HERE / 'focused-tmp'
scratch.mkdir(exist_ok=False)
env = helper.clean_environment(PYTHON, GIT, BASH, scratch)
env['PYTHONPATH'] = str(SNAPSHOT / 'src')
command = [str(PYTHON), '-B', '-X', 'utf8', '-m', 'pytest', *targets,
           '-k', 'not allow_refuses_a_legacy_test_disabled_key', '-q', '--tb=short',
           '-p', 'no:cacheprovider', '--junitxml', str(HERE / 'focused-junit.xml'),
           '--basetemp', str(scratch / 'pytest')]
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
try:
    process = subprocess.run(command, cwd=SNAPSHOT, env=env, capture_output=True, timeout=150)
    stdout, stderr, exit_code, timed_out = process.stdout, process.stderr, process.returncode, False
except subprocess.TimeoutExpired as exc:
    stdout, stderr, exit_code, timed_out = exc.stdout or b'', exc.stderr or b'', 124, True
(HERE / 'focused.stdout').write_bytes(stdout)
(HERE / 'focused.stderr').write_bytes(stderr)
after = hashes()
receipt = {'marker': 'HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL', 'hostname': socket.gethostname(),
           'source_kind': 'OWNED_COPY_OF_SHARED_WORKING_TREE_NOT_HEAD_QUALIFICATION',
           'runtime': sys.version, 'pytest_python': str(PYTHON), 'command': command, 'cwd': str(SNAPSHOT),
           'started': started, 'finished': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'exit': exit_code, 'timed_out': timed_out, 'before': before, 'after': after,
           'snapshot_unchanged': before == after, 'product_cli_calls': 0,
           'fixture_program_execution': 'NOT_RUN_STATIC_ANALYZER_INPUTS',
           'cleanenv_helper_sha256': hashlib.sha256(helper_path.read_bytes()).hexdigest(),
           'stdout_sha256': hashlib.sha256(stdout).hexdigest(), 'stderr_sha256': hashlib.sha256(stderr).hexdigest()}
(HERE / 'focused-receipt.json').write_bytes((json.dumps(receipt, indent=2) + '\n').encode())
print(stdout.decode('utf-8', 'replace'))
print(json.dumps({key: value for key, value in receipt.items() if key not in {'before', 'after'}}, indent=2))
raise SystemExit(exit_code)
