"""Read-only AST inventory of D179 test/tool consumers; no product imports."""
import ast
import hashlib
import json
import pathlib
import platform
import re
import socket

HERE = pathlib.Path(__file__).resolve().parent
REPO = HERE.parents[2] / 'work' / 'checkwash-ux'
constructors = {'IR', 'FileIR', 'Unit', 'UnitSide', 'DiffGlobals'}
metadata = {'moved_assertion_texts', 'moved_unit_hashes', 'duplicate_unit_hashes',
            'oracle_context', 'oracle_assertion_contexts'}
rows = []
hashes = {}
errors = []
for path in sorted([*(REPO / 'tests').rglob('*.py'), *(REPO / 'tools').rglob('*.py')]):
    raw = path.read_bytes()
    relative = path.relative_to(REPO).as_posix()
    hashes[relative] = hashlib.sha256(raw).hexdigest()
    try:
        tree = ast.parse(raw)
    except (SyntaxError, ValueError) as exc:
        errors.append({'path': relative, 'exception_type': type(exc).__name__})
        continue
    parents = {id(child): node for node in ast.walk(tree) for child in ast.iter_child_nodes(node)}
    def enclosing(node):
        while id(node) in parents:
            node = parents[id(node)]
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                return node.name
        return '<module>'
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            name = node.func.id if isinstance(node.func, ast.Name) else None
            if name in constructors | {'analyze', 'apply_gates'}:
                row = {'path': relative, 'line': node.lineno, 'function': enclosing(node), 'call': name,
                       'keywords': [kw.arg for kw in node.keywords]}
                if name == 'analyze':
                    row['head_only_no_strict_root'] = ('head_reader' in row['keywords'] and 'root_reader' not in row['keywords'])
                rows.append(row)
        elif isinstance(node, ast.Attribute) and node.attr in metadata:
            rows.append({'path': relative, 'line': node.lineno, 'function': enclosing(node),
                         'metadata': node.attr, 'access': type(node.ctx).__name__})
    relevant = [node.name for node in ast.walk(tree) if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
                and node.name.startswith('test_') and re.search('mov|duplicat|restructur|relocat|rename|split', node.name)]
    if relevant and any(row['path'] == relative and row.get('head_only_no_strict_root') for row in rows):
        rows.append({'path': relative, 'head_only_movement_test_names': relevant})
payload = {'marker': 'HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL', 'kind': 'READ_ONLY_AST_SCAN_NO_PRODUCT_IMPORT',
           'hostname': socket.gethostname(), 'python': platform.python_version(), 'file_count': len(hashes),
           'source_hashes': hashes, 'rows': rows, 'parse_errors': errors}
(HERE / 'scan.json').write_bytes((json.dumps(payload, indent=2) + '\n').encode())
for row in rows:
    if row.get('head_only_movement_test_names'):
        print(json.dumps(row))
print(json.dumps({'files_scanned': len(hashes), 'calls_or_metadata_rows': len(rows), 'parse_errors': errors}))
