"""Derive inventory disposition and hashes from retained read-only records."""
import collections
import hashlib
import json
import pathlib
import xml.etree.ElementTree as ET

HERE = pathlib.Path(__file__).resolve().parent
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
scan = json.loads((HERE / 'scan.json').read_bytes())
receipt = json.loads((HERE / 'focused-receipt.json').read_bytes())
reasons = {
    'test_body_skips_class_attributes.py': 'Guard constants/liveness, no positive relocation or duplicate proof',
    'test_issue196_guard_removal.py': 'Guard-removal reporting, no positive relocation proof',
    'test_issue196_setup_guards.py': 'Setup guard-removal reporting, no positive relocation proof',
    'test_issue208_209_suite_guards.py': 'Suite guard reporting, no positive relocation proof',
    'test_issue209_effects_pytestmark.py': 'Mark/guard effects, no positive relocation proof',
    'test_issue254_class_attribute_guards.py': 'Class guard constants, no positive relocation proof',
    'test_issue261_suite_guard_removed.py': 'Suite guard removal, no positive relocation proof',
    'test_issue216_runner_vocabulary.py': 'One-hop task-runner script vocabulary, not oracle equality',
    'test_issue219_python_snapshot_tests.py': 'Remaining direct call tests weakened collected code with custom role, not move equality',
    'test_issue286_lent_tolerance_calls.py': 'Borrowed assertion removal must block; focused tests pass without invented proof',
    'test_issue512_test_disabled_keys.py': 'Fingerprint/marker/removal identity, no relocation compensation; focused tests pass',
    'test_issue415_oversized_sources.py': 'Oversized context refusal, must not silently become a positive proof',
    'test_root_oracles.py': 'Intentional legacy sibling capability or rename refusal, preserve test intent',
    'test_sarif_locations.py': 'Unchanged imported helper location capture, not relocation credit',
}
head_only = []
for row in scan['rows']:
    if row.get('head_only_no_strict_root'):
        head_only.append({**row, 'reason': reasons[pathlib.PurePosixPath(row['path']).name],
                          'recommendation': 'KEEP_NO_MIGRATION_REQUIRED_FOR_THIS_TEST_PURPOSE'})
focused = ET.parse(HERE / 'focused-junit.xml')
author_path = HERE.parent / 'oracle' / 'final-reviewed-r3' / 'junit.xml'
author = ET.parse(author_path)
def ids(tree):
    return {case.attrib.get('classname', '') + '::' + case.attrib['name'] for case in tree.iter('testcase')}
mine, previous = ids(focused), ids(author)
overlap = sorted(mine & previous)
constructors = collections.Counter(row['call'] for row in scan['rows']
    if row.get('call') in {'IR', 'FileIR', 'Unit', 'UnitSide', 'DiffGlobals'})
summary = {'marker': scan['marker'], 'result': 'NO_NEW_REQUIRED_MIGRATION_IDENTIFIED',
           'source_kind': receipt['source_kind'], 'files_scanned': scan['file_count'], 'parse_errors': scan['parse_errors'],
           'constructor_sites': dict(constructors), 'head_only_calls': head_only,
           'direct_old_credit_metadata_sites': [row for row in scan['rows']
                if row.get('metadata') in {'moved_assertion_texts', 'moved_unit_hashes', 'duplicate_unit_hashes'}],
           'focused': {'tests': len(mine), 'exit': receipt['exit'], 'snapshot_unchanged': receipt['snapshot_unchanged'],
                       'overlap_with_author_final_reviewed_r3': overlap,
                       'overlap_count': len(overlap), 'not_in_that_selected_set': len(mine - previous),
                       'overlap_source': str(author_path), 'overlap_source_sha256': sha(author_path)},
           'new_product_edits': [], 'new_test_edits': [], 'new_golden_edits': [],
           'remaining_validation': 'Root final frozen-source full suite and qualification; no blanket PASS inferred'}
assert len(head_only) == 17 and len(mine) == 272
assert not scan['parse_errors'] and receipt['exit'] == 0 and receipt['snapshot_unchanged']
assert sha(HERE / 'focused.stdout') == receipt['stdout_sha256']
assert sha(HERE / 'focused.stderr') == receipt['stderr_sha256']
(HERE / 'summary.json').write_bytes((json.dumps(summary, indent=2) + '\n').encode())
payload = {'marker': scan['marker'], 'scope': 'Read-only D179 consumer inventory and one bounded nonnative focused invocation',
           'files': {p.name: sha(p) for p in sorted(HERE.iterdir()) if p.is_file() and p.name != 'manifest.json'},
           'owned_directories': {'focused-source': 'Owned copied test inputs; every member hash is in focused-receipt before/after',
                                 'focused-tmp': 'Owned cleanenv and pytest temporary files, no native subject execution'}}
(HERE / 'manifest.json').write_bytes((json.dumps(payload, indent=2) + '\n').encode())
print(json.dumps({'focused_tests': len(mine), 'overlap': len(overlap), 'outside_author_selected_set': len(mine - previous),
                  'head_only_calls': len(head_only), 'report_sha256': sha(HERE / 'report.md'),
                  'manifest_sha256': sha(HERE / 'manifest.json')}, indent=2))
