"""Read original root green receipts; no product/test invocation."""
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
SESSION=HERE.parents[2]
ROOT=SESSION/'work/ux-stage4/root/contract-crlf-review-green-01'
REPO=SESSION/'work/checkwash-ux'
receipt=json.loads((ROOT/'receipt.json').read_text())
manifest=json.loads((ROOT/'input-hashes.json').read_text())
stdout=(ROOT/'stdout.txt').read_text(encoding='utf-8')
assert receipt['exit_code']==0 and '56 passed in 149.04s' in stdout
assert set(receipt['changed_inputs'])=={'src/checkwash/engine.py','src/checkwash/oracle_credit.py'}
targets=['src/checkwash/contract.py','src/checkwash/gitio/git.py','tests/test_stage4_contract_crlf_review.py']
checks={name:dict(expected=manifest[name],actual=hashlib.sha256((REPO/name).read_bytes()).hexdigest()) for name in targets}
assert all(value['expected']==value['actual'] for value in checks.values())
out=dict(mode='READ_ONLY_INDEPENDENT_SOURCE_AND_RECEIPT_READBACK',status='PASS_NO_REMAINING_BLOCKER_IN_REVIEWED_SCOPE',
    marker=receipt['provenance'],hostname=receipt['host'],runtime=receipt['python'],exit_code=0,passed=56,
    covered_new_red_controls=7,target_files_match_green_input_manifest=checks,
    unrelated_changed_inputs=receipt['changed_inputs'],final_source_qualification=False,
    original_receipt_sha256=hashlib.sha256((ROOT/'receipt.json').read_bytes()).hexdigest(),
    original_stdout_sha256=hashlib.sha256((ROOT/'stdout.txt').read_bytes()).hexdigest())
(HERE/'root-contract-crlf-readback.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(passed=56,new_red_controls=7,reviewed_target_files_unchanged=True)))
