"""Run only the entry-gap controls against the preserved pre-D183 source snapshot."""
from datetime import datetime,timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import subprocess
import sys

HERE=Path(__file__).resolve().parent
SESSION=HERE.parents[2]
OUT=HERE/'pytest-context-baseline-red'
OUT.mkdir()
tmp=OUT/'tmp'
tmp.mkdir()
test=SESSION/'work/checkwash-ux/tests/test_worktree_pytest_config_context.py'
copy=OUT/'test_entry.py'
copy.write_bytes(test.read_bytes())
config=OUT/'pytest.ini'
config.write_text('[pytest]\n',encoding='utf-8',newline='\n')
SOURCE=HERE/'native/source/src'
spec=importlib.util.spec_from_file_location('trusted_environment',SESSION/'work/trusted/replay_pju_action.py')
trusted=importlib.util.module_from_spec(spec)
spec.loader.exec_module(trusted)
env=trusted.clean_environment(Path(sys.executable),Path(r'C:\Program Files\Git\cmd\git.exe'),Path(r'C:\Program Files\Git\bin\bash.exe'),tmp)
args=['-c',str(config),'-q','--junitxml',str(OUT/'junit.xml'),'--basetemp',str(OUT/'pytest-temp'),
      str(copy)+'::test_git_base_link_with_fake_worktree_link_cannot_silently_pass']
bootstrap=f'import sys;sys.path.insert(0,{str(SOURCE)!r});import pytest;raise SystemExit(pytest.main({args!r}))'
command=[sys.executable,'-I','-B','-X','utf8','-c',bootstrap]
start=datetime.now(timezone.utc).isoformat()
p=subprocess.run(command,cwd=OUT,env=env,stdin=subprocess.DEVNULL,capture_output=True,timeout=300)
(OUT/'stdout').write_bytes(p.stdout)
(OUT/'stderr').write_bytes(p.stderr)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
receipt=dict(marker='HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL',hostname=platform.node(),runtime=sys.version,
    source_kind='IMMUTABLE_PRE_D183_WORKING_TREE_SNAPSHOT_NOT_HEAD',
    source_manifest_sha256=sha(HERE/'native/working-tree-source.json'),source=str(SOURCE),
    test_source_sha256=sha(copy),command=command,begin=start,end=datetime.now(timezone.utc).isoformat(),
    exit_code=p.returncode,stdout_sha256=sha(OUT/'stdout'),stderr_sha256=sha(OUT/'stderr'),
    native_file_symlink_exercised=False,git_base_symlink_blob_exercised=True,fixture_programs_executed=False)
(OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n')
print(p.stdout.decode('utf-8','replace'))
print(json.dumps(dict(exit_code=p.returncode,receipt=str(OUT/'receipt.json'))))
raise SystemExit(p.returncode)
