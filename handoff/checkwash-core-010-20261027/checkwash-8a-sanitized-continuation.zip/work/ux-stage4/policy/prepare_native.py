"""Reuse the original 12 static controls with a frozen working-tree source snapshot."""
from pathlib import Path
import hashlib
import json

HERE=Path(__file__).resolve().parent
SESSION=HERE.parents[2]
old=SESSION/'work/ux-stage3/policy-shadow/run.py'
new=HERE/'native'
new.mkdir()
text=old.read_text(encoding='utf-8')
text=text.replace('SESSION = HERE.parents[2]', 'SESSION = Path('+repr(str(SESSION))+')')
text=text.replace("EXPECTED = '9a5a27f44c895ba2fdee8c83a6313baf0e120873'", "EXPECTED = '5f0af4b40cdc6ed2f20414c76dd748549de67109'")
start=text.index("assert git(REPO, 'rev-parse', 'HEAD').decode().strip() == EXPECTED")
end=text.index('source_before = source_hashes()',start)
replacement='''assert git(REPO, 'rev-parse', 'HEAD').decode().strip() == EXPECTED
status_begin = git(REPO, 'status', '--porcelain').decode()
def live_source():
    return {p.relative_to(REPO).as_posix(): p.read_bytes()
            for p in (REPO/'src').rglob('*') if p.is_file() and '__pycache__' not in p.parts
            and p.suffix not in ('.pyc', '.pyo')}
live_before = live_source()
for name, raw in live_before.items():
    p = SOURCE/name
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(raw)
assert live_source() == live_before, 'source changed while freezing; use a fresh native run folder'
save(HERE/'working-tree-source.json', {name: sha(raw) for name,raw in live_before.items()})
import io
buffer = io.BytesIO()
with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED) as z:
    for name, raw in sorted(live_before.items()):
        z.writestr(name, raw)
archive = buffer.getvalue()
(HERE/'source.zip').write_bytes(archive)
def source_hashes():
    files = {p.relative_to(SOURCE).as_posix():p.read_bytes() for p in (SOURCE/'src').rglob('*')
             if p.is_file() and '__pycache__' not in p.parts}
    assert files == live_before, 'frozen source snapshot changed'
    return {name:sha(raw) for name,raw in files.items()}

'''
text=text[:start]+replacement+text[end:]
text=text.replace("assert git(REPO, 'status', '--porcelain') == b''", "status_end = git(REPO, 'status', '--porcelain').decode()")
text=text.replace('source_sha=EXPECTED, source_archive_sha256=sha(archive),',
                  "source_kind='WORKING_TREE_SNAPSHOT_NOT_COMMITTED', head_reference=EXPECTED, source_sha=None, source_archive_sha256=sha(archive),")
text=text.replace('source_unchanged=True, product_clean=True, cli_calls=cli_count,',
                  'source_unchanged=True, shared_worktree_status_begin=status_begin, shared_worktree_status_end=status_end, cli_calls=cli_count,')
text=text.replace("assert git(REPO, 'rev-parse', 'HEAD').decode().strip() == EXPECTED\nstatus_end", "head_end = git(REPO, 'rev-parse', 'HEAD').decode().strip()\nstatus_end")
dest=new/'run.py'
dest.write_text(text,encoding='utf-8',newline='\n')
(new/'driver-provenance.json').write_text(json.dumps(dict(original_driver=str(old),
     original_raw_sha256=hashlib.sha256(old.read_bytes()).hexdigest(),
     adapted_driver_raw_sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),
     fixture_programs_executed=False,scope='same12cases24CLI_current_policy_regression'),indent=2)+'\n',encoding='utf-8',newline='\n')
print('same 12 controls prepared; frozen working-tree source, original receipt files untouched')
