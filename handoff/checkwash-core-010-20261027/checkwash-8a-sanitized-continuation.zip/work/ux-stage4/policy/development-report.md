# Stage 4 policy / D183 development evidence

HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL; LAPTOP-01AGNPJU; Python 3.11.9.

These are development checks against independently hashed working-tree bytes. HEAD references are provenance only; this report does not claim final-source qualification.

## Policy shadow / IR3 (D-177)

All three reviewed patches were applied after preserving the original mixed-EOL embedding document and all bundle-owned bytes. CLI/engine/gating/SPEC ownership was handed back to the coordinating agents. The policy and IR3 consumer core run exited 0; that early receipt has no JUnit count, so no test count is claimed.

The pinned native source replay covered 12 controls / 24 CLI observations, with fixture program execution disabled. Result: 6 pass, 18 block, 0 engine errors; 11 policy-review controls matched the adopted decision. Complete finding dictionaries were unchanged in 15 observations, changed in 9, and 6 verdicts moved. All seed and next-BASE findings/fingerprints remained equal. Old 24 CLI / 186-command evidence was read only; the new snapshot replay has 184 commands because source Git reads were replaced by the explicit source snapshot.

The wider adapters-r1 run was an interim failure: 17 failures among 1359 tests, including 15 oracle/corpus differences and 2 timeouts. Concurrent oracle sources changed. It is not accepted as a passing compatibility run; root/quality own the final resolution, and this agent changed no existing golden labels.

## Root contract / CRLF independent review

Seven new counterexample tests first failed: six malformed quote forms silently broadened scope, and repeated CRLF normalization caused quadratic decoding work. Root repaired the production code. Readback confirmed the exact reviewed contract/gitio/test bytes in root's 56-passed exit-0 receipt. Two unrelated oracle inputs changed during that run, so it is development validation rather than final-source qualification.

## Worktree / Stop pytest context (D-183)

Primary worktree analysis now pairs HEAD with regular working-tree config records. Managed session analysis builds a fresh pair against the recorded session base. Metadata resolves only the parent for the repository-boundary check and lstat checks the final component; final file-link targets are neither resolved nor read. The ordinary reader's admission rules remain in force. OIDs bind exact retained bytes in the repository's SHA1/SHA256 format, with revision=worktree and no committed/stored-object claim.

The preserved pre-D183 source failed both named CLI controls: JSON silently passed a logical link context and hook-json omitted NOT_ANALYSED. These use a real Git BASE symlink blob plus trusted fake after-link metadata, not a native Windows file symlink. Native regular pyproject selection narrowing has identical complete findings and exit between worktree and committed range.

A separate captured-diff control first failed when an API change path used raw backslashes. The changed-path guard now uses the engine's same lexical slash normalization. Independent review then reproduced a second consistency gap: a renamed old config could reappear outside the captured diff. The author controls recorded two failures (slash/backslash) and three passing controls before repair. The change set is now materialized once, explicit normalized after bytes are bound first, then rename old paths default to absence; explicit old-path changes win in either ordering. Single-use generators are covered.

The final necessary regression combines 27 owned controls with the 77 existing Git config controls; counts and the actual exit are in the table below. Earlier 22- and 96-test green runs remain preserved as intermediate evidence. Four managed session/Stop regression tests also passed without source drift. Independent controls reported by quality_fix separately cover both the rename edge and the original general boundaries; their report remains a distinct receipt.

| Receipt | Exit | Tests | Failed | Error | Skipped | Source drift |
|---|---:|---:|---:|---:|---:|---|
| core-r1 | 0 | not captured | - | - | - | [] |
| adapters-r1 | 1 | 1359 | 17 | 0 | 0 | ['src/checkwash/contract.py', 'src/checkwash/engine.py', 'src/checkwash/frontends/javascript/expected_provenance.py', 'src/checkwash/oracle_credit.py', 'tests/test_oracle_credit_context.py', 'tests/test_task_contract_validation.py'] |
| independent-review-r1 | 1 | 7 | 7 | 0 | 0 | [] |
| pytest-context-baseline-red | 1 | 2 | 2 | 0 | 0 | None |
| pytest-context-r1 | 0 | 15 | 0 | 0 | 0 | [] |
| pytest-context-r2 | 0 | 96 | 0 | 0 | 0 | ['src/checkwash/oracle_credit.py', 'tests/test_oracle_credit_context.py'] |
| pytest-context-r3 | 0 | 21 | 0 | 0 | 0 | [] |
| pytest-context-session | 0 | 4 | 0 | 0 | 0 | [] |
| pytest-context-consistency-red | 1 | 1 | 1 | 0 | 0 | [] |
| pytest-context-final | 0 | 22 | 0 | 0 | 0 | [] |
| pytest-context-rename-red | 1 | 5 | 2 | 0 | 0 | [] |
| pytest-context-rename-green | 0 | 104 | 0 | 0 | 0 | [] |

D183 stable raw source hashes:

- `src/checkwash/cli.py`: `bfc0c4ed84a07b4ca457a3da290998e7d6ad2ccad78aa4693f769b77cbcb0023`
- `src/checkwash/gitio/pytest_configs.py`: `ab3f4293dabc4f6131dcbdb4e5bddba6f43af64383c32400c9bf47fde8d201d7`
- `src/checkwash/gitio/snapshot.py`: `1262d04b8dc2bf5c27184425d4ecb38292e5c007a5609c563471fb66c31611e5`
- `tests/test_worktree_pytest_config_context.py`: `f13431d748bd20592f7d977480a4dd5b0592f0aa9084f146384dcb343f30fa77`

The SPEC/DECISIONS integration draft is D183-spec-draft.md. quality_fix's independent D183 review reports PASS_NO_REMAINING_BLOCKERS within its bounded scope: four general controls plus four rename controls passed, and all three source hashes match this summary. Its final read-only terminal receipt check independently verified the author's 104 passed (27+77), exit 0, no source drift, raw stream hashes and both source manifest hashes. The independent audit is work/ux-stage4/D183-independent-review/audit.json; its earlier pending report bytes remain preserved under author-terminal-readback/original.

## Limits

- Development receipts use working-tree bytes or a pinned working-tree source archive, not a sealed final HEAD.
- The adapters-r1 result is an interim failure, never a PASS; concurrent oracle sources changed and root owns resolution/final suite.
- Native Windows file symlink creation was unavailable (WinError 1314); D183 fake metadata controls and real Git BASE link blobs are distinct from native OS link coverage.
- The working-tree config cache is read-once, not an atomic filesystem snapshot; generic source admission remains unchanged.
- No existing golden/corpus labels were changed by this agent.
- No full suite or source/wheel/pyz qualification was performed by this agent.
- Analysed fixture programs were not executed; no pool, model, paid batch or host-global changes were used.

All detailed commands, clean-environment key names, source/input hashes, stdout/stderr and exits remain in the named raw receipt directories. This summary was derived without importing or executing product modules.
