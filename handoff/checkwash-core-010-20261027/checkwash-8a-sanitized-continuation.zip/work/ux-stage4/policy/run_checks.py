"""Record targeted working-tree pytest checks in a credential-free environment."""
from datetime import datetime,timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import subprocess
import sys

HERE=Path(__file__).resolve().parent
SESSION=HERE.parents[2]
REPO=SESSION/'work/checkwash-ux'
name=sys.argv[1]
targets=sys.argv[2:]
assert targets and name.replace('-','').isalnum()
OUT=HERE/name
OUT.mkdir()
tmp=OUT/'tmp'
tmp.mkdir()
spec=importlib.util.spec_from_file_location('trusted_environment',SESSION/'work/trusted/replay_pju_action.py')
trusted=importlib.util.module_from_spec(spec)
spec.loader.exec_module(trusted)
env=trusted.clean_environment(Path(sys.executable),Path(r'C:\Program Files\Git\cmd\git.exe'),Path(r'C:\Program Files\Git\bin\bash.exe'),tmp)
env['PYTHONPATH']=str(REPO/'src')
def sha(raw):return hashlib.sha256(raw).hexdigest()
def snapshot():
    paths=[p for folder in ('src','tools','tests') for p in (REPO/folder).rglob('*')
           if p.is_file() and p.suffix in ('.py','.gwcase','.json','.toml') and '__pycache__' not in p.parts]
    return {p.relative_to(REPO).as_posix():sha(p.read_bytes()) for p in paths}
before=snapshot()
(OUT/'source-before.json').write_text(json.dumps(before,indent=2)+'\n',encoding='utf-8',newline='\n')
command=[sys.executable,'-B','-X','utf8','-m','pytest','-q','--junitxml',str(OUT/'junit.xml'),'--basetemp',str(OUT/'pytest-temp'),*targets]
started=datetime.now(timezone.utc).isoformat()
p=subprocess.run(command,cwd=REPO,env=env,stdin=subprocess.DEVNULL,capture_output=True,timeout=900)
(OUT/'stdout').write_bytes(p.stdout)
(OUT/'stderr').write_bytes(p.stderr)
after=snapshot()
(OUT/'source-after.json').write_text(json.dumps(after,indent=2)+'\n',encoding='utf-8',newline='\n')
changed=[path for path in sorted(before.keys()|after.keys()) if before.get(path)!=after.get(path)]
head=subprocess.run([r'C:\Program Files\Git\cmd\git.exe','-C',str(REPO),'rev-parse','HEAD'],capture_output=True,check=True,env=env).stdout.decode().strip()
receipt=dict(marker='HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL',hostname=platform.node(),runtime=sys.version,
    executable=sys.executable,source_kind='WORKING_TREE_NOT_COMMITTED',head_reference=head,command=command,
    begin=started,end=datetime.now(timezone.utc).isoformat(),exit_code=p.returncode,
    stdout_sha256=sha(p.stdout),stderr_sha256=sha(p.stderr),source_changed_paths=changed,
    source_before_manifest_sha256=sha((OUT/'source-before.json').read_bytes()),
    source_after_manifest_sha256=sha((OUT/'source-after.json').read_bytes()),environment_keys=sorted(env))
(OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n')
print(p.stdout.decode('utf-8','replace'))
print(p.stderr.decode('utf-8','replace'))
print(json.dumps(dict(exit_code=p.returncode,changed_source_paths=changed,receipt=str(OUT/'receipt.json'))))
raise SystemExit(p.returncode)
