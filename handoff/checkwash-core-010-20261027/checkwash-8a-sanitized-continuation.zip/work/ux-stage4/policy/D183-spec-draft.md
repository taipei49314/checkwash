# D-183 integration text for root

Suggested SPEC insertion next to frozen pytest config evidence (§2/§2b):

From 0.10.0, worktree checks and the managed Stop's analyses supply paired
pytest config evidence too. The primary worktree verdict pairs the diff's HEAD
with working-tree sources. A session-commits note pairs the recorded session
base with working-tree sources using a new context; it does not reuse the
primary context or substitute the session's policy-loading base for the
primary diff's HEAD. Each context is prepared once per analysis.

Working-tree config evidence is a bounded read-once cache of regular sources,
not an atomic filesystem snapshot. Inventory/mode facts are retained for the
analysis; selected source presence/modes must remain consistent with that
inventory and bytes of changed controls must match the captured diff, using
the engine's same lexical slash spelling for changed-path matching. Rename
old paths are bound to captured absence unless another explicit change
in the complete captured change set supplies that old path's after bytes;
iterable changes are retained before the two passes so generators obey the
same rule. Explicit old-path changes take priority regardless of ordering. Config
records retain exact bytes and compute content OIDs in the repository's object
format, with revision `worktree`; that label makes no committed/stored-object
claim. Existing per-source, batch and paired evidence limits apply. Config
records/deltas remain internal to the two pytest-control consumers and do not
become general Python/provider source or new physical diff entries.

Git BASE/head config evidence retains its existing one-hop same-tree regular
target capability. Working-tree evidence preserves ordinary source admission:
it reads regular files only, never follows worktree file/directory symlink data,
and refuses outside-repository, nonregular, inconsistent or over-limit sources.
Metadata resolves only the parent for the repository-boundary check and uses
lstat on the final component, without resolving a final file-link target.
Recognized logical aliases are considered before relevance gates, so an
unavailable worktree alias is NOT_ANALYSED rather than silently ignored. The
regular-only worktree limit is deliberate; it does not claim the frozen Git
link capability also exists on the live filesystem. Engine errors remain exit2
in normal formats and the existing Stop systemMessage/no-decision behavior;
session-note failure preserves the primary verdict and reports unanalysed
session commits.

Suggested DECISIONS entry:

## D-183 (2026-10-27): pair worktree/Stop pytest config evidence without widening source admission

The pre-1.0 repair instruction includes this remaining reader-entry defect.
Range and sweep already supplied PairedPytestConfigs; worktree/Stop passed None,
allowing logical pytest config evidence to bypass the consumers' relevance
gates. The implementation adds metadata-only config mode queries and a read-once
strict regular worktree adapter, plus fresh pairs for the primary and session
legs. CLI TASK authority, generic source admission, selection/parser language,
detector severity and fingerprints are unchanged by this entry.

The preserved pre-D183 working-tree source snapshot reproduced the gap: with a
real Git BASE120000 blob and trusted fake after-link metadata (no host file
link), JSON returned0 and hook-json omitted the NOT_ANALYSED warning. The new
entry refuses before worktree link bytes/targets are read. Native regular
pyproject selection narrowing has identical complete findings and exit between
worktree and committed range. Additional tests cover exact SHA1/SHA256 content
identity, read-once bytes, missing/empty distinction, unsafe paths, mode/source
inventory drift, captured-diff mismatch and fresh session-base evidence.
Independent review also reproduced a rename-old-path gap with trusted fake
config sources: a deleted old config could reappear outside the captured diff.
Both slash spellings first failed the added author controls; the implementation
now binds rename absence while preserving explicit old-path after bytes and
single-use iterable inputs. Its follow-up regression receipt records the
executed outcome separately; these fake API controls do not claim native
filesystem race coverage.

All receipts identify PJU and exact working-tree/source snapshot hashes; they
are not final-source qualification. PJU native file-symlink testing is unavailable
(WinError1314); fake after-link controls and real Git link blobs do not establish
native OS link coverage. No host security settings were changed, and analysed
fixture programs were not executed. Existing golden/corpus labels remain intact.
The earlier policy/native records and all consumed grants remain historical.
