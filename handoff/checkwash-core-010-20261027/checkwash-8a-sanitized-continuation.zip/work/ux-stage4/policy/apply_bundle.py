"""Apply the human-authorized 0.10 policy bundle with raw source receipts."""
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import subprocess
import sys

BASE=Path(__file__).resolve().parent
HERE=BASE/'apply-r2'
HERE.mkdir()
SESSION=BASE.parents[2]
REPO=SESSION/'work/checkwash-ux'
PACKET=SESSION/'work/ux-stage3/policy-shadow'
EXPECTED_HEAD='5f0af4b40cdc6ed2f20414c76dd748549de67109'
PATCHES={'implementation.patch':'7ab91501aecaa05ed47a130d2f2d61cb27a96139a63ec1be49c138270385abdf',
         'protected-contract.patch':'8ad77c27e78122889a251af189a130f7f173292415868c1139d813fe5ed4e7ab',
         'consumer-migration.patch':'6f5458ecdfcf0651968e9fef16993faf1e26b6da2235364065c3e5656973958b'}
assert platform.node()=='LAPTOP-01AGNPJU'
assert not (HERE/'apply-receipt.json').exists()
(HERE/'apply-raw').mkdir()
(HERE/'before').mkdir()
tmp=HERE/'tmp-apply'
tmp.mkdir()
spec=importlib.util.spec_from_file_location('trusted_environment',SESSION/'work/trusted/replay_pju_action.py')
trusted=importlib.util.module_from_spec(spec)
spec.loader.exec_module(trusted)
GIT=Path(r'C:\Program Files\Git\cmd\git.exe')
env=trusted.clean_environment(Path(sys.executable),GIT,Path(r'C:\Program Files\Git\bin\bash.exe'),tmp)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def save(path,data):path.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8',newline='\n')
ledger=[]
def git(name,*args):
    argv=[str(GIT),'-c','core.hooksPath=NUL','-C',str(REPO),*map(str,args)]
    start=datetime.now(timezone.utc).isoformat()
    p=subprocess.run(argv,cwd=HERE,env=env,stdin=subprocess.DEVNULL,capture_output=True,timeout=60)
    (HERE/'apply-raw'/(name+'.stdout')).write_bytes(p.stdout)
    (HERE/'apply-raw'/(name+'.stderr')).write_bytes(p.stderr)
    ledger.append(dict(command=argv,begin=start,end=datetime.now(timezone.utc).isoformat(),exit=p.returncode,
                       stdout_sha256=sha(p.stdout),stderr_sha256=sha(p.stderr)))
    save(HERE/'apply-commands.json',ledger)
    assert p.returncode==0,(name,p.stderr.decode('utf-8','replace'))
    return p.stdout
assert git('head','rev-parse','HEAD').decode().strip()==EXPECTED_HEAD
status_before=git('status-before','status','--porcelain')
paths=set()
for name,digest in PATCHES.items():
    raw=(PACKET/name).read_bytes()
    assert sha(raw)==digest,(name,'patch hash mismatch')
    paths.update(line[6:] for line in raw.decode().splitlines() if line.startswith('+++ b/'))
assert git('owned-paths-before','diff','--name-only','--',*sorted(paths))==b'', 'owned bundle paths changed before handoff'
before={}
for name in sorted(paths):
    path=REPO/name
    if path.exists():
        raw=path.read_bytes()
        dest=HERE/'before'/name
        dest.parent.mkdir(parents=True,exist_ok=True)
        dest.write_bytes(raw)
        before[name]=dict(sha256=sha(raw),size=len(raw),crlf=raw.count(b'\r\n'),lf=raw.count(b'\n'))
    else:before[name]=None
save(HERE/'before-files.json',before)
# Preserve mixed-EOL worktree bytes before using the precise source blob.
embedding=git('embedding-git-blob','show',EXPECTED_HEAD+':docs/embedding.md')
(HERE/'before/docs/embedding.git-blob.md').write_bytes(embedding)
(REPO/'docs/embedding.md').write_bytes(embedding)
for name in PATCHES:
    git(name+'-check','apply','--check','--whitespace=nowarn',PACKET/name)
    git(name+'-apply','apply','--whitespace=nowarn',PACKET/name)
after={name:sha((REPO/name).read_bytes()) for name in sorted(paths)}
status_after=git('status-after','status','--porcelain').decode()
save(HERE/'apply-receipt.json',dict(marker='HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL',
     hostname=platform.node(),runtime=sys.version,executable=sys.executable,head_before=EXPECTED_HEAD,
     analyzed_source='WORKING_TREE_NOT_COMMITTED',patches=PATCHES,before=before,after=after,
     status_after=status_after,fixture_programs_executed=False,commands=ledger,
     finished=datetime.now(timezone.utc).isoformat()))
print(json.dumps(dict(applied=True,files=len(paths),analyzed_source='WORKING_TREE_NOT_COMMITTED',
     handoff_hashes={name:after[name] for name in ('src/checkwash/cli.py','src/checkwash/engine.py',
     'src/checkwash/gating.py','src/checkwash/ir/model.py')})))
