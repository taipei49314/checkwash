"""Derive development evidence metadata from existing receipts; no product imports."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import platform
import shutil
import socket
import xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1] / "checkwash-ux"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def observed(label):
    folder = HERE / label
    receipt = json.loads((folder / "receipt.json").read_text(encoding="utf-8"))
    result = {"receipt": str(folder / "receipt.json"), "receipt_sha256": sha(folder / "receipt.json"),
              "exit_code": receipt["exit_code"], "source_kind": receipt["source_kind"],
              "source_changed_paths": receipt.get("source_changed_paths"),
              "command": receipt["command"], "hostname": receipt["hostname"],
              "runtime": receipt["runtime"]}
    junit = folder / "junit.xml"
    if junit.exists():
        suites = ET.fromstring(junit.read_bytes()).findall("testsuite")
        result["junit"] = {name: sum(int(suite.get(name, "0")) for suite in suites)
                           for name in ("tests", "failures", "errors", "skipped")}
        result["junit"]["passed"] = (result["junit"]["tests"] - result["junit"]["failures"]
                                         - result["junit"]["errors"] - result["junit"]["skipped"])
        result["junit_sha256"] = sha(junit)
    else:
        result["junit"] = None
        result["count_note"] = "No JUnit or summary count captured; exit code only."
    return result


labels = ("core-r1", "adapters-r1", "independent-review-r1", "pytest-context-baseline-red",
          "pytest-context-r1", "pytest-context-r2", "pytest-context-r3",
          "pytest-context-session", "pytest-context-consistency-red", "pytest-context-final",
          "pytest-context-rename-red", "pytest-context-rename-green")
checks = {label: observed(label) for label in labels}
native = json.loads((HERE / "native/comparison.json").read_text(encoding="utf-8"))
review = json.loads((HERE / "root-contract-crlf-readback.json").read_text(encoding="utf-8"))
owned = ("src/checkwash/cli.py", "src/checkwash/gitio/pytest_configs.py",
         "src/checkwash/gitio/snapshot.py", "tests/test_worktree_pytest_config_context.py")
hashes = {path: sha(REPO / path) for path in owned}
independent_path = HERE.parent / "D183-independent-review" / "audit.json"
independent = json.loads(independent_path.read_text(encoding="utf-8"))
assert independent["review_state"] == "PASS_NO_REMAINING_BLOCKERS"
assert independent["final_reviewed_source_hashes"] == {path: hashes[path] for path in owned[:3]}
history = HERE / "development-revisions" / "pre-rename-oldpath-fix"
if not history.exists():
    history.mkdir(parents=True)
    preserved = {}
    for name in ("development-summary.json", "development-report.md"):
        original = HERE / name
        if original.exists():
            shutil.copyfile(original, history / name)
            preserved[name] = sha(original)
    (history / "sha256.json").write_text(json.dumps(preserved, indent=2) + "\n", encoding="utf-8")
summary = {
    "marker": "HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL",
    "mode": "READ_ONLY_EXISTING_RECEIPT_SUMMARY_NO_PRODUCT_IMPORT",
    "hostname": socket.gethostname(), "runtime": platform.python_version(),
    "source_kind": "WORKING_TREE_NOT_COMMITTED_SOURCE_BYTES_IDENTIFIED",
    "d183_final_owned_sha256": hashes,
    "checks": checks,
    "policy_native": {key: native[key] for key in (
        "source_kind", "head_reference", "source_archive_sha256", "frozen_source_manifest_sha256",
        "cases", "actual_cli_calls", "expected_policy_review_controls_checked",
        "complete_findings_equal", "changed_finding_observations", "changed_verdict_observations",
        "before_passes", "after_passes", "after_blocks", "engine_errors", "native_command_count",
        "original_native_command_count", "original_fixture_definitions_unchanged", "fixture_programs_executed")},
    "policy_native_comparison_sha256": sha(HERE / "native/comparison.json"),
    "independent_contract_crlf_review": review,
    "limitations": [
        "Development receipts use working-tree bytes or a pinned working-tree source archive, not a sealed final HEAD.",
        "The adapters-r1 result is an interim failure, never a PASS; concurrent oracle sources changed and root owns resolution/final suite.",
        "Native Windows file symlink creation was unavailable (WinError 1314); D183 fake metadata controls and real Git BASE link blobs are distinct from native OS link coverage.",
        "The working-tree config cache is read-once, not an atomic filesystem snapshot; generic source admission remains unchanged.",
        "No existing golden/corpus labels were changed by this agent.",
        "No full suite or source/wheel/pyz qualification was performed by this agent.",
        "Analysed fixture programs were not executed; no pool, model, paid batch or host-global changes were used.",
    ],
    "d183_spec_draft_sha256": sha(HERE / "D183-spec-draft.md"),
    "independent_d183_review": {"audit": str(independent_path), "audit_sha256": sha(independent_path),
                               "status": independent["review_state"], "scope": independent["scope"],
                               "observations": independent["final_independent_observations"],
                               "source_hashes_match_current": True,
                               "author_terminal_readback": independent["author_terminal_readback"],
                               "author_regression_is_a_separate_receipt": True},
}
(HERE / "development-summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

lines = ["# Stage 4 policy / D183 development evidence", "",
         "HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL; LAPTOP-01AGNPJU; Python 3.11.9.", "",
         "These are development checks against independently hashed working-tree bytes. HEAD references are provenance only; this report does not claim final-source qualification.", "",
         "## Policy shadow / IR3 (D-177)", "",
         "All three reviewed patches were applied after preserving the original mixed-EOL embedding document and all bundle-owned bytes. CLI/engine/gating/SPEC ownership was handed back to the coordinating agents. The policy and IR3 consumer core run exited 0; that early receipt has no JUnit count, so no test count is claimed.", "",
         "The pinned native source replay covered 12 controls / 24 CLI observations, with fixture program execution disabled. Result: 6 pass, 18 block, 0 engine errors; 11 policy-review controls matched the adopted decision. Complete finding dictionaries were unchanged in 15 observations, changed in 9, and 6 verdicts moved. All seed and next-BASE findings/fingerprints remained equal. Old 24 CLI / 186-command evidence was read only; the new snapshot replay has 184 commands because source Git reads were replaced by the explicit source snapshot.", "",
         "The wider adapters-r1 run was an interim failure: 17 failures among 1359 tests, including 15 oracle/corpus differences and 2 timeouts. Concurrent oracle sources changed. It is not accepted as a passing compatibility run; root/quality own the final resolution, and this agent changed no existing golden labels.", "",
         "## Root contract / CRLF independent review", "",
         "Seven new counterexample tests first failed: six malformed quote forms silently broadened scope, and repeated CRLF normalization caused quadratic decoding work. Root repaired the production code. Readback confirmed the exact reviewed contract/gitio/test bytes in root's 56-passed exit-0 receipt. Two unrelated oracle inputs changed during that run, so it is development validation rather than final-source qualification.", "",
         "## Worktree / Stop pytest context (D-183)", "",
         "Primary worktree analysis now pairs HEAD with regular working-tree config records. Managed session analysis builds a fresh pair against the recorded session base. Metadata resolves only the parent for the repository-boundary check and lstat checks the final component; final file-link targets are neither resolved nor read. The ordinary reader's admission rules remain in force. OIDs bind exact retained bytes in the repository's SHA1/SHA256 format, with revision=worktree and no committed/stored-object claim.", "",
         "The preserved pre-D183 source failed both named CLI controls: JSON silently passed a logical link context and hook-json omitted NOT_ANALYSED. These use a real Git BASE symlink blob plus trusted fake after-link metadata, not a native Windows file symlink. Native regular pyproject selection narrowing has identical complete findings and exit between worktree and committed range.", "",
         "A separate captured-diff control first failed when an API change path used raw backslashes. The changed-path guard now uses the engine's same lexical slash normalization. Independent review then reproduced a second consistency gap: a renamed old config could reappear outside the captured diff. The author controls recorded two failures (slash/backslash) and three passing controls before repair. The change set is now materialized once, explicit normalized after bytes are bound first, then rename old paths default to absence; explicit old-path changes win in either ordering. Single-use generators are covered.", "",
         "The final necessary regression combines 27 owned controls with the 77 existing Git config controls; counts and the actual exit are in the table below. Earlier 22- and 96-test green runs remain preserved as intermediate evidence. Four managed session/Stop regression tests also passed without source drift. Independent controls reported by quality_fix separately cover both the rename edge and the original general boundaries; their report remains a distinct receipt.", "",
         "| Receipt | Exit | Tests | Failed | Error | Skipped | Source drift |",
         "|---|---:|---:|---:|---:|---:|---|"
]
for label in labels:
    value = checks[label]
    counts = value["junit"] or {}
    lines.append(f"| {label} | {value['exit_code']} | {counts.get('tests', 'not captured')} | {counts.get('failures', '-')} | {counts.get('errors', '-')} | {counts.get('skipped', '-')} | {value['source_changed_paths']} |")
lines += ["", "D183 stable raw source hashes:", ""]
lines += [f"- `{path}`: `{digest}`" for path, digest in hashes.items()]
lines += ["", "The SPEC/DECISIONS integration draft is D183-spec-draft.md. quality_fix's independent D183 review reports PASS_NO_REMAINING_BLOCKERS within its bounded scope: four general controls plus four rename controls passed, and all three source hashes match this summary. Its final read-only terminal receipt check independently verified the author's 104 passed (27+77), exit 0, no source drift, raw stream hashes and both source manifest hashes. The independent audit is work/ux-stage4/D183-independent-review/audit.json; its earlier pending report bytes remain preserved under author-terminal-readback/original.", "",
          "## Limits", ""]
lines += [f"- {item}" for item in summary["limitations"]]
lines += ["", "All detailed commands, clean-environment key names, source/input hashes, stdout/stderr and exits remain in the named raw receipt directories. This summary was derived without importing or executing product modules.", ""]
(HERE / "development-report.md").write_text("\n".join(lines), encoding="utf-8")
print(json.dumps({"derived_summary": str(HERE / "development-summary.json"),
                  "derived_report": str(HERE / "development-report.md"),
                  "d183_final_regression": checks["pytest-context-rename-green"]["junit"],
                  "owned_source_sha256": hashes}, indent=2))
