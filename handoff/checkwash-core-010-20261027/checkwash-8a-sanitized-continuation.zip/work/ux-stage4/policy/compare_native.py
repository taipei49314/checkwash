"""Compare actual native working-tree snapshot output with preserved 0.9.1 observations."""
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
SESSION=HERE.parents[2]
OLD=SESSION/'work/ux-stage3/policy-shadow'
NEW=HERE/'native'
def read(path):return json.loads(path.read_text(encoding='utf-8'))
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
before=read(OLD/'observations.json')
after=read(NEW/'observations.json')
receipt=read(NEW/'receipt.json')
assert len(before)==len(after)==24 and receipt['cli_calls']==24 and receipt['source_unchanged']
assert receipt['source_kind']=='WORKING_TREE_SNAPSHOT_NOT_COMMITTED' and receipt['source_sha'] is None
assert not receipt['fixture_programs_executed']
assert read(OLD/'case-definitions.json')==read(NEW/'case-definitions.json'), 'native fixture definitions or real seed keys drifted'
expected={
 '01-strict-to-loose':(['GUARDRAIL_TOUCHED'],['critical'],'block'),
 '02-equivalent-migration':(['GUARDRAIL_TOUCHED'],['warn'],'pass'),
 '03-tightened-migration':(['GUARDRAIL_TOUCHED'],['warn'],'pass'),
 '04-fresh-relaxation':(['GUARDRAIL_TOUCHED'],['critical'],'block'),
 '05-empty-base':(['GUARDRAIL_TOUCHED'],['warn'],'pass'),
 '06-inactive-lower-config':(['GUARDRAIL_TOUCHED'],['critical'],'block'),
 '07-config-independent-allow':(['GUARDRAIL_TOUCHED'],['critical'],'block'),
 '08-equivalent-allow':([],[],'pass'),
 '09-replaced-allow':(['GUARDRAIL_TOUCHED'],['critical'],'block'),
 '10-empty-allow':(['GUARDRAIL_TOUCHED'],['critical'],'block'),
 '11-allow-independent-config':(['EXEMPTION_ADDED'],['warn'],'pass'),
}
rows=[]
for old,new in zip(before,after):
    assert (old['case'],old['phase'])==(new['case'],new['phase'])
    a,b=old['payload'],new['payload']
    assert b['checkwash_findings_version']==2 and b['run']['checkwash_version']=='0.10.0'
    assert b['config_errors']==b['skipped_files']==[]
    assert new['exit']==(0 if b['verdict']=='pass' else 1)
    if new['phase']=='policy-review':
        rules,severities,verdict=expected[new['case']]
        assert [f['rule'] for f in b['findings']]==rules,new['case']
        assert [f['severity'] for f in b['findings']]==severities,new['case']
        assert b['verdict']==verdict,new['case']
    else:
        assert a['findings']==b['findings'] and a['verdict']==b['verdict'] and old['exit']==new['exit'],new['case']
    if new['case'] in ('04-fresh-relaxation','06-inactive-lower-config'):
        assert a['findings']==b['findings'],new['case']
    rows.append(dict(case=new['case'],phase=new['phase'],before_exit=old['exit'],after_exit=new['exit'],
        before_verdict=a['verdict'],after_verdict=b['verdict'],
        complete_finding_dicts_equal=a['findings']==b['findings'],before_findings=a['findings'],after_findings=b['findings']))
old_last=next(r for r in before if r['case']=='11-allow-independent-config' and r['phase']=='policy-review')
new_last=next(r for r in after if r['case']=='11-allow-independent-config' and r['phase']=='policy-review')
assert new_last['payload']['findings'][0] in old_last['payload']['findings'], 'true suffix addition identity changed'
summary=dict(marker='HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL',source_kind=receipt['source_kind'],
    head_reference=receipt['head_reference'],source_archive_sha256=receipt['source_archive_sha256'],
    frozen_source_manifest_sha256=sha(NEW/'working-tree-source.json'),cases=12,actual_cli_calls=24,
    expected_policy_review_controls_checked=11,complete_findings_equal=sum(r['complete_finding_dicts_equal'] for r in rows),
    changed_finding_observations=sum(not r['complete_finding_dicts_equal'] for r in rows),
    changed_verdict_observations=sum(r['before_verdict']!=r['after_verdict'] for r in rows),
    before_passes=sum(r['exit']==0 for r in before),after_passes=sum(r['exit']==0 for r in after),
    after_blocks=sum(r['exit']==1 for r in after),engine_errors=0,
    original_observations_sha256=sha(OLD/'observations.json'),actual_observations_sha256=sha(NEW/'observations.json'),
    native_command_count=len(read(NEW/'journal.json')),original_native_command_count=len(read(OLD/'journal.json')),
    original_fixture_definitions_unchanged=True,fixture_programs_executed=False,
    source_wheel_pyz_qualification='NOT_RUN',full_suite='NOT_RUN_BY_THIS_AGENT',comparisons=rows)
(NEW/'comparison.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({k:v for k,v in summary.items() if k!='comparisons'},indent=2))
