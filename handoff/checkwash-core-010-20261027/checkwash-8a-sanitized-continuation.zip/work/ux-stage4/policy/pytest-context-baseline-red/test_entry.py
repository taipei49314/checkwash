"""Worktree pytest evidence uses strict regular reads and fresh analysis contexts."""
import hashlib
import json
import subprocess

import pytest

from checkwash.change import EngineError, FileChange
from checkwash.cli import main
from checkwash.gitio import snapshot as snapshots


class BaseIdentity:
    def __init__(self, width=40):
        self.width = width

    def _rev(self):
        return "0" * self.width


class RegularSource:
    def __init__(self, files):
        self.files = dict(files)
        self.modes = {path: b"100644" for path in files}
        self.reads = []

    def list_paths(self):
        return sorted(self.files)

    def config_modes(self, paths):
        return {path: self.modes.get(path) for path in paths}

    def read_many(self, paths):
        self.reads.append(tuple(paths))
        return {path: self.files.get(path) for path in paths}


def view(source, changes=(), width=40):
    from checkwash.gitio.pytest_configs import WorktreePytestConfigs

    return WorktreePytestConfigs(source, BaseIdentity(width), changes)


def test_regular_config_context_retains_one_read_and_truthful_content_identity():
    data = b"[pytest]\naddopts=-k keep\n"
    source = RegularSource({"pytest.ini": data})
    context = view(source)
    first = context.read_config_many(["pytest.ini"])["pytest.ini"]
    source.files["pytest.ini"] = b"changed after captured read"
    assert context.read_config_many(["pytest.ini"])["pytest.ini"] is first
    assert source.reads == [("pytest.ini",)]
    assert first.data == data and first.revision == "worktree"
    assert first.path == first.target_path == "pytest.ini"
    assert first.mode == first.target_mode == b"100644" and first.link_bytes == 0
    assert first.oid == first.target_oid == hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest().encode()


def test_sha256_repository_identity_is_not_falsely_reported_as_sha1():
    data = b"[pytest]\n"
    record = view(RegularSource({"pytest.ini": data}), width=64).read_config_many(["pytest.ini"])["pytest.ini"]
    assert record.target_oid == hashlib.sha256(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest().encode()


@pytest.mark.parametrize("mode", [b"120000", b"040000", b"nonregular"])
def test_worktree_context_never_opens_nonregular_or_link_target(mode):
    source = RegularSource({"pytest.ini": b"an untrusted link would point elsewhere"})
    source.modes["pytest.ini"] = mode
    with pytest.raises(EngineError, match="not a regular source"):
        view(source).read_config_many(["pytest.ini"])
    assert source.reads == []


def test_worktree_context_refuses_data_different_from_captured_diff():
    source = RegularSource({"pytest.ini": b"new bytes during analysis"})
    changes = [FileChange(path="pytest.ini", status="modified", before=b"old", after=b"captured head")]
    with pytest.raises(EngineError, match="differs from captured diff"):
        view(source, changes).read_config_many(["pytest.ini"])


def test_worktree_context_keeps_absence_distinct_from_empty_regular_source():
    source = RegularSource({"pytest.ini": b""})
    result = view(source).read_config_many(["pytest.ini", "pyproject.toml"])
    assert result["pytest.ini"].data == b"" and result["pyproject.toml"] is None


@pytest.mark.parametrize("path", ["../pytest.ini", "/pytest.ini", "C:/pytest.ini", "dir/../pytest.ini", "dir\n/pytest.ini"])
def test_native_metadata_api_rejects_unsafe_names_before_file_reads(tmp_path, path):
    source = snapshots.WorkingTreeSnapshot(tmp_path)
    with pytest.raises(EngineError, match="unsafe path"):
        source.config_modes([path])


def git(repo, *args, data=None):
    result = subprocess.run(["git", "-C", str(repo), *args], input=data, capture_output=True, timeout=30)
    assert result.returncode == 0, result.stderr.decode("utf-8", "replace")
    return result.stdout


def initialize(repo):
    git(repo, "init", "-b", "main")
    git(repo, "config", "user.name", "pytest config context")
    git(repo, "config", "user.email", "context@example.invalid")
    git(repo, "config", "commit.gpgsign", "false")
    git(repo, "config", "core.autocrlf", "false")


@pytest.mark.parametrize("format", ["json", "hook-json"])
def test_git_base_link_with_fake_worktree_link_cannot_silently_pass(tmp_path, monkeypatch, capsys, format):
    # PJU cannot create native file links (WinError1314). Git stores the real
    # BASE120000 blob; the trusted fake supplies only after-side link metadata.
    # Neither the fake nor the reader follows a target through a worktree link.
    from checkwash import cli

    initialize(tmp_path)
    git(tmp_path, "config", "core.symlinks", "false")
    target = tmp_path / "settings" / "current.txt"
    target.parent.mkdir()
    target.write_bytes(b"[pytest]\naddopts=\n")
    link = b"settings/current.txt"
    (tmp_path / "pytest.ini").write_bytes(link)
    tests = tmp_path / "tests"
    tests.mkdir()
    (tests / "test_keep.py").write_bytes(b"def test_keep():\n    assert api() == 1\n")
    git(tmp_path, "add", "-A")
    oid = git(tmp_path, "hash-object", "-w", "--stdin", data=link).decode().strip()
    git(tmp_path, "update-index", "--cacheinfo", f"120000,{oid},pytest.ini")
    git(tmp_path, "commit", "-m", "base with frozen config link")
    base = git(tmp_path, "rev-parse", "HEAD").decode().strip()
    old = snapshots.GitSnapshot(tmp_path, base).read_config_many(["pytest.ini"])["pytest.ini"]
    assert old.mode == b"120000" and old.data == b"[pytest]\naddopts=\n"
    target.write_bytes(b"[pytest]\naddopts=-k keep\n")
    original = snapshots.WorkingTreeSnapshot

    class FakeLinkSnapshot(original):
        def config_modes(self, paths):
            modes = super().config_modes(paths)
            if "pytest.ini" in modes:
                modes["pytest.ini"] = b"120000"
            return modes

        def read_many(self, paths):
            assert "pytest.ini" not in paths, "worktree link must be refused before data reads"
            return super().read_many(paths)

    monkeypatch.setattr(cli, "WorkingTreeSnapshot", FakeLinkSnapshot)
    code = main(["check", "--repo", str(tmp_path), "--format", format])
    output = capsys.readouterr()
    if format == "json":
        assert code == 2 and output.out == ""
        assert "worktree pytest config is not a regular source" in output.err
    else:
        payload = json.loads(output.out)
        assert code == 0 and "decision" not in payload
        assert "not analysed" in payload["systemMessage"]


def test_native_regular_pyproject_context_matches_committed_range(tmp_path, capsys):
    initialize(tmp_path)
    (tmp_path / "pyproject.toml").write_bytes(b'[tool.pytest.ini_options]\naddopts=""\n')
    (tmp_path / "test_keep.py").write_bytes(b"def test_keep():\n    assert api() == 1\n")
    (tmp_path / "test_drop.py").write_bytes(b"def test_drop():\n    assert api() == 2\n")
    git(tmp_path, "add", "-A")
    git(tmp_path, "commit", "-m", "base")
    base = git(tmp_path, "rev-parse", "HEAD").decode().strip()
    (tmp_path / "pyproject.toml").write_bytes(b'[tool.pytest.ini_options]\naddopts="-k keep"\n')
    code = main(["check", "--repo", str(tmp_path), "--format", "json"])
    worktree = json.loads(capsys.readouterr().out)
    git(tmp_path, "add", "-A")
    git(tmp_path, "commit", "-m", "narrow collection")
    other = main(["check", f"{base}..HEAD", "--repo", str(tmp_path), "--format", "json"])
    committed = json.loads(capsys.readouterr().out)
    assert code == other == 1
    assert worktree["findings"] == committed["findings"]
    assert worktree["config_errors"] == committed["config_errors"] == []
    assert any(f["rule"] == "CI_WORKFLOW_TOUCHED" and f["severity"] == "high" for f in worktree["findings"])
