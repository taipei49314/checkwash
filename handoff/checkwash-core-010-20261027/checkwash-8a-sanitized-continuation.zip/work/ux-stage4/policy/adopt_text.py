"""Adopt only D-177's authorized policy text, preserving surrounding decisions."""
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
REPO=HERE.parents[2]/'work/checkwash-ux'
changes={}
def read(name):
    text=(REPO/name).read_text(encoding='utf-8')
    changes[name]=[text,text]
    return text
spec=read('SPEC.md')
old_header='Spec version: 3 (proposed next minor: IR payload `version: 3` with required `globals.policy_shadows`; findings envelope `checkwash_findings_version: 2` retained from v0.3.0). Historical IR2 payloads remain IR2 and carry no newly inferred shadow proof.'
new_header='Spec version: 3 (IR payload `version: 3` with required `globals.policy_shadows`, introduced by the 0.10.0 policy-shadow contract D-177; findings envelope `checkwash_findings_version: 2` retained from v0.3.0). Historical IR2 payloads remain IR2 and carry no newly inferred shadow proof.'
assert spec.count(old_header)==1
spec=spec.replace(old_header,new_header)
spec=spec.replace('Next-minor policy-shadow exception:', 'Since 0.10.0, the D-177 policy-shadow exception:')
start=spec.index('### Policy-shadow transitions (next minor, proposed)')
end=spec.index('`.greenwash/allow.toml`, per-fingerprint only (never per-rule):',start)
section='''### Policy-shadow transitions (0.10.0, D-177)

Existing guardrail edits remain critical, except for the append-only ledger
case below. When no effective BASE predecessor exists, the existing fresh-file
defaults comparison remains in force. Inactive lower-priority creations keep
their existing treatment. A newly created `.checkwash/config.toml` that becomes
selected over an existing BASE `.greenwash/config.toml` compares with that
effective BASE config, including an existing zero-byte file; absence is None.

- A new disabled-rule name, a rise in the `fail_on` severity threshold, or
  `on_engine_error: block` becoming `pass_with_warning` makes the new config
  critical.
- If both policies parse without warnings, their role tables are equal, the
  new disable set is a subset of the old one, its threshold does not rise and
  its engine-error policy does not weaken, the created config stays warn.
  Equal-policy copies and this bounded tightening are included; arbitrary
  glob-language inclusion is not inferred.
- Parse errors, value warnings or differing role tables make the transition
  uncomparable and critical. This is a conservative maintenance cost, not a
  proof of malicious intent. Existing loader exceptions remain engine errors.
- Config and allow precedence remain independent by filename. Evaluation
  uses selected BASE policy throughout the reviewed diff.

A newly created `.checkwash/allow.toml` selected over an existing BASE
`.greenwash/allow.toml` uses the effective BASE ledger for the existing parsed
entry prefix comparison. An equal ledger adds no entries. A preserved prefix
followed by new records emits EXEMPTION_ADDED only for that suffix. Rewriting
or removing an existing record, including an empty priority file hiding a
nonempty BASE ledger, is GUARDRAIL_TOUCHED critical even though the priority
file is new. Revocation therefore retains its protected maintenance cost even
when it tightens the gate. The parser's existing ignored-record behavior is
unchanged.

Shadow GUARDRAIL_TOUCHED fingerprints keep their content-bound v2 outer form
and additionally bind the selected BASE policy's fixed repository-relative
path, complete raw-byte SHA256 and bounded transition kind. Physical before
and after identity remains bound. Exact keys move; old approvals require
review and are not automatically translated. EXEMPTION_ADDED keeps its key
formula for actual suffix additions; duplicate visibility for migrated records
disappears.

IR3 requires `globals.policy_shadows` in every payload, including an empty map
when none is reported. Each entry has exactly `base_path`, `base_sha256` and
`kind`; no policy values or arbitrary paths are copied. This required proof
slot is why IR_VERSION is 3; an omitted slot is not proof of no shadow. Old IR2
documents remain IR2 without inferred proof. FINDINGS_VERSION remains 2, as
does its envelope/object field set. Exit meanings remain 0 pass, 1 block and
2 engine error.

CLI and sweep pass selected BASE path/raw bytes they already read, without a
new HEAD authority read or widened source admission. Direct build_ir/analyze
callers creating a priority policy file need PolicyBase provenance for that
filename, including known absence where applicable. Missing relevant proof
refuses with EngineError. Closed .gwcase adapters use explicit before policy
bytes; after-only means absent at BASE. HEAD-only or slash-alias-ambiguous
context remains unknown by filename through known_names and refuses only when
that filename's new priority creation needs it. An unrelated unknown allow
context does not refuse config creation or a test-only change, and vice versa.
The engine's lexical backslash-to-slash spelling applies before membership,
filename and suffix comparisons and to policy mapping/case keys. No case-fold,
dot resolution, realpath or filesystem authority is added. case_snapshot is
AFTER content and never supplies BASE authority. Golden/demo callers still
pass allow_entries=[]; fixture ledger bytes never activate exemptions.

This contract does not change directory precedence, existing-file/Git-rename
policy, copy-plus-delete maintenance, arbitrary role-glob ordering, HEAD-only
exemption authority, the historical single exemption_ledger_path attribution,
BASE roles already excluding guardrails, reader admission or hook error rules.
The implementation was authorized under Nelson's 2026-10-27 pre-1.0 repair
instruction. Version metadata and this contract are not release qualification
or publication evidence; stop for Nelson's decision before 1.0.

'''
changes['SPEC.md'][1]=spec[:start]+section+spec[end:]
decisions=read('DECISIONS.md')
start=decisions.index('# INERT HUMAN DECISION DRAFT — D-number unassigned')
tail='Nothing in this draft lifts the publication pause or authorizes any of those unrun stages.'
end=decisions.index(tail,start)+len(tail)
entry='''## D-177 (2026-10-27): compare newly winning policy files with effective BASE policy

Nelson instructed this repair continuation: 「我覺得可以一次做完吧 可以推版號 但到1.0版前要停下問我」.
Under that instruction this named defect, its necessary protected contract
and consumer migrations are implemented for the 0.10.0 working-tree candidate.
The pre-1.0 scope supersedes the earlier UX-only/inert boundary; 1.0 still
requires Nelson's decision. It does not rewrite old v0.9.1 tags or failed,
partial and consumed receipts, nor waive validation or publication gates.

Previously, per-filename config/allow lookup already selected `.checkwash/`
over `.greenwash/`, but guardrail classification compared a new physical path
with its own absence. Defaults comparison missed a legacy block-on-parse-error
policy shadowed by a pass-with-warning priority config; it also blocked equal
or tighter copies of already-disabled policies. New priority ledgers were
compared with an empty ledger even when they displaced an effective legacy
ledger. The earlier source-bound PJU observations and inert packet remain
historical evidence, not validation of this implementation.

The adopted §6 rule compares only a newly winning priority creation with its
existing selected legacy BASE predecessor. Equal roles, a subset disable set,
no threshold rise and no engine-error weakening establish nonweakening. Other
recognized relaxation or an uncomparable policy stays critical. Effective
ledger prefix additions retain EXEMPTION_ADDED for the true suffix; equality
adds nothing, and rewrite/revocation stays critical. Authority during the
reviewed diff still comes from BASE, with config and allow selected separately.

Selected BASE provenance is explicit and content-bound. The engine's lexical
slash normalization applies before policy classification and to mapping/case
keys. Ambiguous or HEAD-only context stays unknown per filename, with refusal
only when its new priority creation needs that proof; unrelated cases retain
their admission. No HEAD ledger becomes an active fixture exemption.

This changes frozen policy interpretation and shadow GUARDRAIL fingerprints,
so the candidate is 0.10.0. The required globals.policy_shadows proof slot is
present even when empty and advances IR to 3; findings remains 2. Historical
IR2 stays unchanged and gains no inferred proof. Current-source corpus
validation requires IR3; the historical comparator retains raw IR2 and every
typed version/key/behavior delta. Existing shadow approvals need review, never
mechanical translation. Existing golden/corpus expected labels are untouched.

Conservative costs remain for differing role tables, warning-bearing configs,
ledger revocation and unsupported copy-plus-delete/Git-rename maintenance.
Inactive-file costs, ignored invalid allow records, multi-ledger attribution
and BASE role overrides remain separate limitations. This decision changes
neither general engine-error behavior nor unrelated oracle semantics.

Targeted policy/API/IR3 regression and native comparisons are being recorded
on actual PJU working-tree hashes. Validation, integration, acceptance and
publication remain distinct; this entry claims no missing platform, full-suite,
source/wheel/pyz or release-collector PASS. Required checks remain pending until
their own final-source receipts exist.
'''
changes['DECISIONS.md'][1]=decisions[:start]+entry+decisions[end:]
for name in ('docs/stability.md','docs/embedding.md','docs/remediation-upgrade.md'):
    text=read(name)
    replacements={
        'The separately proposed policy-shadow minor':'The 0.10.0 policy-shadow contract',
        'the separately proposed\npolicy-shadow minor':'the 0.10.0\npolicy-shadow contract',
        'The proposed policy-shadow minor':'The 0.10.0 policy-shadow contract',
        'The proposed IR3 requires':'IR3 requires',
        '## IR payloads (proposed policy-shadow minor)':'## IR payloads (0.10.0)',
        '## Proposed policy-shadow minor: IR3, findings2':'## Policy-shadow migration in 0.10.0: IR3, findings2',
        'Publication\nand this protected policy proposal require separate maintainer decisions.':'This contract was implemented under the pre-1.0 repair instruction;\nrelease checks and any publication approval remain separate. Stop for\nNelson\'s decision before 1.0.'}
    for old,new in replacements.items():text=text.replace(old,new)
    changes[name][1]=text
receipt={}
for name,(before,after) in changes.items():
    assert before!=after,name
    (REPO/name).write_text(after,encoding='utf-8',newline='\n')
    receipt[name]=dict(before_text_sha256=hashlib.sha256(before.encode()).hexdigest(),
                       after_raw_sha256=hashlib.sha256((REPO/name).read_bytes()).hexdigest())
(HERE/'adopt-text-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(adopted=True,files=list(changes))))
