"""Verify the installed wheel's console aliases without the source on sys.path."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

here = Path(__file__).resolve().parent
runtime = here / "wheel-runtime"
artifact = here / "artifacts/checkwash-0.10.0-py3-none-any.whl"
empty = Path(tempfile.mkdtemp(prefix="wheel-console-"))
env = dict(os.environ)
env.pop("PYTHONPATH", None)
env.pop("PYTHONHOME", None)
rows = []
for alias in ("checkwash", "greenwash"):
    command = [str(runtime / ("Scripts/" + alias + ".exe")), "--version"]
    result = subprocess.run(command, cwd=empty, env=env, capture_output=True)
    rows.append({"command": command, "cwd": str(empty), "exit_code": result.returncode,
                 "stdout": result.stdout.decode("utf-8"), "stderr": result.stderr.decode("utf-8")})
    assert result.returncode == 0 and result.stdout.strip() == b"checkwash 0.10.0" and not result.stderr, rows[-1]
command = [str(runtime / "Scripts/python.exe"), "-I", "-B", "-X", "utf8", "-c",
           "import checkwash,json;print(json.dumps({'file':checkwash.__file__,'version':checkwash.__version__}))"]
result = subprocess.run(command, cwd=empty, env=env, capture_output=True)
assert result.returncode == 0 and not result.stderr
identity = json.loads(result.stdout)
assert Path(identity["file"]).is_relative_to(runtime) and identity["version"] == "0.10.0", identity
print(json.dumps({"status": "passed", "console_aliases": rows,
                  "isolated_import": {"command": command, "cwd": str(empty), "exit_code": result.returncode, **identity},
                  "artifact_sha256": hashlib.sha256(artifact.read_bytes()).hexdigest(),
                  "source_pythonpath_removed": True, "formal_check_runs": 0}, indent=2))
