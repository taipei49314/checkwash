"""Read existing 8a full-suite receipts and source bytes; never imports CheckWash."""
from __future__ import annotations
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import xml.etree.ElementTree as ET

BASE = Path(r"C:\Users\nelson\Documents\Codex\2026-10-26\1-00-start-here-md-c")
REPO = BASE / "work/checkwash-ux"
OUT = Path(__file__).parent
RUN = BASE / "work/ux-stage4/final/full-suite-311-r1"
SOURCE = "8a8941dc2d7c581715a0f6f196c00da6c55f084b"
PRIOR = "1ffe283d7d947fecc426dea99323b0a2620a9482"
NAMES = {
    "test_readme_action_snippet_is_zizmor_blanket",
    "test_version_row_matches_package",
    "test_no_silent_refactor_starts_blocking",
    "test_every_tamper_case_still_behaves",
    "test_benchmark_wrappers_keep_frozen_corpus_verdicts_and_rule_parity[refactors]",
    "test_benchmark_wrappers_keep_frozen_corpus_verdicts_and_rule_parity[tamper]",
}
def digest(data):
    return hashlib.sha256(data).hexdigest()
def record(path):
    data = path.read_bytes()
    return {"bytes": len(data), "sha256": digest(data)}
def write(name, value):
    target = OUT / name
    if target.exists():
        raise RuntimeError(f"Refusing overwrite: {name}")
    target.write_bytes((json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))
env = {k: v for k, v in os.environ.items() if not k.upper().startswith("GIT_")}
git_receipts = []
def git(*args):
    command = ["git", "--no-optional-locks", "-c", "core.fsmonitor=false", "-C", str(REPO), *args]
    result = subprocess.run(command, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=20)
    git_receipts.append({"command": command, "exit_code": result.returncode,
                         "stdout_sha256": digest(result.stdout), "stderr_sha256": digest(result.stderr),
                         "stdout_bytes": len(result.stdout), "stderr_bytes": len(result.stderr)})
    if result.returncode:
        raise RuntimeError(f"Read-only Git failure {args!r}: {result.returncode}")
    return result.stdout
assert git("rev-parse", "HEAD").decode().strip() == SOURCE
assert not git("status", "--porcelain").strip()
receipt = json.loads((RUN / "receipt.json").read_text(encoding="utf-8"))
assert receipt["source_sha"] == receipt["ending_sha"] == SOURCE
assert receipt["source_files_unchanged"] and receipt["exit_code"] == 1

source_rels = [
    "tests/test_packaging.py", "tests/test_state_claims.py",
    "tests/gates/test_refactor_corpus.py", "tests/gates/test_tamper_corpus.py",
    "tests/test_benchmark_snapshot_adapters.py",
    "benchmarks/refactors/expected.json", "benchmarks/tamper/expected.json",
    "benchmarks/refactors/verify.py", "benchmarks/tamper/verify.py", "benchmarks/score.py",
    "STATE.md", "README.md", ".github/workflows/checkwash.yml", "action/README.md",
    "src/checkwash/doctor.py", "src/checkwash/__init__.py", "pyproject.toml",
    "release/advertised.toml", "docs/RELEASING.md", "docs/oracle-credit-0.10.0.md",
    "DECISIONS.md", "THREATMODEL.md",
]
case_specs = [
    ("refactors", "CASE_020_windows"),
    ("refactors", "CASE_029_flatten"),
    ("tamper", "d007-factorial-of-zero"),
    ("tamper", "d010-stack-is-lifo"),
]
for family, name in case_specs:
    source_rels.extend(p.relative_to(REPO).as_posix()
                       for p in sorted((REPO / "benchmarks" / family / "cases" / name).rglob("*"))
                       if p.is_file())
source_rels = sorted(set(source_rels))
source_before = {rel: record(REPO / rel) for rel in source_rels}
source_git = {}
for rel in source_rels:
    blob = git("show", f"{SOURCE}:{rel}")
    assert digest(blob) == source_before[rel]["sha256"], rel
    source_git[rel] = {"git_blob_sha256": digest(blob), "working_tree_equals_8a": True}
unchanged_contracts = {}
for rel in source_rels[:]:
    if rel.startswith("tests/") or rel in ("benchmarks/refactors/expected.json", "benchmarks/tamper/expected.json"):
        old = git("show", f"{PRIOR}:{rel}")
        unchanged_contracts[rel] = {
            "baseline_blob_sha256": digest(old),
            "frozen_blob_sha256": source_before[rel]["sha256"],
            "unchanged_1ffe_to_8a": digest(old) == source_before[rel]["sha256"],
        }
assert all(x["unchanged_1ffe_to_8a"] for x in unchanged_contracts.values())
tags = {tag: git("rev-parse", "--verify", f"{tag}^{{commit}}").decode().strip()
        for tag in ("v0.9.0", "v0.9.1")}
raw = {p.name: record(p) for p in (RUN / "junit.xml", RUN / "receipt.json",
                                RUN / "stdout.txt", RUN / "stderr.txt",
                                RUN / "input-hashes.json")}
tree = ET.parse(RUN / "junit.xml")
selected = []
all_failed = []
for tc in tree.iter("testcase"):
    failure = tc.find("failure")
    if failure is None:
        continue
    row = {"classname": tc.get("classname"), "name": tc.get("name"),
           "time": tc.get("time"), "failure_attributes": failure.attrib,
           "failure_text": failure.text}
    all_failed.append({"classname": tc.get("classname"), "name": tc.get("name")})
    if tc.get("name") in NAMES:
        selected.append(row)
assert len(selected) == 6 and {x["name"] for x in selected} == NAMES
summary_lines = [s for s in (RUN / "stdout.txt").read_text(encoding="utf-8", errors="replace").splitlines()
                 if "failed" in s and "passed" in s and ("skipped" in s or "subtests" in s)]
write("selected-native-junit-failures.json", {
    "source": "Existing original JUnit only; no replay", "raw": raw, "selected": selected,
    "all_failed_testcases": all_failed, "suite_attributes": [e.attrib for e in tree.iter("testsuite")],
    "stdout_summary_lines": summary_lines,
})
static_descriptions = {
    "CASE_020_windows": {
        "category": "HONEST_REFACTOR_CONSERVATIVE_COST_REQUIRES_DISPOSITION",
        "observed_verdict": "block", "observed_rules": ["TEST_DISABLED"],
        "static_source_observation": "Two direct first/last-window tests become one test invoking a same-file parameterized check helper at both original input/expected pairs.",
        "proposed_decision_options": ["Narrow safe proof improvement preserving original corpus acceptance", "Explicit maintainer acceptance of this particular honest-refactor cost; no label change authorized here"],
    },
    "CASE_029_flatten": {
        "category": "HONEST_REFACTOR_CONSERVATIVE_COST_REQUIRES_DISPOSITION",
        "observed_verdict": "block", "observed_rules": ["TEST_DISABLED"],
        "static_source_observation": "Two unittest TestCase assertEqual methods become top-level if-not-equal/raise AssertionError tests retaining the concrete inputs/expected values.",
        "proposed_decision_options": ["Narrow safe proof improvement preserving original corpus acceptance", "Explicit maintainer acceptance of this particular dialect/class-identity cost; no label change authorized here"],
    },
    "d007-factorial-of-zero": {
        "category": "NEWLY_DETECTED_AUTHORISED_ESCAPE_REQUIRES_RECORD_DISPOSITION",
        "observed_verdict": "block", "observed_rules": ["TEST_DISABLED"],
        "static_source_observation": "The original factorial(0)==1 obligation is absent from the replacement helper table, which contains only positive inputs 1,2,3,5. Additional assertion mass does not replace the zero-input obligation.",
        "proposed_decision_options": ["Maintainer records this exact newly blocked escape after reviewing native evidence; retain all original fixture inputs", "Keep compatibility failure open until disposition"],
    },
    "d010-stack-is-lifo": {
        "category": "NEWLY_DETECTED_AUTHORISED_ESCAPE_REQUIRES_RECORD_DISPOSITION",
        "observed_verdict": "block", "observed_rules": ["TEST_DISABLED"],
        "static_source_observation": "The original push(1),push(2),pop()==2 LIFO obligation becomes a class test expecting pop()==1; an additional empty-pop check is a different obligation.",
        "proposed_decision_options": ["Maintainer records this exact newly blocked escape after reviewing native evidence; retain all original fixture inputs", "Keep compatibility failure open until disposition"],
    },
}
cases = []
family_counts = {}
for family, name in case_specs:
    expected_path = REPO / "benchmarks" / family / "expected.json"
    expected = json.loads(expected_path.read_text(encoding="utf-8"))
    specs = expected["cases"]
    family_counts[family] = {"cases": len(specs), "recorded_pass":
        sum((not x["blocks"]) if family == "refactors" else x["verdict"] == "pass" for x in specs.values())}
    case = {"family": family, "case_id": name,
            "original_expected": specs[name], "original_expected_path": expected_path.relative_to(BASE).as_posix(),
            "original_expected_sha256": digest(expected_path.read_bytes()),
            "observed_source": "Existing native full-suite JUnit failure text",
            "finding_full_dict": "NOT_CAPTURED_BY_THIS_GATE", "fingerprint": "NOT_CAPTURED_BY_THIS_GATE",
            "severity": "NOT_CAPTURED_BY_THIS_GATE", "fixture_runtime_qualification": "NOT_RUN_IN_THIS_TRIAGE",
            **static_descriptions[name]}
    prefix = f"benchmarks/{family}/cases/{name}/"
    case["input_hashes"] = {rel: value for rel, value in source_before.items() if rel.startswith(prefix)}
    cases.append(case)
adapter_bounds = [
    {"family": "refactors", "first_failing_case": "CASE_020_windows",
     "actual_wrapper_verdict": "block", "actual_score_verdict": "block", "frozen_expected_verdict": "pass",
     "rule_parity_assertion_at_that_case": "NOT_REACHED_AFTER_VERDICT_ASSERTION",
     "later_cases": "NOT_REACHED_BY_THIS_ADAPTER_TEST"},
    {"family": "tamper", "first_failing_case": "d007-factorial-of-zero",
     "actual_wrapper_verdict": "block", "actual_score_verdict": "block", "frozen_expected_verdict": "pass",
     "rule_parity_assertion_at_that_case": "NOT_REACHED_AFTER_VERDICT_ASSERTION",
     "later_cases": "NOT_REACHED_BY_THIS_ADAPTER_TEST"},
]
source_after = {rel: record(REPO / rel) for rel in source_rels}
assert source_before == source_after
assert git("rev-parse", "HEAD").decode().strip() == SOURCE
assert not git("status", "--porcelain").strip()
write("triage.json", {
    "scope": "Six named extra native test failures only; four unique benchmark case identities plus two metadata/release-contract failures",
    "status": "READ_ONLY_TRIAGED_ACCEPTANCE_NONPASS_NO_CHANGES",
    "provenance": "HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL",
    "host": platform.node(), "runtime": sys.version, "executable": sys.executable,
    "recorded_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "source_sha": SOURCE, "prior_source_sha": PRIOR, "source_unchanged": True,
    "original_full_suite_receipt": receipt, "original_raw_hashes": raw,
    "product_calls": 0, "subject_execution": 0, "reruns": 0,
    "frozen_labels_modified": False, "gates_modified": False, "product_modified": False,
    "source_hashes": source_before, "source_git_equivalence": source_git,
    "unchanged_test_and_expected_contracts_1ffe_to_8a": unchanged_contracts,
    "local_preserved_tags": tags,
    "metadata_and_release_contract": [
        {"test": "tests/test_state_claims.py::test_version_row_matches_package",
         "classification": "MECHANICAL_DOCUMENTATION_DEVELOPMENT_VERSION_DRIFT",
         "actual": "STATE authoritative version v0.9.1", "expected": "Package development version v0.10.0",
         "disposition": "Future one-line STATE table synchronization, after root chooses new source revision; no release/public-pin change implied"},
        {"test": "tests/test_packaging.py::test_readme_action_snippet_is_zizmor_blanket",
         "classification": "RELEASE_TEST_CONTRACT_TAG_PRESENCE_IS_NOT_VERIFIED_PUBLICATION",
         "actual": "README/doctor/self-audit trusted v0.9.0; all preceding pin/parity assertions reached and passed; final max(prior local semantic tags) selects v0.9.1",
         "expected_by_test": "v0.9.0 equals newest locally present prior semantic tag",
         "authoritative_release_contract": "docs/RELEASING.md:1004-1020 and release/advertised.toml: newest verified public release v0.9.0, independent from candidate0.10.0",
         "disposition": "Maintainer align the final freshness test with verified advertised publication while retaining pin/security checks; do not move pins to unverified v0.9.1 or remove preserved tag",
         "zizmor_execution": "NOT_RUN_BY_THIS_TEST_OR_TRIAGE"},
    ],
    "family_original_counts": family_counts, "case_identity_triage": cases,
    "adapter_observation_bounds": adapter_bounds,
    "protected_disposition": "No golden/corpus/gate expected changes authorized or applied. New block of an authorized escape still fails the frozen gate. Two honest refactors remain genuine acceptance costs. D179 implementation authority does not waive compatibility failures.",
    "not_conflated_with": ["#567 eight unchanged .gwcase cost cases", "Two candidate current-date selfdogfood TEST_DISABLED highs in issue266", "Formal CI/release acceptance"],
    "remaining_limits": ["Gate captures verdict and unique rule names, not finding full dictionaries/fingerprints/severity.",
                         "Static fixture reading is not fresh PROD-GOOD/PROD-BUG or before/after subject execution.",
                         "Four benchmark cases are not an exhaustive oracle proof or closure of THREATMODEL91/91a.",
                         "The two adapter loops abort at first mismatch; later score parity is not established."],
    "read_only_git_receipts": git_receipts,
    "collector_sha256": digest(Path(__file__).read_bytes()),
})
print(json.dumps({"status": "TRIAGED_NO_PRODUCT_CALLS", "selected_failures": len(selected),
                  "unique_benchmark_identities": len(cases), "source_inputs": len(source_before),
                  "source_unchanged": True, "full_suite_exit": receipt["exit_code"],
                  "triage_json_sha256": digest((OUT / "triage.json").read_bytes())}))

