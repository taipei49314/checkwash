"""Stage TASK validation, preserving any later paired-reader/oracle work."""
import hashlib
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2] / "work/checkwash-ux"


def git(*args, input=None):
    return subprocess.run(["git", *args], cwd=REPO, input=input, capture_output=True, check=True).stdout


def stage_text(name, text):
    data = text.rstrip().encode("utf-8") + b"\n"
    oid = git("hash-object", "-w", "--stdin", input=data).decode().strip()
    git("update-index", "--add", "--cacheinfo", "100644", oid, name)


assert not git("diff", "--cached", "--name-only")
cli = git("show", "HEAD:src/checkwash/cli.py").decode("utf-8")
swaps = {
    "from checkwash.contract import Contract, contract_diagnostics, parse_contract":
        "from checkwash.contract import Contract, contract_diagnostics, load_contract",
    "\n            contract = parse_contract(task_text)\n":
        '\n            contract = load_contract(task_text, source=f"--task {rel!r} (BASE)")\n',
    "\n                contract = parse_contract(task_text)\n":
        '\n                contract = load_contract(task_text, source=f"--task {rel!r} (working-tree fallback)")\n',
}
for old, new in swaps.items():
    assert cli.count(old) == 1, old
    cli = cli.replace(old, new)
stage_text("src/checkwash/cli.py", cli)
patch = HERE.parent / "task/D181-cli-utf8.patch"
assert hashlib.sha256(patch.read_bytes()).hexdigest() == "7b8a7bc06520833bd1a4ff1caf367ac3ed141b8e286f59d2d13044bfe6a73543"
git("apply", "--cached", "--check", str(patch))
git("apply", "--cached", str(patch))

spec = (REPO / "SPEC.md").read_text(encoding="utf-8")
before, rest = spec.split("### Textual worktree relocation (0.10.0, D-182)", 1)
_, after = rest.split("## 5. Escalators / de-escalators", 1)
stage_text("SPEC.md", before + "## 5. Escalators / de-escalators" + after)
decisions = (REPO / "DECISIONS.md").read_text(encoding="utf-8")
stage_text("DECISIONS.md", decisions.split("## D-182 (", 1)[0])
git("add", "--", "docs/task-input.md", "src/checkwash/contract.py",
    "tests/test_task_contract_validation.py", "tests/test_task_source_encoding.py",
    "tests/test_task_syntax_diagnostics.py")
review = (REPO / "tests/test_stage4_contract_crlf_review.py").read_text(encoding="utf-8")
stage_text("tests/test_stage4_contract_crlf_review.py", review.split("def test_crlf_pairing_normalization_work_is_linear_in_input_bytes", 1)[0])
(HERE / "04-validation-staged.patch").write_bytes(git("diff", "--cached", "--binary"))
print(git("diff", "--cached", "--stat").decode())
