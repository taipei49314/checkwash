"""Adopt D-179 implementation semantics while preserving unresolved golden gates."""
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2] / "work/checkwash-ux"
draft = (HERE.parent / "oracle/D179-oracle-adoption.md").read_text(encoding="utf-8")
body = draft.split("## Decision text\n\n", 1)[1].split("\n## Observed implementation controls", 1)[0].strip()
body = body.replace("## IR and compatibility", "### IR and compatibility").replace("## Explicit boundaries and costs", "### Explicit boundaries and costs")
body = body.replace("neither this decision draft nor", "neither this implementation decision nor").replace("relables", "relabels")
body += "\n\nThe adjacent unchanged-name JS/TS provenance repair is recorded separately in D-184.\n"
body += ("\nOrdinary test consumers are migrated explicitly: issue219's closed snapshot\n"
         "helper supplies root context without changing its assertions. Three issue266\n"
         "unit contracts now require UNCREDITED for unknown startup, changed setup or\n"
         "missing strict context, with named D-179 explanations. These are reviewed\n"
         "minor-contract tests, separate from the eight unchanged .gwcase labels.\n")
decisions_path = REPO / "DECISIONS.md"
decisions = decisions_path.read_text(encoding="utf-8")
assert "## D-179 (" not in decisions
position = decisions.index("## D-180 (")
decisions = decisions[:position] + "## D-179 (2026-10-27): bind oracle compensation to static source context\n\n" + body.strip() + "\n\n" + decisions[position:]
decisions_path.write_text(decisions, encoding="utf-8", newline="\n")

spec_path = REPO / "SPEC.md"
spec = spec_path.read_text(encoding="utf-8")
lines = spec.splitlines()
for index, line in enumerate(lines):
    if line.startswith("| D2 `ASSERTION_MOVED` |"):
        lines[index] = ("| D2 `ASSERTION_MOVED` | a removed oracle has a matching two-sided static context in a live arrival, under D-179 below. Text, body hash, assertion mass and name similarity alone establish no credit. Existing collection/liveness checks remain. Each arriving assertion is spendable once across whole-unit, assertion and D5 routes; a complete-unit credit consumes its assertion credits too. Complete-unit equivalence may return at info; assertion-only credit still applies E2 under oracle_freeze | info, or high/ORACLE_FREEZE for assertion-only credit under freeze |")
    elif line.startswith("| D5 `RESTRUCTURED` |"):
        lines[index] = ("| D5 `RESTRUCTURED` | within-file oracle mass is a candidate budget only; every lost own assertion must also have a matching static context/multiplicity proof in live arrivals (D-179). Split/renamed candidates use the same proof and shared spendable budget | hold at warn, still subject to E2 |")
    elif line.startswith("| D10 `DUPLICATE_REMAINS` |"):
        lines[index] = ("| D10 `DUPLICATE_REMAINS` | a disappeared unit has a proven complete oracle-context equivalent in an unchanged, live, collectable Python survivor. The existing bounded head search (at most eight parsed candidates), conftest liveness (#266) and collection checks remain. Strict startup context is required; an unknown context earns no credit. A verified survivor is reusable for genuine deduplication. JS/TS survivors remain outside this route (#484) | → info |")
spec = "\n".join(lines) + "\n"
marker = "Two design notes that are"
assert marker in spec
position = spec.index("D8–D10 came from the second")
# Keep the historical design-note introduction intact; put the current proof
# contract immediately before section 6, where all D-table definitions precede it.
proof = """### Oracle-context proof in IR3 (D-179, 0.10.0)

Python relocation proof includes module/import/class context, full decorators
and arguments, parameter inputs/expectations, the assertion's prior/following
execution context, conftest startup and ancestor package initializers. Unknown
assertion calls are retained; only proved pure literal assertions may be inert.
Literal parameter combinations are expanded statically up to 64 live rows.
There is no getattr-to-attribute equivalence: opaque prior calls may replace
builtin lookup. Module/helper metadata and unsupported dynamic contexts supply
no proof. Exact complete-unit relocation remains available with known context.

JS/TS proof retains declarations/tables, bindings and surrounding execution.
Ordinary strings are never module paths. Only recognized static import tokens
may be resolved lexically; bare, dynamic or unknown imports retain their
directory context. Existing runner/liveness admission is unchanged.

IR3 adds optional UnitSide.oracle_context and oracle_assertion_contexts. Empty,
missing or malformed proof is unknown; valid values are lowercase SHA256 keys.
Assertion keys are IDs with an optional @row ordinal. duplicate_unit_hashes now
contains complete oracle-context keys; moved text/body lists are candidates,
never authority on their own. Historical IR2 gains no inferred proof. Finding
envelope2 and existing fingerprint formulas stay unchanged.

Optional proof is bounded to 256 KiB/128 units per file, 16,384 module AST nodes,
128 statements/4,096 nodes per function, and bounded startup reads (16 ancestor
levels, 64 initializer records, 64 KiB each). Missing/read/type/size/budget or
resource gaps withhold compensation without skipping ordinary analysis. Stable
AST keys omit only empty type_params and reject unsupported generic syntax.

This is bounded static obligation matching, not universal runtime equivalence.
External plugins/import hooks and unsupported dynamic behavior remain limits.
D1/D3, same-unit rewrites, compatibility/production-removal policy, strength and
alignment retain their separate contracts. Complete-unit/duplicate equivalence
can retain info under freeze; every assertion-only D2 or D5 route still reaches
E2. Exact eligible BASE exemptions retain priority. Eight historical golden
expectations remain unresolved compatibility failures; this contract does not
relabel or waive them. See docs/oracle-credit-0.10.0.md.

"""
spec = spec.replace("## 6. Exemptions\n", proof + "## 6. Exemptions\n", 1)
spec_path.write_text(spec, encoding="utf-8", newline="\n")

cost = (HERE.parent / "oracle/cost-r4/cost-table.md").read_text(encoding="utf-8")
cost = cost.replace("# Unresolved historical fixture movements — exact old/new observations", "## Unresolved historical fixture movements — exact old/new observations", 1)
header = """# Oracle credit in the 0.10.0 candidate

D-179 replaces text/body/mass-only compensation with bounded static source
context. Proven complete moves, exact duplicates and supported literal table
projections remain; unknown setup, execution effects and dynamic lookup do not
acquire a waiver. Freeze remains effective for assertion-only compensation.
The [integration overview](repair-integration-0.10.0.md) describes the full goal.

Six independently reproduced proof defects were fixed and read back against
18 bounded observations. The final development target recorded 369 passing
checks; its source map is distinct from final integration qualification. These
results neither prove universal runtime equivalence nor accept historical cost.

The original corpus still has eight incompatible expectations. They remain
unchanged and failing, under the repository's rule against autonomous fixture
relabeling. A 0.10.0 version string and the core implementation instruction do
not turn those failed gates into release acceptance. Final-source checks and
their exact remaining differences must be recorded separately.

"""
(REPO / "docs/oracle-credit-0.10.0.md").write_text(header + cost, encoding="utf-8", newline="\n")
