"""Update only source collection denominators from the actual retained receipt."""
import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2] / "work/checkwash-ux"
raw_path = HERE.parent / "root/final-docs-collection-01/stdout.txt"
receipt = json.loads((raw_path.parent / "receipt.json").read_text(encoding="utf-8"))
assert receipt["exit_code"] == 0 and receipt["source_files_unchanged"]
counts = re.findall(r"(\d+) tests collected", raw_path.read_text(encoding="utf-8"))
assert len(counts) == 1 and int(counts[0]) > 20000
record = {"collected": int(counts[0]), "not_a_pass_count": True,
          "source_receipt": str(raw_path.parent / "receipt.json"), "files": {}}
for name in ("README.md", "CONTRIBUTING.md", "docs/launch.md"):
    path = REPO / name
    before = path.read_bytes()
    text = before.decode("utf-8")
    assert "20858 tests" in text, name
    after = text.replace("20858 tests", counts[0] + " tests").encode("utf-8")
    path.write_bytes(after)
    record["files"][name] = {"before_sha256": hashlib.sha256(before).hexdigest(),
                            "after_sha256": hashlib.sha256(after).hexdigest()}
(HERE / "collection-claim-update.json").write_text(json.dumps(record, indent=2), encoding="utf-8")
print(json.dumps(record, indent=2))
