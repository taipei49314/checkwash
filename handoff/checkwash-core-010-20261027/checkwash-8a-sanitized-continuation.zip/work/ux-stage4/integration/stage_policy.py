"""Stage only the reviewed policy slice without changing shared working files."""
import hashlib
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
REPO = ROOT / "work/checkwash-ux"
BUNDLE = ROOT / "work/ux-stage3/policy-shadow"


def git(*args, input=None):
    return subprocess.run(["git", *args], cwd=REPO, input=input, capture_output=True, check=True).stdout


assert not git("diff", "--cached", "--name-only"), "index must start empty"
patches = {
    "implementation.patch": "7ab91501aecaa05ed47a130d2f2d61cb27a96139a63ec1be49c138270385abdf",
    "protected-contract.patch": "8ad77c27e78122889a251af189a130f7f173292415868c1139d813fe5ed4e7ab",
    "consumer-migration.patch": "6f5458ecdfcf0651968e9fef16993faf1e26b6da2235364065c3e5656973958b",
}
for name, expected in patches.items():
    path = BUNDLE / name
    assert hashlib.sha256(path.read_bytes()).hexdigest() == expected, name
    git("apply", "--cached", "--check", str(path))
    git("apply", "--cached", str(path))

# These paths have additional TASK/oracle work owned by other slices. Keep
# their reviewed policy-only index contents, not their current working bytes.
shared = {"src/checkwash/cli.py", "src/checkwash/engine.py", "src/checkwash/gating.py",
          "src/checkwash/ir/model.py", "SPEC.md", "DECISIONS.md"}
paths = set()
for name in ("patch-manifest.json", "consumer-migration-manifest.json"):
    paths.update(json.loads((BUNDLE / name).read_text(encoding="utf-8"))["files"])
git("add", "--", *sorted(paths - shared))


def stage_text(name, text):
    data = text.rstrip().encode("utf-8") + b"\n"
    (HERE / (name + ".policy-index")).write_bytes(data)
    oid = git("hash-object", "-w", "--stdin", input=data).decode().strip()
    git("update-index", "--cacheinfo", "100644", oid, name)


spec = (REPO / "SPEC.md").read_text(encoding="utf-8")
before, rest = spec.split("### TASK policy syntax validation (0.10.0, D-181)", 1)
_, after = rest.split("## 5. Escalators / de-escalators", 1)
stage_text("SPEC.md", before + "## 5. Escalators / de-escalators" + after)
decisions = (REPO / "DECISIONS.md").read_text(encoding="utf-8")
stage_text("DECISIONS.md", decisions.split("## D-181 (", 1)[0])
diff = git("diff", "--cached", "--binary")
(HERE / "02-policy-staged.patch").write_bytes(diff)
record = {"head": git("rev-parse", "HEAD").decode().strip(),
          "staged_diff_sha256": hashlib.sha256(diff).hexdigest(),
          "staged_paths": git("diff", "--cached", "--name-only").decode().splitlines(),
          "working_files_modified": False, "patch_sha256": patches}
(HERE / "02-policy-staging.json").write_text(json.dumps(record, indent=2), encoding="utf-8")
print(json.dumps(record, indent=2))
