"""Stage lexical TASK addressing separately from the syntax/encoding change."""
import hashlib
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2] / "work/checkwash-ux"


def git(*args, input=None):
    return subprocess.run(["git", *args], cwd=REPO, input=input, capture_output=True, check=True).stdout


def stage_text(name, text):
    data = text.rstrip().encode("utf-8") + b"\n"
    (HERE / (name.replace("/", "_") + ".task-index")).write_bytes(data)
    oid = git("hash-object", "-w", "--stdin", input=data).decode().strip()
    git("update-index", "--cacheinfo", "100644", oid, name)


assert not git("diff", "--cached", "--name-only")
cli_path = REPO / "src/checkwash/cli.py"
cli_raw = cli_path.read_bytes()
cli = cli_raw.decode("utf-8").replace("\r\n", "\n")
replacements = {
    "from checkwash.change import EngineError, SourceOverLimit, UnreadSide": "from checkwash.change import SourceOverLimit, UnreadSide",
    "from checkwash.contract import Contract, contract_diagnostics, load_contract": "from checkwash.contract import Contract, contract_diagnostics, parse_contract",
    "            try:\n                task_text = data.decode(\"utf-8\")\n            except UnicodeDecodeError as exc:\n                raise EngineError(f\"--task {rel!r} (BASE): UTF-8 required\") from exc":
        "            task_text = data.decode(\"utf-8\", errors=\"replace\")",
    "load_contract(task_text, source=f\"--task {rel!r} (BASE)\")": "parse_contract(task_text)",
    "load_contract(task_text, source=f\"--task {rel!r} (working-tree fallback)\")": "parse_contract(task_text)",
}
for old, new in replacements.items():
    assert cli.count(old) == 1, old
    cli = cli.replace(old, new)
stage_text("src/checkwash/cli.py", cli)

spec = (REPO / "SPEC.md").read_text(encoding="utf-8")
before, rest = spec.split("### TASK policy syntax validation (0.10.0, D-181)", 1)
_, after = rest.split("## 5. Escalators / de-escalators", 1)
stage_text("SPEC.md", before + "## 5. Escalators / de-escalators" + after)
decisions = (REPO / "DECISIONS.md").read_text(encoding="utf-8")
stage_text("DECISIONS.md", decisions.split("## D-181 (", 1)[0])

draft = (HERE.parent / "task/contract-wording.md").read_text(encoding="utf-8")
doc_text = draft.split("## docs/task-input.md replacement for the old relative-path discrepancy note\n\n", 1)[1].strip()
doc = git("show", "HEAD:docs/task-input.md").decode("utf-8")
start = doc.index("The reviewed base copy supplies the contract.")
end = doc.index("These task settings apply", start)
# Syntax validation is the next slice, so its note is not yet asserted here.
doc_text = doc_text.replace("The supplied task is still subject to the restricted syntax\nvalidator; a correct lookup is not proof that malformed policy was applied.",
                            "The supplied task still uses the restricted front-matter subset.")
stage_text("docs/task-input.md", doc[:start] + doc_text + "\n\n" + doc[end:])
git("add", "--", "tests/test_task_path_diagnostics.py", "tests/test_task_repo_relative_authority.py")
assert cli_path.read_bytes() == cli_raw, "working CLI changed during index preparation"
diff = git("diff", "--cached", "--binary")
(HERE / "03-task-staged.patch").write_bytes(diff)
(HERE / "03-task-staging.json").write_text(json.dumps({
    "head": git("rev-parse", "HEAD").decode().strip(),
    "working_cli_sha256": hashlib.sha256(cli_raw).hexdigest(),
    "staged_diff_sha256": hashlib.sha256(diff).hexdigest(),
    "staged_paths": git("diff", "--cached", "--name-only").decode().splitlines(),
    "working_files_modified": False}, indent=2), encoding="utf-8")
print(git("diff", "--cached", "--stat").decode())
