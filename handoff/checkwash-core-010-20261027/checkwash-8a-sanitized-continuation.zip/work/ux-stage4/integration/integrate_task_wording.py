"""Adopt the reviewed D-178 wording without disturbing other contract slices."""
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2] / "work/checkwash-ux"
draft = (HERE.parent / "task/contract-wording.md").read_text(encoding="utf-8")
path_text = draft.split("## SPEC §4c path paragraph\n\n", 1)[1].split("\n## DECISIONS D-178", 1)[0].strip()
decision_text = draft.split("## DECISIONS D-178\n\n", 1)[1].split("\n## docs/task-input.md", 1)[0].strip()
decision_text = decision_text.replace("Historical9a", "Historical 9a").replace("a1.0", "a 1.0")
doc_text = draft.split("## docs/task-input.md replacement for the old relative-path discrepancy note\n\n", 1)[1].strip()

spec_path = REPO / "SPEC.md"
spec = spec_path.read_text(encoding="utf-8")
start = spec.index("From a subdirectory (§9), the task path")
end = spec.index("### TASK policy syntax validation", start)
spec_path.write_text(spec[:start] + path_text + "\n\n" + spec[end:], encoding="utf-8", newline="\n")

decision_path = REPO / "DECISIONS.md"
decisions = decision_path.read_text(encoding="utf-8")
marker = "## D-181 ("
assert "## D-178 (" not in decisions
position = decisions.index(marker)
decisions = decisions[:position] + "## D-178 (2026-10-27): TASK lookup belongs to the original repo address\n\n" + decision_text + "\n\n" + decisions[position:]
decision_path.write_text(decisions.rstrip() + "\n", encoding="utf-8", newline="\n")

doc_path = REPO / "docs/task-input.md"
doc = doc_path.read_text(encoding="utf-8")
start = doc.index("The reviewed base copy supplies the contract.")
end = doc.index("These task settings apply", start)
doc_path.write_text(doc[:start] + doc_text + "\n\n" + doc[end:], encoding="utf-8", newline="\n")
