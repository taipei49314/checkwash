"""Record the retained quality trust contract; no executable gate changes."""
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2] / "work/checkwash-ux"
draft = (HERE.parent / "oracle/D180-quality-A-adoption.md").read_text(encoding="utf-8")
decision = draft.split("## DECISIONS text\n\n", 1)[1].split("\n## SPEC §6 addition", 1)[0].strip()
spec_addition = draft.split("## SPEC §6 addition\n\n", 1)[1].split("\n## Evidence and implementation boundary", 1)[0].strip()
spec_path = REPO / "SPEC.md"
spec = spec_path.read_text(encoding="utf-8")
assert "### Quality policy maintenance (D-180)" not in spec
spec = spec.replace("## 6. Exemptions\n\n", "## 6. Exemptions\n\n### Quality policy maintenance (D-180)\n\n" + spec_addition + "\n\n", 1)
spec_path.write_text(spec, encoding="utf-8", newline="\n")
path = REPO / "DECISIONS.md"
text = path.read_text(encoding="utf-8")
assert "## D-180 (" not in text
index = text.index("## D-181 (")
text = text[:index] + "## D-180 (2026-10-27): retain prior-BASE quality maintenance review\n\n" + decision + "\n\n" + text[index:]
path.write_text(text, encoding="utf-8", newline="\n")
