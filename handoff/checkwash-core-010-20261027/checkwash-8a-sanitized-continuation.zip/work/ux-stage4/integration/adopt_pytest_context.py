"""Integrate the bounded worktree pytest evidence contract, D-183."""
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2] / "work/checkwash-ux"
draft = (HERE.parent / "policy/D183-spec-draft.md").read_text(encoding="utf-8")
addition = draft.split("Suggested SPEC insertion next to frozen pytest config evidence (§2/§2b):\n\n", 1)[1].split("\nSuggested DECISIONS entry:", 1)[0].strip()
decision = draft.split("Suggested DECISIONS entry:\n\n", 1)[1].strip()
spec_path = REPO / "SPEC.md"
spec = spec_path.read_text(encoding="utf-8")
assert "### Paired live pytest configuration evidence (D-183)" not in spec
spec = spec.replace("## 3. Assertion strength lattice\n", "### Paired live pytest configuration evidence (D-183)\n\n" + addition + "\n\n## 3. Assertion strength lattice\n", 1)
spec_path.write_text(spec, encoding="utf-8", newline="\n")
decisions_path = REPO / "DECISIONS.md"
decisions = decisions_path.read_text(encoding="utf-8")
assert "## D-183 (" not in decisions
position = decisions.index("## D-184 (")
decisions = decisions[:position] + decision + "\n\n" + decisions[position:]
decisions_path.write_text(decisions, encoding="utf-8", newline="\n")
