# Read-only triage of two ordinary JS failures

Source: `8a8941dc2d7c581715a0f6f196c00da6c55f084b`, compared with
`1ffe283d7d947fecc426dea99323b0a2620a9482`.
HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL; LAPTOP-01AGNPJU.

This triage read the final native JUnit / independent-readback, source and
Git diffs. It did not import, compile or execute CheckWash, fixtures, pytest
or either test. No source, assertions, labels or original raw files changed.
The full suite remains failed: 22 failures comprise the eight known golden
costs and fourteen additional failures. These two ordinary tests are part
of the latter group, not dispositions of the eight golden labels.

## Unchanged test inputs

Both test files have identical Git blobs at 1ffe and 8a:

| Test file | Git blob at both sources |
|---|---|
| tests/test_js_liveness.py | 3ad6e1441612937c718f1f44bc42804e840f1589 |
| tests/test_js_test_obligations.py | 3a3c99ee121cdaae1532892af20ef2e81d4d7df6 |

The observed failures therefore do not come from changed test inputs.
The relevant new route is D-179's oracle proof: engine.py:1753–1767 attaches
proofs, oracle_credit.py:248–257 retains lexical environment outside units,
and gating.py:725–758 requires matching complete context or assertion proofs
for removal/move credit. The old 1ffe route used body/text candidates alone.
DECISIONS.md:283–293 explicitly binds JS declaration/module/binding/control
context; :338–350 describes bounded costs and preserves failing gates.

## 1. Live describe wrapper positive control

Exact native failure nodeID:

```text
tests/test_js_liveness.py::test_a_unit_moved_into_a_skipped_block_earns_no_move_credit[describe("moved", () => {\n  it("computes", () => { expect(total()).toBe(5); });\n});\n-outcome0]
```

At tests/test_js_liveness.py:233–245, the before unit is a top-level
`it("computes", ...)` in tests/a.test.js. It is removed there and added in
tests/b.test.js inside a new active `describe("moved", ...)` wrapper.
The old assertion requires `(pass, [(TEST_DISABLED, info)])`. The native
failure records `block` and a high finding instead. The displayed failure
abbreviates the actual tuple, so this triage does not invent a separately
measured complete finding dictionary.

The sibling `describe.skip` / outcome1 testcase has no native failure,
error or skipped child: its assertion of BLOCK/high still passed in this
same full suite. The liveness-negative behavior did not regress in that
control.

Source explanation: the before module environment is empty outside the
unit. The after environment still contains the newly introduced describe
wrapper after unit spans are removed (oracle_credit.py:248–257). That
different environment joins both unit and assertion proof keys at :293–305
and :350. Therefore identical assertion/body text cannot provide D2/D5
credit. This is consistent with the adopted bounded-context contract,
rather than evidence of an implementation violating it. It is a newly
observed ordinary-positive compatibility cost; it has not been accepted
merely because D-179 exists.

Classification: **bounded-contract cost / unmigrated ordinary positive
control, not a demonstrated implementation regression**. Supplying a
root_reader is not the missing adapter: engine.py:1765 deliberately uses
the already supplied JS module data with known empty startup. The actual
lexical scope changed.

Next named scope, all NOT_EXECUTED here:

- To isolate the original liveness purpose, review a control whose before
  and live after both use the same active describe scope; keep the skipped
  after sibling as BLOCK. This preserves a positive equivalence premise
  rather than silently changing an expected verdict.
- If maintainers require the original top-level-to-new-wrapper positive
  to remain PASS, it needs a separately reviewed narrow wrapper-equivalence
  proof and adjacent setup/control mutation negatives. The present triage
  does not authorize that language/proof expansion or an assertion update.

## 2. Move from a CI directory with a relative import

Exact native failure nodeID:

```text
tests/test_js_test_obligations.py::test_moving_a_test_out_of_a_ci_directory_is_not_a_workflow_removal
```

At tests/test_js_test_obligations.py:96–104, one FileChange moves identical
BEFORE bytes from `.github/workflows/value.test.ts` to `src/value.test.ts`.
The old assertions require verdict PASS, a CI_WORKFLOW_TOUCHED/warn finding,
and no finding above warn. The first assertion now observes BLOCK. This
native failure does not print the full findings vector, so exact additional
finding counts/rules below are source reasoning, not a new runtime result.

The fixture is not a proof of an unchanged producer. BEFORE at :24–29 uses
`import { total } from "./value"`. Its lexical target changes from
`.github/workflows/value` to `src/value` when the test moves without an import
edit. D-179 explicitly canonicalizes recognized relative import specifiers
against each file directory (oracle_credit.py:275–293); those two module
environments differ. That is substantive static binding context, even
though the test declaration text is identical.

The move out of a supervised role is expanded to deleted-old / added-new
changes by engine.py:443–473. The old non-YAML JS/TS CI path retains test
obligations; engine.py:1603–1608 still handles it as CI_WORKFLOW_TOUCHED at
warn. Its ordinary removed-unit route can now fail oracle-credit matching
(gating.py:725–758), explaining a blocking test finding rather than a
return of the old YAML-workflow-removal defect. The two tests' source diff
is empty; this is not caused by changed collection/liveness test inputs.

Classification: **ordinary fixture/consumer migration needed to express a
true unchanged-import-target move**, with an observed bounded-contract cost
for the current fixture. There is no demonstrated D-179 implementation
regression and no missing JS startup-reader adapter in this case.

Next named scope, all NOT_EXECUTED here:

- Review a positive fixture that moves the test while explicitly preserving
  the same canonical producer target, e.g. adjust the destination relative
  specifier to refer back to the original module. Then verify the CI-path
  rule remains warn and the equivalent move can receive its intended credit.
- Keep the current relative-target-changing form as an adjacent control;
  do not turn it into a blanket relocation waiver or suppress test findings
  merely because the old path held a CI role.
- Read and compare the full finding dictionaries during that future bounded
  run. This read-only triage cannot replace them with guessed runtime rows.

## Disposition

Both failures remain real compatibility gate failures in the final suite.
Neither has been relabeled, waived, merged into the eight #567 golden
dispositions or converted to PASS. The analysis supports two named follow-up
reviews, not an immediate code/assertion edit. It makes no claim that every
one of the other twelve unexpected failures has the same cause.
