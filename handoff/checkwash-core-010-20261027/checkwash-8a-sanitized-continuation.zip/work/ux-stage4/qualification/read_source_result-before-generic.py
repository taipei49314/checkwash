"""Independent standard-library readback of completed source qualification only."""
from collections import Counter
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
SOURCE = ROOT / "work/checkwash-ux"
OUT = Path(__file__).resolve().parent / "source-r1"
CAPTURE = ROOT / "work/ux-stage4/final/source-assertion-qualification-r1"
EXPECTED = "8a8941dc2d7c581715a0f6f196c00da6c55f084b"


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


qualification = read(OUT / "qualification.json")
receipt = read(OUT / "receipt.json")
capture = read(CAPTURE / "receipt.json")
ledger = read(OUT / "raw/commands.json")
errors = []
assert qualification["source_commit"] == receipt["source_sha"] == receipt["ending_sha"] == EXPECTED
assert capture["expected_source_sha"] == capture["source_sha"] == capture["ending_sha"] == EXPECTED
assert capture["validation_kind"] == "FIXED_SOURCE_NOT_RELEASE_BRIDGE"
assert qualification["distribution"] == receipt["kind"] == "source"
assert receipt["source_files_unchanged"] and capture["source_files_unchanged"]
assert capture["changed_inputs"] == [] and not qualification["source_package_dirty"]
assert sha(json.dumps(receipt["source_files"], sort_keys=True).encode()) == receipt["source_input_manifest_sha256"]
assert sha((CAPTURE / "input-hashes.json").read_bytes()) == capture["input_manifest_sha256"]
assert (CAPTURE / "source.diff").read_bytes() == b"" and (CAPTURE / "git-status.txt").read_bytes() == b""
assert capture["source_diff_sha256"] == sha(b"")
assert receipt["formal_release_collector"] is False and receipt["published_check_runs"] == 0
summary = qualification["summary"]
assert summary["total"] == 283
assert summary["executed"] == len(qualification["cases"])
assert summary["failed"] == sum(row["status"] != "passed" for row in qualification["cases"])
assert len({row["id"] for row in qualification["cases"]}) == len(qualification["cases"])
assert sha((SOURCE / "tools/qualify_assertions.py").read_bytes()) == receipt["qualifier_sha256"]
for name, digest in receipt["contracts"].items():
    assert sha((SOURCE / name).read_bytes()) == digest
package = SOURCE / "src/checkwash"
members = {
    "checkwash/" + path.relative_to(package).as_posix(): sha(path.read_bytes())
    for path in sorted(package.rglob("*"))
    if path.is_file() and "__pycache__" not in path.parts and path.suffix != ".pyc"
}
package_digest = sha(json.dumps(members, sort_keys=True, separators=(",", ":")).encode())
assert qualification["source_package_sha256"] == package_digest
streams = {stream: (OUT / "raw" / (stream + ".bin")).read_bytes() for stream in ("stdout", "stderr")}
offsets = {stream: 0 for stream in streams}
checks = 0
for command in ledger:
    for stream in streams:
        item = command[stream]
        assert item["path"] == stream + ".bin"
        assert item["offset"] == offsets[stream]
        chunk = streams[stream][item["offset"]:item["offset"] + item["bytes"]]
        assert len(chunk) == item["bytes"] and sha(chunk) == item["sha256"]
        offsets[stream] += item["bytes"]
        checks += 1
assert all(offsets[stream] == len(data) for stream, data in streams.items())
case_commands = [row for row in ledger if "HEAD~1..HEAD" in row["argv"]]
product_commands = [row for row in ledger if any("from checkwash.cli import main" in arg for arg in row["argv"])]
assert len(case_commands) == summary["executed"]
assert all(not row["timed_out"] and row["error"] is None for row in ledger)
assert capture["exit_code"] == receipt["exit_code"]
if qualification["status"] == "passed":
    assert summary == {"total": 283, "executed": 283, "failed": 0}
    assert qualification["errors"] == []
    assert capture["exit_code"] == receipt["exit_code"] == 0
    assert len(product_commands) == summary["executed"] + 3

result = {
    "kind": "READ_ONLY_SOURCE_QUALIFICATION_RESULT_AUDIT_NOT_RELEASE_BRIDGE",
    "provenance": receipt["provenance"], "host": receipt["host"], "runtime": receipt["python"],
    "source_sha": EXPECTED, "qualification_status": qualification["status"], "summary": summary,
    "version": qualification["version"], "source_manifest_files": len(receipt["source_files"]),
    "qualification_errors": qualification["errors"], "exit_code": capture["exit_code"],
    "source_files_unchanged": True, "source_package_sha256": package_digest,
    "suite_sha256": qualification["suite_sha256"], "artifact_sha256": qualification["artifact_sha256"],
    "trusted_trace_source": receipt["trusted_trace_source"], "trusted_trace_sha256": receipt["trusted_trace_sha256"],
    "qualifier_sha256": receipt["qualifier_sha256"], "contracts": receipt["contracts"],
    "recorded_subprocesses": len(ledger), "case_cli_commands": len(case_commands),
    "total_product_cli_commands": len(product_commands),
    "auxiliary_cli_commands": len(product_commands) - len(case_commands),
    "case_exit_counts": dict(Counter(str(row["exit_code"]) for row in case_commands)),
    "raw_stream_slice_hash_checks": checks,
    "raw_stream_full_hashes": {stream: sha(data) for stream, data in streams.items()},
    "qualification_json_sha256": sha((OUT / "qualification.json").read_bytes()),
    "worker_receipt_sha256": sha((OUT / "receipt.json").read_bytes()),
    "outer_receipt_sha256": sha((CAPTURE / "receipt.json").read_bytes()),
    "ledger_sha256": sha((OUT / "raw/commands.json").read_bytes()),
    "formal_release_collector": False, "published_check_runs": 0,
    "product_reexecuted_by_auditor": False,
    "not_run_by_this_leg": ["wheel", "pyz", "full product suite", "formal release bridge", "published checks", "other OS", "Python 3.12/3.13"],
}
(OUT / "independent-readback.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps(result, indent=2))
