"""Save read-only Git/native-JUnit evidence for eight ordinary failure rows."""
import datetime
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[3]
REPO = ROOT / "work/checkwash-ux"
OUT = Path(__file__).resolve().parent / "fullsuite-triage"
OUT.mkdir(exist_ok=False)
(OUT / "raw").mkdir()
BASE, HEAD = "1ffe283d7d947fecc426dea99323b0a2620a9482", "8a8941dc2d7c581715a0f6f196c00da6c55f084b"
TESTS = ["tests/test_js_liveness.py", "tests/test_js_test_obligations.py", "tests/test_root_oracles.py",
         "tests/test_issue223_conftest_request_side.py", "tests/test_issue263_string_conditions.py",
         "tests/test_issue358_own_mark_guards.py", "tests/test_classic_raises_additions.py"]
SOURCES = ["src/checkwash/engine.py", "src/checkwash/gating.py", "src/checkwash/ir/model.py",
           "src/checkwash/oracle_credit.py", "SPEC.md", "DECISIONS.md",
           "tests/test_issue_expectation_families.py", "tests/test_classic_raises_carriers.py"]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def manifest():
    return {name: sha((REPO / name).read_bytes()) for name in TESTS + SOURCES}


before = manifest()
commands, comparisons = [], []
for index, path in enumerate(TESTS):
    blobs = {}
    for label, revision in (("base", BASE), ("head", HEAD)):
        command = ["git", "--no-optional-locks", "-C", str(REPO), "show", revision + ":" + path]
        started = datetime.datetime.now(datetime.timezone.utc).isoformat()
        process = subprocess.run(command, capture_output=True, timeout=60)
        assert process.returncode == 0
        name = f"{index:02d}-{label}"
        for stream in ("stdout", "stderr"):
            (OUT / "raw" / (name + "." + stream)).write_bytes(getattr(process, stream))
        commands.append({"name": name, "command": command, "started_utc": started,
                         "ended_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                         "exit": process.returncode, "stdout_sha256": sha(process.stdout), "stderr_sha256": sha(process.stderr)})
        blobs[label] = process.stdout
    comparisons.append({"path": path, "base_sha256": sha(blobs["base"]), "head_sha256": sha(blobs["head"]),
                        "unchanged_between_fixed_sources": blobs["base"] == blobs["head"],
                        "current_equals_head": (REPO / path).read_bytes() == blobs["head"]})
for path in SOURCES:
    destination = OUT / "source" / path
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes((REPO / path).read_bytes())

junit = ROOT / "work/ux-stage4/final/full-suite-311-r1/junit.xml"
readback = json.loads((junit.parent / "independent-readback.json").read_text(encoding="utf-8"))
selected = [row for row in readback["native_xml_failure_or_error_details"]
            if any(row["nodeid"].startswith(path + "::") for path in TESTS)]
assert len(selected) == 8
native = ET.fromstring(junit.read_bytes())
for row in selected:
    matches = [case for case in native.iter("testcase") if case.attrib == row["xml_attributes"]]
    assert len(matches) == 1
    failures = [failure for failure in matches[0] if failure.tag == row["outcome"]]
    assert any((failure.text or "") == row["text"] and sha((failure.text or "").encode()) == row["text_sha256"]
               for failure in failures)
(OUT / "selected-native-failures.json").write_text(json.dumps(selected, indent=2) + "\n", encoding="utf-8")
after = manifest()
record = {"provenance": "HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL", "host": platform.node(), "runtime": sys.version,
          "mode": "READ_ONLY_STATIC_TRIAGE_NO_PRODUCT_REEXECUTION", "base": BASE, "candidate": HEAD,
          "source_before": before, "source_after": after, "source_unchanged": before == after,
          "test_blob_comparisons": comparisons, "commands": commands,
          "native_junit_sha256": sha(junit.read_bytes()),
          "full_readback_sha256": sha((junit.parent / "independent-readback.json").read_bytes()),
          "selected_failures": len(selected), "product_calls": 0, "pytest_calls": 0}
assert record["source_unchanged"] and all(row["current_equals_head"] for row in comparisons)
(OUT / "receipt.json").write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"selected": len(selected), "unchanged_test_files": sum(row["unchanged_between_fixed_sources"] for row in comparisons),
                  "source_unchanged": record["source_unchanged"], "git_read_commands": len(commands)}, indent=2))
