"""Freeze derived read-only triage, preserving original failed-suite evidence."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
OUT = HERE / "fullsuite-triage"
ROOT = HERE.parents[2]
REPO = ROOT / "work/checkwash-ux"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


receipt = json.loads((OUT / "receipt.json").read_text(encoding="utf-8"))
selected = json.loads((OUT / "selected-native-failures.json").read_text(encoding="utf-8"))
native = ROOT / "work/ux-stage4/final/full-suite-311-r1"
assert sha(native / "junit.xml") == receipt["native_junit_sha256"]
assert sha(native / "independent-readback.json") == receipt["full_readback_sha256"]
assert all(sha(REPO / name) == value for name, value in receipt["source_before"].items())
assessments = []
for failure in selected:
    node = failure["nodeid"]
    if "test_classic_raises_additions.py" in node:
        classification = "DEFINITE_IR3_METADATA_CONSUMER_MIGRATION"
        observed = "Exception evidence, BLOCK and ASSERT_REMOVED checks passed; whole-UnitSide equality differs only on the two new proof fields, with 17 old fields identical."
        next_scope = "INERT_PROPOSAL_ONLY: exact native fields plus separately checked IR3 enrichment."
    elif "test_root_oracles.py" in node:
        classification = "STARTUP_READ_OBSERVER_CONTRACT_MIGRATION"
        observed = "BLOCK, ASSERT_REMOVED/high/path/text and search assertions passed; exact reader list has three additional items, first tests/conftest.py."
        next_scope = "INERT_PROPOSAL_ONLY: distinguish optional D179 startup probes and preserve main detector/read-budget controls."
    elif "test_issue223_conftest_request_side.py" in node:
        classification = "STARTUP_READ_OBSERVER_CONTRACT_MIGRATION"
        observed = "BLOCK and ASSERT_REMOVED/path assertions passed; conftest read list additionally contains tests/conftest.py. This test did not assert the severity."
        next_scope = "INERT_PROPOSAL_ONLY: distinguish proof startup probes from original detector-chain semantics."
    elif "test_js_test_obligations.py" in node:
        classification = "POSITIVE_FIXTURE_DOES_NOT_PRESERVE_RELATIVE_PRODUCER"
        observed = "Expected PASS, observed BLOCK; full actual finding vector was not printed."
        next_scope = "INERT_PROPOSAL_ONLY: same canonical producer positive, retain changed-relative-target negative."
    else:
        classification = "UNRESOLVED_ORDINARY_POSITIVE_COMPATIBILITY_COST"
        observed = "Expected PASS, observed BLOCK. Source explanation is a bounded-context inference, not a new execution."
        next_scope = "PRESERVE_EXPECTATION: safe-proof expansion or explicit maintainer disposition remains pending."
    assessments.append({"nodeid": node, "classification": classification, "observed_native_result": observed,
                        "next_scope": next_scope, "native_text_sha256": failure["text_sha256"],
                        "new_product_run_performed": False})
assert len(assessments) == 8
external = {"fullsuite-triage-js.md": "c57f28d9ca8a073e388c714f342ab47e8a3090b396ebae75d2463c2ee3e71e46",
            "fullsuite-triage-js-evidence.json": "d2294cac8e7b4b1917b016702f4fb7fc2357ccc9dd3bfa737d7e125e12bdcfcb"}
for name, value in external.items():
    assert sha(HERE / name) == value
result = {"state": "READ_ONLY_TRIAGE_COMPLETE_FAILURES_REMAIN", "source": receipt["candidate"],
          "full_suite_state": "COMPLETE_FAILED_SUITE", "suite_exit": 1,
          "summary": {"failed_parents": 22, "passed_parents": 21055, "skipped_parents": 25,
                      "subtests_passed": 67, "native_xml_reports": 21169, "native_xml_parents": 21102},
          "selected_ordinary_rows": assessments, "existing_test_files_unchanged": True,
          "product_calls": 0, "pytest_calls": 0, "source_or_expected_labels_modified": False,
          "external_artifacts_sha256": external, "collector_sha256": sha(HERE / "collect_fullsuite_triage.py"),
          "source_unchanged_after_triage": True}
(OUT / "assessment.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
members = {path.relative_to(OUT).as_posix(): sha(path) for path in sorted(OUT.rglob("*"))
           if path.is_file() and path.name != "MANIFEST.json"}
(OUT / "MANIFEST.json").write_text(json.dumps({"state": "FROZEN_STAGE4_READ_ONLY_TRIAGE",
                                              "members": members}, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"report_sha256": sha(OUT / "report.md"), "assessment_sha256": sha(OUT / "assessment.json"),
                  "manifest_sha256": sha(OUT / "MANIFEST.json"), "members": len(members)}, indent=2))
