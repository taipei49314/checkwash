"""Cross-file decorator-change counterexample; static CLI analysis only."""
from pathlib import Path
import shutil
import reproduce

original = reproduce.HERE
reproduce.HERE = original / "supplement"
reproduce.HERE.mkdir(exist_ok=True)
for label in reproduce.SOURCES:
    shutil.copyfile(original / ("source-" + label + ".zip"), reproduce.HERE / ("source-" + label + ".zip"))
reproduce.CASES = {
    "cross_file_param_changed": (reproduce.BASE, reproduce.BASE.replace("(10,20)", "(10,999999)"), True,
                                 ["D-rename-evasion/#7-1b", "B2-git-worktree/#8"]),
}
reproduce.main()
