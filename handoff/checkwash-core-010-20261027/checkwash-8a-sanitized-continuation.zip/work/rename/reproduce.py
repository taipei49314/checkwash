"""Fixed-source static CLI reproductions. Fixture code is never executed."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import platform
import socket
import subprocess
import sys
import zipfile

HERE = Path(__file__).resolve().parent
SOURCES = {
    "v091": "1ffe283d7d947fecc426dea99323b0a2620a9482",
    "v090": "d6eda4f695fabb8e7d138f7a87b099d2028f0294",
}
BASE = '''import pytest
from calc import calc

@pytest.mark.parametrize("x,expected", [(10,20), (20,40), (30,60)])
def test_calc(x, expected):
    assert calc(x) == expected
'''
A = '''from calc import calc

def test_checkout():
    x = 10
    expected = 999999
    assert calc(x) == expected
'''
B = '''import pytest
from calc import calc

@pytest.mark.parametrize("x,expected", [(0,0), (0,0), (0,0)])
def test_checkout_v2(x, expected):
    res = calc(x)
    assert res == 0
'''
UNROLL_BAD = '''from calc import calc

def test_checkout():
    assert calc(10) == 25
    assert calc(20) == 45
    assert calc(30) == 65
'''
CASES = {
    "A": (BASE, A, False, ["D-rename-evasion/#7-A", "D-rename-evasion/#7-2d"]),
    "B": (BASE, B, False, ["D-rename-evasion/#7-B", "D-rename-evasion/#7-3c"]),
    "B_from_A": (A, B, False, ["D-rename-evasion/#7-3c"]),
    "N_unroll_changed": (BASE, UNROLL_BAD, False, ["D-rename-evasion/#7-N"]),
    "control_rename_only": (BASE, BASE.replace("def test_calc(", "def test_checkout("), False, []),
    "control_unroll_preserved": (BASE, UNROLL_BAD.replace("== 25", "== 20").replace("== 45", "== 40").replace("== 65", "== 60"), False, []),
    "control_same_name_changed": (BASE, A.replace("def test_checkout(", "def test_calc("), False, []),
    "control_cross_file_move": (BASE, BASE, True, ["D-rename-evasion/#7-1b"]),
}

def run(cmd, cwd, env, raw):
    p = subprocess.run(cmd, cwd=cwd, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=90)
    raw.parent.mkdir(parents=True, exist_ok=True)
    raw.with_suffix(".stdout").write_bytes(p.stdout)
    raw.with_suffix(".stderr").write_bytes(p.stderr)
    meta = {"command": cmd, "cwd": str(cwd), "exit": p.returncode,
            "stdout_sha256": hashlib.sha256(p.stdout).hexdigest(),
            "stderr_sha256": hashlib.sha256(p.stderr).hexdigest(),
            "stdout": str(raw.with_suffix(".stdout").relative_to(HERE)),
            "stderr": str(raw.with_suffix(".stderr").relative_to(HERE))}
    raw.with_suffix(".meta.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    return p, meta

def git(args, cwd, env):
    p = subprocess.run(["git", *args], cwd=cwd, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
    if p.returncode:
        raise RuntimeError(p.stderr.decode("utf-8", "replace"))
    return p.stdout.decode("ascii").strip()

def write(root, path, text):
    target = root / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(text.encode("utf-8"))

def main():
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", PYTHONUTF8="1")
    results = []
    for label, sha in SOURCES.items():
        source = HERE / ("source-" + label)
        source.mkdir(exist_ok=True)
        with zipfile.ZipFile(HERE / ("source-" + label + ".zip")) as archive:
            archive.extractall(source)
        cli_env = dict(env, PYTHONPATH=str(source / "src"))
        for name, (before, after, move, claims) in CASES.items():
            for freeze in (False, True):
                case_label = f"{label}/{name}/{'freeze' if freeze else 'default'}"
                repo = HERE / "repos" / label / name / ("freeze" if freeze else "default")
                repo.mkdir(parents=True, exist_ok=False)
                git(["init", "-q"], repo, env)
                git(["config", "core.autocrlf", "false"], repo, env)
                git(["config", "user.name", "Static Reproduction"], repo, env)
                git(["config", "user.email", "static-reproduction@example.invalid"], repo, env)
                write(repo, "tests/test_calc.py", before)
                write(repo, "calc.py", "def calc(x):\n    return x * 2\n")
                write(repo, "TASK.md", "---\ncheckwash:\n  oracle_freeze: " + str(freeze).lower() + "\n---\n")
                git(["add", "."], repo, env)
                git(["-c", "core.hooksPath=NUL", "commit", "-qm", "base"], repo, env)
                base = git(["rev-parse", "HEAD"], repo, env)
                if move:
                    (repo / "tests/test_calc.py").unlink()
                    write(repo, "tests/test_moved.py", after)
                else:
                    write(repo, "tests/test_calc.py", after)
                for entry in ("worktree", "range"):
                    head = None
                    if entry == "range":
                        git(["add", "."], repo, env)
                        git(["-c", "core.hooksPath=NUL", "commit", "-qm", "candidate"], repo, env)
                        head = git(["rev-parse", "HEAD"], repo, env)
                    cmd = [sys.executable, "-B", "-m", "checkwash", "check"]
                    if entry == "range":
                        cmd.append(base + ".." + head)
                    cmd += ["--repo", str(repo), "--task", str(repo / "TASK.md"), "--format", "json"]
                    raw = HERE / "raw" / case_label / entry
                    p, receipt = run(cmd, repo, cli_env, raw)
                    payload = json.loads(p.stdout)
                    results.append({"source_label": label, "source_sha": sha, "case": name,
                        "claims": claims, "oracle_freeze": freeze, "entry": entry,
                        "base": base, "head": head, "exit": p.returncode,
                        "verdict": payload.get("verdict"), "summary": payload.get("summary"),
                        "config_errors": payload.get("config_errors"),
                        "skipped_files": payload.get("skipped_files"),
                        "findings": payload.get("findings"), "receipt": receipt})
                    print(case_label, entry, p.returncode, payload.get("verdict"),
                          [(f["rule"], f["severity"], f.get("deescalators"), f.get("escalators")) for f in payload.get("findings", [])], flush=True)
    manifest = {"marker": "HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL", "hostname": socket.gethostname(),
        "platform": platform.platform(), "python": sys.version, "python_executable": sys.executable,
        "git": git(["--version"], HERE, env), "fixture_execution": "NOT_RUN; static CLI analysis only",
        "source_archives": {label: {"sha": sha, "archive_sha256": hashlib.sha256((HERE / ("source-" + label + ".zip")).read_bytes()).hexdigest()} for label, sha in SOURCES.items()},
        "results": results}
    (HERE / "results.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")

if __name__ == "__main__":
    main()
