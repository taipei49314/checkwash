"""Create deterministic task-only derivatives of three preserved evidence ZIPs.

Default: write a plan only. --apply writes new sanitized ZIPs and sidecars;
it never changes originals, source, labels, root START-HERE/status, or a remote.
No product module, analyzed fixture, model or qualification is executed.
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import stat
import tarfile
import zipfile
import zlib

HERE = Path(__file__).resolve().parent
SESSION = HERE.parents[2]
INPUT = SESSION / "outputs"
OUTPUT = INPUT / "checkwash-core-010-handoff-20261027"
STATUS = "SANITIZED_HISTORICAL_BACKUP_NOT_ACCEPTANCE_NOT_FULL_HISTORY_REPLAY"
CASES = (
    ("stage1", "checkwash-ux-milestone-20261026.zip",
     "e6466727b1eeea9d964bc137b201f57d6e2e23ade4325dd509f373f32c377096",
     "global-AGENTS.snapshot.md"),
    ("stage2", "checkwash-ux-stage2-20261026.zip",
     "c39a09b4ee8c0c3747d8ca6d0ce8a61482eb4e972ada640acce035a7a48d85a4",
     "context/global-AGENTS.md"),
    ("stage3", "checkwash-ux-stage3-20261026.zip",
     "d63425e79e3d7384fb4b73f11b2f562186b80db805f49d16c57de72e0a7f92a2",
     "context/global-AGENTS.md"),
)
ORIGINAL_HASHES = {row[2] for row in CASES}
PRIVATE_MARKERS = (
    b"# Local Codex " + b"project memory",
    b"## PJU " + "現行執行規則".encode(),
)
KEY_SHAPES = (
    re.compile(rb"-----BEGIN (?:[A-Z ]+ )?PRIVATE KEY-----"),
    re.compile(rb"\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{40,})\b"),
    re.compile(rb"\bsk-(?:proj-)?[A-Za-z0-9_-]{30,}\b"),
    re.compile(rb"\bAKIA[0-9A-Z]{16}\b"),
)
MAX_MEMBER = 64 * 1024 * 1024
MAX_ARCHIVE_UNCOMPRESSED = 512 * 1024 * 1024
USERINFO = re.compile(rb'https?://[^\s/"<>]+:[^\s/"<>]+@')
SYNTHETIC_URLS = set()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=True) + "\n").encode()


def safe_name(name):
    path = PurePosixPath(name)
    if (not name or "\\" in name or path.is_absolute() or ".." in path.parts
            or any(char in name for char in (":", "\r", "\n", "\0"))):
        raise ValueError("unsafe archive-relative name")
    return path.as_posix()


def private_memory(raw, name, depth=0):
    """Return a reason only. Never export matching content, values or hashes."""
    base = PurePosixPath(name).name.lower()
    if (("global" in base and "agent" in base) or "github-memory-2026" in base
            or "private-memory" in base):
        return "private-memory-filename"
    if any(marker in raw for marker in PRIVATE_MARKERS):
        return "private-global-memory-content"
    if sha(raw) in ORIGINAL_HASHES:
        return "known-original-archive-containing-private-context"
    if depth >= 4:
        raise ValueError("nested archive inspection bound reached")
    stream = io.BytesIO(raw)
    if zipfile.is_zipfile(stream):
        with zipfile.ZipFile(stream) as archive:
            entries = archive.infolist()
            if sum(info.file_size for info in entries) > MAX_ARCHIVE_UNCOMPRESSED:
                raise ValueError("nested archive inspection size bound reached")
            for info in entries:
                if info.is_dir():
                    continue
                safe_name(info.filename)
                if info.file_size > MAX_MEMBER or info.flag_bits & 1:
                    raise ValueError("oversized or encrypted nested archive member")
                if stat.S_ISLNK(info.external_attr >> 16):
                    raise ValueError("nested archive link member refused")
                reason = private_memory(archive.read(info), info.filename, depth + 1)
                if reason:
                    return "nested-archive-contains-private-memory"
    elif name.lower().endswith((".tar", ".tar.gz", ".tgz")):
        with tarfile.open(fileobj=stream, mode="r:*") as archive:
            entries = archive.getmembers()
            if sum(info.size for info in entries) > MAX_ARCHIVE_UNCOMPRESSED:
                raise ValueError("nested tar inspection size bound reached")
            for info in entries:
                if info.isdir():
                    continue
                safe_name(info.name)
                if not info.isfile() or info.size > MAX_MEMBER:
                    raise ValueError("nonregular or oversized nested tar member refused")
                source = archive.extractfile(info)
                reason = private_memory(source.read(), info.name, depth + 1)
                if reason:
                    return "nested-archive-contains-private-memory"
    return None


def key_marker(raw, name="", depth=0):
    if (any(pattern.search(raw) for pattern in KEY_SHAPES)
            or any(value not in SYNTHETIC_URLS for value in USERINFO.findall(raw))):
        return True
    if depth >= 4:
        raise ValueError("nested credential inspection bound reached")
    stream = io.BytesIO(raw)
    if zipfile.is_zipfile(stream):
        with zipfile.ZipFile(stream) as archive:
            return any(key_marker(archive.read(info), info.filename, depth + 1)
                       for info in archive.infolist() if not info.is_dir())
    if name.lower().endswith((".tar", ".tar.gz", ".tgz")):
        with tarfile.open(fileobj=stream, mode="r:*") as archive:
            return any(key_marker(archive.extractfile(info).read(), info.name, depth + 1)
                       for info in archive.getmembers() if info.isfile())
    return False


def admit_synthetic_url_test_literals():
    """Allow only URL-shaped refusal fixtures verified against sealed source."""
    seal = json.loads((HERE.parent / "seal/source-seal.json").read_bytes())
    rows = {row["path"]: row for row in seal["files"]}
    if seal["source_sha"] != "8a8941dc2d7c581715a0f6f196c00da6c55f084b":
        raise ValueError("unexpected synthetic fixture source seal")
    for name in ("tests/test_collect_pju_release.py", "tests/test_sweep_commit_diagnostics.py"):
        raw = (SESSION / "work/checkwash-ux" / name).read_bytes()
        if sha(raw) != rows[name]["sha256"]:
            raise ValueError("synthetic URL reference differs from sealed source")
        SYNTHETIC_URLS.update(USERINFO.findall(raw))


def plan_all():
    admit_synthetic_url_test_literals()
    plans = []
    private_reference = None
    for stage, filename, expected_hash, global_tail in CASES:
        source = INPUT / filename
        original = source.read_bytes()
        if sha(original) != expected_hash:
            raise ValueError("preserved original archive hash differs: " + filename)
        if (INPUT / (filename + ".sha256")).read_text(encoding="ascii").split()[0] != expected_hash:
            raise ValueError("preserved original sidecar differs: " + filename)
        kept, excluded, review = [], [], []
        with zipfile.ZipFile(io.BytesIO(original)) as archive:
            infos = archive.infolist()
            if archive.testzip() is not None:
                raise ValueError("original archive CRC failed: " + filename)
            if sum(info.file_size for info in infos) > MAX_ARCHIVE_UNCOMPRESSED:
                raise ValueError("original archive inspection size bound reached")
            names = [safe_name(info.filename) for info in infos]
            if len(names) != len(set(names)):
                raise ValueError("duplicate original archive member name")
            roots = {PurePosixPath(name).parts[0] for name in names}
            if len(roots) != 1:
                raise ValueError("expected one preserved package root")
            prefix = next(iter(roots))
            expected_global = prefix + "/" + global_tail
            if expected_global not in names:
                raise ValueError("expected private reference member is absent")
            for info in infos:
                name = safe_name(info.filename)
                if info.is_dir():
                    excluded.append({"path": name, "bytes": 0, "reason": "directory-entry-only"})
                    continue
                if info.file_size > MAX_MEMBER or info.flag_bits & 1:
                    raise ValueError("oversized or encrypted original member")
                if stat.S_ISLNK(info.external_attr >> 16):
                    raise ValueError("original archive link member refused")
                raw = archive.read(info)
                if name == expected_global:
                    if len(raw) != 15137:
                        raise ValueError("private reference byte size differs")
                    if private_reference is None:
                        private_reference = raw
                    elif raw != private_reference:
                        raise ValueError("preserved private references differ")
                    excluded.append({"path": name, "bytes": len(raw),
                                     "reason": "exact-global-agent-memory-local-only"})
                    continue
                reason = private_memory(raw, name)
                if reason:
                    excluded.append({"path": name, "bytes": len(raw), "reason": reason})
                    continue
                if key_marker(raw, name):
                    review.append({"path": name, "bytes": len(raw),
                                   "reason": "credential-shaped-marker-needs-local-review-no-value-exported"})
                kept.append({"path": name, "bytes": len(raw), "sha256": sha(raw)})
            if prefix + "/MANIFEST.json" not in {row["path"] for row in kept}:
                raise ValueError("original manifest must be retained as historical inventory")
            if any(row["path"].endswith("/AGENTS.md") or row["path"].endswith("/repository-AGENTS.snapshot.md")
                   for row in excluded if row["path"] != expected_global):
                raise ValueError("repository-owned instruction member unexpectedly excluded")
        plans.append({"stage": stage, "status": STATUS, "source_archive": filename,
            "source_archive_sha256": expected_hash, "source_archive_bytes": len(original),
            "package_root": prefix, "retained_original_files": sorted(kept, key=lambda row: row["path"]),
            "exclusions": sorted(excluded, key=lambda row: row["path"]),
            "private_review_flags": review, "output_name": "legacy-" + stage + "-sanitized.zip",
            "original_manifest_role": "HISTORICAL_UNMODIFIED_INVENTORY_NOT_SANITIZED_PACKAGE_VALIDATION"})
    return plans


def metadata(plan):
    root = plan["package_root"] + "/"
    readme = ("# Sanitized historical task evidence — backup only\n\n"
        + STATUS + "\n\n"
        + "This archive is a new deterministic derivative, not the original sealed ZIP.\n"
        + "Original archives remain unchanged locally. Exact private global-context files\n"
        + "and nested original packages containing that context are intentionally omitted.\n"
        + "Exclusion records contain relative names, byte lengths and reasons only.\n\n"
        + "All retained original file bytes, including repository-owned instruction files,\n"
        + "are unchanged. The original MANIFEST.json is retained as a HISTORICAL inventory;\n"
        + "its references to intentionally omitted files do not validate this derivative.\n"
        + "Use SANITIZED-MANIFEST.json and SANITIZATION-EXCLUSIONS.json for this archive.\n\n"
        + "No product, fixture program, gate or modified judge was executed by sanitization.\n"
        + "Historical source/runtime, failures, partial results and proposal status remain\n"
        + "historical. New byte hashes do not reclassify them as accepted or passing.\n"
        + "This is not a self-contained replay of every historical run: runtimes, private\n"
        + "context and nested original packages remain local. Read the parent handoff's\n"
        + "START-HERE/status for current candidate state. Backup timing is not release\n"
        + "urgency; no merge, tag, publication, exemption or version1.0 permission is given.\n").encode()
    exclusions = encoded({"status": STATUS, "excluded": plan["exclusions"],
        "originals_unchanged": True, "global_memory_content_exported": False,
        "metadata_scope": "relative member name, bytes and reason only for exclusions"})
    manifest = encoded({"status": STATUS, "source_archive": plan["source_archive"],
        "source_archive_sha256": plan["source_archive_sha256"],
        "source_archive_bytes": plan["source_archive_bytes"],
        "original_manifest_role": plan["original_manifest_role"],
        "retained_original_file_count": len(plan["retained_original_files"]),
        "files": plan["retained_original_files"],
        "added_metadata_files": [
            {"path": root + "SANITIZED-README.md", "bytes": len(readme), "sha256": sha(readme)},
            {"path": root + "SANITIZATION-EXCLUSIONS.json", "bytes": len(exclusions), "sha256": sha(exclusions)}],
        "manifest_self_excluded": True, "archive_format": "fixed1980/sorted/regular0644/deflate9",
        "zlib": zlib.ZLIB_VERSION, "acceptance_reclassification": False,
        "product_or_fixture_test_calls": 0, "publication_performed": False})
    return {root + "SANITIZED-README.md": readme, root + "SANITIZATION-EXCLUSIONS.json": exclusions,
            root + "SANITIZED-MANIFEST.json": manifest}


def write_zip(stream, plan):
    extra = metadata(plan)
    originals = {row["path"]: row for row in plan["retained_original_files"]}
    with zipfile.ZipFile(INPUT / plan["source_archive"]) as source:
        with zipfile.ZipFile(stream, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as target:
            for name in sorted(set(originals) | set(extra)):
                if name in extra:
                    raw = extra[name]
                else:
                    raw = source.read(name)
                    if len(raw) != originals[name]["bytes"] or sha(raw) != originals[name]["sha256"]:
                        raise ValueError("original member changed during derivative write")
                info = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0))
                info.create_system = 3
                info.external_attr = (stat.S_IFREG | 0o644) << 16
                info.compress_type = zipfile.ZIP_DEFLATED
                target.writestr(info, raw, compresslevel=9)


def validate(path, plan):
    extra = metadata(plan)
    expected = {row["path"]: row for row in plan["retained_original_files"]}
    with zipfile.ZipFile(path) as archive:
        if archive.testzip() is not None:
            raise ValueError("sanitized derivative CRC failed")
        infos = archive.infolist()
        names = [info.filename for info in infos]
        if names != sorted(set(expected) | set(extra)):
            raise ValueError("sanitized derivative membership/order differs")
        for info in infos:
            raw = archive.read(info)
            if info.date_time != (1980, 1, 1, 0, 0, 0) or info.external_attr >> 16 != stat.S_IFREG | 0o644:
                raise ValueError("sanitized derivative metadata differs")
            if info.filename in extra:
                if raw != extra[info.filename]:
                    raise ValueError("sanitized metadata bytes differ")
            else:
                row = expected[info.filename]
                if len(raw) != row["bytes"] or sha(raw) != row["sha256"]:
                    raise ValueError("retained original bytes changed")
                if private_memory(raw, info.filename) or key_marker(raw, info.filename):
                    raise ValueError("sanitized derivative private-marker readback failed")
    # Rebuild in memory with the same runtime and compare actual archive bytes.
    again = io.BytesIO()
    write_zip(again, plan)
    if sha(again.getvalue()) != sha(path.read_bytes()):
        raise ValueError("sanitized derivative is not deterministic")
    return {"crc": "PASS", "retained_original_hashes": "MATCH", "metadata": "FIXED",
            "membership_sorted": True, "private_marker_readback": "NO_FLAGS",
            "same_runtime_deterministic_rebuild": True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()
    HERE.mkdir(parents=True, exist_ok=True)
    plans = plan_all()
    plan_document = {"mode": "PLAN_ONLY" if not args.apply else "AUTHORIZED_SANITIZED_DERIVATIVES",
        "status": STATUS, "product_or_fixture_test_calls": 0, "originals_modified": False,
        "plans": plans}
    (HERE / "legacy-selection-plan.json").write_bytes(encoded(plan_document))
    if any(plan["private_review_flags"] for plan in plans):
        print(json.dumps({"mode": "LOCAL_REVIEW_REQUIRED", "flags": [
            {"stage": plan["stage"], "members": plan["private_review_flags"]}
            for plan in plans if plan["private_review_flags"]]}))
        return 2
    if not args.apply:
        print(json.dumps({"mode": "PLAN_ONLY", "packages": [
            {"stage": plan["stage"], "retained": len(plan["retained_original_files"]),
             "excluded": plan["exclusions"]} for plan in plans]}, indent=2))
        return 0
    OUTPUT.mkdir(parents=True, exist_ok=True)
    results = []
    for plan in plans:
        target = OUTPUT / plan["output_name"]
        sidecar = OUTPUT / (plan["output_name"] + ".sha256")
        if target.exists() or sidecar.exists():
            raise ValueError("fresh sanitized output required; existing file is never overwritten")
        with target.open("xb") as output:
            write_zip(output, plan)
        readback = validate(target, plan)
        digest = sha(target.read_bytes())
        with sidecar.open("x", encoding="ascii", newline="\n") as output:
            output.write(digest + "  " + target.name + "\n")
        results.append({"stage": plan["stage"], "archive": target.name,
            "bytes": target.stat().st_size, "sha256": digest,
            "retained_original_files": len(plan["retained_original_files"]),
            "added_metadata_files": 3, "exclusions": plan["exclusions"], "validation": readback})
    # Verify all original archives and sidecars again after writing new files.
    for _stage, filename, digest, _tail in CASES:
        if sha((INPUT / filename).read_bytes()) != digest or (INPUT / (filename + ".sha256")).read_text().split()[0] != digest:
            raise ValueError("original archive/sidecar changed")
    (HERE / "legacy-sanitized-results.json").write_bytes(encoded({"status": STATUS,
        "originals_unchanged": True, "root_START_HERE_status_untouched": True,
        "product_or_fixture_test_calls": 0, "publication_performed": False,
        "archives": results}))
    print(json.dumps({"mode": "SANITIZED_DERIVATIVES_CREATED_NOT_PUBLISHED", "archives": results}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
