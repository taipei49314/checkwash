# Sanitized checkpoint preparation

`pack_checkpoint.py` defaults to **plan only**. It writes the selected files,
hashes and classifications here, while excluding this controller directory,
`remote-checkpoint`, runtimes, caches and rebuildable source/fixture trees.
Named `pytest-context-*` red/green evidence is retained. Legacy sanitized ZIPs
are handled separately by `legacy_sanitize.py`; original ZIPs stay unchanged.

Run with the existing task-local Python and `-I -B -X utf8`. No product or
fixture program is executed. Do not run `--pack` before root supplies the
active qualification / full-suite terminal state. NOT_RUN and failed outcomes
can be honestly backed up; they do not become PASS.

Example terminal-state schema (replace nulls using actual receipt hashes):

```json
{
  "source_sha": "8a8941dc2d7c581715a0f6f196c00da6c55f084b",
  "all_active_jobs_terminal": false,
  "root_confirmed_pack": false,
  "roles": {
    "qualification_source": {"state": "TERMINAL", "receipt": null, "sha256": null},
    "qualification_wheel": {"state": "TERMINAL", "receipt": null, "sha256": null},
    "qualification_pyz": {"state": "TERMINAL", "receipt": null, "sha256": null},
    "full_suite": {"state": "NOT_RUN", "reason": "Replace with the actual state/reason"}
  }
}
```

After root confirms the actual status:

```text
python -I -B -X utf8 work/ux-stage4/checkpoint-pack/pack_checkpoint.py --pack --terminal-state TERMINAL.json --out outputs/checkwash-core-010-handoff-20261027
```

The ZIP preserves the task-relative `work/ux-stage4`, `work/trusted`,
`work/rename` and selected `work/ux-stage2/final-compat` layout. It excludes the
output folder's root-owned `00-START-HERE.md` / `checkpoint.json` from its inputs.
Only three controller files are copied explicitly to `BUNDLE-TOOLS/` with
hashes: this README, the packer and the stable legacy sanitizer. Their restore
location is `work/ux-stage4/checkpoint-pack/`; the controller directory itself,
its plans and generated outputs remain excluded from evidence selection.
Restoration requires fetching both exact Git objects 8a8941dc and 1ffe283d;
the source ZIP alone is not a Git-history backup. This is a current-source
continuation subset, not a complete historical replay environment.

On Windows, begin with a fresh `clone --no-checkout`. Before checking out
exact 8a, set `core.autocrlf=false` and `core.eol=lf` in this task repository
(`git -C work/checkwash-ux config --local ...`), or pass both options with
`-c` to the checkout command. Do not alter host-global Git settings. Then
verify all 3,084 tracked members against `work/ux-stage4/seal/source-seal.json`,
including membership, raw byte lengths/SHA256 and computed Git blob identities.
An exact commit and clean `git status` alone do not prove physical-byte equality.

Backup timing is separate from product release timing. The controller does
not push, tag, publish, change labels, or waive acceptance gates.
