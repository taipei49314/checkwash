# Continuation backup / restore map

Extract this ZIP into a new task workspace root. Keep the archived paths:
`work/ux-stage4/`, `work/trusted/`, `work/rename/`, and the selected
`work/ux-stage2/final-compat/` dependencies. Do not flatten them.
The three explicitly whitelisted `BUNDLE-TOOLS/` files are controller source,
not evidence-directory copies. To reuse them, copy them to
`work/ux-stage4/checkpoint-pack/` before invoking the packer. The rest of the
controller/remote-checkpoint directories, plans and output archives are absent.

Restore a Git checkout at `work/checkwash-ux`, fetch the exact objects
`8a8941dc2d7c581715a0f6f196c00da6c55f084b` and `1ffe283d7d947fecc426dea99323b0a2620a9482`, then check out the former. The sealed source ZIP
preserves bytes; extracting it alone does not supply Git history or the 1ffe
object required by the audited helper. Recreate task-local runtimes from the
retained dependency/runtime receipts. Global memory and host runtimes are absent.

For a fresh Windows checkout, clone with `--no-checkout` and choose LF before
materializing files. Use task-repository settings `core.autocrlf=false` and
`core.eol=lf` (`git -C work/checkwash-ux config --local ...`), or pass both
`-c core.autocrlf=false -c core.eol=lf` to the command that checks out exact 8a.
Do not change host-global Git settings. A clean Git status can still hide
different physical line endings. After checkout, verify all 3,084 tracked
members against `work/ux-stage4/seal/source-seal.json`: exact membership,
raw byte lengths/SHA256 and computed Git blob identities must match, rather
than relying only on the commit ID or clean status.

This is a sanitized continuation subset, not a self-contained replay of every
historical red run. Original local evidence remains unchanged. Eight existing
golden expectation costs, failed/NOT_RUN outcomes, and inert proposals retain
their recorded status. Backup scheduling does not impose a product release
deadline or waive acceptance/publication gates.

ZIP timestamps and file modes are fixed; paths are sorted; Deflate level9 is
used. Identical inputs, packer and Python/zlib runtime yield identical bytes.
Only bounded privacy checks are supplied, not a universal secret-free claim.
