"""Verify native terminal evidence and create the separate stage-2 package."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'outputs/checkwash-ux-stage2-20261026'
HEAD = '9a5a27f44c895ba2fdee8c83a6313baf0e120873'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

receipt = json.loads((OUT / 'evidence/root/final-fullsuite-r2/receipt.json').read_text(encoding='utf-8'))
assert receipt['source_sha'] == receipt['ending_sha'] == HEAD
assert receipt['exit_code'] == 0 and receipt['source_files_unchanged']
assert receipt['source_diff_sha256'] == hashlib.sha256(b'').hexdigest()
xml = ET.parse(OUT / 'evidence/root/final-fullsuite-r2/junit.xml')
cases = list(xml.iter('testcase'))
metrics = {'testcase_nodes': len(cases), 'skipped_nodes': sum(c.find('skipped') is not None for c in cases),
    'failed_nodes': sum(c.find('failure') is not None for c in cases),
    'error_nodes': sum(c.find('error') is not None for c in cases),
    'native_suite_attributes': [node.attrib for node in xml.iter('testsuite')]}
assert metrics['failed_nodes'] == metrics['error_nodes'] == 0
assert metrics['testcase_nodes'] == 20858, 'Native case nodes must match the separately collected denominator'
metrics['passed_testcase_nodes'] = metrics['testcase_nodes'] - metrics['skipped_nodes']
metrics['basis'] = 'Native XML read only; original producer totals include subtests and are not rewritten.'
(OUT / 'native-suite-summary.json').write_text(json.dumps(metrics, indent=2), encoding='utf-8')
stdout = (OUT / 'evidence/root/final-fullsuite-r2/stdout.txt').read_text(encoding='utf-8')
terminal = next(line.strip() for line in reversed(stdout.splitlines()) if ' passed' in line and ' in ' in line)
assert not re.search(r'\b(?:failed|error|errors)\b', terminal)
action = json.loads((OUT / 'evidence/final-action-r2/replay.json').read_text(encoding='utf-8'))
assert action['status'] == 'completed' and action['head_sha'] == HEAD and not action['errors']
assert all(s['exit_code'] == 0 for s in action['steps'])
assert 'summary: critical=0 high=0 warn=4 info=0 verdict=pass' in (
    OUT / 'evidence/final-action-r2/runtime-receipts/stdout.txt').read_text(encoding='utf-8')
candidate = json.loads((OUT / 'evidence/root/final-cli-selfdogfood/stdout.txt').read_text(encoding='utf-8'))
assert candidate['verdict'] == 'pass'
assert candidate['summary'] == {'critical': 0, 'high': 0, 'info': 0, 'warn': 4}
assert candidate['config_errors'] == candidate['skipped_files'] == []
compat = json.loads((OUT / 'evidence/final-compat/comparison.json').read_text(encoding='utf-8'))
assert compat['cli_calls'] == 36 and compat['comparison_count'] == 72
assert compat['differing_pairs'] == 0
assert compat['source_sha'] == HEAD and compat['source_unchanged'] and compat['old_inputs_unchanged']
assert len(compat['comparisons']) == 72
assert {row['baseline_source'] for row in compat['comparisons']} == {
    'd6eda4f695fabb8e7d138f7a87b099d2028f0294', '1ffe283d7d947fecc426dea99323b0a2620a9482'}
assert all(row['candidate_source'] == HEAD for row in compat['comparisons'])
assert all(not row['differences'] for row in compat['comparisons'])
report = (ROOT / 'work/ux-stage2/report-draft.md').read_text(encoding='utf-8')
report = report.replace('{{FULL_SUITE}}', terminal + '；exit0')
report = report.replace('{{COMPAT}}', '候選36次CLI對兩個舊基線的72次逐項配對均相同（exit／verdict／完整findings含fingerprint／config_errors／skipped_files）')
assert '{{' not in report and '\ufffd' not in report
(OUT / 'report.md').write_text(report, encoding='utf-8')
copies = json.loads((OUT / 'copy-provenance.json').read_text(encoding='utf-8'))
assert len({row['destination'] for row in copies}) == len(copies)
for row in copies:
    assert sha(OUT / row['destination']) == row['sha256'], row['destination']
for target in re.findall(r'\]\(([^)]+)\)', report):
    if '://' not in target and target != 'MANIFEST.json':
        assert (OUT / target.split('#', 1)[0]).is_file(), target
files = [{'path': path.relative_to(OUT).as_posix(), 'bytes': path.stat().st_size, 'sha256': sha(path)}
    for path in sorted(OUT.rglob('*')) if path.is_file() and path != OUT / 'MANIFEST.json']
(OUT / 'MANIFEST.json').write_text(json.dumps({'created_utc': datetime.now(timezone.utc).isoformat(),
    'candidate': HEAD, 'provenance': 'HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL', 'files': files,
    'note': 'Excludes this manifest; ZIP sidecar hashes the complete archive.'}, indent=2), encoding='utf-8')
archive = OUT.with_suffix('.zip')
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zipped:
    for path in sorted(OUT.rglob('*')):
        if path.is_file():
            zipped.write(path, OUT.name + '/' + path.relative_to(OUT).as_posix())
digest = sha(archive)
archive.with_suffix('.zip.sha256').write_text(digest + '  ' + archive.name + '\n', encoding='ascii')
print(json.dumps({'archive': str(archive), 'sha256': digest, 'manifest_files': len(files),
    'copy_hashes_verified': len(copies), 'terminal': terminal, 'native': metrics}, indent=2))
