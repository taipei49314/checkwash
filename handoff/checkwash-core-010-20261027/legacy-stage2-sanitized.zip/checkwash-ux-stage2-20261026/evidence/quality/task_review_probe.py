"""Small read-only TASK-note review; no repository or analyzed program runs."""
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import platform
import sys

HERE = Path(__file__).resolve().parent
WORK = HERE.parents[1]
REPO = WORK / "checkwash-ux"
sys.path.insert(0, str(REPO / "src"))
from checkwash.contract import contract_diagnostics, parse_contract

current_bytes = (REPO / "src/checkwash/contract.py").read_bytes()
current = current_bytes.decode("utf-8")
baseline = (WORK / "rename/source-v091/src/checkwash/contract.py").read_bytes().decode("utf-8")
assert current.split("\n\ndef contract_diagnostics", 1)[0].strip() == baseline.strip()
canonical = "---\ncheckwash:\n  oracle_freeze: true\n  scope:\n    allow:\n      - tests/**\n---\n"
variants = {"canonical": canonical, "legacy": canonical.replace("checkwash:", "greenwash:"),
            "CRLF": canonical.replace("\n", "\r\n"), "uppercase_false": canonical.replace("true", "FALSE"),
            "bom": "\ufeff" + canonical, "trailing_comment": canonical.replace("true", "true # note"),
            "quoted": canonical.replace("true", '"true"'),
            "flow_list": canonical.replace("    allow:\n      - tests/**", "    allow: [tests/**]"),
            "unclosed": canonical.rsplit("---", 1)[0],
            "header_comment": canonical.replace("checkwash:", "checkwash: # note"),
            "tab": canonical.replace("  oracle_freeze", "\toracle_freeze"),
            "control_in_value": canonical.replace("true", "true \x1b[31m\u202e")}
rows = []
for name, text in variants.items():
    parsed = asdict(parse_contract(text))
    notes = contract_diagnostics(text)
    assert parsed == asdict(parse_contract(text))
    assert all(not any(c in note for c in "\n\x1b\u202e") for note in notes)
    rows.append({"name": name, "input": text, "parsed": parsed, "notes": notes})
result = {"provenance": "HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL", "hostname": platform.node(),
          "runtime": sys.version, "parser_prefix_matches_old_source": True,
          "contract_source_sha256": hashlib.sha256(current_bytes).hexdigest(), "cases": rows,
          "scope": "12 small parser/note controls; no gate or fixture program execution"}
(HERE / "task-review-probe.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"cases": len(rows), "parser_prefix_matches_old_source": True,
                  "all_parse_results_unchanged": True, "all_notes_control_safe": True}))
