# Independent TASK syntax diagnostic review

Read-only scope: `contract.py`, the `_analyse` task-read hunk in `cli.py`,
`test_task_syntax_diagnostics.py`, and explanatory `docs/task-input.md`.
**No blocking finding observed.** No checkout file was changed by this review.

- The existing `Contract` and `parse_contract` source prefix is unchanged from
  the preserved v0.9.1 source (it was also unchanged through the f86 stage-2
  base). The new function does not normalize or activate ignored input.
- CLI parsing still reads the same base / existing root-only working fallback.
  Early base-alias and subdirectory refusals stay in place. The source label
  names which path supplied the exact text; no read authority is added.
- Notes go through `advise`, so quiet session legs suppress duplicate stderr.
  They do not enter config_errors, findings, payload schemas, policy, severity
  or exit selection. A warning does not claim successful enforcement.
- Task path display uses repr; diagnostic reasons contain only owned text
  and integer line numbers, with no raw task value interpolation. A small
  ESC / bidi value probe produced no raw controls in the notes.
- Twelve small parser/note controls retained identical parsed results before
  and after note generation. Canonical / legacy / CRLF / FALSE controls had
  no new syntax note; the stated BOM, trailing scalar comment, quoted scalar,
  flow-list, unclosed header, commented block header and tab cases were visible.
  `task-review-probe.json` records source/runtime and exact inputs/results.
- The function is deliberately a bounded recognizer, not a general YAML
  validator. The documentation states that limitation and does not imply
  every unsupported spelling is detected or a TASK applies without --task.

This review did not run a source suite, change a protected judge, execute an
analyzed fixture program, or validate task-policy exploit outcomes. The
independent small probe uses only the parser and diagnostic function.
