"""Native development receipts for the owned second-stage quality slices."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys

HERE = Path(__file__).resolve().parent
SESSION = HERE.parents[2]
REPO = SESSION / "work/checkwash-ux"
BASE = "f86aabbbe7e61891d8b93cb2c043b9bcae44f88a"
label, *targets = sys.argv[1:]
out = HERE / label
out.mkdir(exist_ok=False)
temporary = HERE.parent / "qtmp"
temporary.mkdir(exist_ok=True)
env = dict(os.environ, PYTHONPATH=str(REPO / "src"), PYTHONDONTWRITEBYTECODE="1",
           TEMP=str(temporary), TMP=str(temporary), PYTEST_DISABLE_PLUGIN_AUTOLOAD="1")
paths = ["src/checkwash/quality/cli.py", "src/checkwash/quality/setup.py", "src/checkwash/quality/report.py",
         "src/checkwash/cli.py", *[p for p in targets if (REPO / p).is_file()]]
def hashes():
    return {p: hashlib.sha256((REPO / p).read_bytes()).hexdigest() for p in sorted(set(paths))}
before = hashes()
head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=REPO).decode("ascii").strip()
command = [sys.executable, "-B", "-m", "pytest", "-p", "no:cacheprovider", *targets]
started = datetime.now(timezone.utc).isoformat()
process = subprocess.run(command, cwd=REPO, env=env, capture_output=True)
ended = datetime.now(timezone.utc).isoformat()
(out / "stdout.bin").write_bytes(process.stdout)
(out / "stderr.bin").write_bytes(process.stderr)
after = hashes()
meta = {"provenance": "HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL", "host": platform.node(),
        "runtime": sys.version, "executable": sys.executable, "platform": platform.platform(),
        "scope": "development shared tree; not fixed whole-tree qualification", "stage2_base": BASE,
        "head_at_start": head, "command": command, "cwd": str(REPO), "temporary": str(temporary),
        "started_utc": started, "ended_utc": ended, "exit_code": process.returncode,
        "owned_hashes_before": before, "owned_hashes_after": after,
        "owned_sources_unchanged": before == after,
        "stdout_sha256": hashlib.sha256(process.stdout).hexdigest(),
        "stderr_sha256": hashlib.sha256(process.stderr).hexdigest()}
(out / "receipt.json").write_text(json.dumps(meta, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"label": label, "exit": process.returncode, "owned_sources_unchanged": before == after}))
print(process.stdout.decode("utf-8", errors="backslashreplace")[-5500:])
raise SystemExit(process.returncode)
