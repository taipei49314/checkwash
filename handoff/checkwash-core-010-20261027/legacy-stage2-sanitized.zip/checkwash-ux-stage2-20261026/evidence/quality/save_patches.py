"""Save incremental owned-file drafts without touching Git's index."""
import difflib
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
SLICES = [
    ("explain", "base", ["cli.py", "report.py"], "test_quality_explain_formats.py"),
    ("profiles", "explain", ["cli.py", "report.py"], "test_quality_profiles_formats.py"),
    ("init", "profiles", ["setup.py"], "test_quality_init_guidance.py"),
]
manifest = []
for name, before, sources, test in SLICES:
    chunks = []
    for file in sources:
        relative = "src/checkwash/quality/" + file
        left = (HERE / "snapshots" / before / file).read_text(encoding="utf-8").splitlines(keepends=True)
        right = (HERE / "snapshots" / name / file).read_text(encoding="utf-8").splitlines(keepends=True)
        chunks.append(f"diff --git a/{relative} b/{relative}\n")
        chunks.extend(difflib.unified_diff(left, right, fromfile="a/" + relative, tofile="b/" + relative))
    relative = "tests/" + test
    right = (HERE / "snapshots" / name / test).read_text(encoding="utf-8").splitlines(keepends=True)
    chunks.append(f"diff --git a/{relative} b/{relative}\nnew file mode 100644\n")
    chunks.extend(difflib.unified_diff([], right, fromfile="/dev/null", tofile="b/" + relative))
    content = "".join(chunks).encode("utf-8")
    (HERE / (name + ".patch")).write_bytes(content)
    manifest.append({"slice": name, "patch_sha256": hashlib.sha256(content).hexdigest(), "bytes": len(content),
                     "sources": ["src/checkwash/quality/" + p for p in sources], "test": relative,
                     "main_cli_hunks": "parent-owned default=None and per-subcommand normalization" if name == "profiles" else None})
(HERE / "patches.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
print(json.dumps(manifest))
