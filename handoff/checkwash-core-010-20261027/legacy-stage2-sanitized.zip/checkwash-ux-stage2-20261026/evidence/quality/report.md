# Stage 2 quality UX: three named repair slices

Provenance: `HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`; host `LAPTOP-01AGNPJU`,
Windows/Python 3.11.9, existing pytest 9.1.1. Stage 2 base is
`f86aabbbe7e61891d8b93cb2c043b9bcae44f88a`; all runs are explicitly
development checks on the shared tree, not final-source or release acceptance.

## Changes and validation

| Slice | Corrected behavior | Cases / controls |
|---|---|---|
| Successful explain formats | Existing terminal wording stays. JSON describes the rule as advisory metadata; SARIF provides the rule descriptor with empty results and no invented invocation. Neither output claims to analyze a change. | Five current rules in all three formats; native main routing ignores repository lookup for help. 17 new cases. |
| Explicit profiles term | Bare profiles and explicit JSON retain identical JSON bytes, both brief and details. Explicit term prints versions, digests, scope and optional complete metadata. Display controls are escaped. Catalog errors honor term / existing JSON error shape. | Six new cases, including two bare-vs-JSON comparisons, details and control-character display. Parent alone applied the main-parser `default=None` and main normalization hunks so omission stays JSON for profiles, term otherwise. |
| Init save/prerequisite guidance | A successful draft contains valid TOML comments explaining stdout/no tool-written file, UTF-8 draft saving, review and installation. JSON next_steps names the policy_toml field instead of suggesting that the whole JSON object be saved as policy. Init failures explain missing configuration or argument prerequisites; doctor advice remains operation-specific. | Five new cases covering term/JSON draft parsing and no mutation, absent configuration and a missing requested tool. Existing lifecycle, doctor and usage checks remain. |

Original `before` run: **20 failed / 8 passed**, exit 1, owned hashes stable.
The new files were already separate modules; no old receipt is relabeled as a
different test-source hash. Named breakdown: explain 12 failed / 5 passed,
profiles 3 failed / 3 passed, init 5 failed.

- `explain-after`: **62 passed**, exit 0, owned hashes stable.
- `profiles-after`: **68 passed**, exit 0, owned hashes stable.
- `init-after`: **73 passed**, exit 0, owned hashes stable.

These overlap: the final union is 73 targeted cases, including 28 new cases,
not 203 independent passes. Each receipt captures its actual head, owned source
and test hashes before/after, command, runtime, short task-owned TEMP path,
native stdout/stderr bytes and hashes. Plugin auto-loading was disabled for
these ordinary targeted runs; no host settings or global PATH changed.

No existing test assertion, golden/corpus label, quality model/profile,
review verdict/gating, fingerprint construction or protected file was changed
by this subtask. No analyzed fixture program or external quality tool was run.
Init remains report-mode/advisory; no file-writing or review authority was added.

## Integration and saved slices

Parent integrated explain as `8561cdaa` and profiles as `2c06ea98`; parent owns
commits, pushes and final-head validation. Parent integrated init as `1fdec664`.
This agent performed no Git mutation.

`snapshots/base`, `snapshots/explain`, `snapshots/profiles`, `snapshots/init`
preserve owned file states. `explain.patch`, `profiles.patch`, `init.patch` are
incremental owned-source / new-test drafts; `patches.json` gives SHA-256.
The profiles patch intentionally excludes parent's two main CLI hunks, which
parent applied and committed with that slice. No older stage-1 outputs changed.

Other OS / Python versions, the complete source suite, packaged artifacts,
required receipt bridge and release checks are NOT_RUN by this subtask. Parent
will bind its final integration source and checks separately. The r65 release
pause, existing tags and no-publication boundary remain.
