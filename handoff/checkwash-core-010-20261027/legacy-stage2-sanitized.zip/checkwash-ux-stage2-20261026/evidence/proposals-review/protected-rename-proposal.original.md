# Inert proposal — oracle_freeze 與 D2 assertion-text credit

本檔僅為可審查草稿，沒有修改或執行受保護政策。產品基線 `f86aabbbe7e61891d8b93cb2c043b9bcae44f88a` 的 gating/SPEC 與先前固定 `1ffe283d` 的重現相同。r65 發版暫停保持。

## 已有證據與本提案的精確界線

`work/rename/report.md` 的72次固定CLI比較證明：A 在正確 `oracle_freeze:true` 下仍由 assertion-text D2 得到info/PASS；B 在freeze下原本就BLOCK；literal unroll N原本已由concrete projection BLOCK。合法同義unroll和純搬移控制PASS。另有跨檔只改param decorator的worktree PASS/range BLOCK；Python body_hash未涵蓋decorator，所以「whole body相等」不能當完整oracle相等證明。

建議先決定一個狹窄政策修改：**oracle_freeze=true時，D2的assertion-text兩個分支不得提前返回，讓既有E1/E2判斷繼續；whole-body及DUPLICATE_REMAINS分支維持原行為。** 這僅補A所用的ordering缺口，不宣稱修好default A/B、跨檔decorator/body-hash缺口或#419 repair-credit。

## 建議的精確程式差異（未套用）

受保護檔 `src/checkwash/gating.py`：只對兩個text-only路徑加condition，避免更動credit消費演算法、alignment、strength、severity表或其他補償規則。

```diff
-        if f.rule == "ASSERT_REMOVED" and f.before is not None:
+        if f.rule == "ASSERT_REMOVED" and f.before is not None and not contract.oracle_freeze:
             key = normalize_text(f.before.text)
             if moved[key] > 0:
                 moved[key] -= 1
                 f.severity = "info"
                 f.deescalators.append("ASSERTION_MOVED")
                 continue
...
-            if texts and all(moved[t] >= n for t, n in needed.items()):
+            if (not contract.oracle_freeze
+                    and texts and all(moved[t] >= n for t, n in needed.items())):
                 moved.subtract(needed)
                 f.severity = "info"
                 f.deescalators.append("ASSERTION_MOVED")
                 continue
```

freeze是一次analysis的global contract，所以未消費text credits不會在同輪被另一個非freeze finding借走。body-hash與duplicate pools的既有消費／不消費邏輯不動。freeze下不再附text-only `ASSERTION_MOVED`；E1和E2依既有規則附labels，既有allow仍依原政策。

module docstring及D2註解須同步把「所有moved assertion都conclusively benign且跳過escalation」改成精確描述：「whole-body/DUPLICATE_REMAINS保留early-return；assertion-text credit只在未freeze時early-return。」不得把這個狹窄修改描述為完整oracle等價判斷。

## 建議的精確保護文件文字（未套用）

`SPEC.md` §5 D2 row保留現有條件與multiset/liveness文字，在effect欄原 `→ info` 後加入：

> With `oracle_freeze: true`, assertion-text matches do not return early and do not lower the finding to info: the finding continues through E1/E2. The disappeared-unit whole-body route keeps its existing early return; a matching body does not compare decorator or parameter-table context.

`SPEC.md` §5 E2附近補充：

> E2 applies after D2 assertion-text credits are withheld under an oracle freeze. Whole-body D2 and D10 early returns remain existing exceptions; this decision does not establish their semantic equivalence.

`DECISIONS.md` 新entry（id由maintainer分配）應逐項記：A的原始info/PASS與候選high/BLOCK、兩個guard的範圍、誠實text-only moves在freeze下新阻擋的成本、保留的body/decorator/default-D5/#419邊界、下面的實際acceptance證據及其未跑平台。`THREATMODEL.md` 只能記具名ordering情境關閉，不能把unit-rename整類或body-hash情境標closed。

以上屬AGENTS明列protected gating/SPEC/DECISIONS/THREATMODEL；一般UX繼續授權沒有自動解除這些保護，因此本檔停在outside草稿，不把草稿當已採納政策。

## 採納後的必要驗證（預期，尚未跑）

| Control | default預期 | freeze預期 | 用途 |
|---|---|---|---|
| A原始parametrize→locals/改名/保留assert | 保留info/PASS | 改為high/BLOCK，含ORACLE_FREEZE | 唯一主修情境，range/worktree都驗 |
| B duplicate padding | 保留warn/PASS | 保留high/BLOCK | 不把既有E2能力當新成果 |
| literal N改期望 | 保留3個high/BLOCK | 保留3個high/BLOCK | 不重開已攔到的推論主張 |
| 合法literal unroll，期望不變 | 保留零finding/PASS | 保留零finding/PASS | concrete projection正控制 |
| 純whole-file等byte搬移 | 保留原結果 | 保留原結果 | whole-body路徑沒有順帶變更 |
| assertion-only誠實搬移，unit/body並非等同 | 保留原D2結果 | 新high/BLOCK | 公開而非隱藏的freeze成本 |
| 跨檔只改param decorator | 保留原入口差異 | 保留原入口差異 | 明示此狹修沒有關閉body-hash缺口 |
| 相同finding帶有效既有allow | 保留原allow效果 | 保留原allow效果 | gate ordering不退休exemptions |

逐例比較findings完整欄位與fingerprint，不能只比verdict。依目前fingerprint constructor，severity/escalator本身不進identity；這只是來源判讀，仍須實跑證明此次改動未使既有fingerprint失配。跑現有golden/refactor/rename-safety gates，不改其expected；若出現標籤爭議，依AGENTS開issue並停止該項，不修expected取得綠燈。其他平台未跑就寫NOT_RUN。

## 版本與決策語句

這改動直接改SPEC §5 ordering及protected gating，即使最後fingerprint均不變，也依stability的frozen契約走minor；不能用「只有兩個condition」稱為patch。沒有bump或發布授權從本草稿產生。

可供人類採納的精確語句：

> 核可上述兩個D2 assertion-text分支在oracle_freeze=true時繼續既有E1/E2的窄改，並核可對應SPEC/DECISIONS/THREATMODEL文字與具名新增正反例；保持whole-body、DUPLICATE_REMAINS、default D5及#419原行為。走minor候選與完整相容性驗證，不授權合併、tag、發布或解除r65暫停。

若目標是阻止default A/B或跨檔decorator形狀，應另選更完整的context/row identity設計及可接受重構成本；不能把上面窄改的acceptance當作那些問題的驗收。
