"""Read-only integrity/evidence checks. Does not apply or import a judge patch."""
import hashlib
import json
from pathlib import Path
import platform
import re
import subprocess
import sys

HERE = Path(__file__).resolve().parent
SESSION = HERE.parents[2]
REPO = SESSION / "work/checkwash-ux"
PACKET = HERE.parent / "proposals"
manifest = json.loads((PACKET / "proposal-manifest.json").read_text(encoding="utf-8"))
inventory = json.loads((PACKET / "04-movement-inventory.json").read_text(encoding="utf-8"))
errors = []
def sha(data):
    return hashlib.sha256(data).hexdigest()
def check(condition, description):
    if not condition:
        errors.append(description)
def frozen(path):
    return subprocess.check_output(["git", "show", manifest["base_commit"] + ":" + path], cwd=REPO)

packet_hashes = {path.name: sha(path.read_bytes()) for path in PACKET.iterdir() if path.is_file()}
for name, expected in manifest["files"].items():
    check(packet_hashes.get(name) == expected, "packet hash differs: " + name)
protected = {}
for name, expected in manifest["protected_source_sha256"].items():
    baseline = frozen(name)
    current = (REPO / name).read_bytes()
    protected[name] = {"baseline_sha256": sha(baseline), "current_sha256": sha(current),
                       "unchanged": baseline == current}
    check(sha(baseline) == expected, "frozen source hash differs: " + name)
    check(baseline == current, "protected current file differs: " + name)

def inspect_hunks(filename, source_path):
    # Compare old/context lines only. Never construct or write a patched source.
    patch = (PACKET / filename).read_text(encoding="utf-8").splitlines(keepends=True)
    before = frozen(source_path).decode("utf-8").splitlines(keepends=True)
    results = []
    i = 0
    while i < len(patch):
        found = re.match(r"@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@", patch[i])
        if not found:
            i += 1
            continue
        start, length = int(found[1]), int(found[2] or 1)
        new_length = int(found[4] or 1)
        expected_old, added = [], 0
        i += 1
        while i < len(patch) and not patch[i].startswith("@@ "):
            line = patch[i]
            if line.startswith((" ", "-")):
                expected_old.append(line[1:])
            if line.startswith((" ", "+")):
                added += 1
            i += 1
        matched = len(expected_old) == length and before[start - 1:start - 1 + length] == expected_old
        check(matched, f"old/context hunk mismatch: {filename}:{start}")
        check(added == new_length, f"new-line count mismatch: {filename}:{start}")
        results.append({"old_start": start, "old_length": length, "new_length": new_length,
                        "old_context_matches_frozen_source": matched})
    return results
hunks = {"01-gating-proposed.patch": inspect_hunks("01-gating-proposed.patch", "src/checkwash/gating.py"),
         "02-SPEC-proposed.patch": inspect_hunks("02-SPEC-proposed.patch", "SPEC.md")}

source_results = {}
for evidence in manifest["evidence"]:
    path = (SESSION / evidence["source"]).resolve()
    check(path.is_relative_to(SESSION.resolve()), "evidence escaped workspace")
    raw = path.read_bytes()
    data = json.loads(raw)
    check(sha(raw) == evidence["sha256"], "evidence hash differs: " + evidence["source"])
    check(len(data["results"]) == evidence["observations"], "evidence count differs")
    source_results[evidence["source"]] = (path, data)

fields = ("rule", "severity", "path", "unit", "fingerprint", "escalators", "deescalators")
paired = {}
changes = []
raw_receipts = []
seen_pointers = set()
for number, row in enumerate(inventory["rows"]):
    pointer, index = row["evidence_pointer"].split("#/results/")
    path, data = source_results[pointer]
    original = data["results"][int(index)]
    check(row["evidence_pointer"] not in seen_pointers, "duplicate inventory pointer")
    seen_pointers.add(row["evidence_pointer"])
    for key in ("source_label", "source_sha", "case", "entry", "oracle_freeze"):
        check(row[key] == original[key], f"pointer field mismatch row {number}: {key}")
    check(row["original_receipt"] == original["receipt"], f"receipt pointer mismatch row {number}")
    check((row["observed_exit"], row["observed_verdict"]) == (original["exit"], original["verdict"]),
          f"observed outcome mismatch row {number}")
    projection = [{key: finding[key] for key in fields} for finding in original["findings"]]
    check(row["observed_findings"] == projection, f"observed finding projection mismatch row {number}")
    raw_paths = {}
    for stream in ("stdout", "stderr"):
        raw_path = (path.parent / original["receipt"][stream]).resolve()
        check(raw_path.is_relative_to(path.parent.resolve()), f"raw path outside evidence root row {number}")
        content = raw_path.read_bytes()
        check(sha(content) == original["receipt"][stream + "_sha256"], f"raw hash mismatch row {number}/{stream}")
        raw_paths[stream] = content
    payload = json.loads(raw_paths["stdout"])
    check(payload["findings"] == original["findings"], f"raw findings mismatch row {number}")
    check(payload["verdict"] == original["verdict"], f"raw verdict mismatch row {number}")
    check(payload["config_errors"] == [] and payload["skipped_files"] == [], f"raw coverage diagnostics row {number}")
    check(raw_paths["stderr"] == b"", f"nonempty original stderr row {number}")
    check(original["receipt"]["exit"] == original["exit"], f"recorded exit mismatch row {number}")
    expected_change = row["case"] == "A" and row["oracle_freeze"]
    check(row["expected_movement"] == expected_change, f"movement classifier mismatch row {number}")
    predicted = json.loads(json.dumps(projection))
    if expected_change:
        check(len(predicted) == 1 and predicted[0]["rule"] == "TEST_DISABLED", "A shape is not single TEST_DISABLED")
        predicted[0]["severity"] = "high"
        predicted[0]["escalators"].append("ORACLE_FREEZE")
        changes.append({key: row[key] for key in ("source_label", "source_sha", "case", "entry", "oracle_freeze")})
    check(row["predicted_findings"] == predicted, f"predicted field mismatch row {number}")
    check(row["predicted_exit"] == (1 if expected_change else original["exit"]), f"predicted exit mismatch row {number}")
    check(row["predicted_verdict"] == ("block" if expected_change else original["verdict"]), f"predicted verdict mismatch row {number}")
    check(row["prediction_status"] == "PROPOSED_NOT_EXECUTED", f"prediction status row {number}")
    key = (row["case"], row["entry"], row["oracle_freeze"])
    paired.setdefault(key, {})[row["source_label"]] = {
        "exit": original["exit"], "verdict": original["verdict"], "findings": original["findings"],
        "config_errors": payload["config_errors"], "skipped_files": payload["skipped_files"]}
    raw_receipts.append({"pointer": row["evidence_pointer"], "stdout_sha256": sha(raw_paths["stdout"]),
                         "stderr_sha256": sha(raw_paths["stderr"])})
for key, pair in paired.items():
    check(set(pair) == {"v090", "v091"} and pair["v090"] == pair["v091"], "old-source pair differs: " + repr(key))
check(len(seen_pointers) == 72 and len(paired) == 36 and len(changes) == 4, "matrix dimensions differ")
check(len(seen_pointers) == sum(len(data["results"]) for _, data in source_results.values()), "missing original rows")

old_path = HERE / "protected-rename-proposal.original.md"
new_path = HERE.parent / "sweep/protected-rename-proposal.md"
old, new = old_path.read_bytes(), new_path.read_bytes()
supersession = {"original_sha256": sha(old), "superseded_file_sha256": sha(new),
                "historical_body_bytes_preserved": new.endswith(old),
                "banner_present": new.startswith(b"# SUPERSEDED"),
                "new_packet_link_present": b"../proposals/00-D2-E2-proposal.md" in new}
check(all(supersession[key] for key in ("historical_body_bytes_preserved", "banner_present", "new_packet_link_present")),
      "supersession repair missing")

receipt = {"scope": "read-only frozen-source/hunk/evidence audit; no patched source constructed, imported or executed",
           "provenance": "HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL", "hostname": platform.node(),
           "runtime": sys.version, "source_head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=REPO).decode().strip(),
           "packet_hashes": packet_hashes, "protected_sources": protected, "hunks": hunks,
           "matrix": {"old_observations": len(seen_pointers), "old_source_pairs": len(paired),
                      "forecast_changed": len(changes), "forecast_unchanged": len(seen_pointers) - len(changes),
                      "changed_rows": changes, "all_old_pairs_identical": all(set(pair) == {"v090", "v091"} and pair["v090"] == pair["v091"] for pair in paired.values())},
           "raw_receipts": raw_receipts, "supersession_repair": supersession, "errors": errors,
           "modified_judge_execution_by_reviewer": 0,
           "manifest_execution_claim": manifest["modified_judge_executions"],
           "limits": "Does not run or qualify the draft judge, estimate empirical cost, or independently prove all historical process absence."}
(HERE / "audit.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"errors": errors, "matrix": receipt["matrix"], "hunks": hunks,
                  "protected_unchanged": all(row["unchanged"] for row in protected.values()),
                  "supersession_repair": supersession}, indent=2))
raise SystemExit(1 if errors else 0)
