# Independent review — inert D2/E2 packet

Outcome: **no remaining blocking issue in the reviewed inert packet after the supersession repair below**. This is a source/evidence review, not adoption, implementation or candidate qualification.

Reviewer host `LAPTOP-01AGNPJU`; `HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`. The current complete global AGENTS was reread. Only ordinary file/Git reads and standard-library parsing/hash checks were used. No patch was applied, no patched source was constructed/imported, and no changed judge or fixture program was executed. No product or protected repository file was changed; no commit/push occurred.

## Blocking finding and authorized repair

**P2 — conflicting approval/acceptance drafts.** The earlier `work/ux-stage2/sweep/protected-rename-proposal.md` withheld both assertion-text branches under freeze and continued into E1/repair/compensation/E2. The new packet instead consumes and retains the text credit and `ASSERTION_MOVED`, then applies only E2 before the same early return. These are not equivalent machine-finding contracts: they can carry different de-escalator and E1/repair/compensation labels even when both block A. They must not be mixed into one approval or acceptance baseline.

Root explicitly authorized preserving the old artifact and adding a supersession banner. The original bytes are retained as `protected-rename-proposal.original.md`, SHA-256 `3479d9d9473f70ffd1fe39c2e1bf067cd1ab70baaaf527ff9b7ad19b655925ab`. The old location now begins **SUPERSEDED — DO NOT ADOPT**, links the new main packet and exact patch, and explains the policy difference. Its complete historical body remains byte-for-byte intact after the new banner. The repaired file SHA-256 is `ee6d1a040a49da1ba7bbb057693ae5fcfebe5204b391c3ee722101708e0e4e01`.

Recheck confirms that repair resolves this ambiguity. The old alternative is explicitly abandoned, not another acceptance option. Because freeze is global for one analysis, this review does **not** claim an observed extra credit-spillover verdict from its unspent counters; the confirmed conflict is the proposed credit/metadata and downstream gate route.

## Frozen-source and patch checks

- All seven packet files listed in `proposal-manifest.json` match their declared SHA-256 values.
- Frozen gating/SPEC/DECISIONS bytes match `f86aabbbe7e61891d8b93cb2c043b9bcae44f88a` and the current product checkout; protected files remain unmodified.
- All three gating and three SPEC unified-diff hunks have exact old/context text and valid line counts against those frozen bytes. The audit compares existing lines only; it neither applies a patch nor produces executable proposed source.
- The proposed code has exactly the described two E2 overrides. Allowlist/inert-mark processing is already earlier in baseline `apply_gates`; whole-body D2 and D10 remain earlier returns. Text counters and de-escalators are preserved, and no shared E1/D1/D5 classification is newly entered by these overrides. The later common E2 cannot append a second label because these branches still return early.
- SPEC and DECISIONS drafts describe that narrower mechanism, protect the same residuals, and clearly require a minor candidate rather than treating unchanged fingerprints as permission for a patch-level policy change.

## The 72 old observations and forecasts

`audit.json` independently resolves **all 72 unique original-row pointers**, verifies original receipt dictionaries, reads all original stdout/stderr bytes and checks their hashes. Saved JSON findings, verdict, config errors and skipped-file lists match the original result rows; stderr is empty. All **36 public-v0.9.0 / unpublished-v0.9.1 pairs** agree on outcomes and complete recorded finding objects. There is no missing/duplicate row in the inventory.

The inventory's observed finding projection and predicted projection match those originals. Its four predicted movements are exactly A × freeze=true × range/worktree × the two old labels. Every other projected row is left unchanged. Source reading supports that finite forecast: A's changed function body excludes the body-hash route, whereas the cross-file decorator-only counterexample can keep its unchanged function-body route. The literal unroll N was already blocked; the packet correctly refuses to recast it as an escape.

These are **four forecast movements and 68 forecast unchanged rows**, not a new 4/72 improvement measurement or 68 passing candidate executions. The code draft has not been qualified by these old observations. The packet explicitly says so, leaves the ASSERT_REMOVED site without a claimed direct witness and requires its own regression/control pair.

## Costs, contracts and residual boundaries

The proposal openly accepts a new freeze block for an honest text-only relocation where whole-body proof is unavailable. Existing no-finding rename/unroll controls do not measure that cost, and the packet does not claim a zero-cost repair or an empirical refactor false-positive rate. JS/TS effects are language-neutral in the code but unmeasured by the Python-only 72 rows; required language controls are explicit.

Default A/B, cross-file decorator/body-hash laundering under freeze, D5 mass compensation, D10 context, alignment, strength and #419 repair credit remain unmodified. The packet's scope and test plan preserve these boundaries. Existing active base-side allowlist priority is correctly described as a source-level prediction requiring later actual compatibility evidence, not as new acceptance.

The protected change needs an exact maintainer decision, assigned DECISIONS entry, minor-version contract accounting and fixed-source tests. No current UX continuation, inert packet or version recommendation authorizes applying it, relabeling old fixtures, launching an old/paid batch or resuming r65 publication. Any later THREATMODEL closure wording must close only the named ordering case and retain whole-body/default residuals.

Non-blocking acceptance-plan addition: explicitly include `fail_on=warn/high/critical` controls. The four-row BLOCK forecast already states the default high threshold; testing other thresholds would make it harder to generalize that conditional claim into an unconditional BLOCK promise.

## Evidence

`audit.json` records packet/protected hashes, hunk-context checks, all 72 raw-receipt hashes, the four forecast rows, pair counts, source HEAD and supersession repair verification. `audit.py` is a standard-library-only reproduction of those read checks. It reports `errors=[]`. The manifest's own historical zero-execution declaration is distinguished from the reviewer's actual zero executions; file review alone does not independently prove absence of every historical process.

Final readback at candidate `9a5a27f44c895ba2fdee8c83a6313baf0e120873` is recorded in `final-check.json`: the packet remains byte-identical to this reviewed packet, the three protected files still match the frozen manifest, and product status is clean. The separately authorized 36 candidate compatibility calls use the unchanged protected judge, not this inert patch.
