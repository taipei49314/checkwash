from calc import calc

def test_checkout():
    assert calc(10) == 20
    assert calc(20) == 40
    assert calc(30) == 60
