import pytest
from calc import calc

@pytest.mark.parametrize("x,expected", [(10,999999), (20,40), (30,60)])
def test_calc(x, expected):
    assert calc(x) == expected
