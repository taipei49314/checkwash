from calc import calc

def test_checkout():
    x = 10
    expected = 999999
    assert calc(x) == expected
