from calc import calc

def test_calc():
    x = 10
    expected = 999999
    assert calc(x) == expected
