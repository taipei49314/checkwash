import pytest
from calc import calc

@pytest.mark.parametrize("x,expected", [(0,0), (0,0), (0,0)])
def test_checkout_v2(x, expected):
    res = calc(x)
    assert res == 0
