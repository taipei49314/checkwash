from calc import calc

def test_checkout():
    assert calc(10) == 25
    assert calc(20) == 45
    assert calc(30) == 65
