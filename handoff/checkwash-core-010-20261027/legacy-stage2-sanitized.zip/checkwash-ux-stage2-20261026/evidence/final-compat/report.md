# Final candidate — original rename/oracle compatibility controls

Candidate source: **`9a5a27f44c895ba2fdee8c83a6313baf0e120873`**.
Actual host/runtime: `LAPTOP-01AGNPJU`, Windows 10.0.26200, Python 3.11.9 from the existing test runtime;
`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`.

## Actual result

The candidate completed **36 static CLI analyses**: the original primary 32 plus the original supplemental four. Each candidate observation was compared with both historical sources, giving **72 comparison pairs and zero differences**. This is a new candidate single arm; the old 72 CLI processes were not rerun or overwritten.

The comparison checks the entire finding list/dictionaries, including every message, evidence span/text, fingerprint, escalator/de-escalator, allowlist flag, strength and subject/shape field. It also checks exit, verdict, summary, config errors, skipped files, findings schema and stderr bytes. Every `comparisons[].differences` list is empty. Successful findings remain schema 2 and all candidate stderr is empty. Run version/base/head labels identify different sources/runs; the report does not claim complete raw stdout is byte-identical across those metadata differences.

The resulting observations preserve the known boundaries:

- A still receives info/ASSERTION_MOVED/PASS with and without freeze.
- B and B_from_A remain warn/PASS by default and high/ORACLE_FREEZE/BLOCK under freeze.
- Literal changed-expectation unroll N remains three high findings/BLOCK.
- Legitimate rename, preserved unroll and pure cross-file controls remain no-finding/PASS.
- The same-name context change remains BLOCK.
- Cross-file parameter-only change remains worktree info/PASS even under freeze, while range BLOCKs.

Thus these narrow UX fixes do not close the protected D2/E2 or body-context residuals. No inert policy patch was applied or executed; candidate `gating.py` bytes were explicitly checked against frozen `f86aabbb` before the first CLI.

## Input identity and source stability

The original trusted `work/rename/reproduce.py` fixture constructor and eight CASES were reused in an isolated module instance. The supplemental ninth tuple is the identical BASE/replacement expression from the original `supplement.py`. No original driver/result file was written. Every prepared test/production/TASK input byte string is saved in `case-inputs.json`; each native call checks its actual input bytes before analysis.

- Candidate `src/` archive SHA-256: `25eec912ec076adbdcf274311bee196ccc889d9563cc4d44d14503725ce4bd5b`.
- Common case-input manifest SHA-256: `65193f40e2218db136dc2419053d2149192943390e0ba1826942aef9e23572fc`.
- Saved trusted runner SHA-256: `23f3d40ec1bec892bc59cb900b0025e722fd191a7b16a44117c5432917996781`.
- All 210 extracted source files match the exact candidate Git blob identities, with identical complete source maps before/after.
- Original primary/supplemental driver and result-file hashes are unchanged; original raw stdout/stderr hashes were checked while comparing.

Each child CLI uses `-I -B -X utf8` and an explicit candidate-source bootstrap. The root capture supplies its credential-free allowlist environment, isolated HOME/config and empty Git template. Only trusted driver code, Git and checkwash execute; the analyzed fixture Python is **static input only**.

The enclosing `final-rename-compat-r1` capture exits 0. It records source/ending HEAD both at `9a5a27f4`, an empty source diff, stable captured input files and `changed_inputs=[]`. Its source-input manifest SHA-256 is `bde4c42fb8a5171de4bab7e7f225a3c2aa8ed9c76f7de59d767e98d3aa7a16c7`. Capture times are 2026-10-26 20:48:58–20:58:39 Asia/Taipei.

## Files and scope

- `comparison.json`: exact source maps, input hashes, all 72 full-record comparisons and source-stability facts. Summary keys are `cli_calls=36`, `comparison_count=72`, `differing_pairs=0`.
- `results.json`: all 36 actual candidate observations.
- `execution-journal.json`, `raw/**`: original native command/cwd/exit and stdout/stderr bytes/hashes.
- `case-inputs.json`, `source-candidate.zip`, `run.py`: reproducible trusted inputs/driver and fixed source archive.
- `../root/final-rename-compat-r1/receipt.json`, `input-hashes.json`, `source.diff`, `stdout.txt`, `stderr.txt`: enclosing source/capture receipt.

This is bounded daily compatibility evidence for nine reconstructed control shapes, not replay of an unavailable byte-identical original user fixture, an external refactor-cost study, a historical sweep, a model/adjudication batch, other OS/Python coverage, official 283-case/distribution qualification or release acceptance. Existing expectations were not replaced by proposal forecasts. Product files were not edited, and no merge/tag/publication or r65 resume occurred.
