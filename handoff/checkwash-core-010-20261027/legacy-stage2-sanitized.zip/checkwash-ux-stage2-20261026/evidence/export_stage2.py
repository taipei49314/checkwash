"""Copy native receipts and fixed-source context; never rewrite raw evidence."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import stat
import subprocess
import sys
import urllib.request

ROOT = Path(__file__).resolve().parents[2]
WORK = ROOT / 'work'
REPO = WORK / 'checkwash-ux'
STAGE = WORK / 'ux-stage2'
OUT = ROOT / 'outputs/checkwash-ux-stage2-20261026'
HEAD = '9a5a27f44c895ba2fdee8c83a6313baf0e120873'
BASE = '1ffe283d7d947fecc426dea99323b0a2620a9482'
FIRST = ROOT / 'outputs/checkwash-ux-milestone-20261026'
OUT.mkdir(parents=True, exist_ok=True)
copies, omissions, queries = [], [], []

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def copy(source, target):
    if not source.exists():
        return
    info = source.lstat()
    if not stat.S_ISREG(info.st_mode) or getattr(info, 'st_file_attributes', 0) & 0x400:
        omissions.append({'source': str(source), 'reason': 'not an ordinary file; not followed'})
        return
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
    assert sha(source) == sha(target)
    copies.append({'source': str(source), 'destination': target.relative_to(OUT).as_posix(), 'sha256': sha(target)})

def tree(source, target, skip=()):
    for base, dirs, files in os.walk(source):
        base = Path(base)
        kept = []
        for name in dirs:
            path = base / name
            info = path.lstat()
            if stat.S_ISLNK(info.st_mode) or getattr(info, 'st_file_attributes', 0) & 0x400:
                omissions.append({'source': str(path), 'reason': 'reparse/symlink directory; not followed'})
                continue
            if name == '.git':
                # Native reader CLI receipts were intentionally stored here.
                for pattern in ('reader-*', 'nonregular-*'):
                    for raw in path.glob(pattern):
                        copy(raw, target / raw.relative_to(source))
            if name in {'.git', '__pycache__', '.pytest_cache', 'pytest-cache', 'qtmp', 'environment', *skip}:
                continue
            kept.append(name)
        dirs[:] = kept
        for name in files:
            copy(base / name, target / (base / name).relative_to(source))

def command(label, args):
    result = subprocess.run(args, cwd=REPO, capture_output=True, timeout=90)
    (OUT / (label + '.stdout')).write_bytes(result.stdout)
    (OUT / (label + '.stderr')).write_bytes(result.stderr)
    queries.append({'label': label, 'command': args, 'exit_code': result.returncode})
    assert result.returncode == 0, (label, result.returncode)
    return result

assert command('candidate-head', ['git', 'rev-parse', 'HEAD']).stdout.decode().strip() == HEAD
assert command('candidate-status', ['git', 'status', '--porcelain=v1', '--untracked-files=all']).stdout == b''
tree(STAGE, OUT / 'evidence')
tree(WORK / 'rename', OUT / 'original-rename', skip=('repos', 'source-v090', 'source-v091'))
for name in ('report.md', 'baseline.json', 'claim-register.json', 'supplementary-claims.json', 'original-analysis.json',
             'release-pause-r65.json', 'MANIFEST.json'):
    copy(FIRST / name, OUT / 'first-milestone' / name)
copy(FIRST.with_suffix('.zip'), OUT / 'first-milestone-complete.zip')
for name in ('test-runtime-install.json', 'test-runtime-distributions.json'):
    copy(WORK / name, OUT / 'runtime' / name)
copy(WORK / 'test-runtime/pyvenv.cfg', OUT / 'runtime/pyvenv.cfg')
copy(WORK / 'trusted/replay_pju_action.py', OUT / 'runtime/replay_pju_action.py')
copy(Path(r'C:\Users\nelson\.codex\AGENTS.md'), OUT / 'context/global-AGENTS.md')
for name in ('AGENTS.md', 'STATE.md', 'docs/ux-repair-candidate-2026-10-26.md', 'docs/task-input.md', 'docs/embedding.md'):
    copy(REPO / name, OUT / 'context' / name)
tree_sha = command('candidate-tree', ['git', 'rev-parse', 'HEAD^{tree}']).stdout.decode().strip()
command('commit-log', ['git', 'log', '--reverse', '--format=full', BASE + '..' + HEAD])
command('candidate-patch', ['git', 'diff', BASE, HEAD, '--binary'])
command('stage2-patch', ['git', 'diff', 'f86aabbbe7e61891d8b93cb2c043b9bcae44f88a', HEAD, '--binary'])
protected = command('protected-files-diff', ['git', 'diff', '--name-only', BASE, HEAD, '--', 'SPEC.md',
    'THREATMODEL.md', 'DECISIONS.md', 'DECISIONS-archive-*.md', 'tests/gates', 'src/checkwash/gating.py',
    'src/checkwash/ir/strength.py', 'src/checkwash/align.py'])
assert protected.returncode == 0 and protected.stdout == b''
remote = command('remote-refs', ['git', 'ls-remote', 'origin', 'refs/heads/main', 'refs/heads/fix/ux-repairs-20261026',
    'refs/tags/v0.9.0', 'refs/tags/v0.9.0^{}', 'refs/tags/v0.9.1', 'refs/tags/v0.9.1^{}'])
refs = dict(line.split()[::-1] for line in remote.stdout.decode().splitlines())
assert refs['refs/heads/main'] == BASE
assert refs['refs/heads/fix/ux-repairs-20261026'] == HEAD
assert refs['refs/tags/v0.9.1'] == '7155c80e57fb0655c521483988ae58905d9b36f1'
assert refs['refs/tags/v0.9.1^{}'] == BASE
assert refs.get('refs/tags/v0.9.0^{}', refs['refs/tags/v0.9.0']) == 'd6eda4f695fabb8e7d138f7a87b099d2028f0294'
pr = command('pr-state', ['gh', 'api', 'repos/taipei49314/checkwash/pulls/566', '--jq',
    '{number,state,draft,merged,head:.head.sha,base:.base.sha,html_url}'])
pr_data = json.loads(pr.stdout)
assert pr_data['state'] == 'open' and pr_data['draft'] and not pr_data['merged']
assert pr_data['head'] == HEAD and pr_data['base'] == BASE
command('check-runs', ['gh', 'api', 'repos/taipei49314/checkwash/commits/' + HEAD + '/check-runs', '--jq',
    '{total_count,checks:[.check_runs[]|{name,status,conclusion}]}'])
release = command('latest-release', ['gh', 'api', 'repos/taipei49314/checkwash/releases/latest', '--jq',
    '{tag_name,published_at,html_url}'])
assert json.loads(release.stdout)['tag_name'] == 'v0.9.0'
with urllib.request.urlopen('https://pypi.org/pypi/checkwash/json', timeout=30) as response:
    raw = response.read()
pypi = json.loads(raw)
assert pypi['info']['version'] == '0.9.0' and '0.9.1' not in pypi['releases']
summary = {'observed_utc': datetime.now(timezone.utc).isoformat(), 'source_sha': HEAD, 'tree': tree_sha,
    'unpublished_base': BASE, 'public_base': 'd6eda4f695fabb8e7d138f7a87b099d2028f0294',
    'host': platform.node(), 'runtime': sys.version, 'executable': sys.executable,
    'provenance': 'HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL', 'native_queries': queries,
    'pypi': {'url': 'https://pypi.org/pypi/checkwash/json', 'response_sha256': hashlib.sha256(raw).hexdigest(),
             'version': pypi['info']['version'], 'has_091': '0.9.1' in pypi['releases']},
    'first_milestone_zip_sha256': sha(FIRST.with_suffix('.zip')),
    'publication': 'PAUSED_R65; no bump/merge/tag/release/downstream pin/automation resume',
    'formal_required_checks': 'NOT_RUN; local source suite and Action replay are separate evidence'}
assert summary['first_milestone_zip_sha256'] == 'e6466727b1eeea9d964bc137b201f57d6e2e23ade4325dd509f373f32c377096'
(OUT / 'baseline.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
(OUT / 'copy-provenance.json').write_text(json.dumps(copies, indent=2), encoding='utf-8')
(OUT / 'copy-omissions.json').write_text(json.dumps(omissions, indent=2), encoding='utf-8')
print(json.dumps({'output': str(OUT), 'copies': len(copies), 'omissions': len(omissions)}, indent=2))
