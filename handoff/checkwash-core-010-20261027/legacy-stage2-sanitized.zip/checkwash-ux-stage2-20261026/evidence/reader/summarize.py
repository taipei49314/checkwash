"""Read saved test outputs only; no product or fixture execution."""
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent
summary = {"marker": "HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL", "runs": {}, "native": {}, "cleanup": {}}
for stage in ("red", "green"):
    metadata = json.loads((HERE / f"{stage}.json").read_text(encoding="utf-8"))
    tree = ET.parse(HERE / f"{stage}.xml")
    cases = list(tree.iter("testcase"))
    summary["runs"][stage] = {"exit": metadata["exit_code"], "owned_before": metadata["owned_before"],
        "owned_after": metadata["owned_after"], "source_sha_start": metadata["source_sha_start"],
        "source_sha_end": metadata["source_sha_end"], "tests": len(cases),
        "failed": sum(case.find("failure") is not None or case.find("error") is not None for case in cases),
        "skipped": sum(case.find("skipped") is not None for case in cases),
        "new_tests": sum(case.get("classname") == "tests.test_snapshot_path_diagnostics" for case in cases),
        "new_failures": sum(case.get("classname") == "tests.test_snapshot_path_diagnostics" and (
            case.find("failure") is not None or case.find("error") is not None) for case in cases),
        "elapsed_seconds": metadata["elapsed_seconds"]}
    native = HERE / f"t-{stage}/native-reader0"
    summary["native"][stage] = {}
    for kind in ("inside", "outside", "regular"):
        gitdir = native / kind / ".git"
        rows = {}
        for fmt in ("json", "hook-json"):
            stem = gitdir / ("reader-" + fmt)
            stdout, stderr = stem.with_suffix(".stdout").read_bytes(), stem.with_suffix(".stderr").read_bytes()
            command = json.loads(stem.with_suffix(".meta.json").read_text(encoding="utf-8"))
            rows[fmt] = {"exit": command["exit"], "payload": json.loads(stdout) if stdout else None,
                         "stdout_sha256": hashlib.sha256(stdout).hexdigest(),
                         "stderr_sha256": hashlib.sha256(stderr).hexdigest(), "stderr_utf8": stderr.decode("utf-8"),
                         "git_status_bytes": (gitdir / "reader-status.raw").read_bytes().decode("utf-8")}
        summary["native"][stage][kind] = rows
    summary["cleanup"][stage] = {
        "inside_alias_absent": not (native / "inside/tests/alias").exists(),
        "outside_alias_absent": not (native / "outside/tests/alias").exists(),
        "inside_target_sha256": hashlib.sha256((native / "inside/owned-target/test_api.py").read_bytes()).hexdigest(),
        "outside_target_sha256": hashlib.sha256((native / "external-owned-target/test_api.py").read_bytes()).hexdigest()}
summary["comparison"] = {
    "inside_json_bytes_unchanged": summary["native"]["red"]["inside"]["json"]["stdout_sha256"] == summary["native"]["green"]["inside"]["json"]["stdout_sha256"],
    "regular_json_bytes_unchanged": summary["native"]["red"]["regular"]["json"]["stdout_sha256"] == summary["native"]["green"]["regular"]["json"]["stdout_sha256"],
    "inside_regular_findings_identical": summary["native"]["green"]["inside"]["json"]["payload"]["findings"] == summary["native"]["green"]["regular"]["json"]["payload"]["findings"],
    "hook_not_analysed_only": set(summary["native"]["green"]["outside"]["hook-json"]["payload"]) == {"systemMessage"}}
(HERE / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"runs": {stage: {key: row[key] for key in ("exit", "tests", "failed", "skipped", "new_tests", "new_failures")} for stage, row in summary["runs"].items()}, "comparison": summary["comparison"]}, indent=2))
