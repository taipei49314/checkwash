# Stage 2 — explain outside worktree source refusals

Named defect: `B1-paths-junction-usage-errors/#2-1`, generic main-reader outside-path error.
Host `LAPTOP-01AGNPJU`, Windows, Python 3.11.9, pytest 9.1.1, Git 2.55.0.windows.3;
`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`.

The inherited stage-1 evidence at `work/main-junction` was read only. Its old fixtures, source archive, raw receipts and report were not modified. This task creates separate owned native fixtures under `work/ux-stage2/reader/t-red` and `t-green`.

## Narrow change

Only the existing outside-path branch in `WorkingTreeSnapshot.read` changes its error text. It now names the repository-relative logical path with `repr`, the side, the `worktree/read` entrypoint, the containment refusal and a safe next step. An absolute input path is redacted as `<non-repository-relative path>`. The resolved external target and its content are never printed.

Example native diagnostic:

```text
strict snapshot path leaves the repository: path='tests/alias/test_api.py', side='worktree', entry='worktree/read'. Restore a repository-owned regular source at this path; a committed range reads committed bytes only, not this working-tree source.
```

The containment check, reader admission, roles and outcomes are unchanged. `Path.open` is never called in the refused external-source unit control. Nonregular-file refusals retain their existing messages and conditions. No existing unit assertion, `.gwcase` expected verdict, corpus label or protected gate was changed.

## Red and green evidence

Both phases recorded base commit `f86aabbbe7e61891d8b93cb2c043b9bcae44f88a` at start and end; these are scoped working-tree tests while other stage-2 work proceeds, not final-head qualification.

| Phase | Result | Scope | Owned source unchanged during phase |
|---|---|---|---|
| Red | exit 1; 5 failed / 6 passed | All 11 new cases, before product edit | yes |
| Green | exit 0; 29 passed / 10 skipped | Same 11 new cases plus existing issue346, strict-snapshot and issue414 modules | yes |

The five red failures are precisely the missing outside-path diagnostic fields: logical path/no-open, absolute-path redaction, LF/ESC escaping, native outside JSON and native outside hook-json. The new test source hash is identical across both phases: `5b3c71974e98eb6e000f9131188e31528814e216081ac0d7ea065c3191c6da43`.

Owned `snapshot.py` SHA-256:

- Before: `d39fe952a7439e474b4ac0dd7e63e2b745aed30bb85142d040054465c7993052`.
- After: `3a411d7a97b77093440037e85838c66428ca58e78ea3415eb112450accb5f71d`.

The ten skips are existing native-symlink tests with Windows `WinError 1314`; they are not counted as passes. The native junction cases actually executed, with native mount-point tag checks.

## Native controls and unchanged identities

Each native fixture holds the same mode100644 tracked logical path and source bytes; Git status is saved and actually reports ` M tests/alias/test_api.py\0`. No mode160000 or untracked-directory substitute is used.

- Outside junction: JSON remains exit 2 with no ordinary stdout report. Hook-json remains exit 0 with **only `systemMessage`**, explicitly not analysed and with no `decision`.
- Inside junction and regular directory: JSON remains exit 1/BLOCK with `ASSERT_WEAKENED/high`; hook-json remains exit 0 with `decision: block`.
- Inside and regular findings are identical. Their original before/after JSON bytes are unchanged, including fingerprint `ASSERT_WEAKENED/tests/alias/test_api.py/test_api/v2:9a27f17761c9a9d310ac9a4f194d6d80a67c640be4be5e1d17d97bef3619f399`.
- New unit controls prove a repository-owned regular file is still read, nonregular directory refusal is unchanged, and newline/ESC in logical path/side are visibly escaped.

All fixture Python remains static input. Owned junctions were removed nonrecursively after verifying lexical and resolved ownership plus the native junction tag. Post-run checks confirm both aliases absent and both target files preserved with SHA-256 `c254288f96a26e81f0ecefd2852e7cbdec9f529dad369505c3ad18d005adbcd8`.

## Evidence and remaining scope

- `red.json`, `green.json`: actual hostname/runtime, commands, exits, owned hashes before/after and stdout/stderr hashes.
- `red.stdout`, `red.stderr`, `red.xml`; corresponding `green.*`: native pytest output and JUnit.
- `t-{red,green}/native-reader0/{inside,outside,regular}/.git/reader-*`: original native CLI stdout/stderr, command metadata, Git index/status bytes.
- `summary.json`: read-only comparisons and post-run owned-junction absence/target preservation.
- `run.py`, `summarize.py`: scoped trusted drivers.

Nonregular refusal side/entry/remediation is a separate potential diagnostic slice; it was deliberately not folded into this outside-path fix. Repo-root junctions, other OS/Python versions and release qualification are NOT_RUN here. No commit, push, merge, tag, automation or publication was performed by this task; r65 remains paused.
