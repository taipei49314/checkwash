"""Capture scoped reader diagnostics tests, source hashes and native output."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1] / "checkwash-ux"
name = sys.argv[1]
temporary = HERE / "temp"
temporary.mkdir(exist_ok=True)
owned = ("src/checkwash/gitio/snapshot.py", "tests/test_snapshot_path_diagnostics.py")
def hashes():
    return {path: hashlib.sha256((REPO / path).read_bytes()).hexdigest() for path in owned}
def head():
    return subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=REPO).decode().strip()

command = [sys.executable, "-B", "-m", "pytest", "-p", "no:cacheprovider", "-ra",
           "--basetemp", str(HERE / ("t-" + name)), "--junitxml", str(HERE / (name + ".xml")),
           *sys.argv[2:]]
env = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1", "PYTHONPATH": str(REPO / "src"),
       "PYTHONUTF8": "1", "TEMP": str(temporary), "TMP": str(temporary)}
before = hashes()
meta = {"marker": "HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL", "hostname": platform.node(),
        "runtime": sys.version, "platform": platform.platform(), "executable": sys.executable,
        "git_version": subprocess.check_output(["git", "--version"]).decode().strip(),
        "source_sha_start": head(), "owned_before": before, "command": command, "cwd": str(REPO),
        "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "fixture_execution": "Fixture Python is static input only; native junctions are owned local fixtures."}
start = time.monotonic()
try:
    result = subprocess.run(command, cwd=REPO, env=env, capture_output=True, timeout=600)
    code, stdout, stderr, timed_out = result.returncode, result.stdout, result.stderr, False
except subprocess.TimeoutExpired as exc:
    code, stdout, stderr, timed_out = None, exc.stdout or b"", exc.stderr or b"", True
(HERE / (name + ".stdout")).write_bytes(stdout)
(HERE / (name + ".stderr")).write_bytes(stderr)
meta.update({"source_sha_end": head(), "owned_after": hashes(), "elapsed_seconds": time.monotonic() - start,
             "exit_code": code, "timed_out": timed_out,
             "stdout_sha256": hashlib.sha256(stdout).hexdigest(),
             "stderr_sha256": hashlib.sha256(stderr).hexdigest(),
             "ended_utc": datetime.datetime.now(datetime.timezone.utc).isoformat()})
meta["owned_unchanged_during_run"] = meta["owned_before"] == meta["owned_after"]
(HERE / (name + ".json")).write_text(json.dumps(meta, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"name": name, "exit": code, "timed_out": timed_out,
                  "owned_unchanged": meta["owned_unchanged_during_run"],
                  "summary": stdout.decode("utf-8", "replace").splitlines()[-10:]}))
raise SystemExit(code if code is not None else 3)
