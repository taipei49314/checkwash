# Tracked Stop-hook maintenance diagnostic

HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL. Host LAPTOP-01AGNPJU;
Windows 10.0.26200; Python 3.11.9; pytest 9.1.1. This is a development
shared-tree receipt with named file hashes, not fixed whole-tree qualification.
No commit, publication, protected source edit, installer edit, or gating edit.

## Product change

Only `src/checkwash/doctor.py` and new
`tests/test_doctor_hook_maintenance.py` are owned changes. Once an actual
Stop configuration has been detected in either fixed project settings path,
doctor uses the existing sanitized `_git_query` with literal `ls-files -z`
and checks exact NUL-delimited path membership in the Git index.

The new **info** note names only detected, tracked settings. It explains that
installing/reinstalling can change tracked guardrails, asks the user to inspect
`git diff` and follow the existing BASE/review process, and explicitly states
that doctor does not exempt hook maintenance from guardrail checks.
Untracked settings, tracked non-Stop settings, unavailable index queries,
and lookalike index paths do not acquire this note. Existing CI/local-hook
authority and exit decisions remain unchanged. No finding schema, rule,
fingerprint implementation or severity policy changed.

## Red / green

- `before/receipt.json`, `stdout.bin`, `stderr.bin`: new module, 13 cases;
  **6 failed, 7 passed**, exit 1. Six failures expose absent tracked guidance.
  The seven negative controls already passed. `doctor.before.py` preserves
  the pre-fix source. New test bytes were identical in red and green.
- `after/receipt.json`, `stdout.bin`, `stderr.bin`: new module plus existing
  `test_doctor.py` and `test_doctor_policy_sources.py`; **42 passed, 1 skipped**,
  exit 0. Includes canonical healthy-CI and existing local-hook behaviors.
  All recorded source/test hashes were stable through this run.
- Existing configured `-q` plus explicit `-q` suppress pytest's numeric summary;
  stored status progress is `.....................s.....................`.
  The new module has 13 collected parameterized cases. No existing tests or
  fixture labels were edited. Product `git diff --check` succeeded.

The after run began at HEAD `825e2dc22c9cda8f0c4c20311482f5ab0df7da31` with
the diagnostic uncommitted. Root subsequently advanced HEAD independently.
Other agents had unrelated concurrent files; no whole-tree source claim is made.

## Native owned fixture

`native-manifest.json` captures host/runtime, source HEAD, hashes, all 11 native
commands, exits and SHA-256 references to their raw stdout/stderr bytes in
`native-raw/`. The fixture lives only in `native-fixture/`, with repository-local
configuration, empty owned Git hooks, and a tracked legacy managed Stop
configuration in `.claude/settings.local.json`. It contains no executable test
program. Four top-level product CLI calls ran, plus the installer's normal
internal version probe:

| Observation | Actual result |
|---|---|
| Clean HEAD/worktree control | `check --format json`: exit 0, `verdict: pass` |
| Doctor on tracked legacy Stop settings | exit 1 because local hook lacks CI; existing reinstall advice and new tracked-maintenance info both present |
| Actual `hook install --agent claude-code --local` | exit 0; settings bytes changed, Stop and SessionStart configurations written |
| Check after actual installation | exit 1, `verdict: block`; `GUARDRAIL_TOUCHED`, critical, path `.claude/settings.local.json`, `allowlisted: false` |

The raw post-install finding retains a v2 content-bound fingerprint.
The note grants no exemption and the pre-existing guardrail behavior remains
observable after maintenance.

`native_fixture.initial.py` preserves the first harness. Its final audit
assertion incorrectly expected uppercase `PASS`/`BLOCK`; the real JSON schema
correctly emitted lowercase `pass`/`block`, so the outer harness exited 1
after recording every actual product result. No child product call failed
unexpectedly. The corrected `native_fixture.py` uses lowercase values.
`validate_raw.py` then independently checked the preserved raw hashes and all
expected observations, without rerunning the product, and wrote
`native-validation.json` with validation exit 0. The original manifest and raw
files were not rewritten to hide the harness error.

This is a representative legacy-configuration maintenance reproduction,
**not** complete historical-version upgrade validation. Claude, models and
fixture programs were never invoked. Claude Stop lifecycle and other operating
systems/runtimes were not tested.
