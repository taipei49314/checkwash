"""Read-only validation of preserved native receipt bytes; no product calls."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import platform
import sys

HERE = Path(__file__).resolve().parent
manifest = json.loads((HERE / "native-manifest.json").read_text(encoding="utf-8"))
commands = {row["label"]: row for row in manifest["commands"]}
for row in commands.values():
    for stream in ("stdout", "stderr"):
        assert hashlib.sha256(Path(row[stream]).read_bytes()).hexdigest() == row[stream + "_sha256"]
before = json.loads(Path(commands["06-check-before"]["stdout"]).read_bytes())
after = json.loads(Path(commands["11-check-after"]["stdout"]).read_bytes())
doctor = Path(commands["07-doctor-before-install"]["stdout"]).read_bytes()
guardrails = [finding for finding in after["findings"] if finding["rule"] == "GUARDRAIL_TOUCHED"]
assert commands["06-check-before"]["exit_code"] == 0 and before["verdict"] == "pass"
assert commands["07-doctor-before-install"]["exit_code"] == 1
assert b"hook install --agent claude-code" in doctor
assert b"hook maintenance can change tracked guardrails" in doctor
assert b"existing BASE/review" in doctor.replace(b"\r\n", b" ").replace(b"\n", b" ")
assert commands["08-install"]["exit_code"] == 0
assert (HERE / "settings-before.json").read_bytes() != (HERE / "settings-after.json").read_bytes()
assert commands["11-check-after"]["exit_code"] == 1 and after["verdict"] == "block"
assert any(finding["path"] == ".claude/settings.local.json" and finding["severity"] == "critical"
           and not finding["allowlisted"] for finding in guardrails)
assert manifest["owned_sources_unchanged"]
result = {"provenance": "HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL", "host": platform.node(),
          "runtime": sys.version, "validated_utc": datetime.now(timezone.utc).isoformat(),
          "scope": "read-only validation of existing raw bytes; no product rerun",
          "initial_harness_exit": 1,
          "initial_harness_error": "audit expected uppercase PASS/BLOCK, while product JSON correctly emits lowercase pass/block",
          "initial_script_sha256": hashlib.sha256((HERE / "native_fixture.initial.py").read_bytes()).hexdigest(),
          "corrected_reproducer_sha256": hashlib.sha256((HERE / "native_fixture.py").read_bytes()).hexdigest(),
          "preserved_native_manifest_sha256": hashlib.sha256((HERE / "native-manifest.json").read_bytes()).hexdigest(),
          "raw_command_hashes_verified": len(commands), "top_level_product_cli_calls": 4,
          "installer_internal_version_probes": 1,
          "validation_exit_code": 0, "summary": manifest["summary"]}
(HERE / "native-validation.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"validation": "pass", "raw_commands_verified": len(commands),
                  "top_level_product_cli_calls": 4, "guardrail_findings": len(guardrails)}))
