Trusted, session-owned static fixture; no fixture program is executed.
