"""Owned legacy Stop configuration maintenance, not a Claude lifecycle test."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys

HERE = Path(__file__).resolve().parent
SESSION = HERE.parents[2]
SOURCE = SESSION / "work/checkwash-ux"
FIXTURE = HERE / "native-fixture"
RAW = HERE / "native-raw"
TMP = HERE.parent / "hmtmp"
assert FIXTURE.resolve().is_relative_to(HERE.resolve())
FIXTURE.mkdir(exist_ok=False)
RAW.mkdir(exist_ok=False)
TMP.mkdir(exist_ok=True)
(FIXTURE / "empty-hooks").mkdir()
env = {key: value for key, value in os.environ.items() if not key.upper().startswith("GIT_")}
env.update(PYTHONPATH=str(SOURCE / "src"), PYTHONDONTWRITEBYTECODE="1", TEMP=str(TMP), TMP=str(TMP),
           GIT_CONFIG_GLOBAL=os.devnull, GIT_CONFIG_NOSYSTEM="1", GIT_OPTIONAL_LOCKS="0",
           GIT_TERMINAL_PROMPT="0", GCM_INTERACTIVE="Never")
records = []
paths = ["src/checkwash/doctor.py", "src/checkwash/hooks.py", "src/checkwash/cli.py",
         "src/checkwash/gating.py", "tests/test_doctor_hook_maintenance.py"]
def hashes():
    return {path: hashlib.sha256((SOURCE / path).read_bytes()).hexdigest() for path in paths}
owned_before = hashes()
source_head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=SOURCE).decode().strip()

def run(label, command, cwd=FIXTURE):
    started = datetime.now(timezone.utc).isoformat()
    process = subprocess.run(command, cwd=cwd, env=env, stdin=subprocess.DEVNULL,
                             capture_output=True, timeout=60, check=False)
    stdout = RAW / (label + ".stdout.bin")
    stderr = RAW / (label + ".stderr.bin")
    stdout.write_bytes(process.stdout)
    stderr.write_bytes(process.stderr)
    records.append({"label": label, "command": command, "cwd": str(cwd), "exit_code": process.returncode,
                    "started_utc": started, "ended_utc": datetime.now(timezone.utc).isoformat(),
                    "stdout": str(stdout), "stderr": str(stderr),
                    "stdout_sha256": hashlib.sha256(process.stdout).hexdigest(),
                    "stderr_sha256": hashlib.sha256(process.stderr).hexdigest()})
    return process

def git(label, *args):
    result = run(label, ["git", "--no-optional-locks", "-c", "core.fsmonitor=false",
                        "-c", "core.hooksPath=" + str(FIXTURE / "empty-hooks"),
                        "--literal-pathspecs", *args])
    assert result.returncode == 0, label
    return result

def cli(label, *args):
    return run(label, [sys.executable, "-B", "-m", "checkwash", *args, "--repo", str(FIXTURE)])

git("01-init", "init", "--quiet")
git("02-autocrlf", "config", "core.autocrlf", "false")
settings = FIXTURE / ".claude/settings.local.json"
settings.parent.mkdir()
legacy = {"hooks": {"Stop": [{"hooks": [{"type": "command", "command": "checkwash check --format hook-json"}]}]}}
settings.write_bytes((json.dumps(legacy, indent=2) + "\n").encode())
(HERE / "settings-before.json").write_bytes(settings.read_bytes())
(FIXTURE / "README.md").write_bytes(b"Trusted, session-owned static fixture; no fixture program is executed.\n")
git("03-add", "add", "-f", "--", ".claude/settings.local.json", "README.md")
git("04-commit", "-c", "user.name=Owned fixture", "-c", "user.email=fixture@example.invalid",
    "commit", "--quiet", "--no-verify", "-m", "owned legacy Stop settings baseline")
git("05-index-before", "ls-files", "--stage", "-z")
before_check = cli("06-check-before", "check", "--format", "json")
doctor = cli("07-doctor-before-install", "doctor")
install = cli("08-install", "hook", "install", "--agent", "claude-code", "--local")
(HERE / "settings-after.json").write_bytes(settings.read_bytes())
git("09-status-after", "status", "--porcelain=v1", "--untracked-files=all")
git("10-diff-after", "diff", "--", ".claude/settings.local.json")
after_check = cli("11-check-after", "check", "--format", "json")
before_json = json.loads(before_check.stdout)
after_json = json.loads(after_check.stdout)
after_findings = after_json.get("findings", [])
summary = {"before_check_exit": before_check.returncode, "before_check_verdict": before_json.get("verdict"),
           "doctor_exit": doctor.returncode,
           "doctor_reinstall_advice_present": b"hook install --agent claude-code" in doctor.stdout,
           "doctor_tracked_maintenance_note_present": b"hook maintenance can change tracked guardrails" in doctor.stdout,
           "install_exit": install.returncode,
           "settings_changed": (HERE / "settings-before.json").read_bytes() != settings.read_bytes(),
           "after_check_exit": after_check.returncode, "after_check_verdict": after_json.get("verdict"),
           "after_guardrail_findings": [finding for finding in after_findings if finding.get("rule") == "GUARDRAIL_TOUCHED"]}
owned_after = hashes()
manifest = {"provenance": "HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL", "host": platform.node(),
            "runtime": sys.version, "executable": sys.executable, "platform": platform.platform(),
            "scope": "development shared tree; owned native Git fixture; representative legacy Stop configuration only",
            "not_claimed": ["complete historical-version upgrade verification", "Claude Stop lifecycle", "model execution", "other platforms"],
            "source_head_at_start": source_head, "source": str(SOURCE), "fixture": str(FIXTURE),
            "owned_hashes_before": owned_before, "owned_hashes_after": owned_after,
            "owned_sources_unchanged": owned_before == owned_after, "commands": records, "summary": summary}
(HERE / "native-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
print(json.dumps(summary, indent=2))
assert owned_before == owned_after
assert before_check.returncode == 0 and before_json.get("verdict") == "PASS"
assert summary["doctor_reinstall_advice_present"] and summary["doctor_tracked_maintenance_note_present"]
assert install.returncode == 0 and summary["settings_changed"]
assert after_check.returncode == 1 and after_json.get("verdict") == "BLOCK" and summary["after_guardrail_findings"]
