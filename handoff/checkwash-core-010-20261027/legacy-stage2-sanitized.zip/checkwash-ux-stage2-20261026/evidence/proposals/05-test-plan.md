# Proposed controls — all changed-judge results NOT_RUN

The packet contains no applied code and no execution of a modified protected
judge. The following are acceptance-plan drafts, not newly labeled corpus
results. Existing expectations stay unchanged until human review.

## Controls already observed on the two old sources

| Shape | Observed old behavior | Unexecuted narrow-draft expectation |
|---|---|---|
| A, freeze false | Both entrances info/ASSERTION_MOVED/PASS | Unchanged; default escape remains |
| A, freeze true | Both entrances info/ASSERTION_MOVED/PASS | Same key and spent credit, high/ORACLE_FREEZE/BLOCK |
| B and B_from_A, freeze false | warn/RESTRUCTURED/PASS | Unchanged; D5 is untouched |
| B and B_from_A, freeze true | high/RESTRUCTURED/ORACLE_FREEZE/BLOCK | Unchanged |
| Literal N changed expectations | Three EXPECTED_VALUE_CHANGED/high/BLOCK | Unchanged; do not relabel as an escape |
| Rename-only, preserved unroll, pure cross-file move | No findings/PASS | Expected unchanged; these do not cover every preserving text-only move |
| Same-name context weakening | TEST_DISABLED/high/BLOCK | Unchanged |
| Cross-file param-only change, worktree, either freeze value | TEST_DISABLED/info/ASSERTION_MOVED/PASS | Unchanged body-hash residual; must not claim closure |
| Cross-file param-only change, range | EXPECTATION_DEFINITION_CHANGED/high/BLOCK | Unchanged |

`04-movement-inventory.json` enumerates all 72 original rows, four predicted
movements and 68 expected unchanged rows, with exact original source/receipt
pointers. The forecast covers only that finite inventory.

## Additional controls required before any acceptance

1. **Direct ASSERT_REMOVED text route.** A small IR-level finding has before
   evidence matching exactly one moved-text credit, and no whole-body proof.
   Without freeze expect info/ASSERTION_MOVED; with freeze expect the same
   key, high/ASSERTION_MOVED+ORACLE_FREEZE. This route is not directly
   exercised by the original matrix and cannot borrow A's coverage.
2. **Credit spending.** Give two removals one matching moved-text credit.
   Verify the first still consumes it once, the second is not granted a new
   credit, and the draft did not reset or duplicate counters.
3. **Disappeared-unit own-assertion route.** Retain A plus a preserving
   text-only relocation whose normalized whole bodies differ. Price the
   latter explicitly: a freeze block is a cost of this proposed policy, not
   proof that its source behavior was malicious. Do not claim the original
   no-finding rename control proves zero cost.
4. **Whole-body and D10 priorities.** A real whole-body move under freeze,
   and a duplicate survivor in an untouched live module, retain their old
   info early returns. The known decorator/body-hash residual must stay
   visible, rather than being silently counted as fixed.
5. **Existing exemptions.** A valid active base-side exemption still matches
   the unchanged key and bypasses the same gate. Retired/invalid/expired
   records do not acquire eligibility. No writer or base-trust change.
6. **Non-oracle and inert markers.** Existing non-oracle classification and
   the inert conftest pytestmark finding retain their old routes; a freeze
   flag must not turn an inert marker into an active disable.
7. **Both supported language families.** Because the patch branches are
   language-neutral, include JS/TS move/collection-live controls as well as
   Python, with unchanged known context and explicit unknown boundaries.
   Existing Python-only receipts cannot qualify JS/TS behavior.
8. **Final-source evidence.** After exact protected scope is adopted and a
   candidate is fixed, run its relevant regressions, public/unpublished
   baseline comparisons, source suite and actual pinned Action dogfood under
   the applicable workflow. Distribution, nine-platform claims and the full
   official assertion qualification need their own matching receipts.

No historical sweep, natural cohort, model/adjudication batch or old release
attempt is authorized by this plan. If broader cost evidence is needed, define
and approve that separate population/source/budget before execution. The
four-case qualification smoke from stage 1 is not a 283-case release gate.
