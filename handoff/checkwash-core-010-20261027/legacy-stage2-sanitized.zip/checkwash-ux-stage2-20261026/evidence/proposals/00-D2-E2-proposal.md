# D2 assertion-text credit / E2 ordering — exact draft only

Status: **NOT ADOPTED / NOT APPLIED / NOT EXECUTED**. Prepared on 2026-10-26
from the existing 72 static CLI receipts. This package does not authorize a
protected edit, version bump, experiment, merge or publication; r65 remains.
It is an internal review packet, not a question requiring Nelson to reply now.

## Exact proposed decision

When a finding qualifies for one of D2's **assertion-text-only** credits and
the base-owned contract declares `oracle_freeze: true`, spend and retain that
credit as today, but apply E2 before the early return: severity becomes high
and ORACLE_FREEZE is recorded. Keep the existing priority of valid base-side
allowlist hits. Keep D2 whole-body and D10 duplicate early returns unchanged.

The two exact sites are:

1. ASSERT_REMOVED with matching removed-assertion normalized text in `moved`.
2. A disappeared TEST_DISABLED unit whose own assertion-text multiset is
   covered by `moved`, **after** whole-body and duplicate routes did not match.

The attached gating patch adds only an E2 override at those two sites and
clarifies the module comment. It does not move the shared E2 block, stop
spending credits, change matching or add a new fingerprint scheme. This
preserves the credit accounting and avoids accidentally changing E1/D1/D5
classification just to let E2 be reached.

These branches are language-neutral. The draft therefore applies to Python
and JS/TS findings reaching them; **the existing 72 receipts cover Python
only**. JS/TS cost/compatibility is NOT_RUN and must be covered before adopting
an implementation. There is no hidden claim that all language effects have
already been measured.

## Frozen binding and files

The draft is based on the exact bytes of protected `src/checkwash/gating.py`,
`SPEC.md` and `DECISIONS.md` at `f86aabbbe7e61891d8b93cb2c043b9bcae44f88a`.
The builder verifies current protected files still equal those frozen Git
blobs and records SHA-256. The builder never imports or runs the proposed
judge and never writes repository files.

- `01-gating-proposed.patch`: minimal code draft; **do not apply** under the
  current UX-only instruction.
- `02-SPEC-proposed.patch`: exact E2 / D2 / compensation wording draft.
- `03-DECISIONS-draft.md`: proposed decision text, no number reserved and no
  false adoption record.
- `04-movement-inventory.json`: 72 original observations and source/receipt
  pointers, followed by expressly unexecuted expectations.
- `05-test-plan.md`: required positive/negative controls and limits.
- `proposal-manifest.json`: source/evidence/file hashes and zero modified-judge
  execution count. This is a draft integrity manifest, not qualification.

## What the retained evidence proves

`work/rename/results.json` has 64 observations; `supplement/results.json` has
eight. Both old sources (`d6eda4f6` public v0.9.0 and `1ffe283d` unpublished
v0.9.1) agree on verdict/finding identities in the 36 paired observations.
They are original results, not new results of this proposal.

- A changes the test name, parameter/body context and local expected value
  while preserving `assert calc(x) == expected`. That changed body excludes
  whole-body matching, and the only matching assertion survives through the
  disappeared unit's text-only D2 route. It is info/PASS even under freeze.
- B and B_from_A use RESTRUCTURED: default warn/PASS, freeze high/BLOCK.
- The literal unroll weakening N already emits three EXPECTED_VALUE_CHANGED
  high findings and BLOCKs. Its predicted escape was not reproduced.
- Cross-file parameter-only change is info/PASS under worktree even with
  freeze; the whole function body stays the same while the decorator changes,
  so its whole-body D2 route remains **outside this draft**. Range BLOCKs.
- Legitimate pure rename, expectation-preserving unroll and pure cross-file
  move produce no findings in these controls and PASS.

## Unexecuted movement expectations

Within these 72 retained observations only, source reasoning predicts:

- **Four changed observations:** A × freeze=true × two entrances × two old
  source labels. The expected new finding is the same TEST_DISABLED key and
  ASSERTION_MOVED credit, now high with ORACLE_FREEZE; PASS/0 becomes BLOCK/1
  at the existing high fail threshold.
- **68 expected unchanged observations** in this particular inventory.

This is a prereview forecast, **not a 4/72 measured improvement or a 68-pass
new run**. No changed judge was executed. Run/version metadata would bind a
future candidate separately. The ASSERT_REMOVED branch has no direct witness
in the retained matrix and needs its own proposed control before acceptance.

## Costs and residuals to accept explicitly

The policy would block a legitimate text-only move under freeze whenever
the available evidence is insufficient for whole-body matching, even if a
human can prove it preserves behavior. The 72 controls do not measure that
cost; pure rename controls with no findings do not price this shape. No
zero-false-positive or refactor-cost claim is made.

Default A/B remain escapes. The known cross-file decorator/body-hash escape
remains even under freeze. D5 mass compensation, D2 context/identity proofs,
D10 duplicate context, alignment, strength and #419 production cochange /
repair credit remain unchanged and need separate proposals. There is no
blanket prohibition on refactoring or blanket removal of compensation.

Finding construction and keys are not edited by the draft. Existing valid
base-side exemptions retain their priority and keys; this does not revoke
earlier exemptions or redefine who may advance a trusted base. A later test
must verify that claim rather than moving fixture labels to make it true.

## Version and next step

This is a protected gating/contract change. If adopted, prepare it as a
separately reviewed **minor** candidate, for example 0.10.0, with the
maintainer-assigned decision entry and matching exact-source evidence.
Current 0.9.2 narrow-fix consideration cannot imply adoption of this patch.

First perform independent review of this inert packet and its cost/residual
statement. A later explicit maintainer decision must identify the exact
protected scope. Neither this package nor the generic continuation of UX
work approves applying it, changing existing fixture expectations, reviving
old sweep/model grants or resuming publication.
