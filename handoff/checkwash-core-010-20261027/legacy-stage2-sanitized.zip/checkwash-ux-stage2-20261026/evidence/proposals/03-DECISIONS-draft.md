# Proposed DECISIONS entry — unassigned, not adopted

Do not insert as an approved entry. The maintainer assigns the next available
decision number and adoption date only after accepting an exact scope.

## D-UNASSIGNED: oracle_freeze overrides assertion-text-only D2 credit

**Status: PROPOSED. No maintainer decision is recorded by this draft.**

The retained Python rename controls on public v0.9.0 `d6eda4f6` and unpublished
v0.9.1 `1ffe283d` show a changed test name/local expectation shape A kept at
info by ASSERTION_MOVED even when the base task freezes oracles. D2's assertion
text does not bind the old parameter rows and reaching definitions. The
literal-unroll variant N is already blocked; the evidence does not establish
that every refactor or every unroll escapes.

Proposed ruling: for D2's removed-assertion-text route and disappeared-unit
own-assertion-multiset route, preserve spending and recording the move credit,
then apply E2 before returning. Under oracle_freeze the same finding/key is
high with ORACLE_FREEZE. Without freeze the route remains info. No new rule,
strength value, identity scheme or alignment parameter is introduced.

D2 whole-body credits and D10 duplicate-survivor credits retain their existing
early returns. Active base-side exemptions retain their existing precedence.
D5, repair credit, opaque-change treatment, default A/B escapes and the known
cross-file decorator/body-hash residual are not changed by this ruling.

This draft is language-neutral at those two branches. Its motivating 72
retained observations cover Python only. JS/TS controls and legitimate
text-only move costs remain unmeasured. A legitimate move supported only by
assertion text can newly block under freeze; the maintainer must consider that
cost rather than treating the patch as free precision.

Source reasoning predicts four A/freeze observations changing from PASS/info
to BLOCK/high within the 72 old observations; those are expectations, not
execution results. The changed judge has not been applied or run. The
ASSERT_REMOVED site still requires a direct regression/control pair.

If adopted, implement and validate an exact minor candidate, naming both
public v0.9.0 and unpublished v0.9.1 comparison baselines. Preserve historical
receipts and labels; any fixture expectation change follows human review.
The minor number does not grant publication. r65, consumed grants and all
other admission/release conditions remain independently in force.
