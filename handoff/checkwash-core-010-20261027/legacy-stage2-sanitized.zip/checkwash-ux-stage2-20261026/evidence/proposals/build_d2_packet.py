"""Generate inert policy drafts from frozen bytes and existing receipts only.

Never imports or executes the proposed judge. Never writes repository files.
"""
from collections import Counter
import difflib
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys

HERE = Path(__file__).resolve().parent
WORK = HERE.parents[1]
REPO = WORK / "checkwash-ux"
BASE = "f86aabbbe7e61891d8b93cb2c043b9bcae44f88a"

def frozen(path):
    raw = subprocess.check_output(["git", "show", BASE + ":" + path], cwd=REPO)
    actual = (REPO / path).read_bytes()
    assert raw == actual, path + " is not the frozen policy source"
    return raw

gating_bytes = frozen("src/checkwash/gating.py")
spec_bytes = frozen("SPEC.md")
decisions_bytes = frozen("DECISIONS.md")
gating = gating_bytes.decode("utf-8")
proposed = gating.replace(
    "This file IS the auditable policy. Applied in order: D2, E1, E2, D1, D3.\n"
    "(D2 first because a moved assertion is conclusively benign and skips\n"
    "escalation entirely; the SPEC table remains the authority on semantics.)",
    "This file IS the auditable policy. D2 assertion-text credits apply E2\n"
    "before their early return. D2 whole-body and D10 duplicate credits keep\n"
    "their existing early returns; the SPEC table remains the authority.",
    1,
)
old_comment = ("        # D2 ASSERTION_MOVED: conclusively benign, skips escalation. Each\n"
               "        # de-escalation *spends* a credit from the multiset.")
new_comment = ("        # D2 ASSERTION_MOVED: each move credit is still spent once.\n"
               "        # Assertion-text-only matches apply E2 before their early return;\n"
               "        # whole-body matches keep the existing info early return.")
assert old_comment in proposed
proposed = proposed.replace(old_comment, new_comment, 1)
first = '''            if moved[key] > 0:
                moved[key] -= 1
                f.severity = "info"
                f.deescalators.append("ASSERTION_MOVED")
                continue'''
first_after = first.replace('                continue', '''                if contract.oracle_freeze:
                    f.severity = "high"
                    f.escalators.append("ORACLE_FREEZE")
                continue''')
second = '''            if texts and all(moved[t] >= n for t, n in needed.items()):
                moved.subtract(needed)
                f.severity = "info"
                f.deescalators.append("ASSERTION_MOVED")
                continue'''
second_after = second.replace('                continue', '''                if contract.oracle_freeze:
                    f.severity = "high"
                    f.escalators.append("ORACLE_FREEZE")
                continue''')
assert proposed.count(first) == proposed.count(second) == 1
proposed = proposed.replace(first, first_after, 1).replace(second, second_after, 1)

def patch(path, before, after):
    return (f"diff --git a/{path} b/{path}\n" + "".join(difflib.unified_diff(
        before.splitlines(keepends=True), after.splitlines(keepends=True),
        fromfile="a/" + path, tofile="b/" + path))).encode("utf-8")

(HERE / "01-gating-proposed.patch").write_bytes(patch("src/checkwash/gating.py", gating, proposed))
spec = spec_bytes.decode("utf-8")
e2 = next(line for line in spec.splitlines() if line.startswith('| E2 `ORACLE_FREEZE` |'))
d2 = next(line for line in spec.splitlines() if line.startswith('| D2 `ASSERTION_MOVED` |'))
new_e2 = ('| E2 `ORACLE_FREEZE` | contract declares `oracle_freeze: true`. Applies before the early return of '
          'D2 assertion-text-only credit: a removed assertion text, or the own-assertion multiset of a disappeared unit. '
          'The text credit is spent and recorded as before. D2 whole-body and D10 duplicate early returns remain unchanged; '
          'a valid prior base-side allowlist hit retains its existing priority | warn → high; text-only D2 info → high |')
new_d2 = d2.replace(' | → info |', '. Under `oracle_freeze`, assertion-text-only credit still records `ASSERTION_MOVED` '
                    'but E2 makes that finding high. A whole-body match keeps its existing info early return. '
                    '| → info, except text-only credit under E2 → high |')
assert new_d2 != d2
note_before = ('None of D4–D10 suppress a finding. They only decline to *escalate* it: the\n'
               'finding stays in the report (D10, like D2, at `info`; the rest at `warn`),\n'
               'visible and allowlistable.')
note_after = ('None of D4–D10 suppress a finding. Their compensation remains visible\n'
              'and allowlistable. D10 and whole-body D2 keep their info early returns.\n'
              'Assertion-text-only D2 is info unless E2 applies; under oracle_freeze it\n'
              'keeps its spent ASSERTION_MOVED credit and becomes high with ORACLE_FREEZE.\n'
              'The other compensations retain their existing ordering relative to E2.')
assert note_before in spec
spec_after = spec.replace(e2, new_e2, 1).replace(d2, new_d2, 1).replace(note_before, note_after, 1)
(HERE / "02-SPEC-proposed.patch").write_bytes(patch("SPEC.md", spec, spec_after))

evidence = []
movement = []
for relative in ["rename/results.json", "rename/supplement/results.json"]:
    path = WORK / relative
    raw = path.read_bytes()
    data = json.loads(raw)
    evidence.append({"source": "work/" + relative, "sha256": hashlib.sha256(raw).hexdigest(),
                     "observations": len(data["results"])})
    for i, row in enumerate(data["results"]):
        change = row["case"] == "A" and row["oracle_freeze"]
        observed = [{key: finding[key] for key in ("rule", "severity", "path", "unit", "fingerprint", "escalators", "deescalators")}
                    for finding in row["findings"]]
        predicted = json.loads(json.dumps(observed))
        if change:
            assert len(predicted) == 1 and predicted[0]["rule"] == "TEST_DISABLED"
            assert predicted[0]["severity"] == "info" and "ASSERTION_MOVED" in predicted[0]["deescalators"]
            predicted[0]["severity"] = "high"
            predicted[0]["escalators"].append("ORACLE_FREEZE")
        movement.append({"source_label": row["source_label"], "source_sha": row["source_sha"],
                         "case": row["case"], "entry": row["entry"], "oracle_freeze": row["oracle_freeze"],
                         "evidence_pointer": "work/" + relative + "#/results/" + str(i),
                         "original_receipt": row["receipt"],
                         "observed_exit": row["exit"], "observed_verdict": row["verdict"], "observed_findings": observed,
                         "prediction_status": "PROPOSED_NOT_EXECUTED", "expected_movement": change,
                         "predicted_exit": 1 if change else row["exit"],
                         "predicted_verdict": "block" if change else row["verdict"], "predicted_findings": predicted,
                         "route_basis": "Changed body/name/locals excludes body-hash; A reaches own-assertion text credit" if change else
                                        "Existing observed route is outside the two proposed text-credit overrides, or freeze is false"})
assert len(movement) == 72
assert sum(row["expected_movement"] for row in movement) == 4
inventory = {"kind": "PROPOSAL_EXPECTATIONS_NOT_RESULTS", "modified_judge_executions": 0,
             "old_observations": 72, "predicted_changed": 4, "predicted_unchanged": 68,
             "source_labels": dict(Counter(row["source_label"] for row in movement)), "evidence": evidence, "rows": movement}
(HERE / "04-movement-inventory.json").write_text(json.dumps(inventory, indent=2) + "\n", encoding="utf-8")
manifest = {"status": "DRAFT_NOT_ADOPTED_NOT_APPLIED_NOT_EXECUTED", "base_commit": BASE,
            "provenance": "HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL", "hostname": platform.node(),
            "builder_runtime": sys.version, "builder_scope": "read frozen bytes and old receipts; write inert drafts only",
            "version_recommendation": "minor candidate, e.g. 0.10.0; no bump/publication authority",
            "protected_source_sha256": {"src/checkwash/gating.py": hashlib.sha256(gating_bytes).hexdigest(),
                                        "SPEC.md": hashlib.sha256(spec_bytes).hexdigest(),
                                        "DECISIONS.md": hashlib.sha256(decisions_bytes).hexdigest()},
            "evidence": evidence, "prediction_counts": {"changed": 4, "unchanged": 68},
            "modified_judge_executions": 0,
            "files": {path.name: hashlib.sha256(path.read_bytes()).hexdigest()
                      for path in sorted(HERE.iterdir()) if path.is_file() and path.name != "proposal-manifest.json"}}
(HERE / "proposal-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"status": manifest["status"], "old_observations": 72,
                  "predicted_changed": 4, "predicted_unchanged": 68, "modified_judge_executions": 0}))
