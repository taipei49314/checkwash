"""Read owned result files and hash the diagnostic-only assertion updates."""
import hashlib
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1] / "checkwash-ux"
summary = {"runs": {}, "native": {}, "assertion_updates": {}}
for name in ("red", "green"):
    meta = json.loads((HERE / (name + ".json")).read_text(encoding="utf-8"))
    cases = list(ET.parse(HERE / (name + ".xml")).iter("testcase"))
    summary["runs"][name] = {key: meta[key] for key in (
        "marker", "hostname", "runtime", "source_sha_start", "source_sha_end", "owned_before",
        "owned_after", "exit_code", "elapsed_seconds", "owned_unchanged_during_run")}
    summary["runs"][name].update({"total": len(cases),
        "failed": sum(case.find("failure") is not None or case.find("error") is not None for case in cases),
        "skipped": sum(case.find("skipped") is not None for case in cases),
        "new_tests": sum(case.get("classname") == "tests.test_snapshot_nonregular_diagnostics" for case in cases)})
    summary["native"][name] = {}
    for fmt in ("json", "hook-json"):
        stem = HERE / ("t-" + name) / "nested0/parent/.git" / ("nonregular-" + fmt)
        out = stem.with_suffix(".stdout").read_bytes()
        err = stem.with_suffix(".stderr").read_bytes()
        native = json.loads(stem.with_suffix(".meta.json").read_text(encoding="utf-8"))
        summary["native"][name][fmt] = {"exit": native["exit"], "payload": json.loads(out) if out else None,
                                         "stderr": err.decode("utf-8"),
                                         "stdout_sha256": hashlib.sha256(out).hexdigest(),
                                         "stderr_sha256": hashlib.sha256(err).hexdigest()}
for path in ("tests/test_issue346_config_reads.py", "tests/test_gitlink_snapshot.py",
             "tests/test_snapshot_path_diagnostics.py"):
    original = subprocess.check_output(["git", "show", "2c06ea98bcea84aac0ba0dd51b561e589ab155ae:" + path], cwd=REPO)
    summary["assertion_updates"][path] = {"baseline_sha256": hashlib.sha256(original).hexdigest(),
                                          "after_sha256": hashlib.sha256((REPO / path).read_bytes()).hexdigest()}
summary["comparison"] = {
    "json_refusal_exit_unchanged": summary["native"]["red"]["json"]["exit"] == summary["native"]["green"]["json"]["exit"] == 2,
    "json_no_payload_unchanged": summary["native"]["red"]["json"]["payload"] is None and summary["native"]["green"]["json"]["payload"] is None,
    "hook_exit_unchanged": summary["native"]["red"]["hook-json"]["exit"] == summary["native"]["green"]["hook-json"]["exit"] == 0,
    "hook_only_not_analysed_message": all(set(summary["native"][stage]["hook-json"]["payload"]) == {"systemMessage"} for stage in ("red", "green"))}
(HERE / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"runs": {stage: {key: row[key] for key in ("exit_code", "total", "failed", "skipped", "new_tests", "source_sha_start", "source_sha_end")} for stage, row in summary["runs"].items()},
                  "comparison": summary["comparison"],
                  "green_snapshot_hash": summary["runs"]["green"]["owned_after"]["src/checkwash/gitio/snapshot.py"]}, indent=2))
