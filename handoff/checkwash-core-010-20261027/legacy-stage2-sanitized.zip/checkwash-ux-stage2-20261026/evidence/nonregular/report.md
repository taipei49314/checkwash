# Stage 2 — worktree nonregular refusal diagnostics

Named defect: missing side/reader-entry/recovery context on existing worktree single-file and batch nonregular-source refusals.
Host `LAPTOP-01AGNPJU`, Windows, Python 3.11.9, pytest 9.1.1, Git 2.55.0.windows.3;
`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`.

This is a separate slice from the outside-path repair. Its evidence does not overwrite `work/ux-stage2/reader` or the original stage-1 receipts.

## Bounded implementation

`_nonregular` accepts optional diagnostic context. Only the two existing `WorkingTreeSnapshot.read` / `read_many` refusal call sites opt in. Their original condition, error class and refusal remain unchanged. The context quotes the logical path and side, names the actual reader method, and recommends a repository-owned regular source while clarifying that committed ranges read committed bytes only. Absolute input paths are redacted; the helper never reads or prints a link target.

GitSnapshot and other direct helper call sites retain their original text. The worktree search-specific refusal call site is unchanged; where a caller delegates to `read`, that actual read's refusal carries its new context. Directory-symlink ancestry and outside-repository branches retain their existing decisions. Git mode160000 pointer handling and checked-out submodule context are untouched.

Example after the fix:

```text
strict snapshot cannot inspect nonregular source 'nested/' (a directory); side='worktree', entry='worktree/read'. Use a repository-owned regular source at this path; a committed range reads committed bytes only.
```

## Validation and actual source binding

| Phase | Actual integration HEAD | Result |
|---|---|---|
| Red | `1fdec66403400ed99f585f6963dca7b3cd410300` | 11 failed / 3 passed; exit 1; all 14 new cases executed |
| Green | `37ea0ee6198d26a5d1bb6feacc08167e2b10f418` plus owned worktree diff | 65 passed / 10 skipped; exit 0; all 14 new cases passed |

The green run includes the new 14 cases, the previous 11 outside-path cases, issue346, strict-snapshot, all 22 gitlink cases and issue414. It took 282.32 seconds in pytest. Owned snapshot/test hashes were unchanged during both runs; exact hashes, commands, start/end HEADs and output hashes are in `red.json` / `green.json`. Green owned `snapshot.py` SHA-256 is `381d2facf8c7a813cf6cfecda26c8052f326735bd19fc0323042b7d3223ee0d9`.

The ten existing skips are native symlink creation with Windows `WinError 1314`, retained as skips. New worktree symlink-branch tests use controlled metadata to verify the exact existing refusal branch without claiming native symlink capability. The previous inside/outside native junction cases actually execute in the green group. These are scoped integration-working-tree receipts; final committed-source validation belongs to root.

Controls cover directories, single-file/batch entrypoints, absolute-path redaction, LF/ESC/bidirectional-control escaping, regular file and absence behavior, unchanged legacy helper text, actual registered-gitlink regressions and ordinary nested-repository refusal. Guarded reads demonstrate that refusal does not open the link/source.

A native unregistered nested repository with a neighboring test weakening remains refused: JSON exit 2 with no ordinary payload, hook-json exit 0 with **only `systemMessage`** and no `decision`. Before/after exits and payload shape are identical. This does not claim the neighboring change was analysed or clean.

## Existing pure-message assertion updates

Only these existing diagnostic assertions changed; no expected finding/verdict or corpus/golden label changed:

1. `test_issue346_config_reads.py::test_working_tree_refusal_names_a_directory`: quoted logical path plus side/read/recovery context.
2. `test_issue346_config_reads.py::test_working_tree_batch_refusal_names_the_symlinked_path`: quoted logical path plus side/batch/recovery context. Native test remains skipped where the host lacks symlink capability; a new controlled branch test actually verifies the context.
3. `test_gitlink_snapshot.py::test_unregistered_nested_repository_still_refuses`: regex accepts the newly quoted `nested/` path, retaining `EngineError` and directory refusal.
4. The previous `test_snapshot_path_diagnostics.py` nonregular control was renamed to `test_nonregular_admission_remains_refused` and now checks the unchanged reason with the added fields.

The Git batch/Python inventory exact-message tests and the direct legacy `_nonregular` exact-message test remain unchanged. `summary.json` records before/after hashes of the three existing assertion files.

## Evidence and limits

- `red.*` / `green.*`: native pytest stdout, stderr, JUnit and command/source metadata.
- `t-{red,green}/nested0/parent/.git/nonregular-*`: original native CLI bytes, command/exits and Git status.
- `summary.json`: read-only test counts, source hashes and native before/after comparisons.
- `task-review.md` / `task-review.json`: independent read-only TASK diagnostics review and two unsupported-form omissions reported to root. Root fixed them in `6c031741`; the separate `task-review-followup.json` confirms their warnings with unchanged parser results.

No analysed fixture Python was executed. No protected file, `.gwcase` expectation, severity, strength, alignment, parser language, version, tag, automation or publication was changed. No commit or push was performed by this task. Other OS/Python versions and release qualification are NOT_RUN; r65 remains paused.

Root integrated the nonregular slice as `825e2dc22c9cda8f0c4c20311482f5ab0df7da31` after the scoped green result.
