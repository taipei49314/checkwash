def total():
    return round(78.75, 2)
