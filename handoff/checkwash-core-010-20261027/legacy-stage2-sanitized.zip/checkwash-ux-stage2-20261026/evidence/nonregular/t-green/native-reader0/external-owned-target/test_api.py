from pkg import api

def test_api():
    assert api() > 0
