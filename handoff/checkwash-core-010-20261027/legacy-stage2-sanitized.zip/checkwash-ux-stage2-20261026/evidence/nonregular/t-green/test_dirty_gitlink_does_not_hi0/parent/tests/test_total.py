from pkg import total

def test_total():
    assert total() == 75
