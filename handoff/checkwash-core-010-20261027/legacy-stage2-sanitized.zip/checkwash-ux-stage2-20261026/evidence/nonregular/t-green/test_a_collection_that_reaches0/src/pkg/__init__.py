def total():
    return 78.75
