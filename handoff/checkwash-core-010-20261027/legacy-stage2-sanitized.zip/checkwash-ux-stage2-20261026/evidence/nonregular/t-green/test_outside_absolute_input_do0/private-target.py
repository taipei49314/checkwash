private bytes
