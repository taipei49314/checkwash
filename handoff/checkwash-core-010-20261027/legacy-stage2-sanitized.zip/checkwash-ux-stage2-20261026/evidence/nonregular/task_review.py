"""Read-only static/parser probes for the separate TASK diagnostics patch."""
import ast
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1] / "checkwash-ux"
sys.path.insert(0, str(REPO / "src"))
from checkwash.contract import parse_contract, contract_diagnostics

source = (REPO / "src/checkwash/contract.py").read_bytes()
baseline = subprocess.check_output(["git", "show", "2c06ea98bcea84aac0ba0dd51b561e589ab155ae:src/checkwash/contract.py"], cwd=REPO)
def node(text, name):
    return ast.dump(next(item for item in ast.parse(text).body if getattr(item, "name", None) == name), include_attributes=False)

canonical = "---\ncheckwash:\n  oracle_freeze: true\n  scope:\n    allow:\n      - tests/**\n---\n"
cases = {"canonical": canonical,
         "boolean_comment": canonical.replace("true", "true # review"),
         "quoted_boolean": canonical.replace("true", '"true"'),
         "list_comment": canonical.replace("- tests/**", "- tests/** # review"),
         "indented_top_block": "---\n  checkwash:\n    oracle_freeze: true\n    scope:\n      allow:\n        - tests/**\n---\n",
         "control_text": canonical.replace("true", '"synthetic\\u001b[31m"')}
rows = {}
for name, text in cases.items():
    before = asdict(parse_contract(text))
    messages = contract_diagnostics(text)
    rows[name] = {"contract": before, "diagnostics": messages,
                  "unchanged_after_diagnostics": asdict(parse_contract(text)) == before,
                  "diagnostic_controls_absent": all("\n" not in message and "\x1b" not in message for message in messages)}
receipt = {"contract_class_ast_equal_baseline": node(source, "Contract") == node(baseline, "Contract"),
           "parse_contract_ast_equal_baseline": node(source, "parse_contract") == node(baseline, "parse_contract"),
           "source_sha256": hashlib.sha256(source).hexdigest(),
           "source_unchanged_during_probe": source == (REPO / "src/checkwash/contract.py").read_bytes(),
           "cases": rows}
(HERE / (sys.argv[1] if len(sys.argv) > 1 else "task-review.json")).write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
print(json.dumps(receipt, indent=2))
