# Read-only TASK diagnostics review

Reviewed `src/checkwash/contract.py`, its new CLI diagnostic loop and `docs/task-input.md`; no product file was changed by this review.

At probe source SHA-256 `2e63941d6b3b439fe1fc2aeed09aa71a6905946677e661d8218d4d186296454f`, the `Contract` class and `parse_contract` AST are identical to baseline `2c06ea98bcea84aac0ba0dd51b561e589ab155ae`. The new function does not mutate parsed values. Controlled canonical, commented-boolean, quoted-boolean and synthetic-control-text inputs confirmed the expected existing parser results, with fixed one-line diagnostic text and no source value echo. The CLI uses `rel!r` for the new path label and only writes advisory stderr, preserving the existing analysis envelope.

No blocking parser/admission regression was found. Two concrete unsupported forms still receive no diagnostic:

1. `scope.allow` item `- tests/** # review` is parsed as the literal glob `tests/** # review`; its trailing text is not a YAML comment. The current diagnostic function returns `[]`.
2. A top-level header indented as `  checkwash:` is ignored, leaving `present=True`, `scope_allow=[]`, `oracle_freeze=False`; the current diagnostic function returns `[]`.

These are remaining diagnostic omissions over existing parser behavior, not newly changed rulings. The patch explicitly claims partial syntax coverage. It can retain that boundary with explicit documentation, or add advisory-only notes while keeping the parser unchanged. The documentation should make the column-1 top-level header constraint and literal block-list trailing text explicit.

Evidence: `task-review.json` contains the exact controlled strings' observed contracts, messages, no-mutation checks and source hash; `task_review.py` is a trusted, read-only reproduction driver. No analyzed fixture code was run.

## Follow-up at root commit `6c031741`

Root fixed both omissions and clarified column-1 headers / literal trailing text in the documentation. A second independent read-only probe is preserved separately as `task-review-followup.json`; it confirms both forms now receive fixed, one-line advice while their existing parsed values remain exactly the same. `Contract` and `parse_contract` AST still match baseline. Follow-up `contract.py` SHA-256 is `3815e928cf249f9d32376c1b38741d63e0c33354a7b74eba5790a3d69962ec1f`. No blocking issue remains in the reviewed TASK diagnostic slice; this is still a deliberately partial syntax recognizer.
