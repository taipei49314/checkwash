⚠ checkwash: 4 finding(s), none at or above high

EXPECTED_VALUE_CHANGED   WARN   tests/test_issue346_config_reads.py :: test_working_tree_batch_refusal_names_the_symlinked_path
  test_working_tree_batch_refusal_names_the_symlinked_path: expected value rewritten 'strict snapshot batch cannot inspect nonregular source requirements/pyproject.toml (a symlink)' -> "strict snapshot batch cannot inspect nonregular source 'requirements/pyproject.toml' (a symlink); side='worktree', entry='worktree/read_many'. Use a repository-owned regular source at this path; a committed range reads committed bytes only." with no change in assertion strength
  held at warn by: REPAIR_EVIDENCE
  before  assert str(caught.value) == (
  after   assert str(caught.value) == (

EXPECTED_VALUE_CHANGED   WARN   tests/test_issue346_config_reads.py :: test_working_tree_refusal_names_a_directory
  test_working_tree_refusal_names_a_directory: expected value rewritten 'strict snapshot cannot inspect nonregular source configs/pytest.ini (a directory)' -> "strict snapshot cannot inspect nonregular source 'configs/pytest.ini' (a directory); side='worktree', entry='worktree/read'. Use a repository-owned regular source at this path; a committed range reads committed bytes only." with no change in assertion strength
  held at warn by: REPAIR_EVIDENCE
  before  assert str(caught.value) == (
  after   assert str(caught.value) == (

BROAD_EXCEPT_ADDED   WARN   src/checkwash/sweep.py
  broad exception handler added (exceptExceptionasexc:#noqa:BLE001-asweepmustsurviveonebadcommit)
  after   exceptExceptionasexc:#noqa:BLE001-asweepmustsurviveonebadcommit

SUPPRESSION_ADDED   WARN   src/checkwash/sweep.py
  lint/type suppression added (except Exception as exc:  # noqa: BLE001 - a sweep must survive one bad commit)
  after   except Exception as exc:  # noqa: BLE001 - a sweep must survive one bad commit

summary: critical=0 high=0 warn=4 info=0 verdict=pass allow_cap=180d
