# Read-only stage-2 report/export review

Result: **no remaining blocking finding in the current reviewed drafts** after
the exporter correction recorded below. This review does not run or certify
the pending final suite/compatibility matrix, invoke the exporter/package,
or modify product, raw evidence, proposals or existing verdict labels.

Reviewer: `/root/quality_fix`; LAPTOP-01AGNPJU; 2026-10-26;
HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL. Product HEAD was the clean frozen
`9a5a27f44c895ba2fdee8c83a6313baf0e120873` during the review. Ordinary reads,
Git status/identity reads, and existing JSON/text were used. No pool inquiry.

## Confirmed blocking export omission, now repaired

The original `export_stage2.py` special case copied only `.git/nonregular-*`
before skipping the remainder of each `.git` directory. The outside-reader
agent's actual before/after native bytes are instead stored at:

```
reader/t-{red,green}/native-reader0/{inside,outside,regular}/.git/reader-*
```

All 48 such files actually exist: JSON/hook-json stdout, stderr, command
metadata, index and status bytes. Omitting them would leave `reader/report.md`
and `summary.json` pointing at raw evidence absent from the package. Summaries
and their hashes do not replace the original bytes for independent inspection.

Root corrected the exporter after this finding. Reviewed current
`export_stage2.py:46–54` first rejects symlink/reparse directories using lstat,
then copies `reader-*` and `nonregular-*` only from ordinary `.git` directories.
The remainder of `.git` is still excluded. This is the minimal repair and it
needs no product/test rerun. The exported result itself remains a later copy
verification step; this review did not execute the exporter.

## Report assertions checked

- **Old 72 / proposed 4 / candidate 36 remain distinct.** The old matrix is
  36 pairs across public `d6eda4f6` and unpublished `1ffe283d`, totaling 72
  historical CLI observations. The proposal's four movements and 68 unchanged
  rows are explicitly forecasts against those observations. The new compatibility
  driver makes 36 candidate calls on frozen `9a5a27f4`, then compares each to
  both old versions, yielding 72 comparisons. The package replacement wording
  does not claim 72 new candidate executions or a measured improvement rate.
- **Protected proposal remains inert.** The report says no implementation,
  import or execution of the modified judge, retains credit consumption and
  ASSERTION_MOVED in the exact draft, and keeps whole-body/D10/D5/identity
  residuals. `proposals-review/report.md` and `audit.json` support the original
  pointer/hash checks, 36 old source pairs and six context-only hunks. The
  superseded no-credit alternative is preserved and explicitly abandoned.
- **Assertions and fixtures are distinguished.** The candidate JSON raw shows
  precisely the two EXPECTED_VALUE_CHANGED/warn findings for full-message
  equality assertions in `test_issue346_config_reads.py`, both with
  REPAIR_EVIDENCE. It also retains the two sweep warning findings, each
  allowlisted=false. The report acknowledges earlier broader substring
  assertions and names the four diagnostic assertion updates; it does not
  claim that no test assertion changed or that golden/corpus labels changed.
- **Authority is bounded.** Quality explanations/catalog/draft guidance are
  advisory; no review verdict or fake analysis is added. Hook installation
  succeeds in the owned legacy-configuration fixture but the subsequent check
  remains GUARDRAIL_TOUCHED/critical/block with allowlisted=false. The report
  explicitly declines complete historical-upgrade or Claude lifecycle coverage.
  Nothing here adopts protected policy, exempts maintenance or resumes r65.
- **Source identity discloses physical EOL.** `source_audit.py` checks every
  tracked member against its raw Git blob and reports exactly the known
  CRLF-normalization-only `docs/embedding.md` difference. Product/test/tool/
  Action bytes match Git. The AST check compares every original top-level
  Contract/parser definition with baseline `1ffe283d`; the new diagnostic
  helper does not change those original definitions. The report does not
  equate clean Git status with complete physical byte identity.
- **Actual public Action and candidate CLI are separate.** The replay is
  pinned to public v0.9.0 `d6eda4f6` and evaluates base `1ffe283d` / head
  `9a5a27f4`; its runtime receipt says version 0.9.0 and fail_on=high. The
  candidate CLI receipt binds the same full range to 9a5a with stable inputs.
  Their saved terminal/JSON results agree on critical=0/high=0/warn=4/pass.
  This does not establish candidate packaged-artifact qualification.
- **Formal checks/publication remain unclaimed.** The report explicitly says
  local Windows/Python 3.11.9 receipts are not the formal receipt bridge,
  full 283-artifact qualification, other platforms, tag/release acceptance or
  publication. Version suggestions remain conditional, with no bump.
- **Failures remain visible.** The launcher WinError2 occurred before pytest;
  the first Action replay has steps=[] and rejects mixed-EOL bytes before
  installation. The hook schema-case audit failure is retained separately
  from its valid child product results/read-only validation. Sweep driver
  failures and shared-tree source_changed caveats are described as such.

## Package behavior and pending state

The known `{{FULL_SUITE}}` and `{{COMPAT}}` placeholders are intentional, not
findings. At this review the corresponding terminal native receipts/JUnit and
comparison output were still pending; no partial result is promoted to PASS.
`package_stage2.py:17–33` refuses to finalize without exact-source successful
suite receipt, stable inputs, XML without failures/errors, and native terminal
summary. It preserves raw XML totals separately rather than rewriting subtest
accounting. Its candidate CLI checks require the stated warning/config/skip
shape. Root added the actual public Action terminal-summary assertion at
lines 37–38; it matches the saved Action raw.

The exporter hashes copied source/destination bytes. The packager rechecks
unique copy destinations and their hashes, validates local top-level report
links, then writes a separate manifest/ZIP/sidecar. It does not rewrite the old
72 observations, existing raw receipts, first-milestone ZIP or protected source.
Native completion and actual final copy/package verification are still root's
remaining work, not a result asserted by this read-only review.

## Non-blocking wording/guard suggestions

1. `report-draft.md:41`: narrow “新增 schema 表面是 optional sweep array” to
   **“既有 sweep summary 的新增 schema 表面是 optional array”**. The table
   already correctly describes newly format-valid explain JSON/SARIF, so this
   small wording change prevents the sentence sounding like the only machine
   output change across the entire candidate.
2. `package_stage2.py:43–46`: optional defense against stale-arm packaging is
   to assert `compat['source_sha'] == HEAD`, `source_unchanged`, the exact 72
   comparison rows, each candidate_source and the two expected baseline SHAs.
   The inspected runner already constructs and verifies those values, so this
   is an extra final binding check, not an observed wrong-source result.
3. Check successful native-query exits before relying on the final export's
   remote refs/PR/latest-release facts. They are logged with exit codes, but
   unlike local head/status/protected queries, their successful parsing is not
   enforced by the exporter. No failed remote query was observed in this review;
   the exporter had not yet run.

No product or original evidence was edited by this reviewer. The original
export omission was sent to root immediately and repaired by root, then
independently reread here.
