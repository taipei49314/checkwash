# CheckWash UX 第二批：候選與證據

第二批新增 **11 個具名窄修**；連同第一批共 **19 個**。已推至同一份[草稿 PR #566](https://github.com/taipei49314/checkwash/pull/566)，固定候選 `9a5a27f44c895ba2fdee8c83a6313baf0e120873`。main 仍為 `1ffe283d7d947fecc426dea99323b0a2620a9482`，公開版本仍是 v0.9.0；metadata 維持 0.9.1。

完整套件：**{{FULL_SUITE}}**。候選 CLI 與實際公開 v0.9.0 Action 對同一 base/head 都通過 high 門檻，保留 4 個 warn，沒有加新豁免。這些是 `LAPTOP-01AGNPJU`／Windows／Python 3.11.9 的本地證據，標記 `HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`；不是正式 receipt-bridge 必過檢查或發布驗收。

## 第二批已完成

| 窄修 | 現在行為與邊界 |
|---|---|
| Doctor 政策來源 | 同名新舊政策檔並存時，說明逐檔 working-tree precedence 與 BASE 權威；遮蔽裁決未改。 |
| Quality explain 格式 | JSON／SARIF 成功輸出 advisory rule metadata；沒有 review verdict、假 invocation 或 findings。 |
| 外部 worktree 路徑拒絕 | 顯示安全 logical path、side、讀取入口及補救；不列出外部 resolved target、不讀外部 bytes。 |
| Quality profiles 格式 | 明確 term 顯示可讀 catalog；裸命令仍保留原 JSON 預設與 bytes。 |
| Quality init 指引 | 有效 TOML comments 說明 UTF-8 草稿保存；JSON 指向 policy_toml，缺件／錯參數不再只叫人重跑 init。 |
| TASK 語法診斷 | BOM、inline comments、quoted booleans、flow lists、縮排 header、literal glob comment 等有 stderr 提示；原 parser／Contract AST 未變。 |
| Sweep commit 診斷 | 非空時加 optional commit_diagnostics，列 full SHA、已知 parent、phase／kind、安全 reason；counter、fallback、denominator、exit 均不改。正常 summary bytes 保留。 |
| TASK lookup context | 失敗時補 requested／resolved／repo／cwd／mapped，再保留原拒絕；相對路徑解析基準未改。 |
| 非 regular worktree 拒絕 | 現有 read／batch refusal 補 side、入口、regular-source 補救；legacy Git／search helper 文案與准入未改。 |
| Ruff ignore incomplete | 指出具體 ignore input、side、profile 與未 qualification 理由；空／空白正常、comment-only 仍 incomplete，未擴大支援或放行。 |
| Doctor hook 維護 | 偵測 tracked Stop settings 時提示重裝可能修改 guardrail，應先看 diff、走既有 BASE／review；沒有 upgrade 豁免。 |

第一批 8 個窄修與原始 14 項問題的完整重現台帳保留在先前里程碑；本包含[原報告快照](first-milestone/report.md)、127 條原主張 register 與原分析。[第一批完整原包](first-milestone-complete.zip)包含原報告內連結所指的證據。原報告描述的是 `f86aabbb` 當時狀態，後續進展以下表為準。127 條是含反駁與限制的靜態分析，不能當成 127 個實測 PASS。

## 固定候選驗證

| 驗證 | 結果／實際界線 |
|---|---|
| 完整 source suite | {{FULL_SUITE}}；[原始 stdout](evidence/root/final-fullsuite-r2/stdout.txt)、[收據](evidence/root/final-fullsuite-r2/receipt.json)、[JUnit](evidence/root/final-fullsuite-r2/junit.xml)。 |
| Input 穩定性 | 最終 suite 前後 manifest 相同、HEAD 相同；[來源稽核](evidence/source-audit.json)揭露工作副本僅 docs/embedding.md 有混合換行，所有 src/tests/tools/action bytes 等於 Git blob，執行中未改檔。 |
| 公開 Action self-dogfood | [實際 v0.9.0 composite replay](evidence/final-action-r2/replay.json)，固定 Action `d6eda4f6`，base `1ffe283d`／head `9a5a27f4`，install／check exit0，comment_pr=false。另用乾淨 detached checkout，逐 blob 驗證。PJU local replay，不是 GitHub runner。 |
| 候選 CLI self-dogfood | 同 exact range：exit0／pass，high=0、critical=0、warn=4、config_errors=[]、skipped_files=[]；[原始 JSON](evidence/root/final-cli-selfdogfood/stdout.txt)。 |
| 原 rename 矩陣與候選 | {{COMPAT}}；fixture 只被靜態讀取，未執行。原 72 次舊來源觀察不覆寫。 |
| Collection | 20,858 cases；比第一批多 120，是收集分母，不是通過數。 |
| 開發回歸 | 保留各模組 before 紅／after 綠，不加總重疊數。Quality 三切片 union73；outside reader29 pass/10 skip；nonregular65 pass/10 skip；TASK/alias36 pass/5 skip，後續 syntax/path22 pass；sweep20 targeted＋24 synthetic CLI；Ruff16新＋236相關；doctor42 pass/1 skip。 |
| 相容性控制 | Ruff 以改前825e2dc為基線的12對 payload 除 message 外相同、fingerprints 保留，6對正常 JSON/term/SARIF bytes 相同。Sweep 以第一批f86aabbb為基線的6 synthetic cases 所有舊 fields/counters/exits 相同，2個正常 summary bytes 相同；其他4個只加 optional array。這些靶向比較不泛化成所有來源／輸入皆相同。 |
| 未執行／未建立 | 其他 OS／Python、跨平台 byte equality、完整283 source/wheel/pyz qualification、正式 required-check bridge、release collector／tag驗證、歷史 sweep／模型／標註批次均為 NOT_RUN。 |

4 個 self-dogfood warn 均保留：兩個 `EXPECTED_VALUE_CHANGED` 是兩條既有非 regular 拒絕文案的**完整 equality assertion** 隨輸出更新，依原引擎得到 REPAIR_EVIDENCE；兩個是 sweep 既有 `except Exception` 加綁定名稱後的 `BROAD_EXCEPT_ADDED`／`SUPPRESSION_ADDED`。沒有新增 catch 範圍，也沒有新增 exemption 或人工改綠。第一次 prefreeze 曾用較寬 substring assertions，已恢復 whole-message equality；原始中間收據保留。

既有 4 條純診斷 assertions 更新原因已逐條記錄，拒絕類型、准入、golden/corpus verdict labels 不變。既有 sweep summary 的新增欄位是 optional commit_diagnostics array，外部若使用 closed-key validator 需明確納入；不宣稱所有改前輸出均 byte-identical。

## 原 14 項問題的更新狀態

| 項目 | 本輪後狀態與 residual |
|---|---|
| #1 終端編碼 | 第一批受控自有 decoration 修補保留；原完整 shell 環境未重播。 |
| #2 main reader junction | strict refusal 現有路徑／side／入口診斷已修；外部目標仍拒絕，root／跨磁碟變體未測。 |
| #3 policy shadowing | doctor 可見性已修；新增優先政策放寬仍是已重現且未修的政策比較問題。 |
| #4 relative task | 失敗 context 已修；cwd-relative／SPEC repo-relative 落差未改，待獨立相容性決策。 |
| #5 hook 自我阻擋 | 已實際跑 legacy Stop 設定→doctor→hook install；install成功，之後 critical BLOCK。新增事前提醒；完整舊版升級／Claude lifecycle 未測，trust 豁免未改。 |
| #6 quality 輸出 | usage、成功 explain／profiles、init guidance 已修；PowerShell5.1 UTF-16 redirection 仍未測。 |
| #7 rename／oracle | 逃逸與正常控制保留；D2／D5／E2／identity／repair credit未改。精確 D2/E2 提案僅為未採用草稿。 |
| #8 rename CRLF／入口 | 已重現 pairing差異；原純搬移控制均 PASS，未重現誤擋，未改 pairing／fingerprint。 |
| #9 registered gitlink | 第一批 exact index stage0 mode160000 窄修保留；鄰接真 finding、checked-out context 保留。 |
| #10 quality trust／ledger | 第一批 wrong-ledger 拒絕保留；report→enforce critical／BLOCK、quality reported 非 clean 的差異保留；第二筆 allow 自我阻擋未另做原生重現。 |
| #11 unknown fingerprint | 第一批安全 advisory 保留；future namespace eligibility 仍不等於目前 finding 真正匹配。 |
| #12 quality CRLF／junction／Ruff | 第一批 CRLF／3.11 junction 修補保留；Ruff本輪補理由，未新增 qualification／ignore 模型或支援範圍。 |
| #13 TASK parser | subset文件與非變異診斷已完成；不擴充語言、不加dependency、不啟用原本忽略的scope/freeze。 |
| #14 sweep | paired pytest context與commit診斷已完成；歷史數據未重跑，exception仍計engine_errors且不入analysed分母。 |

## 未套用的受保護提案

[D2／E2 精確包](evidence/proposals/00-D2-E2-proposal.md)含 gating patch、SPEC patch、未編號 DECISIONS 草稿、72筆逐項預期 movement 與控制計畫。只在兩個 assertion-text D2 early return 前套 E2，**仍消費 credit 並保留 ASSERTION_MOVED**；whole-body／D10／D5／identity 不動。

獨立審查核對原始 pointer／raw hashes、36對舊版本觀察及6個 frozen hunks，修正了早期另一案「不消費 credit」與本案不等價的問題。舊案已標 SUPERSEDED，原件與雜湊保留於[審查證據](evidence/proposals-review/report.md)。沒有在產品套用、import 或執行修改後 judge，`modified_judge_executions=0`。

推論原72觀察中 A×freeze 的4格在原 high 門檻下可能從 info/PASS→high/BLOCK，其餘68預期不變；**這不是新結果或改善率**。合法 text-only refactor 的成本未量測、ASSERT_REMOVED 分支缺直接原 witness、JS/TS與其他 fail_on 門檻未測；default A/B及跨檔 whole-body decorator 逃逸仍在。需要另行 exact protected 決策與驗證，不能把提案當修補完成。

## 保留的失敗、來源與版本建議

本輪第一次 full-suite launcher 在 pytest 啟動前因相對 executable 路徑 WinError2 失敗；[原失敗紀錄](evidence/root/final-fullsuite/launcher-failure.json)保留，改用絕對路徑的r2才是完整執行。第一次[Action replay](evidence/final-action/replay.json)在任何 install/check 前拒絕 docs/embedding.md 的混合換行；r2使用同 SHA 的乾淨 checkout，沒有放寬驗證器。Sweep／hook driver 的 syntax、唯讀 fixture object、大小寫 schema 驗證錯誤也保留原始失敗，後續補件或只讀驗證另存，不覆寫。共享開發樹的 source_changed 收據不充當固定來源資格。

固定來源與查詢在[baseline](baseline.json)、完整提交訊息在[commit log](commit-log.stdout)，原始證據逐檔複製比對在[copy provenance](copy-provenance.json)，最終包的雜湊在[MANIFEST](MANIFEST.json)。第一批ZIP保全 SHA-256仍為 `e6466727b1eeea9d964bc137b201f57d6e2e23ade4325dd509f373f32c377096`，未覆寫。

仍建議把這19個窄修視為 **0.9.2 候選**，須完成適用的正式相容性／required checks再決定；受保護 rename／oracle 裁決另走 **0.10.0 類 minor 候選**。兩者都只是條件式版本建議，沒有 bump。**r65 發版暫停持續有效；沒有合併、tag、發布、改下游pin或恢復automation。**
