# Sanitized historical task evidence — backup only

SANITIZED_HISTORICAL_BACKUP_NOT_ACCEPTANCE_NOT_FULL_HISTORY_REPLAY

This archive is a new deterministic derivative, not the original sealed ZIP.
Original archives remain unchanged locally. Exact private global-context files
and nested original packages containing that context are intentionally omitted.
Exclusion records contain relative names, byte lengths and reasons only.

All retained original file bytes, including repository-owned instruction files,
are unchanged. The original MANIFEST.json is retained as a HISTORICAL inventory;
its references to intentionally omitted files do not validate this derivative.
Use SANITIZED-MANIFEST.json and SANITIZATION-EXCLUSIONS.json for this archive.

No product, fixture program, gate or modified judge was executed by sanitization.
Historical source/runtime, failures, partial results and proposal status remain
historical. New byte hashes do not reclassify them as accepted or passing.
This is not a self-contained replay of every historical run: runtimes, private
context and nested original packages remain local. Read the parent handoff's
START-HERE/status for current candidate state. Backup timing is not release
urgency; no merge, tag, publication, exemption or version1.0 permission is given.
