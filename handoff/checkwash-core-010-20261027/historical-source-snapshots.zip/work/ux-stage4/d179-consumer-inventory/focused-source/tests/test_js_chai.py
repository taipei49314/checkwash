"""chai assertion styles on the existing strength lattice (issue #180).

Forms, rungs and values below are written from chai's documented semantics,
not read from the frontend tables, so dropping a spelling fails here. The
independent mutation supplement is tests/data/javascript_chai_mutations.json;
it runs in-process here; wiring it into the CLI qualification is left
to the maintainer.
"""

import datetime
from decimal import Decimal
from pathlib import Path
import runpy

import pytest

from checkwash.config import Config
from checkwash.contract import Contract
from checkwash.engine import FileChange, analyze
from checkwash.frontends.javascript.coverage import javascript_coverage_gaps
from checkwash.frontends.javascript.frontend import parse_javascript

_CHAI = 'import { assert, expect } from "chai";'
_PATH = "test/billing.spec.js"


def _source(body, imports=_CHAI):
    return "\n".join([
        imports,
        'describe("billing", function () {',
        '  it("total", function () {',
        f"    {body}",
        "  });",
        "});",
        "",
    ])


def _assertions(source):
    return [assertion for unit in parse_javascript(source.encode()).units
            for assertion in unit.side.assertions]


def _gaps(source, path=_PATH):
    data = source.encode()
    return javascript_coverage_gaps(data, parse_javascript(data), path, "after")


def _outcome(before, after, path=_PATH):
    _ir, findings, verdict = analyze(
        [FileChange(path, "modified", before.encode(), after.encode())],
        Config(), Contract(), [], datetime.date(2026, 10, 1),
    )
    return verdict, [(finding.rule, finding.severity) for finding in findings]


@pytest.mark.parametrize("body,subject,form,strength,positive,value", [
    ("expect(total()).to.equal(78.75);", "total()", "compare_eq", 90, True, "78.75"),
    ("expect(total()).equals(78.75);", "total()", "compare_eq", 90, True, "78.75"),
    ("expect(total(), 'total').to.eq(78.75, 'message');", "total()", "compare_eq", 90, True, "78.75"),
    ("expect(total()).not.to.equal(80);", "total()", "compare_eq", 90, False, "80.0"),
    ("expect(lines()).to.deep.equal([1, 2]);", "lines()", "compare_eq", 100, True, None),
    ("expect(total()).to.eql(78.75);", "total()", "compare_eq", 100, True, "78.75"),
    ("expect(paid()).to.be.true;", "paid()", "compare_eq", 90, True, "True"),
    ("expect(paid()).to.be.false;", "paid()", "compare_eq", 90, True, "False"),
    ("expect(failure()).to.be.null;", "failure()", "compare_eq", 90, True, "None"),
    ("expect(failure()).to.be.undefined;", "failure()", "compare_eq", 90, True, None),
    # `positive` is what the assertion asserts of its predicate key (#198):
    # `.exist` asserts `!= null`, the negation of is_nullish.
    ("expect(failure()).to.exist;", "failure()", "non_null", 30, False, None),
    ("expect(failure()).to.not.exist;", "failure()", "non_null", 30, True, None),
    ("expect(paid()).to.be.ok;", "paid()", "truthy", 20, True, None),
    ("expect(paid()).to.be.ok();", "paid()", "truthy", 20, True, None),
    ("expect(total()).to.be.closeTo(78.75, 0.01);", "total()", "approx", 70, True, "78.75"),
    ("expect(total()).to.be.approximately(78.75, 0.01);", "total()", "approx", 70, True, "78.75"),
    ("expect(lines()).to.include(2);", "lines()", "membership", 60, True, None),
    ("expect(lines()).to.contain(2);", "lines()", "membership", 60, True, None),
    ("expect(name()).to.match(/total/);", "name()", "pattern", 60, True, None),
    # A bound word records its bound, as an ordering matcher does (#198 Q2, Q4).
    ("expect(total()).to.be.above(70);", "total()", "compare_ord", 40, True, "70.0"),
    ("expect(total()).to.be.at.least(70);", "total()", "compare_ord", 40, True, "70.0"),
    ("expect(total()).to.be.below(80);", "total()", "compare_ord", 40, True, "80.0"),
    ("expect(total()).to.be.at.most(80);", "total()", "compare_ord", 40, True, "80.0"),
    ("expect(total()).to.be.within(70, 80);", "total()", "compare_ord", 40, True, None),
    ("expect(lines()).to.have.lengthOf(2);", "lines()", "type_shape", 50, True, None),
    ("expect(total())\n      .to.equal(78.75);", "total()", "compare_eq", 90, True, "78.75"),
    ("assert(paid());", "paid()", "truthy", 20, True, None),
    ("assert.isOk(paid(), 'message');", "paid()", "truthy", 20, True, None),
    # `==` keeps its scalar; the eq_loose key carries the coercion (#196 190.2).
    ("assert.equal(total(), 78.75);", "total()", "compare_eq", 90, True, "78.75"),
    ("assert.strictEqual(total(), 78.75);", "total()", "compare_eq", 90, True, "78.75"),
    ("assert.deepEqual(total(), 78.75);", "total()", "compare_eq", 100, True, "78.75"),
    ("assert.isTrue(paid());", "paid()", "compare_eq", 90, True, "True"),
    ("assert.isNull(failure());", "failure()", "compare_eq", 90, True, "None"),
    ("assert.exists(failure());", "failure()", "non_null", 30, False, None),
    ("assert.isDefined(failure());", "failure()", "non_null", 30, False, None),
    ("assert.closeTo(total(), 78.75, 0.01);", "total()", "approx", 70, True, "78.75"),
    ("assert.include(lines(), 2);", "lines()", "membership", 60, True, None),
    ("assert.match(name(), /total/);", "name()", "pattern", 60, True, None),
    ("assert.isAtLeast(total(), 70);", "total()", "compare_ord", 40, True, "70.0"),
    ("assert.lengthOf(lines(), 2);", "lines()", "type_shape", 50, True, None),
])
def test_chai_spellings_reach_the_existing_lattice(body, subject, form, strength, positive, value):
    source = _source(body)
    assertion, = _assertions(source)
    assert (assertion.left, assertion.form, assertion.strength, assertion.positive,
            assertion.right_value) == (subject, form, strength, positive, value)
    assert assertion.text == body.rstrip(";")
    assert _gaps(source) == []


def test_property_terminal_text_ends_at_its_word():
    # Semicolon-free style: a trailing comment and the next line's comment
    # belong to no assertion, so editing them cannot change this one's text.
    source = _source("expect(paid()).to.be.true // settled\n"
                     "    // totals next\n"
                     "    expect(total()).to.equal(78.75)")
    first, second = _assertions(source)
    assert first.text == "expect(paid()).to.be.true"
    assert second.text == "expect(total()).to.equal(78.75)"


def test_editing_the_comment_after_a_kept_property_does_not_excuse_a_removal():
    # The kept assertion is not newly written, so SAME_UNIT_REWRITE must not
    # hold the other assertion's removal at warn.
    before = _source("expect(paid()).to.be.true\n"
                     "    // settled first\n"
                     "    expect(total()).to.equal(78.75)")
    after = _source("expect(paid()).to.be.true\n"
                    "    // settled first, the total is checked elsewhere")
    assert _outcome(before, after) == ("block", [("ASSERT_REMOVED", "high")])


def test_repeated_not_keeps_chai_negation():
    # chai's `not` sets the negate flag; a second `not` does not clear it.
    assertion, = _assertions(_source("expect(total()).not.to.not.equal(80);"))
    assert assertion.positive is False


@pytest.mark.parametrize("body,epsilon", [
    # Read exactly from its digits, as a hand-rolled bound is (#196 190.4).
    ("expect(total()).to.be.closeTo(78.75, 0.01);", "abs=0.01"),
    ("expect(total()).to.be.approximately(78.75, 1e-2, 'message');", "abs=0.01"),
    ("assert.closeTo(total(), 78.75, 0.010);", "abs=0.010"),
    ("expect(total()).to.be.closeTo(78.75, 5e-7);", "abs=5E-7"),
])
def test_close_to_records_its_absolute_delta(body, epsilon):
    assertion, = _assertions(_source(body))
    assert (assertion.epsilon, assertion.epsilon_kind) == (epsilon, "abs")


@pytest.mark.parametrize("body,bound", [
    ("expect(total()).to.be.closeTo(78.75, Infinity);", Decimal("Infinity")),
    ("expect(total()).to.be.closeTo(78.75, Number.POSITIVE_INFINITY);", Decimal("Infinity")),
    ("expect(total()).to.be.closeTo(78.75, Number.MAX_VALUE);", Decimal(2 ** 1024 - 2 ** 971)),
    # 2**-50 is 5**50 * 10**-50, built from its digits so no context rounds it.
    ("expect(total()).to.be.closeTo(78.75, 4 * Number.EPSILON);",
     Decimal((0, tuple(int(digit) for digit in str(5 ** 50)), -50))),
    ("const BIG = 1e300;\n    expect(total()).to.be.closeTo(78.75, BIG);", Decimal("1e300")),
    ("expect(total()).to.be.closeTo(78.75, (0.5 as number));", Decimal("0.5")),
    # A shadowed global is the local it names.
    ("const Infinity = 1;\n    expect(total()).to.be.closeTo(78.75, Infinity);", Decimal(1)),
])
def test_close_to_reads_named_and_local_deltas(body, bound):
    # #198 M2f-M2h: a delta of Infinity, Number.MAX_VALUE or a local name
    # used to record nothing, and the widening passed. The values are exact.
    *_, assertion = _assertions(_source(body))
    assert assertion.epsilon_kind == "abs"
    assert Decimal(assertion.epsilon[len("abs="):]) == bound


@pytest.mark.parametrize("body", [
    "expect(total()).not.to.be.closeTo(78.75, 0.01);",
    "expect(total()).to.be.closeTo(78.75, tolerance);",
    "expect(total()).to.be.closeTo(78.75, delta());",
    "const BASE = 0.01;\n    const EPS = BASE;\n    expect(total()).to.be.closeTo(78.75, EPS);",
])
def test_unknown_or_negated_delta_claims_no_ordering(body):
    *_, assertion = _assertions(_source(body))
    assert assertion.form == "approx"
    assert assertion.epsilon is None


_CHAI_AND_NODE = 'import assert from "node:assert";\nimport { expect } from "chai";'
_HAND_ROLLED = "Math.abs(total() - 78.75)"


def _tolerance_findings(before, after, imports):
    _verdict, findings = _outcome(_source(before, imports), _source(after, imports))
    return [finding for finding in findings if finding[0] == "TOLERANCE_LOOSENED"]


@pytest.mark.parametrize("before,after", [
    # A delta of 1 is a wider bound than `< 0.5`, not one decimal place: read
    # as places it reported a loosening for a tightened tolerance.
    ("expect(total()).to.be.closeTo(78.75, 1);", f"assert.ok({_HAND_ROLLED} < 0.5);"),
    (f"assert.ok({_HAND_ROLLED} < 0.5);", "expect(total()).to.be.closeTo(78.75, 0.5);"),
    (f"assert.ok({_HAND_ROLLED} < 0.5);", "expect(total()).to.be.closeTo(78.75, 0.25);"),
])
def test_close_to_and_a_hand_rolled_bound_are_one_absolute_bound(before, after):
    assert _tolerance_findings(before, after, _CHAI_AND_NODE) == []


def test_widening_a_hand_rolled_bound_into_close_to_is_reported():
    # Read as places, a fractional delta was unknown and the widening passed.
    found = _tolerance_findings(f"assert.ok({_HAND_ROLLED} < 0.005);",
                                "expect(total()).to.be.closeTo(78.75, 0.5);", _CHAI_AND_NODE)
    assert [rule for rule, _severity in found] == ["TOLERANCE_LOOSENED"]


@pytest.mark.parametrize("before,after,loosened", [
    # Vitest's expect carries both styles; a precision and a delta compare
    # through the absolute bound each states (toBeCloseTo(v, 2) is 0.005).
    ("expect(total()).toBeCloseTo(78.75, 2);", "expect(total()).to.be.closeTo(78.75, 1);", True),
    ("expect(total()).to.be.closeTo(78.75, 1);", "expect(total()).toBeCloseTo(78.75, 0);", False),
    ("expect(total()).to.be.closeTo(78.75, 0.005);", "expect(total()).toBeCloseTo(78.75, 2);", False),
])
def test_vitest_precision_and_delta_compare_as_absolute_bounds(before, after, loosened):
    found = _tolerance_findings(before, after, 'import { expect } from "vitest";')
    assert bool(found) is loosened


@pytest.mark.parametrize("imports,receiver", [
    ('import { expect } from "chai";', "expect"),
    ('import { expect as check } from "chai";', "check"),
    ('import * as chai from "chai";', "chai.expect"),
    ('import chai from "chai";', "chai.expect"),
    ('const { expect } = require("chai");', "expect"),
    ('const expect = require("chai").expect;', "expect"),
    ('const chai = require("chai");\nconst { expect } = chai;', "expect"),
    ('import { expect } from "vitest";', "expect"),
    ("", "expect"),
])
def test_chai_expect_bindings_report_the_issue_weakening(imports, receiver):
    before = _source(f"{receiver}(total()).to.equal(78.75);", imports)
    after = _source(f"{receiver}(total()).to.exist;", imports)
    assert _outcome(before, after) == ("block", [("ASSERT_WEAKENED", "high")])


@pytest.mark.parametrize("imports,receiver", [
    ('import { assert } from "chai";', "assert"),
    ('import { assert as check } from "chai";', "check"),
    ('import * as chai from "chai";', "chai.assert"),
    ('const { assert } = require("chai");', "assert"),
    ('const assert = require("chai").assert;', "assert"),
    ('import { assert } from "vitest";', "assert"),
])
def test_chai_assert_bindings_report_a_truthiness_weakening(imports, receiver):
    before = _source(f"{receiver}.strictEqual(total(), 78.75);", imports)
    after = _source(f"{receiver}.isOk(total());", imports)
    assert _outcome(before, after) == ("block", [("ASSERT_WEAKENED", "high")])


@pytest.mark.parametrize("imports,body", [
    ('import { expect } from "./support/expect.js";', "expect(total()).to.equal(78.75);"),
    ('import { assert } from "./support/assert.js";', "assert.strictEqual(total(), 78.75);"),
    (_CHAI, "const expect = standin; expect(total()).to.equal(78.75);"),
    (_CHAI, "const assert = standin; assert.strictEqual(total(), 78.75);"),
])
def test_lookalikes_and_shadows_do_not_acquire_chai_strength(imports, body):
    source = _source(body, imports)
    assert _assertions(source) == []
    gap, = _gaps(source)
    assert "unresolved" in gap.reason


@pytest.mark.parametrize("body,callee", [
    ("expect(total()).to.equal(78.75).and.not.equal(80);", "expect(...).to.equal"),
    ("expect(total()).to.eventually.equal(78.75);", "expect(...).to.eventually.equal"),
    ("expect(lines()).to.be.an('array');", "expect(...).to.be.an"),
    ("expect(lines()).to.have.length.above(1);", "expect(...).to.have.length.above"),
    # `.own.property` is represented since #215 (pin flip authorized there).
    ("expect(order()).to.have.keys('total');", "expect(...).to.have.keys"),
    ("expect(total()).to.be.closeTo(78.75);", "expect(...).to.be.closeTo"),
    ("assert.isFunction(total);", "assert.isFunction"),
    ("assert.notStrictEqual(total(), 80);", "assert.notStrictEqual"),
])
def test_unsupported_chai_spellings_remain_coverage_gaps(body, callee):
    source = _source(body)
    # Recorded with no strength, so deleting it is ASSERT_REMOVED; its
    # predicate is still not read (#196 190.5).
    assert [(a.form, a.strength) for a in _assertions(source)] == [("unknown", None)]
    gap, = _gaps(source)
    assert gap.callee == callee
    assert "not represented" in gap.reason


def test_chai_expect_has_no_jest_matchers():
    source = _source("expect(total()).toBe(78.75);")
    assert _assertions(source) == []
    gap, = _gaps(source)
    assert gap.callee == "expect(...).toBe"


def test_unimported_assert_keeps_the_node_default():
    source = _source("assert.isTrue(paid());", imports="")
    assert _assertions(source) == []
    gap, = _gaps(source)
    assert gap.callee == "assert.isTrue"
    assert gap.reason.startswith("Node ")


@pytest.mark.parametrize("body,callees", [
    ("vitest.assert.notStrictEqual(total(), 80);", ["vitest.assert.notStrictEqual"]),
    ("vitest.assert.strictEqual(total(), 78.75);", []),
    ("vitest.vi.fn();", []),
])
def test_vitest_namespace_assert_member_is_a_chai_candidate(body, callees):
    # A Vitest namespace exposes chai's assert; its other members are not
    # assertion candidates. A represented call leaves no gap.
    gaps = _gaps(_source(body, 'import * as vitest from "vitest";'))
    assert [(gap.callee, gap.reason.split()[0]) for gap in gaps] == [(callee, "chai") for callee in callees]


def test_should_style_reads_as_an_expect_chain():
    # Should-style was outside the scan until #215, which reads it as the
    # expect() chain it is (pin flip authorized there).
    source = _source("total().should.equal(78.75);", 'import { should } from "chai";\nshould();')
    assert [(a.left, a.form, a.strength, a.right_value) for a in _assertions(source)] == [
        ("total()", "compare_eq", 90, "78.75")]
    assert _gaps(source) == []


_ISSUE_180 = '''// billing.test.js: mocha + chai, "type": "module"
import { expect } from "chai";
import { invoiceTotal } from "./src/billing.js";

describe("billing", function () {
  it("computes invoice total", function () {
    const items = [{ price: 10.0, qty: 3 }, { price: 5.0, qty: 9 }];
    expect(invoiceTotal(items)).to.equal(78.75);
  });
});
'''


def test_issue_180_reproduction_blocks_and_leaves_no_coverage_gap():
    after = _ISSUE_180.replace(".to.equal(78.75);", ".to.exist;")
    assert _outcome(_ISSUE_180, after, "billing.test.js") == ("block", [("ASSERT_WEAKENED", "high")])
    assert _gaps(_ISSUE_180, "billing.test.js") == []
    assert _gaps(after, "billing.test.js") == []


_CONTRACT_TOOLS = runpy.run_path(str(Path(__file__).resolve().parents[1] / "tools/assertion_contract.py"))
_INVENTORY = _CONTRACT_TOOLS["foundation_mutation_cases"](_CONTRACT_TOOLS["CHAI_CONTRACT"])


@pytest.mark.parametrize("case", _INVENTORY, ids=lambda case: case["id"])
def test_independent_chai_mutations(case):
    _CONTRACT_TOOLS["check_mutation_case"](case)


def test_chai_inventory_covers_every_outcome_kind():
    assert {case["kind"] for case in _INVENTORY} == {
        "weakening", "removal", "expected_rewrite", "tolerance_weakened", "preserving", "strengthening",
    }
