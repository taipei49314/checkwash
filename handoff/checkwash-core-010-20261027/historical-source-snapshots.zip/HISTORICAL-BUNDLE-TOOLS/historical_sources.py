"""Preserve explicitly named historical task source snapshots, never execute them.

Default is a read-only plan (written under this controller directory). --pack
writes a fresh outputs ZIP only; it does not modify source, prior evidence,
legacy packages, root handoff files, or any remote.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import stat
import zipfile

HERE = Path(__file__).resolve().parent
STAGE = HERE.parent
SESSION = STAGE.parents[1]
OUTPUT = SESSION / "outputs/checkwash-core-010-handoff-20261027"
PIN = "8a8941dc2d7c581715a0f6f196c00da6c55f084b"
GUARD_SHA = "548566e890a5bd057d6f9ae1970824889c69e07d658b5265a32668b5cd8e598a"
STATUS = "HISTORICAL_SOURCE_BYTES_ONLY_NOT_ACCEPTANCE_NOT_ALL_RUNS_REPLAYABLE"
ROOTS = [
    "d179-consumer-inventory/focused-source",
    "oracle/cost-r1/working-tree-source", "oracle/cost-r2/working-tree-source",
    "oracle/cost-r3/working-tree-source", "oracle/cost-r4/working-tree-source",
    "oracle/native-r1/source", "policy/native/source",
    "native-final-control/source-candidate", "pyz-source-stage",
    *["task/" + phase + "/snapshot" for phase in (
        "before", "before-corrected", "after", "after-corrected", "after-corrected-r2",
        "after-path-focused", "encoding-before", "encoding-after")],
]
SKIP_COMPONENTS = {".git", "__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache",
                   "site-packages", "tmp", "temp", "pytest-temp", "repos", "fixtures"}


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=True) + "\n").encode()


def load(path):
    return json.loads(path.read_bytes())


def privacy_guard():
    path = HERE / "pack_checkpoint.py"
    raw = path.read_bytes()
    if digest(raw) != GUARD_SHA:
        raise ValueError("reviewed metadata/privacy helper changed; new readback required")
    spec = importlib.util.spec_from_file_location("reviewed_metadata_privacy_guard", path)
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)  # Own reviewed stdlib-only tool; main is not called.
    seal = load(STAGE / "seal/source-seal.json")
    if seal["source_sha"] != PIN or not seal["all_tracked_bytes_match_git"]:
        raise ValueError("unexpected fixed source seal")
    current = {row["path"]: row["sha256"] for row in seal["files"]}
    denied, synthetic = helper.guards(current)  # No Git or product call.
    return helper, current, denied, synthetic


def snapshot_files(root, helper):
    rows, refused = [], []
    for path in sorted(root.rglob("*")):
        relative = path.relative_to(root)
        if any(part in SKIP_COMPONENTS for part in relative.parts) or path.suffix in {".pyc", ".pyo"}:
            continue
        info = path.lstat()
        if stat.S_ISDIR(info.st_mode):
            continue
        try:
            raw, stable = helper.read(path)
        except (OSError, ValueError):
            refused.append({"path": path.relative_to(SESSION).as_posix(), "bytes": info.st_size,
                            "reason": "LOCAL_ONLY_NONREGULAR_REPARSE_OR_UNREADABLE"})
            continue
        if not stable:
            raise ValueError("historical snapshot changed during read")
        rows.append({"path": path.relative_to(SESSION).as_posix(),
                     "snapshot_path": relative.as_posix(), "bytes": len(raw), "sha256": digest(raw)})
    return rows, refused


def associated_refs(relative):
    root = STAGE / relative
    parent = root.parent
    paths = []
    names = ("receipt.json", "results.json", "started.json", "attempt-status.json",
             "source-before.json", "source-after.json", "working-tree-source.json",
             "source-head.stdout", "source-status.stdout", "source-working-diff.patch")
    paths.extend(parent / name for name in names if (parent / name).is_file())
    if relative.startswith("task/"):
        paths.extend(STAGE / "task" / name for name in ("report.md", "manifest.json", "capture_tests.py"))
    elif relative.startswith("oracle/"):
        paths.extend(STAGE / "oracle" / name for name in ("report.md", "capture_costs.py", "cost_arm.py", "native_controls.py"))
        if not (parent / "results.json").exists() and (parent / "raw").is_dir():
            paths.extend(path for path in (parent / "raw").iterdir() if path.is_file())
    else:
        paths.extend(parent / name for name in ("focused-receipt.json", "report.md", "manifest.json", "run-focused.py"))
    return sorted({path for path in paths if path.is_file()})


def build_plan():
    helper, current, denied, synthetic = privacy_guard()
    selected = {}
    local_only = []
    snapshots = []
    oldrefs = {}
    identical_maps = {}
    for relative in sorted(ROOTS):
        root = STAGE / relative
        if not root.is_dir():
            raise ValueError("named historical source root is missing: " + relative)
        rows, refused = snapshot_files(root, helper)
        local_only.extend(refused)
        full_map = {row["snapshot_path"]: row["sha256"] for row in rows}
        map_sha = digest(encoded(full_map))
        same_8a = bool(full_map) and not refused and all(current.get(path) == value for path, value in full_map.items())
        archive_path = root.parent / (root.name + ".zip")
        existing_archive = None
        if archive_path.is_file():
            raw_archive, stable = helper.read(archive_path)
            if not stable:
                raise ValueError("sibling source archive changed")
            with zipfile.ZipFile(io.BytesIO(raw_archive)) as archive:
                archive_map = {info.filename: digest(archive.read(info)) for info in archive.infolist() if not info.is_dir()}
            if archive_map == full_map and not refused:
                existing_archive = {"path": archive_path.relative_to(SESSION).as_posix(), "sha256": digest(raw_archive)}
        refs = associated_refs(relative)
        ref_details = []
        for path in refs:
            raw, stable = helper.read(path)
            if not stable:
                raise ValueError("historical reference changed")
            name = path.relative_to(SESSION).as_posix()
            record = {"path": name, "bytes": len(raw), "sha256": digest(raw)}
            if path.suffix == ".json":
                data = json.loads(raw)
                if isinstance(data, dict):
                    checks = []
                    for field in ("source_files", "candidate_source_files", "before", "after", "test_inputs"):
                        mapping = data.get(field)
                        if isinstance(mapping, dict) and mapping and all(isinstance(v, str) and len(v) == 64 for v in mapping.values()):
                            matching = all(full_map.get(key) == value for key, value in mapping.items())
                            checks.append({"field": field, "entries": len(mapping), "matches_snapshot_subset": matching})
                    if checks:
                        record["stored_hash_map_checks"] = checks
                    for field in ("exit", "exit_code", "frozen_source_unchanged", "candidate_source_unchanged", "source_unchanged"):
                        if field in data:
                            record["recorded_" + field] = data[field]
            ref_details.append(record)
        entry = {"root": root.relative_to(SESSION).as_posix(), "files": len(rows), "bytes": sum(row["bytes"] for row in rows),
                 "full_snapshot_map_sha256": map_sha, "source_root_matches_8a_members": same_8a,
                 "exact_existing_source_archive": existing_archive, "oldrefs": ref_details}
        if same_8a or existing_archive:
            entry["classification"] = "NOT_DUPLICATED_REBUILDABLE_FROM_FIXED_8A_OR_ALREADY_PRESERVED_ARCHIVE"
            snapshots.append(entry)
            continue
        entry["classification"] = "PRESERVED_NONCURRENT_TASK_SNAPSHOT_NOT_A_QUALIFIED_HEAD"
        entry["same_full_map_as_earlier_root"] = identical_maps.get(map_sha)
        identical_maps.setdefault(map_sha, entry["root"])
        kept = 0
        for row in rows:
            path = SESSION / row["path"]
            raw, stable = helper.read(path)
            if not stable or digest(raw) != row["sha256"]:
                raise ValueError("snapshot changed during privacy check")
            reason = helper.inspect(raw, row["path"], denied, synthetic)
            if reason:
                local_only.append({"path": row["path"], "bytes": row["bytes"], "reason": "LOCAL_ONLY_" + reason})
                continue
            selected[row["path"]] = {key: row[key] for key in ("path", "bytes", "sha256")}
            kept += 1
        entry["preserved_files"] = kept
        entry["full_snapshot_preserved"] = kept == len(rows) and not refused
        if relative == "oracle/cost-r1/working-tree-source":
            entry["attempt_boundary"] = "NO_RESULTS_RECEIPT; preserve abandoned source, not a completed run"
        elif relative == "task/after-corrected/snapshot":
            entry["attempt_boundary"] = "ABORTED_DURING_SNAPSHOT_GUARD; no tests began for this attempt"
        for path, ref in zip(refs, ref_details):
            raw, stable = helper.read(path)
            reason = helper.inspect(raw, ref["path"], denied, synthetic)
            if not stable or digest(raw) != ref["sha256"]:
                raise ValueError("old reference changed during privacy check")
            if reason:
                local_only.append({"path": ref["path"], "bytes": ref["bytes"], "reason": "LOCAL_ONLY_" + reason})
                continue
            selected[ref["path"]] = {key: ref[key] for key in ("path", "bytes", "sha256")}
            oldrefs[ref["path"]] = ref
        snapshots.append(entry)
    plan = {"status": STATUS, "purpose": "Preserve original source byte snapshots omitted from the minimal current-source continuation bundle",
            "fixed_current_source_sha_for_comparison_only": PIN, "snapshots": snapshots,
            "snapshot_scope_excludes": sorted(SKIP_COMPONENTS) + ["*.pyc", "*.pyo"],
            "files": [selected[name] for name in sorted(selected)], "old_references": [oldrefs[name] for name in sorted(oldrefs)],
            "local_only": sorted({row["path"]: row for row in local_only}.values(), key=lambda row: row["path"]),
            "privacy_helper_sha256": GUARD_SHA, "source_or_fixture_execution": "NOT_RUN",
            "historical_execution_status_preserved": True, "publication_performed": False}
    return plan, helper, denied, synthetic


def zip_write(archive, name, raw):
    info = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0))
    info.create_system = 3
    info.external_attr = (stat.S_IFREG | 0o644) << 16
    info.compress_type = zipfile.ZIP_DEFLATED
    archive.writestr(info, raw, compresslevel=9)


def extras(plan):
    manifest = {key: value for key, value in plan.items() if key not in {"old_references", "local_only"}}
    classification = {"status": STATUS, "local_only": plan["local_only"], "snapshots": plan["snapshots"],
                      "old_current_8a_and_archive_copies_not_duplicated": True, "full_historical_replay_self_contained": False}
    readme = ("# Historical task source byte snapshots — backup, not execution\n\n" + STATUS + "\n\n"
        + "Original files retain task-relative work/ux-stage4/... paths. They are data\n"
        + "for audit and are not imported or executed by this backup. Some snapshots\n"
        + "belong to failed, partial, superseded or never-started attempts. Their\n"
        + "presence never makes those attempts PASS or accepted. Old receipts and\n"
        + "reference maps retain original bytes and status; map comparisons are\n"
        + "recorded separately, not silently repaired.\n\n"
        + "Current8a-equivalent src trees and copies exactly covered by a retained\n"
        + "source ZIP are classified rather than duplicated. Runtime, cache, Git,\n"
        + "fixture-temp and unrelated project/global-context trees are absent. Any\n"
        + "unresolved private-marker file remains LOCAL_ONLY without exporting its\n"
        + "content. Check the classification for omissions. Not every historical\n"
        + "test/OS/dependency environment can be replayed from this archive alone.\n\n"
        + "The reviewed privacy helper is work/ux-stage4/checkpoint-pack/pack_checkpoint.py\n"
        + "from the main continuation bundle; its pinned hash is in this manifest.\n"
        + "The creator script is included for audit. It runs no product code.\n\n"
        + "The07:30 handoff deadline is a backup deadline, not product-release urgency.\n"
        + "Source8a stays frozen; #567 eight golden expectations and the two ordinary\n"
        + "self-dogfood high findings remain open. No labels, exemption or acceptance\n"
        + "state is changed, and Nelson's decision is required before version1.0.\n").encode()
    added = {"HISTORICAL-SOURCES-MANIFEST.json": encoded(manifest),
            "HISTORICAL-SOURCES-CLASSIFICATION.json": encoded(classification),
            "HISTORICAL-SOURCES-OLDREFS.json": encoded({"status": STATUS, "references": plan["old_references"]}),
            "HISTORICAL-SOURCES-README.md": readme,
            "HISTORICAL-BUNDLE-TOOLS/historical_sources.py": Path(__file__).read_bytes()}
    for name in ("historical_sources.initial.py.txt", "historical-source-guard-readback.json"):
        path = HERE / name
        if path.is_file():
            added["HISTORICAL-BUNDLE-TOOLS/" + name] = path.read_bytes()
    return added


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pack", action="store_true")
    args = parser.parse_args()
    plan, helper, denied, synthetic = build_plan()
    (HERE / "historical-source-plan.json").write_bytes(encoded(plan))
    chosen = [row for row in plan["snapshots"] if row["classification"].startswith("PRESERVED_")]
    brief = {"mode": "PLAN_ONLY", "source_roots": len(chosen), "snapshot_files": sum(row["preserved_files"] for row in chosen),
             "selected_files_with_oldrefs": len(plan["files"]), "uncompressed_bytes": sum(row["bytes"] for row in plan["files"]),
             "oldref_files": len(plan["old_references"]), "local_only": plan["local_only"]}
    if not args.pack:
        print(json.dumps(brief, indent=2))
        return 0
    OUTPUT.mkdir(parents=True, exist_ok=True)
    target = OUTPUT / "historical-source-snapshots.zip"
    sidecar = OUTPUT / (target.name + ".sha256")
    if target.exists() or sidecar.exists():
        raise ValueError("fresh output required; no existing artifact is overwritten")
    added = extras(plan)
    for name, raw in added.items():
        if helper.inspect(raw, name, denied, synthetic):
            raise ValueError("generated historical metadata needs privacy review")
    with target.open("xb") as output:
        with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            records = {row["path"]: row for row in plan["files"]}
            for name in sorted(set(records) | set(added)):
                raw = added.get(name)
                if raw is None:
                    raw, stable = helper.read(SESSION / name)
                    row = records[name]
                    if not stable or len(raw) != row["bytes"] or digest(raw) != row["sha256"]:
                        raise ValueError("historical source input changed while writing")
                zip_write(archive, name, raw)
    later, _helper, _denied, _synthetic = build_plan()
    if later != plan:
        raise ValueError("historical snapshot/reference classification changed during packaging")
    with zipfile.ZipFile(target) as archive:
        if archive.testzip() is not None:
            raise ValueError("historical source ZIP CRC failed")
        expected_names = sorted({row["path"] for row in plan["files"]} | set(added))
        if archive.namelist() != expected_names:
            raise ValueError("historical source ZIP membership differs")
        for row in plan["files"]:
            if digest(archive.read(row["path"])) != row["sha256"]:
                raise ValueError("historical original-file hash readback failed")
    final_hash = digest(target.read_bytes())
    with sidecar.open("x", encoding="ascii", newline="\n") as output:
        output.write(final_hash + "  " + target.name + "\n")
    result = {**brief, "mode": "HISTORICAL_BYTES_BACKED_UP_NOT_EXECUTED_NOT_PUBLISHED", "archive": target.name,
              "bytes": target.stat().st_size, "sha256": final_hash, "crc": "PASS", "original_file_hashes": "MATCH",
              "inputs_unchanged": True, "source_or_fixture_calls": 0, "acceptance_reclassified": False}
    (HERE / "historical-source-result.json").write_bytes(encoded(result))
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
