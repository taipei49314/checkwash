# Historical task source byte snapshots — backup, not execution

HISTORICAL_SOURCE_BYTES_ONLY_NOT_ACCEPTANCE_NOT_ALL_RUNS_REPLAYABLE

Original files retain task-relative work/ux-stage4/... paths. They are data
for audit and are not imported or executed by this backup. Some snapshots
belong to failed, partial, superseded or never-started attempts. Their
presence never makes those attempts PASS or accepted. Old receipts and
reference maps retain original bytes and status; map comparisons are
recorded separately, not silently repaired.

Current8a-equivalent src trees and copies exactly covered by a retained
source ZIP are classified rather than duplicated. Runtime, cache, Git,
fixture-temp and unrelated project/global-context trees are absent. Any
unresolved private-marker file remains LOCAL_ONLY without exporting its
content. Check the classification for omissions. Not every historical
test/OS/dependency environment can be replayed from this archive alone.

The reviewed privacy helper is work/ux-stage4/checkpoint-pack/pack_checkpoint.py
from the main continuation bundle; its pinned hash is in this manifest.
The creator script is included for audit. It runs no product code.

The07:30 handoff deadline is a backup deadline, not product-release urgency.
Source8a stays frozen; #567 eight golden expectations and the two ordinary
self-dogfood high findings remain open. No labels, exemption or acceptance
state is changed, and Nelson's decision is required before version1.0.
