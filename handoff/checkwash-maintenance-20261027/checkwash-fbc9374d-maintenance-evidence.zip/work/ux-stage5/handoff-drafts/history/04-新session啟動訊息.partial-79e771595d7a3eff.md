# 新 session 啟動訊息（草稿；root 發出前更新資格終態）

請接手同一個 CheckWash 工作，延續既有具體授權、未解決問題與驗收界線。先讀新工作站實際的全域 AGENTS.md，再讀 checkout 的 STATE.md、AGENTS.md、相關目錄指示與最新交接入口。不要只依舊引文恢復 PJU 禁令，也不要把備份完成當產品完成。

## 固定來源與入口

- Product repo：taipei49314/checkwash；草稿 PR #566；工作分支 fix/ux-repairs-20261026。
- **目前固定 product source：fbc9374dc3bcbfc47f403aec0c36e6b51dd7b86c**，package **0.10.0 / IR3 / findings2**。不要把 handoff metadata commit 當成 product source。
- 比較 BASE／trusted collector 所需 Git object：1ffe283d7d947fecc426dea99323b0a2620a9482。
- 新交接 prefix：handoff/checkwash-maintenance-20261027/，仍在歷史命名分支 handoff/core-010-pju-20261027-8a8941dc。分支名裡的8a不代表新 product source。
- 本稿讀到的新 partial checkpoint 是 **bde3e20c6ed653280170b43cc5b1e36e7a3aa03e**，publisher receipt 的 remote ref 已核對；它是 PARTIAL_CHECKPOINT / NONPASS / bundle NOT_READY，不是完整包或資格 PASS。
- 該 partial 入口：[00-START-HERE.md](https://github.com/taipei49314/checkwash/blob/bde3e20c6ed653280170b43cc5b1e36e7a3aa03e/handoff/checkwash-maintenance-20261027/00-START-HERE.md)。Root 發出本訊息前，須把這個 permalink 與以下資格表更新成最後實際核包／遠端 readback 的 checkpoint，不能只靠 mutable branch tip。
- 本機新 payload：outputs/checkwash-maintenance-followup-20261027/。先讀 00-START-HERE.md、checkpoint.json、MANIFEST.json；完整新包預定名 checkwash-fbc9374d-maintenance-evidence.zip，是否已完成及其 raw SHA/bytes 必須取實際 checkpoint，不能由檔名猜。
- **舊8a完整備份**：d158ec02aac9c0c19751d0475f935b533e3d03f7，[歷史入口](https://github.com/taipei49314/checkwash/blob/d158ec02aac9c0c19751d0475f935b533e3d03f7/handoff/checkwash-core-010-20261027/00-START-HERE.md)。其 source8a、五個 ZIP 與22 failures 都是歷史基線；不可借用成 fbc 的測試結果，也不要改寫舊包。

Handoff commit 繼承舊 checkpoint tree，僅追加新 prefix／舊入口 banner。直接 checkout handoff branch 不會把其 product-root tree 自動升為 fbc；產品 checkout 必須另外定位到完整 fbc SHA。

## 已知正式結果：不是全綠

**fbc full suite 已終態 exit1：15 failed / 21,064 passed / 25 skipped / 67 subtests passed。** 完整 collection denominator 為21,104 parents；不能把 collected 寫成 passed。Full suite 在2026-10-26T21:40:30Z結束；獨立 readback exit0只證明原 XML／stdout／hash一致，沒有把失敗轉成 PASS。

15個 failed parents 分為：

- 8個未核可的舊 golden 成本（#567）：原 fixture expected bytes 仍保留。既有 expected-only patch 是 inert、未採納、未執行改標後的 gate；不能用 static prediction 宣稱改後 PASS。
- 3個普通 positive compatibility controls：JS skipped-block relocation、issue263 string-condition class relocation、issue358 own-mark relocation。保留原正控，不以放寬 expected 代替安全 proof 或具體人類裁決。
- 4個 protected gate/adapter failures（#568），涉及四個 corpus identities：refactor CASE_020_windows、CASE_029_flatten；tamper d007-factorial-of-zero、d010-stack-is-lifo。兩個 refactor 是新保守成本，兩個 tamper 是新增攔截但原 escape record 仍不符。首個 adapter mismatch 的 wrapper/score 同為 BLOCK；後續 NOT_REACHED、full finding/severity NOT_CAPTURED 的界線仍保留，不能聲稱完整 parity 或整個 corpus 已接受。

**fbc 普通 self-dogfood 仍 BLOCK / exit1：0 critical / 3 high / 9 warn。** 它與 golden／corpus decisions 分開，沒有 allowlist、exemption 或改標替它清除。原生 JSON、fingerprints、source comparison 與 raw export map 保留於 stage5/selfdogfood-review 及 payload 的 completed/selfdogfood/。

這一輪普通 maintenance 已整合並固定 fbc；SRC、版本、goldens、gates、benchmarks 未因 maintenance 放寬。不要再拿舊8a的metadata/consumer失敗說成新source仍同樣未修；也不要因 maintenance targeted 通過而把上面15個全套失敗抹掉。

## 三條 assertion qualifications：由 root 最後刷新

下表是本稿所讀 **partial checkpoint 的原始狀態**，不是新 process-live 監控。Root 發出前須由最新 checkpoint.json／原 capture receipt／independent readback 刷新 state、actual exit與hash；現在不先填 PASS。

| role | partial checkpoint 所記狀態 | 本稿實際 terminal exit |
|---|---|---|
| qualification_source | RUNNING；terminal receipt尚未列入該checkpoint | 未填；待root依實收據更新 |
| qualification_wheel | RUNNING；同上 | 未填；待root依實收據更新 |
| qualification_pyz | RUNNING；同上 | 未填；待root依實收據更新 |

不要重啟、重複已有的資格 session，也不把8a的283-case結果移植成fbc資格。資料夾存在本身不證明程序仍活躍；以原 terminal receipt和必要readback為準。即使三條exit0，也不會取消full suite15 failures、selfdogfood BLOCK或人類尚未接受的裁決。

fbc 的兩個額外 process smoke 已有獨立新回執：

- stage5/final/wheel-console-smoke-r1：exit0，實際 checkwash.exe、greenwash.exe均0.10.0；fresh -I import來自新 wheel-runtime 的 site-packages，移除了source PYTHONPATH/PYTHONHOME。
- stage5/final/pyz-process-qualification-r1：exit0，新的 checkwash.pyz 執行 canonical version/demo/clean0、term/json/sarif block1、bad ref/range/typo2及hook-json0。薄啟動器清除source環境後呼叫固定 tools/qualify_zipapp.py；沒有改 frozen tool。
- 兩者均 source/ending=fbc、source unchanged、input manifest 51836ac93ce5670644a050f8e3ced2390d377b63bff4b956cc52741b291f9ee5。它們是PJU本機artifact process smoke，不是重新跑三條assertion qualification、GitHub runner、formal checkrun或release collector。

## 在新工作點恢復

1. 先確認入口的 source_sha/code_source_sha=fbc，並核對實際 ZIP sidecar／manifest／readback。PARTIAL_CHECKPOINT 或 bundle NOT_READY 就照實當partial；資料複製／解壓／checksum相同不代表在新工作點重新驗證。
2. 在新 task workspace 恢復原相對 layout，尤其 work/ux-stage5/ 與 work/trusted/。不要flatten receipt或raw檔。舊歷史若需續查，再依d158五包與各manifest恢復；不是把runtime／tmp／.git或全域私人memory整包搬入payload。
3. 若沒有產品checkout，先 clone --no-checkout，再取得 fix/ux-repairs-20261026、精確fbc與1ffe Git objects。只在owned新checkout選 task-repo的LF：例如以 git -C work/checkwash-ux -c core.autocrlf=false -c core.eol=lf checkout --detach fbc9374dc3bcbfc47f403aec0c36e6b51dd7b86c materialize來源；不改host-global Git設定。已有checkout先檢視，不能reset/刪除使用者資料。
4. 依stage5/seal/source-seal.json核對**全部3,084 tracked members**的membership、raw bytes/length/SHA256與computed Git blob identity。Git status乾淨或SHA相同仍可能掩蓋實體CRLF差異；source ZIP保bytes，但不供Git history。
5. 以原 runtime/install/build receipts與uv.lock／pyproject在task-local目錄重建依賴，保留Python3.11.9、pytest9.1.1等已記runtime的區別；其他plugin/build版本按收據取，不猜、不改全域PATH/runtime。若用不同runtime或OS，記新範圍，不能冒稱舊qualification等價。
6. 恢復並逐manifest核對兩個trusted檔：work/trusted/replay_pju_action.py、work/trusted/collect_pju_receipts-at-1ffe.py。不要隨意換成HEAD或最新collector；1ffe object必須可供原工具的固定來源查詢。重播先讀工具說明與source PIN，不因檔案已搬好就寫PASS。
7. 原始stderr、失敗／中止／NOT_RUN、consumed grant、source與artifact hashes全部保留。繼續工作時先更新逐項台帳和明確residual，新的產品revision必須另固定來源與相應驗證，不混入fbc舊回執。

## 主機與授權邊界

PJU（LAPTOP-01AGNPJU）是已授權的預設執行主機，可以保重要資料。2026-10-27週二是人類處理pool斷網的背景，**沒有週二中午自動到期**；不因舊work-machine引文重問PJU位置授權、不查pool、不自建監控。記實際hostname/source/runtime/scope/exit/raw，明標 HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL；沒跑就NOT_RUN，不能冒稱pool或跨平台完成。

沿用人類已核可的0.x修補範圍；本訊息不新增paid/model/history/標註批次，不復活consumed grant，不改host-global服務/安全/runner/profile，不把未核可的golden/corpus labels或protected judge當成已批准，不自行merge/tag/release/改下游pin或恢復automation。發布與人類裁決的原驗收條件仍在。

人類原話是「我覺得可以一次做完吧 可以推版號 但到1.0版前要停下問我」。**1.0前必須停下取得Nelson明確決定。** 最新「明天7:30前把能推的都推上去」是換工作點前的備份截止，產品不趕，不是以deadline豁免失敗或催發布。

請先回報你實際讀到的source／checkpoint狀態與未完項，再繼續已有具體授權；不要泛稱整個產品或127項全部PASS。

