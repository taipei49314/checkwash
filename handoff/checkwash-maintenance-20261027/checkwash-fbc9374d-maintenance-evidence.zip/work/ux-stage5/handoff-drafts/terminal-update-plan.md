# Terminal 04 更新準備

狀態：**WAITING_FOR_ROOT_TERMINAL_NOTICE**。三條 qualification 仍未在此任務被當成終態；本任務沒有讀live ledger、重啟session或執行產品。

原04仍是9,390 bytes，SHA256：
79e771595d7a3eff7b8e86cbd72de1960e50cefc9062fdd010401a0bc8b00a88

已逐byte複製到 history/04-新session啟動訊息.partial-79e771595d7a3eff.md；目前04沒有修改。產品fbc、publisher與producer均未改。

## Root 通知後才做

對 qualification_source、qualification_wheel、qualification_pyz 各讀新的固定fbc outer receipt與對應 independent-readback。要求：

- source/expected_source/ending完整SHA均為fbc；label正確、fixed-source kind、source unchanged、changed_inputs=[]。
- 取actual integer exit、started/ended、runtime、原receipt raw SHA與input manifest；不以audit0替代outer exit。
- Audit的source/distribution/outer_receipt_sha256/exit與原capture一致；取本次實際qualification_status、summary(total/executed/failed)、errors、worker/qjson/ledger hashes、source package/suite/artifact hashes與raw-stream核對。
- 新case／package數只用新audit報出的實值；不預填8a的283/212/PASS。不完整或不一致就保留未完成並立即告root。

完整欄位與path map見 terminal-update-plan.json，係依owner提供的reviewed audit schema準備，未拿正在執行的資料流產生新結論。

## 修改與 freeze 順序

1. 先確認04仍為原79e77159 bytes；若root另有修改，先對齊而不覆寫。
2. 有root明確terminal＋audit通知後，再改資格段落／title／入口discovery說明，寫actual狀態與receipt/audit引用；保留full15fail、selfdog3high9warn、#567/#568等NONPASS。
3. bde維持「歷史partial」；新入口用branch discovery link尋找包外00/checkpoint，再要求核對精確metadata。
4. 記新04 hash及實引用的receipts/audits hashes，**pack前freeze**，之後不再改選入ZIP的04。
5. 04不嵌自身ZIP最終SHA或未來checkpoint commitSHA，避免自引用。最終身份由包外00/checkpoint、manifest和root最後verified連結提供。
6. 04只在work/handoff-drafts，讓既有packer收進bundle；不手動加到payload根，否則producer MANIFEST漏列且下次refresh拒絕extra。

Root已同意此順序。等待明確通知，不自行輪詢、執行pack/push或把RUNNING換成PASS。保守下一次台灣07:30是備份截止，產品不趕；PJU沒有週二自動到期，fbc仍固定，1.0前停問仍有效。

