"""Compare unchanged native failure IDs; no missing failure becomes PASS."""
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

here = Path(__file__).resolve().parent
old_path = here.parent / "ux-stage4/final/full-suite-311-r1/independent-readback.json"
new_path = here / "final/full-suite-311-r1/independent-readback.json"
old = json.loads(old_path.read_bytes())
new = json.loads(new_path.read_bytes())
assert old["audit_exit_code"] == new["audit_exit_code"] == 0
assert old["suite_exit_code"] == new["suite_exit_code"] == 1
old_ids, new_ids = set(old["failure_nodeids"]), set(new["failure_nodeids"])
root = ET.parse(here / "final/full-suite-311-r1/junit.xml")
negative_controls = []
for name in ("test_startup_probe_does_not_add_a_detector_skip_to_an_unchanged_importer",
             "test_ci_test_move_with_a_different_relative_producer_keeps_blocking"):
    matches = [node for node in root.iter("testcase") if node.get("name") == name]
    assert len(matches) == 1
    node = matches[0]
    assert not any(child.tag in {"failure", "error", "skipped"} for child in node)
    negative_controls.append({"classname": node.get("classname"), "name": name, "native_outcome": "passed"})
result = {"kind": "READ_ONLY_NATIVE_SUITE_DELTA_NOT_ACCEPTANCE", "old_source_sha": old["source_sha"],
          "new_source_sha": new["source_sha"], "old_suite_exit": 1, "new_suite_exit": 1,
          "old_failure_count": len(old_ids), "new_failure_count": len(new_ids),
          "resolved_failure_nodeids": sorted(old_ids-new_ids),
          "new_failure_nodeids": sorted(new_ids-old_ids), "remaining_failure_nodeids": sorted(new_ids),
          "new_negative_controls": negative_controls,
          "old_readback_sha256": hashlib.sha256(old_path.read_bytes()).hexdigest(),
          "new_readback_sha256": hashlib.sha256(new_path.read_bytes()).hexdigest(),
          "product_calls": 0, "pytest_calls": 0, "acceptance": "NONPASS"}
target = here / "full-suite-regression-delta.json"
assert not target.exists()
target.write_text(json.dumps(result, indent=2), encoding="utf-8")
print(json.dumps({"old_failed": len(old_ids), "new_failed": len(new_ids),
                  "resolved": len(old_ids-new_ids), "new_failures": len(new_ids-old_ids),
                  "new_negative_controls_passed": len(negative_controls), "acceptance": "NONPASS"}))
