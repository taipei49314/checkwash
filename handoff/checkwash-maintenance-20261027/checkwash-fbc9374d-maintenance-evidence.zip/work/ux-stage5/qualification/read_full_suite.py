"""Read native full-suite evidence; never import/run CheckWash or pytest.

Audit exit 0 means receipt consistency was verified, not that the suite passed.
The actual pytest exit and COMPLETE_FAILED_SUITE remain explicit in the JSON.
Missing terminal evidence returns 2 and is never written as a passing result.
Only two local, read-only Git queries run, after terminal evidence exists.
"""
from collections import Counter
from collections import defaultdict
import argparse
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[3]
SOURCE = ROOT / "work/checkwash-ux"
STAGE = ROOT / "work/ux-stage5"
PIN = STAGE / "final-source-sha.txt"
LABELS = ("subtests passed", "subtests failed", "subtests skipped", "passed", "failed", "skipped",
          "xfailed", "xpassed", "errors", "error", "warnings", "warning", "deselected", "rerun")
COUNT = re.compile(r"(?<![\w.])(\d+)\s+(" + "|".join(LABELS) + r")\b")
ANSI = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=ROOT / "work/ux-stage5/final/full-suite-311-r1")
    parser.add_argument("--result", type=Path)
    args = parser.parse_args()
    out = args.output.resolve()
    if not out.is_relative_to(STAGE.resolve()):
        print(json.dumps({"status": "WRONG_EVIDENCE_NAMESPACE", "readback_integrity": "UNVERIFIED",
                          "suite_passed": None, "product_calls": 0}, indent=2))
        return 1
    destination = (args.result or out / "independent-readback.json").resolve()
    if not destination.is_relative_to(STAGE.resolve()):
        print(json.dumps({"status": "WRONG_RESULT_NAMESPACE", "readback_integrity": "UNVERIFIED",
                          "suite_passed": None, "product_calls": 0}, indent=2))
        return 1
    names = ("receipt.json", "stdout.txt", "stderr.txt", "junit.xml", "input-hashes.json",
             "source.diff", "git-status.txt")
    paths = {name: out / name for name in names}
    paths["final-source-sha.txt"] = PIN
    missing = [name for name, path in paths.items() if not path.is_file()]
    if missing:
        terminal = paths["receipt.json"].is_file()
        print(json.dumps({
            "status": "INCOMPLETE_TERMINAL_EVIDENCE" if terminal else "RUNNING_OR_MISSING_TERMINAL_RECEIPT",
            "readback_integrity": "INCOMPLETE", "suite_passed": None, "missing": missing,
            "output": str(out), "product_calls": 0,
        }, indent=2))
        return 2

    raw = {name: path.read_bytes() for name, path in paths.items()}
    EXPECTED = raw["final-source-sha.txt"].decode("utf-8").strip()
    if re.fullmatch(r"(?:[0-9a-f]{40}|[0-9a-f]{64})", EXPECTED) is None:
        raise ValueError("invalid sealed stage5 source pin")
    hashes = {name: sha(data) for name, data in raw.items()}
    issues = []

    def require(condition, message):
        if not condition:
            issues.append(message)

    receipt = json.loads(raw["receipt.json"])
    manifest = json.loads(raw["input-hashes.json"])
    terminal_missing = [name for name in ("started_utc", "ended_utc", "exit_code") if name not in receipt]
    if terminal_missing:
        print(json.dumps({"status": "RUNNING_OR_MISSING_TERMINAL_FIELDS", "readback_integrity": "INCOMPLETE",
                          "suite_passed": None, "missing": terminal_missing, "product_calls": 0}, indent=2))
        return 2
    started, ended = (datetime.fromisoformat(receipt[name]) for name in ("started_utc", "ended_utc"))
    require(started.tzinfo is not None and ended.tzinfo is not None and started <= ended,
            "capture terminal timestamps are invalid")
    if type(receipt["exit_code"]) is not int:
        raise ValueError("capture suite exit must be an integer, excluding booleans")

    def safe_path(name):
        return (isinstance(name, str) and bool(name) and not name.startswith("/") and ":" not in name
                and "\\" not in name and not any(c in name for c in "\r\n\0")
                and all(part not in {"", ".", ".."} for part in name.split("/")))

    def valid_digest(value):
        return isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value) is not None

    if (not isinstance(manifest, dict) or not manifest
            or not all(safe_path(name) and valid_digest(value) for name, value in manifest.items())):
        raise ValueError("input manifest must be a nonempty normalized relative path -> SHA256 map")
    seal_path = ROOT / "work/ux-stage5/seal/source-seal.json"
    seal_raw = seal_path.read_bytes()
    seal = json.loads(seal_raw)
    rows = seal.get("files")
    if (seal.get("source_sha") != EXPECTED or seal.get("all_tracked_bytes_match_git") is not True
            or not isinstance(rows, list) or not rows or type(seal.get("tracked_files")) is not int
            or seal["tracked_files"] != len(rows)):
        raise ValueError("fixed source seal header/file inventory is invalid")
    seal_map = {}
    blob_width = {"sha1": 40, "sha256": 64}.get(seal.get("git_object_format"))
    if blob_width is None:
        raise ValueError("fixed source seal object format is invalid")
    for row in rows:
        if (not isinstance(row, dict) or not safe_path(row.get("path")) or not valid_digest(row.get("sha256"))
                or row["path"] in seal_map or row.get("matches") is not True
                or row.get("mode") not in {"100644", "100755"}
                or not isinstance(row.get("git_blob"), str)
                or re.fullmatch(r"[0-9a-f]{" + str(blob_width) + r"}", row["git_blob"]) is None
                or row.get("actual_git_blob") != row["git_blob"]):
            raise ValueError("fixed source seal has invalid/duplicate file provenance")
        seal_map[row["path"]] = row["sha256"]
    if manifest != seal_map:
        raise ValueError("capture input manifest is not the exact complete sealed source file map")
    require(receipt.get("expected_source_sha") == receipt.get("source_sha")
            == receipt.get("ending_sha") == EXPECTED, "capture source identities differ from sealed source pin")
    require(receipt.get("validation_kind") == "FIXED_SOURCE_NOT_RELEASE_BRIDGE", "capture kind is not fixed development source")
    require(receipt.get("source_files_unchanged") is True and receipt.get("changed_inputs") == [],
            "capture reports changed source inputs")
    require(receipt.get("input_manifest_sha256") == hashes["input-hashes.json"], "input manifest digest mismatch")
    require(raw["source.diff"] == b"" and receipt.get("source_diff_sha256") == sha(b""), "capture starts with a source diff")
    require(raw["git-status.txt"] == b"", "capture starts with dirty source status")
    require((ROOT / "work/ux-stage5/final-source-sha.txt").read_text(encoding="utf-8").strip() == EXPECTED,
            "final source pin changed")
    command = receipt.get("command")
    junit_arguments = []
    if isinstance(command, list) and all(isinstance(arg, str) for arg in command):
        for index, argument in enumerate(command):
            if argument in {"--junitxml", "--junit-xml"} and index + 1 < len(command):
                junit_arguments.append(command[index + 1])
            elif argument.startswith(("--junitxml=", "--junit-xml=")):
                junit_arguments.append(argument.partition("=")[2])
    require(len(junit_arguments) == 1 and Path(junit_arguments[0]).resolve() == paths["junit.xml"].resolve(),
            "capture command does not bind exactly this native JUnit path")
    current_differences = []
    source_root = SOURCE.resolve()
    for name, digest in manifest.items():
        path = SOURCE / name
        if (not path.parent.resolve().is_relative_to(source_root) or path.is_symlink()
                or not path.is_file() or sha(path.read_bytes()) != digest):
            current_differences.append(name)
    require(not current_differences, "current source bytes differ from capture manifest")

    git_rows = []
    env = dict(os.environ, GIT_CONFIG_GLOBAL=os.devnull, GIT_CONFIG_NOSYSTEM="1", GIT_TERMINAL_PROMPT="0")
    for arguments in (("rev-parse", "HEAD"), ("status", "--porcelain", "--untracked-files=all")):
        command = ["git", "--no-optional-locks", "-c", "core.fsmonitor=false", "-C", str(SOURCE), *arguments]
        process = subprocess.run(command, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60)
        git_rows.append({"command": command, "exit": process.returncode,
                         "stdout": process.stdout.decode("utf-8", "backslashreplace"),
                         "stderr": process.stderr.decode("utf-8", "backslashreplace"),
                         "stdout_sha256": sha(process.stdout), "stderr_sha256": sha(process.stderr)})
        require(process.returncode == 0, "read-only current-source Git query failed")
    require(git_rows[0]["stdout"].strip() == EXPECTED, "current HEAD differs from sealed source pin")
    require(git_rows[1]["stdout"] == "", "current source is dirty")

    stdout = raw["stdout.txt"].decode("utf-8", "strict")
    stderr = raw["stderr.txt"].decode("utf-8", "strict")
    text = ANSI.sub("", stdout)
    summaries = [line.strip() for line in text.splitlines()
                 if re.search(r"\bin\s+\d+(?:\.\d+)?s\b", line) and COUNT.search(line)]
    summary_line = summaries[-1] if summaries else None
    counts = Counter()
    if summary_line is not None:
        for amount, label in COUNT.findall(summary_line):
            counts[{"error": "errors", "warning": "warnings"}.get(label, label)] += int(amount)
    require(summary_line is not None, "stdout has no terminal pytest outcome summary")

    xml = ET.fromstring(raw["junit.xml"])
    all_suites = list(xml.iter("testsuite"))
    suites = [suite for suite in all_suites if not suite.findall("testsuite")]
    cases = list(xml.iter("testcase"))
    require(bool(suites), "native JUnit has no testsuite")
    for suite in suites:
        require(suite.attrib.get("hostname") == receipt.get("host"), "native JUnit hostname differs from capture")
        timestamp = suite.attrib.get("timestamp")
        if timestamp is None:
            require(False, "native JUnit has no start timestamp")
        else:
            moment = datetime.fromisoformat(timestamp)
            require(moment.tzinfo is not None and started <= moment <= ended,
                    "native JUnit timestamp is outside the capture interval")
    declared = {key: sum(int(suite.attrib.get(key, "0")) for suite in suites)
                for key in ("tests", "failures", "errors", "skipped")}

    # Map native dotted classnames back through the captured real Python paths.
    # This preserves exact pytest parameter IDs rather than guessing file names.
    modules = {name[:-3].replace("/", "."): name for name in manifest if name.endswith(".py")}

    def nodeid(case):
        classname, name = case.attrib.get("classname", ""), case.attrib.get("name", "")
        candidates = [module for module in modules if classname == module or classname.startswith(module + ".")]
        if not candidates:
            return None
        module = max(candidates, key=len)
        classes = classname[len(module):].lstrip(".")
        return modules[module] + ("::" + classes.replace(".", "::") if classes else "") + "::" + name

    parent_groups = defaultdict(list)
    failed, skipped, unknown = [], [], []
    result_elements = Counter()
    for index, case in enumerate(cases):
        identity = nodeid(case)
        if identity is None:
            unknown.append(dict(case.attrib))
        key = identity if identity is not None else "UNMAPPED_XML_CASE_" + str(index)
        outcomes = [child.tag for child in case if child.tag in {"failure", "error", "skipped"}]
        result_elements.update(outcomes)
        state = "error" if "error" in outcomes else "failed" if "failure" in outcomes else "skipped" if "skipped" in outcomes else "passed"
        parent_groups[key].append(state)
        for child in case:
            if child.tag not in {"failure", "error", "skipped"}:
                continue
            details = {"nodeid": identity, "xml_attributes": dict(case.attrib), "outcome": child.tag,
                       "type": child.attrib.get("type"), "message": child.attrib.get("message"),
                       "text": child.text or "", "text_sha256": sha((child.text or "").encode("utf-8"))}
            (skipped if child.tag == "skipped" else failed).append(details)
    parent_counts = Counter()
    priority = {"passed": 0, "skipped": 1, "failed": 2, "error": 3}
    for values in parent_groups.values():
        parent_counts[max(values, key=priority.get)] += 1
    require(not unknown, "some native XML cases could not be mapped to exact source nodeIDs")

    # pytest's native XML `tests` counts reports, including successful subtest
    # reports. Its testcase elements/unique IDs describe the parent topology.
    # Read subtests from the terminal's own labeled categories; never infer a
    # fixed constant or call the native XML declared total a parent collection.
    outcome_labels = ("passed", "failed", "skipped", "xfailed", "xpassed", "errors",
                      "subtests passed", "subtests failed", "subtests skipped")
    stdout_reports_total = sum(counts[label] for label in outcome_labels)
    require(declared["tests"] == stdout_reports_total, "native XML report total differs from terminal outcome categories")
    require(declared["failures"] == counts["failed"] + counts["subtests failed"], "XML/terminal failure report counts differ")
    require(declared["errors"] == counts["errors"], "XML/terminal error report counts differ")
    require(declared["skipped"] == counts["skipped"] + counts["xfailed"] + counts["subtests skipped"],
            "XML/terminal skipped report counts differ")
    require(result_elements["failure"] == declared["failures"] and result_elements["error"] == declared["errors"]
            and result_elements["skipped"] == declared["skipped"], "XML result elements disagree with native declared statistics")

    short = text.rsplit("short test summary info", 1)[-1]
    xml_failure_ids = sorted({row["nodeid"] for row in failed if row["nodeid"] is not None})
    longest_failure_ids = sorted(xml_failure_ids, key=len, reverse=True)
    terminal_failures = []
    for line in short.splitlines():
        match = re.match(r"^(FAILED|ERROR)\s+(.+)$", line.strip())
        if match:
            rest = match.group(2)
            identity = next((node for node in longest_failure_ids if rest == node or rest.startswith(node + " - ")), None)
            terminal_failures.append({"outcome": match.group(1), "nodeid": identity, "line": line})
            require(identity is not None, "stdout has a failure line that does not match any exact native XML nodeID")
    terminal_failure_ids = sorted({row["nodeid"] for row in terminal_failures if row["nodeid"] is not None})
    require(xml_failure_ids == terminal_failure_ids, "exact native XML failure nodeIDs differ from stdout short summary")
    skip_lines = [line for line in short.splitlines() if re.match(r"^SKIPPED\s+\[\d+\]", line.strip())]
    skip_short_total = sum(int(re.search(r"\[(\d+)\]", line).group(1)) for line in skip_lines)
    if skip_lines:
        require(skip_short_total == counts["skipped"], "stdout short-summary skip groups differ from terminal skipped count")

    collection_counts = [int(value) for value in re.findall(r"\bcollected\s+(\d+)\s+items?", text)]
    collection_counts += [int(value) for value in re.findall(r"\d+\s+workers?\s+\[(\d+)\s+items?\]", text)]
    collection = collection_counts[-1] if collection_counts else None
    if collection is not None:
        require(len(parent_groups) + counts["deselected"] == collection,
                "native unique-parent count plus deselections differs from explicit stdout collection")

    actual_exit = receipt.get("exit_code")
    has_failures = bool(declared["failures"] or declared["errors"])
    if actual_exit == 0:
        require(not has_failures, "pytest exit 0 conflicts with native failures/errors")
    if actual_exit == 1:
        require(has_failures, "pytest exit 1 has no native test failures/errors")
    suite_state = "PASSED" if actual_exit == 0 and not has_failures else "FAILED" if actual_exit == 1 else "ABORTED_OR_OTHER_EXIT"
    result = {
        "status": "INCONSISTENT_EVIDENCE" if issues else "COMPLETE_" + suite_state + "_SUITE",
        "readback_integrity": "INCONSISTENT" if issues else "VERIFIED",
        "suite_state": suite_state, "suite_exit_code": actual_exit,
        "audit_exit_code": 1 if issues else 0, "issues": issues,
        "scope": "LOCAL_DEVELOPMENT_FULL_SUITE_NOT_RELEASE_BRIDGE",
        "source_sha": EXPECTED, "host": receipt.get("host"), "runtime": receipt.get("python"),
        "provenance": receipt.get("provenance"), "command": receipt.get("command"),
        "capture_source_files_unchanged": receipt.get("source_files_unchanged"),
        "manifest_files": len(manifest), "current_source_differences": current_differences,
        "sealed_source_map_exact_match": True, "source_seal_sha256": sha(seal_raw),
        "read_only_git_queries": git_rows, "file_sha256": hashes,
        "stdout_terminal_summary": summary_line, "stdout_native_report_counts": dict(counts),
        "stdout_explicit_collection": collection,
        "stdout_collection_missing_note": None if collection is not None else "No explicit collection count in stdout; use native parent topology without claiming a collection banner.",
        "native_xml_suite_attributes": [dict(suite.attrib) for suite in all_suites],
        "native_xml_declared_report_counts": declared,
        "native_xml_testcase_elements": len(cases), "native_xml_unique_parent_nodeids": len(parent_groups),
        "native_xml_parent_outcomes": dict(parent_counts),
        "native_xml_report_total_minus_testcase_elements": declared["tests"] - len(cases),
        "stdout_explicit_subtest_categories": {key: value for key, value in counts.items() if key.startswith("subtests ")},
        "parent_subtest_note": "XML declared tests counts reports; testcase/unique-nodeID totals describe parents. Failed/skipped subtest reports may share terminal categories with their parents; raw native categories and result nodes are retained without inventing a split.",
        "failure_nodeids": xml_failure_ids, "stdout_failure_nodes": terminal_failures,
        "native_xml_failure_or_error_details": failed, "native_xml_skip_details": skipped,
        "native_xml_skip_reason_counts": dict(Counter(row["message"] or row["text"] for row in skipped)),
        "stdout_skip_summary_lines": skip_lines, "unmapped_xml_cases": unknown,
        "stderr_bytes": len(raw["stderr.txt"]), "stderr_text": stderr,
        "product_calls": 0, "pytest_calls": 0, "published_checks": 0,
        "auditor_runtime": sys.version, "auditor_command": sys.argv,
        "auditor_sha256": sha(Path(__file__).read_bytes()),
    }
    # destination was normalized and bounded to stage5 before evidence reads.
    encoded = (json.dumps(result, indent=2) + "\n").encode("utf-8")
    if destination.exists():
        if destination.read_bytes() != encoded:
            raise ValueError("preserve previous readback; select a new --result path")
    else:
        destination.write_bytes(encoded)
    print(json.dumps({key: value for key, value in result.items()
                      if key not in {"native_xml_failure_or_error_details", "native_xml_skip_details", "stderr_text"}}, indent=2))
    return result["audit_exit_code"]


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError, KeyError, TypeError, ET.ParseError, subprocess.SubprocessError) as exc:
        print(json.dumps({"status": "READBACK_ERROR", "readback_integrity": "UNVERIFIED",
                          "suite_passed": None, "error": type(exc).__name__ + ": " + str(exc),
                          "product_calls": 0}, indent=2))
        raise SystemExit(1)
