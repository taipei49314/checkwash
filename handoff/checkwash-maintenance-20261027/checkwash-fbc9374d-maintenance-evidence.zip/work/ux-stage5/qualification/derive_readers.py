"""Derive stage5 evidence readers as text; never execute/compile/import them."""
import difflib
import hashlib
import json
from pathlib import Path
import platform
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
OLD = ROOT / "work/ux-stage4/qualification"
STAGE = ROOT / "work/ux-stage5"
DERIVATION = HERE / "reader-derivation"
DERIVATION.mkdir(exist_ok=False)
BASES = {
    "read_source_result.py": "7134c70531052d41cf25b44ae443ff112552988b8684366df93652c3be3845b4",
    "read_full_suite.py": "0d1e19b2feae9caf916b7f71e1e534448fd34496ce7e11fe5b01ec487006c7af",
}
OLD_PIN = "8a8941dc2d7c581715a0f6f196c00da6c55f084b"


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


records = []
for name, expected in BASES.items():
    original = (OLD / name).read_bytes()
    assert sha(original) == expected and b"\r\n" not in original
    (DERIVATION / ("stage4-" + name)).write_bytes(original)
    text = original.decode("utf-8")
    operations = []

    def change(old, new, label, count=1):
        global text
        assert text.count(old) == count, (name, label, text.count(old), count)
        text = text.replace(old, new)
        operations.append({"label": label, "old": old, "new": new, "occurrences": count})

    change("work/ux-stage4", "work/ux-stage5", "stage-specific evidence namespace", text.count("work/ux-stage4"))
    if name == "read_source_result.py":
        change("import json\n", "import json\nimport re\n", "validate dynamic sealed source pin")
        change('EXPECTED = "' + OLD_PIN + '"\n',
               'STAGE = ROOT / "work/ux-stage5"\nPIN = STAGE / "final-source-sha.txt"\n',
               "replace fixed stage4 source with stage5 pin path")
        anchor = 'CAPTURE = args.capture or ROOT / ("work/ux-stage5/final/" + args.kind + "-assertion-qualification-r1")\n'
        guard = '''OUT = OUT.resolve()
CAPTURE = CAPTURE.resolve()
assert OUT.is_relative_to(STAGE.resolve()) and CAPTURE.is_relative_to(STAGE.resolve()), "stage5 reader requires stage5 output/capture"
if not PIN.is_file():
    print(json.dumps({"status": "INCOMPLETE_SOURCE_PIN", "missing": str(PIN), "qualification_passed": None,
                      "product_calls": 0}, indent=2))
    raise SystemExit(2)
EXPECTED = PIN.read_text(encoding="utf-8").strip()
assert re.fullmatch(r"(?:[0-9a-f]{40}|[0-9a-f]{64})", EXPECTED), "invalid sealed stage5 source pin"
'''
        change(anchor, anchor + guard, "stage5 output/capture boundaries and incomplete/validated pin")
        anchor = '    artifact = Path(receipt["command"][receipt["command"].index("--artifact") + 1]).resolve(strict=True)\n'
        change(anchor, anchor + '    assert artifact.is_relative_to(STAGE.resolve()), "artifact must belong to stage5"\n',
               "reject reuse of a stage4 artifact despite identical source package bytes")
        anchor = '        assert info["prefix"] != info["base"] and installed.is_relative_to(Path(info["prefix"]).resolve())\n'
        change(anchor, anchor + '        assert Path(info["prefix"]).resolve().is_relative_to(STAGE.resolve()), "loaded wheel runtime must belong to stage5"\n',
               "bind fresh loaded-wheel runtime to stage5")
        anchor = '    "source_sha": EXPECTED, "qualification_status": qualification["status"], "summary": summary,\n'
        change(anchor, anchor + '    "source_pin_path": str(PIN), "source_pin_sha256": sha(PIN.read_bytes()),\n',
               "record exact dynamic pin input")
    else:
        change('EXPECTED = "' + OLD_PIN + '"\n',
               'STAGE = ROOT / "work/ux-stage5"\nPIN = STAGE / "final-source-sha.txt"\n',
               "replace fixed stage4 source with stage5 pin path")
        change('    out = args.output\n', '''    out = args.output.resolve()
    if not out.is_relative_to(STAGE.resolve()):
        print(json.dumps({"status": "WRONG_EVIDENCE_NAMESPACE", "readback_integrity": "UNVERIFIED",
                          "suite_passed": None, "product_calls": 0}, indent=2))
        return 1
''', "reject an old-stage full-suite output")
        anchor = '    paths = {name: out / name for name in names}\n'
        change(anchor, anchor + '    paths["final-source-sha.txt"] = PIN\n', "include pin in incomplete-evidence handling")
        anchor = '    raw = {name: path.read_bytes() for name, path in paths.items()}\n'
        change(anchor, anchor + '''    EXPECTED = raw["final-source-sha.txt"].decode("utf-8").strip()
    if re.fullmatch(r"(?:[0-9a-f]{40}|[0-9a-f]{64})", EXPECTED) is None:
        raise ValueError("invalid sealed stage5 source pin")
''', "validate pin before source/receipt checks")
        change("fixed 8a source", "sealed source pin", "remove stale source-specific diagnostic wording", text.count("fixed 8a source"))
    assert OLD_PIN not in text and "ux-stage4" not in text
    derived = text.encode("utf-8")
    destination = HERE / name
    assert not destination.exists()
    destination.write_bytes(derived)
    reverse = text
    for operation in reversed(operations):
        assert reverse.count(operation["new"]) == operation["occurrences"], (name, operation["label"])
        reverse = reverse.replace(operation["new"], operation["old"])
    assert reverse.encode() == original
    patch = "".join(difflib.unified_diff(original.decode().splitlines(keepends=True), text.splitlines(keepends=True),
                                       fromfile="stage4/qualification/" + name, tofile="stage5/qualification/" + name))
    diff_path = DERIVATION / (name + ".diff")
    diff_path.write_text(patch, encoding="utf-8", newline="\n")
    records.append({"reader": name, "reviewed_stage4_sha256": expected, "stage5_sha256": sha(derived),
                    "diff_sha256": sha(diff_path.read_bytes()), "physical_newlines": "LF",
                    "reverse_transform_exactly_restores_stage4_bytes": True, "transformations": operations})

controller_pairs = []
for name in ("qualify_one.py", "seal_source.py", "build_pyz.py"):
    previous = (ROOT / "work/ux-stage4" / name).read_bytes()
    current = (STAGE / name).read_bytes()
    assert previous == current
    controller_pairs.append({"name": name, "stage4_sha256": sha(previous), "stage5_sha256": sha(current), "bytes_equal": True})
old_capture = (ROOT / "work/ux-stage4/capture_final.py").read_bytes()
new_capture = (STAGE / "capture_final.py").read_bytes()
assert old_capture.count(b'"cwf4-"') == 1
assert old_capture.replace(b'"cwf4-"', b'"cwf5-"') == new_capture
controller_pairs.append({"name": "capture_final.py", "stage4_sha256": sha(old_capture), "stage5_sha256": sha(new_capture),
                         "only_change": "temporary prefix cwf4- -> cwf5-"})
for name, digest in BASES.items():
    assert sha((OLD / name).read_bytes()) == digest
record = {"state": "PREPARED_NOT_EXECUTED_NOT_COMPILED", "host": platform.node(), "runtime": sys.version,
          "provenance": "HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL", "readers": records,
          "controller_derivation": controller_pairs, "product_calls": 0, "pytest_calls": 0,
          "new_reader_calls": 0, "new_reader_compile_calls": 0,
          "source_checkout": str(ROOT / "work/checkwash-ux"),
          "shared_trusted_tracer": "work/trusted/collect_pju_receipts-at-1ffe.py (fixed BASE preserved)",
          "source_pin": "work/ux-stage5/final-source-sha.txt (not created by this authoring step)",
          "original_stage4_reader_bytes_preserved": True}
(DERIVATION / "derivation.json").write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"state": record["state"], "readers": [{"reader": row["reader"], "sha256": row["stage5_sha256"],
                                                          "diff_sha256": row["diff_sha256"]} for row in records]}, indent=2))
