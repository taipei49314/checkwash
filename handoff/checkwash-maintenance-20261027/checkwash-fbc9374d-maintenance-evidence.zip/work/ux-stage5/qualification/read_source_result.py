"""Independent standard-library readback of completed artifact qualification."""
import argparse
from collections import Counter
import hashlib
import json
import re
from pathlib import Path
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[3]
SOURCE = ROOT / "work/checkwash-ux"
STAGE = ROOT / "work/ux-stage5"
PIN = STAGE / "final-source-sha.txt"
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--kind", choices=("source", "wheel", "pyz"), default="source")
parser.add_argument("--output", type=Path)
parser.add_argument("--capture", type=Path)
args = parser.parse_args()
OUT = args.output or Path(__file__).resolve().parent / (args.kind + "-r1")
CAPTURE = args.capture or ROOT / ("work/ux-stage5/final/" + args.kind + "-assertion-qualification-r1")
OUT = OUT.resolve()
CAPTURE = CAPTURE.resolve()
assert OUT.is_relative_to(STAGE.resolve()) and CAPTURE.is_relative_to(STAGE.resolve()), "stage5 reader requires stage5 output/capture"
if not PIN.is_file():
    print(json.dumps({"status": "INCOMPLETE_SOURCE_PIN", "missing": str(PIN), "qualification_passed": None,
                      "product_calls": 0}, indent=2))
    raise SystemExit(2)
EXPECTED = PIN.read_text(encoding="utf-8").strip()
assert re.fullmatch(r"(?:[0-9a-f]{40}|[0-9a-f]{64})", EXPECTED), "invalid sealed stage5 source pin"


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


qualification = read(OUT / "qualification.json")
receipt = read(OUT / "receipt.json")
capture = read(CAPTURE / "receipt.json")
ledger = read(OUT / "raw/commands.json")
assert qualification["source_commit"] == receipt["source_sha"] == receipt["ending_sha"] == EXPECTED
assert capture["expected_source_sha"] == capture["source_sha"] == capture["ending_sha"] == EXPECTED
assert capture["validation_kind"] == "FIXED_SOURCE_NOT_RELEASE_BRIDGE"
assert qualification["distribution"] == receipt["kind"] == args.kind
assert receipt["source_files_unchanged"] and capture["source_files_unchanged"]
assert capture["changed_inputs"] == [] and not qualification["source_package_dirty"]
assert sha(json.dumps(receipt["source_files"], sort_keys=True).encode()) == receipt["source_input_manifest_sha256"]
assert sha((CAPTURE / "input-hashes.json").read_bytes()) == capture["input_manifest_sha256"]
assert (CAPTURE / "source.diff").read_bytes() == b"" and (CAPTURE / "git-status.txt").read_bytes() == b""
assert capture["source_diff_sha256"] == sha(b"")
assert receipt["formal_release_collector"] is False and receipt["published_check_runs"] == 0
assert receipt["trusted_trace_source"] == "1ffe283d7d947fecc426dea99323b0a2620a9482"
assert sha((ROOT / "work/trusted/collect_pju_receipts-at-1ffe.py").read_bytes()) == receipt["trusted_trace_sha256"]
summary = qualification["summary"]
assert summary["total"] == 283
assert summary["executed"] == len(qualification["cases"])
assert summary["failed"] == sum(row["status"] != "passed" for row in qualification["cases"])
assert len({row["id"] for row in qualification["cases"]}) == len(qualification["cases"])
assert sha((SOURCE / "tools/qualify_assertions.py").read_bytes()) == receipt["qualifier_sha256"]
for name, digest in receipt["contracts"].items():
    assert sha((SOURCE / name).read_bytes()) == digest
assert {row["path"]: row["sha256"] for row in qualification["inventories"]} == receipt["contracts"]
assert sum(row["mutations"] for row in qualification["inventories"]) == summary["total"]
package = SOURCE / "src/checkwash"
members = {
    "checkwash/" + path.relative_to(package).as_posix(): sha(path.read_bytes())
    for path in sorted(package.rglob("*"))
    if path.is_file() and "__pycache__" not in path.parts and path.suffix != ".pyc"
}
package_digest = sha(json.dumps(members, sort_keys=True, separators=(",", ":")).encode())
assert qualification["source_package_sha256"] == package_digest
artifact = None
archive_member_count = None
if args.kind == "source":
    assert qualification["artifact_sha256"] is None and "--artifact" not in receipt["command"]
else:
    artifact = Path(receipt["command"][receipt["command"].index("--artifact") + 1]).resolve(strict=True)
    assert artifact.is_relative_to(STAGE.resolve()), "artifact must belong to stage5"
    assert sha(artifact.read_bytes()) == qualification["artifact_sha256"]
    with zipfile.ZipFile(artifact) as archive:
        names = [name for name in archive.namelist() if name.startswith("checkwash/") and not name.endswith("/")
                 and "__pycache__" not in Path(name).parts and not name.endswith(".pyc")]
        assert len(names) == len(set(names))
        archive_members = {name: sha(archive.read(name)) for name in names}
    assert archive_members == members
    archive_member_count = len(archive_members)
streams = {stream: (OUT / "raw" / (stream + ".bin")).read_bytes() for stream in ("stdout", "stderr")}
offsets = {stream: 0 for stream in streams}
checks = 0
for command in ledger:
    for stream in streams:
        item = command[stream]
        assert item["path"] == stream + ".bin"
        assert item["offset"] == offsets[stream]
        chunk = streams[stream][item["offset"]:item["offset"] + item["bytes"]]
        assert len(chunk) == item["bytes"] and sha(chunk) == item["sha256"]
        offsets[stream] += item["bytes"]
        checks += 1
assert all(offsets[stream] == len(data) for stream, data in streams.items())
case_commands = [row for row in ledger if "HEAD~1..HEAD" in row["argv"]]
if args.kind == "source":
    product_commands = [row for row in ledger if any("from checkwash.cli import main" in arg for arg in row["argv"])]
elif args.kind == "wheel":
    product_commands = [row for row in ledger if any(row["argv"][i:i + 2] == ["-m", "checkwash"]
                                                   for i in range(len(row["argv"]) - 1))]
else:
    product_commands = [row for row in ledger if str(artifact) in row["argv"]]
loaded_probes = []
if args.kind == "wheel":
    for command in ledger:
        if not any("checkwash.__file__" in arg for arg in command["argv"]):
            continue
        item = command["stdout"]
        info = json.loads(streams["stdout"][item["offset"]:item["offset"] + item["bytes"]])
        installed = Path(info["package"]).resolve().parent
        assert info["prefix"] != info["base"] and installed.is_relative_to(Path(info["prefix"]).resolve())
        assert Path(info["prefix"]).resolve().is_relative_to(STAGE.resolve()), "loaded wheel runtime must belong to stage5"
        loaded_members = {"checkwash/" + path.relative_to(installed).as_posix(): sha(path.read_bytes())
                          for path in sorted(installed.rglob("*")) if path.is_file()
                          and "__pycache__" not in path.parts and path.suffix != ".pyc"}
        assert loaded_members == members
        loaded_probes.append(info)
assert len(case_commands) == summary["executed"]
assert all(not row["timed_out"] and row["error"] is None for row in ledger)
assert capture["exit_code"] == receipt["exit_code"]
if qualification["status"] == "passed":
    assert summary == {"total": 283, "executed": 283, "failed": 0}
    assert qualification["errors"] == []
    assert capture["exit_code"] == receipt["exit_code"] == 0
    assert len(product_commands) == summary["executed"] + 3
    if args.kind == "wheel":
        assert len(loaded_probes) == 2

result = {
    "kind": "READ_ONLY_QUALIFICATION_RESULT_AUDIT_NOT_RELEASE_BRIDGE", "distribution": args.kind,
    "provenance": receipt["provenance"], "host": receipt["host"], "runtime": receipt["python"],
    "source_sha": EXPECTED, "qualification_status": qualification["status"], "summary": summary,
    "source_pin_path": str(PIN), "source_pin_sha256": sha(PIN.read_bytes()),
    "version": qualification["version"], "source_manifest_files": len(receipt["source_files"]),
    "qualification_errors": qualification["errors"], "exit_code": capture["exit_code"],
    "source_files_unchanged": True, "source_package_sha256": package_digest,
    "suite_sha256": qualification["suite_sha256"], "artifact_sha256": qualification["artifact_sha256"],
    "artifact": None if artifact is None else str(artifact), "archive_package_members_verified": archive_member_count,
    "loaded_wheel_probes_verified": loaded_probes,
    "trusted_trace_source": receipt["trusted_trace_source"], "trusted_trace_sha256": receipt["trusted_trace_sha256"],
    "qualifier_sha256": receipt["qualifier_sha256"], "contracts": receipt["contracts"],
    "recorded_subprocesses": len(ledger), "case_cli_commands": len(case_commands),
    "total_product_cli_commands": len(product_commands),
    "auxiliary_cli_commands": len(product_commands) - len(case_commands),
    "case_exit_counts": dict(Counter(str(row["exit_code"]) for row in case_commands)),
    "raw_stream_slice_hash_checks": checks,
    "raw_stream_full_hashes": {stream: sha(data) for stream, data in streams.items()},
    "qualification_json_sha256": sha((OUT / "qualification.json").read_bytes()),
    "worker_receipt_sha256": sha((OUT / "receipt.json").read_bytes()),
    "outer_receipt_sha256": sha((CAPTURE / "receipt.json").read_bytes()),
    "ledger_sha256": sha((OUT / "raw/commands.json").read_bytes()),
    "formal_release_collector": False, "published_check_runs": 0,
    "product_reexecuted_by_auditor": False,
    "auditor_command": sys.argv, "auditor_runtime": sys.version,
    "auditor_sha256": sha(Path(__file__).read_bytes()),
    "not_run_by_this_leg": [kind for kind in ("source", "wheel", "pyz") if kind != args.kind]
                          + ["full product suite", "formal release bridge", "published checks", "other OS", "Python 3.12/3.13"],
}
result_bytes = (json.dumps(result, indent=2) + "\n").encode("utf-8")
if (OUT / "independent-readback.json").exists():
    assert (OUT / "independent-readback.json").read_bytes() == result_bytes, "preserve prior result; use a new output for a changed audit"
else:
    (OUT / "independent-readback.json").write_bytes(result_bytes)
print(json.dumps(result, indent=2))
