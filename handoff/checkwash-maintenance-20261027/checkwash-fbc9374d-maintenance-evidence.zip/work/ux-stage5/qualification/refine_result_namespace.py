"""Add the reviewed --result boundary by text only; execute no reader."""
import difflib
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
DERIVATION = HERE / "reader-derivation"
REVISION = DERIVATION / "result-namespace-correction"
REVISION.mkdir(exist_ok=False)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


originals = {}
for name in ("read_full_suite.py", "reader-derivation/derivation.json", "reader-derivation/read_full_suite.py.diff"):
    original = (HERE / name).read_bytes()
    destination = REVISION / name.replace("/", "--")
    destination.write_bytes(original)
    originals[name] = sha(original)
assert originals["read_full_suite.py"] == "5e59cef3225c5a939af13dff5b96242dcec0c867d7e78f085d01e3d26c73d0b1"
text = (HERE / "read_full_suite.py").read_text(encoding="utf-8")
operations = []


def change(old, new, label):
    global text
    assert text.count(old) == 1
    text = text.replace(old, new)
    operations.append({"label": label, "old": old, "new": new, "occurrences": 1})


anchor = '    names = ("receipt.json", "stdout.txt", "stderr.txt", "junit.xml", "input-hashes.json",\n'
change(anchor, '''    destination = (args.result or out / "independent-readback.json").resolve()
    if not destination.is_relative_to(STAGE.resolve()):
        print(json.dumps({"status": "WRONG_RESULT_NAMESPACE", "readback_integrity": "UNVERIFIED",
                          "suite_passed": None, "product_calls": 0}, indent=2))
        return 1
''' + anchor, "validate explicit/default result path in stage5 before any evidence reads")
change('    destination = args.result or out / "independent-readback.json"\n',
       '    # destination was normalized and bounded to stage5 before evidence reads.\n',
       "retain the already validated result path at the write")
(HERE / "read_full_suite.py").write_text(text, encoding="utf-8", newline="\n")
record = json.loads((DERIVATION / "derivation.json").read_text(encoding="utf-8"))
full = next(row for row in record["readers"] if row["reader"] == "read_full_suite.py")
full["transformations"].extend(operations)
full["stage5_sha256"] = sha(text.encode())
reverse = text
for operation in reversed(full["transformations"]):
    assert reverse.count(operation["new"]) == operation["occurrences"]
    reverse = reverse.replace(operation["new"], operation["old"])
baseline = (DERIVATION / "stage4-read_full_suite.py").read_bytes()
assert reverse.encode() == baseline and sha(baseline) == full["reviewed_stage4_sha256"]
patch = "".join(difflib.unified_diff(baseline.decode().splitlines(keepends=True), text.splitlines(keepends=True),
                                   fromfile="stage4/qualification/read_full_suite.py", tofile="stage5/qualification/read_full_suite.py"))
(DERIVATION / "read_full_suite.py.diff").write_text(patch, encoding="utf-8", newline="\n")
full["diff_sha256"] = sha(patch.encode())
record["result_namespace_correction"] = {"review_finding": "--result could otherwise create a new file outside stage5",
                                         "preserved_prior_candidate": originals,
                                         "new_reader_calls": 0, "new_reader_compile_calls": 0}
(DERIVATION / "derivation.json").write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"state": "PREPARED_NOT_EXECUTED_NOT_COMPILED", "read_full_suite_sha256": full["stage5_sha256"],
                  "diff_sha256": full["diff_sha256"], "derivation_sha256": sha((DERIVATION / "derivation.json").read_bytes())}, indent=2))
