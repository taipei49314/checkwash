# Stage5 evidence-reader derivation

State: **PREPARED — NOT EXECUTED / NOT COMPILED / NOT IMPORTED**.
No new qualification or product call was made while preparing these readers.
The authoring programs use standard-library text/hash operations only.

| Reader | Reviewed stage4 raw SHA256 | Final stage5 raw SHA256 |
|---|---|---|
| `read_source_result.py` | `7134c70531052d41cf25b44ae443ff112552988b8684366df93652c3be3845b4` | `f2053f8b42d8721388a1ac74211a7fe2faaa82203f929f037617775ff2f80a9f` |
| `read_full_suite.py` | `0d1e19b2feae9caf916b7f71e1e534448fd34496ce7e11fe5b01ec487006c7af` | `d5c8f45967e262f6322570ac42de6620767eb38c5ce96448c34afe653f66095c` |

The exact LF unified diffs are alongside this file. `derivation.json` records
every literal transformation. Reversing them, in reverse order, restores the
original reviewed bytes exactly. The preserved originals and the superseded
full-reader candidate are history, not sources to execute for stage5.

## Source and evidence binding

The fixed 8a constant is removed from executable stage5 readers. Source identity
comes only from `work/ux-stage5/final-source-sha.txt`, written by root's seal.
The pin must be a lowercase 40- or 64-character hexadecimal Git identity.
The full reader includes the pin in its missing-evidence handling and hashes;
the distribution reader reports an incomplete pin with exit 2. Missing pin,
receipt or native XML cannot establish a PASS.

All default output/capture/seal paths use stage5. Explicit output/capture and
full-reader `--result` paths must remain inside stage5 after resolution.
Artifact paths and loaded-wheel runtime prefixes must belong to stage5, so
the unchanged product package bytes cannot accidentally justify using a
stage4 archive or wheel environment. The complete loaded-package/archive
comparison and all previous SHA, raw-offset, typed-exit, native XML,
parent/subtest, failure-node and source-seal guards remain intact.

The common active checkout at `work/checkwash-ux` and the fixed-1ffe trusted
tracer in `work/trusted` intentionally remain shared, matching root's unchanged
controller interface. They are not stage4 evidence/artifact/runtime reuse.
The fixed trusted inventories remain 283 cases; no final full-suite denominator
or expected failed-test count is hardcoded. Suite exit 1 remains a failed suite,
even when the readback's own exit 0 verifies consistent evidence.

The inherited distribution reader verifies the recorded artifact digest and
package members. It does not rebuild a wheel or derive its dist-info metadata
from README. Fresh stage5 build/metadata evidence remains root's build phase;
this preparation does not certify an unbuilt archive or a new environment.

## Reviewed correction

The first stage5 full-reader candidate (`5e59cef3…d0b1`) bounded `--output` but
left the inherited custom `--result` unconstrained. Independent text review
found that an unused result name could otherwise be created inside frozen
stage4. The final reader validates both output and result before reading
evidence and reuses the validated destination at the write. The original
candidate, derivation record and diff are preserved under
`result-namespace-correction/`. No reader was executed to discover or repair it.

The final independent review rechecked both raw digests, the complete reverse
transform, zero old-source/stage4 references in runtime reader text, and the
unchanged parser/guard sections. Its bounded PASS is static review, not a
native execution or qualification PASS. `independent-review.json` records this
distinction.

## Controllers and run order

`qualify_one.py`, `seal_source.py` and `build_pyz.py` are byte-identical between
stage4 and stage5. `capture_final.py` differs only in `cwf4-` → `cwf5-` temporary
prefix. Their exact hashes are recorded in `derivation.json` and
`hash-catalog.json`; the qualifying worker continues to use the same trusted
1ffe tracer and unchanged inventory contracts.

Root will first seal the new source and run its full suite alone. Only after
that run finishes will the three 283-case distribution qualifications run,
avoiding contention. Reader invocation is deferred until the corresponding
terminal evidence exists. This packet does not create the source pin, start a
run, publish a check, alter stage4, or change product/test/document bytes.
