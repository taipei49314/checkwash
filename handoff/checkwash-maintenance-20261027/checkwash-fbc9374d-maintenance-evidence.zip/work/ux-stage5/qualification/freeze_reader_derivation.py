"""Record exact final reader hashes without executing or parsing reader code."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
DATA = HERE / "reader-derivation"
record = json.loads((DATA / "derivation.json").read_text(encoding="utf-8"))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


catalog = {"state": "PREPARED_NOT_EXECUTED_NOT_COMPILED", "readers": [],
           "controllers": record["controller_derivation"], "new_reader_calls": 0, "product_calls": 0,
           "qualification_calls": 0, "source_pin_present_at_freeze": (ROOT / "work/ux-stage5/final-source-sha.txt").is_file()}
for reader in record["readers"]:
    name = reader["reader"]
    data = (HERE / name).read_bytes()
    assert sha(HERE / name) == reader["stage5_sha256"] and b"\r\n" not in data
    assert b"ux-stage4" not in data and b"8a8941dc2d7c581715a0f6f196c00da6c55f084b" not in data
    reverse = data.decode("utf-8")
    for operation in reversed(reader["transformations"]):
        assert reverse.count(operation["new"]) == operation["occurrences"]
        reverse = reverse.replace(operation["new"], operation["old"])
    assert hashlib.sha256(reverse.encode()).hexdigest() == reader["reviewed_stage4_sha256"]
    assert sha(ROOT / "work/ux-stage4/qualification" / name) == reader["reviewed_stage4_sha256"]
    assert sha(DATA / (name + ".diff")) == reader["diff_sha256"]
    catalog["readers"].append({"reader": name, "base_sha256": reader["reviewed_stage4_sha256"],
                                "final_sha256": reader["stage5_sha256"], "diff_sha256": reader["diff_sha256"]})
catalog["derivation_sha256"] = sha(DATA / "derivation.json")
catalog["independent_review_sha256"] = sha(DATA / "independent-review.json")
(DATA / "hash-catalog.json").write_text(json.dumps(catalog, indent=2) + "\n", encoding="utf-8")
files = [HERE / "read_source_result.py", HERE / "read_full_suite.py", HERE / "derive_readers.py",
         HERE / "refine_result_namespace.py", HERE / "freeze_reader_derivation.py"]
files += [path for path in sorted(DATA.rglob("*")) if path.is_file() and path.name != "MANIFEST.json"]
members = {path.relative_to(HERE).as_posix(): sha(path) for path in files}
manifest = {"state": "FROZEN_PREPARED_READER_DERIVATION_NOT_EXECUTED",
            "members": members, "stage4_original_reader_bytes_unchanged": True,
            "product_or_new_reader_calls": 0, "new_reader_compile_or_import_calls": 0}
destination = DATA / "MANIFEST.json"
assert not destination.exists()
destination.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"readers": catalog["readers"], "hash_catalog_sha256": sha(DATA / "hash-catalog.json"),
                  "manifest_sha256": sha(destination), "members": len(members)}, indent=2))
