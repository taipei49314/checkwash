# Prepared follow-up index producer

Status: **PREPARED_NOT_EXECUTED**. This preparation has not run the producer,
imported/compiled its source, packed an archive, called the product, or published
anything. Root owns the eventual plan, output write, pack and remote checkpoint.

The source is `fbc9374dc3bcbfc47f403aec0c36e6b51dd7b86c` (0.10.0 / IR3 /
findings2). This index is a backup only; 1.0 requires Nelson's decision. The
older8a five archives, source qualifications and 22 failed tests remain historical
evidence at remote `d158ec02aac9c0c19751d0475f935b533e3d03f7` and are not copied
or substituted for fbc evidence.

`prepare_followup_outputs.py` is a standard-library metadata producer. It has no
subprocess, network, product import, test call, Git call or automatic pack/push.
It reads only explicit stage5 pin/seal/equivalence, completed outer captures,
matching independent readbacks if present, the preserved self-dogfood memo and
the pack receipt when terminal mode is explicitly requested. Live suite streams
and qualification ledgers are not sampled for this small checkpoint.

The output path is fixed:
`outputs/checkwash-maintenance-followup-20261027/`. Every read/output component
is checked with lstat before access; symlinks and Windows reparse points are
refused. All copied files are bounded and stable during read. Existing completed
copies cannot be changed. Replaced START/checkpoint/MANIFEST indexes are kept
verbatim under `index-history/`; earlier stage4 evidence is never touched.

Run a local plan after reviewing the prepared source (commands shown here have
not been executed by this preparation):

    work/test-runtime/Scripts/python.exe -I -B -X utf8 work/ux-stage5/prepare_followup_outputs.py

The default prints metadata and makes no writes. To materialize a partial
checkpoint, root can explicitly use:

    work/test-runtime/Scripts/python.exe -I -B -X utf8 work/ux-stage5/prepare_followup_outputs.py --write

The optional `--include-source-archive` includes only the exact sealed
`source-fbc9374d.zip` and its matching sidecar. A source ZIP contains bytes,
not the Git history needed to replay range comparisons. Partial mode rejects
an already present final evidence ZIP rather than deleting or hiding it.

The four roles are `qualification_source`, `qualification_wheel`,
`qualification_pyz` and `full_suite`. A valid completed native outer capture
provides the actual integer exit, source/ending pin, unchanged flag, empty
changed-input list and terminal interval. Missing folders are NOT_STARTED.
An existing attempt directory without a terminal receipt is RUNNING with the
explicit caveat that directory presence does not establish a live process.
An explicit `--not-run ROLE=reason` is allowed only where no attempt files exist.
No receipt or exit is invented for NOT_RUN/unfinished roles.

The completed self-dogfood result is preserved as **BLOCK / exit1, 3high/9warn**.
It makes this source's acceptance_state NONPASS irrespective of later qualifier
outcomes or backup completion. A full-suite exit1 stays failed/nonpass; an audit
exit0 establishes only evidence consistency. The exact raw self-dogfood bytes,
fingerprints, before/after assertions and 1ffe→fbc comparison are copied. Its
small raw source/diff filenames receive an added `.txt` suffix for publisher
transport; RAW-EXPORT-MAP.json retains original paths and byte hashes.

After all validation jobs have an actual terminal capture or an explicitly
justified NOT_RUN, root can review/author the packer's separate terminal-state
JSON and explicitly run the reviewed packer. This producer never synthesizes
`root_confirmed_pack:true`. When `checkpoint-pack/pack-receipt.json`, the final
ZIP and sidecar exist and match the four current role receipts, prepare terminal
metadata with:

    work/test-runtime/Scripts/python.exe -I -B -X utf8 work/ux-stage5/prepare_followup_outputs.py --backup-state TERMINAL_BACKUP
    work/test-runtime/Scripts/python.exe -I -B -X utf8 work/ux-stage5/prepare_followup_outputs.py --backup-state TERMINAL_BACKUP --write

Complete bundle metadata is not possible while any role is pending. Terminal
mode binds the pack receipt, ZIP digest/size, sidecar and archived terminal map
to those exact current receipts/exits. The publisher independently checks all
archive member hashes and the current sealed source/index before any remote
Git write. TERMINAL_BACKUP means the backup is complete; failed tests or NOT_RUN
remain visible and do not become acceptance.

Finally root reviews the exact payload and uses the separate publisher's
plan/digest-bound publish procedure in checkpoint-pack/PUBLISHER.md. No product
branch, main, tag, release or advertised pin is updated by the backup index.
The old baseline entry can receive only the separately reviewed follow-up banner.

All execution evidence remains `HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL` with
actual host/runtime/source. This producer grants no unexecuted platform/runtime,
formal release-bridge or published-check coverage and does not add exemptions.
