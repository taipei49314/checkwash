"""Prepare a backup-only index from completed stage5 evidence, without product calls.

Default mode prints a plan. --write creates/refreshes only the fixed follow-up
payload. It never packs, imports the product, invokes Git, or publishes anything.
Root must separately review/run the packer and publisher.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[2]
STAGE = ROOT / "work/ux-stage5"
OUT = ROOT / "outputs/checkwash-maintenance-followup-20261027"
SOURCE = "fbc9374dc3bcbfc47f403aec0c36e6b51dd7b86c"
BASE = "1ffe283d7d947fecc426dea99323b0a2620a9482"
LEGACY = "d158ec02aac9c0c19751d0475f935b533e3d03f7"
PURPOSE = "BACKUP_ONLY_NOT_ACCEPTANCE_NOT_RELEASE"
BUNDLE = "checkwash-fbc9374d-maintenance-evidence.zip"
SOURCE_ZIP = "source-fbc9374d.zip"
ROLES = {"qualification_source": "source-assertion-qualification-r1",
         "qualification_wheel": "wheel-assertion-qualification-r1",
         "qualification_pyz": "pyz-assertion-qualification-r1",
         "full_suite": "full-suite-311-r1"}
ALLOWED = {".json", ".md", ".txt", ".patch", ".sha256", ".zip"}
MUTABLE = {"00-START-HERE.md", "checkpoint.json", "MANIFEST.json"}
MAX_SMALL = 32 * 1024 * 1024


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def encoded(value):
    return (json.dumps(value, indent=2, ensure_ascii=False, sort_keys=True) + "\n").encode("utf-8")


def logical(name):
    require(isinstance(name, str) and bool(name) and "\\" not in name and ":" not in name,
            "not a portable relative payload name")
    p = PurePosixPath(name)
    require(not p.is_absolute() and all(x not in {"", ".", ".."} for x in p.parts)
            and p.as_posix() == name, "unsafe payload path")
    require(not any(x.lower() in {".git", "__pycache__", "site-packages", "node_modules", ".venv", "venv"}
                    for x in p.parts), "runtime directory is not backup metadata")
    require(p.suffix in ALLOWED, "unsupported payload extension: " + name)
    require(p.suffix != ".zip" or name in {BUNDLE, SOURCE_ZIP}, "unexpected ZIP path")
    return name


def ordinary(path, missing=False):
    """Check every lexical component before any read; never follow a reparse point."""
    path = Path(os.path.abspath(path))
    require(path.is_relative_to(ROOT), "path is outside this task")
    current = ROOT
    for part in (None,) + path.relative_to(ROOT).parts:
        if part is not None:
            current /= part
        try:
            info = current.lstat()
        except FileNotFoundError:
            if missing:
                return None
            raise
        require(not stat.S_ISLNK(info.st_mode) and not getattr(info, "st_file_attributes", 0) & 1024,
                "symlink/reparse path refused: " + str(current))
        require(stat.S_ISDIR(info.st_mode) if current != path else
                stat.S_ISDIR(info.st_mode) or stat.S_ISREG(info.st_mode), "nonregular path")
    return info


def read(path, limit=MAX_SMALL):
    before = ordinary(path)
    require(stat.S_ISREG(before.st_mode) and before.st_size <= limit, "not a bounded regular input")
    raw = path.read_bytes()
    after = ordinary(path)
    require((before.st_size, before.st_mtime_ns, before.st_ino) ==
            (after.st_size, after.st_mtime_ns, after.st_ino) and len(raw) == before.st_size,
            "input changed while reading: " + str(path))
    return raw


def obj(path):
    raw = read(path)
    value = json.loads(raw)
    require(isinstance(value, dict), "JSON object required: " + str(path))
    return value, raw


def terminal(receipt):
    require(receipt.get("expected_source_sha") == receipt.get("source_sha") == receipt.get("ending_sha") == SOURCE,
            "fixed-source receipt does not bind fbc")
    require(receipt.get("source_files_unchanged") is True and receipt.get("changed_inputs") == [],
            "terminal source/input changes")
    require(receipt.get("validation_kind") == "FIXED_SOURCE_NOT_RELEASE_BRIDGE", "not a fixed-source capture")
    require(type(receipt.get("exit_code")) is int, "actual terminal exit must be an integer")
    start = datetime.fromisoformat(receipt["started_utc"])
    end = datetime.fromisoformat(receipt["ended_utc"])
    require(start.tzinfo is not None and end.tzinfo is not None and end >= start,
            "missing/invalid terminal interval")


def inspect_text(raw):
    # This fixed allowlist is metadata, not a general privacy certification.
    for pattern in (rb"(?:gh[pousr]_)[A-Za-z0-9_]{30,}", rb"github_pat_[A-Za-z0-9_]{30,}",
                    rb"https?://[^\s/]+:[^\s/@]+@", rb"-----BEGIN [A-Z ]*PRIVATE KEY-----"):
        require(re.search(pattern, raw) is None, "credential-shaped bytes in metadata; review locally")


def collect(args):
    files = {}
    inputs = {}

    def add(name, raw):
        logical(name)
        require(len(raw) < 90_000_000, "payload blob exceeds backup bound")
        if not name.endswith(".zip"):
            inspect_text(raw)
        require(name not in files or files[name] == raw, "conflicting payload member")
        files[name] = raw

    def copy(path, name):
        raw = read(path)
        inputs[path.relative_to(ROOT).as_posix()] = sha(raw)
        add(name, raw)
        return raw

    require(read(STAGE / "final-source-sha.txt").decode("utf-8").strip() == SOURCE, "wrong stage5 pin")
    seal, seal_raw = obj(STAGE / "seal/source-seal.json")
    require(seal.get("source_sha") == SOURCE and seal.get("all_tracked_bytes_match_git") is True,
            "wrong/unverified source seal")
    equivalent, _ = obj(STAGE / "source-content-equivalence.json")
    require(equivalent.get("new_source_sha") == SOURCE, "wrong source equivalence")
    copy(STAGE / "seal/source-seal.json", "completed/source-seal.json")
    copy(STAGE / "source-content-equivalence.json", "completed/source-content-equivalence.json")
    copy(STAGE / "controller-copy-record.json", "completed/controller-copy-record.json")

    memo_dir = STAGE / "selfdogfood-review"
    memo, memo_raw = obj(memo_dir / "review.json")
    dog, dog_raw = obj(memo_dir / "native-capture-receipt.json")
    terminal(dog)
    require(memo.get("source_sha") == SOURCE and memo.get("base_sha") == BASE
            and memo.get("native_receipt_sha256") == sha(dog_raw)
            and memo.get("exit_code") == dog["exit_code"], "selfdog memo/capture mismatch")
    native = copy(memo_dir / "candidate-selfdogfood.raw.json", "completed/selfdogfood/candidate-selfdogfood.raw.json")
    require(sha(native) == memo["native_json_sha256"], "selfdog native JSON changed")
    for name in ("README.md", "review.json", "native-capture-receipt.json", "native-stderr.txt"):
        copy(memo_dir / name, "completed/selfdogfood/" + name)
    # Preserve exact raw bytes using publisher-safe .txt names plus an explicit map.
    raw_map = []
    ordinary(memo_dir / "raw")
    for path in sorted((memo_dir / "raw").iterdir()):
        ordinary(path)
        require(path.is_file(), "unexpected selfdog raw directory")
        target = "completed/selfdogfood/raw/" + path.name + ".txt"
        raw = copy(path, target)
        raw_map.append({"original_path": "raw/" + path.name, "payload_path": target,
                        "bytes": len(raw), "sha256": sha(raw)})
    add("completed/selfdogfood/RAW-EXPORT-MAP.json", encoded(raw_map))

    for label in ("build-artifacts-r1", "build-pyz-r1", "wheel-runtime-create-r1", "wheel-runtime-install-r1"):
        path = STAGE / "final" / label / "receipt.json"
        if ordinary(path, missing=True) is not None:
            receipt, raw = obj(path)
            terminal(receipt)
            copy(path, "completed/preparation/" + label + ".json")

    omitted = {}
    for pair in args.not_run:
        role, sep, reason = pair.partition("=")
        require(sep and role in ROLES and reason.strip() and role not in omitted, "invalid --not-run ROLE=reason")
        omitted[role] = reason.strip()
    roles = {}
    originals = {}
    for role, label in ROLES.items():
        folder = STAGE / "final" / label
        receipt_path = folder / "receipt.json"
        present = ordinary(folder, missing=True) is not None
        if role in omitted:
            require(not present or not list(folder.iterdir()), "cannot hide existing attempt evidence with NOT_RUN")
            roles[role] = {"state": "NOT_RUN", "reason": omitted[role]}
            continue
        if ordinary(receipt_path, missing=True) is None:
            roles[role] = {"state": "RUNNING" if present else "NOT_STARTED",
                           "detail": "terminal_missing; directory presence does not prove a live process" if present
                           else "No stage5 attempt directory or terminal receipt at index capture time"}
            continue
        receipt, raw = obj(receipt_path)
        terminal(receipt)
        require(receipt.get("label") == label, "terminal capture label mismatch")
        target = "completed/validation/" + role + "/receipt.json"
        copy(receipt_path, target)
        row = {"state": "TERMINAL", "receipt": target, "sha256": sha(raw), "exit_code": receipt["exit_code"]}
        originals[role] = receipt_path.relative_to(ROOT).as_posix()
        if role == "full_suite":
            audit_path = folder / "independent-readback.json"
        else:
            kind = role.removeprefix("qualification_")
            audit_path = STAGE / "qualification" / (kind + "-r1") / "independent-readback.json"
        if ordinary(audit_path, missing=True) is not None:
            audit, audit_raw = obj(audit_path)
            require(audit.get("source_sha") == SOURCE, "audit source mismatch")
            if role == "full_suite":
                require(audit.get("file_sha256", {}).get("receipt.json") == sha(raw)
                        and audit.get("suite_exit_code") == receipt["exit_code"], "full audit/capture mismatch")
                # An inconsistent readback may be preserved, but never becomes verification.
                audit_state = audit.get("readback_integrity", "UNVERIFIED")
            else:
                require(audit.get("outer_receipt_sha256") == sha(raw)
                        and audit.get("exit_code") == receipt["exit_code"], "qualification audit/capture mismatch")
                audit_state = "READBACK_RECORDED"
            audit_target = "completed/validation/" + role + "/independent-readback.json"
            copy(audit_path, audit_target)
            row["audit"] = {"state": audit_state, "path": audit_target, "sha256": sha(audit_raw)}
        else:
            row["audit"] = {"state": "NOT_PRESENT", "detail": "Raw terminal capture is not an independent consistency audit"}
        roles[role] = row

    all_terminal = all(row["state"] in {"TERMINAL", "NOT_RUN"} for row in roles.values())
    bundle = {"state": "NOT_READY", "filename": BUNDLE}
    if args.backup_state == "PARTIAL_CHECKPOINT":
        require(ordinary(OUT / BUNDLE, missing=True) is None, "complete ZIP exists; select TERMINAL_BACKUP after review")
    else:
        require(all_terminal, "terminal backup needs all four terminal/NOT_RUN roles")
        packed, _ = obj(STAGE / "checkpoint-pack/pack-receipt.json")
        require(packed.get("source_sha") == SOURCE and packed.get("archive") == BUNDLE
                and packed.get("source_and_inputs_unchanged") is True and packed.get("publication_performed") is False,
                "pack receipt is not a completed unchanged fbc backup")
        pvalidation = packed["validation"]
        require(pvalidation.get("source_sha") == SOURCE and pvalidation.get("all_active_jobs_terminal") is True,
                "pack validation is not terminal fbc")
        prows = pvalidation["roles"]
        require(isinstance(prows, list) and len(prows) == len(ROLES)
                and {r["role"] for r in prows} == set(ROLES), "pack roles mismatch")
        for item in prows:
            role = item["role"]
            row = roles[role]
            require(item["state"] == row["state"], "pack/current role state mismatch")
            if row["state"] == "TERMINAL":
                require(item.get("receipt") == originals[role] and item.get("sha256") == row["sha256"]
                        and type(item.get("exit_code")) is int and item["exit_code"] == row["exit_code"],
                        "pack/current receipt or actual exit mismatch")
            else:
                require(item.get("reason") == row["reason"], "pack/current NOT_RUN reason mismatch")
        archive = read(OUT / BUNDLE, 90_000_000)
        require(type(packed.get("bytes")) is int and packed["bytes"] == len(archive)
                and packed.get("sha256") == sha(archive), "complete bundle bytes/hash mismatch")
        sidecar = read(OUT / (BUNDLE + ".sha256"))
        fields = sidecar.decode("ascii").split()
        require(len(fields) == 2 and fields[0] == sha(archive) and fields[1].lstrip("*") == BUNDLE,
                "complete bundle sidecar mismatch")
        # Publisher independently validates every archived member; here bind the terminal role map too.
        with zipfile.ZipFile(io.BytesIO(archive)) as z:
            name = "VALIDATION-TERMINAL-STATE.json"
            require(z.namelist().count(name) == 1 and z.getinfo(name).file_size <= MAX_SMALL,
                    "missing/duplicate/oversized ZIP terminal metadata")
            inside = json.loads(z.read(name))
            require(inside == pvalidation, "ZIP/pack receipt terminal metadata mismatch")
        add(BUNDLE, archive)
        add(BUNDLE + ".sha256", sidecar)
        copy(STAGE / "checkpoint-pack/pack-receipt.json", "completed/pack-receipt.json")
        bundle.update(state="COMPLETE", sha256=sha(archive), bytes=len(archive))
    if args.include_source_archive or ordinary(OUT / SOURCE_ZIP, missing=True) is not None:
        raw = read(STAGE / "seal" / SOURCE_ZIP, 90_000_000)
        require(sha(raw) == seal["archive_sha256"], "sealed source archive mismatch")
        add(SOURCE_ZIP, raw)
        add(SOURCE_ZIP + ".sha256", (sha(raw) + "  " + SOURCE_ZIP + "\n").encode("ascii"))

    previous_path = OUT / "checkpoint.json"
    if ordinary(previous_path, missing=True) is not None:
        previous, _ = obj(previous_path)
        require(previous.get("source_sha") == SOURCE, "refuse overwrite of another source checkpoint")
        require(not (previous.get("backup_state") == "TERMINAL_BACKUP" and args.backup_state != "TERMINAL_BACKUP"),
                "refuse terminal-to-partial downgrade")
        for role, before in previous.get("validation", {}).get("roles", {}).items():
            if before.get("state") == "TERMINAL":
                now = roles[role]
                require(now["state"] == "TERMINAL" and all(now.get(k) == before.get(k) for k in ("sha256", "exit_code")),
                        "terminal r1 evidence is immutable; preserve failed or completed receipts")
    nonpass = dog["exit_code"] != 0 or any(row.get("exit_code", 0) != 0 for row in roles.values())
    checkpoint = {"source_sha": SOURCE, "code_source_sha": SOURCE, "version": "0.10.0", "ir_version": 3,
                  "findings_version": 2, "backup_state": args.backup_state, "purpose": PURPOSE,
                  "acceptance_state": "NONPASS" if nonpass else "NOT_ACCEPTED" if all_terminal else "OPEN",
                  "product_publication_performed": False, "version_1_0_requires_human_decision": True,
                  "validation": {"all_active_jobs_terminal": all_terminal, "roles": roles}, "bundle": bundle,
                  "selfdogfood": {"state": memo["state"], "exit_code": dog["exit_code"], "summary": memo["summary"],
                                  "receipt": "completed/selfdogfood/native-capture-receipt.json", "sha256": sha(dog_raw)},
                  "baseline_only": {"commit": LEGACY, "old_source_sha": equivalent["old_source_sha"],
                                    "not_current_validation": True},
                  "created_utc": datetime.now(timezone.utc).isoformat(),
                  "provenance": "HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL",
                  "producer_product_calls": 0, "producer_git_calls": 0, "source_guard_delegated_to_publisher": True}
    add("checkpoint.json", encoded(checkpoint))
    rows = "\n".join("| " + role + " | " + row["state"] + " | " + str(row.get("exit_code", "not terminal")) + " |"
                     for role, row in roles.items())
    entry = f"""# CheckWash maintenance follow-up: backup only

Source / code source: `{SOURCE}`. Candidate version **0.10.0**, IR3 / findings2.
`backup_state={args.backup_state}`; purpose `{PURPOSE}`.
Acceptance state: **{checkpoint['acceptance_state']}**. No product publication was performed.
Version 1.0 requires Nelson's explicit decision.

The ordinary `{BASE}` → fbc self-check remains **BLOCK / exit {dog['exit_code']}**,
with critical {memo['summary']['critical']}, high {memo['summary']['high']}, warn {memo['summary']['warn']}.
The original findings, exact fingerprints and source comparison are retained under
[completed/selfdogfood/](completed/selfdogfood/README.md). Raw filenames acquire `.txt`
only for safe backup transport; RAW-EXPORT-MAP.json records their original names/hashes.
No waiver, exemption, expected-label change or gate override is added by this backup.

| Validation role | Actual captured state | Actual exit |
|---|---|---|
{rows}

Only completed stage5 outer receipts supply terminal exits. A missing terminal receipt
is not PASS, and a directory does not prove a process is still live. Independent audit
exit 0 means evidence consistency only: a full-suite exit 1 remains NONPASS permanently.
The index does not predict test counts or borrow old8a qualification results.
Bundle state: **{bundle['state']}**. {'The complete evidence ZIP is included; terminal backup completion still does not mean acceptance.' if bundle['state'] == 'COMPLETE' else 'No final evidence ZIP is included or claimed complete; this is a partial checkpoint.'}
See [checkpoint.json](checkpoint.json) and [MANIFEST.json](MANIFEST.json) for exact copied bytes.

The frozen8a backup, its five archives and 22 failing tests are a **historical baseline**
at [d158 legacy entry](https://github.com/taipei49314/checkwash/blob/{LEGACY}/handoff/checkwash-core-010-20261027/00-START-HERE.md).
Those archives/results are not current fbc validation and are not recopied here.
Restore the fbc Git source and its required history before continuing; an optional
sealed source ZIP preserves bytes, not Git objects. Do not rewrite the earlier backup.

All recorded local execution identifies the actual PJU host/runtime and is marked
`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`. This backup does not establish other OS,
unexecuted runtimes, formal release-bridge or published-check coverage. Preserve
all failures, #567/#568 decisions and publication boundaries. Do not run subjects,
paid/model/history batches or change host-global settings to complete this handoff.
"""
    add("00-START-HERE.md", entry.encode("utf-8"))
    return files, inputs, checkpoint


def inventory():
    existing = {}
    if ordinary(OUT, missing=True) is None:
        return existing
    def visit(folder):
        for path in sorted(folder.iterdir()):
            info = ordinary(path)
            if stat.S_ISDIR(info.st_mode):
                visit(path)
            else:
                name = logical(path.relative_to(OUT).as_posix())
                existing[name] = read(path, 90_000_000)
    visit(OUT)
    return existing


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--backup-state", choices=("PARTIAL_CHECKPOINT", "TERMINAL_BACKUP"), default="PARTIAL_CHECKPOINT")
    parser.add_argument("--not-run", action="append", default=[], metavar="ROLE=reason")
    parser.add_argument("--include-source-archive", action="store_true")
    parser.add_argument("--write", action="store_true")
    args = parser.parse_args()
    files, inputs, checkpoint = collect(args)
    existing = inventory()
    # Old index revisions are retained verbatim. Completed raw copies cannot be replaced.
    history = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
    for name, raw in existing.items():
        if name in MUTABLE:
            if name not in files or files[name] != raw:
                files["index-history/" + history + "/" + name] = raw
        elif name in files:
            require(files[name] == raw, "refuse changed completed payload bytes: " + name)
        else:
            require(name.startswith("index-history/"), "unexpected existing payload member: " + name)
            files[name] = raw
    require(len({name.casefold() for name in files}) == len(files), "casefold payload collision")
    require(sum(len(raw) for raw in files.values()) <= 512 * 1024 * 1024, "payload exceeds512MiB")
    members = [{"path": name, "bytes": len(raw), "sha256": sha(raw)} for name, raw in sorted(files.items())]
    manifest = {"source_sha": SOURCE, "code_source_sha": SOURCE, "purpose": PURPOSE,
                "backup_state": args.backup_state, "files": members,
                "manifest_excludes_itself": True, "completed_input_hashes": inputs,
                "producer_sha256": sha(read(Path(__file__))), "product_calls": 0, "git_calls": 0}
    files["MANIFEST.json"] = encoded(manifest)
    # Reread only the completed inputs actually exported; do not sample live streams.
    for name, digest in inputs.items():
        require(sha(read(ROOT / name)) == digest, "completed input changed before index write")
    if args.write:
        ordinary(OUT, missing=True)
        OUT.mkdir(parents=True, exist_ok=True)
        for name, raw in sorted(files.items(), key=lambda item: (item[0] == "MANIFEST.json", item[0])):
            target = OUT / name
            ordinary(target, missing=True)
            target.parent.mkdir(parents=True, exist_ok=True)
            if target.exists() and read(target, 90_000_000) == raw:
                continue
            temp = target.with_name(target.name + ".pending")
            require(ordinary(temp, missing=True) is None, "pending write exists; preserve and investigate")
            with temp.open("xb") as handle:
                handle.write(raw)
            os.replace(temp, target)
    print(json.dumps({"mode": "WROTE_BACKUP_INDEX" if args.write else "PLAN_ONLY_NO_WRITES",
                      "source_sha": SOURCE, "backup_state": args.backup_state, "purpose": PURPOSE,
                      "acceptance_state": checkpoint["acceptance_state"], "validation": checkpoint["validation"],
                      "bundle": checkpoint["bundle"], "files": len(files),
                      "bytes": sum(map(len, files.values())), "manifest_sha256": sha(files["MANIFEST.json"]),
                      "output": str(OUT), "product_calls": 0, "git_calls": 0}, indent=2))


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, KeyError, TypeError, zipfile.BadZipFile) as error:
        print(json.dumps({"state": "INDEX_NOT_PREPARED", "error": type(error).__name__ + ": " + str(error),
                          "product_calls": 0, "git_calls": 0}, indent=2))
        raise SystemExit(1)
