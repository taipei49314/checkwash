"""Preserve completed self-dogfood JSON and static Git comparisons only."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys

STAGE = Path(__file__).resolve().parent
SESSION = STAGE.parents[1]
REPO = SESSION / "work/checkwash-ux"
SOURCE = "fbc9374dc3bcbfc47f403aec0c36e6b51dd7b86c"
BASE = "1ffe283d7d947fecc426dea99323b0a2620a9482"
OLDER = "8a8941dc2d7c581715a0f6f196c00da6c55f084b"
NATIVE = STAGE / "final/candidate-selfdogfood-r1"
OUT = STAGE / "selfdogfood-review"
OUT.mkdir(exist_ok=False)
(OUT / "raw").mkdir()


def sha(data):
    return hashlib.sha256(data).hexdigest()


raw = (NATIVE / "stdout.txt").read_bytes()
payload = json.loads(raw)
receipt_raw = (NATIVE / "receipt.json").read_bytes()
receipt = json.loads(receipt_raw)
assert receipt["source_sha"] == receipt["ending_sha"] == receipt["expected_source_sha"] == SOURCE
assert receipt["source_files_unchanged"] is True and receipt["changed_inputs"] == [] and receipt["exit_code"] == 1
assert payload["verdict"] == "block" and payload["summary"] == {"critical": 0, "high": 3, "warn": 9, "info": 0}
assert payload["config_errors"] == payload["skipped_files"] == []
assert payload["run"]["base"] == BASE[:8] and payload["run"]["head"] == SOURCE[:8]
high = [row for row in payload["findings"] if row["severity"] == "high"]
assert len(high) == 3 and all(row["allowlisted"] is False for row in high)
(OUT / "candidate-selfdogfood.raw.json").write_bytes(raw)
(OUT / "native-capture-receipt.json").write_bytes(receipt_raw)
(OUT / "native-stderr.txt").write_bytes((NATIVE / "stderr.txt").read_bytes())
commands = []
blobs = {}
for path in sorted({row["path"] for row in high}):
    blobs[path] = {}
    for label, revision in (("base", BASE), ("candidate", SOURCE), ("prior8a", OLDER)):
        command = ["git", "--no-optional-locks", "-C", str(REPO), "show", revision + ":" + path]
        started = datetime.now(timezone.utc).isoformat()
        process = subprocess.run(command, capture_output=True, timeout=60)
        assert process.returncode == 0
        name = Path(path).stem + "-" + label
        for stream in ("stdout", "stderr"):
            (OUT / "raw" / (name + "." + stream)).write_bytes(getattr(process, stream))
        blobs[path][label] = sha(process.stdout)
        commands.append({"command": command, "started_utc": started, "ended_utc": datetime.now(timezone.utc).isoformat(),
                         "exit_code": process.returncode, "stdout_sha256": sha(process.stdout), "stderr_sha256": sha(process.stderr)})
    command = ["git", "--no-optional-locks", "-C", str(REPO), "diff", "--no-ext-diff", BASE, SOURCE, "--", path]
    process = subprocess.run(command, capture_output=True, timeout=60)
    assert process.returncode == 0
    name = Path(path).stem + "-1ffe-to-fbc.diff"
    (OUT / "raw" / name).write_bytes(process.stdout)
    (OUT / "raw" / (name + ".stderr")).write_bytes(process.stderr)
    commands.append({"command": command, "exit_code": process.returncode,
                     "stdout_sha256": sha(process.stdout), "stderr_sha256": sha(process.stderr)})
    assert sha((REPO / path).read_bytes()) == blobs[path]["candidate"]
issue266 = "tests/test_issue266_survivor_conftest_chain.py"
assert blobs[issue266]["candidate"] == blobs[issue266]["prior8a"]
review = {"source_sha": SOURCE, "base_sha": BASE, "comparison_scope": "ordinary PR self-check; not release bridge",
          "provenance": receipt["provenance"], "host": receipt["host"], "runtime": receipt["python"],
          "state": "BLOCK_NONPASS_PRESERVED", "exit_code": 1, "summary": payload["summary"],
          "config_errors": [], "skipped_files": [], "high_findings_exact": high,
          "native_json_sha256": sha(raw), "native_receipt_sha256": sha(receipt_raw),
          "native_stderr_sha256": sha((NATIVE / "stderr.txt").read_bytes()), "test_blobs_sha256": blobs,
          "issue266_candidate_equals_prior8a": True, "read_only_git_commands": commands,
          "exemptions_added": False, "judgment_changed": False, "product_calls": 0,
          "memo_is_not_acceptance_or_a_fingerprint_waiver": True}
(OUT / "review.json").write_text(json.dumps(review, indent=2) + "\n", encoding="utf-8")
rows = "\n".join("| `" + row["rule"] + "` | `" + row["path"] + "` / `" + row["unit"] + "` | `"
                 + row["fingerprint"] + "` |" for row in high)
text = f'''# fbc ordinary self-dogfood: three high findings remain BLOCK

Fixed comparison: `{BASE}` → `{SOURCE}`. Native source/version is
`checkwash 0.10.0`; actual date comes from the retained stderr command record.
Host {receipt["host"]}; `HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`.

The completed original JSON reports **BLOCK / exit 1**, critical 0, high 3,
warn 9, info 0; config_errors and skipped_files are empty. This is ordinary
PR self-dogfood, not release acceptance, a release bridge, or a published check.
`candidate-selfdogfood.raw.json` and `native-capture-receipt.json` are byte-for-byte
copies. Their hashes and complete finding objects are in `review.json`.

| Rule | Path / unit | Exact original fingerprint |
|---|---|---|
{rows}

The new classic finding aligns the old `assert preserved.after == original.side`
with `assert len(native_fields) == 17`. Its native message is
`EXACT_VALUE(90) -> TYPE_SHAPE(50)`, drop 40, subject_changed=true, escalator
PROD_CHANGE_NOT_EVIDENCE. The actual fbc test also separately compares all 17
native fields exactly and checks IR3 context/map enrichment. That source
maintenance explains the review context; it does not erase the detector's
alignment, lower the finding or constitute a semantic exemption.

The two issue266 findings are the old disappeared unit names after the
reviewed D179 ordinary-contract migrations to unknown/changed-startup or
missing-strict-context expectations. This file's fbc bytes equal its prior8a
bytes. The native findings remain unallowlisted TEST_DISABLED/high; no
ASSERTION_MOVED/RESTRUCTURED waiver or new ledger entry is supplied here.

`raw/` contains exact 1ffe/fbc/prior8a test blobs and the two 1ffe→fbc diffs.
The long finding dictionaries, original before/after spans/text and strength
metadata are retained unchanged in JSON; this memo does not substitute a
guessed complete vector. No product/fixture/test was reexecuted, no source
or expected label was edited, and no exemption or judgment was changed.

This BLOCK stays NONPASS in follow-up backup metadata, regardless of later
distribution qualification results or whether evidence packaging completes.
Backup completion is not acceptance; version 1.0 still requires Nelson's
explicit decision.
'''
(OUT / "README.md").write_text(text, encoding="utf-8", newline="\n")
members = {path.relative_to(OUT).as_posix(): sha(path.read_bytes()) for path in sorted(OUT.rglob("*")) if path.is_file()}
(OUT / "MANIFEST.json").write_text(json.dumps({"state": "FROZEN_SELF_DOGFOOD_NONPASS_MEMO", "source_sha": SOURCE,
                                              "members": members}, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"source_sha": SOURCE, "exit_code": 1, "high": 3, "warn": 9,
                  "memo_sha256": sha((OUT / "README.md").read_bytes()), "review_sha256": sha((OUT / "review.json").read_bytes()),
                  "manifest_sha256": sha((OUT / "MANIFEST.json").read_bytes())}, indent=2))
