"""Read only named installed distribution metadata for restoring task runtimes."""
import argparse
from datetime import datetime, timezone
import importlib.metadata
import json
from pathlib import Path
import platform
import sys

p = argparse.ArgumentParser()
p.add_argument("--output", type=Path, required=True)
p.add_argument("packages", nargs="+")
a = p.parse_args()
here = Path(__file__).resolve().parent
assert a.output.absolute().resolve().is_relative_to(here)
assert not a.output.exists()
record = {"kind": "READ_ONLY_RUNTIME_DISTRIBUTION_METADATA", "host": platform.node(),
          "provenance": "HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL", "python": sys.version,
          "executable": sys.executable, "prefix": sys.prefix, "base_prefix": sys.base_prefix,
          "captured_utc": datetime.now(timezone.utc).isoformat(),
          "versions": {name: importlib.metadata.version(name) for name in a.packages},
          "product_imports": 0, "tests": 0}
a.output.write_text(json.dumps(record, indent=2), encoding="utf-8")
print(json.dumps(record, indent=2))
