"""Adopt reviewed ordinary maintenance only after the complete 8a backup."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

here = Path(__file__).resolve().parent
prior = here.parent / "ux-stage4"
repo = here.parent / "checkwash-ux"
base = "8a8941dc2d7c581715a0f6f196c00da6c55f084b"
backup = json.loads((here / "backup-audit/remote-d158-readback.json").read_bytes())
assert backup["all_matched"] and backup["source_sha"] == base and backup["file_count"] == 47

def git(*args):
    return subprocess.run(["git", *args], cwd=repo, capture_output=True, check=True).stdout

assert git("rev-parse", "HEAD").decode().strip() == base
assert not git("status", "--porcelain", "--untracked-files=all")
patches = {
    "proposals/docs-public-pin/docs-public-pin.patch": "f34fe192d900fff22881ffc42d0dbcdba8afe20a2536a79263be40e32d3570ab",
    "proposals/ordinary-consumers/01-ir3-native-side-enrichment.patch": "cf2efa98171813e7e112e68e9a1a0ef157c5ae733c560785d08bf94c55c88bfc",
    "proposals/ordinary-consumers/02-startup-probe-observers.patch": "f804b8c67ced5fc8f3f72664ddee3431a193a9ce57a20c5ac6392ca6dabaaed8",
    "proposals/ordinary-consumers/03-ci-test-same-producer.patch": "edd8a3bd32c87fd722cac81955a3ac573a4303a0631663ff67220dc9f4102d63",
}
for name, expected in patches.items():
    assert hashlib.sha256((here / name).read_bytes()).hexdigest() == expected
argv = [str(here / name) for name in patches]
git("apply", "--check", *argv)
git("apply", *argv)
allowed = {"STATE.md", "tests/test_packaging.py", "tests/test_classic_raises_additions.py",
           "tests/test_root_oracles.py", "tests/test_issue223_conftest_request_side.py", "tests/test_js_test_obligations.py"}
changed = set(git("diff", "--name-only").decode().splitlines())
assert changed == allowed, changed
assert not git("diff", base, "--", "src", "pyproject.toml", "tests/cases", "tests/gates", "benchmarks")
(here / "adopted-maintenance.diff").write_bytes(git("diff", "--binary"))
record = {"base_source_sha": base, "kind": "WORKING_TREE_MAINTENANCE_ADOPTION_NOT_ACCEPTANCE",
          "backup_commit": backup["commit"], "backup_readback_verified": True,
          "adopted_utc": datetime.now(timezone.utc).isoformat(), "patches": patches,
          "changed_files": sorted(changed), "production_package_and_judges_unchanged": True,
          "tests_executed_by_this_script": 0, "protected_expectations_changed": False}
(here / "adoption-receipt.json").write_text(json.dumps(record, indent=2), encoding="utf-8")
print(json.dumps(record, indent=2))
