"""Commit the tested maintenance snapshot in named, independently staged rounds."""
import hashlib
import json
from pathlib import Path
import subprocess

here = Path(__file__).resolve().parent
repo = here.parent / "checkwash-ux"
base = "8a8941dc2d7c581715a0f6f196c00da6c55f084b"
gate = json.loads((here / "root/dev-maintenance-targeted-r2/receipt.json").read_bytes())
assert gate["source_sha"] == gate["ending_sha"] == base and gate["exit_code"] == 0 and gate["source_files_unchanged"]
assert "180 passed" in (here / "root/dev-maintenance-targeted-r2/stdout.txt").read_text(encoding="utf-8")
groups = [
    ("docs: align the development version ledger with 0.10.0", ["STATE.md"]),
    ("test: bind Action freshness to the verified public ledger", ["tests/test_packaging.py"]),
    ("test: check IR3 enrichment alongside native oracle fields", ["tests/test_classic_raises_additions.py"]),
    ("test: distinguish startup probes from detector chain reads", ["tests/test_root_oracles.py", "tests/test_issue223_conftest_request_side.py"]),
    ("test: preserve canonical producer identity in CI move controls", ["tests/test_js_test_obligations.py"]),
    ("docs: sync the collected test denominator to 21104", ["README.md", "CONTRIBUTING.md", "docs/launch.md"]),
]

def git(*args):
    return subprocess.run(["git", *args], cwd=repo, capture_output=True, check=True).stdout

assert git("rev-parse", "HEAD").decode().strip() == base
assert not git("diff", "--cached", "--name-only")
allowed = {name for _, names in groups for name in names}
assert set(git("diff", "--name-only").decode().splitlines()) == allowed
before = {name: hashlib.sha256((repo / name).read_bytes()).hexdigest() for name in allowed}
all_inputs = json.loads((here / "root/dev-maintenance-targeted-r2/input-hashes.json").read_bytes())
assert all(before[name] == all_inputs[name] for name in allowed)
assert not git("diff", base, "--", "src", "pyproject.toml", "tests/cases", "tests/gates", "benchmarks", "release/advertised.toml")
messages = here / "commit-messages"
messages.mkdir(exist_ok=False)
commits = []
for index, (title, names) in enumerate(groups, 1):
    message = messages / (str(index) + ".txt")
    message.write_text(title + "\n\nShared maintenance working-tree gate: 180 passed, exit 0.\n"
                       "Receipt: stage5 dev-maintenance-targeted-r2; input manifest " + gate["input_manifest_sha256"] + ".\n"
                       "This is development snapshot evidence, not per-intermediate-commit qualification.\n"
                       "Final fixed-source regression and artifact checks are pending.\n"
                       "No protected expected records, gates, production package or advertised pins changed.\n", encoding="utf-8")
    git("add", "--", *names)
    assert set(git("diff", "--cached", "--name-only").decode().splitlines()) == set(names)
    output = git("commit", "-F", str(message)).decode("utf-8", "backslashreplace")
    commit = git("rev-parse", "HEAD").decode().strip()
    commits.append({"commit": commit, "title": title, "files": names, "output": output})
    (here / "commits.json").write_text(json.dumps(commits, indent=2), encoding="utf-8")
    assert all(hashlib.sha256((repo / name).read_bytes()).hexdigest() == before[name] for name in allowed)
assert not git("status", "--porcelain", "--untracked-files=all")
print(json.dumps({"head": commits[-1]["commit"], "commits": len(commits), "source_files_equal_tested_snapshot": True}, indent=2))
