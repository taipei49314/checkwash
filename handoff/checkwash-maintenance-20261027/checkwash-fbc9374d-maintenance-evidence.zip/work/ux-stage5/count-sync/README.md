# Collection denominator sync

**MECHANICAL_COUNT_SYNC_COMPLETE / POST_SYNC_VALIDATION_NOT_RUN**

Root 指定三份 product docs 的 collection 數字，依真實 collection receipt 同步，沒有把 collected 寫成 passed。

實際證據：work/ux-stage5/root/dev-collection-r1/receipt.json 與原 stdout「21104 tests collected in 6.24s」，exit0、source_files_unchanged=true、changed_inputs=[]。實際host LAPTOP-01AGNPJU、Python3.11.9，標記 HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL。

此 collection 是 **WORKING_TREE_DEVELOPMENT_NOT_COMMIT_QUALIFICATION**：HEAD8a加上root已採納的reviewed maintenance WIP，diff SHA ca6b1abc8d598fd5f8d2f23cf602f8b919c9e33c87d1bceac3872687237cfef7，input manifest de18cd6a3c9193467e3ba8bbbd5a61cad624121775489103e7123a980da6c0fe。不是將此結果冒稱為8a exact-source或新封存SHA qualification。

僅修改：

- README.md：1處21102→21104，保留「collection denominator」。
- CONTRIBUTING.md：1處21102→21104，保留「collected」。
- docs/launch.md：2處21102→21104，保留「collection denominator」、historical draft版本與其他原始文字。

本次逐檔byte比對after恰等於before四處數字替換。ordinary control tests/test_packaging.py::test_documented_test_count_is_accurate 已從實際collection輸出取得actual，並檢查三份文件，沒有硬編碼舊21102，因此不需修改；其原bytes保持不變。

count-sync.json 保存before/after hashes、實collection命令/runtime/source身份、原始收據hash與控制檢視結論。count-sync.diff 是本次精確三檔四行diff；*.before是改動前的task-owned docs byte快照，不是改寫歷史紀錄。

本次0產品call、0pytest、未commit/push，未碰SRC/版本/fixtures/gates/benchmarks或其他歷史記錄。所有原collection receipts重hash吻合。本次只完成文件同步，沒有聲稱修後targeted PASS；root將自行重跑targeted並固定新source驗證。既有full8a的22fail與#567/#568/selfdogfood未接受狀態不因count同步解除，1.0前仍停問。

