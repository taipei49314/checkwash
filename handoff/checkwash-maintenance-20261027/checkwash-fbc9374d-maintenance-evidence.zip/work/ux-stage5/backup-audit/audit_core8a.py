"""Independent read-only ZIP audit. No extraction, rebuilding, or product imports/calls."""
from __future__ import annotations
import collections
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import platform
import re
import stat
import sys
import tarfile
import xml.etree.ElementTree as ET
import zipfile

BASE = Path(r"C:\Users\nelson\Documents\Codex\2026-10-26\1-00-start-here-md-c")
OUT = Path(__file__).parent
BUNDLE = BASE / "outputs/checkwash-core-010-handoff-20261027/checkwash-8a-sanitized-continuation.zip"
SOURCE = "8a8941dc2d7c581715a0f6f196c00da6c55f084b"
PRIOR = "1ffe283d7d947fecc426dea99323b0a2620a9482"
PACKER = "548566e890a5bd057d6f9ae1970824889c69e07d658b5265a32668b5cd8e598a"
EXPECTED = "d8a24a21cc811bc9237631d69d2d163dea98d66430d26aa35fc766cdadc68a4d"
h = lambda raw: hashlib.sha256(raw).hexdigest()
def json_bytes(raw):
    return json.loads(raw.decode("utf-8"))
def safe_name(name):
    p = PurePosixPath(name)
    if not name or name.startswith(("/", "\\")) or "\\" in name or ":" in name or "\x00" in name:
        return False
    if any(x in ("", ".", "..") or any(ord(c) < 32 for c in x) for x in name.rstrip("/").split("/")):
        return False
    return not p.is_absolute()
raw_archive = BUNDLE.read_bytes()
sidecar_path = Path(str(BUNDLE) + ".sha256")
sidecar_before = sidecar_path.read_bytes()
receipt_path = BASE / "work/ux-stage4/checkpoint-pack/pack-receipt.json"
receipt_before = receipt_path.read_bytes()
receipt = json_bytes(receipt_before)
assert len(raw_archive) == 29871864 and h(raw_archive) == EXPECTED
assert sidecar_before.decode().split()[0] == EXPECTED
assert receipt["sha256"] == EXPECTED and receipt["source_sha"] == SOURCE
assert receipt["source_and_inputs_unchanged"] and receipt["file_count"] == 2908
assert receipt["validation"]["all_active_jobs_terminal"]
result = {
 "status": "INDEPENDENT_READ_ONLY_ARCHIVE_INTEGRITY_PASS_ACCEPTANCE_NONPASS",
 "reviewer": "/root/rename_repro", "host": platform.node(), "python": sys.version,
 "provenance": "HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL",
 "archive": BUNDLE.name, "bytes": len(raw_archive), "sha256": h(raw_archive),
 "product_calls": 0, "test_calls": 0, "rebuilds": 0, "extractions": 0,
 "precondition": "Pack author confirmed process5966 terminal exit0; complete stable pack-receipt read independently",
 "blocking": [], "observations": [],
}
with zipfile.ZipFile(io.BytesIO(raw_archive)) as archive:
    infos = archive.infolist()
    names = [x.filename for x in infos]
    assert len(names) == len(set(names)) == 2915
    assert names == sorted(names)
    assert len({n.casefold() for n in names}) == len(names)
    assert all(safe_name(n) for n in names)
    assert all(not i.is_dir() and stat.S_IFMT(i.external_attr >> 16) == stat.S_IFREG for i in infos)
    assert all(i.date_time == (1980, 1, 1, 0, 0, 0) for i in infos)
    assert all(stat.S_IMODE(i.external_attr >> 16) == 0o644 for i in infos)
    assert all(i.compress_type == zipfile.ZIP_DEFLATED for i in infos)
    assert archive.testzip() is None
    payload = {n: archive.read(n) for n in names}
manifest = json_bytes(payload["BUNDLE-MANIFEST.json"])
classification = json_bytes(payload["BUNDLE-CLASSIFICATION.json"])
terminal = json_bytes(payload["VALIDATION-TERMINAL-STATE.json"])
assert manifest["source_sha"] == SOURCE and manifest["required_git_object"] == PRIOR
assert manifest["packer_sha256"] == PACKER
assert manifest["file_count"] == len(manifest["files"]) == 2908
assert sum(r["bytes"] for r in manifest["files"]) == manifest["uncompressed_bytes"] == 87923017
assert classification["historical_replay_self_contained"] is False
rows = {r["path"]: r for r in manifest["files"]}
assert len(rows) == 2908
controllers = {r["path"]: r for r in manifest["controller_files"]}
assert len(controllers) == 3
metadata = {"BUNDLE-MANIFEST.json", "BUNDLE-CLASSIFICATION.json", "RESTORE-MAP.md",
            "VALIDATION-TERMINAL-STATE.json"}
assert set(payload) == set(rows) | set(controllers) | metadata
local_differences = []
for name, row in {**rows, **controllers}.items():
    data = payload[name]
    assert len(data) == row["bytes"] and h(data) == row["sha256"], name
    local = BASE / row.get("restore_to", name)
    if local.is_file() and local.read_bytes() != data:
        local_differences.append({"path": name, "packed_sha256": h(data),
                                  "current_local_sha256": h(local.read_bytes()),
                                  "classification": "POST_PACK_INDEX_GENERATOR_METADATA_DRIFT" if name == "work/ux-stage4/prepare_handoff_outputs.py" else "UNEXPECTED"})
    elif not local.is_file():
        local_differences.append({"path": name, "classification": "LOCAL_FILE_MISSING"})
assert all(x["classification"] == "POST_PACK_INDEX_GENERATOR_METADATA_DRIFT" for x in local_differences), local_differences
assert h(payload["BUNDLE-TOOLS/pack_checkpoint.py"]) == PACKER
for row in controllers.values():
    assert row["restore_to"].startswith("work/ux-stage4/checkpoint-pack/")
result["zip_integrity"] = {"members": 2915, "payload": 2908, "controllers": 3, "generated_metadata": 4,
                           "all_2911_declared_member_hashes": "MATCH", "crc": "PASS",
                           "paths": "UNIQUE_CASEFOLD_SORTED_SAFE_RELATIVE",
                           "types": "REGULAR_ONLY", "timestamp": "FIXED_1980",
                           "mode": "0644", "compression_method": "DEFLATE",
                           "compression_level9": "DESIGN_METADATA_NOT_INDEPENDENTLY_REPRODUCED"}
result["live_comparison"] = {"compared": 2911, "differences": local_differences,
                             "interpretation": "Archived bytes match pack-time manifest. Root reported post-pack index-generator edit; no source or raw receipt difference observed among other compared members."}
roles = {}
for row in terminal["roles"]:
    data = payload[row["receipt"]]
    assert h(data) == row["sha256"]
    r = json_bytes(data)
    want = 1 if row["role"] == "full_suite" else 0
    assert row["state"] == "TERMINAL" and row["exit_code"] == r["exit_code"] == want
    assert r["source_sha"] == r["ending_sha"] == SOURCE and r["source_files_unchanged"]
    roles[row["role"]] = {"receipt": row["receipt"], "sha256": h(data), "exit_code": want,
                          "source_sha": r["source_sha"], "ending_sha": r["ending_sha"]}
assert set(roles) == {"qualification_source", "qualification_wheel", "qualification_pyz", "full_suite"}
assert terminal["source_sha"] == SOURCE and terminal["all_active_jobs_terminal"]
assert "does not assert all tests passed" in terminal["interpretation"]
full_prefix = "work/ux-stage4/final/full-suite-311-r1/"
full_receipt = json_bytes(payload[full_prefix + "receipt.json"])
xml = ET.fromstring(payload[full_prefix + "junit.xml"])
parents = list(xml.iter("testcase"))
failed = [t for t in parents if t.find("failure") is not None]
skipped = [t for t in parents if t.find("skipped") is not None]
assert len(failed) == 22
stdout = payload[full_prefix + "stdout.txt"].decode("utf-8", errors="replace")
summary = [s for s in stdout.splitlines() if "22 failed" in s and "21055 passed" in s and "25 skipped" in s]
assert len(summary) == 1 and "67 subtests passed" in summary[0]
extra = json_bytes(payload["work/ux-stage4/full-suite-extra-triage/triage.json"])
for name, row in extra["original_raw_hashes"].items():
    assert len(payload[full_prefix + name]) == row["bytes"] and h(payload[full_prefix + name]) == row["sha256"]
ordinary = json_bytes(payload["work/ux-stage4/qualification/fullsuite-triage/assessment.json"])
assert ordinary["suite_exit"] == 1 and ordinary["summary"]["failed_parents"] == 22
assert ordinary["summary"]["native_xml_reports"] == 21169
assert ordinary["summary"]["native_xml_parents"] == 21102
assert extra["status"] == "READ_ONLY_TRIAGED_ACCEPTANCE_NONPASS_NO_CHANGES"
assert len(extra["case_identity_triage"]) == 4
assert len(ordinary["selected_ordinary_rows"]) == 8
body = payload["work/ux-stage4/pr566-body-proposed.md"].decode()
assert "issues/568" in body and "issues/567" in body
for marker in ["14 additional failures", "NOT_REACHED", "NOT_CAPTURED", "unapproved",
               "INERT_NOT_APPLIED_NOT_ACCEPTED_NONPASS_STILL_OPEN", "two-high BLOCK",
               "not been merged, tagged or released", "before version 1.0"]:
    assert marker in body, marker
golden_prefix = "work/ux-stage4/golden-ruling-proposal/"
assert golden_prefix + "expected-only.patch" in payload
golden_markers = [n for n in payload if n.startswith(golden_prefix) and n.endswith((".md", ".json"))]
assert any(b"INERT_NOT_APPLIED_NOT_ACCEPTED_NONPASS_STILL_OPEN" in payload[n] for n in golden_markers)
result["terminal_receipts"] = roles
result["full_suite"] = {"exit_code": 1, "failed_parents": 22, "passed_parents": 21055,
                         "skipped_parents": 25, "subtests_passed": 67,
                         "native_xml_reports": 21169, "native_xml_unique_parents": 21102,
                         "stdout_summary": summary[0], "raw_hashes_against_extra_triage": "ALL5_MATCH",
                         "native_failed_nodeids": [{"classname": t.get("classname"), "name": t.get("name")} for t in failed],
                         "acceptance": "NONPASS"}
result["pending_acceptance"] = {"both_triage_packets_present": True, "ordinary_triage_rows": 8,
                                 "corpus_case_identities_in_extra_triage": 4, "issue568": "OPEN_NO_LABEL_ACCEPTANCE",
                                 "issue567_eight_golden": "INERT_UNAPPLIED_UNACCEPTED_NONPASS",
                                 "selfdogfood": "SEPARATE_TWO_HIGH_BLOCK_NOT_OVERRIDDEN",
                                 "formal_release_acceptance": "NOT_CLAIMED"}
# Independently verify all sealed tracked source archive bytes and Git-blob identities.
seal = json_bytes(payload["work/ux-stage4/seal/source-seal.json"])
source_zip_name = "work/ux-stage4/seal/" + Path(seal["source_archive"].replace("\\", "/")).name
assert h(payload[source_zip_name]) == seal["archive_sha256"]
assert seal["source_sha"] == SOURCE and seal["tracked_files"] == len(seal["files"]) == 3084
with zipfile.ZipFile(io.BytesIO(payload[source_zip_name])) as source_zip:
    source_members = {i.filename: i for i in source_zip.infolist() if not i.is_dir()}
    assert set(source_members) == {row["path"] for row in seal["files"]}
    for row in seal["files"]:
        data = source_zip.read(row["path"])
        assert len(data) == row["bytes"] and h(data) == row["sha256"]
        blob = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
        assert blob == row["git_blob"] == row["actual_git_blob"]
    source_proof = {name: source_zip.read(name) for name in
                    ("tests/test_collect_pju_release.py", "tests/test_sweep_commit_diagnostics.py")}
restore = payload["RESTORE-MAP.md"].decode()
assert SOURCE in restore and PRIOR in restore and "3,084" in restore and "raw byte" in restore
result["restore"] = {"source_sha": SOURCE, "required_git_object": PRIOR, "controller_sha256": PACKER,
                      "sealed_source_zip_sha256": seal["archive_sha256"],
                      "source_member_bytes_and_computed_git_blobs": "3084_MATCH",
                      "restore_map": "EXACT_LAYOUT_GIT_OBJECTS_LF_RAW_BYTE_CHECKS_PRESENT",
                      "actual_restore_or_git_fetch": "NOT_RUN"}
# Bounded independent content scan; no values are printed or copied to report.
denied = {
 "e6466727b1eeea9d964bc137b201f57d6e2e23ade4325dd509f373f32c377096",
 "c39a09b4ee8c0c3747d8ca6d0ce8a61482eb4e972ada640acce035a7a48d85a4",
 "d63425e79e3d7384fb4b73f11b2f562186b80db805f49d16c57de72e0a7f92a2",
}
private_refs = [
 Path(r"C:\Users\nelson\.codex\AGENTS.md"),
 Path(r"C:\Users\nelson\Documents\Codex\2026-10-16\new-chat\outputs\github-memory-2026-10-16.md"),
]
private_reference_count = 0
for ref in private_refs:
    if ref.is_file():
        denied.add(h(ref.read_bytes())); private_reference_count += 1
markers = [b"Local Codex project memory", b"## General work-machine rule", b"EYE trial 1 (ended)"]
shapes = [re.compile(rb"-----BEGIN (?:[A-Z ]+ )?PRIVATE KEY-----"),
          re.compile(rb"\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{40,})\b"),
          re.compile(rb"\bsk-(?:proj-)?[A-Za-z0-9_-]{30,}\b"),
          re.compile(rb"\bAKIA[0-9A-Z]{16}\b")]
userinfo = re.compile(rb'https?://[^\s/"<>]+:[^\s/"<>]+@')
synthetic_urls = set()
for data in source_proof.values():
    synthetic_urls.update(userinfo.findall(data))
privacy_counts = collections.Counter()
privacy_findings = []
guard_literal_headers = []
synthetic_url_files = []
def inspect(data, name, depth=0):
    privacy_counts["regular_records_read"] += 1
    privacy_counts["bytes_scanned"] += len(data)
    private_name = any(x in name.lower() for x in ("github-memory", "global-agents", "global_agents"))
    if h(data) in denied or private_name:
        privacy_findings.append({"path": name, "reason": "EXACT_PRIVATE_OR_ORIGINAL_ARCHIVE_OR_PRIVATE_NAME"})
    if sum(x in data for x in markers) >= 2:
        if name in controllers and h(data) == controllers[name]["sha256"]:
            guard_literal_headers.append({"path": name, "reason": "REVIEWED_CONTROLLER_GUARD_MARKER_LITERALS"})
        else:
            privacy_findings.append({"path": name, "reason": "MULTIPLE_GLOBAL_MEMORY_HEADER_MARKERS"})
    if any(x.search(data) for x in shapes):
        privacy_findings.append({"path": name, "reason": "CREDENTIAL_SHAPED_CONTENT"})
    urls = userinfo.findall(data)
    if any(u not in synthetic_urls for u in urls):
        privacy_findings.append({"path": name, "reason": "UNEXPECTED_AUTHENTICATED_URL"})
    elif urls:
        synthetic_url_files.append(name)
    stream = io.BytesIO(data)
    if zipfile.is_zipfile(stream):
        assert depth < 4
        with zipfile.ZipFile(stream) as nested:
            info = nested.infolist()
            assert sum(i.file_size for i in info) <= 512 * 1024 * 1024
            assert nested.testzip() is None
            privacy_counts["nested_zip_archives"] += 1
            for i in info:
                assert safe_name(i.filename)
                if i.is_dir(): continue
                assert stat.S_IFMT(i.external_attr >> 16) in (0, stat.S_IFREG)
                inspect(nested.read(i), name + "!/" + i.filename, depth + 1)
    elif name.lower().endswith((".tar.gz", ".tgz", ".tar")):
        assert depth < 4
        with tarfile.open(fileobj=stream, mode="r:*") as nested:
            members = nested.getmembers()
            assert sum(i.size for i in members) <= 512 * 1024 * 1024
            privacy_counts["nested_tar_archives"] += 1
            for i in members:
                assert safe_name(i.name)
                if i.isdir(): continue
                assert i.isfile()
                inspect(nested.extractfile(i).read(), name + "!/" + i.name, depth + 1)
for name, data in payload.items():
    inspect(data, name)
result["privacy"] = {"scope": "All2915 outer member bytes plus recursively recognized ZIP/whl/pyz/tar members",
                       "counts": dict(privacy_counts), "private_reference_fingerprints_read_without_export": private_reference_count,
                       "checks": ["Exact original3ZIP/private-memory fingerprints", "Private member names",
                                  "Multiple global-memory header markers", "Private-key/token/AWS credential shapes",
                                  "Authenticated URLs except exact synthetic literals anchored to3084-source seal",
                                  "Nested archive CRC/safe names/regular types; depth<4 and512MiB/archive caps"],
                       "findings": privacy_findings, "guard_literal_headers": guard_literal_headers,
                       "synthetic_url_record_paths": sorted(set(synthetic_url_files)),
                       "interpretation": "Bounded scan, not a universal secret-free guarantee. No matched values exported."}
if privacy_findings:
    result["blocking"].extend(privacy_findings)
    result["status"] = "REQUIRES_PRIVACY_DISPOSITION"
assert h(BUNDLE.read_bytes()) == EXPECTED
assert sidecar_path.read_bytes() == sidecar_before and receipt_path.read_bytes() == receipt_before
result["non_repeated_guards"] = [
 "No packer execution, selector/reparse traversal replay, deterministic recompression or restoration",
 "No product/fullsuite/qualification rerun, cross-platform check, Git fetch or network/remote-push verification",
 "Pack-time source/input stability fields are original receipts; archived source hashes independently checked as stated",
 "Live post-pack metadata drift is retained, not hidden or used to rebuild frozenZIP",
]
target = OUT / "core8a-independent-readback.json"
assert not target.exists()
target.write_bytes((json.dumps(result, ensure_ascii=False, indent=2) + "\n").encode())
print(json.dumps({"status": result["status"], "archive_sha256": EXPECTED,
                  "declared_hashes_checked":2911,"source_members_checked":3084,
                  "local_differences":local_differences,
                  "privacy_counts":dict(privacy_counts),"privacy_findings":len(privacy_findings),
                  "json_sha256":h(target.read_bytes())},ensure_ascii=False))

