# core8a continuation ZIP：獨立只讀核包

**ARCHIVE INTEGRITY PASS / PRODUCT ACCEPTANCE NONPASS；未發現備份阻擋項。**

核對前已取得 pack author 確認 session5966 terminal exit0，並獨立讀到完整 pack receipt。此審查沒有執行 packer、重建／解壓到磁碟、import 產品、跑 pytest/qualification、讀遠端或變更任何 stage4/input/ZIP。只寫 stage5。實際主機 LAPTOP-01AGNPJU、Python3.11.9，標記 HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL。

## 實際核對結果

ZIP：checkwash-8a-sanitized-continuation.zip，**29,871,864 bytes**。

SHA256：**d8a24a21cc811bc9237631d69d2d163dea98d66430d26aa35fc766cdadc68a4d**

- 實際 ZIP SHA、sidecar 與完整 pack receipt 一致；核對結束後三者保持原 bytes。
- 2,915 members = 2,908 selected payload + 3 BUNDLE-TOOLS controllers + 4 generated metadata。全部 2,911 個 declared raw byte lengths/hashes 與 manifest 相符。Payload 合計 87,923,017 uncompressed bytes。
- 外層 CRC 全通過；members 無重名／casefold collision，排序一致，均為安全相對名稱與 regular files，固定1980 timestamp、0644、DEFLATE。另檢查外層 Windows reserved device names／尾端 dot-space：零項。
- 四個 terminal receipt 的 archived SHA、source/ending8a、source_unchanged 均吻合。原 exit 精確保留：

| role | 原 exit | source/ending |
|---|---:|---|
| source assertion qualification | 0 | 8a8941dc |
| wheel assertion qualification | 0 | 8a8941dc |
| pyz assertion qualification | 0 | 8a8941dc |
| full suite | **1** | 8a8941dc |

這是對原回執的完整性核對，未重新執行 qualification，也未重做其283-case worker/raw-offset資格審查。

## full suite 與尚未接受的結果

獨立解析包內原 XML：

- **21,102 testcase elements = 21,102 unique classname/name parent keys**。
- 22 failure parents、25 skipped parents。
- testsuite declared tests 是 **21,169**；原 stdout 明列 **22 failed / 21,055 passed / 25 skipped / 67 subtests passed**。21,169 是含 subtests 的宣告報告分母，並非21,169個 testcase elements。
- 這五個原檔的 hash 與包內既有六項分流記錄全部吻合：receipt.json、junit.xml、stdout.txt、stderr.txt、input-hashes.json。
- 兩份 triage packet 與 supporting raw 存在：full-suite-extra-triage（六個指定 failures／四個 corpus identities）、qualification/fullsuite-triage（八個 ordinary failures）及 JS supporting evidence。
- archived PR body 明確保留 full-suite exit1、八個既有 golden 與十四個額外 failures，不豁免任何失敗。
- #568 的四個 corpus identities 及 wrapper/score 首例一致、後續 NOT_REACHED、full finding/severity NOT_CAPTURED 界線保留。
- #567 八案 expected-only proposal 仍 **INERT_NOT_APPLIED_NOT_ACCEPTED_NONPASS_STILL_OPEN**。原 golden labels 未由這次備份接受或改標。
- candidate selfdogfood 的兩個 high BLOCK 另列；public090 local Action／三條 qualification 的 exit0 沒有取代它或 full-suite NONPASS。
- PR維持draft，未聲稱formal release collector/check-run接受、merge、tag、release；1.0前停問界線仍在。

## 恢復資料

Manifest 與 RESTORE-MAP 明示產品 source **8a8941dc2d7c581715a0f6f196c00da6c55f084b**，另須取得 Git object **1ffe283d7d947fecc426dea99323b0a2620a9482**。sealed source ZIP 本次實讀 **3,084 tracked member bytes/SHA256**，並逐個重算 Git blob SHA1，全部吻合 source-seal 的 path membership、length、sha256、git_blob 與 actual_git_blob；source archive 本身 SHA 也吻合。

三個 controller 的 raw hashes／restore_to 均與 manifest 相符。Packer 是 **548566e890a5bd057d6f9ae1970824889c69e07d658b5265a32668b5cd8e598a**。Restore map 保留原 work layout、兩個精確 Git objects、Windows checkout LF與原始3084-byte驗證要求；明說 ZIP 不供給 Git history、不是所有 historical red runs 自足重播。沒有實際執行 restore、fetch 或 source test。

## 唯一 live temporal 差異

2,911 個 declared files 與目前本機位置比較，只有 root事先說明的 post-pack 索引生成程式不同：

- work/ux-stage4/prepare_handoff_outputs.py
- packed SHA：f22473e0b3dc3b74b4b758808f42563a49f20c138260adbc120cf10466ab23fd
- current local SHA：b5d3326c381889a580ecdfccf553522d9edf5400ee2984dd0035b12b1240a83a

這是封包後索引程式 metadata drift；ZIP 內舊 bytes 仍精確符合 pack-time manifest。其他本次比較的 source/raw/receipt/controller bytes沒有差異。本審查沒有因這個已說明時間差重建ZIP，也未把最新外部 INDEX-TOOLS/00-START-HERE 的狀態冒稱成ZIP內pack時bytes。外部最新 HANDOFF-MANIFEST／remote push 不屬本次核對範圍。

## bounded privacy 的實際範圍

實讀 **6,862 regular records / 133,193,655 bytes**：全部2,915外層members，遞迴辨識6個ZIP/whl/pyz與1個tar archive。沒有抽取到磁碟。

檢查 exact 三個原legacy ZIP與兩個本機private-memory reference fingerprints（只讀fingerprint、不輸出本文）、私密member命名、多個global-memory header組合、private-key／GitHub／OpenAI／AWS credential shapes，以及帶userinfo的HTTP URL。Nested ZIP另做CRC，nested members檢查safe paths／regular types；depth<4、每archive512MiB界線未觸及。

**零未解privacy finding。** Packer controller 中的三個global-header字串是先前已審的guard常量，raw5485 hash吻合，明確列作guard literals而非記憶正文。唯一userinfo字串位於sealed source的兩個既有synthetic credential tests，逐字literal由本次3084-source seal錨定；未輸出任何matched值。

這是上述有界檢查，**不宣稱普遍secret-free**；沒有重跑原selector/reparse admission、全host掃描或原pack-time stability過程。

## 原件與審查紀錄

- core8a-independent-readback.json：完整核對範圍、22 failed IDs、四回執hash、privacy scope與唯一live drift。SHA256 **c407102ead62397833a20de882f0a5acf3e3c844e2826621759584ee67a4501b**。
- core8a-independent-native-count-readback.json：補充直接XML parent/declared分母與Windows名稱檢查。SHA256 **5d0de60945d836402ad045a6d44af870b64170e585440e24e8ceea3d46b9e8f7**。
- audit_core8a.py：獨立只讀stdlib核對程式，本次exit0只代表封包核對完成，不能轉稱產品suite PASS。

未重做 deterministic recompression，所以只核實DEFLATE method與固定member metadata；Deflate9／相同runtime重建相同bytes仍是記錄的設計保證，沒有冒稱此審查重建驗證。所有原始資料與coreZIP保持不變。備份可續作與產品已驗收是分開狀態。

