"""Build an inert two-file patch from frozen8a; never imports or executes proposed code."""
from __future__ import annotations
import ast
from collections import Counter
import difflib
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys

BASE = Path(r"C:\Users\nelson\Documents\Codex\2026-10-26\1-00-start-here-md-c")
REPO = BASE / "work/checkwash-ux"
OUT = Path(__file__).parent
SOURCE = "8a8941dc2d7c581715a0f6f196c00da6c55f084b"
ENV = {k: v for k, v in os.environ.items() if not k.upper().startswith("GIT_")}
def h(data):
    return hashlib.sha256(data).hexdigest()
def git(*args):
    p = subprocess.run(["git", "--no-optional-locks", "-c", "core.fsmonitor=false",
                        "-C", str(REPO), *args], stdout=subprocess.PIPE,
                       stderr=subprocess.PIPE, env=ENV, timeout=20)
    if p.returncode:
        raise RuntimeError(f"Read-only Git exit {p.returncode}")
    return p.stdout
def write(name, data):
    p = OUT / name
    if p.exists():
        raise RuntimeError(f"Refusing overwrite {name}")
    p.write_bytes(data)
assert git("rev-parse", "HEAD").decode().strip() == SOURCE
assert not git("status", "--porcelain").strip()
rels = [
    "tests/test_packaging.py", "STATE.md", "release/advertised.toml",
    "README.md", ".github/workflows/checkwash.yml", "action/README.md",
    "src/checkwash/doctor.py", ".pre-commit-hooks.yaml",
    "src/checkwash/__init__.py", "pyproject.toml",
    "docs/RELEASING.md", "tests/test_published_source.py",
]
old = {rel: (REPO / rel).read_bytes() for rel in rels}
for rel, data in old.items():
    assert data == git("show", f"{SOURCE}:{rel}"), rel
text = old["tests/test_packaging.py"].decode("utf-8")
helper = '''def _assert_action_pin_matches_verified_release(
    trusted_tag: str, pin: str, advertised: dict,
) -> None:
    # Tag presence is not publication: candidate/paused tags may exist locally.
    assert trusted_tag == advertised["tag"], (
        f"trusted {trusted_tag} is not verified advertised release {advertised['tag']}"
    )
    assert pin == advertised["commit"], (
        f"trusted {trusted_tag} pin {pin} differs from verified advertised commit "
        f"{advertised['commit']}"
    )


'''
anchor = "def test_version_matches_pyproject():\n"
assert text.count(anchor) == 1
text = text.replace(anchor, helper + anchor, 1)
comment_before = '''    # The required-check snippet, self-audit workflow, and doctor's offline
    # allowlist are one contract. The Greenwash pin intentionally trails by one
    # release: a commit cannot contain its own SHA, so only an already-existing
    # stable tag can be verified and embedded.
'''
comment_after = '''    # The required-check snippet, self-audit workflow, and doctor's offline
    # allowlist are one contract. Their Action pin follows the explicitly
    # verified advertised release, not the newest tag present locally.
'''
assert text.count(comment_before) == 1
text = text.replace(comment_before, comment_after, 1)
local_before = '''    if trusted_version < current_version:
        released = subprocess.check_output(
            ["git", "tag", "--list", "v[0-9]*"], cwd=str(ROOT), text=True
        ).splitlines()
        prior = [
            version_tuple(tag)
            for tag in released
            if re.fullmatch(r"v\\d+\\.\\d+\\.\\d+", tag)
            and version_tuple(tag) < current_version
        ]
        assert prior and trusted_version == max(prior), (
            f"trusted {trusted_tag} is not the newest prior stable tag"
        )
'''
verified_after = '''    manifest = tomllib.loads((ROOT / "release/advertised.toml").read_text(encoding="utf-8"))
    _assert_action_pin_matches_verified_release(trusted_tag, pin, manifest["release"])

    # Synthetic peeled local tags model the paused v0.9.1/candidate scenario.
    # A newer local tag must not promote itself into the verified ledger.
    import pytest

    local_tags = {"v0.9.0": "a" * 40, "v0.9.1": "b" * 40, "v0.10.0": "c" * 40}
    verified = {"tag": "v0.9.0", "commit": local_tags["v0.9.0"]}
    _assert_action_pin_matches_verified_release("v0.9.0", local_tags["v0.9.0"], verified)
    for unpublished in ("v0.9.1", "v0.10.0"):
        with pytest.raises(AssertionError, match="not verified advertised release"):
            _assert_action_pin_matches_verified_release(
                unpublished, local_tags[unpublished], verified,
            )
    with pytest.raises(AssertionError, match="differs from verified advertised commit"):
        _assert_action_pin_matches_verified_release("v0.9.0", "d" * 40, verified)

    # If a reviewed ledger later advances, the formerly trusted pin is stale.
    advanced = {"tag": "v0.9.1", "commit": local_tags["v0.9.1"]}
    _assert_action_pin_matches_verified_release("v0.9.1", local_tags["v0.9.1"], advanced)
    with pytest.raises(AssertionError, match="not verified advertised release"):
        _assert_action_pin_matches_verified_release("v0.9.0", local_tags["v0.9.0"], advanced)
'''
assert text.count(local_before) == 1
text = text.replace(local_before, verified_after, 1)
new = {"tests/test_packaging.py": text.encode("utf-8")}
before_row = b"| version | v0.9.1 |"
after_row = b"| version | v0.10.0 |"
assert old["STATE.md"].count(before_row) == 1
new["STATE.md"] = old["STATE.md"].replace(before_row, after_row, 1)

# Parsing/dumping AST is static inspection only; proposed code is never compiled/imported/run.
old_tree = ast.parse(old["tests/test_packaging.py"], filename="8a/tests/test_packaging.py")
new_tree = ast.parse(new["tests/test_packaging.py"], filename="INERT/tests/test_packaging.py")
def named(tree):
    return {x.name: x for x in tree.body if isinstance(x, (ast.FunctionDef, ast.AsyncFunctionDef))}
old_named, new_named = named(old_tree), named(new_tree)
target = "test_readme_action_snippet_is_zizmor_blanket"
assert set(new_named) - set(old_named) == {"_assert_action_pin_matches_verified_release"}
for name in old_named:
    if name != target:
        assert ast.dump(old_named[name], include_attributes=False) == ast.dump(new_named[name], include_attributes=False), name
def assertions(fn):
    return Counter(ast.dump(x, include_attributes=False) for x in ast.walk(fn) if isinstance(x, ast.Assert))
removed = assertions(old_named[target]) - assertions(new_named[target])
assert sum(removed.values()) == 1
removed_node = next(x for x in ast.walk(old_named[target])
                    if isinstance(x, ast.Assert) and "newest prior stable tag" in ast.get_source_segment(old["tests/test_packaging.py"].decode(), x))
assert removed == Counter({ast.dump(removed_node, include_attributes=False): 1})
old_tests = {x for x in old_named if x.startswith("test_")}
new_tests = {x for x in new_named if x.startswith("test_")}
assert old_tests == new_tests
assert b'["git", "tag", "--list"' not in new["tests/test_packaging.py"]
patch = "".join("".join(difflib.unified_diff(old[rel].decode().splitlines(keepends=True),
                                           new[rel].decode().splitlines(keepends=True),
                                           fromfile="a/" + rel, tofile="b/" + rel))
                for rel in ["STATE.md", "tests/test_packaging.py"]).encode("utf-8")
write("docs-public-pin.patch", patch)
write("proposed-test_packaging.py.txt", new["tests/test_packaging.py"])
validation = {
    "status": "INERT_NOT_APPLIED_NOT_IMPORTED_NOT_EXECUTED_NOT_ACCEPTED",
    "source_sha": SOURCE, "host": platform.node(),
    "provenance": "HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL",
    "runtime": sys.version, "executable": sys.executable,
    "product_calls": 0, "pytest_calls": 0, "subject_execution": 0,
    "patch_sha256": h(patch), "patch_bytes": len(patch),
    "eol": "LF raw bytes; hashes are raw SHA256",
    "before": {rel: {"bytes": len(data), "sha256": h(data)} for rel, data in old.items()},
    "proposed_after": {rel: {"bytes": len(data), "sha256": h(data)} for rel, data in new.items()},
    "scope": ["STATE authoritative development version only",
              "Ordinary packaging helper/comment/freshness assertion/controls only"],
    "static_guards": {
        "source_bytes_equal_Git8a": True,
        "all_other_packaging_function_ASTs_unchanged": True,
        "all_existing_assertions_retained_except_local_tag_max_authority": True,
        "removed_assertion": ast.get_source_segment(old["tests/test_packaging.py"].decode(), removed_node),
        "original_test_node_names_preserved_no_new_nodes": True,
        "STATE_only_single_version_row_replaced": True,
        "public_CLI_Action_ledger_README_doctor_hook_bytes_not_modified": True,
        "proposed_python_AST_parse": "STATIC_PARSE_ONLY_NOT_EXECUTION",
    },
    "controls_not_executed": [
        "Real trusted tag+pin must match explicit verified advertised tag+commit",
        "Synthetic local v0.9.1 and v0.10.0 cannot promote themselves over ledger v0.9.0",
        "Same verified tag with wrong SHA must reject",
        "Advanced synthetic reviewed ledger v0.9.1 accepts v0.9.1 and rejects stale v0.9.0",
        "Existing trusted_version <= development candidate version assertion retained",
    ],
    "expected_movement": "STATIC_PREDICTION_ONLY: remove the two identified metadata/freshness failures; targeted tests are NOT_RUN",
    "required_targeted_nodes": [
        "tests/test_state_claims.py::test_version_row_matches_package",
        "tests/test_packaging.py::test_readme_action_snippet_is_zizmor_blanket",
        "tests/test_packaging.py::test_version_matches_pyproject",
        "tests/test_packaging.py::test_readme_install_refs_match_advertised_release",
        "tests/test_published_source.py::test_advertised_manifest_records_publication_receipt_identity",
        "tests/test_published_source.py::test_state_separately_labels_published_release_identity",
    ],
    "original_failure_evidence": "work/ux-stage4/final/full-suite-311-r1/junit.xml",
    "original_triage": "work/ux-stage4/full-suite-extra-triage/triage.json",
}
for rel, data in old.items():
    assert (REPO / rel).read_bytes() == data, rel
assert git("rev-parse", "HEAD").decode().strip() == SOURCE
assert not git("status", "--porcelain").strip()
write("validation.json", (json.dumps(validation, ensure_ascii=False, indent=2) + "\n").encode())
print(json.dumps({"status": validation["status"], "patch_sha256": h(patch),
                  "patch_bytes": len(patch), "changed_product_files": 0,
                  "static_assertion_preservation": True, "targeted_tests": "NOT_RUN"}))

