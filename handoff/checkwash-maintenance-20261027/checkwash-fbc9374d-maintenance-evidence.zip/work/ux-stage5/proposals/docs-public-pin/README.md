# STATE development version / verified-public Action freshness

**INERT_NOT_APPLIED_NOT_IMPORTED_NOT_EXECUTED_NOT_ACCEPTED**

這是 root 指定的兩項 metadata/test-contract 提案，基準為 frozen **8a8941dc2d7c581715a0f6f196c00da6c55f084b**。所有新增檔案只在 work/ux-stage5/proposals/docs-public-pin/；沒有寫 stage4、產品 checkout 或原始收據。不是版本發布、gate 豁免或驗收 PASS。PJU 標記：HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL；1.0 前仍須停問。

## 精確差異

docs-public-pin.patch 原始 **LF bytes 3794 B**，SHA256：

f34fe192d900fff22881ffc42d0dbcdba8afe20a2536a79263be40e32d3570ab

只涉及兩個檔：

1. STATE.md：唯一權威 development version row 由 v0.9.1 改為 v0.10.0。last published CLI、commit 等原列不變。
2. tests/test_packaging.py：Action freshness 使用既有 release/advertised.toml 的 release.tag 與 release.commit。移除「本機最大的 prior semantic tag 等於 trusted tag」的錯誤判準，修正旁邊過時的 lag-one-release 註解。抽出普通測試 helper 驗證 tag 與 commit，失配會 fail，沒有缺檔 fallback、skip、return 或放寬 pin。

既有依據：release/advertised.toml 說明已驗證發布紀錄並綁 docs/releases/v0.9.0-publication-verification.md；docs/RELEASING.md:1004–1020 要求 newest verified release，STATE.md:3116–3120 明確分開 development 與 published identity。這不是新增 ledger 或相信所有本機 tags。公開身份維持 **v0.9.0 / d6eda4f695fabb8e7d138f7a87b099d2028f0294**，未發布 v0.9.1 tag 不刪不改。

## 保留的判準與控制

prepare_proposal.py 只用 stdlib 讀取、組字串、difflib 與 AST 靜態比較。驗證原 Action test 中**除了 local-tag-max 判準之外，每一條既有 assert AST 都保留**；其他既有 packaging functions AST 完全不變。特別保留：

- permissions / persist-credentials 與每個 uses 的 40-SHA lint。
- trusted tag 的本機 Git peeled commit，README pin 與該 SHA 相同。
- README、自我檢查 workflow、doctor _PINS 與三個 uses 的 parity。
- trusted_version 不可大於 candidate version。
- README 既有自身 SHA 說明、Action doc remote-tag 查證指令斷言。
- 此外新增 trusted pin 必須與 verified advertised commit 相同。

README、Action 文件／workflow、doctor、hook manifest、advertised ledger、src 與 pyproject 原 bytes 沒有變動。沒有 fixture/expected/gates 修改。

負控放在原 test_readme_action_snippet_is_zizmor_blanket 節點內，因此沒有新增 pytest nodes，也不需要因這份提案捏造新 collection count：

- 合成 peeled local-tag lookup table 同時列 v0.9.0、未發布 v0.9.1、candidate v0.10.0。ledger 仍指090時，090接受，091/010都必須拒絕。
- 同一個 verified tag 配錯 SHA 必須拒絕。
- 合成「ledger 已經經過審查而前進到091」情境，091接受、舊090必須拒絕，防止永久硬鎖090。

這些是**提案中的合成單元控制，尚未執行**，不是實際建立 Git tag、查網路或聲稱真的已發布091。實際 repo 的既有 Git peel 斷言仍照原樣存在。

## 後續驗證節點（全部 NOT_RUN）

Root 完成8a原始完整備份後，若決定採納，先在新 revision 執行：

- tests/test_state_claims.py::test_version_row_matches_package
- tests/test_packaging.py::test_readme_action_snippet_is_zizmor_blanket
- tests/test_packaging.py::test_version_matches_pyproject
- tests/test_packaging.py::test_readme_install_refs_match_advertised_release
- tests/test_published_source.py::test_advertised_manifest_records_publication_receipt_identity
- tests/test_published_source.py::test_state_separately_labels_published_release_identity

該 Action test node 本身包含全部新正反控制，無須獨立新 node。新 source 的完整必過驗證依原契約執行，本提案不替代它。修後兩個既有失敗消失是**靜態預測**；未稱改後 PASS。#567、其他 corpus/finding 成本、兩個 selfdogfood high、full-suite 非通過結果均不受此提案解除。

## 保全

validation.json 保存 frozen Git/source 與 proposed bytes hashes、唯一移除的 assert、靜態 AST guard、需跑節點與 NOT_RUN 狀態。proposed-test_packaging.py.txt 是便於閱讀的完整文字草案，沒有 import/compile/run。prepare_proposal.py 的執行只構造提案，exit0 不是產品驗證。

原失敗來源：work/ux-stage4/final/full-suite-311-r1/junit.xml；只讀分流：work/ux-stage4/full-suite-extra-triage/triage.json。本次產品呼叫、pytest 呼叫、subject execution 均為 **0**。

