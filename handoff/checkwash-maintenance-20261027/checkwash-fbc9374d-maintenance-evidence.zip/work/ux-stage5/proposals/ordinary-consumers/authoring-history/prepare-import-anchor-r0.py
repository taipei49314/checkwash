"""Build inert consumer-test diffs from sealed 8a bytes, never apply or execute."""
import difflib
import hashlib
import json
from pathlib import Path
import platform
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
SOURCE = ROOT / "work/checkwash-ux"
PIN = "8a8941dc2d7c581715a0f6f196c00da6c55f084b"
seal = json.loads((ROOT / "work/ux-stage4/seal/source-seal.json").read_text(encoding="utf-8"))
assert seal["source_sha"] == PIN
sealed = {row["path"]: row["sha256"] for row in seal["files"]}
records = []


def sha(data):
    return hashlib.sha256(data).hexdigest()


def load(path):
    raw = (SOURCE / path).read_bytes()
    assert sha(raw) == sealed[path] and b"\r\n" not in raw
    return raw.decode("utf-8")


def replace_once(text, old, new):
    assert text.count(old) == 1, old[:80]
    return text.replace(old, new)


def proposal(name, changes):
    parts, files = [], []
    for path, before, after in changes:
        assert before != after and before == load(path)
        for label, text in (("base", before), ("proposed", after)):
            destination = HERE / name / label / path
            destination.parent.mkdir(parents=True, exist_ok=True)
            assert not destination.exists()
            destination.write_text(text, encoding="utf-8", newline="\n")
        parts.append("".join(difflib.unified_diff(before.splitlines(keepends=True), after.splitlines(keepends=True),
                                               fromfile="a/" + path, tofile="b/" + path)))
        files.append({"path": path, "base_sha256": sha(before.encode()), "proposed_sha256": sha(after.encode()),
                      "base_physical_newlines": "LF", "proposed_physical_newlines": "LF"})
    patch = HERE / (name + ".patch")
    assert not patch.exists()
    patch.write_text("".join(parts), encoding="utf-8", newline="\n")
    records.append({"name": name, "patch": patch.name, "patch_sha256": sha(patch.read_bytes()), "files": files,
                    "state": "INERT_NOT_APPLIED_NOT_EXECUTED"})


path = "tests/test_classic_raises_additions.py"
base = load(path)
after = replace_once(base, "import pytest\n", "from dataclasses import fields\nimport re\n\nimport pytest\n")
after = replace_once(after, "    assert preserved.after == original.side\n", '''    # D-179 enriches engine IR after the standalone frontend returns its side.
    # Preserve every native field, and check enrichment separately without
    # deleting or blanking the new authority fields on either object.
    enrichment = {"oracle_context", "oracle_assertion_contexts"}
    native_fields = [field.name for field in fields(original.side) if field.name not in enrichment]
    assert len(native_fields) == 17
    assert {name: getattr(preserved.after, name) for name in native_fields} == {
        name: getattr(original.side, name) for name in native_fields
    }
    assert original.side.oracle_context == ""
    assert original.side.oracle_assertion_contexts == {}
    assert re.fullmatch(r"[0-9a-f]{64}", preserved.after.oracle_context)
    assert original.side.param_cases == 4
    expected_keys = {f"{assertion.id}@{row}" for assertion in original.side.assertions
                     for row in range(original.side.param_cases)}
    assert set(preserved.after.oracle_assertion_contexts) == expected_keys
    assert all(re.fullmatch(r"[0-9a-f]{64}", value)
               for value in preserved.after.oracle_assertion_contexts.values())
''')
proposal("01-ir3-native-side-enrichment", [(path, base, after)])

path = "tests/test_root_oracles.py"
base_root = load(path)
old = '''    # `test_helpers.py` is itself a test module the diff changes, so the
    # conftest above it is read (#223); the unchanged importer reads none.
    assert reads == ["tests/test_calc.py", "conftest.py", "tests/calc.py", "tests/test_helpers.py",
                     "test_helpers/__init__.py", "tests/test_helpers/__init__.py"]
'''
new = '''    # The original helper/oracle reads retain their order. D-179 separately
    # inspects startup for the unchanged importer's optional context proof;
    # those probes must not add a detector skip to that unchanged importer.
    oracle_reads = ["tests/test_calc.py", "conftest.py", "tests/calc.py", "tests/test_helpers.py",
                    "test_helpers/__init__.py", "tests/test_helpers/__init__.py"]
    startup_probes = ["tests/conftest.py", "tests/__init__.py", "__init__.py"]
    assert reads == oracle_reads + startup_probes
    assert not any(f.rule == "TEST_DISABLED" for f in findings)
'''
after_root = replace_once(base_root, old, new)
anchor = '\n\ndef test_helper_only_change_does_not_claim_unchanged_importer_is_out_of_scope():\n'
addition = '''

def test_startup_probe_does_not_add_a_detector_skip_to_an_unchanged_importer():
    conftest = (b"import pytest\\n@pytest.fixture(autouse=True)\\n"
                b"def skip_all():\\n    pytest.skip('existing startup')\\n")
    (_ir, findings, verdict), _searches, reads = helper_only_change(
        b"def assert_equal(actual, expected):\\n    pass\\n",
        {"tests/test_calc.py": AFTER, "tests/conftest.py": conftest},
    )
    assert verdict == "block"
    assert any(f.rule == "ASSERT_REMOVED" and f.path == "tests/test_calc.py" and f.severity == "high"
               for f in findings)
    assert not any(f.rule == "TEST_DISABLED" for f in findings)
    assert reads.count("tests/conftest.py") == 1
'''
after_root = replace_once(after_root, anchor, addition + anchor)

path223 = "tests/test_issue223_conftest_request_side.py"
base223 = load(path223)
after223 = replace_once(base223,
    '    """A root helper\'s importer joins the analysis unchanged: no module the diff changes (D-093 7)."""\n',
    '    """D-093 detector attribution stays unchanged; D-179 startup probes are separate."""\n')
old = '''    assert any(f.rule == "ASSERT_REMOVED" and f.path == TEST for f in findings)
    # The helper is itself a module the diff changes (`test_*.py`), so the
    # root level is read for it; the importer's own level is not.
    assert TEST in reads and [path for path in reads if path.endswith("conftest.py")] == ["conftest.py"]
'''
new = '''    assert any(f.rule == "ASSERT_REMOVED" and f.path == TEST for f in findings)
    assert any(f.rule == "ASSERT_REMOVED" and f.path == TEST and f.severity == "high" for f in findings)
    # The changed helper's ordinary chain reads root conftest.py. Optional
    # D-179 proof then probes the importer's startup without attaching new
    # detector skip semantics to that unchanged module.
    startup_probes = ["tests/conftest.py", "tests/__init__.py", "__init__.py"]
    assert TEST in reads and reads[-3:] == startup_probes
    assert [path for path in reads if path.endswith("conftest.py")] == ["conftest.py", "tests/conftest.py"]
    assert not any(f.rule == "TEST_DISABLED" for f in findings)
'''
after223 = replace_once(after223, old, new)
proposal("02-startup-probe-observers", [("tests/test_root_oracles.py", base_root, after_root),
                                         (path223, base223, after223)])

path = "tests/test_js_test_obligations.py"
base = load(path)
after = replace_once(base, "from checkwash.ir.model import FileIR, judged_as_test\n",
                     "from checkwash.ir.model import FileIR, judged_as_test\nfrom checkwash.gitio.snapshot import search_source_mapping\n")
anchor = '\n\ndef _summary(findings):\n'
helper = '''

def _closed_move(old, new, before, after, producers):
    # A complete owned head snapshot; explicit change bytes supply BASE.
    snapshot = {**producers, new: after}
    return analyze(
        [FileChange(new, "modified", before, after, old_path=old)],
        Config(), Contract(), [], datetime.date(2026, 10, 3),
        head_reader=snapshot.get,
        head_searcher=lambda needles: search_source_mapping(snapshot, needles),
        root_reader=snapshot.get,
        root_searcher=lambda needles: search_source_mapping(snapshot, needles),
        root_path_lister=lambda: sorted(snapshot),
        root_batch_reader=lambda paths: {path: snapshot.get(path) for path in paths},
    )
'''
after = replace_once(after, anchor, helper + anchor)
old = '''    # v0.5.0 read the old path as a deleted workflow that ran tests and
    # blocked. Only YAML there is a workflow (197.Q5), and the units arrive
    # intact at the new path.
    old, new = ".github/workflows/value.test.ts", "src/value.test.ts"
    _ir, findings, verdict = _analyze([FileChange(new, "modified", BEFORE, BEFORE, old_path=old)])
    assert verdict == "pass"
    assert ("CI_WORKFLOW_TOUCHED", "warn", None) in _summary(findings)
    assert all(finding.severity in ("warn", "info") for finding in findings)
'''
new = '''    # Only YAML is a workflow (197.Q5). Preserve the canonical producer
    # while the test leaves CI: unchanged './value' would resolve elsewhere.
    old, new = ".github/workflows/value.test.ts", "src/value.test.ts"
    moved = BEFORE.replace(b'"./value"', b'"../.github/workflows/value"')
    producers = {".github/workflows/value.ts": b"export function total() { return 78.75; }\\n"}
    _ir, findings, verdict = _closed_move(old, new, BEFORE, moved, producers)
    assert verdict == "pass"
    assert ("CI_WORKFLOW_TOUCHED", "warn", None) in _summary(findings)
    assert all(finding.severity in ("warn", "info") for finding in findings)


def test_ci_test_move_with_a_different_relative_producer_keeps_blocking():
    old, new = ".github/workflows/value.test.ts", "src/value.test.ts"
    producers = {".github/workflows/value.ts": b"export function total() { return 78.75; }\\n",
                 "src/value.ts": b"export function total() { return 0; }\\n"}
    _ir, findings, verdict = _closed_move(old, new, BEFORE, BEFORE, producers)
    assert verdict == "block"
    assert any(f.rule == "TEST_DISABLED" and f.severity == "high" for f in findings)
    assert ("CI_WORKFLOW_TOUCHED", "warn", None) in _summary(findings)
    assert not any("ASSERTION_MOVED" in f.deescalators for f in findings if f.rule == "TEST_DISABLED")
'''
after = replace_once(after, old, new)
proposal("03-ci-test-same-producer", [(path, base, after)])

record = {"state": "INERT_NOT_APPLIED_NOT_EXECUTED", "base_source": PIN,
          "provenance": "HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL", "host": platform.node(), "runtime": sys.version,
          "prerequisite": "Root must confirm complete remote 8a backup before adopting or validating any proposal.",
          "proposals": records, "product_calls": 0, "pytest_calls": 0, "compile_calls": 0,
          "shared_source_modified": False,
          "excluded_positive_expectations_unchanged": ["active JS describe", "issue263 class/string-mark move", "issue358 own-mark fixture move"],
          "golden_or_protected_files_changed": []}
(HERE / "proposal-manifest.json").write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"state": record["state"], "patches": [{"name": row["patch"], "sha256": row["patch_sha256"]}
                                                         for row in records]}, indent=2))
