# Inert ordinary-consumer proposals

State: **NOT APPLIED / NOT EXECUTED**. Product, pytest and compile calls: zero.
The base is the sealed `8a8941dc2d7c581715a0f6f196c00da6c55f084b`.
Root must first confirm that the complete failed 8a packet is backed up remotely
before adopting or validating any proposal. These files grant no waiver and
do not turn the 22-failure full-suite receipt into a passing result.

The stage4 eight-row triage is frozen separately. This directory contains
three atomic diffs and exact base/proposed file bytes for review. All four
target test files have physical LF newlines; patch and proposed bytes are LF
as well. `proposal-manifest.json` records actual raw hashes, not normalized
hashes mislabeled as physical bytes. No product implementation, protected
contract/gate or `.gwcase` file is included.

## 01 — IR3 native side versus engine enrichment

`01-ir3-native-side-enrichment.patch` only changes the existing classic-raises
ordinary consumer. Its two parameter cases retain the earlier exception
evidence, BLOCK and ASSERT_REMOVED assertions. Every one of the 17 native
UnitSide fields remains exactly equal to the standalone frontend result.
The two new authority fields are not deleted, reset or hidden: the proposal
separately checks their engine enrichment, the standalone parser's unknown
defaults, a SHA256 unit context, exactly four concrete-row keys per native
assertion and SHA256 assertion-context values.

This is a consumer schema migration, not a proposed change to oracle identity,
the frontend, severity, fingerprints or the original exception finding.

## 02 — separate startup probes from detector attribution

`02-startup-probe-observers.patch` changes only the two reader-observer units
and adds one semantic control in `test_root_oracles.py`.

The original oracle read prefix stays exact. D-179's additional probes are
separately named as `tests/conftest.py`, `tests/__init__.py`, `__init__.py`.
Original BLOCK, ASSERT_REMOVED path/text/high and search assertions remain.
The issue223 unit additionally checks high explicitly (it did not previously
measure severity), retains the exact conftest read list and checks that proof
probes do not create a detector TEST_DISABLED event on the unchanged importer.

The new autouse-skip startup control requires the original helper-removal
finding to stay high/BLOCK and forbids a newly attributed TEST_DISABLED event.
It also requires one cached startup conftest read. The ordinary detector's
changed-module chain boundary is not replaced with a blanket allowance for
all reads.

All existing refusal/budget controls remain byte-for-byte outside the hunks,
including:

- root oracle reverse-search/sibling/read-budget controls;
- issue223 `test_past_the_read_limit_is_an_engine_error`;
- issue223 `test_past_the_byte_limit_is_an_engine_error`;
- issue223 `test_a_reader_that_returns_no_bytes_is_an_engine_error`;
- existing conftest-side, nearest-definition, skip attribution and read-once
  controls.

The exact new probe sequence and new autouse control are source-based
predictions, **not measured green results**. Root must verify them after the
backup/adoption boundary; unexpected results remain data and must not be
handled by deleting these controls.

## 03 — a CI move that preserves its producer

`03-ci-test-same-producer.patch` preserves the existing positive's expected
PASS, CI_WORKFLOW_TOUCHED/warn and no high findings. It changes that one
fixture's destination relative import to `../.github/workflows/value`, so
both sides name the original `.github/workflows/value` producer. A complete
owned source mapping supplies explicit regular head/root readers, inventory
and batch/search adapters; explicit FileChange bytes supply BASE. The shared
BEFORE/AFTER constants and the rest of the role matrix are unchanged.

The old identical `./value` spelling is retained in a separate new negative
that supplies different producer files. It must BLOCK with a high removed-test
finding, keep the CI role warning, and obtain no ASSERTION_MOVED compensation.
This isolates the original CI-role purpose without erasing relative-import
identity or granting a blanket move exemption. Producer fixture programs are
data and must not be executed.

## Scope deliberately left unresolved

The active-describe, issue263 class/string-mark and issue358 own-mark-fixture
positive expectations are untouched. They require bounded safe-proof work or
maintainer disposition; this proposal does not flip them to BLOCK for green.
The eight immutable golden expectations, corpus gates, other additional full
suite failures and release acceptance are separate outstanding work.

The two new independent controls also create a collection-metadata dependency.
Their static proposed delta is +2 parent nodes; no new collection was run.
After adoption on a new source, root must collect the actual full denominator
and then synchronize README.md:359, CONTRIBUTING.md:66 and
docs/launch.md:68/289 together with
`tests/test_packaging.py::test_documented_test_count_is_accurate`.
The currently sealed 21102 prose is not edited here, and 21104 is not recorded
as an observed count. `adoption-dependencies.json` makes this dependency
machine-readable. Other next-stage changes may change the actual denominator
again, so the static delta cannot substitute for collection.

After root's explicit backup confirmation and adoption, the proposed validation
scope is the four affected ordinary modules with their existing negative/budget
controls, followed by final-source checks appropriate to the resulting change.
Nothing in this directory records that validation as performed. Any adopted
revision and actual run must get a new source/run identity; none may reuse the
8a full-suite receipt as a PASS receipt.

## Authoring provenance

The first string-only generator attempt stopped before creating any patch:
its defensive unique-import anchor matched both a module import and fixture
text. It returned exit 1. The original generator bytes are preserved under
`authoring-history/prepare-import-anchor-r0.py`; the anchor was narrowed to the
module import block and the generator then returned exit 0. This was an
external proposal-authoring failure, not a product/test execution or a hidden
qualification retry. The proposed tests themselves have not been parsed,
compiled, imported, applied or executed by this agent.
