"""Hash the inert proposal packet; no product imports/apply/compile/tests."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
SOURCE = ROOT / "work/checkwash-ux"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


proposals = json.loads((HERE / "proposal-manifest.json").read_text(encoding="utf-8"))
assert proposals["base_source"] == "8a8941dc2d7c581715a0f6f196c00da6c55f084b"
assert proposals["state"] == "INERT_NOT_APPLIED_NOT_EXECUTED"
targets = set()
for proposal in proposals["proposals"]:
    assert sha(HERE / proposal["patch"]) == proposal["patch_sha256"]
    for member in proposal["files"]:
        name = member["path"]
        assert name.startswith("tests/test_") and name.endswith(".py") and ".gwcase" not in name
        targets.add(name)
        assert sha(SOURCE / name) == member["base_sha256"]
        assert sha(HERE / proposal["name"] / "base" / name) == member["base_sha256"]
        assert sha(HERE / proposal["name"] / "proposed" / name) == member["proposed_sha256"]
        assert b"\r\n" not in (HERE / proposal["patch"]).read_bytes()
assert len(targets) == 4
seal = json.loads((ROOT / "work/ux-stage4/seal/source-seal.json").read_text(encoding="utf-8"))
sealed = {row["path"]: row["sha256"] for row in seal["files"]}
for name in ("tests/test_js_liveness.py", "tests/test_issue263_string_conditions.py", "tests/test_issue358_own_mark_guards.py"):
    assert sha(SOURCE / name) == sealed[name] and name not in targets

stage4 = ROOT / "work/ux-stage4/qualification/fullsuite-triage"
assert sha(stage4 / "MANIFEST.json") == "14bd645de7fa96e855e81077512018b1e772fba06df8c637677aee17e1cb9d0a"
old = json.loads((stage4 / "MANIFEST.json").read_text(encoding="utf-8"))
for name, digest in old["members"].items():
    assert sha(stage4 / name) == digest
assert sha(ROOT / "work/ux-stage4/final/full-suite-311-r1/independent-readback.json") == "89ee94bc17caec0b79a80834fed1228643e68eb61cf7f01879bb40e329f5b177"

members = {path.relative_to(HERE).as_posix(): sha(path) for path in sorted(HERE.rglob("*"))
           if path.is_file() and path.name != "MANIFEST.json"}
record = {"state": "FROZEN_INERT_PROPOSALS_NOT_APPLIED_NOT_EXECUTED",
          "base_source": proposals["base_source"], "members": members,
          "product_calls": 0, "pytest_calls": 0, "compile_calls": 0,
          "source_target_files_unchanged": True, "excluded_three_positive_files_unchanged": True,
          "stage4_manifest_sha256": sha(stage4 / "MANIFEST.json"),
          "stage4_all_40_member_hashes_unchanged": len(old["members"]) == 40,
          "adoption_prerequisite": "Root confirms complete remote failed-8a backup before adoption/validation.",
          "collection_dependency": "Static proposed +2 only; actual next-source collection is NOT_RUN and prose must follow actual count."}
destination = HERE / "MANIFEST.json"
assert not destination.exists()
destination.write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"state": record["state"], "members": len(members),
                  "manifest_sha256": sha(destination), "readme_sha256": sha(HERE / "README.md"),
                  "proposal_manifest_sha256": sha(HERE / "proposal-manifest.json"),
                  "review_sha256": sha(HERE / "independent-review.json")}, indent=2))
