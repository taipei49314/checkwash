"""Derive new controller locations; original stage4 controls stay immutable."""
import hashlib
import json
from pathlib import Path

here = Path(__file__).resolve().parent
prior = here.parent / "ux-stage4"
records = []
for name in ("capture.py", "capture_final.py", "seal_source.py", "build_pyz.py", "qualify_one.py"):
    raw = (prior / name).read_bytes()
    text = raw.decode("utf-8")
    if name == "capture.py":
        text = text.replace("Record stage-4 local test commands", "Record stage-5 maintenance development snapshots")
        text = text.replace('"cw566-s4-"', '"cw566-s5-"')
        marker = "started = datetime.now(timezone.utc).isoformat()"
        assert text.count(marker) == 1
        text = text.replace(marker, 'safe_basetemp = temporary / "p"\nassert not safe_basetemp.exists()\na.command = [str(safe_basetemp) if arg == "__PJU_BASETEMP__" else arg for arg in a.command]\n' + marker)
        text = text.replace("source_sha=head, ending_sha=", 'validation_kind="WORKING_TREE_DEVELOPMENT_NOT_COMMIT_QUALIFICATION",\n              source_sha=head, ending_sha=')
    if name == "capture_final.py":
        text = text.replace('"cwf4-"', '"cwf5-"')
    target = here / name
    assert not target.exists()
    target.write_bytes(text.encode("utf-8"))
    records.append({"name": name, "prior_sha256": hashlib.sha256(raw).hexdigest(),
                    "derived_sha256": hashlib.sha256(target.read_bytes()).hexdigest()})
(here / "controller-copy-record.json").write_text(json.dumps(records, indent=2), encoding="utf-8")
print(json.dumps(records, indent=2))
