"""Launch the frozen zipapp qualifier with no source-import environment fallback."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

here = Path(__file__).resolve().parent
tool = here.parents[0] / "checkwash-ux" / "tools" / "qualify_zipapp.py"
artifact = here / "artifacts" / "checkwash.pyz"
env = dict(os.environ)
env.pop("PYTHONPATH", None)
env.pop("PYTHONHOME", None)
before = hashlib.sha256(artifact.read_bytes()).hexdigest()
command = [str(Path(sys.executable).absolute()), "-I", "-B", "-X", "utf8", str(tool), str(artifact)]
print(json.dumps({"phase": "launch", "command": command, "artifact_sha256": before,
                  "qualifier_sha256": hashlib.sha256(tool.read_bytes()).hexdigest(),
                  "source_pythonpath_removed": True, "source_pythonhome_removed": True}), flush=True)
with tempfile.TemporaryDirectory(prefix="pyz-process-smoke-") as temporary:
    result = subprocess.run(command, cwd=temporary, env=env)
after = hashlib.sha256(artifact.read_bytes()).hexdigest()
print(json.dumps({"phase": "complete", "exit_code": result.returncode,
                  "artifact_sha256": after, "artifact_unchanged": before == after,
                  "formal_check_runs": 0}), flush=True)
if before != after:
    raise SystemExit(3)
raise SystemExit(result.returncode)

