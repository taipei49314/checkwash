# Maintenance continuation backup / restore map

Extract into a new task workspace root, preserving `work/ux-stage5/` and
`work/trusted/`. Copy the four explicit BUNDLE-TOOLS controller files to
`work/ux-stage5/checkpoint-pack/` before reusing them; do not flatten the
remaining task layout. Output folders and controller-generated files are absent.

Create a clean Git checkout at `work/checkwash-ux`. Fetch exact current
`fbc9374dc3bcbfc47f403aec0c36e6b51dd7b86c`, baseline `1ffe283d7d947fecc426dea99323b0a2620a9482`, and the prior comparison source
`8a8941dc2d7c581715a0f6f196c00da6c55f084b`. The source ZIP preserves bytes;
extracting it alone does not supply those Git objects or history.
For a fresh Windows checkout use clone --no-checkout, then task-local
core.autocrlf=false/core.eol=lf (or both -c settings on checkout). Do not
change host-global Git configuration. Verify every tracked member's bytes,
SHA256 and Git blob identity against this stage5 source-seal, not merely
HEAD or clean status. Recreate local runtimes from retained dependency receipts.

This is a current maintenance-source continuation subset, not a self-contained
replay of all history. Prior 8a artifacts and five backup ZIPs remain separate
and unchanged. Historical proposals, failed runs, NO_CAPTURED/NOT_REACHED,
RUNNING/NOT_RUN and unresolved golden/semantic costs retain their status.
Only actual terminal receipts establish outcomes; packing does not turn a
failed full suite into PASS or authorize merge, publication, tags or version1.0.
A partial remote checkpoint is a status backup, never this complete bundle.

ZIP timestamps/modes are fixed, paths sorted, Deflate9 used. Same inputs,
controller and Python/zlib runtime yield the same bytes. Privacy checks are
bounded, not a universal secret-free assurance. Backup time is not a product
release deadline.
