"""Publish one reviewed maintenance backup snapshot without moving product refs.

Default: validate and write a local plan using read-only Git.
Only --publish --expect-plan-sha256 <reviewed digest> enables Git object writes
and a normal non-force push to the single fixed handoff branch.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import sys
import zipfile

HERE = Path(__file__).resolve().parent
STAGE = HERE.parent
SESSION = STAGE.parents[1]
REPO = SESSION / "work/checkwash-ux"
PAYLOAD = SESSION / "outputs/checkwash-maintenance-followup-20261027"
SOURCE = "fbc9374dc3bcbfc47f403aec0c36e6b51dd7b86c"
LEGACY_SOURCE = "8a8941dc2d7c581715a0f6f196c00da6c55f084b"
LAST_VERIFIED_LEGACY = "d158ec02aac9c0c19751d0475f935b533e3d03f7"
BRANCH = "handoff/core-010-pju-20261027-8a8941dc"
PREFIX = "handoff/checkwash-maintenance-20261027"
LEGACY_START = "handoff/checkwash-core-010-20261027/00-START-HERE.md"
BUNDLE = "checkwash-fbc9374d-maintenance-evidence.zip"
SOURCE_ZIP = "source-fbc9374d.zip"
PURPOSE = "BACKUP_ONLY_NOT_ACCEPTANCE_NOT_RELEASE"
ROLES = ("qualification_source", "qualification_wheel", "qualification_pyz", "full_suite")
SUFFIXES = {".zip", ".json", ".md", ".txt", ".patch", ".sha256"}
STATE_PATH = HERE / "remote-state.json"
LEGACY_STATE = SESSION / "work/ux-stage4/remote-checkpoint/state.json"
BANNER = (
    "> **後續 maintenance 交接入口：source " + SOURCE + "**\n"
    "> [開啟後續交接](../checkwash-maintenance-20261027/00-START-HERE.md)。\n"
    "> 此連結只接續備份；partial 不代表完整證據包，也不代表產品驗收或發布。\n"
    "> 下方 8a 歷史正文逐 byte 保留；1.0 前仍須 Nelson 明確決定。\n\n"
    "---\n\n"
).encode("utf-8")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def encoded(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def save(path, value):
    path.write_bytes(encoded(value))


def logical(name):
    require(isinstance(name, str) and bool(name), "empty/non-text payload path")
    require(not name.startswith(("/", "\\")) and "\\" not in name and ":" not in name,
            "absolute, backslash or ADS path")
    parts = name.rstrip("/").split("/")
    require(all(part not in ("", ".", "..") and not any(ord(c) < 32 for c in part)
                for part in parts), "unsafe path component")
    reserved = {"CON", "PRN", "AUX", "NUL"} | {f"COM{i}" for i in range(1, 10)} | {f"LPT{i}" for i in range(1, 10)}
    require(all(not part.endswith((" ", ".")) and part.split(".")[0].upper() not in reserved
                for part in parts), "unsafe Windows restore component")
    require(not PurePosixPath(name).is_absolute(), "absolute path")
    return name


def ordinary(path):
    info = path.lstat()
    require(not stat.S_ISLNK(info.st_mode) and not getattr(info, "st_file_attributes", 0) & 0x400,
            "link/reparse input refused")
    return info


class Git:
    def __init__(self, output):
        self.output = output
        self.write_enabled = False
        self.commands = []
        self.env = {k: v for k, v in os.environ.items() if not k.upper().startswith("GIT_")}
        # Invocation-only overrides; user credential configuration remains usable.
        self.common = ["git", "--no-optional-locks", "-c", "core.fsmonitor=false",
                       "-c", "core.hooksPath=" + str(output / "no-hooks"),
                       "-c", "remote.origin.mirror=false",
                       "-c", "commit.gpgsign=false"]

    def run(self, *args, data=None, alternate=None, writes=False, timeout=60):
        require(not writes or self.write_enabled, "Git writes disabled in plan mode")
        env = dict(self.env)
        if alternate is not None:
            env.update(GIT_INDEX_FILE=str(alternate),
                       GIT_AUTHOR_NAME="Codex maintenance checkpoint",
                       GIT_AUTHOR_EMAIL="checkpoint@example.invalid",
                       GIT_COMMITTER_NAME="Codex maintenance checkpoint",
                       GIT_COMMITTER_EMAIL="checkpoint@example.invalid")
        command = self.common + list(args)
        result = subprocess.run(command, cwd=REPO, env=env, input=data,
                                capture_output=True, timeout=timeout)
        self.commands.append({"command": command, "exit_code": result.returncode,
                              "stdout_bytes": len(result.stdout), "stderr_bytes": len(result.stderr),
                              "stdout_sha256": digest(result.stdout), "stderr_sha256": digest(result.stderr),
                              "git_writes": writes})
        save(self.output / "git-commands.json", self.commands)
        if args and args[0] == "push":
            # Local recovery evidence only; not an automatic public payload.
            (self.output / "push.stdout").write_bytes(result.stdout)
            (self.output / "push.stderr").write_bytes(result.stderr)
        require(result.returncode == 0, "Git failed; inspect local command/push receipts")
        return result.stdout


def source_guard(git):
    require((STAGE / "final-source-sha.txt").read_text(encoding="utf-8").strip() == SOURCE,
            "stage5 source PIN changed")
    require(git.run("rev-parse", "HEAD").decode().strip() == SOURCE, "product HEAD changed")
    index = Path(git.run("rev-parse", "--git-path", "index").decode().strip())
    if not index.is_absolute():
        index = REPO / index
    require(stat.S_ISREG(ordinary(index).st_mode), "nonregular product index")
    index_raw = index.read_bytes()
    require(not git.run("status", "--porcelain=v1", "-z", "--untracked-files=all"),
            "product checkout is not clean")
    seal_raw = (STAGE / "seal/source-seal.json").read_bytes()
    seal = json.loads(seal_raw)
    require(seal["source_sha"] == SOURCE and seal["all_tracked_bytes_match_git"],
            "unexpected stage5 seal")
    rows = seal["files"]
    require(len(rows) == seal["tracked_files"] == 3084, "unexpected sealed source member count")
    tracked = set(git.run("ls-files", "-z").decode("utf-8").rstrip("\0").split("\0"))
    require(tracked == {row["path"] for row in rows}, "tracked source membership changed")
    observed = []
    for row in rows:
        name = logical(row["path"])
        path = REPO.joinpath(*PurePosixPath(name).parts)
        require(stat.S_ISREG(ordinary(path).st_mode), "nonregular source member")
        raw = path.read_bytes()
        require(len(raw) == row["bytes"] and digest(raw) == row["sha256"], "source bytes differ from seal")
        blob = hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
        require(blob == row["git_blob"] == row["actual_git_blob"], "source Git blob differs from seal")
        observed.append({"path": name, "bytes": len(raw), "sha256": digest(raw)})
    archive = STAGE / "seal" / Path(str(seal["source_archive"]).replace("\\", "/")).name
    require(digest(archive.read_bytes()) == seal["archive_sha256"], "sealed source ZIP changed")
    refs = git.run("for-each-ref", "--format=%(refname) %(objectname)", "refs/heads/main", "refs/tags")
    require(index.read_bytes() == index_raw, "read-only preflight changed product index bytes")
    return ({"source_sha": SOURCE, "tracked_files": 3084, "source_digest": digest(encoded(observed)),
             "seal_sha256": digest(seal_raw), "source_archive_sha256": seal["archive_sha256"],
             "product_index_sha256": digest(index_raw), "local_main_tags_sha256": digest(refs)},
            index_raw)


def parent_snapshot(git):
    if STATE_PATH.is_file():
        previous = json.loads(STATE_PATH.read_bytes())
        require(previous["source_sha"] == SOURCE and previous["branch"] == BRANCH
                and previous["remote_ref_verified"], "unverified stage5 remote state")
        parent = previous["checkpoint_commit"]
        origin = "stage5 publisher last verified receipt"
    else:
        previous = json.loads(LEGACY_STATE.read_bytes())
        require(previous["checkpoint_commit"] == LAST_VERIFIED_LEGACY
                and previous["branch"] == BRANCH and previous["remote_ref_verified"],
                "legacy verified baseline changed; reconcile explicitly")
        require(previous.get("code_source_sha", previous.get("source_sha")) == LEGACY_SOURCE,
                "legacy source identity mismatch")
        parent = LAST_VERIFIED_LEGACY
        origin = "stage4 last verified d158 snapshot; not a fresh API assertion"
    require(re.fullmatch(r"[0-9a-f]{40}", parent), "invalid checkpoint parent")
    require(git.run("cat-file", "-t", parent).strip() == b"commit", "checkpoint parent not available")
    allowed = {"https://github.com/taipei49314/checkwash.git",
               "git@github.com:taipei49314/checkwash.git",
               "ssh://git@github.com/taipei49314/checkwash.git"}
    remote = git.run("remote", "get-url", "origin").decode().strip()
    push_urls = git.run("remote", "get-url", "--push", "--all", "origin").decode().splitlines()
    require(remote in allowed and len(push_urls) == 1 and push_urls[0] in allowed,
            "unexpected fetch/push origin or multiple push URLs")
    remote_tip = git.run("ls-remote", "--heads", "origin", "refs/heads/" + BRANCH).decode().split()
    require(len(remote_tip) == 2 and remote_tip == [parent, "refs/heads/" + BRANCH],
            "remote handoff moved; reconcile before appending")
    return parent, origin, previous


def inventory(payload):
    require(payload.absolute() == PAYLOAD.absolute(), "payload must be the fixed maintenance output directory")
    for path in (SESSION / "outputs", payload):
        require(stat.S_ISDIR(ordinary(path).st_mode), "payload parent is not a regular directory")
    members, raw = [], {}
    def visit(folder):
        for path in sorted(folder.iterdir()):
            info = ordinary(path)
            if stat.S_ISDIR(info.st_mode):
                visit(path)
                continue
            require(stat.S_ISREG(info.st_mode), "nonregular payload input")
            name = logical(path.relative_to(payload).as_posix())
            require(not any(part.lower() in {".git", "__pycache__", "site-packages", "node_modules",
                                             ".venv", "venv"} for part in PurePosixPath(name).parts),
                    "runtime/private directory in payload")
            require(not any(x in name.lower() for x in ("github-memory", "global-agents", "global_agents")),
                    "private context filename")
            require(path.suffix in SUFFIXES, "unsupported payload suffix")
            data = path.read_bytes()
            require(len(data) < 90_000_000, "blob too large for this backup publisher")
            if path.suffix == ".zip":
                require(name in {BUNDLE, SOURCE_ZIP}, "ZIP must use an exact reviewed root-relative name")
            members.append({"path": name, "bytes": len(data), "sha256": digest(data)})
            raw[name] = data
    visit(payload)
    require(members and len({r["path"].casefold() for r in members}) == len(members),
            "empty payload or casefold path collision")
    require(sum(r["bytes"] for r in members) <= 512 * 1024 * 1024, "payload size bound exceeded")
    for name, data in raw.items():
        if name.endswith(".sha256"):
            partner = name.removesuffix(".sha256")
            require(partner in raw, "orphan SHA256 sidecar")
            fields = data.decode("utf-8").split()
            require(len(fields) == 2 and fields[0] == digest(raw[partner])
                    and fields[1].lstrip("*") in {partner, PurePosixPath(partner).name},
                    "sidecar does not match payload bytes")
    return sorted(members, key=lambda r: r["path"]), raw


def checked_receipt(raw, path, expected_sha, expected_exit):
    logical(path)
    require(path.endswith(".json") and path in raw, "missing terminal receipt copy")
    require(digest(raw[path]) == expected_sha, "terminal receipt SHA mismatch")
    receipt = json.loads(raw[path])
    require(type(expected_exit) is int and type(receipt.get("exit_code")) is int
            and receipt.get("exit_code") == expected_exit,
            "terminal exit must equal actual receipt, not an audit exit")
    require(receipt.get("source_sha") == receipt.get("ending_sha") == SOURCE,
            "terminal receipt belongs to a different source")
    require(receipt.get("source_files_unchanged") is True and receipt.get("changed_inputs") == [],
            "terminal receipt has changed inputs")
    require(receipt.get("validation_kind") != "WORKING_TREE_DEVELOPMENT_NOT_COMMIT_QUALIFICATION",
            "working-tree development receipt is not fixed-source terminal evidence")
    return receipt


def inspect_bundle(data, checkpoint_roles):
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        infos = archive.infolist()
        names = [i.filename for i in infos]
        require(len(names) == len(set(names)), "duplicate bundle members")
        require(sum(i.file_size for i in infos) <= 512 * 1024 * 1024, "bundle expanded-size bound")
        for info in infos:
            logical(info.filename)
            require(not info.is_dir() and stat.S_IFMT(info.external_attr >> 16) == stat.S_IFREG,
                    "bundle member is not regular")
        require(archive.testzip() is None, "bundle CRC failure")
        manifest = json.loads(archive.read("BUNDLE-MANIFEST.json"))
        terminal = json.loads(archive.read("VALIDATION-TERMINAL-STATE.json"))
        require(manifest["source_sha"] == terminal["source_sha"] == SOURCE, "bundle source mismatch")
        require(terminal["all_active_jobs_terminal"] is True, "bundle is not terminal")
        declared = manifest["files"] + manifest["controller_files"]
        declared_names = {row["path"] for row in declared}
        require(len(declared_names) == len(declared), "duplicate declared bundle members")
        require(manifest["file_count"] == len(manifest["files"])
                and manifest["uncompressed_bytes"] == sum(row["bytes"] for row in manifest["files"]),
                "bundle manifest count/size mismatch")
        metadata_names = {"BUNDLE-MANIFEST.json", "BUNDLE-CLASSIFICATION.json",
                          "RESTORE-MAP.md", "VALIDATION-TERMINAL-STATE.json"}
        require(set(names) == declared_names | metadata_names, "undeclared or missing bundle member")
        for row in declared:
            logical(row["path"])
            blob = archive.read(row["path"])
            require(len(blob) == row["bytes"] and digest(blob) == row["sha256"], "bundle member hash mismatch")
        role_rows = {r["role"]: r for r in terminal["roles"]}
        require(set(role_rows) == set(ROLES), "bundle terminal roles differ")
        for role in ROLES:
            inside, outside = role_rows[role], checkpoint_roles[role]
            require(inside["state"] == outside["state"], "bundle and checkpoint role states differ")
            if inside["state"] == "TERMINAL":
                blob = archive.read(logical(inside["receipt"]))
                receipt = json.loads(blob)
                require(digest(blob) == inside["sha256"] == outside["sha256"],
                        "bundle and checkpoint terminal receipt bytes differ")
                require(receipt.get("source_sha") == receipt.get("ending_sha") == SOURCE
                        and receipt.get("source_files_unchanged") is True
                        and receipt.get("changed_inputs") == [], "bundle receipt source/input mismatch")
                require(receipt["exit_code"] == inside["exit_code"] == outside["exit_code"],
                        "bundle and checkpoint exits differ")
            else:
                require(inside["state"] == "NOT_RUN" and bool(inside.get("reason"))
                        and inside["reason"] == outside["reason"],
                        "bundle unexecuted role must be explicit NOT_RUN")


def metadata(raw):
    require("00-START-HERE.md" in raw and "checkpoint.json" in raw, "missing entry/checkpoint metadata")
    cp = json.loads(raw["checkpoint.json"])
    require(cp.get("source_sha") == cp.get("code_source_sha") == SOURCE, "checkpoint source mismatch")
    mode = cp.get("backup_state")
    require(mode in {"PARTIAL_CHECKPOINT", "TERMINAL_BACKUP"}, "unknown backup_state")
    require(cp.get("purpose") == PURPOSE and cp.get("acceptance_state") in {"OPEN", "NONPASS", "NOT_ACCEPTED"},
            "checkpoint must remain backup-only with acceptance open")
    require(cp.get("product_publication_performed") is False
            and cp.get("version_1_0_requires_human_decision") is True, "publication/1.0 boundary missing")
    entry = raw["00-START-HERE.md"].decode("utf-8")
    require(all(value in entry for value in (SOURCE, mode, PURPOSE)), "entry lacks exact source/state/purpose")
    validation = cp["validation"]
    roles = validation["roles"]
    require(isinstance(roles, dict) and set(roles) == set(ROLES), "exact four validation roles required")
    for role, row in roles.items():
        state = row.get("state")
        require(state in {"NOT_STARTED", "RUNNING", "TERMINAL", "NOT_RUN"}, "unknown role state")
        if state == "TERMINAL":
            checked_receipt(raw, row["receipt"], row["sha256"], row["exit_code"])
        else:
            require(row.get("exit_code") is None, "unfinished/NOT_RUN role must not claim exit0")
            if state == "NOT_RUN":
                require(isinstance(row.get("reason"), str) and bool(row["reason"].strip()), "NOT_RUN reason missing")
            require(row.get("receipt") is None and row.get("sha256") is None,
                    "unfinished/NOT_RUN role must not masquerade as a terminal receipt")
    all_terminal = all(r["state"] in {"TERMINAL", "NOT_RUN"} for r in roles.values())
    require(validation.get("all_active_jobs_terminal") is all_terminal, "terminal aggregate contradicts role states")
    bundle = cp["bundle"]
    require(bundle.get("filename") == BUNDLE, "unexpected bundle filename")
    if mode == "PARTIAL_CHECKPOINT":
        require(bundle.get("state") == "NOT_READY" and BUNDLE not in raw,
                "partial checkpoint cannot include/claim complete evidence ZIP")
        require(bundle.get("sha256") is None and bundle.get("bytes") in (None, 0),
                "NOT_READY bundle must not advertise a completed digest/size")
    else:
        require(all_terminal and bundle.get("state") == "COMPLETE" and BUNDLE in raw,
                "terminal backup needs four terminal/NOT_RUN roles and complete bundle")
        require(type(bundle.get("bytes")) is int and bundle["bytes"] == len(raw[BUNDLE])
                and bundle.get("sha256") == digest(raw[BUNDLE]), "bundle digest/size mismatch")
        require(BUNDLE + ".sha256" in raw, "complete bundle SHA sidecar missing")
        inspect_bundle(raw[BUNDLE], roles)
    if SOURCE_ZIP in raw:
        seal = json.loads((STAGE / "seal/source-seal.json").read_bytes())
        require(digest(raw[SOURCE_ZIP]) == seal["archive_sha256"], "source ZIP differs from sealed fbc")
    return cp


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--payload", type=Path, default=PAYLOAD)
    parser.add_argument("--label", required=True)
    parser.add_argument("--publish", action="store_true")
    parser.add_argument("--expect-plan-sha256")
    args = parser.parse_args()
    require(re.fullmatch(r"[a-z0-9][a-z0-9-]{0,47}", args.label), "invalid label")
    require(not args.publish or re.fullmatch(r"[0-9a-f]{64}", args.expect_plan_sha256 or ""),
            "--publish requires the reviewed plan digest")
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
    output = HERE / "runs" / (stamp + "-" + args.label)
    output.mkdir(parents=True, exist_ok=False)
    (output / "no-hooks").mkdir()
    git = Git(output)
    before, original_index = source_guard(git)
    parent, parent_origin, previous = parent_snapshot(git)
    members, raw = inventory(args.payload)
    checkpoint = metadata(raw)
    require(not (previous.get("backup_state") == "TERMINAL_BACKUP"
                 and checkpoint["backup_state"] == "PARTIAL_CHECKPOINT"), "refuse terminal-to-partial downgrade")
    legacy = git.run("show", LAST_VERIFIED_LEGACY + ":" + LEGACY_START)
    current = git.run("show", parent + ":" + LEGACY_START)
    require(current in (legacy, BANNER + legacy), "legacy entry differs from exact baseline+fixed banner")
    next_legacy = BANNER + legacy
    plan = {"source_sha": SOURCE, "code_source_sha": SOURCE, "branch": BRANCH, "parent": parent,
            "parent_origin": parent_origin, "prefix": PREFIX, "backup_state": checkpoint["backup_state"],
            "purpose": PURPOSE, "acceptance_state": checkpoint["acceptance_state"],
            "product_publication_performed": False, "payload": str(args.payload.absolute()),
            "checkpoint_product_tree": "INHERITED_FROM_HANDOFF_PARENT_NOT_PROMOTED_TO_FBC",
            "members": members, "bytes": sum(r["bytes"] for r in members),
            "legacy_start": {"path": LEGACY_START, "baseline_commit": LAST_VERIFIED_LEGACY,
                             "baseline_sha256": digest(legacy), "before_sha256": digest(current),
                             "after_sha256": digest(next_legacy), "baseline_is_exact_suffix": True},
            "source_guard": before, "publisher_sha256": digest(Path(__file__).read_bytes())}
    plan_sha = digest(encoded(plan))
    save(output / "plan.json", plan)
    (output / "plan.sha256").write_text(plan_sha + "\n", encoding="ascii")
    again, again_index = source_guard(git)
    require(again == before and again_index == original_index, "source/index changed during preflight")
    if not args.publish:
        print(json.dumps({"mode": "PLAN_ONLY_NO_GIT_WRITES", "plan_sha256": plan_sha,
                          "plan_path": str(output / "plan.json"), "backup_state": checkpoint["backup_state"],
                          "members": len(members), "parent": parent}, indent=2))
        return
    require(args.expect_plan_sha256 == plan_sha, "reviewed plan digest changed; do not publish")
    alternate = output / "alternate.index"
    git.write_enabled = True
    git.run("read-tree", parent, alternate=alternate, writes=True)
    staged = []
    for row in members:
        blob = raw[row["path"]]
        oid = git.run("hash-object", "-w", "--stdin", data=blob, alternate=alternate, writes=True).decode().strip()
        destination = PREFIX + "/" + row["path"]
        git.run("update-index", "--add", "--cacheinfo", "100644", oid, destination,
                alternate=alternate, writes=True)
        staged.append({**row, "path": destination, "git_blob": oid})
    if current != next_legacy:
        oid = git.run("hash-object", "-w", "--stdin", data=next_legacy,
                      alternate=alternate, writes=True).decode().strip()
        git.run("update-index", "--add", "--cacheinfo", "100644", oid, LEGACY_START,
                alternate=alternate, writes=True)
    tree = git.run("write-tree", alternate=alternate, writes=True).decode().strip()
    message = ("checkpoint: preserve fbc9374d " + args.label + "\n\n" + PURPOSE
               + "\nNo product acceptance, golden approval, merge, tag or release.\n")
    commit = git.run("commit-tree", tree, "-p", parent, data=message.encode(),
                     alternate=alternate, writes=True).decode().strip()
    changes = git.run("diff-tree", "--no-commit-id", "--name-status", "-r", "-z", parent, commit).split(b"\0")
    changes = [x.decode("utf-8") for x in changes if x]
    require(len(changes) % 2 == 0, "unexpected tree delta format")
    for status, name in zip(changes[::2], changes[1::2]):
        require(status in {"A", "M"} and (name.startswith(PREFIX + "/") or name == LEGACY_START),
                "prepared commit changes a path outside allowed backup scope")
    require(git.run("show", commit + ":" + LEGACY_START) == next_legacy, "legacy suffix not preserved")
    legacy_oid = git.run("rev-parse", commit + ":" + LEGACY_START).decode().strip()
    staged.append({"path": LEGACY_START, "bytes": len(next_legacy),
                   "sha256": digest(next_legacy), "git_blob": legacy_oid,
                   "kind": "legacy-entry-fixed-banner-plus-original8a-bytes"})
    prepared = {**plan, "plan_sha256": plan_sha, "checkpoint_commit": commit, "tree": tree,
                "files": staged, "created_utc": datetime.now(timezone.utc).isoformat(),
                "remote_ref_verified": False}
    save(output / "prepared-commit.json", prepared)
    latest_members, _latest_raw = inventory(args.payload)
    require(latest_members == members, "payload changed before push")
    after, after_index = source_guard(git)
    require(after == before and after_index == original_index, "source/index changed before push")
    git.run("push", "--porcelain", "--no-follow-tags", "--recurse-submodules=no",
            "origin", commit + ":refs/heads/" + BRANCH, writes=True, timeout=180)
    tip = git.run("ls-remote", "--heads", "origin", "refs/heads/" + BRANCH).decode().split()
    require(tip == [commit, "refs/heads/" + BRANCH], "push outcome needs explicit recovery/readback")
    final, final_index = source_guard(git)
    require(final == before and final_index == original_index, "source/index changed after push")
    result = {**prepared, "remote_ref_verified": True, "head_unchanged": True,
              "product_index_unchanged": True, "product_source_bytes_unchanged": True,
              "local_main_tags_unchanged": True, "publication_performed": False}
    save(output / "push-receipt.json", result)
    save(STATE_PATH, result)
    print(json.dumps({k: result[k] for k in ("checkpoint_commit", "backup_state", "branch",
                                            "source_sha", "remote_ref_verified",
                                            "product_index_unchanged")}, indent=2))


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print("Checkpoint stopped: " + type(error).__name__ + ": " + str(error), file=sys.stderr)
        raise SystemExit(1)

