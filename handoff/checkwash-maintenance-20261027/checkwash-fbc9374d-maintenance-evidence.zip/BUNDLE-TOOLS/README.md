# fbc maintenance evidence controller

Default invocation is plan only. Formal ZIP creation waits for root's explicit
all-active-terminal confirmation and four actual outer receipts. The source PIN
and stage5 seal must identify fbc9374dc3bcbfc47f403aec0c36e6b51dd7b86c;
current checkout must be clean and every tracked physical byte/blob must match.
No product, fixture or qualification is run by this tool.

```
python -I -B -X utf8 work/ux-stage5/checkpoint-pack/pack_checkpoint.py --out outputs/checkwash-maintenance-followup-20261027
```

Only after root supplies an actual terminal-state JSON:

```
python -I -B -X utf8 work/ux-stage5/checkpoint-pack/pack_checkpoint.py --pack --terminal-state TERMINAL.json --out outputs/checkwash-maintenance-followup-20261027
```

Terminal-state format is source_sha=fbc..., all_active_jobs_terminal=true,
root_confirmed_pack=true, and roles qualification_source/qualification_wheel/
qualification_pyz/full_suite. Each role is TERMINAL with task-relative receipt
path and SHA256, or explicit NOT_RUN with a reason. Actual nonzero exit codes
are retained; backup integrity never means suite PASS. Missing/active evidence
cannot become a complete ZIP. Do not infer new full-suite counts from targeted
180 tests or the collection of 21104; use the new native terminal evidence.

The new ZIP is checkwash-fbc9374d-maintenance-evidence.zip. Task-relative
work/ux-stage5 and work/trusted paths are preserved. Four controller files are
explicitly copied to BUNDLE-TOOLS with hash/restore mappings; the controller
and remote-checkpoint trees are otherwise excluded. All runtime, cache, temp,
Git fixtures, pyz source staging and source copies are excluded. Original 8a
five ZIPs are not copied or changed. Inert proposals and historical NONPASS
boundaries remain data, not adopted rulings or new qualification results.

Fresh Windows clone: use --no-checkout, choose repository-local (or per-command)
core.autocrlf=false and core.eol=lf before checkout, then compare the whole seal's
tracked member set, raw byte length/SHA256 and Git blobs. Do not change global
host settings. Fetch fbc, 1ffe and prior8a objects explicitly; source ZIP alone
is not a Git backup. See PUBLISHER.md for separately authorized partial/terminal
remote checkpoints. No pack or push is automatic and no main/tag/release moves.

One exact path+SHA exception retains the independently read audit_core8a.py
privacy-scanner source. Only its three reviewed header-marker literals bypass
embedded-header refusal. Private names/exact private hashes/key/URL/archive
checks still inspect original bytes. Details and AST positions are retained
in classification.reviewed_guard_source_exceptions; no broad pattern exception.
