# Maintenance follow-up publisher

Status: **PREPARED_NOT_EXECUTED**. This preparation performed no Git writes,
push, packing, product calls or new qualification. This tool is for the already
authorized task backup; it adds no merge/tag/release/1.0 authority.

The fixed product source is fbc9374dc3bcbfc47f403aec0c36e6b51dd7b86c.
The local checkout, stage5 PIN and 3,084-file source seal must agree exactly.
PJU is the authorized default; resulting receipts retain
HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL. No pool investigation or host-global
settings change is involved.

## Fixed destinations and history

- Payload: outputs/checkwash-maintenance-followup-20261027/
- Remote: the existing origin for taipei49314/checkwash, exact known HTTPS/SSH
  fetch URL and exactly one approved effective push URL (including rewrites).
- Branch: handoff/core-010-pju-20261027-8a8941dc
- New prefix: handoff/checkwash-maintenance-20261027/
- Evidence ZIP: checkwash-fbc9374d-maintenance-evidence.zip
- Optional sealed-source copy: source-fbc9374d.zip
- First parent: d158ec02aac9c0c19751d0475f935b533e3d03f7,
  the last root-verified8a backup snapshot in stage4 remote-checkpoint/state.json.
  This document does not pretend that dated snapshot is a new network observation.
- After a successful publish, only this publisher's verified stage5 remote-state
  receipt may supply the next parent. Every execution re-reads the exact remote
  handoff ref; any unexpected movement stops it. No force push or auto-rebase.
  The single push explicitly uses --no-follow-tags and --recurse-submodules=no,
  with invocation-only remote.origin.mirror=false, so user push settings cannot
  append tags, submodule pushes or a mirror operation to this backup.

The alternate index inherits the handoff parent tree. Only files under the new
prefix may be added/updated, plus the one old
handoff/checkwash-core-010-20261027/00-START-HERE.md entry. That old entry becomes
a fixed continuation banner plus its exact d158 original bytes, once. Later
terminal updates must find exactly that same banner+suffix and do not duplicate
the banner. Other old8a paths/ZIPs and earlier commits are retained.

**The handoff checkpoint tree does not promote its inherited product-root
files to fbc.** The tested code identity is the separate fbc source commit and
its retained sealed source ZIP. Restore the product checkout at the explicit
source commit, rather than treating a handoff metadata commit as tested source.

A later terminal payload adds/updates its prepared files; files from previous
partial commits that are not in the new payload remain historical branch
members. The plan/receipt lists the current payload snapshot explicitly, not
an assertion that all cumulative prefix files are current.

## Metadata contract

checkpoint.json permits extra descriptive/audit fields, but these fields are
required and enforced:

    {
      "source_sha": "fbc9374dc3bcbfc47f403aec0c36e6b51dd7b86c",
      "code_source_sha": "fbc9374dc3bcbfc47f403aec0c36e6b51dd7b86c",
      "backup_state": "PARTIAL_CHECKPOINT",
      "purpose": "BACKUP_ONLY_NOT_ACCEPTANCE_NOT_RELEASE",
      "acceptance_state": "NONPASS",
      "product_publication_performed": false,
      "version_1_0_requires_human_decision": true,
      "validation": {
        "all_active_jobs_terminal": false,
        "roles": {
          "qualification_source": {"state": "NOT_STARTED"},
          "qualification_wheel": {"state": "NOT_STARTED"},
          "qualification_pyz": {"state": "NOT_STARTED"},
          "full_suite": {"state": "RUNNING", "detail": "actual terminal receipt not yet available"}
        }
      },
      "bundle": {
        "state": "NOT_READY",
        "filename": "checkwash-fbc9374d-maintenance-evidence.zip"
      }
    }

The example is a **schema example, not a claim about live jobs**. The producer
must populate current states from actual evidence. Accepted role states:

- NOT_STARTED or RUNNING: no terminal exit/receipt/hash. Descriptive details
  may say terminal_missing rather than assuming an existing folder is live.
- TERMINAL: receipt is a payload-relative .json copy, sha256 is its raw hash,
  exit_code is the actual integer exit from that receipt. The receipt must have
  source_sha=ending_sha=fbc, source_files_unchanged=true, changed_inputs=[].
  A development/WIP receipt is refused. An audit exit cannot replace a suite exit.
- NOT_RUN: explicit nonempty reason; no exit/terminal receipt/hash. It is not PASS.

The keys are exactly qualification_source, qualification_wheel,
qualification_pyz, full_suite. all_active_jobs_terminal must equal the four
actual role states being TERMINAL or explicit NOT_RUN.

acceptance_state is OPEN, NONPASS or NOT_ACCEPTED, never PASS/accepted.
00-START-HERE.md must include the full fixed source, the exact backup_state
literal and BACKUP_ONLY_NOT_ACCEPTANCE_NOT_RELEASE purpose literal, so a
partial entry cannot be mistaken for the terminal package.

PARTIAL_CHECKPOINT requires bundle NOT_READY and no final evidence ZIP or
completed bundle digest/size. It can preserve already-terminal receipts while
another role or final packaging remains incomplete. It does not advertise a
complete evidence package.

TERMINAL_BACKUP requires all four roles TERMINAL/NOT_RUN and bundle:

    {
      "state": "COMPLETE",
      "filename": "checkwash-fbc9374d-maintenance-evidence.zip",
      "sha256": "<actual raw ZIP SHA256>",
      "bytes": "<actual integer byte size>"
    }

The byte size above must be an integer, not the illustrative string. The
matching .zip.sha256 file is mandatory. The publisher checks ZIP CRC, safe
regular paths, sourcefbc, exact declared member count/bytes/hashes, and the
four inner terminal roles/receipt hashes/actual exits against checkpoint.json.
It does not require exit0: failures/NOT_RUN remain failures/NOT_RUN. Terminal
means the backup inputs have reached recorded states, not product acceptance.

The optional source-fbc9374d.zip must match the existing stage5 seal archive
hash exactly. Only these exact root-relative .zip paths are accepted; ZIPs in
subdirectories are refused, so partial/seal checks cannot be bypassed by moving
an archive below another payload directory.

## File and source guards

Payload is restricted to the fixed output directory, regular non-reparse
members, safe relative/Windows paths, no runtime/private-context filenames and
.zip/.json/.md/.txt/.patch/.sha256 extensions. Export any needed controller as
.py.txt, rather than admitting arbitrary executable .py payloads. Sidecars
must match included bytes; each Git blob stays below90,000,000 bytes and the
payload below512MiB.

This is not a new universal privacy proof. Use the already reviewed producer,
sanitized bundle guards and independent readback; review the exact plan.
The publisher does not silently infer acceptance from prose or rerun product
qualification.

Before/pre-push/post-push guards require HEAD=fbc, a clean checkout, exact
tracked membership/raw lengths/SHA256/computed Git blobs against the seal,
unchanged product index bytes, unchanged local main/tag refs and sealed
source ZIP. Invocation-only Git overrides disable fsmonitor and point hooks
to an owned empty directory, preventing incidental product hooks. User
credential configuration remains available; no host-global config/PATH is
changed. Incoming GIT_* overrides are removed, with a private GIT_INDEX_FILE
added only for object/index preparation.

Git read-tree/hash-object/update-index/write-tree/commit-tree use the private
index and do not checkout/reset/stage the product. A prepared-commit receipt
is saved before the only allowed normal non-force branch push. A tree-delta
check rejects deletions or changes outside the new prefix/one old banner entry.
Source/index/protected local refs are checked again after remote readback.

## Operation after root review

No command below has been executed by this preparation task.

First review/populate 00-START-HERE.md, checkpoint.json and all payload files,
then ask the tool for a plan using the existing task Python:

    python -I -B -X utf8 work/ux-stage5/checkpoint-pack/publish_checkpoint.py --label partial-r1

Default mode performs read-only Git/network checks and writes only local plan
receipts under checkpoint-pack/runs/. It does not call hash-object -w, write
an alternate Git index, create commits or push.

After reviewing that exact plan/payload digest, root can explicitly run:

    python -I -B -X utf8 work/ux-stage5/checkpoint-pack/publish_checkpoint.py --label partial-r1 --publish --expect-plan-sha256 <reviewed-plan-sha256>

A byte/source/parent/publisher change invalidates the digest. The label is not
a promise of PASS. For terminal supplementation, prepare the terminal metadata
and reviewed complete ZIP, make/review a new plan and publish it the same way.

If push times out or succeeds but post-checks fail, preserve
prepared-commit.json, push.stdout/stderr and git-commands.json. Do not blindly
repeat or change the parent. Root must read the exact remote outcome/API and
reconcile the checkpoint receipt before continuing. Raw push stderr is local
recovery evidence, not automatically published payload.

Root's final remote/API member-hash readback remains separate. The publisher
itself verifies the remote ref and local invariants; it does not claim a
GitHub runner/formal check run or assert all remote blobs were re-downloaded.

Old8a failures, #567/#568, selfdogfood BLOCKs, consumed grants, publication
pause/acceptance boundaries and the explicit human decision before1.0 remain
as recorded. Backup timing is not a release deadline.

