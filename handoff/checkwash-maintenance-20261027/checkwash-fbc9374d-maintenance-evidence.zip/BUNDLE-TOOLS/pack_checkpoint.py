"""Plan a sanitized continuation archive; --pack needs explicit terminal status.

Only task evidence is read. No product, fixture program, Git write or push runs.
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import platform
import re
import stat
import subprocess
import tarfile
import zipfile
import zlib

HERE = Path(__file__).resolve().parent
STAGE = HERE.parent
SESSION = STAGE.parents[1]
REPO = SESSION / "work/checkwash-ux"
SOURCE = "fbc9374dc3bcbfc47f403aec0c36e6b51dd7b86c"
PIN = STAGE / "final-source-sha.txt"
BASE = "1ffe283d7d947fecc426dea99323b0a2620a9482"
DEFAULT_OUT = SESSION / "outputs/checkwash-maintenance-followup-20261027"
ORIGINAL_ZIPS = {
    "e6466727b1eeea9d964bc137b201f57d6e2e23ade4325dd509f373f32c377096",
    "c39a09b4ee8c0c3747d8ca6d0ce8a61482eb4e972ada640acce035a7a48d85a4",
    "d63425e79e3d7384fb4b73f11b2f562186b80db805f49d16c57de72e0a7f92a2",
    # Prior 8a backup artifacts are preserved separately, never recursively copied.
    "fff0b0e35282fa10df0d9f85a7996938e64ad267a9fa64dc1fdad03f654d5a8a",
    "b17dda4b17d0585e365b8439589c819c0be3f6ea35abb4773f9e6b240449d1cd",
    "1d9e52fabc28e3018ccdf12d21c5465b8a817f2d668325d5bffab591f21e3705",
    "3773ccdf0473fbbd8a0e4d52adfaf2317da3a13c7c7fb3704014abc7b27bb5f0",
    "d8a24a21cc811bc9237631d69d2d163dea98d66430d26aa35fc766cdadc68a4d",
}
TOP_EXCLUDED = {
    "build-runtime", "python312-runtime", "wheel-runtime", "dependency-index-cache",
    "pyz-source-stage", "remote-checkpoint", "checkpoint-pack",
}
DIR_EXCLUDED = {
    ".git", "__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache", "site-packages", "venv", ".venv", "node_modules",
    "tmp", "temp", "focused-tmp", "owned-tmp", "repos", "pytest-temp", "basetemp",
    "snapshot", "working-tree-source", "focused-source", "source-candidate", "source", "fixtures",
}
FIXED_EXTERNAL = (
    "work/trusted/replay_pju_action.py", "work/trusted/collect_pju_receipts-at-1ffe.py",
)

REVIEWED_GUARD_SOURCE = {'work/ux-stage5/backup-audit/audit_core8a.py': '00feab922ebb43e18146d7e436be83e320c316fed111223d2c8907366901162b'}

HEADER_MARKERS = (b"Local Codex project memory", b"## General work-machine rule", b"EYE trial 1 (ended)")
KEY_SHAPES = (
    re.compile(rb"-----BEGIN (?:[A-Z ]+ )?PRIVATE KEY-----"),
    re.compile(rb"\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{40,})\b"),
    re.compile(rb"\bsk-(?:proj-)?[A-Za-z0-9_-]{30,}\b"),
    re.compile(rb"\bAKIA[0-9A-Z]{16}\b"),
)
USERINFO = re.compile(rb'https?://[^\s/"<>]+:[^\s/"<>]+@')
ROLES = ("qualification_source", "qualification_wheel", "qualification_pyz", "full_suite")


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=False) + "\n").encode("utf-8")


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def logical(value):
    value = str(value).replace("\\", "/")
    p = PurePosixPath(value)
    if p.is_absolute() or any(x in value for x in (":", "\r", "\n", "\0")) or ".." in p.parts:
        raise ValueError("unsafe relative task path")
    return p.as_posix()


def regular(path):
    relative = path.relative_to(SESSION)
    current = SESSION
    for part in relative.parts:
        current /= part
        info = current.lstat()
        if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
            raise ValueError("link/reparse task input refused: " + relative.as_posix())
    if not stat.S_ISREG(info.st_mode):
        raise ValueError("nonregular task input refused: " + relative.as_posix())


def read(path):
    regular(path)
    first = path.stat()
    raw = path.read_bytes()
    last = path.stat()
    stable = (first.st_size, first.st_mtime_ns) == (last.st_size, last.st_mtime_ns)
    return raw, stable


def dir_reason(parts):
    if len(parts) == 1 and parts[0].lower() in TOP_EXCLUDED:
        return "runtime-cache-or-controller-directory"
    if any(p.lower() in DIR_EXCLUDED for p in parts):
        return "rebuildable-source-fixture-temp-or-cache"
    # Do not exclude named pytest-context-* red/green evidence directories.
    if re.fullmatch(r"pytest-[0-9]+", parts[-1]) and any("temp" in p.lower() or p.lower() in {"tmp", "pytest"} for p in parts[:-1]):
        return "owned-pytest-temporary-directory"
    return None


def private_name(name):
    base = PurePosixPath(name.replace("\\", "/")).name.lower()
    return ("global" in base and "agent" in base) or "github-memory-2026" in base


def git_read(*args):
    env = {key: value for key, value in os.environ.items() if not key.startswith("GIT_")}
    env.update(GIT_CONFIG_GLOBAL=os.devnull, GIT_CONFIG_NOSYSTEM="1", GIT_TERMINAL_PROMPT="0")
    result = subprocess.run(["git", "--no-optional-locks", "-c", "core.fsmonitor=false", "-C", str(REPO), *args],
                            env=env, capture_output=True, check=True, timeout=60)
    return result.stdout


def source_guard():
    if not PIN.is_file() or PIN.read_text(encoding="utf-8").strip() != SOURCE:
        raise ValueError("the sealed maintenance PIN must be exact fbc")
    if git_read("rev-parse", "HEAD").decode().strip() != SOURCE or git_read("status", "--porcelain", "--untracked-files=all"):
        raise ValueError("the sealed product checkout must remain clean at exact fbc")
    if git_read("rev-parse", BASE + "^{commit}").decode().strip() != BASE:
        raise ValueError("required 1ffe Git object is missing")
    seal = json.loads((STAGE / "seal/source-seal.json").read_bytes())
    if seal["source_sha"] != SOURCE or not seal["all_tracked_bytes_match_git"]:
        raise ValueError("unexpected source seal")
    archive = STAGE / "seal" / PurePosixPath(str(seal["source_archive"]).replace("\\", "/")).name
    if digest(archive.read_bytes()) != seal["archive_sha256"]:
        raise ValueError("sealed source archive changed")
    rows = seal["files"]
    expected = {logical(row["path"]): row["sha256"] for row in rows}
    tracked = set(git_read("ls-files", "-z").decode("utf-8").split("\0")) - {""}
    if len(expected) != len(rows) or len(rows) != seal["tracked_files"] or tracked != set(expected):
        raise ValueError("seal membership differs from the complete tracked checkout")
    algorithm = {"sha1": hashlib.sha1, "sha256": hashlib.sha256}.get(seal["git_object_format"])
    if algorithm is None:
        raise ValueError("unsupported sealed Git object format")
    for row in rows:
        content, stable = read(REPO / row["path"])
        blob = algorithm(b"blob " + str(len(content)).encode("ascii") + b"\0" + content).hexdigest()
        if (not stable or len(content) != row["bytes"] or digest(content) != row["sha256"]
                or blob != row["git_blob"] or row["actual_git_blob"] != blob or not row["matches"]):
            raise ValueError("physical source bytes differ from the sealed Git member: " + row["path"])
    return expected


def guards(sealed_files):
    denied = set(ORIGINAL_ZIPS)
    # Fingerprint private reference files without exporting their content/path.
    references = [SESSION.parents[1] / "2026-10-16/new-chat/outputs/github-memory-2026-10-16.md"]
    for ancestor in SESSION.parents:
        candidate = ancestor / ".codex/AGENTS.md"
        if candidate.is_file():
            references.append(candidate)
            break
    for path in references:
        if path.is_file():
            denied.add(digest(path.read_bytes()))
    synthetic_urls = set()
    for name in ("tests/test_collect_pju_release.py", "tests/test_sweep_commit_diagnostics.py"):
        raw = (REPO / name).read_bytes()
        if digest(raw) != sealed_files[name]:
            raise ValueError("synthetic URL reference differs from seal")
        synthetic_urls.update(USERINFO.findall(raw))
    return denied, synthetic_urls


def inspect(raw, name, denied, synthetic_urls, depth=0, allow_reviewed_header_literals=False):
    """Return reason labels only; never log matched private/key values."""
    if private_name(name) or digest(raw) in denied:
        return "exact-private-memory-or-original-archive"
    if sum(marker in raw for marker in HEADER_MARKERS) >= 2 and not allow_reviewed_header_literals:
        return "embedded-global-memory"
    if any(pattern.search(raw) for pattern in KEY_SHAPES):
        return "credential-shaped-content-needs-local-review"
    if any(value not in synthetic_urls for value in USERINFO.findall(raw)):
        return "unexpected-authenticated-url-needs-local-review"
    if depth >= 4:
        return "archive-inspection-depth-limit"
    stream = io.BytesIO(raw)
    if zipfile.is_zipfile(stream):
        with zipfile.ZipFile(stream) as archive:
            entries = archive.infolist()
            if sum(row.file_size for row in entries) > 512 * 1024 * 1024:
                return "archive-inspection-size-limit"
            for row in entries:
                if row.is_dir():
                    continue
                logical(row.filename)
                if (row.external_attr >> 16) & 0o170000 == stat.S_IFLNK:
                    return "archive-link-member"
                reason = inspect(archive.read(row), row.filename, denied, synthetic_urls, depth + 1)
                if reason:
                    return "archive-contains-" + reason
    elif name.lower().endswith((".tar.gz", ".tgz", ".tar")):
        with tarfile.open(fileobj=stream, mode="r:*") as archive:
            members = archive.getmembers()
            if sum(row.size for row in members) > 512 * 1024 * 1024:
                return "archive-inspection-size-limit"
            for member in members:
                if member.isdir():
                    continue
                logical(member.name)
                if not member.isfile():
                    return "archive-nonregular-member"
                reason = inspect(archive.extractfile(member).read(), member.name, denied, synthetic_urls, depth + 1)
                if reason:
                    return "archive-contains-" + reason
    return None


def external_closure():
    return set(FIXED_EXTERNAL)


def inventory():
    sealed_files = source_guard()
    denied, synthetic = guards(sealed_files)
    candidates = set(external_closure())
    excluded = []
    for directory, dirs, files in os.walk(STAGE, followlinks=False):
        current = Path(directory)
        kept = []
        for name in sorted(dirs):
            path = current / name
            relative = path.relative_to(STAGE)
            info = path.lstat()
            reason = "link-or-reparse-directory" if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400 else dir_reason(relative.parts)
            if not reason and ((path / "pyvenv.cfg").is_file() or name.lower().endswith("-runtime")):
                reason = "task-local-runtime-environment"
            if reason:
                excluded.append({"path": path.relative_to(SESSION).as_posix() + "/", "reason": reason})
            else:
                kept.append(name)
        dirs[:] = kept
        candidates.update((current / name).relative_to(SESSION).as_posix() for name in sorted(files))
    selected = []
    for name in sorted(candidates):
        path = SESSION / name
        raw, stable = read(path)
        reviewed_literals = REVIEWED_GUARD_SOURCE.get(name) == digest(raw)
        reason = inspect(raw, name, denied, synthetic, allow_reviewed_header_literals=reviewed_literals)
        if reason:
            excluded.append({"path": name, "bytes": len(raw), "reason": reason})
            continue
        selected.append({"path": name, "bytes": len(raw), "sha256": digest(raw), "stable_during_read": stable})
    return selected, sorted(excluded, key=lambda row: row["path"])


def terminal_status(path):
    data = json.loads(path.read_bytes())
    if data.get("source_sha") != SOURCE or data.get("all_active_jobs_terminal") is not True or data.get("root_confirmed_pack") is not True:
        raise ValueError("root's explicit terminal/pack confirmation is required")
    records = []
    for role in ROLES:
        row = data["roles"][role]
        if row["state"] == "NOT_RUN":
            if not row.get("reason"):
                raise ValueError("NOT_RUN needs an explicit reason")
            records.append({"role": role, "state": "NOT_RUN", "reason": row["reason"]})
            continue
        if row["state"] != "TERMINAL":
            raise ValueError("validation role remains active: " + role)
        name = logical(row["receipt"])
        raw, stable = read(SESSION / name)
        receipt = json.loads(raw)
        if not stable or digest(raw) != row["sha256"]:
            raise ValueError("terminal receipt changed: " + role)
        binding = [receipt[key] for key in ("source_sha", "expected_source_sha", "ending_sha") if key in receipt]
        if not binding or any(value != SOURCE for value in binding):
            raise ValueError("terminal receipt source binding differs: " + role)
        code = receipt.get("exit_code", receipt.get("exit"))
        if type(code) is not int:
            raise ValueError("terminal receipt has no actual exit code: " + role)
        records.append({"role": role, "state": "TERMINAL", "receipt": name, "sha256": digest(raw), "exit_code": code})
    return {"source_sha": SOURCE, "all_active_jobs_terminal": True, "roles": records,
            "interpretation": "Backup completion records actual outcomes; it does not assert all tests passed or authorize publication."}


def controller_files(required):
    rows, content = [], {}
    for name in ("pack_checkpoint.py", "publish_checkpoint.py", "README.md", "PUBLISHER.md"):
        path = HERE / name
        if not path.is_file():
            if required:
                raise ValueError("controller provenance is not ready: " + name)
            rows.append({"path": "BUNDLE-TOOLS/" + name, "state": "NOT_READY"})
            continue
        raw, stable = read(path)
        if not stable or any(pattern.search(raw) for pattern in KEY_SHAPES) or re.search(rb"(?m)^# Local Codex project memory\r?$", raw):
            raise ValueError("controller provenance is unstable or needs local review: " + name)
        destination = "BUNDLE-TOOLS/" + name
        rows.append({"path": destination, "restore_to": "work/ux-stage5/checkpoint-pack/" + name,
                     "bytes": len(raw), "sha256": digest(raw)})
        content[destination] = raw
    return rows, content


RESTORE = f"""# Maintenance continuation backup / restore map

Extract into a new task workspace root, preserving `work/ux-stage5/` and
`work/trusted/`. Copy the four explicit BUNDLE-TOOLS controller files to
`work/ux-stage5/checkpoint-pack/` before reusing them; do not flatten the
remaining task layout. Output folders and controller-generated files are absent.

Create a clean Git checkout at `work/checkwash-ux`. Fetch exact current
`{SOURCE}`, baseline `{BASE}`, and the prior comparison source
`8a8941dc2d7c581715a0f6f196c00da6c55f084b`. The source ZIP preserves bytes;
extracting it alone does not supply those Git objects or history.
For a fresh Windows checkout use clone --no-checkout, then task-local
core.autocrlf=false/core.eol=lf (or both -c settings on checkout). Do not
change host-global Git configuration. Verify every tracked member's bytes,
SHA256 and Git blob identity against this stage5 source-seal, not merely
HEAD or clean status. Recreate local runtimes from retained dependency receipts.

This is a current maintenance-source continuation subset, not a self-contained
replay of all history. Prior 8a artifacts and five backup ZIPs remain separate
and unchanged. Historical proposals, failed runs, NO_CAPTURED/NOT_REACHED,
RUNNING/NOT_RUN and unresolved golden/semantic costs retain their status.
Only actual terminal receipts establish outcomes; packing does not turn a
failed full suite into PASS or authorize merge, publication, tags or version1.0.
A partial remote checkpoint is a status backup, never this complete bundle.

ZIP timestamps/modes are fixed, paths sorted, Deflate9 used. Same inputs,
controller and Python/zlib runtime yield the same bytes. Privacy checks are
bounded, not a universal secret-free assurance. Backup time is not a product
release deadline.
"""


def zip_write(archive, name, raw):
    info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
    info.create_system = 3
    info.external_attr = (stat.S_IFREG | 0o644) << 16
    info.compress_type = zipfile.ZIP_DEFLATED
    archive.writestr(info, raw, compresslevel=9)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pack", action="store_true", help="Only after root confirms terminal status; default is plan only")
    parser.add_argument("--out", type=Path, default=DEFAULT_OUT, help="Output directory; never included as evidence input")
    parser.add_argument("--terminal-state", type=Path)
    args = parser.parse_args()
    args.out = args.out.absolute()
    if not args.out.resolve().is_relative_to((SESSION / "outputs").resolve()):
        raise ValueError("--out must stay inside this task's outputs directory")
    selected, excluded = inventory()
    controls, controller_content = controller_files(args.pack)
    manifest = {"schema_version": 1, "source_sha": SOURCE, "required_git_object": BASE,
                "kind": "SANITIZED_CONTINUATION_SUBSET_NOT_FULL_HISTORY",
                "provenance": "HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL",
                "files": selected, "file_count": len(selected), "uncompressed_bytes": sum(row["bytes"] for row in selected),
                "packer_sha256": digest(Path(__file__).read_bytes()), "python": platform.python_version(),
                "host": platform.node(), "controller_files": controls,
                "zlib": zlib.ZLIB_VERSION, "archive_format": "zip/deflate9/fixed1980/regular0644/sorted"}
    classification = {"public_candidate": True, "bounded_checks_only": True,
                      "originals_unchanged": True, "excluded": excluded,
                      "historical_replay_self_contained": False,
                      "reviewed_guard_source_exceptions": [{'path': 'work/ux-stage5/backup-audit/audit_core8a.py', 'sha256': '00feab922ebb43e18146d7e436be83e320c316fed111223d2c8907366901162b', 'bytes': 17247, 'disposition': 'EXACT_REVIEWED_PRIVACY_GUARD_LITERAL_EXCEPTION_ONLY', 'marker_literal_ast_positions': [{'marker_label': 1, 'line': 196, 'column': 11, 'node': 'Constant(bytes)'}, {'marker_label': 2, 'line': 196, 'column': 42, 'node': 'Constant(bytes)'}, {'marker_label': 3, 'line': 196, 'column': 75, 'node': 'Constant(bytes)'}], 'complete_global_agents_body_present': False, 'same_as_global_agents_bytes': False, 'scope': 'Source was fully read as inert text; these are privacy-scanner marker literals, not a global-memory dump. No product, creator or proposed code was imported/compiled/executed. This bounded review does not guarantee universal absence of secrets.', 'exception': 'Only embedded-header marker refusal may be bypassed for exact path and bytes; all other checks inspect the original bytes, including exact denied hashes/private names, key/URL patterns and recursive archives.'}],
                      "note": "Plan sizes are point-in-time; named pytest-context evidence is retained. Outputs and controller directories are not inputs."}
    HERE.mkdir(parents=True, exist_ok=True)
    (HERE / "selection-plan.json").write_bytes(encoded({**manifest, "mode": "PLAN_ONLY_NO_ARCHIVE", "active_validation_may_change": True}))
    (HERE / "classification.json").write_bytes(encoded(classification))
    if not args.pack:
        print(json.dumps({"mode": "PLAN_ONLY_NO_ARCHIVE", "file_count": len(selected), "uncompressed_bytes": manifest["uncompressed_bytes"],
                          "excluded_roots_or_files": len(excluded), "unstable_reads": sum(not row["stable_during_read"] for row in selected)}))
        return 0
    if args.terminal_state is None:
        raise ValueError("--pack requires --terminal-state after root confirms all active jobs terminal")
    terminal = terminal_status(args.terminal_state)
    if any(not row["stable_during_read"] for row in selected):
        raise ValueError("evidence changed during selection; retry only after terminal state")
    args.out.mkdir(parents=True, exist_ok=True)
    target = args.out / "checkwash-fbc9374d-maintenance-evidence.zip"
    partial = args.out / "checkwash-fbc9374d-maintenance-evidence.zip.partial"
    if target.exists() or partial.exists():
        raise ValueError("fresh output required; existing backup is never overwritten")
    metadata = {"BUNDLE-MANIFEST.json": encoded(manifest), "BUNDLE-CLASSIFICATION.json": encoded(classification),
                "VALIDATION-TERMINAL-STATE.json": encoded(terminal), "RESTORE-MAP.md": RESTORE.encode("utf-8")}
    denied, synthetic = guards(source_guard())
    for name, raw in metadata.items():
        if inspect(raw, name, denied, synthetic):
            raise ValueError("generated metadata needs local privacy review: " + name)
    metadata.update(controller_content)
    with zipfile.ZipFile(partial, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name in sorted(metadata):
            zip_write(archive, name, metadata[name])
        for row in selected:
            raw, stable = read(SESSION / row["path"])
            if not stable or len(raw) != row["bytes"] or digest(raw) != row["sha256"]:
                raise ValueError("evidence changed while packaging: " + row["path"])
            zip_write(archive, row["path"], raw)
    after, after_excluded = inventory()
    if after != selected or after_excluded != excluded or terminal_status(args.terminal_state) != terminal or controller_files(True)[1] != controller_content:
        raise ValueError("evidence or terminal status changed during packaging; partial archive retained locally")
    with zipfile.ZipFile(partial) as archive:
        if archive.testzip() is not None or len(archive.namelist()) != len(selected) + len(metadata):
            raise ValueError("archive readback failed")
    partial.rename(target)
    (args.out / (target.name + ".sha256")).write_text(digest(target.read_bytes()) + "  " + target.name + "\n", encoding="ascii")
    (HERE / "pack-receipt.json").write_bytes(encoded({"source_sha": SOURCE, "archive": target.name,
        "sha256": digest(target.read_bytes()), "bytes": target.stat().st_size, "file_count": len(selected),
        "host": platform.node(), "python": platform.python_version(),
        "source_and_inputs_unchanged": True, "validation": terminal, "publication_performed": False}))
    print(json.dumps({"mode": "PACKED_BACKUP_NOT_RELEASE", "archive": str(target), "sha256": digest(target.read_bytes()), "bytes": target.stat().st_size}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
