"""IR data model (checkwash_ir_version 3).

Detectors consume this and nothing else. All ordering inside the IR is
explicit and deterministic; no dict/set iteration order leaks into output.
Spans are character offsets into CRLF→LF-normalized source (SPEC §8).
"""

from __future__ import annotations

import dataclasses
from dataclasses import dataclass, field
from typing import Any

from checkwash import IR_VERSION


@dataclass
class Assertion:
    id: str
    form: str  # compare_eq | compare_ord | membership | non_null | approx | type_shape | pattern | truthy | tautology | raises | unknown
    strength: int | None
    text: str
    span: tuple[int, int]
    left: str | None = None
    right_literal: str | None = None
    right_value: str | None = None  # repr() of the evaluated or folded (#226) literal, for hardcode matching
    epsilon: str | None = None  # literal source text of the tolerance, never a float
    epsilon_kind: str | None = None  # rel | abs | delta (bigger=looser) | places (bigger=stricter)
    # The asserted subject depends only on literals and builtins, so the
    # assertion cannot fail. Such assertions never count as compensation.
    trivial: bool = False
    # False for negated forms (!=, is not, not in, assertFalse, ...).
    # Flipping polarity inverts what the test proves while leaving form and
    # strength identical, so it needs to be part of the assertion's identity.
    positive: bool = True
    # The predicate this assertion states, as one canonical key of
    # `ir/predicate.py` (is_null, truthy, eq_strict, lt, ...), when the
    # frontend knows it; `positive` then says whether the assertion asserts
    # that predicate or its negation (`toBeDefined()` is is_undefined
    # asserted negatively). None leaves the pair to the lattice rules (#198).
    predicate: str | None = None
    # The operand's source as one canonical line (`operand_text` in the JS
    # literal reader): the expected value of an equality or closeTo, or the
    # bound of a bound key. It decides only whether two spellings on two
    # APIs state the same operand (`toBeLessThan(LIMIT)`, `.below(LIMIT)`)
    # and which names a rewritten one reads; `right_value` stays the
    # literal evidence. A hand-rolled `Math.abs(d) < bound` records its
    # bound here only when the bound was read, because that bound is
    # tolerance evidence only. The Python frontend records the bound of a
    # bound key, as written (#224).
    operand_source: str | None = None
    # The expected value or bound as one canonical line, when it is a call
    # checkwash neither folds nor resolves (#226): its callee's root is a
    # name the file never binds, a builtin or global outside the fold set
    # (`int('75')`, `parseFloat('75')`) or a name bound nowhere. A literal
    # replaced by one, or one rewritten into another, is an expected value
    # checkwash does not evaluate (EXPECTED_VALUE_CHANGED). A fold-set
    # conversion of a literal (`float('75')`, `Decimal('75')`,
    # `Number('75')`) is no such call: `right_value` records its value.
    unevaluated_expected: str | None = None
    # True when the assertion's operands cannot be bound: a unittest method
    # called with `*` or `**` operands (`self.assertEqual(**case)`,
    # `self.assertEqual(*pair)`). Its form and strength are the method's, it
    # records no subject, expected value or names, and it is not trivial: what
    # it compares is unknown. A known oracle replaced by one is unverifiable
    # (ASSERT_WEAKENED, #462 Q2); one replaced by another stays silent.
    unbound_operands: bool = False
    # Names appearing in the asserted subject's own expression, and the names
    # the expectation transitively depends on after in-body assignments are
    # followed (`expected = sum(items)` -> ("items", "sum")). Both sorted.
    #
    # These exist for EXPECTED_VALUE_DERIVED, which needs to tell a rewritten
    # expectation apart from a *recomputed* one. A literal replaced by a named
    # constant shares nothing with the subject; a literal replaced by an
    # expression over the subject's own arguments is the test re-implementing
    # the code it is supposed to be checking (THREATMODEL 84a).
    left_names: tuple[str, ...] = ()
    right_depends_on: tuple[str, ...] = ()
    # True when the expectation side is a single bare name — `== expected`,
    # nothing wrapped around it. Set for inherited helper asserts, where it is
    # the discriminator between "the literal-ness moved to the call site" and
    # "the helper transforms the expectation before comparing" (`sorted(...)`,
    # `set(...)`) — the latter is how three disguised-arm attacks hide, and
    # both spellings depend on the same names, so `right_depends_on` cannot
    # tell them apart.
    bare_expectation: bool = False
    # True when this assertion is not written in the unit but in a same-file
    # scope the unit invokes. It is part of the unit's oracle either way — that
    # is the whole point of reachability — but it is not part of the unit's
    # *body*, and rules that reason about an assertion holding a slot need to
    # know the difference. Extracting a concrete assert into a shared,
    # parametrised helper otherwise reads as substitution.
    inherited: bool = False
    # Reaching definition keys for the names this assertion consumes: name ->
    # the last unconditional
    # binding at or before this assertion joined with every conditional binding
    # after that one, in source order. SPEC §5's stated semantics — "the last
    # unconditional binding is the one the assertion reads" — held
    # per-assertion: `UnitSide.bindings` joins every definition of a name, so
    # inserting one self-contained case into a long function changed "the"
    # definition for every untouched assertion (sympy ed75b73d fired 13 times
    # on a 23-line pure insertion; R1). A name bound in the unit only *after*
    # the assertion maps to "", which is equal on both sides of a tail-append
    # and different when a definition moves across the assertion. A name bound
    # only inside a nested def is absent, and consumers fall back to the
    # unit-level map. Same-file inherited assertions carry the keys of their
    # unit-level call site — computed where the helper's oracle executes
    # relative to the unit's own bindings (issue #55); cross-file and
    # fixture-channel inherited assertions still carry None.
    reaching: dict[str, str] | None = None
    # The pairing signature: the reaching entries of the names this assertion
    # *directly* spells (left and right), serialized stably. Pairing needs a
    # context key so a repeated oracle matches the twin that reads the same
    # definitions — but the transitive closure must stay out of it: `F`
    # resolved through the unit-level map drags in names other definitions of
    # `F` reference, whose reaching keys legitimately differ across an
    # insertion, and a polluted signature would push untouched twins back to
    # the FIFO fallback this exists to avoid. Same-file inherited copies get
    # their call site's signature, which is what tells N copies of one helper
    # assert apart; "" for cross-file and fixture-channel inherited ones.
    reaching_sig: str = ""
    # The class-qualified name of the helper method the unit reached this
    # assertion through (`TotalTest._check` for `self._check(...)`, #306),
    # None for every other assertion. Such an assertion is a detection-only
    # overlay (306 Sub-Q11): it is paired after the unit's own assertions,
    # earns no credit, adds no requirement for another finding, and takes
    # repair evidence from that method's callees only for findings about
    # itself (306 Sub-Q8). Optional, so IR_VERSION stays 2.
    via: str | None = None
    # The subject a bare local name stands for (#434): when `left` is one
    # name of the unit, bound only by plain `name = <expr>` statements, and
    # exactly one of them reaches this assertion, the bound expression as
    # canonical source (`ast.unparse`) and the reaching keys of the names
    # that expression reads at that statement (`ir.subjects`). Python only,
    # an own assertion in the unit's own scope only; None for every other
    # assertion. The order fallback reads it through
    # `ir.subjects.same_subject`. Optional, so IR_VERSION stays 2.
    resolved_subject: tuple[str, str] | None = None
    # The unit's parameters this assertion reads that name a fixture whose
    # producer was read (`UnitSide.fixture_producers`): directly, or through
    # the unit's own assignments (#471). Only an assertion written in the
    # unit's own body, outside a nested def, class or lambda, records any,
    # and a parameter the body binds again, in any form, is not recorded.
    # Repair evidence reads the before half's for the finding about it
    # (471 Q3). Sorted. Optional, so IR_VERSION stays 2.
    fixture_reads: tuple[str, ...] = ()


@dataclass
class Marker:
    name: str  # e.g. "pytest.mark.skip"
    text: str
    span: tuple[int, int]
    # For imperative skip calls (`pytest.skip()` et al.): the conjunction of
    # enclosing `if` conditions, source text, `not (...)`-wrapped for else
    # branches. `if PY_3_14_PLUS: pytest.xfail(...)` is the imperative spelling
    # of `skipif(PY_3_14_PLUS)`, and without the guard D6 cannot tell it from
    # an unconditional kill. For a skip in the setup a unit runs
    # (`setup.<provider>.<effect>`): the condition its setup callback reaches
    # it under, None when every call does (#196 183.2). Deliberately NOT part
    # of the marker identity alignment pairs markers on (D-019): a guard
    # rewritten is no marker removed and another added. The TEST_DISABLED
    # exemption key does bind it, for a marker added (#512 Q1 (a), D-169).
    guard: str | None = None


@dataclass
class Handler:
    caught: tuple[str, ...]  # empty = bare except
    is_broad: bool
    text: str
    span: tuple[int, int]


@dataclass(frozen=True)
class ParamTable:
    """One `parametrize` decorator's table, kept as rows.

    `names` are the argnames the decorator binds, `rows` the canonical
    (`ast.unparse`) cell texts of each row in argname order, `disabled` one
    flag per row for the rows a `skip` / non-strict `xfail` mark took out of
    the run. Cell text is read *through* `pytest.param`, so marking a row or
    giving it an `id=` does not change which row it is -- the mark is the
    `disabled` flag, and that separation is the whole point: the row is still
    written down, it just stopped running.

    Stacked decorators are independent tables (pytest multiplies them into
    test items), so a unit carries one entry per decorator rather than one
    wider table; zipping across decorators would invent pairings that do
    not exist.
    """

    names: tuple[str, ...]
    rows: tuple[tuple[str, ...], ...]
    disabled: tuple[bool, ...]


@dataclass
class UnitSide:
    span: tuple[int, int]
    assertions: list[Assertion] = field(default_factory=list)
    calls: tuple[str, ...] = ()  # sorted, unique
    markers: list[Marker] = field(default_factory=list)
    handlers: list[Handler] = field(default_factory=list)
    param_cases: int | None = None  # parametrized case count, None = not parametrized
    # sha256 of the unit's normalized body (decorators excluded), for the
    # whole-unit relocation credit: an assertion-less smoke test that moves
    # files verbatim has nothing in the D2 multiset to prove it moved.
    body_hash: str = ""
    # Locally bound name -> a structural key for its defining expression.
    #
    # `right_depends_on` records which names an expectation reaches; this
    # records what those names are *defined as*. Without it, editing
    # `expected = round(sum(items) * (1 + TAX), 2)` into
    # `round(sum(items), 2)` leaves the assertion line byte-identical and every
    # rule silent — THREATMODEL 86a, the shape an expectation that was already
    # a name has always been able to hide in. The key is `ast.dump` of the
    # parsed expression, so reformatting is not a change and a rename inside it
    # is. Keys inserted in sorted order (SPEC §8).
    bindings: dict[str, str] = field(default_factory=dict)
    # parametrize argname -> canonical text of that column across all rows.
    # A parametrized test's expectation lives in the decorator, not the body,
    # so editing it moves the oracle with the assertion untouched.
    param_columns: dict[str, str] = field(default_factory=dict)
    # The same tables, unflattened: one `ParamTable` per `parametrize`
    # decorator (read through `param_tables()`, never directly). Both facts
    # a row carries are lost by the two flattenings above. `param_columns`
    # keeps the cells but not which expectation belongs to which input, so
    # a swapped pair of answers, or an answer rewritten while a row is
    # appended, reads as no change (F-060). `param_cases` keeps a *count*
    # of live rows, so disabling one row while appending another nets to
    # zero and the disabled test item is never reported (F-063). Empty when
    # the unit has no readable table -- and, deliberately, when *any* of its
    # counted decorators is unreadable (a starred row, a non-literal cell
    # list), so that whoever reads the rows sees exactly the decorators
    # `param_cases` counted, or nothing.
    param_rows: tuple[ParamTable, ...] = ()
    # JS/TS only (#428): this unit is a `.each`/`.for` table whose rows
    # cannot be counted, so `param_cases` is None and `param_rows` empty.
    # A table's rows are counted when it passes an array literal with no
    # spread or hole, a tagged template, or a same-file `const` bound once
    # to such a literal and read nowhere but as a table argument. When either
    # side of a table pair is unknown the count rule stays silent; a plain
    # test whose pair is such a table is the one test item it was (428.Q2a).
    # The Python frontend never sets it, so no Python reading moves.
    # Optional, so IR_VERSION stays 2.
    param_rows_unknown: bool = False
    # Literal paths a conftest removes from collection, sorted. Markers
    # deduplicate by name, so appending a second control to a conftest that
    # already had one produced no event at all (THREATMODEL 81). The path set
    # is what makes it one.
    collect_ignored: tuple[str, ...] = ()
    # Names this unit's own body invokes (invocation, not mention) and the
    # unit's parameter names. The cross-file oracle merge is an engine step —
    # it needs to know what the unit calls (import channel) and what it
    # requests (fixture channel) without re-walking the AST there.
    invoked: tuple[str, ...] = ()
    params: tuple[str, ...] = ()
    # Stand-ins this unit installs: (dotted target, patched attribute), sorted.
    # `monkeypatch.setattr`, `mock.patch`, `patch.object`, `mocker.patch` —
    # every dialect flattened to the same pair, because a rule that knows one
    # spelling is a rule the next agent spells around.
    #
    # Collected unfiltered. Whether a target is the repo's own code is a
    # question about the *diff*, not about this file, so the judgement lives in
    # the detector where `DiffGlobals` is in reach.
    patches: tuple[tuple[str, str], ...] = ()
    # Names bound more than once whose bindings are pairwise branch-exclusive —
    # every one in a different arm of the same `if`/`elif`/`else` (or `match`)
    # chain, so at most one of them executes on any path. `bindings` joins the
    # definitions but flattens the control flow, and the difference is load-
    # bearing: a version-gated alternative golden (`if sys.version_info >=
    # (3, 13): expected = new` / `else: expected = old`) keeps the old oracle
    # alive on the path that had it, while the same two definitions on a
    # straight line are a rebind where the last one wins at the assertion.
    # rich c8abbb3bd2 (adjudicated false positive, 2026-08-25) is the first
    # shape; the guard that spares it must not spare the second.
    exclusive_bindings: tuple[str, ...] = ()
    # Each fixture this unit requests by parameter whose producer was read,
    # as (parameter, dotted callee, modules): the call the fixture returns or
    # yields, and the modules that the import binding the callee's root names
    # in the fixture's own file (#471, `frontends/python/fixture_producers`).
    # One level deep, resolved as pytest resolves the fixture for this test,
    # from this side's module and conftest chain. Repair evidence reads the
    # before side's, for a finding whose before-side assertion reads the
    # parameter (`Assertion.fixture_reads`). Sorted by parameter. Optional,
    # so IR_VERSION stays 2.
    fixture_producers: tuple[tuple[str, str, tuple[str, ...]], ...] = ()
    # Optional static relocation proofs (D-179). Empty means unknown, never
    # equality. Whole-unit identity includes decorator/parameter/module scope;
    # assertion entries include their execution/definition context.
    oracle_context: str = ""
    oracle_assertion_contexts: dict[str, str] = field(default_factory=dict)

    @property
    def disabled(self) -> bool:
        return bool(self.markers)


@dataclass
class AssertionPair:
    before_id: str
    after_id: str
    strength_change: int | None  # None when either side is unclassifiable
    # True when the pair came from the order fallback rather than from
    # matching text or matching (form, subject). A fallback pair is a guess:
    # two leftover assertions of compatible strength, paired by position and
    # nothing else. ASSERT_SUBSTITUTED exists because that guess reported
    # `strength_change: 0` for a deleted assertion whose slot a different one
    # had taken (THREATMODEL 84b).
    fallback: bool = False


@dataclass
class UnitDelta:
    assertion_pairs: list[AssertionPair] = field(default_factory=list)
    assertions_removed: list[str] = field(default_factory=list)  # before-side assertion ids
    assertions_added: list[str] = field(default_factory=list)  # after-side assertion ids
    markers_added: list[str] = field(default_factory=list)
    # Skips moved into a helper the test calls, out of one, or into a renamed
    # one, as (before name, after name): the marker is named for the helper,
    # so the move adds none, and its guard is read against the skip it was
    # (#272).
    markers_moved: list[tuple[str, str]] = field(default_factory=list)
    handlers_widened: list[str] = field(default_factory=list)
    tolerance_changes: list[tuple[str, str, str]] = field(default_factory=list)  # (kind, before, after)
    # Parametrized test items that ran before and do not run after: deleted
    # rows, and -- when the rows can be paired by identity -- rows that are
    # still written down but marked off. Never less than the live-count
    # difference the field originally held.
    param_cases_removed: int = 0
    # How many of `param_cases_removed` are lost to a `pytest.param(...,
    # marks=skip)` on a row that is still there, rather than to a deletion.
    # Kept apart only so the finding can say which happened: "1 deleted
    # (2 -> 2)" would be a lie about a row that was marked while another was
    # appended, where the live count never moved (F-063). Zero whenever the
    # rows could not be paired, so the count rule's message is unchanged.
    param_cases_disabled: int = 0
    # Skips whose guard stopped discriminating while the marker stayed the
    # same: a constant it names was edited (`STRICT = True` -> `False` under
    # `if not STRICT: pytest.skip(...)` silences the test with no marker
    # event at all, decoy probe arm 2026-08-04), its text now always holds
    # (`if True:`, THREATMODEL 54), or it was removed (#196 183.2), in the
    # test body or in the setup it runs. Entries are marker names, matched to
    # the after side.
    guards_weakened: list[str] = field(default_factory=list)


@dataclass
class Unit:
    kind: str  # "test_function"
    qualname: str
    match: str | None  # by_name | by_fingerprint | None (one-sided)
    before: UnitSide | None
    after: UnitSide | None
    delta: UnitDelta | None


@dataclass(frozen=True)
class ChangeEvidence:
    """Content identity of the analyzed change, without copying file contents.

    None means the side does not exist; an empty file has a real digest.
    Digests normalize CRLF only. Commit labels and local paths are excluded.
    rename_to preserves the destination of a rename expanded into deletion.
    """

    before_sha256: str | None
    after_sha256: str | None
    old_path: str | None = None
    rename_to: str | None = None


@dataclass
class FileIR:
    path: str
    language: str  # "python" | "unknown"
    role: str
    status: str  # added | modified | deleted
    units: list[Unit] = field(default_factory=list)
    alignment: str = "full"  # "full" | "degraded"
    parse_ok: bool = True
    # Constant environment for D6 on this file's skip conditions: name ->
    # defining expression source. Merged by the engine from the file's own
    # module-level constants plus names imported from files it can read
    # (in-diff first, then the head snapshot), so gating stays a pure
    # function of the IR. Keys are inserted in sorted order.
    constants: dict[str, str] = field(default_factory=dict)
    # The same environment resolved against this file's BASE side, so a
    # constant edit under an unchanged guard can be compared (GUARD_WEAKENED).
    constants_before: dict[str, str] = field(default_factory=dict)
    # Same-file top-level constant name -> canonical (ast.unparse) defining
    # expression, on each side. NOT the merged D6 environment above: that one
    # resolves cross-file with a head reader on the after side only, and an
    # asymmetric environment must never feed a two-sided comparison. These two
    # are the file's own module scope, both sides, canonicalized the same way
    # — the fourth expectation source for EXPECTATION_DEFINITION_CHANGED
    # (THREATMODEL 86a's largest blind bucket, 29.2% of the census; D-051).
    # Top-level rebinds are last-wins on both sides, which is module
    # execution order.
    module_constants: dict[str, str] = field(default_factory=dict)
    module_constants_before: dict[str, str] = field(default_factory=dict)
    # Complete-file literal constant rename proof; never production repair
    # credit. Only assertion pairs transformed by this bijection may use it.
    module_constant_renames: dict[str, str] = field(default_factory=dict)
    # Same-file `@pytest.fixture` name -> canonical text of what it returns or
    # yields. A fixture is not a collected unit, so without this an expectation
    # supplied by one is invisible. Conftest fixtures are out of scope.
    fixture_defs: dict[str, str] = field(default_factory=dict)
    fixture_defs_before: dict[str, str] = field(default_factory=dict)
    # Same-file helper name -> callee leaves. Repair evidence follows one
    # hop through a helper the unit actually invokes (T1.9).
    helper_calls: dict[str, tuple[str, ...]] = field(default_factory=dict)
    # Required by content-bound finding identities. Populated only for
    # relevant evidence; an absent record is not a legacy fallback.
    change_evidence: ChangeEvidence | None = None
    # Optional proof for numeric bound -> exact restoration. The engine
    # compares normalized file contents outside concrete native bare-assert
    # spans before oracle inheritance, permitting at most one changed native
    # assertion, in a single non-artifact file change with no rename. Other
    # files could redefine the callee; unknown provenance defaults to false.
    native_assertion_context_unchanged: bool = False
    # Optional closed-expression proof that added test-side normalization
    # preserves the concrete production call. Each tuple identifies
    # (unit qualname, before assertion id, after assertion id). Only strict
    # snapshot reads and a bounded, non-executing Python projection may grant
    # it; absent/unsupported evidence leaves the normal finding in place.
    normalization_equivalent_pairs: tuple[tuple[str, str, str], ...] = ()
    # Additive literal-table wrapper evidence, never equivalence credit.
    # (after unit, before text/span, after text/span, concrete old/new subject,
    # comparison operator, concrete expected expression).
    # JSON arrays reconstruct directly; the detector validates the records.
    table_normalization_events: tuple[tuple[str, str, tuple[int, int], str, tuple[int, int], str, str, str, str], ...] = ()
    # Additive expected-value provenance: (unit, old text/span, new text/span,
    # concrete subject/input, comparison operator, old expected, new expected).
    # Helpers and literal loops supply evidence only; native IR is unchanged.
    expected_provenance_events: tuple[tuple[str, str, tuple[int, int], str, tuple[int, int], str, str, str, str], ...] = ()
    # Two-sided source evidence for parametrize input roles, scoped to one
    # unchanged assertion. Decorator arguments belong to the active producer
    # only when the same unrebound local function object feeds both subjects.
    # (unit, before assertion id, after assertion id, parameter name).
    shared_param_input_pairs: tuple[tuple[str, str, str, str], ...] = ()
    # Copy-invariant input rewrites: (unit, before assertion id, after assertion
    # id, expected column, old row, new row). Each record consumes one row on
    # each side; it cannot credit a same-input answer edit or another oracle.
    param_input_identity_pairs: tuple[tuple[str, str, str, str, tuple[str, ...], tuple[str, ...]], ...] = ()
    # A JS/TS test path whose role resolved to guardrail, ci, snapshot,
    # lockfile or conftest (SPEC section 2) is still a test: every test rule
    # parses and judges it beside that role's own rules (#197). `role` stays
    # the public role, so fingerprints that include it do not move. Read it
    # through `judged_as_test`, never on its own.
    test_obligations: bool = False
    # A focus this diff adds to a JS/TS test file that had none, when the
    # file's runner is not proven to keep focus inside the file: under
    # Mocha or Jasmine every test outside it stops (#196 187.4). The head
    # side's first focus; TEST_DISABLED reports it when no unit of the file
    # already reports the focus.
    suite_focus_added: Marker | None = None


def judged_as_test(file: FileIR) -> bool:
    """Does every test rule judge this file?

    Its role is `test`, or it is a JS/TS test path that holds another role
    and carries test obligations beside it (#197). The one predicate for
    test rules, in place of `file.role == "test"`.
    """
    return file.role == "test" or file.test_obligations


@dataclass
class DiffGlobals:
    prod_files_changed: list[str] = field(default_factory=list)
    prod_symbols_changed: list[str] = field(default_factory=list)  # non-trivial only
    # Symbols that existed at base and are gone at head, in modified prod
    # files. Feature removal explains a deleted test the way a modified
    # symbol explains an edited expectation (PROD_SYMBOL_REMOVED).
    prod_symbols_deleted: list[str] = field(default_factory=list)
    # The entries of `prod_symbols_changed` that a Python prod file the diff
    # adds contributed, one per entry: a multiset, since an added `pkg.py`
    # and a modified `pkg/__init__.py` can both give `pkg::X`. Only the
    # file-scoped EXPECTED_VALUE_CHANGED reads it: nothing in a brand-new
    # file explains rewriting an existing stored expectation (#463 Q1 (a)),
    # the reason repair-evidence clause 3 and PACKAGE_REPAIR already give for
    # refusing new code. Every other reader of `prod_symbols_changed` is
    # unchanged. Optional, so IR_VERSION stays 2; an IR without it counts
    # every changed symbol, as before.
    prod_symbols_in_added_files: list[str] = field(default_factory=list)
    # Callers of changed prod symbols, for one-hop repair evidence:
    # {caller leaf name: [changed symbol leaf names it calls]}.
    prod_symbol_callers: dict[str, list[str]] = field(default_factory=dict)
    # A changed prod file checkwash cannot reason about (non-Python, or
    # Python that does not parse; never a deletion, and never unparseability
    # the diff itself caused, engine.py has the conditions). Conservatively
    # suppresses E1 — see THREATMODEL #4 — except where gating refuses it: an
    # unguarded suite control (D-028), a finding in a Python test or conftest
    # whose rule is in gating.OPAQUE_REFUSED_RULES (#419; empty, so no rule),
    # the Python unit-less broad except (D-176), and since D-199 every
    # finding whose rule takes no repair evidence (gating.REPAIR_REFUSED_PYTHON
    # and REPAIR_REFUSED_JS). The flag
    # itself stays a diff-level fact: the sweep counts it and the snapshot
    # rule reads it exactly as before (#463 Q3 (a) keeps that).
    prod_opaque_change: bool = False
    # Top-level packages/modules of changed prod files, and what each test
    # file imports. Symbol-level evidence is confined to files the diff
    # touched, so any indirection through an unchanged module breaks it —
    # which is why httpx's URL-parser commits blocked (SPEC §5).
    prod_packages: list[str] = field(default_factory=list)
    test_file_imports: dict[str, list[str]] = field(default_factory=dict)
    new_literals_in_prod: list[str] = field(default_factory=list)  # repr() of constants
    # Literals already present on the base side of any changed file. A value
    # that already existed in the codebase is not a hardcode fingerprint,
    # however new its latest occurrence looks (dogfood-found false positive).
    base_literals: list[str] = field(default_factory=list)
    guardrail_files_changed: list[str] = field(default_factory=list)
    # Guardrail files this diff *created*. A constraint that did not
    # exist has not been relaxed, and treating creation as relaxation
    # made checkwash's own installer produce a critical block (field
    # integration 2026-08-07).
    guardrail_files_created: list[str] = field(default_factory=list)
    ci_files_changed: list[str] = field(default_factory=list)
    ci_weakening_lines: list[tuple[str, str]] = field(default_factory=list)  # (path, line)
    snapshot_files_changed: list[str] = field(default_factory=list)
    test_logic_changed: bool = False  # any test-role unit delta or one-sided unit
    imports_added: list[str] = field(default_factory=list)  # "path:module"
    unresolved_imports: list[tuple[str, str]] = field(default_factory=list)  # (path, module)
    suppressions_added: list[str] = field(default_factory=list)  # "path:text"
    broad_excepts_added: list[tuple[str, str]] = field(default_factory=list)  # (path, text)
    # Test/conftest files checkwash could not parse: (path, parsed_before?).
    unparseable_tests: list[tuple[str, bool]] = field(default_factory=list)
    hidden_unicode: list[tuple[str, str, str]] = field(default_factory=list)  # (path, codepoint, escaped line)
    exemptions_added: list[str] = field(default_factory=list)  # fingerprints appended in head allow.toml
    exemption_ledger_path: str = ".greenwash/allow.toml"  # the ledger those fingerprints were appended to
    guardrail_configs_created_loosening: list[str] = field(default_factory=list)  # created own config that disables a detector or raises fail_on (issue #79)
    policy_shadows: dict[str, dict[str, str]] = field(default_factory=dict)  # IR3 required proof slot (may be empty); never inferred for IR2
    scope_allow: list[str] = field(default_factory=list)  # contract globs ([] = SCOPE_DRIFT off)
    scope_drift: list[tuple[str, str]] = field(default_factory=list)  # (path, role)
    moved_assertion_texts: list[str] = field(default_factory=list)  # normalized, sorted candidates; D-179 needs context proof
    # Body hashes of disappeared units that reappear verbatim as live added
    # units — the whole-unit form of the D2 move credit, and the only form an
    # assertion-less unit can earn. Retained diagnostic candidates; D-179
    # spends proven context/constituent assertion credits in gating.
    moved_unit_hashes: list[str] = field(default_factory=list)
    # Oracle-context hashes (IR3 / D-179) of disappeared units whose
    # identical, live copy exists at
    # head in a file the diff never touched (click 1103c5cac2: the deleted
    # test was a duplicate; the survivor still runs). A set, not a multiset:
    # one live survivor covers any number of identical deletions.
    duplicate_unit_hashes: list[str] = field(default_factory=list)
    # A dependency manifest (pyproject, requirements, lockfiles) changed in
    # this diff — the honest cause of expectation drift like httpx 0.28's
    # compact JSON separators (DEPENDENCY_DRIFT, EXPECTED_VALUE_CHANGED only).
    dependency_manifest_changed: bool = False
    # Conftest fixtures that monkeypatch a first-party target: (path, text).
    # Replacing the code under test from a fixture makes the oracle assert
    # against a stand-in while prod and tests both stay byte-identical
    # (decoy probe arm 2026-08-04).
    conftest_prod_patches: list[tuple[str, str]] = field(default_factory=list)
    # Import roots that the manifests declare as *someone else's* code, sorted.
    #
    # Declared dependencies minus the project's own name, and the second half
    # of that sentence is the whole point: `parse_manifest` folds `project.name`
    # in with the dependencies on purpose, so "declared" alone would have
    # classified `flask` as third-party inside flask — a first-party check that
    # denies the first party, dead in exactly the six repos it is measured on.
    # Empty when no manifest was read, which leaves the stdlib list as the only
    # deny and is deliberately the quieter half of the error.
    third_party_roots: tuple[str, ...] = ()
    # (finding path, module, base provider, head provider, test path, trigger).
    # Equivalent switches are excluded here, but still cannot buy repair.
    runtime_subject_shadows: list[tuple[str, str, str, str, str, str]] = field(default_factory=list)
    # Source-proved assignment/setattr/module installation reaching an existing
    # oracle: (source path, test unit, canonical target, source text, span).
    # No unit: a JS setup file installs it before every test file (#218).
    subject_installations: list[tuple[str, str | None, str, str, tuple[int, int]]] = field(default_factory=list)


@dataclass
class IR:
    base: str
    head: str
    files: list[FileIR] = field(default_factory=list)
    globals: DiffGlobals = field(default_factory=DiffGlobals)
    skipped_files: list[str] = field(default_factory=list)
    version: int = IR_VERSION


def param_tables(side: UnitSide | None) -> tuple[ParamTable, ...]:
    """A side's `param_rows`, validated, or `()` when they cannot be trusted.

    This is the one way a consumer reads the row structure, and it accepts
    every spelling the structure arrives in: the frontend's `ParamTable`
    instances, the dict-and-list form `to_jsonable` emits (dataclasses
    become dicts, tuples become lists), and a bare `(names, rows, disabled)`
    triple. Everything is normalized back to tuples, so a row can be a
    Counter key again after a JSON round trip.

    A side without `param_rows` -- an older IR payload, a unit with no
    readable table -- reads as no tables, and every consumer then keeps the
    behaviour it had before the field existed. A side whose entries do not
    all pass the shape check (a width that is not the argname count, a cell
    that is not text, a `disabled` list that does not line up) also reads as
    no tables: a partly readable structure cannot say which rows survived,
    and a finding built on the readable half would be built on nothing.
    """
    raw = getattr(side, "param_rows", None) if side is not None else None
    if not raw or isinstance(raw, (str, bytes, dict)):
        return ()
    out: list[ParamTable] = []
    try:
        for entry in raw:
            if isinstance(entry, ParamTable):
                names, rows, disabled = entry.names, entry.rows, entry.disabled
            elif isinstance(entry, dict):
                names, rows, disabled = entry["names"], entry["rows"], entry["disabled"]
            else:
                names, rows, disabled = entry
            if any(isinstance(x, (str, bytes, dict)) for x in (names, rows, disabled)):
                return ()
            names = tuple(names)
            if not names or not all(isinstance(n, str) for n in names):
                return ()
            rows = tuple(
                tuple(r) if not isinstance(r, (str, bytes, dict)) else () for r in rows
            )
            if any(len(r) != len(names) or not all(isinstance(c, str) for c in r) for r in rows):
                return ()
            disabled = tuple(disabled)
            if len(disabled) != len(rows) or not all(isinstance(d, bool) for d in disabled):
                return ()
            out.append(ParamTable(names, rows, disabled))
    except (TypeError, ValueError, KeyError):
        return ()
    return tuple(out)


def to_jsonable(obj: Any) -> Any:
    """Dataclass tree → plain JSON-serializable structure (tuples become lists)."""
    if dataclasses.is_dataclass(obj) and not isinstance(obj, type):
        return {f.name: to_jsonable(getattr(obj, f.name)) for f in dataclasses.fields(obj)}
    if isinstance(obj, (list, tuple)):
        return [to_jsonable(x) for x in obj]
    if isinstance(obj, dict):
        return {k: to_jsonable(v) for k, v in obj.items()}
    return obj


def normalize_text(text: str) -> str:
    """Normal form for pairing, moves and fingerprints.

    Strips whitespace *outside* string literals only: whitespace inside a
    quoted string is semantics, and erasing it would let a relocated
    assertion with a silently edited expected value count as "moved
    verbatim" (SPEC §5 D2 — confirmed red-team finding).
    """
    out: list[str] = []
    i, n = 0, len(text)
    while i < n:
        ch = text[i]
        if ch in "\"'":
            quote = ch * 3 if text[i : i + 3] == ch * 3 else ch
            out.append(quote)
            i += len(quote)
            while i < n:
                if text[i] == "\\" and len(quote) == 1 and i + 1 < n:
                    out.append(text[i : i + 2])
                    i += 2
                    continue
                if text.startswith(quote, i):
                    out.append(quote)
                    i += len(quote)
                    break
                out.append(text[i])
                i += 1
        elif ch.isspace():
            i += 1
        else:
            out.append(ch)
            i += 1
    return "".join(out)
