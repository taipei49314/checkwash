"""CI weakening scan. Extracted from engine (E5)."""
from __future__ import annotations

import re

from checkwash.change import FileChange
from checkwash.ci_control_flow import control_flow_weakenings, is_github_workflow
from checkwash.deps import parse_manifest_pins
from checkwash.config import Config
from checkwash.frontends.javascript.paths import is_js_test_file
from checkwash.ir.model import DiffGlobals
from checkwash.pytest_collection import pytest_collection_changes
from checkwash.roles import (
    _CI_NARROWING_TOKENS,
    _CI_SWALLOW_TOKENS,
    _TEST_RUNNER_TOKENS,
    _added_lines,
    _ci_scan_base,
    _ci_scan_view,
    _is_runner_script,
    _manifest_unreadable,
    _runner_shape,
    _runs_test_command,
    _runs_tests,
    _test_command_manifest,
    _test_commands_changed,
    is_artifact,
)

def _is_ci_workflow(path: str) -> bool:
    """A CI pipeline definition, as opposed to test-runner configuration.

    Deleting a workflow removes a gate. Deleting `tox.ini` or `setup.cfg`
    almost always means the settings moved into `pyproject.toml`, which is
    housekeeping — treating that as "the test command was weakened" blocked
    two such consolidations in the corpus. The edit is still reported at warn.
    Beneath `.github/workflows/` only YAML is a pipeline (`is_github_workflow`):
    deleting a README or a test kept there removed no gate (#197 Q5).
    """
    p = path.replace("\\", "/")
    return is_github_workflow(p) or p in (".gitlab-ci.yml", ".pre-commit-config.yaml")

def _errexit_on(data: bytes | None) -> bool:
    """Would a failing command abort this script?

    Tracks `set -e` / `set +e` and the flags on the shebang itself
    (`#!/bin/sh -e`, which is how httpx and starlette arm theirs). Last
    setting wins, exactly as the shell reads it.
    """
    if not data or len(data) > 1_000_000:
        return False
    state = False
    for line in data.decode("utf-8", errors="replace").splitlines():
        stripped = line.strip()
        words = stripped.split()
        if stripped.startswith("#!"):
            flags = words[1:]
        elif words[:1] == ["set"]:
            flags = words[1:]
        else:
            continue
        i = 0
        while i < len(flags):
            word = flags[i]
            # `set -o errexit` / `set +o errexit`: the option name is a
            # separate word, so the single-letter scan below saw neither an
            # `e` in `-o` nor a flag in `errexit` and concluded errexit was
            # never on. That is the spelling the Google shell style guide
            # recommends, which made the most careful projects the least
            # readable — and it printed "a failing command no longer fails
            # the script" over a script that still exits 1 (audit 2026-08-07).
            if word in ("-o", "+o") and i + 1 < len(flags):
                if flags[i + 1] == "errexit":
                    state = word == "-o"
                i += 2
                continue
            if word.startswith("-") and "e" in word.lstrip("-"):
                state = True
            elif word.startswith("+") and "e" in word.lstrip("+"):
                state = False
            i += 1
    return state


def _make_ignores_error(line: str) -> bool:
    """A make recipe prefixed with `-` reports success whatever it does.

    Recipes are tab-indented — YAML forbids tabs for indentation — so the tab
    is what keeps this from firing on every `- run: pytest` step in a
    workflow. `@-` and `-@` are both valid orderings.
    """
    if not line.startswith("\t"):
        return False
    body = line[1:].lstrip("@")
    return body.startswith("-") and not body[1:2].isspace() and body[1:2] != ""


def _ci_base_surface(changes: list[FileChange], config: Config, one_hop: set[str] | None = None) -> str:
    """Every ci-role file's *base* side, concatenated without losing case.

    A narrowing that already existed somewhere on this surface is not being
    introduced by the diff, wherever in the diff it now appears. That is what
    lets a configuration move between files — `setup.cfg` to `pyproject.toml`
    is the migration most of the ecosystem has made — without reading as a
    weakened test command. A JS/TS test kept in a CI directory is test code,
    not part of this surface: its text cannot pre-date a narrowing (#197 Q5).
    """
    parts: list[str] = []
    for change in changes:
        path = change.path.replace("\\", "/")
        if is_artifact(path) or not change.before or is_js_test_file(path, change.before, change.after):
            continue
        role = config.role_of(path)
        if role == "prod" and (
            _is_runner_script(path, change.before, change.after, change.old_path) or path in (one_hop or ())
            or _test_commands_changed(path, change.before, change.after)
        ):
            role = "ci"
        if role == "ci":
            # A manifest contributes its test command, not its dependencies.
            base = _ci_scan_view(path, change.before) or b""
            parts.append(base.decode("utf-8-sig", errors="replace"))
    return "\n".join(parts)


_OWN_VERSION_LINE = re.compile(rb"^\s*(?:__)?version(?:__)?\s*=.*$", re.MULTILINE)


def _deps_differ(before: bytes | None, after: bytes | None, path: str) -> bool:
    """Did a manifest's *dependencies* change — not its bytes, its pins?

    D9 `DEPENDENCY_DRIFT` credits an expectation that moved because a pinned
    dependency's behaviour moved. Any edit to a manifest used to satisfy it,
    which meant **a project bumping its own version bought the credit** — and
    almost every release commit does exactly that.

    The comparison was still bytes after the own-version strip, so a comment
    appended to requirements.txt or a swap of the `name`/`version` lines in
    pyproject.toml — no dependency touched — granted the credit to an
    expectation rewrite riding along in the same diff (audit 2026-08-19,
    both shapes reproduced as verdict pass). The semantic content is the set
    of `(distribution, pin)` pairs (`parse_manifest_pins`): reorder-invisible
    and comment-blind, while a real specifier change still differs. When
    neither side parses to a single pin, fall back to the byte comparison
    rather than declaring an exotic manifest inert.
    """
    b_pins = parse_manifest_pins(path, before or b"")
    a_pins = parse_manifest_pins(path, after or b"")
    if b_pins or a_pins:
        return b_pins != a_pins
    b = _OWN_VERSION_LINE.sub(b"", before or b"")
    a = _OWN_VERSION_LINE.sub(b"", after or b"")
    return b != a


# Swallow spellings that only mean something in one dialect, keyed on suffix so
# PowerShell idioms are not hunted in sh and vice versa. `.ps1`/`.bat`/`.cmd`
# were already reclassified to `ci` — so they never bought the opaque exemption
# — but the token table was shell/YAML-shaped, so their weakening was simply
# invisible (THREATMODEL 87a, measured 2026-08-11).
_DIALECT_SWALLOW_TOKENS: dict[tuple[str, ...], tuple[str, ...]] = {
    (".ps1",): (
        "$erroractionpreference = 'continue'",
        '$erroractionpreference = "continue"',
        "$erroractionpreference = 'silentlycontinue'",
        '$erroractionpreference = "silentlycontinue"',
        "$erroractionpreference = 'ignore'",
        '$erroractionpreference = "ignore"',
        "-erroraction silentlycontinue",
        "-erroraction ignore",
    ),
    (".bat", ".cmd"): ("exit /b 0",),
    (".sh", ".bash", ".zsh"): ("|| echo", "|| printf", "; true"),
}

# `if ! pytest; then :; fi` — the runner's failure is caught by a no-op branch.
# Requires a runner token on the same line, so a bare `then :` elsewhere in a
# script is not matched.
_NOOP_BRANCH = re.compile(r"then\s*:\s*(;|$)")


def _dialect_swallow_tokens(path: str) -> tuple[str, ...]:
    for suffixes, tokens in _DIALECT_SWALLOW_TOKENS.items():
        if path.endswith(suffixes):
            return tokens
    # A shell shebang with no extension (httpx and starlette both ship
    # `scripts/test`) still gets the sh spellings.
    return _DIALECT_SWALLOW_TOKENS[(".sh", ".bash", ".zsh")]


def _exit_code_checked(data: bytes | None, needle: str) -> bool:
    """Does this script inspect the runner's exit status at all?

    The two-sided counterpart of `_errexit_on`, for dialects that have no
    `set -e`: PowerShell scripts gate on `$LASTEXITCODE`, cmd scripts on
    `if errorlevel`. Losing the check is exactly as permissive as losing
    errexit, and produces no added line for the scan above to see.
    """
    if not data or len(data) > 1_000_000:
        return False
    return needle in data.decode("utf-8", errors="replace").lower()


def _scan_ci_weakening(
    g: DiffGlobals,
    path: str,
    before: bytes | None,
    after: bytes | None,
    ci_base: str = "",
    old_path: str | None = None,
) -> None:
    # A package manifest is test-runner configuration only in its test
    # command (issue #174): `prepare: husky || true` beside it swallows
    # nothing the suite reports. Read exactly the commands the test command
    # runs, in the sh dialect npm hands them to. Added commands are counted
    # against the base values of every script in the test command on either
    # side (`_ci_scan_base`): a script the diff only starts calling wrote no
    # new text. A side this reader cannot open is not projected; both sides
    # are then read whole, line against line, like any other ci file.
    manifest = _test_command_manifest(path) is not None
    added_base = before
    if manifest and not (
        _manifest_unreadable(path, before) or _manifest_unreadable(path, after)
    ):
        added_base = _ci_scan_base(path, before, after)
        before, after = _ci_scan_view(path, before), _ci_scan_view(path, after)
    # A file that did not exist at base cannot have *narrowed* anything —
    # there was no test command there to narrow. It can still swallow an exit
    # code, which is why the two families are separated.
    existed = bool(before)
    dialect = (
        _dialect_swallow_tokens(path)
        if manifest or _runner_shape(path, before, after)
        else ()
    )
    for line in _added_lines(added_base, after):
        lowered = line.lower()
        swallowed = any(token in lowered for token in _CI_SWALLOW_TOKENS) or (
            any(token in lowered for token in dialect)
        ) or (
            bool(_NOOP_BRANCH.search(lowered))
            and _runs_test_command(line.encode("utf-8", errors="replace"))
        )
        narrowed = existed and any(
            token in lowered and token not in ci_base.lower() for token in _CI_NARROWING_TOKENS
        )
        if swallowed or narrowed or (
            _make_ignores_error(line) and _runs_test_command(line.encode("utf-8", errors="replace"))
        ):
            g.ci_weakening_lines.append((path, line.strip()[:200]))
    # Keep the established evidence/fingerprint when the legacy scanner
    # already owns this file. New collection syntax fills its blind spots.
    # Fingerprints remain bound to the complete changed file contents.
    if (not any(p == path for p, _ in g.ci_weakening_lines) and after
            and (_runs_tests(before, old_path or path) or _runs_tests(after, path)
                 or path.endswith(("pytest.ini", "tox.ini", "setup.cfg", "pyproject.toml")))):
        for reason in pytest_collection_changes(ci_base or (before or b"").decode("utf-8-sig", errors="replace"), after.decode("utf-8-sig", errors="replace")):
            g.ci_weakening_lines.append((path, reason))
    # A condition, a trigger or a hook inventory can stop a runner while every
    # runner line stays byte-identical, so the added-line scan above has
    # nothing to read: `if: false` under `- run: pytest` passed at warn while
    # `pytest || true` on the same step blocked (issue #181). Both sides must
    # exist: a new file had no runner to disable, and a deleted workflow is
    # the engine's removal rule.
    if before and after:
        for reason in control_flow_weakenings(path, before, after):
            g.ci_weakening_lines.append((path, reason))
    # The two weakenings that a scan of *added* lines can never see, both
    # meaningful only in a shell script — so a yaml or ini file, where
    # neither idea applies, is not judged on them. `after` truthy, not just
    # non-None: a deleted or emptied script has no commands left to be
    # lenient about, and removal is the consolidation case this project
    # deliberately does not escalate. A manifest's test command is a list of
    # commands, not a script, and is judged on its added commands only.
    if manifest or not (after and _runner_shape(path, before, after)):
        return
    if _errexit_on(before) and not _errexit_on(after):
        # `#!/bin/sh -e` -> `#!/bin/sh` removes the only reason a failing
        # pytest fails the script, and adds no line worth scanning.
        g.ci_weakening_lines.append((path, "errexit removed: a failing command no longer fails the script"))
    if path.endswith(".ps1") and _exit_code_checked(before, "$lastexitcode") and not _exit_code_checked(
        after, "$lastexitcode"
    ):
        g.ci_weakening_lines.append(
            (path, "$LASTEXITCODE is no longer checked: a failing command no longer fails the script")
        )
    if path.endswith((".bat", ".cmd")) and _exit_code_checked(
        before, "errorlevel"
    ) and not _exit_code_checked(after, "errorlevel"):
        g.ci_weakening_lines.append(
            (path, "errorlevel is no longer checked: a failing command no longer fails the script")
        )
    if _runs_test_command(before, old_path or path) and not _runs_test_command(after, path):
        # Deleting the invocation is the same gate removal as weakening it,
        # and quieter: the pipeline still calls a script that still exits 0.
        # Swapping one runner for another (pytest -> nox, or to `node
        # --test`, which runs only in command position: #216) keeps a runner
        # and earns nothing, which is the consolidation this must not punish.
        g.ci_weakening_lines.append((path, "the test suite is no longer invoked by this script"))
