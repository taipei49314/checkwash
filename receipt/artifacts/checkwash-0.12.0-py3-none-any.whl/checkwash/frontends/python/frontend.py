"""Python frontend: stdlib-ast parsing of one file side into semantic units.

See DECISIONS.md D-001 for why this is `ast` and not tree-sitter in v0.1.
A file that fails to parse is reported with parse_ok=False and surfaces in
`skipped_files` — visible degradation, never silent (SPEC §8).
"""

from __future__ import annotations

import ast
import bisect
import hashlib
import math
import operator
import re
from collections.abc import Iterator
from dataclasses import dataclass, field, replace
from types import SimpleNamespace

from checkwash.frontends.python.binding_canonical import binding_key as _binding_key
from checkwash.frontends.python.conditional_oracles import conditional_oracle_carriers
from checkwash.frontends.python.failure_relays import Reader as _RelayReader
from checkwash.frontends.python.failure_relays import candidate as _relay_candidate
from checkwash.frontends.python.fixture_producers import (
    ProducerScope,
    _binders as _fixture_binders,
    assertion_names,
    import_modules,
    nested_bound_names,
    unit_producers,
)
from checkwash.frontends.python.hook_guards import collection_hook_guards, weakest
from checkwash.frontends.python.own_marks import OwnMarks, reads_marks, resolve as resolve_own_marks
from checkwash.frontends.python.runtime_controls import runtime_controls
from checkwash.frontends.python.syntax import parse_module
from checkwash.frontends.python.setup_skip_controls import (
    BODY_MARKERS,
    ConftestLevel,
    SetupScope,
    _conjunction,
    _import_pairs,
    _names as _bound_names,
    body_bindings,
    body_outcome,
    conftest_level,
    module_bindings,
    setup_helper_outcomes,
    setup_outcomes,
)
from checkwash.frontends.python.branch_constants import guard_truths, literal_fixtures
from checkwash.frontends.python.class_attributes import NONE as CLASS_NONE
from checkwash.frontends.python.class_attributes import OBJECT as CLASS_OBJECT
from checkwash.frontends.python.class_attributes import ClassAttributes, ClassValue, receivers, substitute
from checkwash.frontends.python.helper_skips import (
    Foreign,
    HelperOutcomes,
    ImportedHelpers,
    imported_helper_names,
)
from checkwash.frontends.python.inherited_tests import inherited_test_methods
from checkwash.frontends.python.rebindings import Reader as _BindingReader
from checkwash.frontends.python.rebindings import Status as BindingStatus
from checkwash.frontends.python.rebindings import final_bindings
from checkwash.frontends.python.self_methods import TESTCASE_NAMES, Methods, instance_calls, receiver
from checkwash.frontends.python.doctest_oracles import checked_examples, module_examples
from checkwash.frontends.python.literal_string_methods import literal_string_replace
from checkwash.frontends.python.literal_conversions import (
    conversion_names as _conversion_names_of,
    folded_conversion as _folded_conversion,
    module_bindings as _module_bindings_of,
    unbound_callee as _unbound_callee,
)
from checkwash.frontends.python.tolerance_calls import (
    find_predicate as _find_tolerance_predicate,
    import_names as _tolerance_import_names,
    may_resolve as _tolerance_may_resolve,
    statement_call as _tolerance_statement,
    tolerance as _call_tolerance,
    values as _tolerance_values,
)
from checkwash.ir import strength as S
from checkwash.ir.astutil import dotted_name as _dotted
from checkwash.ir.astutil import stable_dump as _stable_dump
from checkwash.ir.markers import parse_expr
from checkwash.ir.model import Assertion, Handler, Marker, ParamTable, UnitSide, normalize_text
from checkwash.ir.subjects import reaching_signature

_SUPPRESSION_RE = re.compile(r"#\s*(noqa|type:\s*ignore)", re.IGNORECASE)

# unittest assertion method -> (form, strength). Unknown methods are left
# unclassified on purpose (fail-safe: no guess, no noise).
_UNITTEST_MAP: dict[str, tuple[str, int | None]] = {
    # The whole *Equal family sits at EXACT_VALUE; the container-LITERAL
    # upgrade to EXACT_STRUCT is applied uniformly afterwards. unittest's
    # assertEqual type-dispatches to assertListEqual at runtime, so rating
    # them differently turned a style cleanup into a blocking "weakening"
    # (confirmed red-team false positive).
    "assertEqual": ("compare_eq", S.EXACT_VALUE),
    "assertNotEqual": ("compare_eq", S.EXACT_VALUE),
    "assertListEqual": ("compare_eq", S.EXACT_VALUE),
    "assertDictEqual": ("compare_eq", S.EXACT_VALUE),
    "assertSetEqual": ("compare_eq", S.EXACT_VALUE),
    "assertTupleEqual": ("compare_eq", S.EXACT_VALUE),
    "assertSequenceEqual": ("compare_eq", S.EXACT_VALUE),
    "assertMultiLineEqual": ("compare_eq", S.EXACT_VALUE),
    "assertAlmostEqual": ("approx", S.APPROX),
    "assertNotAlmostEqual": ("approx", S.APPROX),
    "assertTrue": ("truthy", S.TRUTHY),
    "assertFalse": ("truthy", S.TRUTHY),
    "assertIsNone": ("non_null", S.NON_NULL),
    "assertIsNotNone": ("non_null", S.NON_NULL),
    # THREATMODEL row 33 claimed `is`/`is not` polarity flips were closed, but
    # the unittest spelling was never in this map at all, so assertIs ->
    # assertIsNot produced no classification and no finding (reader audit
    # 2026-08-02).
    "assertIs": ("compare_eq", S.EXACT_VALUE),
    "assertIsNot": ("compare_eq", S.EXACT_VALUE),
    "assertCountEqual": ("compare_eq", S.EXACT_VALUE),
    "assertGreater": ("compare_ord", S.BOUND),
    "assertGreaterEqual": ("compare_ord", S.BOUND),
    "assertLess": ("compare_ord", S.BOUND),
    "assertLessEqual": ("compare_ord", S.BOUND),
    "assertIn": ("membership", S.PATTERN),
    "assertNotIn": ("membership", S.PATTERN),
    "assertRegex": ("pattern", S.PATTERN),
    "assertNotRegex": ("pattern", S.PATTERN),
    "assertIsInstance": ("type_shape", S.TYPE_SHAPE),
    "assertNotIsInstance": ("type_shape", S.TYPE_SHAPE),
    "assertRaises": ("raises", None),
    "assertRaisesRegex": ("raises", None),
    "assertWarns": ("raises", None),
    "assertWarnsRegex": ("raises", None),
}

_SKIP_DECORATORS = {
    "pytest.mark.skip",
    "pytest.mark.skipif",
    "pytest.mark.xfail",
    "unittest.skip",
    "unittest.skipIf",
    "unittest.skipUnless",
    "unittest.expectedFailure",
    "skip",
    "skipIf",
    "skipUnless",
    "expectedFailure",
}

# A body skip is any native outcome call or raise, read through the module's
# import bindings (`setup_skip_controls.body_outcome`, #220). The literal set
# of four dotted spellings it replaces missed `pt.skip()` and a bare `skip()`
# imported from pytest, and read `raise unittest.SkipTest` as removed
# assertions. Roots that can spell one when nothing rebinds them:
_OUTCOME_ROOTS = frozenset({"pytest", "_pytest", "unittest", "self"})
# An indented import line: only then can a test bind a skip under its own name.
_NESTED_IMPORT = re.compile(r"^[ \t]+(?:import|from)[ \t]", re.MULTILINE)

# Every native setup outcome (`setup_skip_controls`) is spelled with one of
# these, if only on its import line; a module without them has none to find.
_SETUP_OUTCOME_TOKENS = ("skip", "Skip", "xfail", "XFail")

# AssertionError belongs here: catching it is precisely how you swallow an
# oracle, and it is the obvious variant of the broad-except cheat.
_BROAD_EXCEPTIONS = {"Exception", "BaseException", "AssertionError"}

# A module spells one of these, if it binds a name inside an expression or
# through a literal-name call (#424 Q4); one without them skips that walk.
_EXPRESSION_BINDING_TOKENS = (":=", "setattr", "delattr", "globals", "vars(", "locals(")

# conftest.py is where pytest lets you disable collection for a whole tree.
# These are the curated suite-level controls TEST_DISABLED watches for.
_CONFTEST_HOOKS = {"pytest_ignore_collect", "pytest_collection_modifyitems"}
_CONFTEST_NAMES = {"collect_ignore", "collect_ignore_glob"}


@dataclass
class ParsedUnit:
    qualname: str
    span: tuple[int, int]
    side: UnitSide
    shingles: frozenset[tuple[str, ...]] = frozenset()


@dataclass
class ParsedFile:
    parse_ok: bool
    units: list[ParsedUnit] = field(default_factory=list)
    symbols: dict[str, str] = field(default_factory=dict)  # qualname -> behaviour fingerprint
    symbol_calls: dict[str, tuple[str, ...]] = field(default_factory=dict)  # qualname -> callees
    imports: list[str] = field(default_factory=list)
    # Top-level `NAME = <expr>` bindings, name -> expression source (last
    # binding wins, matching module semantics). Conditional definitions
    # (inside if/try) are deliberately absent: a name checkwash cannot pin
    # to one expression stays unevaluable.
    constants: dict[str, str] = field(default_factory=dict)
    # Module-level oracle carriers, for the engine's cross-file merge (A5-x).
    # `helper_asserts`: non-fixture, non-test top-level def -> its own direct
    # asserts (classified, `inherited=True`, ids assigned at merge time).
    # `fixture_asserts`: @pytest.fixture def -> every assert lexically inside
    # it, nested defs included — the returned closure is what a unit calls,
    # and the post-`yield` teardown runs unconditionally.
    helper_asserts: dict[str, tuple] = field(default_factory=dict)
    # Non-test, non-fixture top-level defs -> callee leaves. Repair evidence
    # follows one hop through a helper the unit actually invokes (T1.9).
    helper_calls: dict[str, tuple[str, ...]] = field(default_factory=dict)
    fixture_asserts: dict[str, tuple] = field(default_factory=dict)
    autouse_fixtures: tuple[str, ...] = ()
    # Same-file `@pytest.fixture` name -> canonical text of what it produces.
    fixture_defs: dict[str, str] = field(default_factory=dict)
    # Top-level absolute `from M import a as b` bindings, local -> (module,
    # original). Relative and star imports are not recorded.
    from_imports: dict[str, tuple[str, str]] = field(default_factory=dict)
    suppressions: list[str] = field(default_factory=list)
    literals: frozenset[str] = frozenset()
    broad_handlers: tuple[str, ...] = ()  # normalized texts of broad except handlers, module-wide
    # Subset of the above that actually hides a failure: the guarded block
    # holds an oracle and the handler neither re-raises nor asserts. Test
    # files are judged on this narrower list, production files on the full one
    # — swallowing an error in prod is its own cheat, but a test that provokes
    # an error on purpose and inspects it hides nothing.
    swallowing_handlers: tuple[str, ...] = ()
    # Subset of `swallowing_handlers`: the handlers that relay the failure to
    # a future the test awaits (proven failure relays, SPEC §4, D-190). The
    # engine reads them on a change's after side only, to cap what it counts
    # as added, never above 0.10's count. Python only, and only in a
    # collected test module.
    relay_handlers: tuple[str, ...] = ()
    # JS only: the file's first focus (`.only`, `fit`, `fdescribe`,
    # `{ only: true }`), whatever it turns off in this file (#196 187.4).
    focus: Marker | None = None
    # JS only: whether the file declares a test, scanned as a unit or not: a
    # `.each` table or a computed title with an inline callback counts, a
    # `pattern.test(value)` call does not (#196 186.8).
    declares_tests: bool = False
    # A setup marker whose outcome lies in a conftest fixture (#223), keyed by
    # (name, span, text) -> that conftest's path. Its text and span are in
    # that file, so a report locates it there, not in this one.
    marker_origins: dict[tuple[str, tuple[int, int], str], str] = field(default_factory=dict)
    # JS only (#429): the spans of assertions a test callback spells but never
    # reaches, with a strength and without one. Not IR: they keep the coverage
    # inventory from reading them as calls the scan does not represent.
    unreachable_assertion_spans: tuple[tuple[int, int], ...] = ()
    unreachable_unjudged_assertion_spans: tuple[tuple[int, int], ...] = ()


# One parse's walks of a subtree (#344). A unit's tree is walked by several
# passes, and the walk is the parse's largest cost, so `parse_python` walks
# each subtree once, after its last change to the tree, and reuses the nodes.
_walks: dict[int, tuple[ast.AST, tuple[ast.AST, ...]]] | None = None


def _walk(node: ast.AST):
    """`ast.walk(node)`, read once per parse while one is running (#344)."""
    walks = _walks
    if walks is None:
        return ast.walk(node)
    known = walks.get(id(node))
    if known is None or known[0] is not node:
        known = walks[id(node)] = (node, tuple(ast.walk(node)))
    return iter(known[1])


def normalize_source(data: bytes) -> str:
    # utf-8-sig strips a BOM if present (routine on Windows-authored files);
    # spans are offsets into this normalized text (SPEC §8).
    text = data.decode("utf-8-sig", errors="replace")
    return text.replace("\r\n", "\n").replace("\r", "\n")


class _Offsets:
    """Line-start index over the normalized source.

    `seg()` replaces ast.get_source_segment, which re-splits the whole file on
    every call — O(file) per assertion made a 3000-line diff take seconds and
    tripped the perf gate.
    """

    def __init__(self, text: str) -> None:
        starts = [0]
        for i, ch in enumerate(text):
            if ch == "\n":
                starts.append(i + 1)
        self._starts = starts
        self._len = len(text)
        self.text = text
        self._bytecols: dict[int, list[int]] = {}
        self._ascii_lines: dict[int, bool] = {}
        # The parsed module, when the parser attaches it, for the rare
        # question about the whole file (`_shadows_abs`); asked lazily.
        self.tree: ast.AST | None = None
        self.abs_shadowed: bool | None = None
        self.tolerance_names: dict[str, str | None] | None = None
        # The names the module binds, and the spellings that fold as
        # conversions (#226), asked lazily as the two above are.
        self.module_bindings: tuple | None = None
        self.conversion_names: dict[str, str] | None = None
        # The spellings that name unittest.mock.ANY in this file (D-201).
        self.mock_any_names: frozenset[str] | None = None

    def _char_col(self, lineno: int, col: int) -> int:
        """Translate CPython's UTF-8 *byte* column into a character column.

        `ast` documents col_offset as a byte offset. Adding it straight to a
        character-indexed line start shifted every span on any line holding
        non-ASCII text, so `seg()` returned garbled source — which silently
        reopened the self-comparison bypass (#10), because the tautology check
        compares extracted source strings and they no longer matched. One CJK
        character in a test literal was enough (reader audit 2026-08-02).
        """
        idx = lineno - 1
        if col <= 0 or idx < 0 or idx >= len(self._starts):
            return col
        if idx not in self._ascii_lines:
            start = self._starts[idx]
            end = self._starts[idx + 1] if idx + 1 < len(self._starts) else self._len
            self._ascii_lines[idx] = self.text[start:end].isascii()
        if self._ascii_lines[idx]:  # bytes == chars; do not rescan a long line per name
            return col
        table = self._bytecols.get(idx)
        if table is None:
            start = self._starts[idx]
            end = self._starts[idx + 1] if idx + 1 < len(self._starts) else self._len
            line = self.text[start:end]
            table = []
            byte = 0
            for ch in line:
                table.append(byte)
                byte += len(ch.encode("utf-8"))
            table.append(byte)
            self._bytecols[idx] = table
        pos = bisect.bisect_left(table, col)
        return min(pos, len(table) - 1)

    def span(self, node: ast.AST) -> tuple[int, int]:
        lineno = getattr(node, "lineno", 1)
        col = getattr(node, "col_offset", 0)
        end_lineno = getattr(node, "end_lineno", lineno)
        end_col = getattr(node, "end_col_offset", col)
        try:
            start = self._starts[lineno - 1] + self._char_col(lineno, col)
            end = self._starts[end_lineno - 1] + self._char_col(end_lineno, end_col)
        except IndexError:  # synthesized node (e.g. inserted Pass)
            return (0, 0)
        return (min(start, self._len), min(end, self._len))

    def seg(self, node: ast.AST) -> str:
        start, end = self.span(node)
        return self.text[start:end]


def _is_container_literal(node: ast.AST) -> bool:
    return isinstance(node, (ast.List, ast.Dict, ast.Set, ast.Tuple)) and _is_literal(node)


def _norm(text: str) -> str:
    return "".join(text.split())


def _strip_identity(node: ast.AST, text) -> str:
    """Source text of `node` with outer no-op arithmetic peeled off.

    `x + 0`, `0 + x`, `x - 0`, `x * 1`, `1 * x`, `x / 1` all reduce to `x`,
    recursively. Used only to unmask `f(x) == f(x) + 0` self-comparisons.
    """
    if isinstance(node, ast.BinOp):
        left, right = node.left, node.right
        if isinstance(node.op, ast.Add):
            if _is_zero(right):
                return _strip_identity(left, text)
            if _is_zero(left):
                return _strip_identity(right, text)
        elif isinstance(node.op, ast.Sub) and _is_zero(right):
            return _strip_identity(left, text)
        elif isinstance(node.op, ast.Mult):
            if _is_one(right):
                return _strip_identity(left, text)
            if _is_one(left):
                return _strip_identity(right, text)
        elif isinstance(node.op, ast.Div) and _is_one(right):
            return _strip_identity(left, text)
    return text.seg(node) or ""


def _is_zero(node: ast.AST) -> bool:
    return isinstance(node, ast.Constant) and node.value == 0 and not isinstance(node.value, bool)


def _is_one(node: ast.AST) -> bool:
    return isinstance(node, ast.Constant) and node.value == 1 and not isinstance(node.value, bool)


def _is_literal(node: ast.AST) -> bool:
    if isinstance(node, ast.Constant):
        return True
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.USub, ast.UAdd)):
        return _is_literal(node.operand)
    if isinstance(node, (ast.Tuple, ast.List, ast.Set)):
        return all(_is_literal(e) for e in node.elts)
    if isinstance(node, ast.Dict):
        return all(k is not None and _is_literal(k) for k in node.keys) and all(
            _is_literal(v) for v in node.values
        )
    return False


def _literal_repr(node: ast.AST, text: str, *, fold_string_methods=True, conversions=None) -> str | None:
    if (_is_literal(node) or fold_string_methods and literal_string_replace(node) is not None
            or _folded_conversion(node, conversions) is not None):
        seg = text.seg(node)
        if seg is not None and len(seg) <= 120:
            return seg
    return None


def _is_approx_call(node: ast.AST) -> bool:
    return isinstance(node, ast.Call) and _dotted(node.func) in ("pytest.approx", "approx")


# `unittest.mock.ANY` equals every value, so an equality with it as a whole
# operand passes whatever the other side is, however exact it looks.
# `assert total() == ANY` was read as an expectation changed to another name,
# which D9's DEPENDENCY_DRIFT holds at warn beside any version bump in a
# manifest (D-201). Read through the file's imports, so a project's own
# `ANY` constant is not mock's and an alias is: `from unittest.mock import
# ANY as anything`, `from unittest import mock as um` -> `um.ANY`. Only a
# whole operand: in `{"id": ANY, "name": "x"}` the other entries are still
# checked.


_MOCK_MODULES = frozenset({"unittest.mock", "mock"})


def _mock_any_dotted(tree: ast.AST | None) -> frozenset[str]:
    """The dotted spellings of unittest.mock.ANY a module's imports allow, wherever they are.

    pytest-mock's fixture attribute, `mocker.ANY`, is read by name. Without
    a parsed module (an oracle helper's own offsets) the plain module
    spellings are. A module's name is read whatever else the file calls by
    it, since a local mock called `mock` is common and its `.ANY` compared in
    an assertion is not.
    """
    names = {"mocker.ANY"}
    if tree is None:
        return frozenset(names | {"mock.ANY", "unittest.mock.ANY"})
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom) and node.level == 0 and node.module == "unittest":
            names.update((alias.asname or "mock") + ".ANY" for alias in node.names if alias.name == "mock")
        elif isinstance(node, ast.Import):
            for alias in node.names:
                if alias.name == "mock":
                    names.add((alias.asname or "mock") + ".ANY")
                elif alias.name == "unittest.mock":
                    names.add(alias.asname + ".ANY" if alias.asname else "unittest.mock.ANY")
                elif alias.name == "unittest":
                    names.add((alias.asname or "unittest") + ".mock.ANY")
    return frozenset(names)


def _scope_names(stmts, dotted: frozenset[str], outer: dict[str, set[str]] | None = None,
                 names: dict[str, set[str]] | None = None) -> dict[str, set[str]]:
    """The names one scope binds, each "mock" (bound to mock's ANY) or "other" (D-201).

    A bare `ANY` means whatever the innermost scope binding it binds it to,
    as Python reads it: `from unittest.mock import ANY` (or `*`), an alias
    of it, or an assignment whose value is mock's ANY is "mock"; any other
    binding, an import from elsewhere included, is "other". Nested functions
    and classes are scopes of their own, and a comprehension's targets are
    its own. Walked with an explicit stack in source order: a megabyte-deep
    expression must not recurse.
    """
    names = {} if names is None else names
    outer = outer or {}

    def bind(name: str, kind: str) -> None:
        names.setdefault(name, set()).add(kind)

    def is_any(node: ast.AST | None) -> bool:
        if isinstance(node, ast.Name):
            return (names.get(node.id) or outer.get(node.id)) == {"mock"}
        return node is not None and _dotted(node) in dotted

    def bind_target(target: ast.AST, kind: str) -> None:
        targets = [(target, kind)]
        while targets:
            node, how = targets.pop()
            if isinstance(node, ast.Name):
                bind(node.id, how)
            elif isinstance(node, (ast.Tuple, ast.List)):
                targets.extend((elt, "other") for elt in node.elts)
            elif isinstance(node, ast.Starred):
                targets.append((node.value, "other"))

    stack = list(reversed(list(stmts)))
    while stack:
        node = stack.pop()
        later: list[ast.AST] = []
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            bind(node.name, "other")
            later = [*node.decorator_list, *node.args.defaults, *(d for d in node.args.kw_defaults if d is not None)]
        elif isinstance(node, ast.ClassDef):
            bind(node.name, "other")
            later = [*node.decorator_list, *node.bases, *(k.value for k in node.keywords)]
        elif isinstance(node, ast.Lambda):
            later = [*node.args.defaults, *(d for d in node.args.kw_defaults if d is not None)]
        elif isinstance(node, (ast.ListComp, ast.SetComp, ast.DictComp, ast.GeneratorExp)):
            later = [node.generators[0].iter] if node.generators else []
        elif isinstance(node, ast.Import):
            for alias in node.names:
                bind(alias.asname or alias.name.split(".", 1)[0], "other")
        elif isinstance(node, ast.ImportFrom):
            mock = node.level == 0 and node.module in _MOCK_MODULES
            for alias in node.names:
                if alias.name == "*":
                    if mock:
                        bind("ANY", "mock")
                    continue
                bind(alias.asname or alias.name, "mock" if mock and alias.name == "ANY" else "other")
        elif isinstance(node, (ast.Assign, ast.AnnAssign)):
            kind = "mock" if is_any(node.value) else "other"
            for target in (node.targets if isinstance(node, ast.Assign) else [node.target]):
                bind_target(target, kind)
            later = [node.value] if node.value is not None else []
        elif isinstance(node, (ast.AugAssign, ast.NamedExpr)):
            bind_target(node.target, "other")
            later = [node.value]
        elif isinstance(node, (ast.For, ast.AsyncFor)):
            bind_target(node.target, "other")
            later = [node.iter, *node.body, *node.orelse]
        elif isinstance(node, ast.withitem):
            if node.optional_vars is not None:
                bind_target(node.optional_vars, "other")
            later = [node.context_expr]
        else:
            if isinstance(node, ast.ExceptHandler) and node.name:
                bind(node.name, "other")
            elif isinstance(node, (ast.MatchAs, ast.MatchStar)) and node.name:
                bind(node.name, "other")
            elif isinstance(node, ast.MatchMapping) and node.rest:
                bind(node.rest, "other")
            later = list(ast.iter_child_nodes(node))
        stack.extend(reversed(later))
    return names


def _any_scopes(tree: ast.AST | None) -> tuple:
    """The dotted spellings, the module's own bindings, each function's span and
    bindings, and every name some scope binds to mock's ANY."""
    dotted = _mock_any_dotted(tree)
    if tree is None:
        return dotted, {}, [], frozenset()
    module = _scope_names(getattr(tree, "body", []), dotted)
    functions = []
    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) or not hasattr(node, "end_lineno"):
            continue
        names: dict[str, set[str]] = {}
        args = node.args
        positional = [*args.posonlyargs, *args.args]
        defaults = [None] * (len(positional) - len(args.defaults)) + list(args.defaults)
        for arg, default in [*zip(positional, defaults), *zip(args.kwonlyargs, args.kw_defaults)]:
            # A default is evaluated where the function is defined; the
            # module's reading is the one checked.
            mock = default is not None and (
                module.get(default.id) == {"mock"} if isinstance(default, ast.Name) else _dotted(default) in dotted)
            names.setdefault(arg.arg, set()).add("mock" if mock else "other")
        for arg in (args.vararg, args.kwarg):
            if arg is not None:
                names.setdefault(arg.arg, set()).add("other")
        _scope_names(node.body, dotted, module, names)
        functions.append(((node.lineno, node.col_offset), (node.end_lineno, node.end_col_offset), names))
    bound = frozenset(name for scope in (module, *(f[2] for f in functions))
                      for name, kinds in scope.items() if "mock" in kinds)
    return dotted, module, functions, bound


def _mock_any_scopes(text) -> tuple:
    """`_any_scopes` for this file, worked out once per file."""
    if getattr(text, "mock_any_scopes", None) is None:
        scopes = _any_scopes(getattr(text, "tree", None))
        try:
            text.mock_any_scopes = scopes
        except AttributeError:
            return scopes
    return text.mock_any_scopes


def _is_mock_any(node: ast.AST | None, text) -> bool:
    """Is this operand mock's ANY? (D-201)

    A dotted spelling is read through the file's imports. A bare name is
    read as Python reads it: the innermost function enclosing it that binds
    the name decides, then the module, so a parameter or loop variable
    called `ANY` in another function changes nothing here, and `ANY = 6` in
    the module or in this function makes it a value.
    """
    if node is None:
        return False
    dotted, module, functions, bound = _mock_any_scopes(text)
    if not isinstance(node, ast.Name):
        return _dotted(node) in dotted
    if node.id not in bound:
        return False
    if not hasattr(node, "lineno"):
        return module.get(node.id) == {"mock"}
    where = (node.lineno, node.col_offset)
    enclosing = sorted((f for f in functions if f[0] <= where < f[1]), key=lambda f: f[0], reverse=True)
    for _start, _end, names in enclosing:
        if node.id in names:
            return names[node.id] == {"mock"}
    return module.get(node.id) == {"mock"}


def _only_any(node: ast.AST | None, text, depth: int = 0) -> bool:
    """A list, tuple or dict every checked entry of which is mock's ANY (D-201).

    `[ANY, ANY, ANY]` or `{"total": ANY}` checks only the shape: a length,
    or the keys. So do the nested displays (`{"a": {"b": ANY}}`), a
    repetition (`[ANY] * 3`), a comprehension of ANY (`[ANY for _ in
    range(3)]`, `{k: ANY for k in keys}`) and `dict.fromkeys(keys, ANY)`. A
    set display is not one: its entries are hashed, not compared.
    """
    if depth > 32:
        return False
    deeper = depth + 1
    if isinstance(node, (ast.List, ast.Tuple)):
        return bool(node.elts) and all(_any_like(e, text, deeper) for e in node.elts)
    if isinstance(node, ast.Dict):
        return bool(node.values) and None not in node.keys and all(_any_like(v, text, deeper) for v in node.values)
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Mult):
        return _only_any(node.left, text, deeper) or _only_any(node.right, text, deeper)
    if isinstance(node, ast.ListComp):
        return _any_like(node.elt, text, deeper)
    if isinstance(node, ast.DictComp):
        return _any_like(node.value, text, deeper)
    if isinstance(node, ast.Call) and _dotted(node.func) == "dict.fromkeys" and len(node.args) == 2:
        return _any_like(node.args[1], text, deeper)
    if (isinstance(node, ast.Call) and _dotted(node.func) == "dict" and not node.args and node.keywords
            and all(k.arg is not None and _any_like(k.value, text, deeper) for k in node.keywords)):
        return True
    return False


def _shaped_by(display: ast.AST | None, subject: ast.AST | None, text) -> bool:
    """An all-ANY display whose length or keys come from the subject itself (D-201).

    `[ANY] * len(items())` against `items()`, or `dict.fromkeys(record(),
    ANY)` against `record()`, has the subject's own shape, so the equality
    holds whatever the subject is.
    """
    if display is None or subject is None:
        return False
    same = _norm(text.seg(subject) or "")
    if isinstance(display, ast.BinOp) and isinstance(display.op, ast.Mult):
        for one, count in ((display.left, display.right), (display.right, display.left)):
            if (isinstance(one, (ast.List, ast.Tuple)) and len(one.elts) == 1 and _any_like(one.elts[0], text)
                    and isinstance(count, ast.Call) and _dotted(count.func) == "len" and len(count.args) == 1
                    and same and _norm(text.seg(count.args[0]) or "") == same):
                return True
    if (isinstance(display, ast.Call) and _dotted(display.func) == "dict.fromkeys" and len(display.args) == 2
            and _any_like(display.args[1], text) and same and _norm(text.seg(display.args[0]) or "") == same):
        return True
    return False


def _any_like(node: ast.AST | None, text, depth: int = 0) -> bool:
    """Mock's ANY, or a display of nothing but it: compares as anything of its shape."""
    return _is_mock_any(node, text) or _only_any(node, text, depth)


def _elementwise_unchecked(left: ast.AST | None, right: ast.AST | None, text) -> bool:
    """Two displays of one kind and length no position of which is checked (D-201).

    `(total(), 0) == (ANY, 0)` and `(total(), ANY) == (ANY, 6)` hold for
    every value: each position has ANY on one side, or the same literal on
    both.
    """
    if not (isinstance(left, (ast.List, ast.Tuple)) and type(left) is type(right)
            and len(left.elts) == len(right.elts) and left.elts):
        return False
    for a, b in zip(left.elts, right.elts):
        if _any_like(a, text) or _any_like(b, text):
            continue
        if _is_literal(a) and _is_literal(b) and _norm(text.seg(a) or "") == _norm(text.seg(b) or ""):
            continue
        return False
    return True


def _holds_any(node: ast.AST | None, text) -> bool:
    """A list or tuple display with mock's ANY as an entry: `x in [ANY]` holds for every x.

    Not a set display: ANY cannot be hashed, so `{ANY}` raises.
    """
    return isinstance(node, (ast.List, ast.Tuple)) and any(_is_mock_any(e, text) for e in node.elts)


def _operand_approx_call(node: ast.AST) -> ast.Call | None:
    """The approx call an operand is, or holds through container displays."""
    if _is_approx_call(node):
        return node  # type: ignore[return-value]
    if isinstance(node, (ast.List, ast.Tuple, ast.Set)):
        children = list(node.elts)
    elif isinstance(node, ast.Dict):
        children = list(node.values)
    elif isinstance(node, ast.Starred):
        children = [node.value]
    else:
        return None
    for child in children:
        found = _operand_approx_call(child)
        if found is not None:
            return found
    return None


# The operators `pytest.approx` answers: equality, and membership, which tests
# equality item by item.
_APPROX_OPS = (ast.Eq, ast.NotEq, ast.In, ast.NotIn)


def _comparison_approx_call(test: ast.AST) -> tuple[ast.cmpop, ast.Call] | None:
    """The `==`, `!=`, `in` or `not in` that compares with an approx call, and the call.

    The call is one of its operands, or sits inside one through container
    displays (`[total()] == approx([78.75])`, `{"t": approx(78.75)} == d`). A
    chained comparison holds each of its links, so a link that is such a
    comparison is stated too (`0 < total() == approx(78.75)`): the first one.
    """
    if not isinstance(test, ast.Compare):
        return None
    operands = (test.left, *test.comparators)
    for i, op in enumerate(test.ops):
        if not isinstance(op, _APPROX_OPS):
            continue
        for operand in operands[i:i + 2]:
            found = _operand_approx_call(operand)
            if found is not None:
                return op, found
    return None


def _asserted_approx_comparison(test: ast.AST) -> tuple[ast.cmpop, ast.Call] | None:
    """The approximate comparison an assertion states: its operator and its approx call (#299).

    The assertion's own comparison, or a link of it; or, since each part must
    hold, a comparison it conjoins with `and`, or one `all(...)` asserts for
    every item of a comprehension. Anywhere else (a disjunction, `any(...)`, a
    call's arguments, a comparison of a comparison's result) the assertion is
    not that comparison: `x == approx(y) or True` was read as it, so the
    disjunction that makes it hold everywhere was no change at all. Such a
    test is read as the plain path reads it.
    """
    found = _comparison_approx_call(test)
    if found is not None:
        return found
    if isinstance(test, ast.BoolOp) and isinstance(test.op, ast.And):
        for value in test.values:
            found = _asserted_approx_comparison(value)
            if found is not None:
                return found
        return None
    if (isinstance(test, ast.Call) and _dotted(test.func) == "all" and len(test.args) == 1
            and not test.keywords and isinstance(test.args[0], (ast.GeneratorExp, ast.ListComp))):
        return _asserted_approx_comparison(test.args[0].elt)
    return None


def _approx_expected(call: ast.Call) -> ast.AST | None:
    """The expected value of an approx call: its first argument, else `expected=` (#462).

    `pytest.approx(expected, rel=None, abs=None, nan_ok=False)` takes it by
    name as well. A call with a positional argument keeps the reading it
    always had, so a starred one (`approx(*values)`) still records no value.
    """
    if call.args:
        return call.args[0]
    return next((kw.value for kw in call.keywords if kw.arg == "expected"), None)


def _approx_epsilon(call: ast.Call, text: str) -> tuple[str | None, str | None]:
    """All tolerances on the call, joined — not just the first.

    `approx(x, rel=1e-9, abs=1e-9)` -> `approx(x, rel=1e-9, abs=1.0)` widened
    the absolute tolerance by nine orders of magnitude and was invisible,
    because only the first keyword found was recorded (confirmed bypass).
    Each kind is compared independently by the detector.
    """
    parts: list[tuple[str, str]] = []
    for kw in call.keywords:
        if kw.arg in ("rel", "abs"):
            seg = text.seg(kw.value)
            if seg:
                parts.append((kw.arg, seg))
    # pytest.approx(expected, rel) — a positional tolerance was invisible, so
    # widening one by a million produced no finding at all.
    if not parts and len(call.args) > 1:
        seg = text.seg(call.args[1])
        if seg:
            parts.append(("rel", seg))
    if not parts:
        # `approx(42)` still carries pytest's implicit default (rel=1e-06,
        # abs=1e-12). Recording it makes a tolerance that APPEARS in the head
        # a widening of that default instead of silence — the comment here
        # claimed as much for two releases while the code returned None
        # (audit 2026-08-19). One default kind suffices: it turns every
        # one-sided tolerance event two-sided, and tightening to the default
        # reads equal and stays quiet. Keyed form, like every other single
        # tolerance, so the detector's per-kind parse sees the same key.
        return "rel=1e-06", "rel"
    parts.sort()
    return "|".join(f"{k}={v}" for k, v in parts), "multi" if len(parts) > 1 else parts[0][0]


def _canonical_repr(value: object) -> str:
    """repr() with set iteration order removed.

    `repr({"a", "b"})` depends on hash randomisation, so a set literal in an
    expectation produced a different string on every run — leaking into
    finding messages and the IR, and breaking the byte-identical guarantee
    (SPEC §8). Sets are emitted in sorted-by-canonical-repr order instead;
    containers are rebuilt recursively so nested sets are covered too.
    """
    if isinstance(value, (set, frozenset)):
        inner = sorted(_canonical_repr(v) for v in value)
        prefix = "frozenset(" if isinstance(value, frozenset) else ""
        if not inner:
            return "frozenset()" if prefix else "set()"
        body = "{" + ", ".join(inner) + "}"
        return f"frozenset({body})" if prefix else body
    if isinstance(value, tuple):
        if len(value) == 1:
            return f"({_canonical_repr(value[0])},)"
        return "(" + ", ".join(_canonical_repr(v) for v in value) + ")"
    if isinstance(value, list):
        return "[" + ", ".join(_canonical_repr(v) for v in value) + "]"
    if isinstance(value, dict):
        # dicts preserve insertion order in the source, which is stable.
        return "{" + ", ".join(
            f"{_canonical_repr(k)}: {_canonical_repr(v)}" for k, v in value.items()
        ) + "}"
    return repr(value)


def _literal_value(node: ast.AST, *, fold_string_methods=True, conversions=None) -> str | None:
    """Canonical repr of a literal's VALUE (quote-style independent), else None.

    `conversions` names the spellings that fold in this file (#226):
    `float('75')` is the literal 75.0, `Decimal('75')` the Decimal it makes.
    """
    folded = literal_string_replace(node) if fold_string_methods else None
    if folded is not None:
        return _canonical_repr(folded.value)
    converted = _folded_conversion(node, conversions)
    if converted is not None:
        return _canonical_repr(converted)
    try:
        return _canonical_repr(ast.literal_eval(node))
    except (ValueError, SyntaxError, TypeError, MemoryError, RecursionError):
        return None


@dataclass
class _Classified:
    form: str
    strength: int | None
    left: str | None = None
    right_literal: str | None = None
    right_value: str | None = None
    epsilon: str | None = None
    epsilon_kind: str | None = None
    positive: bool = True
    # Raw name references on each side, before local bindings are followed.
    # _collect_unit resolves right_names into Assertion.right_depends_on.
    left_names: tuple[str, ...] = ()
    right_names: tuple[str, ...] = ()
    # Whether the classified assertion depends on nothing but literals and
    # builtin calls — the vacuousness test that keeps padding out of D4/D5
    # compensation. Computed here so every construction site can pass it
    # through without re-deriving nodes it no longer holds.
    trivial: bool = False
    # The bound key a comparison states (`ir/predicate.py`: lt, le, gt, ge)
    # and its bound as one line (#224), as the JavaScript frontend records
    # them (#198).
    predicate: str | None = None
    operand_source: str | None = None
    # The expected call checkwash neither folds nor resolves (#226).
    unevaluated_expected: str | None = None
    # A unittest assertion whose operands come through `*` or `**` and so
    # cannot be bound (#462 Q2): it records no operand, and is not trivial.
    unbound_operands: bool = False


# A comparison's bound key, and the key it states read from the other side:
# `80 > total()` is `total() < 80` (#224).
_BOUND_KEYS = {ast.Lt: "lt", ast.LtE: "le", ast.Gt: "gt", ast.GtE: "ge"}
_REVERSED_KEYS = {"lt": "gt", "le": "ge", "gt": "lt", "ge": "le"}


def _operand_source(node: ast.AST | None, text) -> str | None:
    """An operand's source as one line, as `operand_source` records it (#224)."""
    seg = text.seg(node) if node is not None else None
    return " ".join(seg.split()) if seg else None


# The polarity of the None family follows the bare lattice: `is None` is the
# positive form there (op `Is` → positive), so assertIsNone must be too.
# assertIsNone used to sit in this set while bare `is None` was positive, so a
# spelling conversion between the two dialects read as a polarity inversion
# ("the test now proves the opposite") and a genuine cross-dialect inversion
# did not fire at all (audit 2026-08-19).
_NEGATED_UNITTEST = frozenset(
    {
        "assertNotEqual", "assertFalse", "assertIsNotNone", "assertNotIn",
        "assertNotRegex", "assertNotIsInstance", "assertNotAlmostEqual",
        "assertIsNot",
    }
)

_BUILTIN_CALLS = frozenset(
    {
        "str", "int", "float", "bool", "len", "repr", "sorted", "list", "dict",
        "set", "tuple", "abs", "round", "min", "max", "sum", "any", "all",
        "reversed", "type", "format",
    }
)


def _is_trivial_subject(node: ast.AST | None) -> bool:
    """Does this expression depend on nothing but literals and builtin calls?

    `assert str(1) == "1"` sits at EXACT_VALUE(90) and can never fail, so it
    was usable as padding to fake compensation for a deleted oracle.

    A **bare** name is state, not a builtin, even when it is spelled like one:
    `sum == 42` (a local named `sum`) is a real, fallible assertion. Only a
    builtin used as a call — `sum(xs) == 42` — is trivial (confirmed
    red-team false positive). Recursion, not ast.walk, so a call's function
    Name is judged in call context, not as a bare reference.
    """
    if node is None:
        return True
    if isinstance(node, ast.Constant):
        return True
    if isinstance(node, (ast.List, ast.Tuple, ast.Set)):
        return all(_is_trivial_subject(e) for e in node.elts)
    if isinstance(node, ast.Dict):
        return all(k is not None and _is_trivial_subject(k) for k in node.keys) and all(
            _is_trivial_subject(v) for v in node.values
        )
    if isinstance(node, ast.BinOp):
        return _is_trivial_subject(node.left) and _is_trivial_subject(node.right)
    if isinstance(node, ast.UnaryOp):
        return _is_trivial_subject(node.operand)
    if isinstance(node, ast.BoolOp):
        return all(_is_trivial_subject(v) for v in node.values)
    if isinstance(node, ast.Compare):
        return _is_trivial_subject(node.left) and all(
            _is_trivial_subject(c) for c in node.comparators
        )
    if isinstance(node, ast.Call):
        name = _dotted(node.func)
        if name is None or name.rsplit(".", 1)[-1] not in _BUILTIN_CALLS:
            return False  # a non-builtin call can fail
        return all(_is_trivial_subject(a) for a in node.args) and all(
            _is_trivial_subject(k.value) for k in node.keywords
        )
    # Bare Name, Attribute, Subscript, comprehension, … = depends on state.
    return False


def _classify_assert(node: ast.Assert, text: str) -> _Classified:
    return _classify_assert_expr(node.test, text)


def _binds_abs(node: ast.AST) -> bool:
    """Does this node bind the name `abs`: a def, class, import, parameter or target?"""
    if isinstance(node, ast.Name):
        return node.id == "abs" and not isinstance(node.ctx, ast.Load)
    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
        return node.name == "abs"
    if isinstance(node, ast.alias):
        return (node.asname or node.name.split(".")[0]) == "abs"
    if isinstance(node, ast.arg):
        return node.arg == "abs"
    if isinstance(node, (ast.ExceptHandler, ast.MatchAs, ast.MatchStar)):
        return node.name == "abs"
    return False


def _shadows_abs(text) -> bool:
    """Does the module bind `abs` anywhere, so that `abs(...)` may not be the builtin?

    Module-wide on purpose, like the JS frontend's unshadowed-`Math` check:
    a file that defines, imports or assigns its own `abs` gets no
    hand-rolled reading at all (#196 189.2). Without a parsed module (an
    oracle helper's own offsets) the builtin is assumed.
    """
    if text.abs_shadowed is None:
        text.abs_shadowed = text.tree is not None and any(_binds_abs(node) for node in ast.walk(text.tree))
    return text.abs_shadowed


def _tolerance_names(text) -> dict[str, str | None]:
    """The names the file binds to math, numpy or torch (#222), worked out once per file.

    Without a parsed module (an oracle helper's own offsets) only the plain
    spellings (`math.isclose`, `numpy.isclose`) are read. A module whose
    source cannot spell a tolerance call, as most test modules cannot, is not
    walked: the walk was most of what #222 added to the perf gate's 500 files.
    """
    if getattr(text, "tolerance_names", None) is None:
        source = getattr(text, "text", None)
        if isinstance(source, str) and not _tolerance_may_resolve(source):
            names: dict[str, str | None] = {}
        else:
            names = _tolerance_import_names(getattr(text, "tree", None))
        try:
            text.tolerance_names = names
        except AttributeError:
            return names
    return text.tolerance_names


def _bindings(text):
    """The names the file binds anywhere, and whether a star import binds more (#226), once per file.

    None without a parsed module (an oracle helper's own offsets): no name is
    then known to be unbound, and nothing folds.
    """
    if getattr(text, "module_bindings", None) is None:
        tree = getattr(text, "tree", None)
        if tree is None:
            return None
        bindings = _module_bindings_of(tree)
        try:
            text.module_bindings = bindings
        except AttributeError:
            return bindings
    return text.module_bindings


def _conversions(text) -> dict[str, str]:
    """The spellings that fold as conversions in this file (#226), worked out once per file.

    A module whose source spells neither `float` nor `Decimal` folds none
    and is not walked for them.
    """
    if getattr(text, "conversion_names", None) is None:
        source = getattr(text, "text", None)
        spelled = not isinstance(source, str) or "float" in source or "Decimal" in source
        bindings = _bindings(text) if spelled else None
        names = _conversion_names_of(text.tree, bindings) if bindings is not None else {}
        try:
            text.conversion_names = names
        except AttributeError:
            return names
    return text.conversion_names


# The forms whose second operand is an expected value or a bound.
_EXPECTED_FORMS = frozenset({"compare_eq", "compare_ord", "approx", "membership"})


def _unevaluated(node: ast.AST | None, text) -> str | None:
    """The expected value's source when it is a call checkwash neither folds nor resolves (#226).

    Its callee's root is a name the file never binds: a builtin outside the
    fold set (`int('75')`, `round(75.0, 2)`) or a name bound nowhere
    (226.Q1). A call whose callee the file binds is the provenance channel's.
    """
    if not isinstance(node, ast.Call):
        return None
    bindings = _bindings(text)
    if (bindings is None or not _unbound_callee(node, bindings)
            or _folded_conversion(node, _conversions(text)) is not None):
        return None
    try:
        source = ast.unparse(node)
    except (ValueError, RecursionError):
        return None
    return source if len(source) <= 4096 else None


def _any_shape(node: ast.AST | None) -> str | None:
    """An all-ANY display's source, as the expectation it states: its length or its keys (D-201)."""
    if node is None:
        return None
    try:
        source = ast.unparse(node)
    except (ValueError, RecursionError):
        return None
    return source if len(source) <= 4096 else None


def _tolerance_classified(call: ast.Call, name: str, text, positive: bool = True) -> _Classified:
    """A tolerance call (#222) as the approximate comparison it states.

    Its tolerances and their defaults are recorded as `pytest.approx` records
    its own, and the value it compares against is the expected value (222.Q1):
    the literal one when only one of the two is a literal, as in
    `assertEqual`, else the second. A negated call passes when the values are
    far apart, so its tolerance orders the other way and is not recorded, as
    in JavaScript.
    """
    subject, expected = _tolerance_values(call, name)
    if subject is not None and expected is not None and _is_literal(subject) and not _is_literal(expected):
        subject, expected = expected, subject
    epsilon, kind = _call_tolerance(call, name, text.seg) if positive else (None, None)
    return _Classified(
        "approx",
        S.APPROX,
        text.seg(subject) if subject is not None else None,
        _literal_repr(expected, text, conversions=_conversions(text)) if expected is not None else None,
        _literal_value(expected, conversions=_conversions(text)) if expected is not None else None,
        epsilon,
        kind,
        positive,
        _referenced_names(subject),
        _referenced_names(expected),
        subject is not None and _is_trivial_subject(subject)
        and (expected is None or _is_trivial_subject(expected)),
        unevaluated_expected=_unevaluated(expected, text),
    )


def _finite_number(node: ast.AST | None) -> bool:
    """A finite int or float literal, signed or not: `78.75`, `-1.5`, `75`."""
    if node is None or not _is_literal(node):
        return False
    try:
        value = ast.literal_eval(node)
    except (ValueError, TypeError, SyntaxError, MemoryError, RecursionError):
        return False
    return type(value) in (int, float) and math.isfinite(value)


def _is_abs_call(node: ast.AST) -> bool:
    return (isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "abs"
            and len(node.args) == 1 and not node.keywords and not isinstance(node.args[0], ast.Starred))


def _hand_rolled(smaller: ast.AST, larger: ast.AST, strict: bool, text, form: str,
                 strength: int | None) -> _Classified | None:
    """`abs(total() - 78.75) < 0.01`, read as the bound it states (#196 189.2, #224).

    The caller passes the comparison as `smaller < larger` (`strict`) or
    `smaller <= larger`. With the builtin `abs` on the smaller side it is an
    upper bound: it checks `total()` against 78.75 within 0.01, as
    `pytest.approx(78.75, abs=0.01)` does, and the JS frontend reads
    `Math.abs` the same way. What the builtin `abs` measures is `left`, a
    numeric literal centre on either side of its one subtraction is the
    expected value, and the bound is an `abs=` tolerance, recorded as written
    like an approx tolerance. With no literal centre (`abs(total() -
    expected)`, `abs(d)`) or two, the whole argument is `left` and there is
    no expected value. With `abs` on the larger side (`abs(d) > eps`) it
    asserts that two values differ: a lower bound, read for its direction so
    a `<` -> `>` flip is reported, which records no tolerance, as in
    JavaScript (#224). Either way the bound key (lt, le, gt, ge) is
    recorded, with the bound as the operand, so both directions of one
    check share a subject.
    """
    if _is_abs_call(smaller):
        magnitude, bound, key = smaller, larger, "lt" if strict else "le"
    elif _is_abs_call(larger):
        magnitude, bound, key = larger, smaller, "gt" if strict else "ge"
    else:
        return None
    if _shadows_abs(text):
        return None
    measured = magnitude.args[0]
    subject, centre = measured, None
    if isinstance(measured, ast.BinOp) and isinstance(measured.op, ast.Sub):
        first, second = measured.left, measured.right
        if _finite_number(first) != _finite_number(second):
            centre, subject = (first, second) if _finite_number(first) else (second, first)
    tolerance = text.seg(bound) if key in ("lt", "le") else None
    return _Classified(
        form,
        strength,
        text.seg(subject),
        _literal_repr(centre, text) if centre is not None else None,
        _literal_value(centre) if centre is not None else None,
        f"abs={tolerance}" if tolerance else None,
        "abs" if tolerance else None,
        True,
        _referenced_names(subject),
        _referenced_names(centre),
        _is_trivial_subject(magnitude) and _is_trivial_subject(bound),
        key,
        _operand_source(bound, text),
    )


def _hand_rolled_comparison(test: ast.AST, text, form: str, strength: int | None) -> _Classified | None:
    """A single comparison bounding a builtin `abs(...)`, above or below, either way round."""
    if not isinstance(test, ast.Compare) or len(test.ops) != 1:
        return None
    op, left, right = test.ops[0], test.left, test.comparators[0]
    if isinstance(op, (ast.Lt, ast.LtE)):
        return _hand_rolled(left, right, isinstance(op, ast.Lt), text, form, strength)
    if isinstance(op, (ast.Gt, ast.GtE)):
        return _hand_rolled(right, left, isinstance(op, ast.Gt), text, form, strength)
    return None


def _is_unfalsifiable(test: ast.AST, text) -> bool:
    """Assertions that are structurally incapable of failing.

    `_is_trivial_subject` asks "does this depend on anything but literals?",
    which `assert "" in str(x)` passes — it mentions `x` — while still being
    true for every possible `x`. That made it valid compensation, and eight
    deleted exact assertions could be laundered through D5 with one line of
    padding (reader audit 2026-08-02). These are the shapes seen in the wild;
    the list is a floor, not a claim of completeness.
    """
    if not isinstance(test, ast.Compare) or len(test.ops) != 1:
        return False
    op = test.ops[0]
    left, right = test.left, test.comparators[0]
    # `"" in <str>` / `b"" in <bytes>` / `() in ...` — the empty needle is in
    # every haystack of the same kind.
    if isinstance(op, ast.In) and isinstance(left, ast.Constant) and left.value in ("", b""):
        return True
    # `len(x) >= 0`, `len(x) > -1`: a length is never negative. The bound is
    # literal-evaluated, not isinstance-checked — `-1` is a UnaryOp, not a
    # Constant, and matching only Constant missed exactly that spelling.
    if isinstance(left, ast.Call) and _dotted(left.func) == "len" and _is_literal(right):
        try:
            bound = ast.literal_eval(right)
        except (ValueError, SyntaxError, TypeError):
            bound = None
        if isinstance(bound, int) and not isinstance(bound, bool):
            if isinstance(op, ast.GtE) and bound <= 0:
                return True
            if isinstance(op, ast.Gt) and bound < 0:
                return True
    # `x in x`, `x <= x`, `x >= x` — same expression both sides.
    if isinstance(op, (ast.In, ast.LtE, ast.GtE)):
        if _norm(_strip_identity(left, text)) == _norm(_strip_identity(right, text)):
            return True
    return False


def _classify_assert_expr(test: ast.AST, text) -> _Classified:
    # `assert (cond, "message")` asserts a non-empty tuple display, which is
    # always truthy — CPython itself warns about it. It was rated TRUTHY(20),
    # so neutering a real truthy assertion this way produced no finding at all
    # (reader audit 2026-08-02).
    if isinstance(test, ast.Tuple) and test.elts:
        return _Classified("tautology", S.TAUTOLOGY)
    if _is_unfalsifiable(test, text):
        return _Classified("tautology", S.TAUTOLOGY)
    # `assert not x == approx(y)` is read by the `not` branch below, which
    # negates what its operand states (#284).
    stated = _asserted_approx_comparison(test)
    if stated is not None:
        op, approx = stated
        # The comparison the call sits in states the polarity, as for a plain
        # comparison: `x != approx(y)` asserts that the values differ. It read
        # as positive, so `==` -> `!=` was no change at all (#284). A negated
        # approximate comparison passes when the values are far apart, so its
        # tolerance orders the other way and is not recorded, as in JavaScript.
        positive = not isinstance(op, (ast.NotEq, ast.NotIn))
        eps, kind = _approx_epsilon(approx, text) if positive else (None, None)
        # The argument of the approx call is the expected value; recording it
        # puts `approx(105.0)` -> `approx(100.0)` in front of
        # EXPECTED_VALUE_CHANGED. Strength is APPROX on both sides, so the
        # rewrite was completely invisible before (audit 2026-08-19). It is
        # read by name too: `approx(expected=100.0)` recorded no expected
        # value, so a rewrite into it passed and its cleanup back into
        # `approx(100.0)` read as a call replaced by a literal (#462).
        expected = _approx_expected(approx)
        # `approx(ANY)` compares as ANY does: pytest hands a value it cannot
        # treat as a number to `==` (D-201).
        if positive and isinstance(op, ast.Eq) and _is_mock_any(expected, text):
            return _Classified("tautology", S.TAUTOLOGY)
        if positive and isinstance(op, ast.Eq) and _only_any(expected, text):
            return _Classified("type_shape", S.TYPE_SHAPE)
        return _Classified(
            "approx",
            S.APPROX,
            right_literal=(_literal_repr(expected, text, conversions=_conversions(text))
                           if expected is not None else None),
            right_value=_literal_value(expected, conversions=_conversions(text)) if expected is not None else None,
            epsilon=eps,
            epsilon_kind=kind,
            positive=positive,
            unevaluated_expected=_unevaluated(expected, text),
        )
    hand = _hand_rolled_comparison(test, text, "compare_ord", S.BOUND)
    if hand is not None:
        return hand
    if isinstance(test, ast.Compare) and test.ops:
        left = test.left
        comparators = test.comparators
        all_literal = _is_literal(left) and all(_is_literal(c) for c in comparators)
        if all_literal:
            return _Classified("tautology", S.TAUTOLOGY)
        # A chain of `==` each link of which has `ANY` on one side holds for
        # every value: `total() == ANY == 6` (D-201).
        chain = [left, *comparators]
        if len(test.ops) > 1 and all(isinstance(o, ast.Eq) for o in test.ops) and all(
                _is_mock_any(chain[i], text) or _is_mock_any(chain[i + 1], text) for i in range(len(test.ops))):
            return _Classified("tautology", S.TAUTOLOGY)
        op = test.ops[0]
        # Chained comparisons (`0 < x < 10`): the last comparator carries the
        # upper expectation, so consider every comparator, not just the first.
        expect_node = comparators[-1] if comparators else None
        # `assert 3 == calc()` puts the expectation on the LEFT. Taking the
        # right side unconditionally made changing it invisible (confirmed
        # bypass); prefer whichever side is the literal.
        subject_node = left
        single = len(test.ops) == 1
        # ANY on the left is the expectation, as a literal is (D-201).
        if (comparators and (_is_literal(left) or single and _any_like(left, text)
                             or single and literal_string_replace(left) is not None)
                and not (_is_literal(comparators[-1]) or single and _any_like(comparators[-1], text))
                and (not single or literal_string_replace(comparators[-1]) is None)):
            expect_node, subject_node = left, comparators[-1]
        # A chained comparison is a range oracle: the non-literal operand is
        # the subject (usually the middle term) and every literal bound is
        # part of the expectation. The middle term used to be recorded
        # nowhere — subject_node stayed the LEFT bound, so rewriting that
        # bound (`0` -> `-1000000`) moved only the subject text and no rule
        # saw the oracle move (audit 2026-08-19).
        bounds: list[ast.AST] | None = None
        if len(test.ops) > 1:
            operands = [left, *comparators]
            non_literals = [n for n in operands if not _is_literal(n)]
            if len(non_literals) == 1:
                subject_node = non_literals[0]
                bounds = [n for n in operands if _is_literal(n)]
                expect_node = bounds[-1] if bounds else None
        left_text = text.seg(subject_node)
        conversions = _conversions(text) if single else None
        right_lit = (_literal_repr(expect_node, text, fold_string_methods=single, conversions=conversions)
                     if expect_node is not None else None)
        right_val = (_literal_value(expect_node, fold_string_methods=single, conversions=conversions)
                     if expect_node is not None else None)
        if bounds is not None and len(bounds) > 1:
            # The whole bound tuple is the expectation, so moving any single
            # bound is an expectation rewrite.
            right_lit = ", ".join(filter(None, (text.seg(b) for b in bounds)))
            try:
                right_val = _canonical_repr(tuple(ast.literal_eval(b) for b in bounds))
            except (ValueError, SyntaxError, TypeError, MemoryError, RecursionError):
                right_val = None
        pos = not isinstance(op, (ast.NotEq, ast.IsNot, ast.NotIn))
        c = _classify_compare_op(
            op, left, comparators, text, left_text, right_lit, right_val, pos, subject_node
        )
        if single and c.form == "compare_ord" and type(op) in _BOUND_KEYS:
            # The bound key, read from the subject's side: the flip above
            # makes `80 > total()` the `total() < 80` it states (#224).
            key = _BOUND_KEYS[type(op)]
            c.predicate = key if subject_node is left else _REVERSED_KEYS[key]
            c.operand_source = _operand_source(expect_node, text)
        if single and c.form in _EXPECTED_FORMS:
            c.unevaluated_expected = _unevaluated(expect_node, text)
        elif single and c.form == "type_shape" and _only_any(expect_node, text):
            # `[ANY, ANY, ANY]` -> `[ANY]` changes the length it checks
            # (D-201); main read the display as an expectation and saw that.
            c.unevaluated_expected = _any_shape(expect_node)
        # Which side is the subject and which the expectation was decided
        # above, including the `assert 3 == calc()` flip, so the name sets come
        # from those nodes rather than being re-derived. EXPECTED_VALUE_DERIVED
        # needs them to tell a renamed constant from a recomputed expectation.
        c.left_names = _referenced_names(subject_node)
        c.right_names = _referenced_names(expect_node)
        return c
    if (isinstance(test, ast.UnaryOp) and isinstance(test.op, ast.Not) and isinstance(test.operand, ast.Compare)
            and len(test.operand.ops) == 1 and isinstance(test.operand.ops[0], ast.NotEq)):
        # `assert not (x != ANY)` is `assert x == ANY` (D-201).
        pair = (test.operand.left, test.operand.comparators[0])
        if any(_is_mock_any(n, text) for n in pair):
            return _Classified("tautology", S.TAUTOLOGY)
        if any(_only_any(n, text) for n in pair):
            return _Classified("type_shape", S.TYPE_SHAPE)
    if isinstance(test, ast.UnaryOp) and isinstance(test.op, ast.Not):
        # `assert not x` is the negated form of `assert x`. A negated tolerance
        # call (#222) passes when the values are far apart, so its tolerance
        # orders the other way and is not recorded, as in JavaScript.
        inner = _classify_assert_expr(test.operand, text)
        approximate = inner.form == "approx"
        return _Classified(
            inner.form, inner.strength, inner.left, inner.right_literal,
            inner.right_value, None if approximate else inner.epsilon,
            None if approximate else inner.epsilon_kind, not inner.positive,
            inner.left_names, inner.right_names,
            predicate=inner.predicate, operand_source=inner.operand_source,
            unevaluated_expected=inner.unevaluated_expected,
        )
    if isinstance(test, ast.Call):
        name = _dotted(test.func)
        if name == "isinstance":
            # `isinstance(x, object)` is true for every object.
            if len(test.args) == 2 and _dotted(test.args[1]) == "object":
                return _Classified("tautology", S.TAUTOLOGY)
            return _Classified("type_shape", S.TYPE_SHAPE)
        # `math.isclose(...)`, `numpy.isclose(...).all()`, `numpy.allclose(...)`
        # state a tolerance (#222).
        found = _find_tolerance_predicate(test, _tolerance_names(text))
        if found is not None:
            return _tolerance_classified(*found, text)
        return _Classified("truthy", S.TRUTHY)
    if _is_literal(test):
        return _Classified("tautology", S.TAUTOLOGY)
    return _Classified("truthy", S.TRUTHY)


def _assignment_name_targets(target: ast.AST) -> list[str]:
    """Local names an assignment target binds.

    Bare names and tuple/list unpacks. Subscript and attribute targets are
    not locals; starred leftovers are skipped. E4 / THREATMODEL 86g: the
    spellings that hide a recomputed expectation, not every bindable node.
    """
    if isinstance(target, ast.Name):
        return [target.id]
    if isinstance(target, (ast.Tuple, ast.List)):
        names: list[str] = []
        for elt in target.elts:
            names.extend(_assignment_name_targets(elt))
        return names
    return []


def _binding_maps(
    func,
    *,
    include_definitions: bool = True,
    unparse_memo: dict[int, str] | None = None,
    refs_memo: dict[int, tuple[str, ...]] | None = None,
    flags: dict[str, bool] | None = None,
) -> tuple[dict[str, str], dict[str, tuple[str, ...]]]:
    """Collect definition keys and referenced names in one AST walk.

    The two maps used to be built by `_binding_definitions` and
    `_local_bindings`, each with separate assignment and walrus walks. That
    meant four complete traversals of every test unit before exclusivity was
    considered. The 500-file perf gate exercises thousands of small units, so
    the repeated traversal was measurable there. One pass can produce both
    maps without changing either contract.

    Definition keys use canonical source (`ast.unparse`) rather than raw text,
    so reformatting an expression is not a change — the first false positive
    this would otherwise invent. A name bound more than once takes the joined
    keys of every right-hand side because checkwash cannot tell which one
    reaches the assertion without evaluating. Assignment keys remain ahead of
    walrus keys, matching the former two-pass ordering.

    **Not `ast.dump`.** The first version used it and broke the byte-identical
    guarantee: `ast.dump` renders the AST's internal field set, which changes
    between Python releases, so 3.13 produced different IR from 3.11 and 3.12
    for identical input. The nine-way byte-compare job caught it on the release
    commit — the split was by interpreter version, not by OS, which is the
    signature. `ast.unparse` emits code, not node internals.

    This cannot be verified on a single interpreter: only the matrix can see a
    cross-version divergence, which is precisely why that job exists.
    """
    definitions: dict[str, list[str]] = {}
    walrus_definitions: dict[str, list[str]] = {}
    assignment_references: dict[str, set[str]] = {}
    walrus_references: dict[str, set[str]] = {}

    # `_ordered_bindings` visits the same value nodes for its position-keyed
    # map; unparse and reference extraction are the expensive parts of both
    # walks, so a caller working per unit shares the results through the two
    # memos (the perf gate's 500-file budget is what noticed — 3.08s over
    # 2.5s on the slowest CI leg when every value was unparsed twice).
    def _key(value: ast.AST) -> str:
        if unparse_memo is not None:
            hit = unparse_memo.get(id(value))
            if hit is not None:
                return hit
        try:
            if isinstance(value, ast.BinOp):
                key = _binding_key(value)
            else:
                key = ast.unparse(value)
        except (AttributeError, ValueError):  # pragma: no cover - defensive
            key = ""
        if unparse_memo is not None:
            unparse_memo[id(value)] = key
        return key

    def _refs(value: ast.AST) -> tuple[str, ...]:
        if refs_memo is not None:
            hit = refs_memo.get(id(value))
            if hit is not None:
                return hit
        refs = _referenced_names(value)
        if refs_memo is not None:
            refs_memo[id(value)] = refs
        return refs

    for node in _walk(func):
        if isinstance(node, ast.Assign):
            targets, value = node.targets, node.value
        elif isinstance(node, (ast.AnnAssign, ast.AugAssign)):
            targets, value = [node.target], node.value
        elif isinstance(node, ast.NamedExpr) and isinstance(node.target, ast.Name):
            if flags is not None:
                flags["walrus"] = True
            if include_definitions:
                walrus_definitions.setdefault(node.target.id, []).append(
                    _key(node.value)
                )
            walrus_references.setdefault(node.target.id, set()).update(
                _refs(node.value)
            )
            continue
        else:
            continue
        if value is None:
            continue
        if include_definitions:
            key = _key(value)
        refs = set(_refs(value))
        for target in targets:
            for name in _assignment_name_targets(target):
                if include_definitions:
                    definitions.setdefault(name, []).append(key)
                assignment_references.setdefault(name, set()).update(refs)
    # Unit separator, not "|": a Python expression can contain a bitwise or,
    # and `resolve_through` has to be able to tell "one binding" from "several".
    definition_names = definitions.keys() | walrus_definitions.keys()
    definition_map = {
        name: "".join(definitions.get(name, []) + walrus_definitions.get(name, []))
        for name in sorted(definition_names)
    }
    # Preserve `_local_bindings`' former insertion order: every ordinary
    # assignment name in walk order, followed by walrus-only names. Map order
    # is not part of detector policy, but keeping it costs nothing and makes
    # this a strict refactor for focused frontend callers too.
    references = {name: set(refs) for name, refs in assignment_references.items()}
    for name, refs in walrus_references.items():
        references.setdefault(name, set()).update(refs)
    reference_map = {name: tuple(sorted(refs)) for name, refs in references.items()}
    return definition_map, reference_map


def _binding_definitions(func) -> dict[str, str]:
    """Definition half of `_binding_maps` for focused frontend callers."""
    return _binding_maps(func)[0]


def _local_bindings(func) -> dict[str, tuple[str, ...]]:
    """Reference half of `_binding_maps` for focused frontend callers."""
    return _binding_maps(func, include_definitions=False)[1]


_TRY_TYPES = tuple(
    t for t in (getattr(ast, "Try", None), getattr(ast, "TryStar", None)) if t is not None
)


def _ordered_bindings(
    func,
    *,
    unparse_memo: dict[int, str] | None = None,
    refs_memo: dict[int, tuple[str, ...]] | None = None,
    has_walrus: bool = True,
) -> dict[str, list[tuple[tuple[int, int], bool, str, tuple[str, ...]]]]:
    """name -> [(statement position, conditional?, canonical key)] in source
    order, for the per-assertion reaching-definition computation.

    `_binding_maps` deliberately joins every definition of a name because it
    serves unit-level consumers; the reaching computation needs the same keys
    with position and branch information kept. A binding inside an `if`/loop/
    `try`/`match` arm may or may not execute, so it is conditional; a `with`
    body and a `finally` always run. Bindings inside nested defs and lambdas
    are skipped — they do not execute at the unit's own statement positions —
    and a name bound only there stays absent, which consumers treat as
    "fall back to the unit-level map". Walruses are scanned on simple
    statements and recorded as conditional (short-circuit operands may not
    evaluate); one inside a compound statement's header is a documented miss
    with the same fallback.
    """
    out: dict[str, list[tuple[tuple[int, int], bool, str, tuple[str, ...]]]] = {}

    def record(name: str, pos: tuple[int, int], conditional: bool, value: ast.AST) -> None:
        key = None
        if unparse_memo is not None:
            key = unparse_memo.get(id(value))
        if key is None:
            try:
                if isinstance(value, ast.BinOp):
                    key = _binding_key(value)
                else:
                    key = ast.unparse(value)
            except (AttributeError, ValueError):  # pragma: no cover - defensive
                key = ""
            if unparse_memo is not None:
                unparse_memo[id(value)] = key
        refs = None
        if refs_memo is not None:
            refs = refs_memo.get(id(value))
        if refs is None:
            refs = _referenced_names(value)
            if refs_memo is not None:
                refs_memo[id(value)] = refs
        out.setdefault(name, []).append((pos, conditional, key, refs))

    # Walruses are rare, and `_binding_maps` has already walked the whole
    # unit: callers pass its verdict in so walrus-free code skips every
    # per-statement scan without a pre-scan of its own (the perf gate's
    # 500-file budget felt both spellings).

    def walk(stmts: list[ast.stmt], conditional: bool) -> None:
        for st in stmts:
            pos = (st.lineno, st.col_offset)
            if isinstance(st, ast.Assign):
                for target in st.targets:
                    for name in _assignment_name_targets(target):
                        record(name, pos, conditional, st.value)
            elif isinstance(st, (ast.AnnAssign, ast.AugAssign)) and st.value is not None:
                for name in _assignment_name_targets(st.target):
                    record(name, pos, conditional, st.value)
            if isinstance(st, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                continue
            if isinstance(st, (ast.If, ast.While)):
                walk(st.body, True)
                walk(st.orelse, True)
            elif isinstance(st, (ast.For, ast.AsyncFor)):
                walk(st.body, True)
                walk(st.orelse, True)
            elif isinstance(st, _TRY_TYPES):
                walk(st.body, True)
                for handler in st.handlers:
                    walk(handler.body, True)
                walk(st.orelse, True)
                walk(st.finalbody, conditional)
            elif isinstance(st, (ast.With, ast.AsyncWith)):
                walk(st.body, conditional)
            elif isinstance(st, ast.Match):
                for case in st.cases:
                    walk(case.body, True)
            elif has_walrus:
                for sub in ast.walk(st):
                    if isinstance(sub, ast.NamedExpr) and isinstance(sub.target, ast.Name):
                        record(sub.target.id, pos, True, sub.value)
    walk(func.body, False)
    for entries in out.values():
        entries.sort(key=lambda e: e[0])
    return out


def _reaching_entries(
    pos: tuple[int, int],
    name: str,
    ordered: dict[str, list[tuple[tuple[int, int], bool, str, tuple[str, ...]]]],
) -> list[tuple[tuple[int, int], bool, str, tuple[str, ...]]]:
    """The entries that can reach position `pos` for `name`: the last
    unconditional binding before it plus every conditional one after that."""
    entries = ordered.get(name)
    if not entries:
        return []
    prior = [e for e in entries if e[0] < pos]
    if not prior:
        return []
    last_uncond = None
    for i, e in enumerate(prior):
        if not e[1]:
            last_uncond = i
    if last_uncond is None:
        return prior
    return [prior[last_uncond]] + [e for e in prior[last_uncond + 1 :] if e[1]]


def _reaching_keys(
    node: ast.AST,
    names: set[str],
    ordered: dict[str, list[tuple[tuple[int, int], bool, str]]],
) -> dict[str, str]:
    """The reaching-definition key per consumed name at this assertion.

    The last unconditional binding before the assertion, joined with every
    conditional binding between it and the assertion — the per-assertion form
    of the "last unconditional binding is the one the assertion reads"
    semantics SPEC §5 already states. A name bound in the unit only after the
    assertion maps to "": equal on both sides of a tail append, different
    when a definition moves across the assertion.
    """
    pos = (node.lineno, node.col_offset)
    result: dict[str, str] = {}
    for name in sorted(names):
        if name not in ordered:
            continue
        reach = _reaching_entries(pos, name, ordered)
        result[name] = "\x1f".join(e[2] for e in reach)
    return result


def _positional_closure(
    node: ast.AST,
    seeds: tuple[str, ...],
    ordered: dict[str, list[tuple[tuple[int, int], bool, str, tuple[str, ...]]]],
) -> set[str]:
    """Names transitively read at this assertion's position.

    `_resolve_through` follows the unit-level joined map, so `F` drags in
    every name any definition of `F` ever references — and an assertion in
    one case was charged with names only other cases read, which is how a
    pure insertion kept firing after the direct keys were made positional
    (sympy ed75b73d, R1). This closure follows only the definitions that
    reach this position.
    """
    pos = (node.lineno, node.col_offset)
    seen: set[str] = set()
    queue = list(seeds)
    while queue:
        name = queue.pop()
        if name in seen:
            continue
        seen.add(name)
        for entry in _reaching_entries(pos, name, ordered):
            queue.extend(n for n in entry[3] if n not in seen)
    return seen


def _reaching_sig(reaching: dict[str, str], direct: set[str]) -> str:
    """Serialize the direct names' reaching entries for assertion pairing.

    Direct names only: `F` resolved transitively drags in names that other
    definitions of `F` reference, whose reaching keys legitimately differ
    across an insertion — a polluted signature pushes untouched twins back
    to the FIFO fallback the signature exists to avoid.
    """
    return "\x1e".join(
        f"{name}\x1d{reaching[name]}" for name in sorted(direct) if name in reaching
    )


def _plain_names(func, ordered: dict[str, list]) -> frozenset[str]:
    """The unit's names bound only by plain `name = <expr>` statements (#434).

    Such a name holds what one of those statements bound, so the subject an
    assertion checks through it is that statement's expression. Every
    binding of the name anywhere in the unit, nested scopes included, must be
    the single target of an `=`. A name is left out when anything else binds
    or declares it: a parameter (the unit's or a nested one), `global` or
    `nonlocal`, an augmented, annotated, tuple or chained assignment, a
    walrus, `for`, `with ... as`, `except ... as`, an import, a def or class,
    a match capture, `del`, or a comprehension target. A plain assignment in
    a nested scope binds that scope's own name, but one the unit's statement
    walk does not record is left out too: the counts must agree.
    """
    plain_targets: set[int] = set()
    stores: dict[str, list[int]] = {}
    other: set[str] = set()
    for node in _walk(func):
        if isinstance(node, ast.Name):
            if not isinstance(node.ctx, ast.Load):
                stores.setdefault(node.id, []).append(id(node))
        elif isinstance(node, ast.Assign):
            if len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
                plain_targets.add(id(node.targets[0]))
        elif isinstance(node, ast.arg):
            other.add(node.arg)
        elif isinstance(node, (ast.Global, ast.Nonlocal)):
            other.update(node.names)
        elif isinstance(node, ast.alias):
            other.add((node.asname or node.name).partition(".")[0])
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            other.add(node.name)
        elif isinstance(node, (ast.ExceptHandler, ast.MatchAs, ast.MatchStar)):
            if node.name:
                other.add(node.name)
        elif isinstance(node, ast.MatchMapping):
            if node.rest:
                other.add(node.rest)
    return frozenset(
        name for name, ids in stores.items()
        if name not in other
        and len(ids) == len(ordered.get(name, ()))
        and all(i in plain_targets for i in ids)
    )


def _resolved_subject(
    node: ast.AST,
    name: str,
    ordered: dict[str, list[tuple[tuple[int, int], bool, str, tuple[str, ...]]]],
) -> tuple[str, str] | None:
    """(expression, reading context) a plain local name stands for at this assertion (#434).

    The caller has checked that `name` is one of the unit's `_plain_names`
    and that the assertion is in the unit's own scope. Exactly one binding
    may reach it. A conditional one is enough: had it not run, the local
    would be unbound and the assertion would raise. No conditional binding
    may follow the assertion, since a loop around both would bring it back
    to the assertion. The context is the reaching keys of the names the
    expression reads, at the binding, in `ir.subjects.reaching_signature`'s
    form, so it compares with a subject written out at an assertion.
    """
    pos = (node.lineno, node.col_offset)
    reach = _reaching_entries(pos, name, ordered)
    if len(reach) != 1 or any(entry[1] and entry[0] > pos for entry in ordered.get(name, ())):
        return None
    bound_at, _conditional, key, refs = reach[0]
    if not key:
        return None
    keys = {
        ref: "\x1f".join(entry[2] for entry in _reaching_entries(bound_at, ref, ordered))
        for ref in refs
        if ref in ordered
    }
    return key, reaching_signature(keys, refs)


def _exclusive_bindings(func) -> tuple[str, ...]:
    """Multiply-bound names whose every binding sits in a different branch arm.

    A statement walk that labels each binding with its branch path — one
    `(id(branch_stmt), arm_index)` per enclosing `if`/`match` arm. Two bindings
    are exclusive when their paths diverge: at the first differing step they
    are different arms of the same statement, so no execution reaches both.
    A name qualifies only if *all* its bindings are pairwise exclusive —
    `expected = old` followed by an unconditional `expected = new` shares a
    path and must not qualify, because the second binding is the one the
    assertion reads.

    Records exactly the node kinds `_binding_maps` records — Assign,
    AnnAssign, AugAssign and walrus — so the two walks agree on what counts
    as a binding. Deliberately narrow: `for`/`while`/`with`/`try` bodies keep their parent's
    path (a rebind there is sequential or partially-executed, not an
    alternative), a walrus in an `if` test belongs to the parent path (the
    test runs before the branch), and nested `def`/`class` bodies keep the
    parent path too, mirroring the flat walk `_binding_definitions` uses.
    Conservative failures fire the rule, which is the safe direction.
    """
    found: dict[str, list[tuple]] = {}

    def record(stmt, path) -> None:
        for node in ast.walk(stmt):
            if isinstance(node, ast.Assign):
                targets, value = node.targets, node.value
            elif isinstance(node, (ast.AnnAssign, ast.AugAssign)):
                targets, value = [node.target], node.value
            elif isinstance(node, ast.NamedExpr) and isinstance(node.target, ast.Name):
                found.setdefault(node.target.id, []).append(path)
                continue
            else:
                continue
            if value is None:
                continue
            for target in targets:
                for name in _assignment_name_targets(target):
                    found.setdefault(name, []).append(path)

    def record_expr(expr, path) -> None:
        if expr is None:
            return
        for node in ast.walk(expr):
            if isinstance(node, ast.NamedExpr) and isinstance(node.target, ast.Name):
                found.setdefault(node.target.id, []).append(path)

    def walk(stmts, path) -> None:
        for s in stmts:
            if isinstance(s, ast.If):
                record_expr(s.test, path)
                walk(s.body, path + ((id(s), 0),))
                walk(s.orelse, path + ((id(s), 1),))
            elif isinstance(s, ast.Match):
                record_expr(s.subject, path)
                for i, case in enumerate(s.cases):
                    walk(case.body, path + ((id(s), i),))
            elif isinstance(s, (ast.For, ast.AsyncFor)):
                record_expr(s.iter, path)
                walk(s.body, path)
                walk(s.orelse, path)
            elif isinstance(s, ast.While):
                record_expr(s.test, path)
                walk(s.body, path)
                walk(s.orelse, path)
            elif isinstance(s, (ast.With, ast.AsyncWith)):
                for item in s.items:
                    record_expr(item.context_expr, path)
                walk(s.body, path)
            elif isinstance(s, ast.Try):
                walk(s.body, path)
                for h in s.handlers:
                    walk(h.body, path)
                walk(s.orelse, path)
                walk(s.finalbody, path)
            elif isinstance(s, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                walk(s.body, path)
            else:
                record(s, path)

    walk(func.body, ())

    def exclusive(paths: list[tuple]) -> bool:
        for i in range(len(paths)):
            for j in range(i + 1, len(paths)):
                a, b = paths[i], paths[j]
                diverged = False
                for x, y in zip(a, b):
                    if x != y:
                        diverged = x[0] == y[0]
                        break
                if not diverged:
                    return False
        return True

    return tuple(
        sorted(name for name, paths in found.items() if len(paths) > 1 and exclusive(paths))
    )


def _resolve_through(names: tuple[str, ...], bindings: dict[str, tuple[str, ...]]) -> tuple[str, ...]:
    """Follow local bindings to the names an expression really depends on.

    `expected = sum(items)` then `== expected` depends on `items`, which is
    what makes it a recomputation of the subject's own input rather than an
    independent expectation. Unbound names resolve to themselves so a module
    constant or a fixture argument stays distinguishable from a local
    computation. Cycles terminate on the `seen` set.

    Every name walked through is kept, not just the leaves. `items = [50.0,
    50.0]` binds a literal with no name references of its own, so dropping
    intermediates made `items` disappear from the closure — and `items` is
    exactly the name the subject shares. The link being looked for is between
    names as written on both sides, not between root values.
    """
    seen: set[str] = set()
    queue = list(names)
    while queue:
        name = queue.pop()
        if name in seen:
            continue
        seen.add(name)
        queue.extend(bindings.get(name, ()))
    return tuple(sorted(seen))


def _fixture_read_bindings(
    func,
    nested: set[int],
    refs_memo: dict[int, tuple[str, ...]] | None = None,
) -> dict[str, tuple[str, ...]]:
    """`_binding_maps`' reference half as `fixture_reads` follows it: the unit's own scope only (#471).

    `fixture_reads` follows the unit's own assignments through this map
    (D-155, reading 3). In `result = (lambda ledger: ledger.fee)(make())`,
    the lambda's `ledger` is not the fixture parameter, so `result` leads to
    `make` only. Each assigned value's `fixture_producers.nested_bound_names`
    are dropped from its references, even where such a name also occurs
    outside the lambda or comprehension that binds it, erring toward no
    evidence. An assignment or walrus inside a nested def, class or lambda
    (`nested`, the ids of their nodes) binds another scope's name and is not
    followed: neither `(lambda ledger: (fee := ledger.fee))(make())` nor a
    nested def's `fee = ledger.fee` leads `fee` to `ledger`. A walrus in what
    such a def, class or lambda evaluates in the unit's scope (a default or a
    decorator) is left out too, erring toward no evidence; a walrus in a
    comprehension of the unit's own scope is kept. So the keys are the
    binding map's, less the names bound only there; `fixture_reads` still
    checks the binding map for a parameter the body assigns again.
    `refs_memo` is the unit's memo of `_referenced_names`, which
    `_binding_maps` has already filled.
    """
    references: dict[str, set[str]] = {}
    for node in _walk(func):
        if isinstance(node, ast.Assign):
            targets, value = node.targets, node.value
        elif isinstance(node, (ast.AnnAssign, ast.AugAssign)):
            targets, value = [node.target], node.value
        elif isinstance(node, ast.NamedExpr) and isinstance(node.target, ast.Name):
            targets, value = [node.target], node.value
        else:
            continue
        if value is None or id(node) in nested:
            continue
        names = refs_memo.get(id(value)) if refs_memo is not None else None
        if names is None:
            names = _referenced_names(value)
        kept = set(names) - nested_bound_names(value)
        for target in targets:
            for name in _assignment_name_targets(target):
                references.setdefault(name, set()).update(kept)
    return {name: tuple(sorted(refs)) for name, refs in references.items()}


def _referenced_names(node) -> tuple[str, ...]:
    """Every `Name` id in a subtree, sorted and unique.

    Sorted rather than set-ordered because this reaches the IR, and no set
    iteration order is allowed to leak into output (SPEC §8).
    """
    if node is None:
        return ()
    return tuple(sorted({n.id for n in ast.walk(node) if isinstance(n, ast.Name)}))


def _classify_compare_op(
    op, left, comparators, text, left_text, right_lit, right_val, pos, subject=None
) -> _Classified:
    """The comparison-operator chain, split out so the caller can attach name
    sets to whichever `_Classified` comes back without repeating them at nine
    return sites. `subject` is the post-flip subject node: the `len()` shape
    rule must follow it, or `assert 3 == len(x)` and `assert len(x) == 3` rate
    differently and a pure operand flip reads as a weakening (SPEC §3 says
    `len(x) == n` is TYPE_SHAPE, full stop — audit 2026-08-19)."""
    if subject is None:
        subject = left
    if isinstance(op, (ast.Eq, ast.NotEq)):
        # Self-comparison (`assert f(x) == f(x)`) can never fail: the
        # oracle is gone even though the form still looks exact. Strip
        # identity ops (+0, -0, *1, /1) from both sides first, so
        # `f(x) == f(x) + 0` is caught too (confirmed red-team finding).
        if comparators and _norm(_strip_identity(left, text)) == _norm(
            _strip_identity(comparators[0], text)
        ):
            return _Classified("tautology", S.TAUTOLOGY, left_text, right_lit, right_val)
        # An equality with `ANY` holds for every value (D-201). `!=` with it
        # never holds, which is no weakening, so it keeps its reading. A
        # display of nothing but `ANY` checks only its shape.
        if isinstance(op, ast.Eq) and len(comparators) == 1 and (
                _is_mock_any(left, text) or _is_mock_any(comparators[0], text)):
            return _Classified("tautology", S.TAUTOLOGY, left_text, right_lit, right_val)
        if isinstance(op, ast.Eq) and len(comparators) == 1 and (
                _elementwise_unchecked(left, comparators[0], text)
                or _shaped_by(comparators[0], left, text) or _shaped_by(left, comparators[0], text)):
            return _Classified("tautology", S.TAUTOLOGY, left_text, right_lit, right_val)
        if isinstance(op, ast.Eq) and len(comparators) == 1 and (
                _only_any(left, text) or _only_any(comparators[0], text)):
            return _Classified("type_shape", S.TYPE_SHAPE, left_text, right_lit, right_val)
        if isinstance(subject, ast.Call) and _dotted(subject.func) == "len":
            return _Classified("type_shape", S.TYPE_SHAPE, left_text, right_lit, right_val)
        if _is_container_literal(left) or any(_is_container_literal(c) for c in comparators):
            return _Classified("compare_eq", S.EXACT_STRUCT, left_text, right_lit, right_val, positive=pos)
        return _Classified("compare_eq", S.EXACT_VALUE, left_text, right_lit, right_val, positive=pos)
    if isinstance(op, (ast.Gt, ast.GtE, ast.Lt, ast.LtE)):
        return _Classified("compare_ord", S.BOUND, left_text, right_lit, right_val, positive=pos)
    if isinstance(op, ast.In) and len(comparators) == 1:
        # `x in [ANY]` holds for every x, and `ANY in items()` only says
        # that items() is not empty (D-201).
        if _holds_any(comparators[0], text):
            return _Classified("tautology", S.TAUTOLOGY, left_text, right_lit, right_val)
        if _is_mock_any(left, text):
            return _Classified("truthy", S.TRUTHY, left_text)
    if isinstance(op, (ast.In, ast.NotIn)):
        return _Classified("membership", S.PATTERN, left_text, right_lit, right_val, positive=pos)
    if isinstance(op, (ast.Is, ast.IsNot)):
        comp = comparators[0]
        if isinstance(comp, ast.Constant) and comp.value is None:
            return _Classified("non_null", S.NON_NULL, left_text, positive=pos)
        return _Classified("compare_eq", S.EXACT_VALUE, left_text, right_lit, right_val, positive=pos)
    return _Classified("unknown", None, left_text)


def _tolerance_statement_classified(node: ast.Call, text) -> _Classified | None:
    """numpy's and torch's assertion calls, written as statements (#222)."""
    name = _tolerance_statement(node, _tolerance_names(text))
    return _tolerance_classified(node, name, text) if name is not None else None


# Each assertion method's operands by unittest's own parameter names, in
# positional order (`unittest.case.TestCase`). The raises family is not here:
# its operands keep their positional reading (#462).
_UNITTEST_OPERANDS: dict[str, tuple[str, ...]] = {
    "assertEqual": ("first", "second"),
    "assertNotEqual": ("first", "second"),
    "assertMultiLineEqual": ("first", "second"),
    "assertCountEqual": ("first", "second"),
    "assertAlmostEqual": ("first", "second"),
    "assertNotAlmostEqual": ("first", "second"),
    "assertListEqual": ("list1", "list2"),
    "assertTupleEqual": ("tuple1", "tuple2"),
    "assertSetEqual": ("set1", "set2"),
    "assertDictEqual": ("d1", "d2"),
    "assertSequenceEqual": ("seq1", "seq2"),
    "assertIs": ("expr1", "expr2"),
    "assertIsNot": ("expr1", "expr2"),
    "assertIn": ("member", "container"),
    "assertNotIn": ("member", "container"),
    "assertIsInstance": ("obj", "cls"),
    "assertNotIsInstance": ("obj", "cls"),
    "assertGreater": ("a", "b"),
    "assertGreaterEqual": ("a", "b"),
    "assertLess": ("a", "b"),
    "assertLessEqual": ("a", "b"),
    "assertRegex": ("text", "expected_regex"),
    "assertNotRegex": ("text", "unexpected_regex"),
    "assertTrue": ("expr",),
    "assertFalse": ("expr",),
    "assertIsNone": ("obj",),
    "assertIsNotNone": ("obj",),
}


def _unittest_operands(method: str, node: ast.Call) -> list[ast.expr] | None:
    """A unittest assertion's operands in positional order, or None when they cannot be bound (#462).

    Each operand is taken by position or, failing that, by its parameter
    name: `assertEqual(first=value(), second=[1, 2])` and
    `assertEqual(value(), second=[1, 2])` state what
    `assertEqual(value(), [1, 2])` states. Only the positional reading
    existed, so a keyword operand was no operand at all: a rewritten
    expectation passed, and a respelling read as a weakening.

    As for a tolerance call (#222), no operand is read from a position at
    or after a starred argument; its keyword is taken instead. An operand
    that has neither, in a call with a `*` or `**` argument
    (`assertEqual(*pair)`, `assertEqual(**case)`, `assertEqual(x, **kw)`),
    could be anything, so the call's operands are unbound: None (462.Q2).

    The list is exactly `node.args`, the same nodes, for a call that states
    every operand by position before any starred argument, extra positional
    arguments (`places`, `msg`) included; for an all-positional call with no
    starred argument, even one that lacks an operand; and for a method with
    no name table (the raises family). Those records are unchanged.
    """
    args = node.args
    names = _UNITTEST_OPERANDS.get(method)
    starred = next((i for i, arg in enumerate(args) if isinstance(arg, ast.Starred)), len(args))
    if names is None or starred >= len(names):
        return list(args)
    operands = list(args[:starred])
    spread = starred < len(args) or any(kw.arg is None for kw in node.keywords)
    for name in names[starred:]:
        value = next((kw.value for kw in node.keywords if kw.arg == name), None)
        if value is None:
            if spread:
                return None
            break
        operands.append(value)
    return operands


def _unbound_unittest(node: ast.Call, form: str, level: int | None, positive: bool, text) -> _Classified:
    """A unittest assertion whose operands cannot be bound (462.Q2).

    Its form and strength are the method's; it records no subject, no
    expected value and no names, and it is not trivial: what it compares is
    unknown, not known to be vacuous. ASSERT_WEAKENED reports a known oracle
    replaced by one as unverifiable. A tolerance stated by keyword is read
    as it always is; with none, the default is not assumed, since the
    spread may carry `places` or `delta`.
    """
    epsilon = epsilon_kind = None
    if form == "approx" and positive:
        for kw in node.keywords:
            if kw.arg in ("places", "delta"):
                epsilon = text.seg(kw.value)
                epsilon_kind = kw.arg
    return _Classified(form, level, epsilon=epsilon, epsilon_kind=epsilon_kind, positive=positive,
                       unbound_operands=True)


def _classify_unittest_call(node: ast.Call, text: str) -> _Classified | None:
    if not (isinstance(node.func, ast.Attribute) and isinstance(node.func.value, ast.Name) and node.func.value.id == "self"):
        return None
    method = node.func.attr
    if method not in _UNITTEST_MAP:
        return None
    form, level = _UNITTEST_MAP[method]
    # Every operand below is read from the bound list, by position or by
    # name (#462); a call whose operands cannot be bound records none.
    args = _unittest_operands(method, node)
    if args is None:
        return _unbound_unittest(node, form, level, method not in _NEGATED_UNITTEST, text)
    # `assertIs(x, None)` / `assertIsNot(x, None)` are the generic spellings of
    # assertIsNone / assertIsNotNone. Leaving them at compare_eq made the
    # dialects incoherent — bare `assert x is None` is non_null, so a pure
    # spelling conversion was reported as a polarity inversion while a genuine
    # cross-dialect inversion was not (audit 2026-08-19).
    if method in ("assertIs", "assertIsNot") and len(args) > 1:
        for arg in args[:2]:
            if isinstance(arg, ast.Constant) and arg.value is None:
                method = "assertIsNone" if method == "assertIs" else "assertIsNotNone"
                form, level = _UNITTEST_MAP[method]
                break
    positive = method not in _NEGATED_UNITTEST
    # `assertTrue(math.isclose(...))` is read as the call it wraps (222.Q2), and
    # `assertFalse(...)` as its negation.
    if method in ("assertTrue", "assertFalse") and args:
        wrapped, holds = args[0], positive
        while isinstance(wrapped, ast.UnaryOp) and isinstance(wrapped.op, ast.Not):
            wrapped, holds = wrapped.operand, not holds
        found = (_find_tolerance_predicate(wrapped, _tolerance_names(text))
                 if isinstance(wrapped, ast.Call) else None)
        if found is not None:
            return _tolerance_classified(*found, text, positive=holds)
    # The hand-rolled bound in the unittest dialect: `assertLess(abs(d), eps)`,
    # `assertGreater(eps, abs(d))` and `assertTrue(abs(d) < eps)` (#196 189.2),
    # and each lower bound, `assertGreater(abs(d), eps)` (#224).
    hand = None
    if method in ("assertLess", "assertLessEqual") and len(args) > 1:
        hand = _hand_rolled(args[0], args[1], method == "assertLess", text, form, level)
    elif method in ("assertGreater", "assertGreaterEqual") and len(args) > 1:
        hand = _hand_rolled(args[1], args[0], method == "assertGreater", text, form, level)
    elif method == "assertTrue" and args:
        hand = _hand_rolled_comparison(args[0], text, form, level)
    if hand is not None:
        return hand
    left_text = None
    right_lit = None
    right_val = None
    epsilon = None
    epsilon_kind = None
    subject_node: ast.AST | None = None
    expect_node: ast.AST | None = None
    if args:
        subject_node = args[0]
        if len(args) > 1:
            expect_node = args[1]
            # Same literal-side flip as bare assert: `assertEqual(3, calc())`,
            # and `assertEqual(ANY, calc())` (D-201).
            if ((_is_literal(args[0]) or _any_like(args[0], text))
                    and not (_is_literal(args[1]) or _any_like(args[1], text))):
                expect_node, subject_node = args[0], args[1]
        left_text = text.seg(subject_node) if subject_node is not None else None
        if expect_node is not None:
            right_lit = _literal_repr(expect_node, text, conversions=_conversions(text))
            right_val = _literal_value(expect_node, conversions=_conversions(text))
        if form == "compare_eq" and level == S.EXACT_VALUE and len(args) > 1:
            if _is_container_literal(args[0]) or _is_container_literal(args[1]):
                level = S.EXACT_STRUCT
        # The len() shape rule, on the post-flip subject, same as the bare
        # lattice: `assertEqual(len(x), 3)` and `assert len(x) == 3` are both
        # TYPE_SHAPE. Without it the unittest dialect rated the shape
        # EXACT_VALUE and a routine modernisation blocked at high
        # (audit 2026-08-19).
        if (
            form == "compare_eq"
            and level == S.EXACT_VALUE
            and isinstance(subject_node, ast.Call)
            and _dotted(subject_node.func) == "len"
        ):
            form, level = "type_shape", S.TYPE_SHAPE
    # assertNotAlmostEqual passes when the values are far apart, so its
    # tolerance orders the other way and is not recorded, as a negated
    # `approx` is not (#284).
    if form == "approx" and positive:
        for kw in node.keywords:
            if kw.arg in ("places", "delta"):
                epsilon = text.seg(kw.value)
                epsilon_kind = kw.arg
        # assertAlmostEqual(a, b, places) — positional third argument.
        if epsilon is None and len(args) > 2:
            seg = text.seg(args[2])
            if seg:
                epsilon, epsilon_kind = seg, "places"
        if epsilon is None:
            # assertAlmostEqual's implicit default is places=7. Recording it
            # makes `places=0` appearing a loosening of that default instead
            # of silence — same one-sided-event defect as pytest.approx
            # (audit 2026-08-19).
            epsilon, epsilon_kind = "7", "places"
    if form == "truthy" and args and _is_literal(args[0]):
        form, level = "tautology", S.TAUTOLOGY
    if form == "compare_eq" and subject_node is not None and expect_node is not None:
        # Self-comparison with identity ops stripped, on the two actual
        # operands — the post-flip subject against the post-flip expectation.
        # The old check read `seg(args[1])` against `seg(args[1])`, so every
        # literal-first `assertEqual(expected, actual)` — the canonical
        # unittest order — was a textual self-comparison and classified
        # TAUTOLOGY(10). With strength 10 recorded, any weakening read as a
        # strength rise and the whole lattice was inert on the dialect's most
        # common spelling (audit 2026-08-19).
        if _norm(_strip_identity(subject_node, text)) == _norm(
            _strip_identity(expect_node, text)
        ):
            form, level = "tautology", S.TAUTOLOGY
    # `self.assertEqual(x, ANY)` holds for every x, as `x == ANY` does, and so
    # does `assertAlmostEqual(x, ANY)`, which returns as soon as the two
    # compare equal (D-201). Whatever the subject reads as: a `len(x)`
    # subject has already made the pair TYPE_SHAPE. Not the typed variants,
    # which check an operand's type first, nor assertCountEqual, which
    # iterates it, nor the negated methods, which can then never pass.
    if (positive and method in ("assertEqual", "assertAlmostEqual")
            and (_is_mock_any(subject_node, text) or _is_mock_any(expect_node, text))):
        form, level = "tautology", S.TAUTOLOGY
        epsilon = epsilon_kind = None
    elif (positive and method in ("assertEqual", "assertListEqual", "assertTupleEqual", "assertSequenceEqual",
                                  "assertDictEqual")
            and (_elementwise_unchecked(subject_node, expect_node, text) or _shaped_by(expect_node, subject_node, text)
                 or _shaped_by(subject_node, expect_node, text))):
        form, level = "tautology", S.TAUTOLOGY
    elif (positive and method in ("assertEqual", "assertListEqual", "assertTupleEqual", "assertDictEqual",
                                  "assertSequenceEqual", "assertCountEqual")
            and (_only_any(subject_node, text) or _only_any(expect_node, text))):
        # assertCountEqual pairs each entry with one that compares equal, and
        # ANY compares equal to every entry, so only the length is left.
        form, level = "type_shape", S.TYPE_SHAPE
    elif method == "assertIn" and len(args) > 1 and _holds_any(args[1], text):
        # `assertIn(x, [ANY])` holds for every x; `assertIn(ANY, items())`
        # says only that items() is not empty (D-201).
        form, level = "tautology", S.TAUTOLOGY
    elif method == "assertIn" and len(args) > 1 and _is_mock_any(args[0], text):
        form, level = "truthy", S.TRUTHY
    return _Classified(
        form,
        level,
        left_text,
        right_lit,
        right_val,
        epsilon,
        epsilon_kind,
        positive,
        _referenced_names(subject_node),
        _referenced_names(expect_node),
        # Same vacuousness test the bare path applies (`assert str(1) == "1"`
        # cannot fail): without it, `self.assertEqual(str(1), "1")` counted as
        # oracle mass for D4/D5 and reopened the padding family in the
        # unittest dialect (THREATMODEL 20/25/46, audit 2026-08-19).
        _is_trivial_subject(subject_node)
        and (expect_node is None or _is_trivial_subject(expect_node)),
        *_unittest_bound(method, form, args, subject_node, expect_node, text),
        unevaluated_expected=(_unevaluated(expect_node, text) if form in _EXPECTED_FORMS
                              else _any_shape(expect_node) if form == "type_shape" and _only_any(expect_node, text)
                              else None),
    )


# unittest's ordering methods, as the bound key each states (#224).
_UNITTEST_BOUND_KEYS = {"assertLess": "lt", "assertLessEqual": "le", "assertGreater": "gt",
                        "assertGreaterEqual": "ge"}


def _unittest_bound(method, form, operands, subject_node, expect_node, text) -> tuple[str | None, str | None]:
    """(predicate, operand_source) of `assertLess(x, 80)` and its kin, read from the subject's side.

    `operands` is the call's bound operand list (`_unittest_operands`), so
    `assertLess(a=x, b=80)` states what `assertLess(x, 80)` states (#462).
    Both operands were found, so the list holds at least two.
    """
    key = _UNITTEST_BOUND_KEYS.get(method)
    if key is None or form != "compare_ord" or subject_node is None or expect_node is None:
        return None, None
    if subject_node is not operands[0]:
        # `assertGreater(80, total())` states `total() < 80`.
        key = _REVERSED_KEYS[key]
    return key, _operand_source(expect_node, text)


def _canonical_marker(name: str | None) -> str | None:
    """Resolve a decorator's dotted name to its canonical skip-marker name.

    `import pytest as p` then `@p.mark.skip` is the same marker as
    `@pytest.mark.skip`; matching the literal dotted string missed it
    (confirmed bypass). Matching is done on the trailing components, which
    are alias-independent.
    """
    if not name:
        return None
    if name in _SKIP_DECORATORS:
        return name
    parts = name.split(".")
    for width in (3, 2, 1):
        if len(parts) >= width:
            tail = ".".join(parts[-width:])
            if tail in _SKIP_DECORATORS:
                return tail
            if width >= 2 and parts[-2] == "mark" and f"pytest.mark.{parts[-1]}" in _SKIP_DECORATORS:
                return f"pytest.mark.{parts[-1]}"
    return None


def _marker_identity(canonical: str, node: ast.AST, text) -> str:
    """Marker name plus its condition, so `skipif(False)` -> `skipif(True)` is
    a change and not a no-op (confirmed bypass: only names were compared)."""
    if isinstance(node, ast.Call) and node.args:
        cond = _norm(text.seg(node.args[0]) or "")
        if cond:
            return f"{canonical}({cond})"
    return canonical


def _held_marks(
    name: str, aliases: dict[str, list[ast.expr]], resolving: frozenset[str] = frozenset()
) -> list[ast.AST]:
    """The marks a name may hold as a decorator: each value it is bound to that is one mark."""
    if name in resolving or len(resolving) >= 8:
        return []
    held: list[ast.AST] = []
    for value in aliases.get(name, []):
        if isinstance(value, ast.Name) and not _canonical_marker(value.id):
            held += _held_marks(value.id, aliases, resolving | {name})
        elif isinstance(value, (ast.Call, ast.Attribute, ast.Name)):
            if _canonical_marker(_dotted(value.func if isinstance(value, ast.Call) else value)):
                held.append(value)
    return held


def _decorator_markers(
    node: ast.FunctionDef | ast.AsyncFunctionDef | ast.ClassDef,
    text: str,
    off: _Offsets,
    aliases: dict[str, list[ast.expr]] | None = None,
) -> list[Marker]:
    """The skip and xfail marks a definition's decorators apply.

    A decorator that names a bound mark (`skip_slow = pytest.mark.skip(...)`
    / `@skip_slow`) applies that mark, and is recorded as the mark's own
    call. Until #260 that binding was read as a module-level skip call, which
    caught this spelling and also blocked a mark that was never applied
    (#260 M1). A called name (`skip_if = pytest.mark.skipif` /
    `@skip_if(cond)`) is the decorator's own call.
    """
    markers: list[Marker] = []
    for dec in node.decorator_list:
        target = dec.func if isinstance(dec, ast.Call) else dec
        canonical = _canonical_marker(_dotted(target))
        found: list[tuple[str, ast.AST]] = [(canonical, dec)] if canonical else []
        if not canonical and aliases and isinstance(target, ast.Name):
            for held in _held_marks(target.id, aliases):
                name = _canonical_marker(_dotted(held.func if isinstance(held, ast.Call) else held))
                # `@skip_if(cond)` calls a mark the name holds uncalled: the
                # call is the decorator's own.
                called = isinstance(dec, ast.Call) and not isinstance(held, ast.Call)
                found.append((name, dec if called else held))
        for name, mark in found:
            markers.append(
                Marker(name=_marker_identity(name, mark, text), text=text.seg(mark) or name, span=off.span(mark))
            )
    return markers


# `pytestmark.append(m)`, `.insert(i, m)` and `.extend([...])`: which argument
# holds the mark, or the list of them (#260 Q1).
_PYTESTMARK_METHODS = {"append": 0, "extend": 0, "insert": 1}


def _plain_values(body: list[ast.stmt]) -> dict[str, list[ast.expr]]:
    """Every value one scope binds each name to by a plain `=`, in any compound statement.

    Only the scope's own statements are read, never the body of a function
    or class it defines: this runs on every test module.
    """
    values: dict[str, list[ast.expr]] = {}
    stack = list(reversed(body))
    while stack:
        stmt = stack.pop()
        if isinstance(stmt, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            continue
        if isinstance(stmt, ast.Assign):
            for target in stmt.targets:
                if isinstance(target, ast.Name):
                    values.setdefault(target.id, []).append(stmt.value)
        elif isinstance(stmt, ast.AnnAssign) and stmt.value is not None and isinstance(stmt.target, ast.Name):
            values.setdefault(stmt.target.id, []).append(stmt.value)
        nested = [s for name in _STMT_BODY_FIELDS for s in getattr(stmt, name, None) or []]
        nested += [s for handler in getattr(stmt, "handlers", None) or [] for s in handler.body]
        nested += [s for case in getattr(stmt, "cases", None) or [] for s in case.body]
        stack.extend(reversed([s for s in nested if isinstance(s, ast.stmt)]))
    return values


def _mark_aliases(
    body: list[ast.stmt], outer: dict[str, list[ast.expr]] | None = None
) -> dict[str, list[ast.expr]]:
    """Every value one scope binds each name to by a plain `=`.

    A class body's names are read with its module's, which Python falls back
    to there.
    """
    own = _plain_values(body)
    if not outer:
        return own
    if not own:
        return outer
    return {name: own.get(name, []) + outer.get(name, []) for name in {*own, *outer}}


def _marks_in(
    value: ast.AST, aliases: dict[str, list[ast.expr]], resolving: frozenset[str] = frozenset()
) -> list[ast.AST]:
    """The skip and xfail marks a value holds, as the nodes that spell them.

    A mark, a list or tuple of marks, a `+` of those, or a name bound to any
    of them (#260 Q1). The ruling names a name bound once; one bound more
    than once holds the marks of every value it is bound to, so the reading
    fails toward flagging. A name a decorator would read as a mark is one,
    as before, whatever it is bound to.
    """
    if isinstance(value, ast.Starred):
        value = value.value
    if isinstance(value, (ast.Call, ast.Attribute, ast.Name)):
        if _canonical_marker(_dotted(value.func if isinstance(value, ast.Call) else value)):
            return [value]
    if isinstance(value, (ast.List, ast.Tuple)):
        return [mark for element in value.elts for mark in _marks_in(element, aliases, resolving)]
    if isinstance(value, ast.BinOp) and isinstance(value.op, ast.Add):
        return _marks_in(value.left, aliases, resolving) + _marks_in(value.right, aliases, resolving)
    if isinstance(value, ast.Name) and value.id not in resolving and len(resolving) < 8:
        inner = resolving | {value.id}
        return [mark for bound in aliases.get(value.id, []) for mark in _marks_in(bound, aliases, inner)]
    return []


def _is_pytestmark(node: ast.AST) -> bool:
    if isinstance(node, ast.Subscript):
        node = node.value
    return isinstance(node, ast.Name) and node.id == "pytestmark"


def _paired(target: ast.AST, value: ast.AST):
    """Each target with the value it receives, through the unpacking of a literal tuple or list.

    A literal of the target's length unpacks element by element, so a starred
    target receives a list of the one element beside it.
    """
    if isinstance(target, ast.Starred):
        target = target.value
    if isinstance(target, (ast.Tuple, ast.List)):
        if (
            isinstance(value, (ast.Tuple, ast.List))
            and len(value.elts) == len(target.elts)
            and not any(isinstance(e, ast.Starred) for e in value.elts)
        ):
            for t, v in zip(target.elts, value.elts):
                yield from _paired(t, v)
        return
    yield target, value


def _pytestmark_values(stmt: ast.stmt) -> list[ast.AST]:
    """What one statement puts into `pytestmark`: each value it binds, adds or appends."""
    if isinstance(stmt, ast.Assign):
        return [v for target in stmt.targets for t, v in _paired(target, stmt.value) if _is_pytestmark(t)]
    if isinstance(stmt, ast.AnnAssign):
        return [stmt.value] if stmt.value is not None and _is_pytestmark(stmt.target) else []
    if isinstance(stmt, ast.AugAssign):
        return [stmt.value] if _is_pytestmark(stmt.target) else []
    if isinstance(stmt, ast.Expr) and isinstance(stmt.value, ast.Call):
        call = stmt.value
        func = call.func
        if isinstance(func, ast.Attribute) and func.attr in _PYTESTMARK_METHODS and _is_pytestmark(func.value):
            index = _PYTESTMARK_METHODS[func.attr]
            return [call.args[index]] if len(call.args) > index else []
    return []


def _pytestmark_markers(
    body: list[ast.stmt], text: str, off: _Offsets, aliases: dict[str, list[ast.expr]]
) -> list[Marker]:
    """Every skip or xfail mark `pytestmark` gets in one scope: a module or a class body.

    pytest reads the name once the scope has run, so every binding counts
    (#260 Q1): `=` and an annotated `=`, one target of a tuple, `+=`, a
    subscript, and `.append`, `.extend` or `.insert` on it, inside any
    compound statement. A value is read by `_marks_in`.

    Each mark is recorded as a decorator is: its own call's text and span.
    D6 reads a `skipif` condition by parsing the marker's text as a call, and
    the whole `pytestmark = ...` statement never parsed as one (#209 X1). Its
    name is the one a decorator would mint, so a mark keeps its identity when
    it moves between spellings (#260 Q3).

    The binding's path condition is the mark's guard (#260 Q2): each
    enclosing `if` test, `not (...)` for an `else`, and an `except` block's
    condition (`_handler_guard`), as a conftest's `collect_ignore` records
    its own. A `with`, loop or `match` body and a `try` body add none, so a
    binding there reads as unconditional.
    """
    found: list[tuple[ast.AST, tuple[str, ...]]] = []

    def record(statements: list[ast.stmt], conds: tuple[str, ...]) -> None:
        for stmt in statements:
            if isinstance(stmt, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                continue
            if isinstance(stmt, ast.If):
                test = text.seg(stmt.test) or ast.unparse(stmt.test)
                record(stmt.body, (*conds, test))
                record(stmt.orelse, (*conds, f"not ({test})"))
                continue
            for value in _pytestmark_values(stmt):
                found.extend((mark, conds) for mark in _marks_in(value, aliases))
            for field_name in _STMT_BODY_FIELDS:
                record([s for s in getattr(stmt, field_name, None) or [] if isinstance(s, ast.stmt)], conds)
            for handler in getattr(stmt, "handlers", None) or []:
                record(handler.body, (*conds, _handler_guard(stmt, handler)))
            for case in getattr(stmt, "cases", None) or []:
                record(case.body, conds)

    record(body, ())
    markers: list[Marker] = []
    for mark, conds in found:
        canonical = _canonical_marker(_dotted(mark.func if isinstance(mark, ast.Call) else mark))
        markers.append(
            Marker(
                name=_marker_identity(canonical, mark, text),
                text=text.seg(mark) or canonical,
                span=off.span(mark),
                guard=_conjunction(conds),
            )
        )
    return markers


def _test_attr_disabled(body: list[ast.stmt]) -> bool:
    """`__test__ = False` at module or class scope removes it from collection."""
    for stmt in body:
        targets: list[ast.expr] = []
        if isinstance(stmt, ast.Assign):
            targets = list(stmt.targets)
        elif isinstance(stmt, ast.AnnAssign) and stmt.value is not None:
            targets = [stmt.target]
        else:
            continue
        if not any(isinstance(t, ast.Name) and t.id == "__test__" for t in targets):
            continue
        value = stmt.value
        if isinstance(value, ast.Constant) and not value.value:
            return True
    return False


def _module_skip_markers(tree: ast.Module, text, off: _Offsets) -> list[Marker]:
    """Module-level `pytest.skip(..., allow_module_level=True)` and
    `pytest.importorskip(...)` disable the whole file (confirmed bypass)."""
    markers: list[Marker] = []
    if _test_attr_disabled(tree.body):
        # pytest checks `safe_getattr(obj, "__test__", True)` before collecting
        # a module or a class. One line at module scope de-collects the whole
        # file and greenwash reported nothing at all (reader audit 2026-08-02).
        markers.append(Marker(name="module.__test__", text="__test__ = False", span=(0, 0)))
    for stmt in tree.body:
        call = None
        if isinstance(stmt, ast.Expr) and isinstance(stmt.value, ast.Call):
            call = stmt.value
        elif isinstance(stmt, ast.Assign) and isinstance(stmt.value, ast.Call):
            # `pytestmark = pytest.mark.skip(...)` is _pytestmark_markers' job;
            # only the assigned-result form of importorskip belongs here.
            if any(isinstance(t, ast.Name) and t.id == "pytestmark" for t in stmt.targets):
                continue
            call = stmt.value
        if call is None:
            continue
        name = _dotted(call.func)
        if not name:
            continue
        parts = name.split(".")
        if len(parts) >= 2 and parts[-2] == "mark":
            # `skip_slow = pytest.mark.skip(...)` builds a mark and disables
            # nothing until a decorator or `pytestmark` applies it, and those
            # read it. Its leaf name made it a module-level skip call, which
            # blocked a mark that was never applied (#260 M1, M2).
            continue
        leaf = parts[-1]
        if leaf in ("skip", "xfail", "importorskip"):
            seg = (text.seg(stmt) or leaf).split("\n")[0]
            markers.append(Marker(name=f"module.{leaf}", text=seg, span=off.span(stmt)))
    return markers


def _caught_types(type_expr: ast.AST | None) -> tuple[str, ...]:
    """Dotted names of the exception types one catcher expression spells.

    `None` (a bare `except`) is (); tuples expand to their elements; an
    expression that is not a name chain — `E` resolved from an assignment
    would need binding analysis, a call, a subscript — records as "?", which
    no membership test matches: the aliased/dynamic spellings stay a named
    residual on every path (issue #57 §3), priced in the matrix rather than
    guessed at here.
    """
    if type_expr is None:
        return ()
    if isinstance(type_expr, ast.Tuple):
        return tuple(_dotted(e) or "?" for e in type_expr.elts)
    return (_dotted(type_expr) or "?",)


def _catches_assertionerror(caught: tuple[str, ...]) -> bool:
    """The one type-set truth: can this catcher swallow a failed assert?

    A bare catcher, or any type whose leaf is in `_BROAD_EXCEPTIONS`
    (Exception and BaseException are AssertionError's ancestors), catches it.
    Both the `except` path and the `with` path decide through this predicate —
    issue #57's whole point: the 2026-09-01 history was per-spelling patches
    (except covered, then `pytest.raises` bypassed, then `suppress`, then the
    tuple spelling) because the two paths kept separate type logic.
    """
    return not caught or any(c.rsplit(".", 1)[-1] in _BROAD_EXCEPTIONS for c in caught)


def _handler_info(node: ast.ExceptHandler) -> tuple[tuple[str, ...], bool]:
    caught = _caught_types(node.type)
    return caught, _catches_assertionerror(caught)


def _is_oracle_call(node: ast.AST) -> bool:
    """A call that can fail the test: `self.assertX(...)`, `pytest.fail()`,
    `pytest.raises(...)`. Matched on the trailing component so an aliased
    import cannot dodge it."""
    if not isinstance(node, ast.Call):
        return False
    leaf = (_dotted(node.func) or "").rsplit(".", 1)[-1]
    return leaf.startswith("assert") or leaf in ("fail", "raises")


def _contains_oracle(body: list[ast.stmt]) -> bool:
    """Is there something in these statements that can fail the test?

    Nested `def`/`class`/`lambda` bodies are skipped: they are definitions,
    not statements this block executes (same reasoning as `_unreachable_ids`).
    """
    stack: list[ast.AST] = list(body)
    while stack:
        node = stack.pop()
        if isinstance(node, ast.Assert) or _is_oracle_call(node):
            return True
        for child in ast.iter_child_nodes(node):
            if isinstance(
                child, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef, ast.Lambda)
            ):
                continue
            stack.append(child)
    return False


def _wraps_bare_assert(body: list[ast.stmt]) -> bool:
    """A bare `assert` statement runs directly in these statements.

    Narrower than `_contains_oracle` on purpose: `_is_oracle_call` treats any
    `assert*`-named call as an oracle, so a legitimate contract test —
    `with pytest.raises(AssertionError): my_validator(bad)` — would look like
    it wraps one. The neutralization signal keys only on a real `assert`
    statement, which is what both reported bypasses wrap and what a contract
    test of a helper never does. Nested scopes skipped, as everywhere else.
    """
    stack: list[ast.AST] = list(body)
    while stack:
        node = stack.pop()
        if isinstance(node, ast.Assert):
            return True
        for child in ast.iter_child_nodes(node):
            if isinstance(
                child, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef, ast.Lambda)
            ):
                continue
            stack.append(child)
    return False


_NEUTRALIZING_CONTEXTS = ("suppress", "raises", "assertRaises", "assertRaisesRegex")


def _neutralizes_assertionerror(call: ast.AST) -> str | None:
    """A `with`-context that catches a failed assertion.

    `suppress(...)` swallows it, `pytest.raises(...)` expects it, and the
    unittest dialect — `self.assertRaises(...)` / `assertRaisesRegex(...)` as
    a context manager — is `raises` with a different surface (issue #57 §1;
    the regex variant still requires the assert to fail, the pattern only
    constrains the message). Whether the named type set can catch an
    AssertionError is decided by `_catches_assertionerror`, the same
    predicate the `except` path uses, so `pytest.raises(Exception)` and
    `raises(BaseException)` count exactly as `except Exception` always has
    (issue #57 §2 — the asymmetry that produced the tuple hole). Matched on
    the trailing callee name so an alias can't dodge it — `from contextlib
    import suppress as s` still resolves to `suppress`. For `suppress` every
    positional argument counts (it can suppress several); for the raises
    family only the first argument is the expected type. A callee bound to a
    bare name (`r = pytest.raises`) and an aliased type value
    (`E = AssertionError`) stay named residuals, asserted silent in
    tests/test_neutralization_matrix.py.
    """
    if not isinstance(call, ast.Call):
        return None
    leaf = (_dotted(call.func) or "").rsplit(".", 1)[-1]
    if leaf not in _NEUTRALIZING_CONTEXTS:
        return None
    candidates = call.args if leaf == "suppress" else call.args[:1]
    caught = tuple(t for arg in candidates for t in _caught_types(arg))
    if caught and _catches_assertionerror(caught):
        return leaf
    return None


def _swallows(handler: ast.ExceptHandler) -> bool:
    """Does this handler make the caught failure disappear?

    A handler that re-raises, or that asserts on what it caught, still lets
    the test fail — it is inspection, not suppression.
    """
    return not _raises_in(handler) and not _contains_oracle(handler.body)


def _unreachable_ids(
    func: ast.FunctionDef | ast.AsyncFunctionDef, fixtures=None, outcome=None, attrs=None
) -> set[int]:
    """Node ids under statements that can never execute.

    `return` (or `raise`) parked at the top of a test body leaves every
    assertion in the AST while killing the test — a one-token cheat that was
    completely silent before (confirmed red-team finding). A raise that
    `outcome` reads as a native skip or xfail is not one: it skips the test as
    `pytest.skip()` does, its marker reports that, and the assertions after
    it are still the test's (#220).

    `attrs` resolves the class attributes a method's guards read through its
    receiver (`ClassAttributes.env`, #254): `if self.item_class is None:` is
    dead code for a class whose body sets `item_class = list`.
    """
    dead: set[int] = set()
    resolved_guards = None
    names: frozenset[str] | None = None if attrs is not None else frozenset()

    def truth_of(test: ast.AST) -> bool | None:
        # The receiver is found only once a guard needs it: most units have none.
        nonlocal names
        if names is None:
            names = receivers(func)
        return _static_truth(substitute(test, attrs, names))

    def kill(node: ast.AST) -> None:
        for sub in ast.walk(node):
            dead.add(id(sub))

    def scan(body: list[ast.stmt]) -> bool:
        nonlocal resolved_guards
        stop = False
        for stmt in body:
            if stop:
                kill(stmt)
                continue
            if isinstance(stmt, ast.Raise) and outcome is not None and outcome(stmt):
                continue
            if isinstance(stmt, (ast.Return, ast.Raise)):
                stop = True
                continue
            # A nested def/lambda/class body does not run when the test runs;
            # moving an assertion into one keeps it in the AST while removing
            # it from execution (confirmed bypass).
            if isinstance(stmt, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                kill(stmt)
                continue
            if isinstance(stmt, (ast.If, ast.While)):
                # Most tests have no branch. Resolve bindings only when the
                # reachability walk needs a guard, using the same whole scope.
                if resolved_guards is None:
                    resolved_guards = guard_truths(func, fixtures or {}, truth_of)
                truth = resolved_guards.get(id(stmt), truth_of(stmt.test))
                if truth is False:
                    for inner in stmt.body:
                        kill(inner)
                    stop = scan(stmt.orelse)
                    continue
                if truth is True and isinstance(stmt, ast.If):
                    stop = scan(stmt.body)
                    for inner in stmt.orelse:
                        kill(inner)
                    continue
            # `for _ in []:` never enters its body; the else clause still runs.
            if isinstance(stmt, ast.For) and _is_literal(stmt.iter) and not _truthy_literal(stmt.iter):
                for inner in stmt.body:
                    kill(inner)
                stop = scan(stmt.orelse)
                continue
            if isinstance(stmt, ast.Match) and _match_is_dead(stmt):
                for case in stmt.cases:
                    for inner in case.body:
                        kill(inner)
                continue
            for name in ("body", "orelse", "finalbody"):
                inner_body = getattr(stmt, name, None)
                if isinstance(inner_body, list) and inner_body and isinstance(inner_body[0], ast.stmt):
                    scan(inner_body)
            for handler in getattr(stmt, "handlers", []) or []:
                scan(handler.body)
        # Only a statically selected branch inherits its body's termination.
        # Unknown loops, exception handlers and finally retain the existing
        # conservative path handling above.
        return stop

    scan(func.body)
    # Lambdas anywhere in the body are deferred code too.
    for node in _walk(func):
        if isinstance(node, ast.Lambda):
            kill(node.body)
    return dead


_CMP_OPS: dict[type, object] = {
    ast.Eq: operator.eq,
    ast.NotEq: operator.ne,
    ast.Lt: operator.lt,
    ast.LtE: operator.le,
    ast.Gt: operator.gt,
    ast.GtE: operator.ge,
    ast.In: lambda a, b: a in b,
    ast.NotIn: lambda a, b: a not in b,
}
# `is` / `is not` are deliberately absent: their result on literals depends on
# interning, which differs between interpreters and would make the verdict
# version-dependent. Unknown is the safe answer — it keeps the branch live.


def _static_truth(node: ast.AST) -> bool | None:
    """Constant-fold a branch condition to True / False / None (unknown).

    `if False:` was recognised, but `if not True:`, `if 1 == 2:` and
    `if False and x:` were all treated as live code, so a one-word edit parked
    an assertion where checkwash still believed it ran — reopening bypass #29
    (reader audit 2026-08-02).

    A class attribute the class bodies resolve (`ClassValue`, #254) is
    compared with `None` by `is` and `is not`: `None` is one object in every
    interpreter, so these answers do not depend on interning, as `is` between
    other literals would. `None` itself and a class or a function
    (`CLASS_OBJECT`) are also read as truth values and by `==` and `!=`; an
    imported name is not, since what it holds is not in this file.
    """
    if isinstance(node, ClassValue):
        return {CLASS_NONE: False, CLASS_OBJECT: True}.get(node.kind)
    if (isinstance(node, ast.Compare) and len(node.ops) == 1
            and isinstance(node.ops[0], (ast.Is, ast.IsNot, ast.Eq, ast.NotEq))):
        left, right = node.left, node.comparators[0]
        value, other = (left, right) if isinstance(left, ClassValue) else (right, left)
        if isinstance(value, ClassValue) and isinstance(other, ast.Constant) and other.value is None:
            identity = isinstance(node.ops[0], (ast.Is, ast.IsNot))
            if identity or value.kind in (CLASS_NONE, CLASS_OBJECT):
                is_none = value.kind == CLASS_NONE
                return is_none if isinstance(node.ops[0], (ast.Is, ast.Eq)) else not is_none
            return None
    if _is_literal(node):
        return _truthy_literal(node)
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.Not):
        inner = _static_truth(node.operand)
        return None if inner is None else not inner
    if isinstance(node, ast.BoolOp):
        values = [_static_truth(v) for v in node.values]
        if isinstance(node.op, ast.And):
            if any(v is False for v in values):
                return False
            return True if all(v is True for v in values) else None
        if any(v is True for v in values):
            return True
        return False if all(v is False for v in values) else None
    if (
        isinstance(node, ast.Compare)
        and _is_literal(node.left)
        and all(_is_literal(c) for c in node.comparators)
    ):
        try:
            left = ast.literal_eval(node.left)
            for op, comparator in zip(node.ops, node.comparators):
                fn = _CMP_OPS.get(type(op))
                if fn is None:
                    return None
                right = ast.literal_eval(comparator)
                if not fn(left, right):  # type: ignore[operator]
                    return False
                left = right
            return True
        except (ValueError, SyntaxError, TypeError):
            return None
    return None


def _match_is_dead(stmt: ast.Match) -> bool:
    """A `match` on a literal where no case can possibly fire.

    Only the unambiguous shape is judged — literal subject, every case a
    guardless literal value, no wildcard. Anything else is left live.
    """
    if not _is_literal(stmt.subject):
        return False
    try:
        subject = ast.literal_eval(stmt.subject)
    except (ValueError, SyntaxError, TypeError):
        return False
    for case in stmt.cases:
        if case.guard is not None:
            return False
        pattern = case.pattern
        if isinstance(pattern, ast.MatchAs) and pattern.pattern is None:
            return False  # wildcard / capture: always matches
        if not isinstance(pattern, ast.MatchValue) or not _is_literal(pattern.value):
            return False
        try:
            if ast.literal_eval(pattern.value) == subject:
                return False
        except (ValueError, SyntaxError, TypeError):
            return False
    return True


def _truthy_literal(node: ast.AST) -> bool:
    try:
        return bool(ast.literal_eval(node))
    except (ValueError, SyntaxError, TypeError):
        return True


# A broad handler whose every oracle is proved to always pass (#496). D-015
# counted any oracle in a handler as inspection, so adding `assert True` to an
# `except Exception:` turned row 16's block back into a clean pass. Ruling 496
# (R49 to R51): only a proof moves a handler, and it is a narrow one, apart
# from `_static_truth`. That folder answers True where a pass proof must not:
# `_truthy_literal` on a `literal_eval` failure (`assert -"a"` raises), and an
# `or` with one True operand (`assert check() or True` runs `check()` first).
# The proof answers "proved to pass" or nothing; anything else keeps the
# handler inspection, as on main.

# The evidence text of such a handler is its first line, a space and this
# suffix (R50). `_norm` leaves no space in any other handler's text, so the two
# never compare equal and main's set of texts is unchanged.
_ALWAYS_PASSING = " [always-passing assertion]"

_UNPROVED = object()

# The unittest methods the proof reads (R49), each with the predicate its
# operands' values pass (`Lib/unittest/case.py`). `assertEqual` on two values
# of one type dispatches to a type-specific method, and each of unittest's
# own passes when `==` holds; `_REACHED` names them.
_PROVED_UNITTEST = {
    "assertTrue": lambda expr: bool(expr),
    "assertFalse": lambda expr: not expr,
    "assertIsNone": lambda obj: obj is None,
    "assertIsNotNone": lambda obj: obj is not None,
    "assertEqual": lambda first, second: first == second,
    "assertNotEqual": lambda first, second: first != second,
}

# The names a passing call looks up on its receiver (`Lib/unittest/case.py`,
# CPython 3.11 to 3.14). `assertEqual` asks `_getAssertEqualityFunc`, which
# returns `_baseAssertEqual` or, for two values of one type, the method
# registered for that type by name and found with `getattr` on the receiver
# (`assertDictEqual`, `assertListEqual`, `assertTupleEqual`,
# `assertSetEqual`, `assertMultiLineEqual`); those call `assertSequenceEqual`
# and `assertIsInstance`. A same-file class can bind any of them, so
# condition two reads each as it reads the called name. The other five
# methods look up nothing else when they pass.
_REACHED = {
    "assertEqual": frozenset({
        "assertEqual", "_getAssertEqualityFunc", "_baseAssertEqual", "assertDictEqual", "assertListEqual",
        "assertTupleEqual", "assertSetEqual", "assertMultiLineEqual", "assertSequenceEqual", "assertIsInstance",
    }),
}

# Names a same-file class of the order must not bind, as for a helper method
# (#306, `self_methods.Methods._resolve`): each lets the class answer a lookup
# on, or a store into, the receiver with something its body does not say.
_RECEIVER_HOOKS = frozenset({"__getattribute__", "__init_subclass__", "__setattr__"})


def _proved_literal(node: ast.AST):
    """A literal's value, or `_UNPROVED` when `literal_eval` refuses it (`-"a"`, `{[1]: 2}`)."""
    if not _is_literal(node):
        return _UNPROVED
    try:
        return ast.literal_eval(node)
    except Exception:  # ValueError, TypeError, SyntaxError, RecursionError, MemoryError
        return _UNPROVED


def _holds_bytes(node: ast.AST) -> bool:
    """Comparing bytes with str or int warns under `python -b` and raises under `-bb`."""
    return any(isinstance(sub, ast.Constant) and isinstance(sub.value, bytes) for sub in ast.walk(node))


def _proved_comparison(node: ast.Compare):
    """A comparison between literals, every link evaluated, or `_UNPROVED`.

    `is` and `is not` only with None on one side: None is one object in every
    interpreter, so the answer does not depend on interning (R49).
    """
    operands = [node.left, *node.comparators]
    values = [_proved_literal(operand) for operand in operands]
    if any(value is _UNPROVED for value in values) or any(_holds_bytes(operand) for operand in operands):
        return _UNPROVED
    outcome = True
    for op, left, right in zip(node.ops, values, values[1:]):
        if isinstance(op, (ast.Is, ast.IsNot)):
            if left is not None and right is not None:
                return _UNPROVED
            result = (left is right) == isinstance(op, ast.Is)
        else:
            compare = _CMP_OPS.get(type(op))
            if compare is None:
                return _UNPROVED
            try:
                result = bool(compare(left, right))  # type: ignore[operator]
            except Exception:
                return _UNPROVED
        outcome = outcome and result
    return outcome


def _proved_value(node: ast.AST):
    """The value of an `assert` test the narrow proof evaluates (R49), or `_UNPROVED`.

    A literal; `not` before a literal; a comparison between literals; and
    `and` or `or` over these. Every operand of `and` and `or` is evaluated
    on its own, so a short circuit never hides one that raises or calls.
    """
    if _is_literal(node):
        return _proved_literal(node)
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.Not):
        value = _proved_literal(node.operand)
        return _UNPROVED if value is _UNPROVED else not value
    if isinstance(node, ast.Compare):
        return _proved_comparison(node)
    if isinstance(node, ast.BoolOp):
        values = [_proved_value(value) for value in node.values]
        if any(value is _UNPROVED for value in values):
            return _UNPROVED
        # Python's own result: `or` stops at the first truthy operand, `and`
        # at the first falsy one, and otherwise gives the last.
        stops_on = isinstance(node.op, ast.Or)
        return next((value for value in values[:-1] if bool(value) == stops_on), values[-1])
    return _UNPROVED


def _proved_unittest_call(call: ast.Call, testcase) -> bool:
    """`<receiver>.<method>(...)` with literal operands that pass (R49).

    Condition one: the call passes the method's operands and at most one
    `msg`, by position or by keyword, and nothing else; any other argument
    list raises TypeError. The operands are bound by `_unittest_operands`.
    Unlike an `assert` message, `msg` is evaluated before the call, so it
    must be a literal that `literal_eval` reads. Condition two, that the
    receiver is the TestCase running the method, is `testcase(call)`.
    """
    func = call.func
    if not (isinstance(func, ast.Attribute) and isinstance(func.value, ast.Name)):
        return False
    predicate = _PROVED_UNITTEST.get(func.attr)
    if predicate is None:
        return False
    names = _UNITTEST_OPERANDS[func.attr]
    params = (*names, "msg")
    if len(call.args) > len(params) or any(isinstance(arg, ast.Starred) for arg in call.args):
        return False
    given = list(params[:len(call.args)])
    for keyword in call.keywords:
        # A `**` argument has no name, so it is not in `params` either.
        if keyword.arg not in params or keyword.arg in given:
            return False
        given.append(keyword.arg)
    if not set(names) <= set(given):
        return False
    message = (call.args[len(names)] if len(call.args) > len(names)
               else next((keyword.value for keyword in call.keywords if keyword.arg == "msg"), None))
    if message is not None and _proved_literal(message) is _UNPROVED:
        return False
    operands = (_unittest_operands(func.attr, call) or [])[:len(names)]
    values = [_proved_literal(operand) for operand in operands]
    if len(values) != len(names) or any(value is _UNPROVED for value in values):
        return False
    if len(names) == 2 and any(_holds_bytes(operand) for operand in operands):
        return False
    try:
        if not predicate(*values):
            return False
    except Exception:
        return False
    return testcase(call)


_SCOPES = (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef, ast.Lambda)


def _raises_in(handler: ast.ExceptHandler) -> bool:
    return any(isinstance(sub, ast.Raise) for stmt in handler.body for sub in ast.walk(stmt))


def _proved_to_pass(handler: ast.ExceptHandler, testcase) -> bool:
    """Is every oracle in this handler proved to always pass (R49, condition three)?

    It walks the handler as `_contains_oracle` does, except that it does not
    enter an assertion's message, and every oracle it meets must be proved.
    An `assert` passes when its test is proved truthy; its message runs
    only when it fails, so the message is not read. One oracle the proof
    cannot read keeps the handler inspection, as 431.Q2 ruled for `assert
    str(e) == "y"`, `assert False`, `self.fail()`, `pytest.fail()` and
    `assert e == e`. Reachability is not read (R66): an oracle under
    `if False:` is read as any other.
    """
    stack: list[ast.AST] = list(handler.body)
    while stack:
        node = stack.pop()
        if isinstance(node, ast.Assert):
            value = _proved_value(node.test)
            if value is _UNPROVED or not value:
                return False
            continue
        if _is_oracle_call(node):
            if not _proved_unittest_call(node, testcase):
                return False
            continue
        stack.extend(child for child in ast.iter_child_nodes(node) if not isinstance(child, _SCOPES))
    return True


def _handler_methods(tree: ast.Module) -> dict[int, tuple[ast.ClassDef, ast.AST]]:
    """id(handler) -> (class, method) for each handler that a method of a
    top-level class runs itself, outside any nested def, lambda or class."""
    found: dict[int, tuple[ast.ClassDef, ast.AST]] = {}
    for cls in tree.body:
        if not isinstance(cls, ast.ClassDef):
            continue
        for function in cls.body:
            if not isinstance(function, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            stack: list[ast.AST] = [node for node in function.body if not isinstance(node, _SCOPES)]
            while stack:
                node = stack.pop()
                if isinstance(node, ast.ExceptHandler):
                    found[id(node)] = (cls, function)
                stack.extend(child for child in ast.iter_child_nodes(node) if not isinstance(child, _SCOPES))
    return found


def _testcase_method(call: ast.Call, cls: ast.ClassDef, function, methods: Methods, raw: str) -> bool:
    """Is `call` the unittest method of the TestCase running `function` (R49, condition two)?

    The receiver is the method's first positional parameter, which it never
    rebinds, and the method is neither a staticmethod nor a classmethod. In
    the class's local order (`Methods.order`), no same-file class binds the
    method's name, and the first base the file does not define is spelled
    with a name ending in `TestCase`: a class with no such base, as a
    same-file mixin, may be collected by pytest, and there the call raises
    AttributeError; and a base from another module that comes first may
    define the name itself. As for a helper method (#306), the name is
    unproved when the module stores it, stores an item into a `__dict__`,
    sets a computed name on the receiver or on a class of the order, or a
    class of the order binds `__getattribute__`, `__init_subclass__` or
    `__setattr__` (`_RECEIVER_HOOKS`). `assertEqual` is read the same way
    for every name it reaches (`_REACHED`), and is unproved when the module
    registers a type-equality function.
    """
    if any(isinstance(d, ast.Name) and d.id in ("staticmethod", "classmethod") for d in function.decorator_list):
        return False
    name = call.func.value.id  # type: ignore[attr-defined]
    attr = call.func.attr  # type: ignore[attr-defined]
    reached = _REACHED.get(attr, frozenset({attr}))
    if (name != receiver(function) or not reached.isdisjoint(methods.stored) or methods.dict_store
            or name in methods.computed):
        return False
    if attr == "assertEqual" and ("addTypeEqualityFunc" in raw or "_type_equality_funcs" in raw):
        return False
    order = methods.order(cls)
    if order is None:
        return False
    local = [entry for entry in order if not isinstance(entry, tuple)]
    if any(entry.name in methods.computed or not _RECEIVER_HOOKS.isdisjoint(methods.binds(entry)) for entry in local):
        return False
    spelled = {ast.dump(base): _dotted(base) or "" for entry in local for base in entry.bases}
    for entry in order:
        if isinstance(entry, tuple):
            return spelled.get(entry[1], "").rsplit(".", 1)[-1].endswith("TestCase")
        if not reached.isdisjoint(methods.binds(entry)):
            return False
    return False


def _param_row_disabled(node: ast.AST) -> bool:
    """`pytest.param(..., marks=pytest.mark.skip)` — a row that no longer runs.

    Marker names are matched on their trailing components, so an aliased
    `import pytest as p` cannot dodge it. `xfail` counts as disabled only when
    it is strict=False (the default), because a non-strict xfail turns a
    failure into a pass. A skipif condition counts only when a closed literal
    proves it true; unresolved environment conditions do not become blanket
    skips merely because this reader cannot evaluate them.
    """
    if not isinstance(node, ast.Call) or (_dotted(node.func) or "").rsplit(".", 1)[-1] != "param":
        return False
    for kw in node.keywords:
        if kw.arg != "marks":
            continue
        marks = kw.value.elts if isinstance(kw.value, (ast.List, ast.Tuple)) else [kw.value]
        for mark in marks:
            target = mark.func if isinstance(mark, ast.Call) else mark
            name = _dotted(target) or ""
            leaf = name.rsplit(".", 1)[-1]
            if leaf == "skip":
                return True
            if leaf == "skipif" and _literal_skipif_true(mark):
                return True
            if leaf == "xfail" and not _xfail_is_strict(mark):
                return True
    return False


def _literal_skipif_true(mark: ast.AST) -> bool:
    """Prove an unconditional row skip without evaluating repository code.

    Pytest treats a string condition as an expression, not as a truthy string.
    Interpret only literal expressions in that string, once. Multiple
    positional conditions are alternatives; a condition keyword takes their
    place. Name lookups, calls and arbitrary comparisons remain unknown.
    """
    if not isinstance(mark, ast.Call):
        return False
    conditions = list(mark.args)
    for keyword in mark.keywords:
        if keyword.arg == "condition":
            conditions = [keyword.value]
            break
    for condition in conditions:
        if isinstance(condition, ast.Starred):
            continue
        if isinstance(condition, ast.Constant) and isinstance(condition.value, str):
            condition = condition.value
        try:
            if bool(ast.literal_eval(condition)):
                return True
        except (ValueError, SyntaxError, TypeError, MemoryError, RecursionError):
            continue
    return False


def _xfail_is_strict(mark: ast.AST) -> bool:
    if not isinstance(mark, ast.Call):
        return False
    for kw in mark.keywords:
        if kw.arg == "strict":
            return bool(isinstance(kw.value, ast.Constant) and kw.value.value)
    return False


_PARAMETRIZE = ("pytest.mark.parametrize", "mark.parametrize", "parametrize")


def _param_cell_value(cell):
    """The value inside a parametrize cell, seen through `pytest.param`.

    `[1, 2, 3]` becoming `[pytest.param(1, marks=pytest.mark.skip), ...]` keeps
    every value and every row, and disables the lot. That is `TEST_DISABLED`'s
    event and it is already reported at high; reading the wrapper as part of
    the value made this rule fire on it as well, which is two findings for one
    edit.
    """
    if isinstance(cell, ast.Call) and _dotted(cell.func) in ("pytest.param", "param") and cell.args:
        return cell.args[0]
    return cell


def _param_argnames(dec: ast.Call) -> list[str] | None:
    """The argnames a `parametrize` decorator binds, or None if unreadable.

    Stricter than `_param_columns`' inline reading on purpose: a list of
    argnames with a non-string element is unreadable here, not partially
    read, because a table whose width is uncertain cannot say which row is
    which.
    """
    names_node = dec.args[0]
    if isinstance(names_node, ast.Constant) and isinstance(names_node.value, str):
        return [n.strip() for n in names_node.value.split(",") if n.strip()]
    if isinstance(names_node, (ast.List, ast.Tuple)):
        if not all(isinstance(e, ast.Constant) and isinstance(e.value, str) for e in names_node.elts):
            return None
        return [e.value for e in names_node.elts]
    return None


def _param_row_cells(names: list[str], row: ast.AST) -> list[ast.AST] | None:
    """The cell nodes of one parametrize row, or None if the row is unreadable.

    `pytest.param(a, b, marks=...)` spells the row as call arguments, one per
    argname -- not as a tuple, and not as `_param_cell_value`'s single value
    (that helper answers the one-cell question). Reading only `args[0]` would
    drop every cell after the first, which is how `_param_columns` loses the
    expectation of a wrapped row (F-067) and would drop every marked
    multi-argument row here -- exactly the row F-063 is about.

    A single argname takes the whole value as its one cell, tuple or not,
    which is what pytest does. A row of the wrong width, or one with a
    starred element, is unreadable: the first is a collection error, the
    second a table whose rows this reader cannot enumerate.
    """
    if isinstance(row, ast.Call) and (_dotted(row.func) or "").rsplit(".", 1)[-1] == "param":
        cells = list(row.args)
    elif len(names) > 1 and isinstance(row, (ast.List, ast.Tuple)):
        cells = list(row.elts)
    else:
        cells = [row]
    if len(cells) != len(names) or any(isinstance(c, ast.Starred) for c in cells):
        return None
    return cells


def _param_tables(func) -> tuple[ParamTable, ...]:
    """One `ParamTable` per `parametrize` decorator, or `()` if any is unreadable.

    `_param_columns` flattens the table into one string per argname and
    `_param_case_count` flattens it into a number; the two facts a *row*
    carries survive neither. Which expectation belongs to which input is
    gone from the column string (F-060); which rows are the *same* rows is
    gone from the count, so skip-marking one row while appending another
    nets to zero (F-063). This keeps the rows, per decorator, with the
    disabling mark recorded beside the row rather than inside its text.

    The decorators considered are exactly the ones `_param_case_count`
    counts (a literal list of values), and the answer is all-or-nothing:
    if one of them cannot be read row by row, the unit has no tables. A
    consumer that read the other decorators would be pairing rows against
    a live count that includes the unreadable one.
    """
    tables: list[ParamTable] = []
    for dec in func.decorator_list:
        if not isinstance(dec, ast.Call) or _dotted(dec.func) not in _PARAMETRIZE:
            continue
        if len(dec.args) < 2 or not isinstance(dec.args[1], (ast.List, ast.Tuple)):
            continue
        names = _param_argnames(dec)
        if not names:
            return ()
        rows: list[tuple[str, ...]] = []
        disabled: list[bool] = []
        for row in dec.args[1].elts:
            cells = _param_row_cells(names, row)
            if cells is None:
                return ()
            try:
                rows.append(tuple(ast.unparse(cell) for cell in cells))
            except (AttributeError, ValueError):  # pragma: no cover - defensive
                return ()
            disabled.append(_param_row_disabled(row))
        tables.append(ParamTable(tuple(names), tuple(rows), tuple(disabled)))
    return tuple(tables)


def _param_columns(func) -> dict[str, str]:
    """parametrize argname -> canonical text of that column, row by row.

    The expectation of a parametrized test does not live in the test at all; it
    lives in a column of the decorator's table. Editing that column moves the
    oracle while the assertion stays byte-identical, which is the same shape as
    editing a local binding (THREATMODEL 86a) one level out.

    Only argnames are recorded here. Which of them is the *expectation* is not
    decided by position or by being called `expected` — it is whichever column
    the assertion's expectation side actually consumes, which the detector
    reads off `right_depends_on`. Changing the input column is not changing the
    oracle, and a heuristic on the name would get that wrong.
    """
    out: dict[str, list[str]] = {}
    for dec in func.decorator_list:
        if not isinstance(dec, ast.Call) or _dotted(dec.func) not in _PARAMETRIZE:
            continue
        if len(dec.args) < 2 or not isinstance(dec.args[1], (ast.List, ast.Tuple)):
            continue
        names_node = dec.args[0]
        if isinstance(names_node, ast.Constant) and isinstance(names_node.value, str):
            names = [n.strip() for n in names_node.value.split(",") if n.strip()]
        elif isinstance(names_node, (ast.List, ast.Tuple)):
            names = [
                e.value for e in names_node.elts
                if isinstance(e, ast.Constant) and isinstance(e.value, str)
            ]
        else:
            continue
        for row in dec.args[1].elts:
            cells = row.elts if isinstance(row, (ast.List, ast.Tuple)) else [row]
            if len(names) == 1 and not isinstance(row, (ast.List, ast.Tuple)):
                cells = [row]
            for name, cell in zip(names, cells):
                try:
                    out.setdefault(name, []).append(ast.unparse(_param_cell_value(cell)))
                except (AttributeError, ValueError):  # pragma: no cover - defensive
                    out.setdefault(name, []).append("")
    return {name: "".join(vals) for name, vals in sorted(out.items())}


def _fixture_definitions(tree: ast.Module) -> dict[str, str]:
    """Same-file `@pytest.fixture` name -> canonical text of what it produces.

    A fixture is not a collected unit, so nothing in the IR saw its body. An
    expectation supplied by one could be edited with the assertion untouched
    and every rule silent. Conftest fixtures are deliberately out of scope and
    recorded as a residual rather than half-implemented.
    """
    out: dict[str, str] = {}
    for node in tree.body:
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        if not any(
            _dotted(d.func if isinstance(d, ast.Call) else d) in ("pytest.fixture", "fixture")
            for d in node.decorator_list
        ):
            continue
        produced = []
        for sub in ast.walk(node):
            if isinstance(sub, (ast.Return, ast.Yield)) and sub.value is not None:
                try:
                    produced.append(ast.unparse(sub.value))
                except (AttributeError, ValueError):  # pragma: no cover - defensive
                    produced.append("")
        if produced:
            out[node.name] = "|".join(produced)
    return dict(sorted(out.items()))


def _param_case_count(func: ast.FunctionDef | ast.AsyncFunctionDef) -> int | None:
    """pytest test-item count contributed by @pytest.mark.parametrize rows.

    Deleting rows deletes test items; in pytest's model each row IS a test
    unit, so the count belongs in the IR (confirmed red-team finding).
    """
    total: int | None = None
    for dec in func.decorator_list:
        if not isinstance(dec, ast.Call):
            continue
        if _dotted(dec.func) not in ("pytest.mark.parametrize", "mark.parametrize", "parametrize"):
            continue
        if len(dec.args) < 2 or not isinstance(dec.args[1], (ast.List, ast.Tuple)):
            continue
        # A row is a test item only if it still runs. Counting `len(elts)`
        # meant wrapping every row in `pytest.param(..., marks=pytest.mark.skip)`
        # left the count unchanged while the whole parametrized test stopped
        # executing — deleting the same rows blocked, skipping them did not
        # (reader audit 2026-08-02).
        rows = sum(0 if _param_row_disabled(e) else 1 for e in dec.args[1].elts)
        total = rows if total is None else total * rows
    return total


_STMT_BODY_FIELDS = ("body", "orelse", "finalbody")


def _skip_call_guards(func: ast.FunctionDef | ast.AsyncFunctionDef, text) -> dict[int, str]:
    """id(call or raise node) -> conjunction of enclosing `if` condition sources.

    `if PY_3_14_PLUS and not slots: pytest.xfail(...)` is the imperative
    spelling of `skipif(PY_3_14_PLUS and not slots)`; without the guard, D6
    cannot tell it from an unconditional kill (attrs 7373d88, FP sweep).
    Orelse branches contribute the negated test. Loop/try/with/match bodies
    pass conditions through without adding their own: an unrecorded conjunct
    only makes the real skip *more* conditional, so a recorded guard that is
    false somewhere means the real condition is false there too, and one that
    is not earns nothing — both err toward flagging.
    """
    out: dict[int, str] = {}

    def record(stmts: list[ast.stmt], conds: tuple[str, ...]) -> None:
        for stmt in stmts:
            if isinstance(stmt, ast.If):
                t = text.seg(stmt.test) or ""
                record(stmt.body, conds + ((t,) if t else ()))
                record(stmt.orelse, conds + ((f"not ({t})",) if t else ()))
                continue
            compound = False
            for fname in _STMT_BODY_FIELDS:
                sub = getattr(stmt, fname, None)
                if isinstance(sub, list) and any(isinstance(s, ast.stmt) for s in sub):
                    compound = True
                    record([s for s in sub if isinstance(s, ast.stmt)], conds)
            for handler in getattr(stmt, "handlers", None) or []:
                compound = True
                record(handler.body, conds)
            for case in getattr(stmt, "cases", None) or []:
                compound = True
                record(case.body, conds)
            if not compound and conds:
                for node in ast.walk(stmt):
                    if isinstance(node, (ast.Call, ast.Raise)):
                        out[id(node)] = " and ".join(conds)

    record(func.body, ())
    return out


_SCOPE_NODES = (ast.FunctionDef, ast.AsyncFunctionDef, ast.Lambda, ast.ClassDef)
# Callees that invoke a function argument immediately. `partial` is deliberately
# absent: it *constructs*, and the call happens when the partial itself is
# called — which is exactly the edit that turns `job()` into
# `assert callable(job)` (benchmarks/tamper 036).
_INVOKES_ARGUMENT = frozenset({"map", "filter", "apply", "run", "testmod", "exec"})
_DEFERS_ARGUMENT = frozenset({"partial"})


def _scope_nodes(scope):
    """Nodes this scope executes, without descending into nested scopes.

    Nested scopes come back separately, and only when something invokes them.
    """
    stack = list(ast.iter_child_nodes(scope))
    while stack:
        node = stack.pop()
        if isinstance(node, _SCOPE_NODES):
            continue
        yield node
        stack.extend(ast.iter_child_nodes(node))


def _scope_nodes_cached(scope, cache: dict[int, tuple] | None):
    """`_scope_nodes`, memoised per scope for one file's parse.

    A module helper invoked by many units used to be re-walked once per unit
    per consumer — the single largest share of the perf gate's budget after
    the reaching round pushed the slowest CI leg over it.
    """
    if cache is None:
        return _scope_nodes(scope)
    key = id(scope)
    got = cache.get(key)
    if got is None:
        got = tuple(_scope_nodes(scope))
        cache[key] = got
    return got


def _invocations(scope, caches: tuple[dict, dict] | None = None) -> set[str]:
    """Names this scope actually *invokes*.

    Mention is not invocation, and the distinction is the whole design:
    `callable(assert_sum)`, `hasattr`, `inspect.getsource(f)` and `f.__name__`
    all name the oracle without running it, which is precisely the edit these
    attacks make. Counting a bare `Name` argument as a call hides
    benchmarks/tamper 001.

    `caches` is one file's `(scope-nodes, invocations)` memo pair: shared
    module scopes are asked the same question by every unit that reaches
    them, and the answer never changes within a parse.
    """
    nodes_cache = inv_cache = None
    if caches is not None:
        nodes_cache, inv_cache = caches
        hit = inv_cache.get(id(scope))
        if hit is not None:
            return set(hit)
    out: set[str] = set()
    for node in _scope_nodes_cached(scope, nodes_cache):
        if isinstance(node, (ast.With, ast.AsyncWith)):
            for item in node.items:
                name = _callee_root(item.context_expr)
                if name:
                    out.add(name)
        elif isinstance(node, ast.For):
            name = _callee_root(node.iter)
            if name:
                out.add(name)
        elif isinstance(node, ast.Call):
            name = _callee_root(node)
            if not name:
                continue
            out.add(name)
            if name.split(".")[-1] in _INVOKES_ARGUMENT:
                out.update(a.id for a in node.args if isinstance(a, ast.Name))
    if inv_cache is not None:
        inv_cache[id(scope)] = frozenset(out)
    return out


def _callee_root(node) -> str | None:
    if not isinstance(node, ast.Call):
        return None
    f = node.func
    while isinstance(f, ast.Attribute):
        f = f.value
    return f.id if isinstance(f, ast.Name) else None


def _is_contextmanager(node) -> bool:
    return isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and any(
        (isinstance(d, ast.Name) and d.id == "contextmanager")
        or (isinstance(d, ast.Attribute) and d.attr == "contextmanager")
        for d in node.decorator_list
    )


def _local_scopes(func, module_scopes: dict[str, ast.AST]) -> dict[str, ast.AST]:
    """Callable names visible to this unit: the module's, plus its own nested
    defs and lambdas, plus names bound to a deferred call (`partial`)."""
    out = dict(module_scopes)
    for node in _walk(func):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node is not func:
            out[node.name] = node
        elif isinstance(node, ast.Assign):
            for target in node.targets:
                if not isinstance(target, ast.Name):
                    continue
                if isinstance(node.value, ast.Lambda):
                    out[target.id] = node.value
                elif isinstance(node.value, ast.Call):
                    callee = _callee_root(node.value)
                    if callee and callee.split(".")[-1] in _DEFERS_ARGUMENT:
                        for arg in node.value.args:
                            if isinstance(arg, ast.Name) and arg.id in out:
                                out[target.id] = out[arg.id]
                                break
    return out


def _executed_scopes(
    func,
    module_scopes: dict[str, ast.AST],
    max_depth: int = 4,
    caches: tuple[dict, dict] | None = None,
    roots: tuple[str, ...] | None = None,
    local_scopes: dict[str, ast.AST] | None = None,
) -> list:
    """The unit, plus every same-file scope it actually reaches.

    This is what makes `UnitSide.assertions` mean *the assertions this test
    runs* rather than *the assert statements written inside it*. Both halves
    matter: an assertion in an uninvoked nested `def` stops counting, and an
    assertion in a helper the unit calls starts.

    With `roots`, the walk starts from those invocation names instead of
    everything the unit invokes: the closure reachable through one entry
    site. The union over a unit's entry roots equals the default walk —
    per-root depth is counted from the root exactly as the default counts
    it from the frontier.
    """
    scopes = local_scopes if local_scopes is not None else _local_scopes(func, module_scopes)
    with_entered = None
    out = [func]
    seen: set[int] = {id(func)}
    frontier = [
        (name, 0) for name in (_invocations(func, caches) if roots is None else roots)
    ]
    while frontier:
        name, depth = frontier.pop()
        target = scopes.get(name)
        if target is None or depth >= max_depth or id(target) in seen:
            continue
        # A @contextmanager runs its body only when entered: building the
        # generator and never using `with` runs nothing (tamper 004).
        if _is_contextmanager(target):
            if with_entered is None:
                with_entered = {
                    _callee_root(item.context_expr)
                    for node in _scope_nodes_cached(func, caches[0] if caches is not None else None)
                    if isinstance(node, (ast.With, ast.AsyncWith))
                    for item in node.items
                }
            if name not in with_entered:
                continue
        seen.add(id(target))
        out.append(target)
        if isinstance(target, ast.ClassDef):
            for child in target.body:
                if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    seen.add(id(child))
                    out.append(child)
                    frontier.extend((c, depth + 1) for c in _invocations(child, caches))
        frontier.extend((c, depth + 1) for c in _invocations(target, caches))
    return out


def _helper_entry_sites(func, nodes_cache) -> list[tuple[ast.AST, str]]:
    """(position node, invocation name) for every unit-level entry into a
    same-file helper, in source order.

    Mirrors `_invocations` node for node — a plain call, a `with` item's
    context expression, a `for` iterator, and a bare-`Name` argument to an
    `_INVOKES_ARGUMENT` call — but keeps *where* each entry happens instead
    of collapsing to a name set. The position node is what the inherited
    assertions' reaching keys are computed at: that is when the helper's
    oracle executes relative to the unit's own bindings (issue #55).
    """
    sites: list[tuple[ast.AST, str]] = []
    for node in _scope_nodes_cached(func, nodes_cache):
        if isinstance(node, (ast.With, ast.AsyncWith)):
            for item in node.items:
                name = _callee_root(item.context_expr)
                if name:
                    sites.append((item.context_expr, name))
        elif isinstance(node, ast.For):
            name = _callee_root(node.iter)
            if name:
                sites.append((node.iter, name))
        elif isinstance(node, ast.Call):
            name = _callee_root(node)
            if not name:
                continue
            sites.append((node, name))
            if name.split(".")[-1] in _INVOKES_ARGUMENT:
                sites.extend((node, a.id) for a in node.args if isinstance(a, ast.Name))
    sites.sort(key=lambda s: (s[0].lineno, s[0].col_offset))
    return sites


def _vacuous_bound_asserts(func: ast.AST) -> set[int]:
    """Ids of `assert data == <literal>` where `data` was bound to the same
    literal earlier in the same statement list and nothing between touches it.

    The subject is a bare Name, so `_is_trivial_subject` calls it state — yet
    straight-line locally the assertion cannot fail. That spelling counted as
    full oracle mass for D4/D5 and excused a deleted failing test through
    RESTRUCTURED: the bare-dialect member of the padding family (rows
    20/25/46), reproduced as a silent pass in the 2026-08-19 audit.

    Deliberately narrow: same statement list only (an outer binding is
    invisible to an inner block, failing toward real, not vacuous), both
    operand orders accepted, and ANY mention of the name between binding and
    assert disqualifies — `data = [1, 2, 3]; process(data);
    assert data == [1, 2, 3]` is a genuine oracle over `process`, not
    padding.
    """
    out: set[int] = set()

    def _nameless(node: ast.AST) -> bool:
        return not any(isinstance(n, ast.Name) for n in ast.walk(node))

    for holder in _walk(func):
        body = getattr(holder, "body", None)
        if not isinstance(body, list):
            continue
        bound: dict[str, ast.expr] = {}
        for stmt in body:
            if (
                isinstance(stmt, ast.Assign)
                and len(stmt.targets) == 1
                and isinstance(stmt.targets[0], ast.Name)
                and _nameless(stmt.value)
            ):
                bound[stmt.targets[0].id] = stmt.value
                continue
            # Without an earlier candidate binding there is nothing to match
            # or invalidate; scanning this assertion cannot add a vacuity id.
            if not bound:
                continue
            if isinstance(stmt, ast.Assert) and id(stmt) not in out:
                t = stmt.test
                if (
                    isinstance(t, ast.Compare)
                    and len(t.ops) == 1
                    and isinstance(t.ops[0], ast.Eq)
                    and t.comparators
                ):
                    pair = None
                    if isinstance(t.left, ast.Name) and _nameless(t.comparators[0]):
                        pair = (t.left, t.comparators[0])
                    elif isinstance(t.comparators[0], ast.Name) and _nameless(t.left):
                        pair = (t.comparators[0], t.left)
                    if pair is not None:
                        subject, expect = pair
                        hit = bound.get(subject.id)
                        if hit is not None and ast.dump(hit) == ast.dump(expect):
                            out.add(id(stmt))
            mentions = {n.id for n in ast.walk(stmt) if isinstance(n, ast.Name)}
            for name in list(bound):
                if name in mentions:
                    del bound[name]
    return out


class _Instance:
    """Calls through the instance of one class running a test (#306).

    `methods` builds the module's resolution (`self_methods.Methods`) the
    first time a call needs it: most units only call TestCase's own
    methods through `self`, and those are never followed.
    """

    def __init__(self, methods, running: ast.ClassDef) -> None:
        self._methods = methods
        self.running = running
        self._receivers: dict[int, str | None] = {}

    def receiver(self, scope) -> str | None:
        if id(scope) not in self._receivers:
            method = isinstance(scope, (ast.FunctionDef, ast.AsyncFunctionDef))
            self._receivers[id(scope)] = receiver(scope) if method else None
        return self._receivers[id(scope)]

    def resolve(self, scope, node):
        """(method, the class defining it) a call in `scope` through its instance runs, or None."""
        if not (isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
                and isinstance(node.func.value, ast.Name) and node.func.attr not in TESTCASE_NAMES):
            return None
        name = self.receiver(scope)
        if name is None or node.func.value.id != name:
            return None
        return self._methods().resolve(self.running, node.func.attr, name)

    def follow(self, scope, node):
        found = self.resolve(scope, node)
        return found[0] if found is not None else None

    def closure(self, method, module_scopes, caches, max_depth: int = 4) -> list:
        """`method` and every scope it reaches: the helpers it calls by plain name,
        as `_executed_scopes` follows them, and the methods it calls through its
        own instance, at most `max_depth` calls from the test."""
        out: list = []
        seen: set[int] = set()
        frontier = [(method, 0)]
        nodes_cache = caches[0] if caches is not None else None
        while frontier:
            scope, depth = frontier.pop(0)
            if id(scope) in seen or depth >= max_depth:
                continue
            seen.add(id(scope))
            out.append(scope)
            for reached in _executed_scopes(scope, module_scopes, max_depth=max_depth - 1 - depth, caches=caches)[1:]:
                if id(reached) not in seen:
                    seen.add(id(reached))
                    out.append(reached)
            for call, _name in instance_calls(_scope_nodes_cached(scope, nodes_cache), self.receiver(scope)):
                found = self.resolve(scope, call)
                if found is not None:
                    frontier.append((found[0], depth + 1))
        return out


def _helper_marker(helper, effect, evidence, guard, text, off, origins) -> Marker:
    """The `helper.<function>.<effect>` marker for an outcome a unit reaches through a helper (#272).

    An outcome in another module (`Foreign`) keeps that file's text and span,
    and `origins` records the file, as a conftest fixture's outcome is
    recorded (#223), so a report locates it there.
    """
    if isinstance(evidence, Foreign):
        marker = Marker(name=f"helper.{helper}.{effect}", text=evidence.text or helper, span=evidence.span, guard=guard)
        if origins is not None:
            origins[(marker.name, marker.span, marker.text)] = evidence.path
        return marker
    return Marker(name=f"helper.{helper}.{effect}", text=text.seg(evidence) or helper, span=off.span(evidence),
                  guard=guard)


def _collect_unit(
    func: ast.FunctionDef | ast.AsyncFunctionDef,
    qualname: str,
    text: str,
    off: _Offsets,
    inherited_markers: list[Marker] | None = None,
    module_scopes: dict[str, ast.AST] | None = None,
    caches: tuple[dict, dict] | None = None,
    fixtures: dict[str, ast.Constant] | None = None,
    doctests: list[Assertion] | None = None,
    aliases: dict[str, list[ast.expr]] | None = None,
    outcome_bindings: dict[str, str | None] | None = None,
    method: bool = False,
    outcome_roots: frozenset[str] = frozenset(),
    attrs=None,
    helpers: HelperOutcomes | None = None,
    origins: dict | None = None,
    instance: _Instance | None = None,
    resolved: dict | None = None,
    producers: tuple[tuple[str, str, tuple[str, ...]], ...] = (),
) -> ParsedUnit:
    """`instance`: the class running a method unit, for the helper methods it
    reaches through `self` (#306); `resolved` collects each one it follows,
    by its class-qualified name. `producers`: the fixtures the unit requests
    by parameter whose producer was read (`fixture_producers`, #471), whose
    parameters an assertion records reading (`Assertion.fixture_reads`)."""
    assertions: list[Assertion] = []
    calls: set[str] = set()
    patches: set[tuple[str, str]] = set()
    markers = _decorator_markers(func, text, off, aliases) + list(inherited_markers or [])
    handlers: list[Handler] = []
    counter = 0
    # A body skip is read through the module's import bindings, shadowed by
    # the function's own, which are worked out only for a call or raise whose
    # root can spell one (#220).
    module_names = outcome_bindings or {}
    roots = _OUTCOME_ROOTS | outcome_roots | {name for name, target in module_names.items() if target}
    positional = [*func.args.posonlyargs, *func.args.args]
    if method and positional:
        # The instance, whatever it is called, spells `self.skipTest`.
        roots = roots | {positional[0].arg}
    local_names: dict[str, str | None] | None = None

    def outcome_of(node: ast.Call | ast.Raise) -> str | None:
        nonlocal local_names
        target = node.func if isinstance(node, ast.Call) else node.exc
        if isinstance(target, ast.Call):
            target = target.func
        name = _dotted(target) if target is not None else None
        if not name or name.partition(".")[0] not in roots:
            return None
        if local_names is None:
            local_names = body_bindings(func, module_names, method=method)
        return body_outcome(node, local_names)

    dead = _unreachable_ids(func, fixtures, lambda stmt: outcome_of(stmt) is not None, attrs)
    guards = _skip_call_guards(func, text)
    receiver_names: frozenset[str] | None = None
    _unparse_memo: dict[int, str] = {}
    _refs_memo: dict[int, tuple[str, ...]] = {}
    _flags: dict[str, bool] = {}
    definition_bindings, bindings = _binding_maps(
        func, unparse_memo=_unparse_memo, refs_memo=_refs_memo, flags=_flags
    )
    ordered_bindings = (
        _ordered_bindings(
            func,
            unparse_memo=_unparse_memo,
            refs_memo=_refs_memo,
            has_walrus=_flags.get("walrus", False),
        )
        if definition_bindings
        else {}
    )
    vacuous = _vacuous_bound_asserts(func)

    # The parameters naming a fixture whose producer was read (#471), the
    # nodes inside the unit's nested scopes, whose names may be another
    # scope's, and the unit's assignments as `fixture_reads` follows them:
    # worked out only for a unit that has such a parameter.
    fixture_params = frozenset(param for param, _callee, _modules in producers)
    nested_nodes: set[int] | None = None
    rebound: frozenset[str] = frozenset()
    followed: dict[str, tuple[str, ...]] = {}

    def fixture_reads(node: ast.AST, expression: ast.AST) -> tuple[str, ...]:
        """The fixture parameters assertion `node` of the unit's own body reads in `expression` (471 Q3).

        Directly, or through the unit's own assignments (`_resolve_through`):
        not one made inside a nested def, class or lambda, and less the names
        an assigned value binds in a lambda or comprehension of its own
        (`_fixture_read_bindings`, D-155 reading 3). A parameter the body binds
        again holds another value there, and is not counted: one the binding
        map records (`=`, augmented, annotated or walrus), and one bound any
        other way in the unit's own scope (`_fixture_binders`: a `for` or
        comprehension target, `with ... as`, `except ... as`, `del`, an
        import, `global` or `nonlocal`, a match capture, a nested def or class
        of that name). A name inside a lambda or a comprehension of the
        assertion that binds it is not read, nor followed (`assertion_names`);
        a parameter all of whose occurrences there are such names is not
        counted, even when a name the assertion reads leads to it, which errs
        toward no evidence.
        """
        nonlocal nested_nodes, rebound, followed
        if not fixture_params:
            return ()
        if nested_nodes is None:
            nested_nodes = {
                id(inner)
                for scope in _walk(func)
                if scope is not func
                and isinstance(scope, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef, ast.Lambda))
                for inner in ast.walk(scope)
            }
            rebound = frozenset(param for param in fixture_params if _fixture_binders(func, param))
            followed = _fixture_read_bindings(func, nested_nodes, _refs_memo)
        if id(node) in nested_nodes:
            return ()
        read, shadowed = assertion_names(expression)
        return tuple(sorted(
            name for name in _resolve_through(tuple(sorted(read)), followed)
            if name in fixture_params and name not in bindings and name not in rebound and name not in shadowed
        ))

    # Markers, handlers, calls and patches stay keyed to the unit's own body: a
    # helper's assertions are this unit's oracle, a helper's `except` is not
    # this unit's handler. Only the assertion set follows reachability.
    nodes_cache = caches[0] if caches is not None else None
    # The callable map is stable for this unit; reuse it for the initial walk
    # and each helper entry instead of rediscovering the same nested scopes.
    local_scopes = _local_scopes(func, module_scopes or {})
    executed = _executed_scopes(func, module_scopes or {}, caches=caches, local_scopes=local_scopes)
    reached_asserts = {
        id(n)
        for scope in executed
        for n in _scope_nodes_cached(scope, nodes_cache)
        if isinstance(n, ast.Assert)
    }
    # Asserts collected by this walk, so the executed-scopes pass below does
    # not add them a second time: an invoked *nested* def is both lexically
    # inside `func` (this walk sees it) and an executed scope (that loop sees
    # it), and double-counting an oracle invents an assertion to "remove".
    own_assert_ids: set[int] = set()
    # Calls by a plain name to something the unit can reach in this file, or
    # to a name a top-level `from M import f` binds: a helper whose run ends
    # in a skip skips this unit too (#272).
    helper_calls: list[ast.Call] = []
    # Calls through the instance that run, for the helper methods they reach (#306).
    method_calls: list[ast.Call] = []
    # The subject a bare local name stands for (#434), worked out per unit
    # only once an assertion checks a name the unit binds.
    plain_names: frozenset[str] | None = None
    own_scope: frozenset[int] | None = None

    def resolved_subject(node: ast.AST, left: str | None) -> tuple[str, str] | None:
        nonlocal plain_names, own_scope
        if not left or not left.isidentifier() or left not in ordered_bindings:
            return None
        if plain_names is None:
            plain_names = _plain_names(func, ordered_bindings)
            own_scope = frozenset(map(id, _scope_nodes_cached(func, nodes_cache)))
        if left not in plain_names or id(node) not in own_scope:
            return None
        return _resolved_subject(node, left, ordered_bindings)

    for node in _walk(func):
        if id(node) in dead:
            continue
        if (
            helpers is not None
            and isinstance(node, ast.Call)
            and isinstance(node.func, ast.Name)
            and (node.func.id in local_scopes
                 or helpers.imported is not None and node.func.id in helpers.imported)
        ):
            helper_calls.append(node)
        if instance is not None and isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
            method_calls.append(node)
        # A native skip or xfail, called or raised (`raise unittest.SkipTest`
        # is the same act as `pytest.skip()`), read through the bindings (#220).
        if isinstance(node, (ast.Call, ast.Raise)):
            skip = outcome_of(node)
            if skip is not None:
                seg = text.seg(node) or skip
                guard = guards.get(id(node))
                if guard is not None and attrs is not None:
                    # A guard that holds under the class's attributes is
                    # no condition: the skip reads as unconditional, as
                    # a setup callback's does (#254).
                    if receiver_names is None:
                        receiver_names = receivers(func)
                    parsed = parse_expr(guard)
                    if parsed is not None and _static_truth(substitute(parsed, attrs, receiver_names)) is True:
                        guard = None
                markers.append(Marker(name=skip, text=seg, span=off.span(node), guard=guard))
        # An assert written inside a nested `def` that nothing calls is present
        # in the source and absent from the run. Counting it as live is what
        # let `verify()` be defined and never invoked (tamper 020) — and it is
        # older than that attack.
        if isinstance(node, ast.Assert) and id(node) not in reached_asserts:
            continue
        if isinstance(node, ast.Assert):
            own_assert_ids.add(id(node))
            c = _classify_assert(node, text)
            seg = text.seg(node) or ""
            depends = _resolve_through(c.right_names, bindings)
            direct = set(c.left_names) | set(c.right_names)
            reach = _reaching_keys(
                node,
                _positional_closure(node, c.left_names + c.right_names, ordered_bindings),
                ordered_bindings,
            )
            assertions.append(
                Assertion(
                    id=f"a{counter}",
                    form=c.form,
                    strength=c.strength,
                    text=seg,
                    span=off.span(node),
                    left=c.left,
                    right_literal=c.right_literal,
                    right_value=c.right_value,
                    epsilon=c.epsilon,
                    epsilon_kind=c.epsilon_kind,
                    predicate=c.predicate,
                    operand_source=c.operand_source,
                    unevaluated_expected=c.unevaluated_expected,
                    unbound_operands=c.unbound_operands,
                    # A tolerance call (#222) judges its two values, as
                    # `assertTrue(<call>)` and `assertAlmostEqual` do.
                    trivial=_is_trivial_subject(node.test) or c.trivial or id(node) in vacuous,
                    positive=c.positive,
                    left_names=c.left_names,
                    right_depends_on=depends,
                    reaching=reach,
                    reaching_sig=_reaching_sig(reach, direct),
                    resolved_subject=resolved_subject(node, c.left),
                    fixture_reads=fixture_reads(node, node.test) if fixture_params else (),
                )
            )
            counter += 1
        elif isinstance(node, ast.Call):
            name = _dotted(node.func)
            if name:
                calls.add(name)
                calls.add(name.rsplit(".", 1)[-1])
                # Folded into this walk rather than given its own: a second
                # full `ast.walk` per unit put the 500-file budget over by
                # 0.18 s, and the dotted name is already computed here.
                # Unreachable code is skipped above, which is right — a patch
                # that never executes installs nothing.
                pair = _patch_call_target(node, name, func, text)
                if pair is not None:
                    patches.add(pair)
                if name in ("pytest.raises", "pytest.warns", "raises"):
                    # `pytest.raises(E, match=...)` IS an oracle: triage found
                    # human commits folding an excinfo substring assert into
                    # match= and getting blocked for "removing" it.
                    match_kw = next((kw for kw in node.keywords if kw.arg == "match"), None)
                    seg = text.seg(node) or name
                    assertions.append(
                        Assertion(
                            id=f"a{counter}",
                            form="pattern" if match_kw is not None else "raises",
                            strength=S.PATTERN if match_kw is not None else None,
                            text=seg,
                            span=off.span(node),
                            right_literal=(
                                _literal_repr(match_kw.value, text) if match_kw is not None else None
                            ),
                        )
                    )
                    counter += 1
            c = _classify_unittest_call(node, text) or _tolerance_statement_classified(node, text)
            if c is not None:
                seg = text.seg(node) or ""
                depends = _resolve_through(c.right_names, bindings)
                direct = set(c.left_names) | set(c.right_names)
                reach = _reaching_keys(
                    node,
                    _positional_closure(
                        node, c.left_names + c.right_names, ordered_bindings
                    ),
                    ordered_bindings,
                )
                assertions.append(
                    Assertion(
                        id=f"a{counter}",
                        form=c.form,
                        strength=c.strength,
                        text=seg,
                        span=off.span(node),
                        left=c.left,
                        right_literal=c.right_literal,
                        right_value=c.right_value,
                        epsilon=c.epsilon,
                        epsilon_kind=c.epsilon_kind,
                        predicate=c.predicate,
                        operand_source=c.operand_source,
                        unevaluated_expected=c.unevaluated_expected,
                        unbound_operands=c.unbound_operands,
                        positive=c.positive,
                        left_names=c.left_names,
                        right_depends_on=depends,
                        trivial=c.trivial,
                        reaching=reach,
                        reaching_sig=_reaching_sig(reach, direct),
                        resolved_subject=resolved_subject(node, c.left),
                        fixture_reads=fixture_reads(node, node) if fixture_params else (),
                    )
                )
                counter += 1
        elif isinstance(node, ast.ExceptHandler):
            caught, is_broad = _handler_info(node)
            seg = text.seg(node) or ""
            handlers.append(
                Handler(caught=caught, is_broad=is_broad, text=seg.split("\n")[0], span=off.span(node))
            )

    if helper_calls:
        for helper, effect, evidence, guard in helpers.reached(
            func, module_names, helper_calls, method=method, local_scopes=local_scopes
        ):
            markers.append(_helper_marker(helper, effect, evidence, guard, text, off, origins))
    # A skip a helper method the unit calls through its instance ends in, read
    # under the running class's attributes (#306 Q1, Sub-Q5).
    if helpers is not None and method_calls:
        for helper, effect, evidence, guard in helpers.method_calls(
            func, module_names, id(instance.running), attrs=attrs, follow=instance.follow, calls=method_calls
        ):
            markers.append(_helper_marker(helper, effect, evidence, guard, text, off, origins))

    # The other half: assertions the unit runs that are not written inside it.
    # `assert_sum(add(2, 3), 5)` is a *call*, so without this the unit records
    # zero assertions, nothing can be removed or weakened, and a replacement
    # `assert callable(assert_sum)` reads as an assertion *added* — by the
    # strength lattice the test got stronger (THREATMODEL 91).
    #
    # Inherited once per unit-level entry site, not once per helper: each
    # copy carries the reaching keys of its own call's position, so a pure
    # insertion of one more case leaves every other site's copy identical
    # (issue #55, sympy aa1b43c3 — the R1 residual), while rebinding a
    # forwarded name between its honest definition and the call still
    # changes what that site's copy reads. The span stays the helper-side
    # assert — one edited helper line keeps collapsing to one finding
    # downstream — so a site's copies differ by `reaching_sig` alone, and
    # deleting one of N calls surfaces as a removed assertion instead of
    # vanishing into a same-size set.
    root_closures: dict[str, list] = {}
    inherited_rows: dict[int, list] = {}

    def rows_of(scope) -> list:
        rows = inherited_rows.get(id(scope))
        if rows is None:
            rows = []
            for node in _scope_nodes_cached(scope, nodes_cache):
                if isinstance(node, ast.Assert):
                    if id(node) in own_assert_ids:
                        continue
                    c = _classify_assert(node, text)
                    trivial = _is_trivial_subject(node.test) or c.trivial or id(node) in vacuous
                elif isinstance(node, ast.Call):
                    c = _classify_unittest_call(node, text) or _tolerance_statement_classified(node, text)
                    if c is None:
                        continue
                    trivial = c.trivial
                else:
                    continue
                rows.append((node, c, trivial))
            inherited_rows[id(scope)] = rows
        return rows

    def inherit(site_node, scope, via=None) -> None:
        nonlocal counter
        for node, c, trivial in rows_of(scope):
            seg = text.seg(node) or ""
            direct = set(c.left_names) | set(c.right_names)
            reach = _reaching_keys(
                site_node,
                _positional_closure(
                    site_node, c.left_names + c.right_names, ordered_bindings
                ),
                ordered_bindings,
            )
            assertions.append(
                Assertion(
                    id=f"a{counter}",
                    form=c.form,
                    strength=c.strength,
                    text=seg,
                    span=off.span(node),
                    left=c.left,
                    right_literal=c.right_literal,
                    right_value=c.right_value,
                    epsilon=c.epsilon,
                    epsilon_kind=c.epsilon_kind,
                    predicate=c.predicate,
                    operand_source=c.operand_source,
                    unevaluated_expected=c.unevaluated_expected,
                    unbound_operands=c.unbound_operands,
                    trivial=trivial,
                    positive=c.positive,
                    left_names=c.left_names,
                    right_depends_on=c.right_names,
                    inherited=True,
                    reaching=reach,
                    reaching_sig=_reaching_sig(reach, direct),
                    via=via,
                )
            )
            counter += 1

    for site_node, root in _helper_entry_sites(func, nodes_cache):
        if id(site_node) in dead or root not in local_scopes:
            continue
        closure = root_closures.get(root)
        if closure is None:
            closure = _executed_scopes(func, module_scopes or {}, caches=caches,
                                       roots=(root,), local_scopes=local_scopes)
            root_closures[root] = closure
        for scope in closure:
            if scope is func:
                continue
            inherit(site_node, scope)

    # A helper method reached through the instance (#306): followed as a
    # module helper is, once per entry site, and its assertions carry the
    # method's class-qualified name as `via` (306 Sub-Q11).
    if instance is not None:
        method_closures: dict[int, list] = {}
        for site_node in sorted(method_calls, key=lambda node: (node.lineno, node.col_offset)):
            found = instance.resolve(func, site_node)
            if found is None:
                continue
            target, owner = found
            via = f"{owner.name}.{target.name}"
            if resolved is not None:
                resolved[via] = target
            closure = method_closures.get(id(target))
            if closure is None:
                closure = instance.closure(target, module_scopes or {}, caches)
                method_closures[id(target)] = closure
            for scope in closure:
                if scope is not func:
                    inherit(site_node, scope, via)

    assertions.extend(checked_examples(func, doctests or [], dead))
    body = text.seg(func) or ""
    body_hash = hashlib.sha256(normalize_text(body).encode("utf-8")).hexdigest() if body else ""

    assertions.sort(key=lambda a: a.span)
    for i, a in enumerate(assertions):
        a.id = f"a{i}"

    side = UnitSide(
        span=off.span(func),
        assertions=assertions,
        calls=tuple(sorted(calls)),
        markers=sorted(markers, key=lambda m: m.span),
        handlers=sorted(handlers, key=lambda h: h.span),
        param_cases=_param_case_count(func),
        body_hash=body_hash,
        bindings=definition_bindings,
        # Exclusivity can only matter for a multiply-bound name. Most test
        # units bind each local once, so avoid another full statement walk
        # when the definition map already proves the result must be empty.
        exclusive_bindings=(
            _exclusive_bindings(func)
            if any("" in key for key in definition_bindings.values())
            else ()
        ),
        param_columns=_param_columns(func),
        param_rows=_param_tables(func),
        patches=tuple(sorted(patches)),
        invoked=tuple(sorted(_invocations(func, caches))),
        params=tuple(
            a.arg
            for a in (func.args.posonlyargs + func.args.args + func.args.kwonlyargs)
            if a.arg not in ("self", "cls")
        ),
        fixture_producers=producers,
    )
    return ParsedUnit(qualname=qualname, span=side.span, side=side, shingles=_shingles(func))


def _collection_controls(tree: ast.Module, text) -> list[tuple[ast.AST, str | None]]:
    """(statement, enclosing-`if` conjunction) for everything that puts a path
    into `collect_ignore`.

    Only the assignment form used to count, so the idiomatic spelling — set an
    empty list, then `extend` it, which is how attrs writes it — dropped whole
    test files silently (bypass 70). An *empty* assignment is an initialiser
    and not a control: recording it would make attrs' honest version gate look
    like an unconditional kill.
    """
    found: list[tuple[ast.AST, str | None]] = []

    def control(stmt: ast.stmt) -> ast.AST | None:
        def _targets_control(target) -> bool:
            # `collect_ignore[:] = [...]` and `collect_ignore[0] = ...` are
            # Subscript, not Name, so the whole slice form was invisible
            # (THREATMODEL 83).
            if isinstance(target, ast.Subscript):
                target = target.value
            return isinstance(target, ast.Name) and target.id in _CONFTEST_NAMES

        if isinstance(stmt, ast.Assign) and any(_targets_control(t) for t in stmt.targets):
            value = stmt.value
            if isinstance(value, (ast.List, ast.Tuple, ast.Set)) and not value.elts:
                return None
            return stmt
        if isinstance(stmt, ast.AugAssign) and _targets_control(stmt.target):
            return stmt
        if isinstance(stmt, ast.Expr) and isinstance(stmt.value, ast.Call):
            head, _, attr = (_dotted(stmt.value.func) or "").rpartition(".")
            if head in _CONFTEST_NAMES and attr in ("extend", "append", "insert"):
                return stmt
        return None

    def record(stmts: list[ast.stmt], conds: tuple[str, ...]) -> None:
        for stmt in stmts:
            if isinstance(stmt, ast.If):
                t = text.seg(stmt.test) or ""
                record(stmt.body, conds + ((t,) if t else ()))
                record(stmt.orelse, conds + ((f"not ({t})",) if t else ()))
                continue
            node = control(stmt)
            if node is not None:
                found.append((node, " and ".join(conds) if conds else None))
            for fname in _STMT_BODY_FIELDS:
                sub = getattr(stmt, fname, None)
                if isinstance(sub, list) and any(isinstance(s, ast.stmt) for s in sub):
                    record([s for s in sub if isinstance(s, ast.stmt)], conds)
            # `except ImportError: collect_ignore.append(...)` is what every
            # project with an optional dependency writes, and handlers were not
            # walked at all: an `ExceptHandler` is not an `ast.stmt`, so the
            # loop above skipped the whole list (THREATMODEL 83).
            #
            # Walking them without reading the exception as a guard would have
            # turned that idiom into a false positive. The exception type *is*
            # the condition, so it is recorded as one and the compat-gate logic
            # treats it as the gate it is.
            for handler in getattr(stmt, "handlers", []) or []:
                if not isinstance(handler, ast.ExceptHandler):
                    continue
                record(
                    [s for s in handler.body if isinstance(s, ast.stmt)],
                    conds + (_handler_guard(stmt, handler),),
                )

    record(tree.body, ())
    return found


_IMPORT_ERRORS = frozenset({"ImportError", "ModuleNotFoundError"})


def _handler_guard(try_stmt, handler: ast.ExceptHandler) -> str:
    """The condition an `except` block actually expresses.

    `try: import redis / except ImportError: collect_ignore.append(...)` is the
    optional-dependency gate every such project writes, and its condition is
    exactly "redis is not installed". Recorded as `find_spec("redis") is None`,
    which is the spelling the compat-gate logic already recognises and the one
    an adversarial audit cited when this build blocked a PR that *added* the
    tests it was guarding.

    Anything else — a bare `except`, a different exception, a try body that is
    not a plain import — records the exception text, which does not parse as a
    condition and therefore earns no credit. That is deliberate: an
    unconditional control hidden inside a `try` should still fire.
    """
    caught = _dotted(handler.type) if handler.type is not None else None
    body = [s for s in getattr(try_stmt, "body", []) if isinstance(s, ast.stmt)]
    if caught in _IMPORT_ERRORS and body and all(
        isinstance(s, (ast.Import, ast.ImportFrom)) for s in body
    ):
        first = body[0]
        module = (
            first.names[0].name
            if isinstance(first, ast.Import) and first.names
            else (first.module or "")
        )
        if module:
            return f'find_spec("{module}") is None'
    return f"except {caught}" if caught else "except"


def _ignored_paths(controls) -> tuple[str, ...]:
    """Every literal path these controls put into `collect_ignore`, sorted.

    Markers deduplicate by name, so a conftest that *already had* a control
    produced no event at all when a second one was appended — an entire test
    file left collection in silence (THREATMODEL 81). Comparing the resolved
    set of paths rather than the marker's name is what makes the second control
    an event.

    Non-literal entries are simply absent: a path this cannot resolve is not
    evidence in either direction.
    """
    out: set[str] = set()
    for node, _guard in controls:
        for sub in ast.walk(node):
            if isinstance(sub, ast.Constant) and isinstance(sub.value, str):
                out.add(sub.value)
    return tuple(sorted(out))


def _conftest_unit(tree: ast.Module, text: str, off: _Offsets) -> ParsedUnit:
    """Suite-level controls in a conftest, collection and runtime alike, as one
    synthetic unit. `conftest_controls` tells their kinds apart."""
    markers: list[Marker] = _pytestmark_markers(tree.body, text, off, _mark_aliases(tree.body))

    for name, node in runtime_controls(tree):
        markers.append(Marker(name=name, text=text.seg(node) or name, span=off.span(node)))

    controls = _collection_controls(tree, text)
    ignored: tuple[str, ...] = _ignored_paths(controls)
    if controls:
        node, _ = controls[0]
        guards = [g for _, g in controls]
        # The weakest guard wins. Markers are deduplicated by name, so without
        # this one honest version gate would have covered any number of
        # unconditional drops sharing the name (bypass 71). A disjunction is
        # the true reading anyway: the files are ignored if *any* branch fires.
        combined = (
            None
            if any(g is None for g in guards)
            else " or ".join(f"({g})" for g in guards)
        )
        seg = (text.seg(node) or "conftest.collect_ignore").split("\n")[0]
        markers.append(
            Marker(name="conftest.collect_ignore", text=seg, span=off.span(node), guard=combined)
        )

    # A collection hook, and an `add_marker` skip in one, carries the condition
    # its effects fire under (#209 Q1, `hook_guards`). Several controls under
    # one name keep the weakest guard, as `collect_ignore` does above: the
    # markers deduplicate by name. A hook with no effect that can drop or
    # disable an item is not a control (#209 Q2).
    hook_guards, marker_guards = collection_hook_guards(
        tree, lambda node: text.seg(node) or ast.unparse(node)
    )
    found: list[tuple[str, ast.AST, str | None]] = []
    for node in ast.walk(tree):
        name = guard = None
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name in _CONFTEST_HOOKS:
            if id(node) in hook_guards:
                name = f"conftest.{node.name}"
                guard = hook_guards[id(node)]
        elif isinstance(node, ast.Call) and (_dotted(node.func) or "").endswith("add_marker"):
            arg = _dotted(node.args[0].func) if node.args and isinstance(node.args[0], ast.Call) else (
                _dotted(node.args[0]) if node.args else None
            )
            if arg in _SKIP_DECORATORS:
                name = "conftest.add_marker_skip"
                guard = marker_guards.get(id(node))
        if name is not None:
            found.append((name, node, guard))
    combined: dict[str, list[str | None]] = {}
    for name, _node, guard in found:
        combined.setdefault(name, []).append(guard)
    for name, node, _guard in found:
        seg = (text.seg(node) or name).split("\n")[0]
        markers.append(Marker(name=name, text=seg, span=off.span(node), guard=weakest(combined[name])))

    seen: set[str] = set()
    unique = []
    for m in sorted(markers, key=lambda m: m.span):
        if m.name in seen:
            continue
        seen.add(m.name)
        unique.append(m)
    side = UnitSide(span=(0, len(text.text)), markers=unique, collect_ignored=ignored)
    return ParsedUnit(qualname="<suite>", span=side.span, side=side, shingles=frozenset())


def _shingles(func: ast.AST, k: int = 5) -> frozenset[tuple[str, ...]]:
    """k-shingles over the AST node-kind token sequence (SPEC §7)."""
    tokens: list[str] = []
    for node in _walk(func):
        kind = type(node).__name__
        if isinstance(node, ast.Name):
            kind += ":" + node.id
        elif isinstance(node, ast.Attribute):
            kind += ":" + node.attr
        tokens.append(kind)
    if len(tokens) < k:
        return frozenset({tuple(tokens)})
    return frozenset(tuple(tokens[i : i + k]) for i in range(len(tokens) - k + 1))


def _strip_docstrings(tree: ast.AST) -> ast.AST:
    # Only a module, a def or a class holds a docstring, and none of them can
    # sit inside an expression, so expressions are not walked (#344).
    todo = [tree]
    while todo:
        node = todo.pop()
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            body = node.body
            if (
                body
                and isinstance(body[0], ast.Expr)
                and isinstance(body[0].value, ast.Constant)
                and isinstance(body[0].value.value, str)
            ):
                node.body = body[1:] or [ast.Pass()]
        todo.extend(child for child in ast.iter_child_nodes(node) if not isinstance(child, ast.expr))
    return tree


def _normalize_for_fingerprint(tree: ast.AST) -> ast.AST:
    """Strip what cannot change behaviour, so a cosmetic edit does not flip a
    symbol's fingerprint and buy repair evidence (audit 2026-08-19).

    `def f(x) -> float:` with an added return annotation, a non-leading string
    statement after the docstring, `x: int` with no value, and
    `_checked = None` inside the function body all change `ast.dump` while
    changing nothing the code does — and an attacker controls both sides of
    the diff, so each was a one-line purchase of REPAIR_EVIDENCE for any
    oracle cheat (THREATMODEL row 4 reopened).

    Removed here: parameter/return annotations (function and lambda), string
    constants in non-leading statement position, value-less annotated
    assignments, the annotation of a value-carrying annotated assignment,
    and — **inside function bodies only** — an assignment of a literal to a
    name the function never reads. Module- and class-level constants are
    untouched: a constant the production file never reads may still be read
    by the tests (`TAX = 0.05` in billing.py), and dropping it would deny
    honest repair evidence. Functions containing `global`/`nonlocal` keep
    their assignments: a store can escape the scope without a load.

    Deliberately NOT normalised: alpha-renames. Deciding which names escape
    needs scope analysis checkwash does not have, and a wrong normalisation
    silently disables evidence for genuine rename-driven API changes — a
    documented residual, priced as such.
    """
    for node in ast.walk(tree):
        args: ast.arguments | None = None
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            node.returns = None
            args = node.args
        elif isinstance(node, ast.Lambda):
            args = node.args
        if args is not None:
            for arg in (
                *args.posonlyargs, *args.args, args.vararg,
                *args.kwonlyargs, args.kwarg,
            ):
                if arg is not None:
                    arg.annotation = None
        if isinstance(node, ast.AnnAssign) and node.annotation is not None:
            node.annotation = None
        if isinstance(node, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            kept: list[ast.stmt] = []
            for stmt in node.body:
                # Any string statement still standing is noise: leading
                # docstrings were stripped by the earlier pass, so a survivor
                # here was never a docstring (audit 2026-08-19).
                if (
                    isinstance(stmt, ast.Expr)
                    and isinstance(stmt.value, ast.Constant)
                    and isinstance(stmt.value.value, str)
                ):
                    continue
                if isinstance(stmt, ast.AnnAssign) and stmt.value is None:
                    continue  # `x: int` binds nothing
                kept.append(stmt)
            node.body = kept or [ast.Pass()]
    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        # The expensive checks (nested walks) run only when a drop candidate
        # exists, so files without dead literal bindings pay one cheap pass.
        if not any(
            isinstance(stmt, ast.Assign)
            and len(stmt.targets) == 1
            and isinstance(stmt.targets[0], ast.Name)
            and isinstance(stmt.value, ast.Constant)
            for stmt in node.body
        ):
            continue
        if any(
            isinstance(stmt, (ast.Global, ast.Nonlocal))
            for stmt in ast.walk(node)
        ):
            continue
        loads = {
            n.id
            for n in ast.walk(node)
            if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Load)
        }
        kept = []
        for stmt in node.body:
            if (
                isinstance(stmt, ast.Assign)
                and len(stmt.targets) == 1
                and isinstance(stmt.targets[0], ast.Name)
                and stmt.targets[0].id not in loads
                and isinstance(stmt.value, ast.Constant)
            ):
                continue  # a literal bound to a name this scope never reads
            kept.append(stmt)
        node.body = kept or [ast.Pass()]
    return tree


def _fingerprint(node: ast.AST) -> str:
    dump = _stable_dump(node)
    return hashlib.sha256(dump.encode("utf-8")).hexdigest()[:16]


def _is_test_name(name: str) -> bool:
    return name.startswith("test")


def _is_test_class(node: ast.ClassDef) -> bool:
    """pytest's default `python_classes = Test*`, **plus unittest subclasses**.

    Renaming `TestBilling` to `BillingTests` silently deletes every test in a
    plain class, so the `Test*` half stays (confirmed red-team finding).

    But `python_classes` does not gate unittest collection: pytest collects any
    `unittest.TestCase` subclass whatever it is called. This function used to
    take only the name and return `name.startswith("Test")`, so
    `class BillingTests(unittest.TestCase)` produced **zero units** and all
    nineteen detectors were inert on the file — `assertEqual(total, 105.0)`
    becoming `assertTrue(total > 0)` passed clean while pytest ran the test and
    the suite went from `1 failed` to `1 passed`. SPEC §2 asserted the opposite
    of pytest's real behaviour and the implementation was built on it
    (THREATMODEL 86, adversarial verification 2026-08-09).

    Base detection is syntactic and deliberately generous: anything whose base
    is spelled `TestCase`, or is an attribute access ending in `TestCase`
    (`unittest.TestCase`, `unittest.IsolatedAsyncioTestCase`, `django.test.TestCase`),
    counts. A project-local subclass used as a base (`class Foo(BaseTest)`) is
    not resolved — that is a residual, not a claim.
    """
    if node.name.startswith("Test"):
        return True
    for base in node.bases:
        dotted = _dotted(base)
        if dotted and dotted.split(".")[-1].endswith("TestCase"):
            return True
    return False


def _transitive_test_classes(tree: ast.Module) -> frozenset[str]:
    """Module-level class names that are test containers once same-file base
    chains are followed to a fixpoint.

    SPEC §2: every `unittest.TestCase` subclass is collected, whatever it is
    named. `_is_test_class` reads one hop of spelled bases, so routing
    TestCase through a same-file class — tornado's `abstract_base_test`
    refactor turned `class OverrideResolverTest(AsyncTestCase, _Mixin)` into
    `class OverrideResolverTest(_Mixin)` with `_Mixin(AsyncTestCase)` — made
    the subclass stop being a test container, and every lexical unit in it
    "disappeared" while its def was byte-identical on both sides (R1 phantom,
    tornado e6d3f49). Same-file bare-name bases only; a base imported from
    another module is still the documented residual.
    """
    classes = {n.name: n for n in tree.body if isinstance(n, ast.ClassDef)}
    test = {name for name, node in classes.items() if _is_test_class(node)}
    changed = True
    while changed:
        changed = False
        for name, node in classes.items():
            if name in test:
                continue
            for base in node.bases:
                if isinstance(base, ast.Name) and base.id in test:
                    test.add(name)
                    changed = True
                    break
    return frozenset(test)


def _callees(node: ast.AST) -> tuple[str, ...]:
    names: set[str] = set()
    for sub in ast.walk(node):
        if isinstance(sub, ast.Call):
            dotted = _dotted(sub.func)
            if dotted:
                names.add(dotted.rsplit(".", 1)[-1])
    return tuple(sorted(names))


def parse_python(
    data: bytes, collect_tests: bool, conftest: bool = False, chain: tuple[ConftestLevel, ...] = (),
    imported=None,
) -> ParsedFile:
    """`chain`: the conftest files above a test module, nearest first, whose
    fixtures its units can request (#223). `imported`: reads the module a
    top-level `from M import f` names, `(module, original) -> outcomes`, for
    what calling `f` ends in (#272, second stage). Only a test module reads
    either."""
    global _walks
    outer, _walks = _walks, None
    try:
        return _parse_python(data, collect_tests, conftest, chain, imported)
    finally:
        _walks = outer


def _parse_python(
    data: bytes, collect_tests: bool, conftest: bool, chain: tuple[ConftestLevel, ...], imported=None
) -> ParsedFile:
    global _walks
    raw = normalize_source(data)
    try:
        tree = parse_module(raw)
        if collect_tests and "if" in raw and ("assert" in raw or "raise" in raw and "AssertionError" in raw):
            tree = conditional_oracle_carriers(tree)
    except SyntaxError:
        return ParsedFile(parse_ok=False)
    except (RecursionError, ValueError, MemoryError):
        # Deeply nested expressions raise RecursionError, not SyntaxError.
        # Head-side content is attacker-controlled: degrade visibly instead
        # of crashing the process (confirmed red-team finding).
        return ParsedFile(parse_ok=False)

    # One parse, one in-place normalisation: symbol fingerprints are dumped
    # straight from subtrees instead of re-running unparse+parse per symbol,
    # and the fingerprint ignores what cannot change behaviour (annotations,
    # noise statements, dead literal bindings) so a cosmetic prod edit buys
    # no repair evidence. Test files never fingerprint symbols, so they skip
    # the pass entirely — collection semantics never see a mutated tree.
    text = off = _Offsets(raw)
    off.tree = tree
    doctests = module_examples(tree, off) if collect_tests and ">>>" in raw and "doctest" in raw else []
    _strip_docstrings(tree)
    if not collect_tests:
        _normalize_for_fingerprint(tree)
    # The tree is final from here on: each subtree's walk is read once (#344).
    _walks = {}
    units: list[ParsedUnit] = []
    symbols: dict[str, str] = {}
    symbol_calls: dict[str, tuple[str, ...]] = {}
    literals: set[str] = set()
    imports: list[str] = []

    # Symbol fingerprints exist to answer "did prod behaviour change?"; test
    # files never need them, and computing them dominated parse time.
    want_symbols = not collect_tests
    module_aliases = _mark_aliases(tree.body) if collect_tests else {}
    module_markers = (
        _pytestmark_markers(tree.body, text, off, module_aliases) + _module_skip_markers(tree, text, off)
        if collect_tests
        else []
    )
    # Callables a unit can reach without leaving the file. Computed once per
    # module, not per unit: a suite with 200 tests and 5 helpers would otherwise
    # rebuild the same map 200 times.
    module_scopes: dict[str, ast.AST] = {}
    test_class_names: frozenset[str] = frozenset()
    if collect_tests:
        for node in tree.body:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                module_scopes[node.name] = node
            elif isinstance(node, ast.Assign) and isinstance(node.value, ast.Lambda):
                for target in node.targets:
                    if isinstance(target, ast.Name):
                        module_scopes[target.id] = node.value
        test_class_names = _transitive_test_classes(tree)
    # One file's worth of scope-walk memoisation: (scope-nodes, invocations),
    # shared by every unit so a helper reached by many tests is walked once.
    file_caches: tuple[dict, dict] = ({}, {})
    branch_fixtures = literal_fixtures(tree) if collect_tests else {}
    # A unit's setup runs before its body: the fixtures it reaches and the
    # xunit setup pytest calls for it. An unconditional skip there disables
    # the unit as surely as a marker does, so it is recorded as one (issue
    # #172), and a guarded one in the test module is recorded with its guard,
    # like a skip in the body (#196 183.2). A conftest fixture the unit
    # reaches records its skip on the unit too (#223), a guarded one with its
    # guard closed over the conftest's names (#351); an unconditional one is
    # also judged suite-wide in `_conftest_unit`.
    setup_scopes: tuple[SetupScope, ...] = ()
    marker_origins: dict[tuple[str, tuple[int, int], str], str] = {}
    # What a test body's names resolve to at module level, for its skips (#220).
    body_names = module_bindings(tree, mutated=False) if collect_tests and not conftest else {}
    # Names a test can import inside itself, read when an import is indented.
    body_roots = frozenset(
        name
        for node in _walk(tree)
        if isinstance(node, (ast.Import, ast.ImportFrom))
        for name, _target in (_import_pairs(node) or ())
    ) if body_names and _NESTED_IMPORT.search(raw) else frozenset()

    def condition(node: ast.AST) -> str:
        return text.seg(node) or ast.unparse(node)

    # Same-file helpers a unit or its setup calls (#272), read only in a test
    # module that can spell a native outcome at all, and the functions it
    # imports by name from another module, read in that module (#272, second
    # stage).
    imported_helpers = (
        ImportedHelpers(imported_helper_names(tree), imported)
        if imported is not None and collect_tests and not conftest
        else None
    )
    if imported_helpers is not None and not imported_helpers.names:
        imported_helpers = None
    spells_outcome = any(token in raw for token in _SETUP_OUTCOME_TOKENS)
    helper_outcomes = (
        HelperOutcomes(module_scopes, condition, branch_fixtures, imported_helpers)
        if collect_tests and not conftest and (spells_outcome or imported_helpers is not None)
        else None
    )

    if collect_tests and not conftest and (
        spells_outcome
        or imported_helpers is not None
        or any(fixture[2] is not None for level in chain for fixture in level.fixtures.values())
    ):
        setup_scopes = (
            SetupScope(tree.body, module_bindings(tree), condition=condition, helpers=helper_outcomes),
        )
    class_setup: dict[tuple[int, int], SetupScope] = {}
    # The class attributes a guard reads through `self` (#254): only a test
    # module with a class has any.
    class_attrs = (
        ClassAttributes(tree)
        if collect_tests and not conftest and any(isinstance(node, ast.ClassDef) for node in tree.body)
        else None
    )

    def attrs_of(cls: ast.ClassDef | None):
        return class_attrs.env(cls) if class_attrs is not None and cls is not None else None

    # The module's resolution of calls through an instance (#306), built the
    # first time a unit calls a method TestCase does not define, and one view
    # of it per class running a test.
    methods_built: list[Methods] = []
    instances: dict[int, _Instance] = {}
    # Each helper method a unit follows, by its class-qualified name, whose
    # callees are repair evidence for its own assertions only (306 Sub-Q8).
    resolved_methods: dict[str, ast.AST] = {}

    def methods_of() -> Methods:
        if not methods_built:
            methods_built.append(Methods(tree))
        return methods_built[0]

    def instance_of(cls: ast.ClassDef | None) -> _Instance | None:
        if cls is None or not collect_tests or conftest:
            return None
        if id(cls) not in instances:
            instances[id(cls)] = _Instance(methods_of, cls)
        return instances[id(cls)]

    def nested_setup(
        scopes: tuple[SetupScope, ...], *classes: ast.ClassDef, instance: ast.ClassDef | None = None
    ) -> tuple[SetupScope, ...]:
        """`scopes` extended by these class bodies, innermost last.

        `instance` is the class whose instance runs the setup, when it is not
        the class that defines it: its class attributes are the ones a
        guard reads (#254), and its methods are the ones a setup callback's
        calls through `self` run (#306).
        """
        if not scopes:
            return scopes
        for cls in classes:
            owner = instance if instance is not None else cls
            key = (id(cls), id(owner))
            if key not in class_setup:
                running = instance_of(owner)
                class_setup[key] = SetupScope(
                    cls.body, scopes[0].bindings, in_class=True, marks=cls.decorator_list, bases=cls.bases,
                    condition=condition, attrs=attrs_of(owner), helpers=helper_outcomes,
                    methods=(id(owner), running.follow) if running is not None else None,
                )
            scopes = scopes + (class_setup[key],)
        return scopes

    # The producer of each fixture a unit requests by parameter (#471), read
    # from the module, the classes enclosing the unit and the conftest chain.
    # Only a unit that takes a parameter reads any, and each body is read
    # once per module.
    producer_scopes: dict[int, ProducerScope] = {}

    def fixture_producers(func, classes: tuple[ast.ClassDef, ...]) -> tuple:
        if not collect_tests or conftest:
            return ()
        args = func.args
        if not (args.posonlyargs or args.args or args.kwonlyargs):
            return ()
        module_scope = producer_scopes.get(id(tree))
        if module_scope is None:
            module_scope = producer_scopes[id(tree)] = ProducerScope(
                tree.body, module_bindings(tree), import_modules(tree))
        scopes = [module_scope]
        for cls in classes:
            scope = producer_scopes.get(id(cls))
            if scope is None:
                scope = producer_scopes[id(cls)] = ProducerScope(
                    cls.body, module_scope.bindings, module_scope.modules, in_class=True,
                    marks=cls.decorator_list, bases=cls.bases, keywords=cls.keywords,
                )
            scopes.append(scope)
        return unit_producers(scopes, func, method=bool(classes), chain=chain)

    own_marks: list[OwnMarks] = []

    def setup_markers(func, scopes: tuple[SetupScope, ...], classes: tuple[ast.ClassDef, ...] = ()) -> list[Marker]:
        """The setup outcomes this unit reaches, as markers.

        `classes` are the classes the unit is collected in, outermost first.
        A guard that reads the unit's own marks is read with them first
        (#358): a guarded outcome that never fires for this unit is no marker.
        """
        if not scopes:
            return []
        markers = []
        for provider, effect, evidence, guard, origin in setup_outcomes(
            scopes, func, method=len(scopes) > 1, chain=chain
        ):
            paths = getattr(guard, "paths", None)
            if paths and any(reads_marks(cond) for _effect, _evidence, conds in paths for cond in conds):
                if not own_marks:
                    own_marks.append(OwnMarks(tree, chain))
                # Parametrized items have test_name[id], and fixture params
                # can add that suffix too. The function name is not a
                # guaranteed keyword; enclosing class names still are.
                names = frozenset(cls.name for cls in classes)
                resolved = resolve_own_marks(paths, own_marks[0].of(func, classes), names)
                if resolved is None:
                    continue
                effect, evidence, guard = resolved
            guard = None if guard is None else str(guard)
            # A conftest's outcome carries its text and span in that file.
            seg, span = evidence if origin is not None else (text.seg(evidence), off.span(evidence))
            marker = Marker(name=f"setup.{provider}.{effect}", text=seg or provider, span=span, guard=guard)
            if origin is not None:
                marker_origins[(marker.name, marker.span, marker.text)] = origin
            markers.append(marker)
        # A helper the setup calls (#272), in this file or imported.
        for helper, effect, evidence, guard in setup_helper_outcomes(
            scopes, func, method=len(scopes) > 1, chain=chain
        ):
            markers.append(_helper_marker(helper, effect, evidence, guard, text, off, marker_origins))
        return markers

    class_aliases: dict[int, dict[str, list[ast.expr]]] = {}

    def aliases_of(cls: ast.ClassDef) -> dict[str, list[ast.expr]]:
        if id(cls) not in class_aliases:
            class_aliases[id(cls)] = _mark_aliases(cls.body, module_aliases)
        return class_aliases[id(cls)]

    def class_marks(cls: ast.ClassDef) -> list[Marker]:
        """A class's decorators and its body's `pytestmark` (#260 Q1)."""
        return _decorator_markers(cls, text, off, module_aliases) + _pytestmark_markers(
            cls.body, text, off, aliases_of(cls)
        )

    def credit_base(unit: ParsedUnit, func, cls: ast.ClassDef) -> ParsedUnit:
        """Ruling 254.Q2: an abstract base's test that a same-file subclass runs.

        The unit's only disabling markers are skips in its body or setup, and
        each one's guard holds under the class's own attributes. A same-file
        subclass that runs the test unchanged (`crediting_subclasses`), and
        under whose attributes neither the body nor the setup skips, runs it,
        so the base's unit keeps no marker and stays live. A marker that a
        subclass would share (a decorator, a class or module mark) leaves
        the unit as it is.
        """
        markers = unit.side.markers
        # A skip whose guard holds under the class's attributes is recorded
        # with no guard (`_collect_unit`, `setup_outcome`); one that still
        # has a guard may not hold on the base, and a decorator, class or
        # module mark (named for the mark, or `module.*`) is one a subclass
        # shares. A skip a helper ends in is admitted too, and read again
        # under each subclass (#306 Sub-Q5).
        if class_attrs is None or not markers or any(
            not (m.name in BODY_MARKERS or m.name.startswith(("setup.", "helper."))) or m.guard is not None
            for m in markers
        ):
            return unit
        helper_marked = any(m.name.startswith("helper.") for m in markers)
        # Every skip the body spells, called or raised, read as the unit
        # reads it (#220): one dead under the base's attributes may still run
        # under a subclass's.
        local = body_bindings(func, body_names, method=True)
        skips = {
            id(node) for node in _walk(func)
            if isinstance(node, (ast.Call, ast.Raise)) and body_outcome(node, local) is not None
        }
        for subclass in class_attrs.crediting_subclasses(cls, func.name):
            dead = _unreachable_ids(func, branch_fixtures, lambda stmt: id(stmt) in skips, attrs_of(subclass))
            if any(node not in dead for node in skips):
                continue
            if setup_markers(func, nested_setup(setup_scopes, cls, instance=subclass), (subclass,)):
                continue
            if helper_marked and helper_outcomes is not None:
                calls = [node for node in _walk(func) if isinstance(node, ast.Call) and id(node) not in dead]
                scopes_seen = _local_scopes(func, module_scopes)
                plain = [
                    node for node in calls
                    if isinstance(node.func, ast.Name)
                    and (node.func.id in scopes_seen
                         or helper_outcomes.imported is not None and node.func.id in helper_outcomes.imported)
                ]
                if plain and helper_outcomes.reached(func, body_names, plain, method=True, local_scopes=scopes_seen):
                    continue
                running = instance_of(subclass)
                if running is not None and helper_outcomes.method_calls(
                    func, body_names, id(subclass), attrs=attrs_of(subclass), follow=running.follow,
                    calls=[node for node in calls if isinstance(node.func, ast.Attribute)],
                ):
                    continue
            return ParsedUnit(
                qualname=unit.qualname, span=unit.span,
                side=replace(unit.side, markers=[]), shingles=unit.shingles,
            )
        return unit

    def visit(
        node: ast.AST,
        prefix: str,
        inherited: list[Marker],
        collectible: bool,
        scopes: tuple[SetupScope, ...] = (),
        aliases: dict[str, list[ast.expr]] | None = None,
        owner: ast.ClassDef | None = None,
        classes: tuple[ast.ClassDef, ...] = (),
    ) -> None:
        # Keep suspended child iterators so preorder and lexical contexts are
        # identical to recursive visitation, without consuming Python frames
        # for expression nodes that cannot themselves introduce a scope.
        frames: list[tuple[
            Iterator[ast.AST], str, list[Marker], bool,
            tuple[SetupScope, ...], dict[str, list[ast.expr]] | None,
            ast.ClassDef | None, tuple[ast.ClassDef, ...],
        ]] = [(ast.iter_child_nodes(node), prefix, inherited, collectible,
               scopes, aliases, owner, classes)]
        while frames:
            children, prefix, inherited, collectible, scopes, aliases, owner, classes = frames[-1]
            child = next(children, None)
            if child is None:
                frames.pop()
                continue
            if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)):
                qual = f"{prefix}{child.name}"
                if want_symbols:
                    symbols[qual] = _fingerprint(child)
                    symbol_calls[qual] = _callees(child)
                # pytest collects the last binding of a name (#424): a def a
                # later binding certainly replaces is no unit, and one it may
                # replace carries that binding as a marker. A def whose own
                # statement never runs is no unit either (#499).
                bound = rebound.get(id(child))
                if collect_tests and collectible and _is_test_name(child.name) and not (bound and bound.dropped):
                    unit = _collect_unit(
                        child, qual, text, off,
                        inherited + (bound.markers if bound else []) + setup_markers(child, scopes, classes),
                        module_scopes, file_caches, branch_fixtures, doctests, aliases,
                        outcome_bindings=body_names, method="." in qual, outcome_roots=body_roots,
                        attrs=attrs_of(owner), helpers=helper_outcomes, origins=marker_origins,
                        instance=instance_of(owner if owner is not None else classes[-1]) if classes else None,
                        resolved=resolved_methods,
                        producers=fixture_producers(child, classes),
                    )
                    units.append(credit_base(unit, child, owner) if owner is not None else unit)
                # Nested defs are never collected as pytest items.
                frames.append((ast.iter_child_nodes(child), qual + ".", inherited, False,
                               (), None, None, ()))
            elif isinstance(child, ast.ClassDef):
                qual = f"{prefix}{child.name}"
                if want_symbols:
                    symbols[qual] = _fingerprint(child)
                # Class-level skip decorators disable every test inside the
                # class — they must reach each unit (confirmed red-team FN).
                # So does a `pytestmark` in the class body, and only those
                # (#260 Q1).
                class_markers = class_marks(child) if collect_tests else []
                bound = rebound.get(id(child))
                if bound is not None:
                    class_markers = class_markers + bound.markers
                class_collectible = (
                    collectible
                    and (_is_test_class(child) or child.name in test_class_names)
                    and not _test_attr_disabled(child.body)
                    and not (bound and bound.dropped)
                )
                frames.append((
                    ast.iter_child_nodes(child),
                    qual + ".",
                    inherited + class_markers,
                    class_collectible,
                    nested_setup(scopes, child) if class_collectible else (),
                    aliases_of(child) if collect_tests else None,
                    child,
                    classes + (child,),
                ))
            elif want_symbols and isinstance(child, (ast.Assign, ast.AnnAssign)):
                # Module- and class-level constants are behaviour too. They
                # were not symbols, so changing `TIMEOUT = 30` to 60 produced
                # no repair evidence and every test updating its expectation
                # blocked at high.
                targets = child.targets if isinstance(child, ast.Assign) else [child.target]
                for target in targets:
                    if isinstance(target, ast.Name):
                        symbols[f"{prefix}{target.id}"] = _fingerprint(child)
            else:
                frames.append((ast.iter_child_nodes(child), prefix, inherited, collectible,
                               scopes, aliases, None, classes))

    # What later bindings of each name do to the defs and classes they rebind
    # (#424), and which defs and classes never run (#499): read once per test
    # module, before any unit is collected.
    rebound: dict[int, BindingStatus] = {}
    if collect_tests and not conftest:
        rebound = final_bindings(
            tree,
            _BindingReader(
                condition=condition,
                truth=_static_truth,
                handler_guard=_handler_guard,
                match_dead=_match_is_dead,
                never_iterates=lambda stmt: _is_literal(stmt.iter) and not _truthy_literal(stmt.iter),
                marks=lambda decorators, cls: _decorator_markers(
                    SimpleNamespace(decorator_list=list(decorators)), text, off,
                    aliases_of(cls) if cls is not None else module_aliases,
                ),
                cite=lambda node: ((text.seg(node) or "").split("\n")[0], off.span(node)),
                collectible_class=lambda cls: (
                    (_is_test_class(cls) or cls.name in test_class_names) and not _test_attr_disabled(cls.body)
                ),
            ),
            expressions=any(token in raw for token in _EXPRESSION_BINDING_TOKENS),
        )

    visit(tree, "", module_markers, True, setup_scopes, module_aliases)
    if collect_tests:
        for cls, owner, method in inherited_test_methods(tree):
            # A class its own later binding replaces takes the units it
            # inherits with it, as it does its own (#424).
            through = rebound.get(id(cls))
            if through is not None and through.gone:
                continue
            units.append(_collect_unit(
                method, f"{cls.name}.{method.name}", text, off,
                module_markers + class_marks(owner) + class_marks(cls)
                + (through.markers + through.rebound if through is not None else [])
                + setup_markers(method, nested_setup(setup_scopes, owner, cls, instance=cls), (cls,)),
                module_scopes, file_caches, branch_fixtures, doctests, aliases_of(owner),
                outcome_bindings=body_names, method=True, outcome_roots=body_roots, attrs=attrs_of(cls),
                helpers=helper_outcomes, origins=marker_origins, instance=instance_of(cls),
                resolved=resolved_methods,
                producers=fixture_producers(method, (owner, cls)),
            ))
    if conftest:
        units = [_conftest_unit(tree, text, off)]

    # Two defs sharing a name shadow each other at runtime, and name-keyed
    # alignment produced phantom findings on comment-only diffs (triage,
    # rich 6c48a5c). Disambiguate deterministically by order.
    seen_names: dict[str, int] = {}
    for unit in units:
        n = seen_names.get(unit.qualname, 0)
        seen_names[unit.qualname] = n + 1
        if n:
            unit.qualname = f"{unit.qualname}#{n + 1}"

    # The class and method each handler runs in, read the first time a
    # handler's unittest call reaches condition two of ruling 496 (R49).
    handler_scopes: list[dict[int, tuple[ast.ClassDef, ast.AST]]] = []

    def testcase_of(handler: ast.ExceptHandler):
        def testcase(call: ast.Call) -> bool:
            if not handler_scopes:
                handler_scopes.append(_handler_methods(tree))
            scope = handler_scopes[0].get(id(handler))
            return scope is not None and _testcase_method(call, *scope, methods_of(), raw)
        return testcase

    # The proven failure relays among the swallowing handlers (D-190), read
    # only in a collected test module (R2b), and only once a relay-shaped
    # handler asks: the reader is built then, with the spans of the
    # assertions this file's units execute (R2), which are final by now.
    relays: list[str] = []
    relay_readers: list[_RelayReader | None] = []
    reads_relays = collect_tests and not conftest

    def proven_relay(handler: ast.ExceptHandler, node: ast.AST) -> bool:
        # A tree too deep for the reading leaves the handler unproven, which
        # is 0.10's reading: the relay pass never turns a file 0.10 analyses
        # into an engine error.
        try:
            if not relay_readers:
                relay_readers.append(None)
                relay_readers[0] = _RelayReader(tree, off, [a.span for u in units for a in u.side.assertions])
            reader = relay_readers[0]
            return reader is not None and reader.proven(handler, node)
        except RecursionError:
            return False

    broad: list[str] = []
    swallowing: list[str] = []
    for node in _walk(tree):
        if isinstance(node, ast.Import):
            imports.extend(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module:
            # `from .helpers import x` resolves inside the package; recording
            # it as top-level `helpers` made IMPORT_UNRESOLVED fire on it.
            if not node.level:
                imports.append(node.module)
        elif isinstance(node, ast.Constant) and not isinstance(node.value, (bool, type(None))):
            rep = repr(node.value)
            if len(rep) <= 64:
                literals.add(rep)
        elif isinstance(node, (ast.Try, ast.TryStar)):
            # In a test file the rule is "an oracle got swallowed", not "an
            # except clause exists". Judging the handler alone flagged a
            # brand-new test that provokes an error on purpose and asserts
            # *inside* the handler, and a helper whose handler re-raises —
            # neither hides anything (reader audit 2026-08-02, rich 44797c0 /
            # starlette 26d66bb). Both lists are emitted; the engine picks by
            # role.
            guards_oracle = _contains_oracle(node.body)
            for handler in node.handlers:
                _caught, is_broad = _handler_info(handler)
                if not is_broad:
                    continue
                seg = _norm((text.seg(handler) or "except:").split("\n")[0])
                broad.append(seg)
                if not guards_oracle:
                    continue
                if _swallows(handler):
                    swallowing.append(seg)
                    if reads_relays and _relay_candidate(handler) and proven_relay(handler, node):
                        # It hands the failure, unchanged, to a future the
                        # test awaits. It stays in both lists, as on 0.10;
                        # the engine credits it in what a change adds (D-190).
                        relays.append(seg)
                elif not _raises_in(handler) and _proved_to_pass(handler, testcase_of(handler)):
                    # Its oracles cannot fail, so it swallows too, under its
                    # own text (#496, R50).
                    swallowing.append(seg + _ALWAYS_PASSING)
        elif isinstance(node, (ast.With, ast.AsyncWith)):
            # The with-context twins of `except AssertionError`:
            # `suppress(...)` swallows a failed assert, the raises family
            # (`pytest.raises`, `self.assertRaises`, `assertRaisesRegex`)
            # expects one — for any type set that can catch an
            # AssertionError, same predicate as the except path (issue #57;
            # the original two spellings were red-team bypasses,
            # 2026-09-01). Keyed on wrapping a bare `assert` so a contract
            # test of a helper (a call, not an assert) is untouched. Emitted
            # to both lists: for a test file the engine reads swallowing, and
            # neutralising an assertion is the swallow.
            #
            # The cheap check first: `with` statements are everywhere in test
            # files (`open`, `raises`, `patch`), and running the bare-assert
            # walk on every one of them cost the macOS perf leg its budget
            # (v0.2.4). `_neutralizes_assertionerror` is a name+args lookup;
            # the walk runs only when a neutraliser is actually present.
            neutralisers = [
                item.context_expr
                for item in node.items
                if _neutralizes_assertionerror(item.context_expr)
            ]
            if neutralisers and _wraps_bare_assert(node.body):
                for ctx in neutralisers:
                    seg = _norm((text.seg(ctx) or "").split("\n")[0])
                    broad.append(seg)
                    swallowing.append(seg)
    broad.sort()
    swallowing.sort()
    relays.sort()

    suppressions = [
        f"{i + 1}:{line.strip()}"
        for i, line in enumerate(raw.split("\n"))
        if _SUPPRESSION_RE.search(line)
    ]

    units.sort(key=lambda u: u.span)
    if collect_tests:
        helper_asserts, fixture_asserts, autouse = _module_oracle_scopes(tree, text, off)
        helper_calls = _module_helper_calls(tree)
        # A helper method's callees, under its class-qualified name: evidence
        # only for the assertions reached through it (306 Sub-Q8).
        for via, method_node in sorted(resolved_methods.items()):
            helper_calls[via] = _callees(method_node)
    else:
        helper_asserts, fixture_asserts, autouse = {}, {}, ()
        helper_calls = {}
    return ParsedFile(
        parse_ok=True,
        units=units,
        symbols=symbols,
        symbol_calls=symbol_calls,
        imports=sorted(set(imports)),
        suppressions=suppressions,
        literals=frozenset(literals),
        broad_handlers=tuple(broad),
        swallowing_handlers=tuple(swallowing),
        relay_handlers=tuple(relays),
        constants=_top_level_constants(tree, text),
        from_imports=_top_level_from_imports(tree),
        fixture_defs=_fixture_definitions(tree) if collect_tests else {},
        helper_asserts=helper_asserts,
        helper_calls=helper_calls,
        fixture_asserts=fixture_asserts,
        autouse_fixtures=autouse,
        marker_origins=marker_origins,
    )


def parse_conftest_level(data: bytes, path: str) -> ConftestLevel | None:
    """A conftest's fixtures as a test module below its directory sees them (#223).

    None when it does not parse: pytest cannot import it either, and what it
    would define is unknown.
    """
    raw = normalize_source(data)
    try:
        tree = ast.parse(raw)
    except (SyntaxError, RecursionError, ValueError, MemoryError):
        return None
    off = _Offsets(raw)
    return conftest_level(path, tree, off.seg, off.span)


def _module_helper_calls(tree: ast.Module) -> dict[str, tuple[str, ...]]:
    """Callee leaves of same-file helpers. One hop, no fixtures, no tests."""
    out: dict[str, tuple[str, ...]] = {}
    for node in tree.body:
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        if _is_test_name(node.name) or _is_fixture_def(node):
            continue
        out[node.name] = _callees(node)
    return out


def _is_fixture_def(node) -> bool:
    return isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and any(
        _dotted(d.func if isinstance(d, ast.Call) else d) in ("pytest.fixture", "fixture")
        for d in node.decorator_list
    )


def _classified_asserts(nodes, text, off) -> tuple:
    out = []
    for node in nodes:
        if isinstance(node, ast.Call):
            # numpy's and torch's assertion calls are lent as a bare `assert`
            # is, as the unit's own walk reads them (#222, #286).
            c = _tolerance_statement_classified(node, text)
            if c is None:
                continue
            bare, trivial = False, c.trivial
        elif isinstance(node, ast.Assert):
            c = _classify_assert(node, text)
            bare = (
                isinstance(node.test, ast.Compare)
                and len(node.test.comparators) == 1
                and isinstance(node.test.comparators[0], ast.Name)
            )
            trivial = _is_trivial_subject(node.test) or c.trivial
        else:
            continue
        seg = text.seg(node) or ""
        out.append(
            Assertion(
                id="a?",  # assigned when merged into a unit
                bare_expectation=bare,
                form=c.form,
                strength=c.strength,
                text=seg,
                span=off.span(node),
                left=c.left,
                right_literal=c.right_literal,
                right_value=c.right_value,
                epsilon=c.epsilon,
                epsilon_kind=c.epsilon_kind,
                predicate=c.predicate,
                operand_source=c.operand_source,
                unevaluated_expected=c.unevaluated_expected,
                unbound_operands=c.unbound_operands,
                trivial=trivial,
                positive=c.positive,
                left_names=c.left_names,
                right_depends_on=c.right_names,
                inherited=True,
            )
        )
    return tuple(out)


def _module_oracle_scopes(tree: ast.Module, text, off):
    """(helper_asserts, fixture_asserts, autouse_fixtures) for a test module.

    Helpers contribute their **own** direct asserts — one hop across the file
    boundary, matching the same-file depth line. Fixtures contribute everything
    lexically inside: the closure they return is what the unit invokes, and the
    post-`yield` teardown runs whether or not anything calls it.
    """
    helpers: dict[str, tuple] = {}
    fixtures: dict[str, tuple] = {}
    autouse: list[str] = []
    for node in tree.body:
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        if _is_fixture_def(node):
            found = _classified_asserts(ast.walk(node), text, off)
            if found:
                fixtures[node.name] = found
            for d in node.decorator_list:
                if isinstance(d, ast.Call) and any(
                    kw.arg == "autouse" and isinstance(kw.value, ast.Constant) and kw.value.value
                    for kw in d.keywords
                ):
                    autouse.append(node.name)
        elif not _is_test_name(node.name):
            found = _classified_asserts(_scope_nodes(node), text, off)
            if found:
                helpers[node.name] = found
    return helpers, fixtures, tuple(sorted(autouse))


def _top_level_constants(tree: ast.Module, text) -> dict[str, str]:
    """Top-level `NAME = <expr>` bindings, name -> expression source."""
    out: dict[str, str] = {}
    for stmt in tree.body:
        if isinstance(stmt, ast.Assign):
            value, names = stmt.value, [t.id for t in stmt.targets if isinstance(t, ast.Name)]
        elif isinstance(stmt, ast.AnnAssign) and stmt.value is not None and isinstance(stmt.target, ast.Name):
            value, names = stmt.value, [stmt.target.id]
        else:
            continue
        seg = text.seg(value)
        if seg:
            for name in names:
                out[name] = seg
    return out


_PATCH_CALLS = ("setattr", "setitem", "set_attribute")
# A target a test builds at runtime is read only from a patcher (#196 188.5):
# a literal "pkg.mod.attr" is read from any `.patch(...)`, but a computed
# one there is as likely `client.patch(url)`, an HTTP request.
_RUNTIME_PATCHERS = frozenset({
    "patch", "mock.patch", "unittest.mock.patch", "mocker.patch", "module_mocker.patch",
    "class_mocker.patch", "package_mocker.patch", "session_mocker.patch",
})
_RUNTIME_SETTERS = frozenset({"monkeypatch", "mp"})
# `__name__` in a test module is that module: a target built from it
# (`f"{__name__}.A"`) replaces the test's own code, not the code it tests.
OWN_MODULE = "\x00"


def _runtime_patcher(dotted: str) -> bool:
    parts = dotted.split(".")
    if parts[-1] == "patch":
        return dotted in _RUNTIME_PATCHERS
    if parts[-1] == "object":
        return ".".join(parts[:-1]) in _RUNTIME_PATCHERS
    return len(parts) == 2 and parts[0] in _RUNTIME_SETTERS and parts[1] in {"setattr", "setitem"}


def _opaque_target(node: ast.AST) -> tuple[str, str]:
    """A target built at runtime that one hop cannot read: its source, and
    the attribute when a literal tail spells it (`f"{MOD}.compute"`), else
    `*`, any attribute (#196 188.5)."""
    tail = None
    if isinstance(node, ast.JoinedStr) and node.values and isinstance(node.values[-1], ast.Constant):
        tail = node.values[-1].value
    elif (isinstance(node, ast.BinOp) and isinstance(node.right, ast.Constant)
          and isinstance(node.right.value, str)):
        tail = node.right.value
    attribute = tail.rsplit(".", 1)[1] if isinstance(tail, str) and "." in tail else ""
    return ast.unparse(node), attribute if attribute.isidentifier() else "*"


def _module_strings(text) -> dict[str, str]:
    """Top-level names the module binds once, and to a string literal (#196 188.5)."""
    cached = getattr(text, "module_strings", None)
    if cached is not None:
        return cached
    counts: dict[str, int] = {}
    values: dict[str, str] = {}
    tree = getattr(text, "tree", None)
    for statement in tree.body if tree is not None else ():
        for name in _bound_names([statement]):
            counts[name] = counts.get(name, 0) + 1
        if isinstance(statement, (ast.Assign, ast.AnnAssign)):
            targets = statement.targets if isinstance(statement, ast.Assign) else [statement.target]
            value = statement.value
            if (len(targets) == 1 and isinstance(targets[0], ast.Name)
                    and isinstance(value, ast.Constant) and isinstance(value.value, str)):
                values[targets[0].id] = value.value
    cached = {name: value for name, value in values.items() if counts.get(name) == 1}
    try:
        text.module_strings = cached
    except AttributeError:
        pass
    return cached


# What binds a name to no string: a def, a class, or `import x` (a module).
# `from m import x` may bind a string constant, so it is no such binding.
_OBJECT_BINDINGS = (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef, ast.Import)


def _module_objects(text) -> frozenset[str]:
    """Top-level names the module binds once, and to no string: a def, a
    class or an imported module. None at all once a star import may rebind
    any name (#196 188.5)."""
    cached = getattr(text, "module_objects", None)
    if cached is not None:
        return cached
    counts: dict[str, int] = {}
    objects: set[str] = set()
    tree = getattr(text, "tree", None)
    body = tree.body if tree is not None else []
    if any(isinstance(statement, ast.ImportFrom) and any(alias.name == "*" for alias in statement.names)
           for statement in body):
        body = []
    for statement in body:
        names = _bound_names([statement])
        for name in names:
            counts[name] = counts.get(name, 0) + 1
        if isinstance(statement, _OBJECT_BINDINGS):
            objects |= names
    cached = frozenset(name for name in objects if counts.get(name) == 1)
    try:
        text.module_objects = cached
    except AttributeError:
        pass
    return cached


def _not_a_string(node: ast.AST, func, text) -> bool:
    """Is a patch target provably no string? The patcher then raises
    TypeError and installs nothing, as pytest's own tests of monkeypatch
    spell it (`monkeypatch.setattr(A, "y")` under `pytest.raises(TypeError)`):
    a constant that is no string, or a name bound once, to a def, a class or
    an imported module, in the test or else the module (#196 188.5)."""
    if isinstance(node, ast.Constant):
        return not isinstance(node.value, str)
    if not isinstance(node, ast.Name):
        return False
    args = func.args
    if node.id in {arg.arg for arg in (*args.posonlyargs, *args.args, *args.kwonlyargs, args.vararg, args.kwarg)
                   if arg is not None}:
        return False
    bindings = objects = 0
    for child in ast.walk(func):
        if child is func:
            continue
        if isinstance(child, ast.Name) and child.id == node.id and isinstance(child.ctx, (ast.Store, ast.Del)):
            bindings += 1
        elif isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)) and child.name == node.id:
            bindings += 1
            objects += 1
        elif isinstance(child, (ast.Import, ast.ImportFrom)):
            for alias in child.names:
                if (alias.asname or alias.name.split(".")[0]) == node.id:
                    bindings += 1
                    objects += isinstance(child, ast.Import)
        elif (isinstance(child, (ast.ExceptHandler, ast.MatchAs, ast.MatchStar)) and child.name == node.id
              or isinstance(child, (ast.Global, ast.Nonlocal)) and node.id in child.names):
            bindings += 1
    if bindings:
        return bindings == 1 and objects == 1
    return node.id in _module_objects(text)


def _runtime_string(node: ast.AST, func, text) -> str | None:
    """A patch target the test builds at runtime, read one hop (#196 188.5).

    A string literal; a name the test function binds once, to a string
    literal, or else one the module binds once that way; `__name__`, the test
    module itself (`OWN_MODULE`); and an f-string or `+` of those. Anything
    else is None: unreadable, so the target is opaque.
    """
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    if isinstance(node, ast.Name):
        if node.id == "__name__":
            return OWN_MODULE
        return _function_string(func, node.id, text)
    if isinstance(node, ast.JoinedStr):
        parts = []
        for value in node.values:
            if isinstance(value, ast.Constant) and isinstance(value.value, str):
                parts.append(value.value)
                continue
            part = (_runtime_string(value.value, func, text)
                    if isinstance(value, ast.FormattedValue) and value.conversion == -1
                    and value.format_spec is None and isinstance(value.value, ast.Name) else None)
            if part is None:
                return None
            parts.append(part)
        return "".join(parts)
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
        left, right = _runtime_string(node.left, func, text), _runtime_string(node.right, func, text)
        return left + right if left is not None and right is not None else None
    return None


def _function_string(func, name: str, text) -> str | None:
    """The string literal `name` holds in `func`: its one binding there, an
    assignment of a literal; or, bound nowhere in the function, the module's."""
    args = func.args
    parameters = {arg.arg for arg in (*args.posonlyargs, *args.args, *args.kwonlyargs, args.vararg, args.kwarg)
                  if arg is not None}
    if name in parameters:
        return None
    stores = []
    for node in ast.walk(func):
        if isinstance(node, ast.Name) and node.id == name and isinstance(node.ctx, (ast.Store, ast.Del)):
            stores.append(node)
        elif (isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)) and node.name == name
              and node is not func
              or isinstance(node, ast.alias) and (node.asname or node.name.split(".")[0]) == name
              or isinstance(node, (ast.ExceptHandler, ast.MatchAs, ast.MatchStar)) and node.name == name
              or isinstance(node, (ast.Global, ast.Nonlocal)) and name in node.names):
            return None  # an import, a def, `except ... as`, a pattern: not a literal
    if len(stores) > 1:
        return None
    if not stores:
        return _module_strings(text).get(name)
    for node in ast.walk(func):
        if (isinstance(node, (ast.Assign, ast.AnnAssign))
                and (node.targets if isinstance(node, ast.Assign) else [node.target]) == [stores[0]]
                and isinstance(node.value, ast.Constant) and isinstance(node.value.value, str)):
            return node.value.value
    return None


def _patch_call_target(node: ast.Call, dotted: str | None, func=None, text=None) -> tuple[str, str] | None:
    """One patch dialect -> (target, attribute), or None if this is not one.

    Called from `_collect_unit`'s single walk, which covers the decorator list
    too — that is where half of these live: `@mock.patch("pkg.mod.attr")` is
    the same installation as the `monkeypatch.setattr` two lines into the body.

    Accepted: `monkeypatch.setattr`/`setitem` (including through
    `monkeypatch.context()`, whose receiver is named by the `with` clause and
    so cannot be pinned to the fixture name), `patch(...)`, `mock.patch(...)`,
    `mocker.patch(...)`, and `patch.object(...)` in any of those spellings.

    The builtin `setattr(obj, "name", v)` is deliberately NOT one: it has no
    receiver, and mutating an object the test owns is configuration, not the
    installation of a stand-in. Reading it as one would fire on every fixture
    that sets up its subject.
    """
    if not dotted or not node.args:
        return None
    parts = dotted.split(".")
    tail = parts[-1]
    if tail in _PATCH_CALLS:
        if len(parts) < 2:  # the builtin, not a patcher
            return None
    elif tail == "object":
        if len(parts) < 2 or parts[-2] != "patch":
            return None
    elif tail != "patch":
        return None

    # Which form this is depends on the first argument, not on the arity:
    # `monkeypatch.setattr("pkg.mod.attr", v)` and
    # `monkeypatch.setattr(mod, "attr", v)` are both three-argument calls.
    first = node.args[0]
    if isinstance(first, ast.Constant) and isinstance(first.value, str):
        target = first.value
        if "." not in target:
            return None  # unqualified: neither a module nor an attribute
        return (target, target.rsplit(".", 1)[1])
    # A target built at runtime (#196 188.5) is read one hop from a patcher,
    # and one that stays unreadable is opaque: `*` for its attribute.
    runtime = func is not None and _runtime_patcher(dotted)
    if runtime and (tail == "patch" or tail == "setattr" and len(node.args) == 2):
        if _not_a_string(first, func, text):
            return None  # the patcher raises TypeError: nothing is installed
        target = _runtime_string(first, func, text)
        if target is None:
            return _opaque_target(first)
        if target.startswith(OWN_MODULE) or "." not in target:
            return None
        return (target, target.rsplit(".", 1)[1])
    if len(node.args) < 2:
        return None
    attr = node.args[1]
    base = _dotted(first)
    if base is None:
        return None
    if isinstance(attr, ast.Constant) and isinstance(attr.value, str):
        return (f"{base}.{attr.value}", attr.value)
    if not runtime:
        return None
    name = _runtime_string(attr, func, text)
    if name is None or name.startswith(OWN_MODULE):
        return (f"{base}.*", "*")
    return (f"{base}.{name}", name)


def conftest_patch_targets(data: bytes, first_party: frozenset[str] = frozenset(), *, module_exists=None, module_name="") -> list[str]:
    """Proven monkeypatch/unittest.mock calls aimed at first-party code.

    A fixture that swaps the module under test for an adapter makes every
    assertion in the suite check the stand-in, with production and test files
    both byte-identical — a real agent escaped exactly this way (decoy probe
    arm 2026-08-04). Third-party and stdlib targets (faking time, network,
    env) are normal hygiene and are not reported.
    """
    raw = normalize_source(data)
    try:
        tree = ast.parse(raw)
    except (SyntaxError, RecursionError, ValueError, MemoryError):
        return []
    from checkwash.frontends.python.conftest_patches import patch_calls

    resolve = module_exists or (lambda name: name.split(".")[0] in first_party)
    return sorted({_norm(seg.split("\n")[0]) for seg in patch_calls(tree, raw, resolve, module_name=module_name, source_segment=_Offsets(raw).seg)})


def _top_level_from_imports(tree: ast.Module) -> dict[str, tuple[str, str]]:
    """Top-level `from M import a as b`, local name -> (module, original).

    Absolute imports (level 0), and same-directory package-relative imports
    (`from .assertions import x`, level 1 with a single-component module).
    The engine resolves a dotless module as a sibling `{tdir}/{module}.py`,
    which is exactly where `.assertions` lives, so the relative spelling of a
    verbatim assertion-helper extraction now resolves the same as the
    absolute one — the two disagreed, and the relative form read as
    ASSERT_REMOVED (red-team false positive, 2026-09-01). Deeper relative
    imports (`from ..pkg import x`, or `from .sub.helpers import x`) resolve
    against a parent the engine's sibling rule does not model, and stay a
    documented residual.
    """
    out: dict[str, tuple[str, str]] = {}
    for stmt in tree.body:
        if not isinstance(stmt, ast.ImportFrom) or not stmt.module:
            continue
        same_dir_relative = stmt.level == 1 and "." not in stmt.module
        if stmt.level == 0 or same_dir_relative:
            for alias in stmt.names:
                if alias.name != "*":
                    out[alias.asname or alias.name] = (stmt.module, alias.name)
    return out


def module_constants(data: bytes) -> dict[str, str]:
    """Top-level constant bindings of a module checkwash was not diffing.

    The engine uses this to resolve skip-condition names imported from files
    outside the diff (click's `from click._compat import WIN`). An unreadable
    or unparseable module yields nothing: the name stays unevaluable and the
    compat-gate credit is simply not earned.
    """
    raw = normalize_source(data)
    try:
        tree = ast.parse(raw)
    except (SyntaxError, RecursionError, ValueError, MemoryError):
        return {}
    return _top_level_constants(tree, _Offsets(raw))
