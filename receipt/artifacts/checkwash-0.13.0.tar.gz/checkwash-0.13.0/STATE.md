# STATE — read this first when taking over

Updated: 2026-11-18 (v0.13.0 published and verified; the CLI and advertised pins move to v0.13.0 and the Action pin to its Action commit A (`9ada8cfa`), the commit tag `v0.13.0` (`f8ff8258`) points to (D-200), after all five PJU release stages passed on LAPTOP-01AGNPJU and both `release-hosted.yml` macOS/Linux checkpoints (`43910068162` attempt 2, `43940303262` attempt 1) succeeded (`fe4c3fcb`), stopping at Gate 4 before Step 9 (`DECISIONS-archive-6.md` and `tests/verdict_gate/baseline.toml`) and leaving newly opened issues `#624`–`#631` untouched; earlier: the 0.13.0 release pull request (#623, `7d458142`): version 0.13.0, the release guide and known issues, the release authorization and preparation record with the final-`main` R29 fixed-corpus comparison (3,600 commits, 0 moves, 0 report differences; checkwash-lab `ec15f59d`), the uvloop diagnostic (3/3 pass, 0 findings) and D-176's 0.13.0 disposition; its stages are verified from the trusted ref `review/collector-d-013-20261116` (`978d015e`), while `release/advertised.toml`, the README install commands/Action pin and `doctor`'s base pin stay at v0.12.0 (`532f74ab`) until step 8; earlier: 0.13, strict inert EOF-append narrowing on repository-root `CLAUDE.md`, `O(N)` list-container scan, `.gwcase` pins and `AGENTS.md` L1 boundary expansion (D-213, L1): `guardrail_additive.is_pure_line_addition` narrows `GUARDRAIL_ADDITIVE` (`warn`) to strict inert end-of-file appends separated by `>= 1` blank line from `before`'s last non-blank line with clean EOF on both sides, verbatim invariance of both line-anchored frontmatter and Claude Code's non-anchored `/^---\s*\n([\s\S]*?)---\s*\n?/` slice, no `---` substring, `3+` consecutive `` ` ``/`~`, `<!--`/`-->` or `[label]:` opener on added lines, and zero newly introduced `Cf`/`Default_Ignorable` code points (`U+FE00..FE0F`, `U+E0100..E01EF`, Hangul fillers `U+115F..1160`/`U+3164`/`U+FFA0`), `_match_open_containers` caches leading-whitespace column scanning for true `O(N)` (`repro-52` `29.48s -> 1.07s`, `repro-53` `57.23s -> 0.70s`), `AGENTS.md` adds all of `src/checkwash/gating.py` and `src/checkwash/guardrail_additive.py` to `Agent-READ-ONLY`, `test_claude_md_additive.py` switches timing bounds to 3-run medians and pins `51` audit cases, and `5` `.gwcase` fixtures land over #620's `44` base-side v2 allow entries (suite count: 23,358), merged as #621 (`978d015e`), with `0.14` tracking issue #622 opened for `DET13-03`; earlier: 0.13, direct unit checking on set-aside test/conftest helper modules, `on_engine_error = "block"` `exit 2` on `importer_gaps`, and pre-release threat-model/spec/governance alignment (D-212, L1): `expected_provenance.importer_changes` records `set_aside_paths` and updates the note to `... were not read; each helper's own functions were checked, not expected values resolved through its callers`, `engine_ir_files` + `frontend_file_parse` (`collect_helpers=True`) + `diffalign` + `engine.run_detectors` check non-`test*` (and non-`pytest_*` on conftest) top-level functions of set-aside helpers directly across `REPAIR_REFUSED_PYTHON` while keeping helper units out of cross-file/arrival/restructure/duplicate/move credits, `cli._cmd_check` exits `2` with empty stdout on non-`hook-json` runs when `report_context.importer_gaps` is non-empty under `on_engine_error = "block"`, `SPEC.md` §9 updates D-206/D-212 and adds B6 (`unanalysed_test_files`), `THREATMODEL.md` updates rows 125 (`Closed in part (#272)`) and 183 and adds rows 187 (`RC-1`) and 188 (`RC-2`) (`FAILURES.md`: `87` of `207` not closed), and `DECISIONS.md` ratifies `#607` (`857c88d4`) `gating.apply_gates` split and `D-209` (`f2bfe8e0`) bootstrap clause and corrects `D-210`'s `SPEC.md §2b` reference (suite count: 23,303), merged as #619 (`7f85c855`), followed by #620 (`0a010788`), the 44 owner-approved base-side `.greenwash/allow.toml` v2 keys for D-213; earlier: 0.13, fail-closed runtime-shadow parsing on deep or unparseable candidate tests and controls: `shadow_imports._fixture_bindings`/`_test_fixture_requests`/`_active_test_imports`/`_import_targets`/`_scope_global_loads`, `shadow_controls._sys_path_roots` and `shadow_providers._extends_package_path` raise `EngineError` consistently when `parse_python` returns `parse_ok=False` after `ast.parse` succeeds or when `ast.parse` / recursive AST walks hit `RecursionError` or `MemoryError`, closing the `R607-01` silent-pass band across Python 3.11–3.13 while keeping ordinary `SyntaxError`/`ValueError` non-crashing and suppressing `SyntaxWarning`/`DeprecationWarning` via `shadow_models._parse_ast` (suite count: 23,293), merged as #618 (`c0c46a26`); earlier: 0.13, PEP 701 prefixed f-string condensation, quiet Python `SyntaxWarning` parsing and `#613` comment accuracy: `syntax._NONCHAIN_ATOM_RE` and `_condense_complete_nonchain_line` reject identifier tokens immediately followed by quotes or identifier continuations (`fr`/`FR`/`rf`/`t`/`tr`) so multiline PEP 701 prefixed f-strings over `2,048` characters never collapse into complete-line stubs (`PERF613-1`), `syntax.parse_module`/`_recover`/`_literal_tree`, `frontend.parse_python` and `engine.build_ir` suppress `SyntaxWarning` and `DeprecationWarning` on analysed Python source so invalid escape sequences emit zero `stderr` lines across Python 3.11–3.13 (`XPLAT-03`), and `syntax._chains` clarifies bounded `_Tok` retention across all Python versions vs CPython `3.12.3`'s per-token `TokenInfo.line` copies fixed by `3.12.14` (`PERF613-3`) (suite count: 23,289), merged as #617 (`9ac10fc9`); earlier: 0.13, pre-release module-naming, timing-bound, receipt-prose and provenance hygiene: renames `frontends/python/table_oracles_test.py` -> `table_oracles_carriers.py` so pytest/CheckWash default `*_test.py` discovery never classifies the production helper as a test module, renames `unanalysed_tests.py` -> `unanalysed_test_files.py` and requires `prod`-role Python files outside test directories to declare test functions/classes before emitting the B6 `analysis incomplete` note, switches the single-sample timing assertion in `test_unanalysed_test_files.py` to a 3-run median with a `3.0` s bound, expands `test_issue319_quiet_parse.py` across `engine*.py`, updates stale paths in `handover_review_mutants.py` and `r1-seen-cost.yml`, adds `collect_compact` unsupported-host refusal coverage, clarifies ruleset `22032046` context-name/App-ID binding and compact-receipt self-reported digest semantics across `pju_receipt_bridge.py` and PJU docs, and completes `#607/#610/#612/#613/#614/#615` merge/provenance/boundary records in `STATE.md` (suite count: 23,283), merged as #616 (`91676bb1`); earlier: 0.13, public-facing `README.md` layering before `v0.13.0`: removes the disabled `ci.yml` status badge, folds deep guardrail-customization, repair-evidence/refactor-provenance, 1-MB size-limit and `A`-vs-`M` release-tag geometry details into collapsible `<details>` disclosures while keeping quickstarts, core limits and every contract/measurement pin intact, and updates the related-project footer link from `checkwash-corpus` / `smallestlie` to `checkwash-prove` (suite count: 23,283), merged as #615 (`a5cfb161`); earlier: 0.13, cross-platform compact collector helper test isolation in `test_pju_compact_receipt.py`: `test_collect_compact_binds_admitted_git_and_restores_helpers` resolves `tmp_path` and `git` to real paths, stubs `action_mod.execution_route` and materializes regular `python.exe`, `SystemRoot` and `ProgramFiles` directories under the resolved temporary root so the test no longer depends on the PJU Windows host route, non-symlinked POSIX/macOS `sys.executable`/`git`/`/var` paths, or default Windows `C:\Windows`/`C:\Program Files` directories (suite count: 23,283), merged as #614 (`eece00f3`); earlier: 0.13, CPython 3.12.3 single-line `tokenize` memory DoS and OOM fix in `syntax.py` and `test_string_chain_syntax.py`: `syntax._chains` avoids retaining `TokenInfo.line` copies and pre-scans or condenses physical lines over `2,048` characters so CPython 3.12.3's `_tokenize.TokenizerIter` (fixed upstream in `3.12.14`) does not allocate `O(K * L)` full-line copies (`40 GB`–`1 TB` on `test_perf.py::test_pathological_file_does_not_hang` and `10`–`20 GB` on `DEEP` string chains), while `test_string_chain_syntax.py` drops retained `TokenInfo.line` references and adds `12` bounded-memory/time and lexical-boundary regressions (suite count: 23,283), merged as #613 (`66c4a9b1`); earlier: 0.13, protected threat-model, decision-log and gate-README text corrections (L1, #612, approved by Nelson at 2026-11-15T10:44:37Z and 10:47:09Z): updates `THREATMODEL.md` item 2 (`hook install` `.claude/settings.local.json` `info/exclude` behaviour since D-205), row 2 (#212's 2026-11-08 blind rating of the 11 JS/TS commits, D-203), rows 7, 31 and 40 (`Closed` -> `Partly closed` for `pytest_runtest_setup` sibling/signature/guard bounds and `pytest_runtest_call` / `'skipped'` report hooks, compound/raised module-level skips and compound/post-class `__test__ = False`), row 105 item 6 (`closed` -> `partly closed` for `collection_inventory._candidates` omitting `unittest.TestCase` and subclassed test classes) and row 157 (#428 closed as fixed on 2026-11-08 with D-152's targeted JS table scan and replay moved to #504, D-203), regenerates `benchmarks/FAILURES.md` (`84` of `205` not closed: `Closed in part` `16 -> 19`, `Closed` `121 -> 118`), corrects `DECISIONS.md` `D-203`'s question timestamp from `14:08:05Z` to `2026-11-12T14:07:42Z` (keeping Nelson's `14:08:05Z` answer), and replaces `tests/gates/README.md` item 2's present-tense `byte-compare` CI wording with the actual PJU pull-request and `release-hosted.yml` six-leg verification scope (suite count: 23,271), merged as #612 (`04473e4d`); earlier: 0.13, pure line additions to repository-root `CLAUDE.md` stay at `warn` (`GUARDRAIL_ADDITIVE`, D-211, #611, approved by Nelson at 2026-11-15T09:34:17Z): `guardrail_additive.is_pure_line_addition` + `DiffGlobals.guardrail_files_additive` + `gating.GUARDRAIL_ADDITIVE_PATHS` (`{"CLAUDE.md"}`) keep non-rename in-place line additions to root `CLAUDE.md` at `warn` (`GUARDRAIL_ADDITIVE`, `"additive": True` v2 fingerprint context) when any leading frontmatter is unchanged and every existing line survives in order and in its CommonMark / GFM / HTML structural context, while line deletions, edits, reorderings, frontmatter edits, comment/fence/HTML/Markdown wrapping or re-contextualization, renames, deletions, and all other guardrail paths escalate to `critical` (`META`) as before (suite count: 23,271), merged as #611 (`bce7c8d3`); earlier: 0.13, report note for changed test-shaped files outside the Python and JS/TS test parse gates (B6): `unanalysed_tests.py` + `ReportContext.unanalysed_test_files` emit a single-line `analysis incomplete: N test-shaped file(s) not analysed: ...` summary on `cli._cmd_check` `stderr`, `report/term.py` and SARIF `toolExecutionNotifications` for changed inherited/mixin Python test modules (`PM-02`), non-default Python test filenames (`PM-03`), and non-default JS/TS test directories and suffixes (`F-03`/`F-13`), while keeping verdicts, exit codes and `--format json` / `--emit-ir` / `--format hook-json` / `hook pre-tool-use` / `--coverage-report` machine `stdout` unchanged (suite count: 23,149), merged as #610 (`aa678cb3`); earlier: 0.13, findings on projected Python units report real test names and non-transitioning `captured-result` edits keep source assertion text (D-210, #608, approved by Nelson at 2026-11-14T02:55:05Z and 04:10:13Z): `ParsedUnit` and `Unit` carry optional `source_unit: str = ""` (`IR_VERSION = 3`, `FINDINGS_VERSION = 2` unchanged), all eleven unit-scoped detector modules and gating report the enclosing Python test's qualified name instead of `test_concrete_*` / `test_exception_*` / `test_local_auxiliary_*` while `_resolve_finding_unit` and `unit_assertion_position` preserve per-concrete-unit `REPAIR_EVIDENCE` isolation and duplicate-row v2 fingerprint distinctness, and same-carrier `captured-result` tests without special authorities or local renames skip projection so `repro-07` `v0`–`v6` and `repro-06` `a2`/`a2b` report consistent real unit names and source assertions (suite count: 23,122), merged as #608 (`0ffbeb31`); earlier: 0.13, CLI `GitSnapshot` reuse and batched base manifest reads: `cli._analyse`, `_cmd_check`, `_session_note` and `_pre_tool_use` share one resolved `GitSnapshot` across base policy (`config.toml`/`allow.toml`), `--task` base read and `#500` alias check, `MANIFESTS` batch read (`read_base_manifests_from_snapshot`), `list_range_changes`, and `PairedPytestConfigs`, while `GitSnapshot.read` short-circuits known-absent paths on inventoried snapshots and preserves cross-module monkeypatch fallbacks (suite count: 23,108), merged as #609 (`5e0fb5aa`); earlier: Phase 2 structural decomposition of five core God-function modules (`engine.py`, `shadow.py`, `frontends/python/frontend.py`, `gating.py`, `frontends/python/table_oracles.py`), reducing eight orchestrators (`build_ir`, `find_runtime_subject_shadows`, `_collect_unit`, `_parse_python`, `apply_gates`, `_test`, `_module`, `project_table_consolidation`) to 17–80 lines across 22 `src/checkwash/**` files with zero fixture/verdict-gate output, L1 severity-table or `tests/**` changes (recursion-frame boundary shifts by 1–6 frames near `~2,956` `+` operators; `gating.apply_gates` split ratified by Nelson at `2026-11-15T17:34:59Z`, suite count: 23,098), merged as #607 (`3231a03f`); earlier: compact PJU digest receipts for ordinary PRs and ruleset App binding (D-209): `collect_pju_receipts.py --compact` runs the full local suite with 16 xdist workers on PJU, replays pinned and candidate Actions concurrently, builds and byte-matches wheel/sdist/pyz and runs isolated wheel/pyz `demo` checks, emitting a single-line ~6–9 KB JSON digest receipt with zero new `evidence/*` branches; `pju_receipt_bridge.py` enforces exact documented test-count equality (`>= 23,065`, RC-09) and `refs/heads/main` workflow dispatch (self-sealing after same-tree bootstrap on compact, immediate on legacy `verify`/`publish`, RC-02), removes `quality-candidate-intake.yml` from `pull_request.paths` and binds required check `checkwash` to GitHub Actions App `15368` in `action/required-ruleset.json` and ruleset `22032046` (RC-03), while release stages keep full `3x283` qualification, merged as #606 (`620f5236`); earlier: 0.13, a virtual environment's own links (D-208): on Linux (macOS by Python's source, not run) a check without a range and the Stop hook set aside an untracked link in an environment's `bin` or `Scripts`, or its `lib64` linking to `lib`, in an environment directory neither `HEAD` nor the session base holds, unless a detector must read its path or pytest's collection can reach the environment, and the working tree's listing leaves out non-directory own links in `bin` or `Scripts` and its walks pass over `lib64` linking to `lib` beside directory `lib`, so an environment beside the change, untracked or ignored, no longer stops the run, and the PreToolUse hook asks on a weakened helper beside one too; a range that adds or changes a link still refuses it, base-held links stop a range when read, and THREATMODEL row 186 records the local residual, merged as #605 (`b326f201`); earlier: 0.13, the signature block that ends a PowerShell file is not read for a test runner (D-207), so a Windows virtual environment's signed `Activate.ps1` no longer blocks, untracked or committed; THREATMODEL row 185 records the residual, a PowerShell-named file another program runs, merged as #604 (`0f054eef`); earlier: 0.13, a changed test helper's importers past the search limit (D-206): the expected-value pass searches each changed helper's module name on its own, without the diff's own paths; past that name's bounds, or the run's 192 importer reads, it reads none of its importers and says "analysis incomplete", where the hit limit used to stop every run; a helper renamed to another name, `sweep` and the root-helper search still exit 2 at the limit; THREATMODEL row 184 records older gaps of the pass, merged as #603 (`82b88866`); earlier: 0.13, first-week fixes (D-205): a check without a range and the Stop hook set aside the untracked zipapp checkwash runs from, and a local hook install keeps `.claude/settings.local.json` out of Git, merged as #602 (`6c2b7669`); earlier: toward 1.0 (D-203): 0.x outreach resumes as a trial with no quantitative quality promise; the fifteen frozen P0/P1 issues gate 1.0; #212 is narrowed to a blind rating of 0.12's eleven JS/TS moves, a selected set and not a rate: 10 should pass and 1 is unclear, and it closes with its caveats; #428 closes as fixed; one macOS verification per release, since widened to macOS and Linux by D-204; the cohort answers are research design, not a frozen protocol; a string-chain test regains its at-limit check; 1.0 is still NOT_MET, merged as #597 (`9b69183d`); earlier: the v0.12.0 Release notes end with a paragraph on its hosted verification after publication, added on Nelson's answer, merged as #601 (`f93e24ce`); earlier: v0.12.0's hosted verification after publication, run 43039360146, failed on macOS in 14 entries (13 tests) of the PJU release collector's tests, which now take each temporary directory by its real path; the published files, the corpus and the Action passed; the result is recorded with 0.12.0 and the run's artifacts are kept on an evidence branch, merged as #600 (`c4dee609`); earlier: from the release after v0.12.0 each release gets one hosted verification on GitHub-hosted macOS and Linux, in two checkpoints, and the macOS skip of the two budget checks stays at 1.0 (D-204), merged as #599 (`eb4fdab6`); earlier: the README states four more limits of a pass, leads its refactor paragraph with the current 6/60, links examples/invoice and no longer calls the eight demo cases real; stale statements in six documents are corrected; documentation and one test pin only, merged as #598 (`fb71bc75`); earlier: the release workflow's PyPI upload uses pypa/gh-action-pypi-publish v1.14.3, the first version advisory GHSA-5xjx-3w67-w9x9 lists as patched, merged as #596 (`8f610be9`); earlier: the T3.5 design note links the first execution satellite, checkwash-prove, a separate repository and package; nothing in checkwash runs code because of it, merged as #595 (`86e5322e`); earlier: v0.12.0 published and verified; the CLI and advertised pins move to v0.12.0 and the Action pin to its Action commit A, the commit the tag points to (D-200); the decision log moves D-197 to D-201 to archive 5, the verdict baseline rotates to v0.12.0 and i198/S1's label becomes block, on Nelson's answer (#594, D-202); THREATMODEL unchanged on Nelson's answer; earlier: the 0.12.0 release pull request: version 0.12.0, the release guide and known issues, the delegated release record with the fixed-corpus comparison and D-176's 0.12 disposition; its stages are to be verified from the trusted ref `review/collector-d-012-20261107` (`e27eec6b`); earlier: three holes beside D-191's residual close, D-201, merged as #591 (`e27eec6b`): an equality with `ANY` is a tautology, a single test's skip must provably run somewhere and the gates a change adds must leave it somewhere to run, and `assertEqual` -> `assertCountEqual` drops order; from v0.12.0 the release tag points at the release's Action commit A and names the release merge M, and the README installs the CLI only from PyPI and the pyz, D-200, merged as #589 (`54113c06`); the weakening, stand-in and subject rules take no repair evidence, a finding the evidence reached is labelled `REPAIR_EVIDENCE_REFUSED`, and 22 fixture expectations move with Nelson's approval by name, D-199, merged as #588 (`af0c5651`); #590 merged as `19f400ca`, the allow keys for D-199 and D-200; #587 merged as `7cd8549c`; earlier: receipts spread over the receipt host's cores: 8 pytest workers, the three qualification chains at once and the verdict gate's cases six at a time, D-198; #586 merged as `003e12dd`; earlier: v0.11.0 published and verified; the CLI and advertised pins move to v0.11.0 and the Action pin to its Action commit A; the decision log and the verdict baseline move to v0.11.0 (#586, D-197); THREATMODEL item 4 and row 2 state the 0.11.0 D-176 record, on Nelson's answer; earlier: the 0.11.0 release pull request: version 0.11.0, the release guide and known issues, the delegated release record with the fixed-corpus comparison, the uvloop diagnostic and D-176's 0.11 disposition, stale release labels fixed, a #455 test fixed that runs only where it can create symlinks, and R naming the release's own Action commit; 0.11 candidate: the README puts the three ways to start before the release history, which moves to `docs/releases/README.md`, merged as #583; D-196 keeps scheme S for 0.11 with its pin-updater and zizmor consequence accepted, lets the fixed-corpus candidate differ in `doctor`'s own pin line, and plans for 0.12 the tag at the Action commit and a change to D-191's residual, merged as #582; D-194 lets a release's `doctor` accept its own Action commit, which the release pull request's last commit names and the release bridge verifies (scheme S), merged as #581; D-195 restores five test relaxations that agent sessions left in checkwash's own tests, merged as #580; D-193 closes row 179 by reading the repository's own pytest collection settings, merged as #579; an outside report on #130 is fixed by D-192, which proves a lone `pytest.raises` carrier like an assertion, makes a file that lost no oracle mass a D5 candidate and stops substituting parametrize cells that never reach the test; D-190 and D-191 merged as #577; v0.10.0 published and verified; pins, decision log and verdict baseline moved to v0.10.0; 0.11 scope changed by D-189)

## 2026-11-18: v0.13.0 published

GitHub Release `v0.13.0` (`447438064`, `2026-11-16T18:39:12Z`) and PyPI `0.13.0`
(`2026-11-17T05:23:45Z`; both `2026-11-17` Asia/Taipei) serve identical wheel
(`8244e21b...`, `1,102,075` B) and sdist (`8338315a...`, `5,796,875` B) bytes,
alongside GitHub Release `checkwash.pyz` (`326e2a0c...`, `1,077,802` B). All
five PJU release stages (`pr` check `133384220945` + four required checks on
`R` = `c37a341f`, `main` `133486645794`, `tag` `133521468206`, `release-event`
`133550586375`, and `public-visitor` `134818745070`) passed on LAPTOP-01AGNPJU
(Windows 11, CPython 3.11.9, `HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`), all
collected and verified from `review/collector-d-013-20261116` (`978d015e`);
native Linux, macOS and other Python versions remain `NOT_RUN` inside those
stage receipts. Alongside them, `R` passed the six-leg Windows + WSL2 Linux
Python `3.11`/`3.12`/`3.13` full-suite batch (`23,358` tests + `67` subtests,
corpus SHA256 `f57e1ba6...`, `HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`), and
`release-hosted.yml` passed both `source-at-M` (run `43910068162` attempt 2,
after attempt 1's unacquired hosted `macos-latest` 3.11 runner) and
`published-artifacts` (run `43940303262` attempt 1) across `macos-latest` and
`ubuntu-latest` Python `3.11`–`3.13` and the Linux composite Action at `A`
(`HUMAN_AUTHORIZED_GITHUB_HOSTED_NOT_PJU_RECEIPT`, archived on
`evidence/v0130-hosted-runs-43910068162-43940303262-20261117` `fe4c3fcb`).

`#623` merged as `M` = `7d45814211bbb458d310607b3a241761c7d5f7e3` at
`2026-11-16T16:38:35Z` after Nelson's Gate 2 reply verbatim 「ok 繼續」 (and
「開新session 」), and unsigned annotated tag `v0.13.0` (`f8ff8258`, tagger
Antigravity) peels to Action commit `A` = `9ada8cfaa618b002b5d0d829c7ddbe1b8e8ae638`
with `Release-Merge: 7d45814211bbb458d310607b3a241761c7d5f7e3` (D-200). Run
`43938228666`'s `pypi` deployment was approved under `taipei49314` (GitHub
approvals comment from Codex chat `01a1e7f1-7484-7973-8995-88cbe3d868d6` on
`2026-11-17`; Antigravity made zero approval calls), followed by Nelson's
verbatim 「我部屬好了」, 「我上面有開issue 先不要解」 and 「幫我做13.0收尾就好 謝謝哈基米」 on
`2026-11-18`. Details:
[RELEASING](docs/RELEASING.md#v0130-checked-publication-and-pin-promotion-2026-11-18)
and the [publication record](docs/releases/v0.13.0-publication-verification.md).

This follow-up promotes `release/advertised.toml`, the README CLI/pyz commands,
and the Action pins in `README.md`, `.github/workflows/checkwash.yml`,
`src/checkwash/doctor.py` (`_PREVIOUS_ACTION_PIN`), `tests/test_doctor.py`,
`tools/pju_receipt_bridge.py`, `tools/replay_pju_action.py`, `SECURITY.md`,
`action/README.md` and `docs/quality-adoption.md` to `v0.13.0` (`A` =
`9ada8cfaa618b002b5d0d829c7ddbe1b8e8ae638`), leaving newly opened issues
`#624`–`#631` untouched and stopping at Gate 4 before Step 9
(`DECISIONS-archive-6.md` cut and `tests/verdict_gate/baseline.toml` rotation).
`THREATMODEL.md` is unchanged, downstream re-pins remain unauthorized, and
`1.0` remains `NOT_MET`.

## 2026-11-16: the 0.13.0 release pull request

Prepared under Nelson's one-time release instruction in session
`5472d923-3651-42a1-9267-6490cb024f59` at `2026-11-15T14:24:06Z` verbatim
「開一個session 對整體做一次檢查 沒問題後就發」, his `2026-11-15T15:15:53Z` review-discussion note
verbatim 「我這邊也會做審查 等等交給你討論」, his `2026-11-15T17:34:59Z` post-audit `Q1`–`Q6`
ruling in session `c8f1073f-a39c-4c95-a65f-90c9037eff91` verbatim 「可以 照你的建議走
開個新session? 需要用到goal 或其他技能嗎」 plus `/goal` handover in session
`3da7dc8a-5957-4ba3-bde0-bba9c03b8042`, and his `2026-11-16T11:45:56Z` Gate 1
L1 approval verbatim 「核可並合併」 (agent scope interpretation: authorizes building
and opening the `0.13.0` release pull request `A` + `R` over final `main`
`978d015e` with `23,358` tests, stopping at Gate 2 before merging/tagging, Gate
3 at the `pypi` environment deployment, and Gate 4 before Step 9; `1.0` stays
`NOT_MET` and downstream re-pins stay out of scope):

- **Version and Scheme S commits (`A` + `R`).** `A` bumps `pyproject.toml`,
  `src/checkwash/__init__.py` and `uv.lock` to `0.13.0`, keeping
  `release/advertised.toml`, the `README.md` install commands and Action pin,
  and `src/checkwash/doctor.py`'s base pin at `v0.12.0`
  (`532f74ab070a924b23e2cc70e5d0091a05d8401d`) until step 8, and `R` sets
  `doctor`'s `_OWN_ACTION_PIN` to `A` via `tools/own_action_pin.py write`.
  Trusted collector ref: `review/collector-d-013-20261116`
  (`978d015e1d614448eb393403601cbb3b0f33f79a`).
- **R29 fixed-corpus comparison, uvloop diagnostic, and 0.13.0 documentation.**
  Same-host PJU comparison (`LAPTOP-01AGNPJU`, Windows 11, CPython 3.11.9,
  `HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`) of published `v0.12.0`
  `checkwash.pyz` (`4ef6eda2...`) against final `main` `978d015e` `src/` tree
  `cfd205d7b913d867e9e3452841978ae38a01e77e`: `3,600 / 3,600` identical exit
  codes and `--format json` reports (`0` moves, `0` report differences; Python
  `1,726` pass / `74` block, JS/TS `1,748` pass / `50` block / `2`
  symlink-refusal errors with identical stderr; `checkwash-lab` `ec15f59d`),
  uvloop diagnostic `3 / 3` pass with `findings: []` (`59e941a1...`), and
  source-bound `docs/d176-cost-disposition-0.13.0.md`,
  `docs/releases/v0.13.0-public-launch.md`, `docs/KNOWN-ISSUES-v0.13.0.md`
  (including `D-211`/`D-213` key movement, `B6` `embedding.md` note and
  `PERF613-2`), `docs/RELEASING.md`, `benchmarks/javascript-replay/results.md`
  (Run 8) and release labels across `README.md`, `SECURITY.md`,
  `docs/embedding.md`, `docs/stability.md`, `docs/enterprise.md` and
  `docs/releases/README.md`.

## 2026-11-16: 0.13, strict inert EOF-append narrowing on repository-root `CLAUDE.md`, `O(N)` list-container scan, `.gwcase` pins and `AGENTS.md` L1 boundary expansion (D-213)

Addresses `Q1` (`GD211-01..06`, Option 甲-1), `Q3` (3-run median timing bounds in
`test_claude_md_additive.py`) and `Q6` (`DG-04`, `AGENTS.md` L1 boundary
expansion) from the 2026-11-15–16 external read-only audit (Phase 2 L1 PR 5;
heading date Asia/Taipei, timestamps UTC). Human authorization provenance:
Nelson's `2026-11-15T14:24:06Z` instruction in session `5472d923` verbatim
「開一個session 對整體做一次檢查 沒問題後就發」 and `2026-11-15T17:34:59Z` ruling in session
`c8f1073f` verbatim 「可以 照你的建議走 開個新session? 需要用到goal 或其他技能嗎」 plus the `/goal` handover in session `3da7dc8a` and Gate 1 verbatim L1 diff approval at `2026-11-16T11:45:56Z` verbatim 「核可並合併」 (agent scope interpretation: authorizes pushing and merging #620 `0a010788` and `D-213` onto `main` once PJU compact receipts pass):

- **Strict inert EOF-append narrowing and `O(N)` staircase fix
  (`src/checkwash/guardrail_additive.py`, `src/checkwash/gating.py`, `SPEC.md`,
  `README.md`, `docs/KNOWN-ISSUES-next.md`).** Narrows `is_pure_line_addition`
  so repository-root `CLAUDE.md` keeps `GUARDRAIL_TOUCHED` at `warn`
  (`GUARDRAIL_ADDITIVE`) only when `after` starts with the exact unmodified
  `before` line sequence, at least one blank line separates `before`'s last
  non-blank line from the added block's first non-blank line, both sides end
  cleanly (`eof_clean == True`), `after` does not newly start with `---`/`+++`,
  both `_frontmatter_end` and Claude Code's non-anchored `/^---\s*\n([\s\S]*?)---\s*\n?/`
  slice match verbatim (`GD211-01`), no added line holds `---`, `3+` consecutive
  `` ` ``/`~`, `<!--`/`-->` or `[label]:` (`GD211-02`), and zero newly
  introduced `Cf`/`Default_Ignorable` code points (`U+FE00..FE0F`,
  `U+E0100..E01EF`, Hangul fillers `U+115F..1160`, `U+3164`, `U+FFA0`) appear
  (`GD211-03`). Caches `(cached_ws_pos, cached_end_col)` in
  `_match_open_containers` (`GD211-04`, `repro-52` `29.48s -> 1.07s`, `repro-53`
  `57.23s -> 0.70s`).
- **L1 boundary, `.gwcase` pins, 3-run median timing bounds and base-side v2
  allow keys (`AGENTS.md`, `DECISIONS.md`, `.greenwash/allow.toml`,
  `tests/cases/guardrail_claude_md_*.gwcase`,
  `tests/test_claude_md_additive.py`).** Adds all of `src/checkwash/gating.py`
  and `src/checkwash/guardrail_additive.py` to `AGENTS.md` `Agent-READ-ONLY`,
  records `D-213`, switches single-run wall-clock bounds in
  `test_claude_md_additive.py` to 3-run medians (`< 3.0s` / `< 5.0s`), adds `51`
  audit regression cases plus `5` `.gwcase` fixtures, and pre-lands the `44`
  content-bound v2 exemptions (`1` `GUARDRAIL_TOUCHED` on `AGENTS.md` + `43`
  `EXPECTED_VALUE_CHANGED` on `tests/test_claude_md_additive.py`) in a preceding
  atomic `.greenwash/allow.toml` commit. Documented suite count: `23,303 ->
  23,358` (`+55`).

Checked on LAPTOP-01AGNPJU (`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`) across all
`44` `cwrev1115/work/guardrail-d211/repro-*` repositories, `tests/gates`, and
the pre-release Windows + WSL Linux Python `3.11`/`3.12`/`3.13` six-leg gate.
Not run (`NOT_RUN`) locally: macOS.

## 2026-11-16: 0.13, direct unit checking on set-aside test/conftest helper modules, `on_engine_error = "block"` `exit 2` on `importer_gaps`, and pre-release threat-model/spec/governance alignment (D-212)

Addresses `Q2` (`DET13-01`, `DET13-02`, `DET13-05`), `Q4(1)(2)` (`DET13-03`,
`RC-1`, `RC-2`) and `Q6` (`DG-01`, `DG-02`, `DG-03`, `DG-06`) from the
2026-11-15–16 external read-only audit (Phase 2 L1 PR 4; heading date
Asia/Taipei, timestamps UTC). Human authorization provenance: Nelson's
`2026-11-15T14:24:06Z` instruction in session `5472d923` verbatim 「開一個session
對整體做一次檢查 沒問題後就發」 and `2026-11-15T17:34:59Z` ruling in session
`c8f1073f` verbatim 「可以 照你的建議走 開個新session? 需要用到goal 或其他技能嗎」 plus
the `/goal` handover in session `3da7dc8a` and Gate 1 verbatim L1 diff approval
at `2026-11-16T11:45:56Z` verbatim 「核可並合併」 (agent scope interpretation:
authorizes pushing and merging `D-212`'s L1 changes in `SPEC.md`,
`THREATMODEL.md`, `DECISIONS.md` and `gating.py` onto `main` once the PJU
compact receipt passes):

- **Direct `helper_function` unit checking on set-aside helper modules
  (`src/checkwash/frontends/python/expected_provenance.py`,
  `src/checkwash/engine_ir_intake.py`, `src/checkwash/engine_ir_files.py`,
  `src/checkwash/frontends/python/frontend.py`,
  `src/checkwash/frontends/python/frontend_file_parse.py`,
  `src/checkwash/ir/diffalign.py`, `src/checkwash/engine.py`,
  `src/checkwash/gating.py`, `src/checkwash/oracle_credit.py`,
  `src/checkwash/engine_ir_resolvers.py`,
  `src/checkwash/engine_ir_credits.py`).** Set-aside test and conftest modules
  now parse their top-level non-`test*` (and non-`pytest_*` on conftest)
  functions as `kind="helper_function"` units and run `REPAIR_REFUSED_PYTHON`
  unit detectors directly (`ASSERT_WEAKENED`, `ASSERT_REMOVED`, `TEST_DISABLED`,
  `TOLERANCE_LOOSENED`, stand-ins and subject/derived rewrites, requiring
  `unit.before.assertions` on `SHAPE_UNIT_REMOVED`), while excluding
  `helper_function` units from cross-file, arrival, restructure, duplicate and
  move credits. Updates the note to `analysis incomplete: <reason>, so unchanged
  tests that import <helpers> were not read; each helper's own functions were
  checked, not expected values resolved through its callers`.
- **`[gate] on_engine_error = "block"` fail-closed `exit 2` in `check`
  (`src/checkwash/cli.py`).** Returns `exit 2` with empty stdout in non-`hook-json`
  `check` runs whenever `report_context.importer_gaps` is non-empty under
  `on_engine_error = "block"`, while keeping `exit 0` and `systemMessage` in Stop
  `hook-json`.
- **Protected L1 and doc updates (`SPEC.md`, `THREATMODEL.md`,
  `benchmarks/FAILURES.md`, `DECISIONS.md`, `docs/embedding.md`,
  `docs/KNOWN-ISSUES-next.md`).** Updates `SPEC.md` §9 (`D-206, D-212` and new
  **Test-shaped files left unparsed (B6, 0.13)** paragraph), updates
  `THREATMODEL.md` row 125 (`**Closed in part (#272).**` with the `DET13-03`
  unchanged-caller cross-file helper skip residual) and row 183 and adds rows
  187 (`RC-1`) and 188 (`RC-2`), regenerates `benchmarks/FAILURES.md` (`87` of
  `207` not closed: `Closed in part` `19 -> 20`, `Closed` `118 -> 117`, `Open by
  design` `+2`), records `D-212` plus the `#607` `gating.apply_gates`
  ratification, `D-209` `15:33:34Z` clarification and `D-210` `SPEC.md §2b`
  corrigendum in `DECISIONS.md`, and updates `docs/embedding.md` and
  `docs/KNOWN-ISSUES-next.md`. Documented suite count: `23,293 -> 23,303`
  (`+10`).

Checked on LAPTOP-01AGNPJU (`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`) across
`test_importer_search_skip.py`, `tests/gates`, `cwrev1115/work/detection-0.13`
`repro-01..04,13,16`, and the pre-release Windows + WSL Linux Python
`3.11`/`3.12`/`3.13` six-leg gate. Not run (`NOT_RUN`) locally: macOS.

## 2026-11-16: 0.13, fail-closed runtime-shadow parsing on deep or unparseable candidate tests and controls

Addresses `R607-01` from the 2026-11-15–16 pre-release audit (`Q4(3)`, non-L1
Phase 1 PR 3; heading date Asia/Taipei, timestamps UTC). Human authorization
provenance: Nelson's `2026-11-15T17:34:59Z` ruling in session `c8f1073f`
verbatim 「可以 照你的建議走 開個新session? 需要用到goal 或其他技能嗎」 and `/goal` handover in
session `3da7dc8a` (agent scope interpretation: zero L1 files modified):

- **Fail-closed runtime-shadow test and control parsing
  (`src/checkwash/shadow_imports.py`, `src/checkwash/shadow_controls.py`,
  `src/checkwash/shadow_providers.py`, `src/checkwash/shadow_models.py`,
  `tests/test_runtime_subject_shadow.py`).** Previously, when a candidate test
  module held a deep expression (`DEEP = 1 + 1 + ... + 1` around `2,933`–`2,950`
  `+` terms on CPython `3.11`), the shallower main pass parsed the file
  (`parse_ok=True`) while `shadow_imports._test_fixture_requests` and
  `_active_test_imports` caught `RecursionError` inside `parse_python` as
  `parsed.parse_ok == False` and returned `set()`, hiding a competing stand-in
  provider (`TEST_PATCHES_SUBJECT`), whereas adjacent depths raised uncaught
  `RecursionError` in `_import_targets` or `ast.parse`. `_test_fixture_requests`
  and `_active_test_imports` now raise `EngineError` whenever `parse_python`
  returns `parse_ok=False` after `ast.parse` succeeds, and `_fixture_bindings`,
  `_test_fixture_requests`, `_active_test_imports`, `_import_targets`,
  `_scope_global_loads`, `_sys_path_roots` and `_extends_package_path` convert
  `(RecursionError, MemoryError)` from `ast.parse` or recursive AST walks into
  `EngineError` (`exit 2` in `check`, non-blocking `not analysed` in Stop
  `hook-json`) while keeping ordinary `SyntaxError`/`ValueError` non-crashing
  and suppressing `SyntaxWarning`/`DeprecationWarning` via `_parse_ast`.
  Documented suite count: `23,289 -> 23,293` (`+4`).

Checked on LAPTOP-01AGNPJU (`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`) across
Windows CPython `3.11.9`, `3.12.14` and `3.13.15` (`test_runtime_subject_shadow`
and `repro-09` boundary scan `N=2930..2966`) and full PJU `3.11.9` compact
receipt (`23,293` tests). Not run (`NOT_RUN`) in the compact receipt: macOS and
full-suite Linux (covered in the pre-release six-leg gate).

#618 merged as `c0c46a2678b4117b3873f56547b3c86f73bea8b6` at
2026-11-15T19:35:41Z, with parents `9ac10fc9` and `c24ad861` and the tree its
receipt verified (`444dd9e4`, `444dd9e42e0904f9f95c49177331b36292da1ac1`).
Nelson's 2026-11-15T17:34:59Z answer, above, approved the merge. Its compact
receipt `e04e7b748973` (`C:\Users\nelson\dev\cw618r1\r\compact-receipt.json`,
`8,672` B) was verified by workflow run 43753120653 dispatched from
`refs/heads/main`, which set the required `checkwash` check (`132931482300`,
GitHub Actions App `15368`).

## 2026-11-16: 0.13, PEP 701 prefixed f-string condensation, quiet Python `SyntaxWarning` parsing and `#613` comment accuracy

Addresses `PERF613-1`, `PERF613-3` and `XPLAT-03` from the 2026-11-15–16
pre-release audit (`Q4(3)`, non-L1 Phase 1 PR 2; heading date Asia/Taipei,
timestamps UTC). Human authorization provenance: Nelson's `2026-11-15T17:34:59Z`
ruling in session `c8f1073f` verbatim 「可以 照你的建議走 開個新session? 需要用到goal 或其他技能嗎」
and `/goal` handover in session `3da7dc8a` (agent scope interpretation: zero L1
files modified; `PERF613-2` single-line long f-string fallback CPU cost on
CPython `3.12` is recorded in `KNOWN-ISSUES-v0.13.0.md` per `Q4(3)`):

- **PEP 701 prefixed f-string condensation guard
  (`src/checkwash/frontends/python/syntax.py`,
  `tests/test_string_chain_syntax.py`).** Uses possessive identifier matching in
  `_NONCHAIN_ATOM_RE` and rejects identifiers immediately followed by quotes or
  identifier continuations in `_condense_complete_nonchain_line`, preventing
  multiline PEP 701 `fr`/`FR`/`rf` replacement fields over `2,048` characters
  from backtracking into `f` + `r"..."` and hiding subsequent module-level string
  chains (`PERF613-1`).
- **Quiet Python `SyntaxWarning` / `DeprecationWarning` parsing
  (`src/checkwash/frontends/python/syntax.py`,
  `src/checkwash/frontends/python/frontend.py`, `src/checkwash/engine.py`,
  `tests/test_string_chain_syntax.py`).** Wraps `syntax.parse_module` /
  `_recover` / `_literal_tree`, `frontend.parse_python` and `engine.build_ir` in
  `warnings.catch_warnings()` ignoring `SyntaxWarning` and `DeprecationWarning`,
  so analysed Python files with invalid escape sequences (such as `"\d+"`) print
  zero warning lines to `stderr` across Python `3.11`, `3.12` and `3.13`
  (`XPLAT-03`).
- **`#613` `tokenize` comment accuracy
  (`src/checkwash/frontends/python/syntax.py`).** Clarifies that condensing lines
  over `2,048` characters bounds per-statement `_Tok` retention across all Python
  versions while avoiding per-token full-line `TokenInfo.line` copies observed on
  older CPython `3.12` patch releases such as Ubuntu 24.04's `3.12.3` (fixed by
  `3.12.14` / `3.12.16` and `3.13.18`, verified locally on `LAPTOP-01AGNPJU`,
  `PERF613-3`). Documented suite count: `23,283 -> 23,289` (`+6`).

Checked on LAPTOP-01AGNPJU (`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`) across
isolated Windows CPython `3.11.16`, `3.12.14`, `3.13.15` (`test_string_chain_syntax`,
`repro-02-613-e2e`, `repro-03-syntaxwarning`), WSL Ubuntu 24.04 `3.12.3` /
`3.12.16` / `3.13.18` `TokenInfo.line` probes, and full PJU `3.11.9` compact
receipt (`23,289` tests). Not run (`NOT_RUN`) in the compact receipt: macOS and
full-suite Linux (covered in the pre-release six-leg gate).

#617 merged as `9ac10fc92845602db498e07699d938004e863b59` at
2026-11-15T18:59:19Z, with parents `91676bb1` and `f1afdc21` and the tree its
receipt verified (`42c1f936`, `42c1f936c884217df9171403dd7fc7604394f893`).
Nelson's 2026-11-15T17:34:59Z answer, above, approved the merge. Its compact
receipt `6461f9225203` (`C:\Users\nelson\dev\cw617r1\r\compact-receipt.json`,
`8,669` B) was verified by workflow run 43749458658 dispatched from
`refs/heads/main`, which set the required `checkwash` check (`132920151429`,
GitHub Actions App `15368`).

## 2026-11-16: 0.13, pre-release module-naming, timing-bound, receipt-prose and provenance hygiene

Addresses the non-L1 module-naming, test-hygiene, receipt-prose and governance
record items from the 2026-11-15–16 read-only pre-release audit ahead of
`v0.13.0` (`R607-03..05`, `XPLAT-01`, `XPLAT-02`, `XPLAT-04`, `RC-1`, `RC-2`,
`RC-4`, `DG-01`, `DG-04`, `DG-05`, `DG-06`; heading date Asia/Taipei, timestamps
UTC). Human authorization provenance: in session `5472d923` at
`2026-11-15T14:24:06Z` Nelson instructed verbatim 「開一個session 對整體做一次檢查
沒問題後就發」; after the external read-only audit reported `0.13` pre-release
findings, Nelson answered `Q1`–`Q6` in session `c8f1073f` at
`2026-11-15T17:34:59Z` verbatim 「可以 照你的建議走 開個新session? 需要用到goal 或其他技能嗎」
and launched session `3da7dc8a` (`/goal`) at `2026-11-15T17:37:45Z` delegating
Phase 1 atomic non-L1 PR merges via compact PJU receipts on **Antigravity**
(agent scope interpretation: zero L1 files touched here; `1.0` remains
`NOT_MET` and downstream `smallestlie` / `checkwash-corpus` re-pins remain out
of scope):

- **Module renames and B6 `src/` production-file guard
  (`src/checkwash/frontends/python/table_oracles_carriers.py`,
  `src/checkwash/unanalysed_test_files.py`).** Renames `table_oracles_test.py`
  to `table_oracles_carriers.py` so default `*_test.py` discovery never treats
  the production helper module as a pytest test file (`R607-03`), and renames
  `unanalysed_tests.py` to `unanalysed_test_files.py` while requiring `prod`-role
  Python files outside `_TEST_DIRS` (`src/api_spec.py`, `src/schema_tests.py`,
  etc.) to declare `test_*` functions/methods or `Test*`/`TestCase` classes
  before emitting the B6 `analysis incomplete` note, preserving Django
  `src/shopcart/tests.py` and `[roles].test` overrides (`XPLAT-04`). Updates
  `README.md` (`## Know the limits`) and `docs/KNOWN-ISSUES-next.md` accordingly.
- **Median timing bound, quiet-parse scan, stale paths and route refusal
  (`tests/test_unanalysed_test_files.py`, `tests/test_issue319_quiet_parse.py`,
  `tests/test_receipt_execution_routes.py`, `tools/handover_review_mutants.py`,
  `.github/workflows/r1-seen-cost.yml`).** Replaces the single-sample wall-clock
  check in `test_unanalysed_test_files.py` with a 3-run median
  (`statistics.median`, `< 3.0` s; `test_claude_md_additive.py`'s timing update
  accompanies `guardrail_additive.py` in D-211's narrowing PR, `XPLAT-01`),
  expands `test_issue319_quiet_parse.py` across `engine*.py` (`R607-04`),
  updates post-`#607` module/method references in
  `tools/handover_review_mutants.py` and `.github/workflows/r1-seen-cost.yml`
  (`R607-05`), and adds `collect_compact` and `--compact` CLI unsupported-host
  refusal assertions (`XPLAT-02`). Documented suite count unchanged: `23,283`.
- **Receipt-bridge summary, ruleset scope and governance provenance
  (`tools/pju_receipt_bridge.py`, `.github/workflows/quality-candidate-intake.yml`,
  `docs/testing-on-pju.md`, `docs/pju-receipt-bridge.md`,
  `docs/pju-release-handoff.md`, `docs/RELEASING.md`, `STATE.md`).** Clarifies
  that `publish_compact` verifies Git source/contract/closure digest consistency
  of a maintainer-admitted self-reported PJU compact receipt rather than
  re-executing tests or builds on the hosted runner (`RC-2`), notes that GitHub
  ruleset `22032046` binds required context `checkwash` by context name and
  GitHub Actions App ID (`15368`) rather than by workflow file (`RC-1`), updates
  stale "four required PR checks" prose to distinguish ordinary-PR compact single
  `checkwash` checks from legacy/release-PR four-`B.CONTEXTS` checks (`RC-4`,
  `DG-06`), and completes `#607/#610/#612/#613/#614/#615` merge, verbatim
  provenance, `#607` recursion-frame boundary and `#613` CPython `3.12.3` /
  targeted-WSL records below (`DG-01`, `DG-04`, `DG-05`).

Checked on LAPTOP-01AGNPJU (`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`, Windows 11
CPython `3.11.9`) across full `pytest -n 16` (`23,283` tests), `checkwash check`
dogfood (`--fail-on high`: `verdict=pass`, 0 critical/high findings), and
compact PJU digest receipt (`collect_pju_receipts.py --compact`). Not run
(`NOT_RUN`): macOS, Linux, and other platforms.

#616 merged as `91676bb10de396e7e7df2191a4dedcd5e2bb782e` at
2026-11-15T18:10:49Z, with parents `a5cfb161` and `13c1c44e` and the tree its
receipt verified (`52d10717`, `52d10717adcd5a602f84c234e841ae336de93b9c`).
Nelson's 2026-11-15T17:34:59Z answer, above, approved the merge. Its compact
receipt `5de31016835d` (`C:\Users\nelson\dev\cw616r1\r\compact-receipt.json`,
`8,651` B) was verified by workflow run 43747021117 dispatched from
`refs/heads/main`, which set the required `checkwash` check (`132912683839`,
GitHub Actions App `15368`).

## 2026-11-15: 0.13, public-facing `README.md` layering before `v0.13.0`

Prepares `README.md` ahead of the `v0.13.0` build (so PyPI `0.13.0`'s baked
package description receives the layered layout directly, following Nelson's
2026-11-15 Step 1 confirmation):

- **Badge and related-project links (`README.md`).** Removes the top-row
  `ci.yml` badge (`ci.yml` has been `disabled_manually` since `2026-10-23`),
  retaining the PyPI and Apache-2.0 badges, and updates the footer's related
  project link from `checkwash-corpus` and `smallestlie` (scheduled to move to
  private visibility) to the public execution satellite `checkwash-prove`.
- **Gentle front/back-stage layering (`README.md`).** Keeps the three
  quickstarts (Claude Code hooks, single-file `checkwash.pyz` / CLI, required
  GitHub Action snippet and ruleset command), the finding/exemption walkthrough,
  the `## Know the limits` anchor and four core limits, the `6 of 60` refactor
  summary, and all test-pinned version, workflow, `git rev-parse`, demo-count
  and historical-sweep strings intact, while folding guardrail TOML overrides,
  repair-evidence/JS-table/historical-refactor provenance, oversized-file rules,
  and `A`-vs-`M` release-tag geometry / `<= v0.7.0` Action advisory details into
  collapsible `<details>` disclosures (zero `src/` or `tests/` changes;
  documented suite count unchanged: `23,283`).

Checked on LAPTOP-01AGNPJU (`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`, Windows 11
CPython `3.11.9`) across documentation, packaging, state, link and doctor
contract suites, `checkwash check` dogfood (`--fail-on info`), and compact PJU
digest receipt (`collect_pju_receipts.py --compact`). Not run (`NOT_RUN`):
macOS, Linux, and other platforms.

#615 merged as `a5cfb1615065b57b240b589a0976d93c94b4e81c` at
`2026-11-15T16:09:14Z`, with parents `eece00f3` and `87dc226b` and the tree its
receipt verified (`ad695e75`, `ad695e7523dde0f6d5d567baae3164d73e03299f`). Human
authorization provenance (session `1f0e5cb3`): Nelson answered verbatim
「可以 就照你的建議」 at `2026-11-15T15:11:58Z`, selected the Step 1 `README.md`
gentle-layering option at `15:13:41Z`, instructed verbatim
「公開頁面只放成熟的專案 其餘的改私人」 at `15:14:20Z`, and confirmed the 4-public-repo
list (`checkwash`, `checkwash-prove`, `starry-night-3d`,
`taipei49314.github.io`) at `15:16:14Z` (agent scope interpretation: merge Step
1's non-L1 `README.md` layering PR after compact PJU receipt verification,
without starting the `0.13.0` release). Its compact receipt `959b2a35145a`
(`C:\Users\nelson\dev\cw615r1\r\compact-receipt.json`, `8,655` B) was verified
by workflow run `43733705906` dispatched from `refs/heads/main`, which set the
required `checkwash` check (`132871812828`, GitHub Actions App `15368`).

## 2026-11-15: 0.13, cross-platform compact collector helper test isolation

Pre-release Linux verification on `LAPTOP-01AGNPJU` WSL2 (`Ubuntu 24.04.4 LTS`,
CPython `3.12.3`) found that
`tests/test_pju_compact_receipt.py::test_collect_compact_binds_admitted_git_and_restores_helpers`
called `collector_mod.collect_compact(args)` against the ambient host route,
`sys.executable`, `shutil.which("git")`, un-resolved `tmp_path`, and default
Windows `SystemRoot` / `ProgramFiles` paths, failing on Linux/macOS with
`ValueError: authorized local Windows host required` (and otherwise failing
`action.absolute_path` / `clean_environment` on POSIX venv symlinks, `/bin ->
usr/bin` or Homebrew `git` symlinks, macOS `/var -> private/var` temporary
roots, and unset `C:\Windows` / `C:\Program Files`):

- **Cross-platform fixture isolation (`tests/test_pju_compact_receipt.py`).**
  Resolves `tmp_path` and `git` via `os.path.realpath`, stubs
  `action_mod.execution_route`, and materializes regular `venv/Scripts/python.exe`,
  `SystemRoot` (`system/System32`) and `ProgramFiles` (`program/Git/usr/bin`)
  paths under the resolved temporary directory (matching
  `tests/test_replay_pju_action.py`), while preserving every assertion on
  admitted `git` binding and helper restoration unchanged (zero `src/` changes;
  documented suite count unchanged: `23,283`).

Checked on LAPTOP-01AGNPJU (`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`) across
Windows 11 CPython `3.11.9` (full `23,283`-test compact receipt) and WSL2
`Ubuntu 24.04.4 LTS` CPython `3.12.3` (targeted `test_pju_compact_receipt.py`
on the PR, followed after merge by a full `23,283`-test WSL2 `3.12.3` suite run
on `eece00f3` with `0` failures), `checkwash check` dogfood (`--fail-on high`:
`critical=0 high=0 warn=0 info=0 verdict=pass`), and compact PJU digest receipt
(`collect_pju_receipts.py --compact`). Not run (`NOT_RUN`): macOS, Linux Python
3.11, and Python 3.13.

#614 merged as `eece00f3e7a566b5ec927e0c605a2e3081705bea` at
`2026-11-15T13:56:11Z`, with parents `66c4a9b1` and `21d9778d` and the tree its
receipt verified (`40b741d6`, `40b741d63e12a5150311833367f67ecaa77b5d09`). Human
authorization provenance (session `5472d923`): Nelson asked verbatim
「現在驗證還有linux沒驗過對吧」 (`2026-11-15T11:36:43Z`), answered verbatim 「對 先跑過」
(`11:38:20Z`), and confirmed the `#613 -> #614` remediation-and-merge sequence
verbatim 「好 照這個順序」 at `2026-11-15T12:51:08Z` (agent scope interpretation:
merge non-L1 cross-platform test isolation fix `#614` after compact PJU receipt
verification). Its compact receipt `a73ae9e81208`
(`C:\Users\nelson\dev\cw614r1\r\compact-receipt.json`, `8,641` B) was verified
by workflow run `43721445044` dispatched from `refs/heads/main`, which set the
required `checkwash` check (`132834305786`, GitHub Actions App `15368`).

## 2026-11-15: 0.13, CPython 3.12.3 single-line `tokenize` memory DoS and OOM fix

Pre-release Linux verification on `LAPTOP-01AGNPJU` WSL2 (`Ubuntu 24.04.4 LTS`,
CPython `3.12.3`) uncovered an `O(K * L)` memory and CPU explosion on CPython
`3.12.3` (`_tokenize.TokenizerIter`, PEP 701; CPython fixed the per-token full
line allocation upstream by `3.12.14`, though single-line megabyte f-strings on
`3.12` still incur multi-minute C tokenizer cost as in `0.12.0`), which on
`3.12.3` allocated a fresh `str` copy of the entire physical line
(`token.line`) on every yielded `TokenInfo`:

- **Bounded-memory recursion recovery (`src/checkwash/frontends/python/syntax.py`).**
  `_Chain` and `statement` store compact `_Literal` / `_Tok` records without
  retaining `TokenInfo.line`, and `_chains` wraps `io.StringIO(source).readline`
  so physical lines up to `2,048` characters pass unchanged to
  `tokenize.generate_tokens` while longer physical lines at verified logical
  boundaries either pre-scan `NAME = STRING (+ STRING)+` in `O(L)` time or
  condense complete/quote-free non-chain lines to lexically equivalent stubs
  preserving indentation, brackets, multiline state and `ast.parse` diagnostics.
  On CPython 3.12.3, `tests/gates/test_perf.py::test_pathological_file_does_not_hang`
  (`200 KB` and `1 MB` single-line `x = 1+1+...+1`) drops from `40 GB`–`1 TB`
  allocation (`OOM` / `> 40s`) to `< 16 MiB` and `< 0.2s`.
- **Test retention and regression coverage (`tests/test_string_chain_syntax.py`).**
  `test_original_deep_pair_has_every_literal_operator_and_source_position` clears
  `token.line` via `token._replace(line="")` while preserving every existing
  assertion, and adds `12` collected tests covering forced fallback on the `1 MB`
  `9,899`-literal chain under `tracemalloc`, `200 KB`–`1 MB` non-chain rejection
  time/memory bounds, and multiline string, parenthesis, continuation,
  indentation, comment and Unicode identifier boundaries (documented suite count:
  `23,283`).

Checked on LAPTOP-01AGNPJU (`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`) across
Windows 11 CPython `3.11.9` (full `23,283`-test compact receipt) and WSL2
`Ubuntu 24.04.4 LTS` CPython `3.12.3` (`MemoryMax=1G`, targeted
`tests/gates/test_perf.py` and `tests/test_string_chain_syntax.py` suites),
`checkwash check` dogfood (`--fail-on high`: `critical=0 high=0 warn=4 info=0
verdict=pass`), and compact PJU digest receipt (`collect_pju_receipts.py
--compact`). Not run (`NOT_RUN`): macOS, Linux Python 3.11, and Python 3.13.

#613 merged as `66c4a9b1e5f8af9510d5d2dc9d8d3f85c814f8aa` at
`2026-11-15T13:31:36Z`, with parents `04473e4d` and `d5e4360b` and the tree its
receipt verified (`64ba4388`, `64ba4388a6fa915d27164f7c2e8200f155fd2ff3`). Human
authorization provenance (session `5472d923`): Nelson asked verbatim
「現在驗證還有linux沒驗過對吧」 (`2026-11-15T11:36:43Z`), answered verbatim 「對 先跑過」
(`11:38:20Z`), and confirmed the `#613 -> #614` remediation-and-merge sequence
verbatim 「好 照這個順序」 at `2026-11-15T12:51:08Z` (agent scope interpretation:
merge non-L1 `syntax.py` `3.12.3` memory/OOM fix `#613` after compact PJU
receipt verification). Its compact receipt `91dce3d62e2f`
(`C:\Users\nelson\dev\cw613r1\r\compact-receipt.json`) was verified by workflow
run `43719291035` dispatched from `refs/heads/main`, which set the required
`checkwash` check (`132827771431`, GitHub Actions App `15368`).

## 2026-11-15: 0.13, protected threat-model, decision-log and gate-README text corrections (L1)

Consolidates the remaining protected L1 text updates from the 2026-11-10
re-review (`1-python-漏抓.md` `PM-04`, `PM-05`, `PM-08`; `6-文件與新手.md` `ND-05`;
`7-PR598-文件修正審查.md` "Other places … (item 8)"; `00-重審總結與規劃.md` §5 `1-5` and §6
`A.2`) and Nelson's 2026-11-15 Phase 3 handoff into one L1 pull request (#612,
approved by Nelson at 2026-11-15T10:44:37Z and 10:47:09Z):

- **`THREATMODEL.md` and `benchmarks/FAILURES.md`.**
  - Item 2 (`Out-of-band tampering`): replaces the stale 0.12.0 wording (`a
    file that is often git-ignored`) with the [D-205](DECISIONS.md) (0.13)
    behaviour (`hook install` adds `.claude/settings.local.json` to the
    repository's `info/exclude` file when Git neither tracks nor ignores it; in
    0.12.0 a repository without an ignore rule of its own left the file
    unignored, and whenever Git ignores or excludes it an agent edit to the
    handlers there shows in no diff).
  - Row 2: replaces `none is adjudicated (D-199)` with `#212`'s 2026-11-08
    blind rating and arbitration of the 11 JS/TS commits ([D-203](DECISIONS.md),
    row 131: 10 should pass, 7 of them honest changes whose tests now check
    less, 1 is unclear and none should block, a selected set and not a
    false-block rate), while the 7 Python commits and D-088's 53 (#464's 11
    among them) remain unadjudicated.
  - Rows 7, 31 and 40: updates `**Closed**` to `**Partly closed**` to state the
    actual covered vs open spellings (`PM-04`: `setup_skip_controls` requires a
    `conftest.py` holding nothing besides non-star imports, plain unannotated
    parameterless bare-`yield` fixtures with at most boolean `autouse` and an
    unannotated synchronous `pytest_runtest_setup`, leaving real-conftest
    `pytest_runtest_setup`, guarded `pytest_runtest_setup` (including item-name
    guards), `pytest_runtest_call` skips/xfails (wrapped or unwrapped) and
    `pytest_runtest_makereport` / `pytest_runtest_logreport` `'skipped'` open;
    `PM-05`: `_module_skip_markers` and `_test_attr_disabled` read only direct
    module/class statements, leaving compound statements, module-level `raise
    SkipTest` / `raise pytest.skip.Exception` and post-class / post-`def`
    `__test__ = False` open).
  - Row 105 item `(6)`: updates `closed` to `partly closed` (`PM-08`:
    `collection_inventory._candidates` counts only top-level test functions and
    base-less test classes without `__init__` or `__new__`, leaving
    `unittest.TestCase` and subclassed test classes uncounted across `addopts`
    target narrowing and first-config `-k`/`-m` selectors, `--deselect <node
    id>`, `--ignore` and collection settings).
  - Row 157: updates the two pre-closure `D-152` sentences to record that
    v0.9.0's combined sweep moved no verdict over its 4,818 rows and `#428`
    closed as fixed on 2026-11-08 ([D-203](DECISIONS.md)), with D-152's
    targeted JS table scan and replay moved to `#504` (after `1.0`).
  - `benchmarks/FAILURES.md`: regenerated via `benchmarks/make_failures.py`
    (`205` bypasses, `84` not closed: `Closed in part` `16 -> 19`, `Closed`
    `121 -> 118`).
- **`DECISIONS.md` (`D-203` `**Approval.**`).** Corrects the question timestamp
  from `2026-11-12T14:08:05Z` to `2026-11-12T14:07:42Z` while keeping Nelson's
  `14:08:05Z` `「核可並合併」` answer timestamp, matching `STATE.md`'s `#597`
  record.
- **`tests/gates/README.md` (item 2, `Cross-platform`).** Replaces the
  present-tense statement (`the byte-compare CI job — every OS × Python emits
  byte-identical corpus findings`) with the actual state since 2026-10-23:
  `ci.yml` (`byte-compare`) is disabled, pull requests run on one Windows host
  (LAPTOP-01AGNPJU, Python 3.11, `checkwash-pju-tests` / [D-209](DECISIONS.md)),
  and each release runs `release-hosted.yml` (`macos-latest` and
  `ubuntu-latest` × Python 3.11–3.13, [D-204](DECISIONS.md)), checking
  byte-identical `corpus-findings.json` outputs across its six source legs and,
  when run, against the PJU six-leg batch's `SHA256`, while a single-run
  nine-leg comparison across all three OSes is not executed.

Zero `src/` or test changes (documented suite count unchanged: `23,271`).
Checked on LAPTOP-01AGNPJU (`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`, Windows
CPython 3.11.9) across full `pytest -n 16` (`23,271` tests), `checkwash check`
dogfood (`--fail-on high`: `verdict=pass`, 0 critical/high findings), and 1
independent adversarial read-only review sub-agent across 2 rounds (all findings
resolved: `conftest_skip_hook_pos` pin placement, `pytest_runtest_setup`
signature/decorator/guard bounds and wrapped-or-unwrapped `pytest_runtest_call`
skip/xfail scope in row 7, empty-head-run abort and first-config `--deselect` /
`--ignore` / collection-setting scope in row 105 item 6, and #611's
`DECISIONS.md` `4b001c12` provenance note in `STATE.md`, re-verified clean by
the reviewer); Nelson approved `THREATMODEL.md`, `DECISIONS.md` (`D-203`) and
`tests/gates/README.md` (L1) on #612 (`b9f86a45`,
`b9f86a457e016bc123cf36f2d3f922b290d347e1`, asked at 2026-11-15T10:43:41Z in
session `fa98badb`, answered 「可以核可 但是開個新session?」 at
`2026-11-15T10:44:37Z` in session `fa98badb` and formally confirmed in session
`5472d923` at `2026-11-15T10:47:09Z` verbatim 「接手 checkwash Phase 3 收尾：我已核可 draft
PR `#612`（`b9f86a457e016bc123cf36f2d3f922b290d347e1`）的受保護 L1 文字變更（`THREATMODEL.md`、
`DECISIONS.md` `D-203`、`tests/gates/README.md`），請完成 `#612` 的核可紀錄更新、輕量 PJU
收據驗證與合併。」, with `THREATMODEL.md`, `DECISIONS.md` and
`tests/gates/README.md` kept byte-identical to `b9f86a45`), and the pull
request's description and hosted `checkwash` check record its compact PJU
digest receipt (`collect_pju_receipts.py --compact`: `53efaee39b12` in `cw612r1`,
workflow run `43707619674`, check run `132792231488`). Not run (`NOT_RUN`):
macOS, Linux, and other platforms.

#612 merged as `04473e4da16d68324c5c63a42b843312c8d529dd` at
`2026-11-15T11:14:01Z`, with parents `bce7c8d3` and `1636fe90` and the tree its
receipt verified (`6d51a10a`, `6d51a10a87d023bf145020b53c4f010c162c1e35`).

## 2026-11-15: 0.13, pure line additions to `CLAUDE.md` stay at `warn` (D-211)

The 2026-11-10 re-review's `ND-01` (`repro-13`): appending a housekeeping bullet
to a tracked repository-root `CLAUDE.md` whose existing testing rule was
untouched fired `GUARDRAIL_TOUCHED` at `critical` (`META`), blocking `checkwash
check`, the Claude Code Stop hook (`decision = "block"`), and range-mode CI.
Following Nelson's `2026-11-11T02:44:43Z` `G2 b` direction answer and
`2026-11-15` Phase 3 handoff, [D-211](DECISIONS.md) (L1, approved by Nelson at
`2026-11-15T09:34:17Z` with `SPEC.md` §4/§5 and `src/checkwash/gating.py`, #611)
keeps pure line additions to repository-root `CLAUDE.md` at `warn` while
escalating every deletion, edit, reordering or Markdown / HTML / frontmatter
wrapping or re-contextualization of existing lines to `critical`:

- **Linear-time Markdown-aware pure-addition check
  (`src/checkwash/guardrail_additive.py`, `src/checkwash/engine_ir_files.py`,
  `src/checkwash/ir/model.py`).** `is_pure_line_addition` validates strict UTF-8
  without NUL bytes or lone `\r`, rejects newly added `HIDDEN_UNICODE` / Unicode
  `Cf` format characters and non-LF Unicode line/paragraph separators, requires
  strictly more lines (`len(after_lines) > len(before_lines)`) and line-for-line
  unchanged YAML/TOML frontmatter, and verifies in linear time (`O(N)`) that
  every `(line_text, markdown_context)` entry of `before` survives as an ordered
  subsequence of `after` across CommonMark fenced code blocks (top-level,
  blockquoted or list-prefixed / list-continued with 4-column tab stops,
  separating opening delimiter, code interior and matching closing delimiter with
  `O(1)` length checks), Phase-1 §4.6 rules 1–5 HTML blocks, paragraph-scoped
  multi-line inline backtick code spans with §2.4 `\` escapes, HTML comments
  (`<!-- ... -->`), raw HTML blocks / declarations / PIs / CDATA (`<pre>`,
  `<script>` 3-state, `<style>`, `<textarea>`, `<iframe>`, `<noembed>`,
  `<noframes>`, `<noscript>`, `<title>`, `<xmp>`, `<listing>`, `<plaintext>`,
  `<!...>`, `<?...?>`, `<![CDATA[...]]>`), trie-interned open HTML element
  stacks (ignoring bogus `/>` on non-void HTML tags, restricting implied closes
  to HTML5 §13.2.6.3 tags, poisoning unclosed inline/container HTML across
  boundaries, and tracking paired custom elements) and multi-line
  quoted/unquoted tag attributes, CommonMark §4.7 link reference definitions,
  frontmatter, and interleaved blockquote/list, Setext-heading, 1+-column
  GFM-table and indented-code block continuation.
  `engine_ir_files._record_non_prod_role_change` records `"CLAUDE.md"` on
  `DiffGlobals.guardrail_files_additive` (`IR_VERSION = 3`, `FINDINGS_VERSION =
  2` unchanged) only for non-rename `status == "modified"` changes whose
  resolved role is `guardrail` with no policy-shadow transition.
- **Detector, gating and schema (`src/checkwash/detectors/globals_rules.py`,
  `src/checkwash/gating.py`, `SPEC.md` §4/§5, `docs/findings.schema.json`,
  `docs/embedding.md`).** `gating.py` declares `GUARDRAIL_ADDITIVE_PATHS =
  frozenset({"CLAUDE.md"})` (pinned in `tests/test_oracle_rules_pinned.py`),
  keeps `severity = "warn"` with `escalators = ["GUARDRAIL_ADDITIVE"]` on
  eligible additive `CLAUDE.md` modifications, and escalates all other guardrail
  edits (`AGENTS.md`, `.cursorrules`, `.claude/**`, `.checkwash/**`,
  `.greenwash/**`, renames, deletions, line deletions/edits/reorders, and
  comment/fence/HTML/Markdown wraps) to `critical` (`META`). `detect_guardrail`
  formats `guardrail file extended (CLAUDE.md) — added lines only; existing
  constraints preserved` and binds `"additive": True` into `GUARDRAIL_TOUCHED`'s
  v2 fingerprint context only on that additive path, leaving every non-additive
  `GUARDRAIL_TOUCHED` fingerprint and every existing `.gwcase` expectation
  byte-identical.

`tests/test_claude_md_additive.py` adds `121` collected tests (`5` positive test
functions failing on `main` `aa678cb3` and `116` preserving negative controls
passing on `main`, with `121/121` passing on this branch) and
`tests/test_oracle_rules_pinned.py` adds `1` policy pin (documented suite count:
`23,271`). `README.md`, `docs/KNOWN-ISSUES-next.md`, `docs/embedding.md`,
`SPEC.md` §4/§5 and `DECISIONS.md` (`D-211`) document the contract and
prose-override / `@path` residual. Checked on LAPTOP-01AGNPJU
(`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`, Windows CPython 3.11.9) across full
`pytest -n 16` (`23,271` tests), `checkwash check` dogfood (`--fail-on high`:
`verdict=pass`, 0 critical/high findings), and 1 independent adversarial
read-only review sub-agent across 6 rounds (all findings resolved: `O(N)`
fence-close, autolink, `<script><!--` arrow cache, `bisect_left` §6.6
quote/failure cache, single-pass interleaved container and lazy `text.lower()`
bounds, separated CommonMark §4.6 Phase-1 HTML block continuation vs HTML5
§13.2.5 tokenizer state with block-end and mid-chunk desynchronization
poisoning, paragraph-scoped multi-line inline backtick spans and §2.4 `\`
escapes, list-stack and post-`>` tab-stop container fences, non-void `/>`
rejection, HTML5 `<script>` 3-state machine,
`<iframe|noembed|noframes|noscript|title|xmp|plaintext>`, `<pre>`/`<noscript>`
inner `<template>` handling, `_IMPLIED_END_HTML_TAGS`, §6.6 close-tag attribute
rejection, 8-state HTML5 attribute quote machine, trailing `</` bogus-comment
state, paired custom elements, exact frontmatter preservation, adjacent
blockquote/Setext/1+-col-GFM-table/indented-code re-contextualization, guard
symmetry, `docs/embedding.md`, Unicode `Cf` rejection, and `@path` disclosure,
re-verified clean by the reviewer); Nelson approved `SPEC.md` §4/§5,
`DECISIONS.md` (`D-211`) and `src/checkwash/gating.py` (L1) on #611
(`df5c54a2`) at 2026-11-15T09:34:17Z (asked at 2026-11-15T09:33:12Z, session
`fa98badb`), and the pull request's description and hosted `checkwash` check
record its compact PJU digest receipt (`collect_pju_receipts.py --compact`). Not
run (`NOT_RUN`): macOS, Linux, and other platforms.

#611 merged as `bce7c8d370579bb3e30aa83d229d758e4ba8138c` at
2026-11-15T10:07:02Z, with parents `aa678cb3` and `17653738` and the tree its
receipt verified (`e8fc3d05`, `e8fc3d0537e1c2967ca3a61fa63774d737a6e57e`).
Nelson's 「核可」 at 2026-11-15T09:34:17Z, above, approved `SPEC.md` §4/§5,
`DECISIONS.md` (`D-211`) and `src/checkwash/gating.py` (L1) on #611 (`df5c54a2`;
`SPEC.md` and `src/checkwash/gating.py` unchanged at `4b001c12` and `17653738`,
and `DECISIONS.md` updated at `4b001c12` only to record `D-211`'s `**Approval.**`
paragraph and unchanged at `17653738`, where `17653738` switched
`tests/test_claude_md_additive.py` to load `test_findings_schema.py` via
`importlib.util.spec_from_file_location` under `python -I`). Its compact receipt
`f6ee199dbf02` (`C:\Users\nelson\dev\cw611r2\r\compact-receipt.json`, `8,652` B;
`cw611r1` preserved untouched as the failed collection record on `4b001c12`) was
verified by workflow run 43702329256 dispatched from `refs/heads/main`, which
set the required `checkwash` check (`132776151109`, GitHub Actions App `15368`).

## 2026-11-15: 0.13, report note for changed test-shaped files not analysed (B6)

The 2026-11-10 re-review's `PM-02`, `PM-03`, `F-03` and `F-13`: whole classes
of changed test modules sit outside CheckWash's default unit parse gates
(`roles.collectable` for Python; `is_js_test_file` for JS/TS) and previously
produced `checkwash: no known tampering pattern detected` with no notice when
weakened, skipped or deleted:

- **Classifier and formatter (`src/checkwash/unanalysed_tests.py`).** Adds
  `unanalysed_test_paths`, `is_unanalysed_test_file` and `unanalysed_test_note`,
  identifying uncollected changed Python modules that carry non-default test
  filenames (`tests.py`, `*_tests.py`, `*_spec.py`, `*_specs.py`, and in test
  directories `test*.py` excluding `testing.py`/`testutils.py`/`testhelpers.py`/
  `testsupport.py`, `spec_*.py`, `check_*.py`, `*_check.py`, `*_checks.py`) or
  declare inherited/mixin `test_*` functions/methods or `TestCase` subclasses
  while honoring `__test__ = False` on non-oracle helper classes/modules
  (`PM-02`, `PM-03`), and unparsed JS/TS files with non-default test
  suffixes/names (`.unit`, `.integration`, `.int`, `.e2e`, `.cy`, `.tests`,
  `.specs`, `.playwright`, `.pw`, `*Spec`, `*Specs`, `*Tests`, `spec_*`,
  `spec-*`) or code-position runner imports / linear-time masked test calls
  under test directories (`tests/`, `spec/`, `specs/`, `e2e/`, `cypress/`,
  `playwright/`, `F-03`, `F-13`). Evaluates unsplit renames per side under each
  side's own path and role (including renames into artifact/vendor/non-source
  destinations), and excludes synthetic rename/importer entries, artifacts,
  vendored `site-packages` / `dist-packages`, supervised non-test roles
  (`guardrail`, `ci`, `snapshot`, `lockfile`, `conftest`), `.d.ts` declarations,
  JS config/setup/`__mocks__` helpers, and unparseable `judged_test` Python
  files already reported by `TEST_FILE_UNPARSEABLE`.
- **Pipeline and channel wiring (`report/context.py`, `engine_ir_files.py`,
  `cli.py`, `report/term.py`, `report/sarif.py`).** Records sorted paths on
  `ReportContext.unanalysed_test_files` and emits a single summary line
  (`analysis incomplete: <N> test-shaped file(s) not analysed: ...`, up to 4
  paths plus `and <K> more` with non-printable and Unicode `Cf` format
  characters escaped) on `cli._cmd_check` `stderr`, `report/term.py` (switching
  a zero-finding header to `analysis incomplete; no known tampering pattern
  detected` and rendering after `importer_gaps` and before `unread_sides`), and
  SARIF `toolExecutionNotifications`. Keeps verdicts, exit codes, and machine
  `stdout` of `--format json`, `--emit-ir`, `--format hook-json`,
  `hook pre-tool-use` and `--coverage-report` byte-for-byte unchanged, with zero
  L1 changes (`gating.py` `L1–L682` SHA-256
  `cfa19f5589cf650136e243f9b7404bd1bf5da85a95b4f6d72001b6931f868f5d`).

`tests/test_unanalysed_test_files.py` adds `27` collected tests (`24` failing on
`main` `0ffbeb31` and `3` preserving negative controls; documented suite count:
`23,149`), and `docs/KNOWN-ISSUES-next.md` documents the scope and remaining
residuals. Checked on LAPTOP-01AGNPJU
(`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`, Windows CPython 3.11.9) across full
`pytest -n 16` (`23,149` tests), `checkwash check` dogfood (`--fail-on high`:
`verdict=pass`, 0 critical/high findings), and 1 independent read-only review
sub-agent (all findings resolved: possessive linear-time `_has_js_test_call`
scan, per-side unsplit rename attribution, prod JS byte pre-filter and
code-position runner specifier check, `__test__ = False` opt-out, dead exclusion
cleanup, and Unicode `Cf` escaping); the pull request's description and hosted
`checkwash` check record its compact PJU digest receipt
(`collect_pju_receipts.py --compact`). Not run (`NOT_RUN`): macOS, Linux, and
other platforms.

#610 merged as `aa678cb387606a80ee1ca20587b9c9feffc7f382` at
2026-11-15T06:43:25Z, with parents `0ffbeb31` and `932d4d23` and the tree its
receipt verified (`a67e62cc`, `a67e62cc2d95a80d1de0496a340ddb54fcb1468b`).
Human authorization provenance (session `fa98badb`, `2026-11-15T05:29:32Z`):
Nelson instructed verbatim 「接手 checkwash Phase 3 下一階段（`0.13` 剩餘功能 B6 → G2(b) →
受保護文字 L1 收尾）... 輕量收據（`cw610r1`）後直接合併」 (agent scope interpretation: merge
zero-L1 B6 report-note PR `#610` directly after compact PJU receipt
verification).
Its compact receipt `65d535618544` (`C:\Users\nelson\dev\cw610r1\r\compact-receipt.json`,
`8,655` B) was verified by workflow run 43686511842 dispatched from
`refs/heads/main`, which set the required `checkwash` check (`132728180876`,
GitHub Actions App `15368`).

## 2026-11-14: 0.13, findings on projected Python units report real test names (D-210)

The 2026-11-10 re-review's ND-04 (`repro-07` `v0`–`v6` and `repro-06` `a2` vs
`a2b`): on a test-only expectation edit to the README's own quickstart example
(`total = invoice_total(...); assert total == 105.0`), `table_oracles`
classified the test as `"captured-result"`, projected it even without any table
or carrier transition, and replaced the unit's `qualname` with
`test_concrete_<digest>_1`, leaking synthetic names into `Finding.unit`,
`Finding.message` and `Finding.fingerprint` and rewriting `before`/`after`
assertion text relative to the co-changed diff (`repro-06/a2`). Every genuine
projected consolidation (`table_oracles`, `normalized_result_tables`,
`raises_oracles` `test_exception_*`, `local_auxiliary_oracles`
`test_local_auxiliary_*`) leaked synthetic `test_*_<digest>_<n>` unit names the
same way whenever an oracle changed inside a projected carrier.

[D-210](DECISIONS.md) fixes both without touching `gating.py` `L1–L682`
(SHA-256 `cfa19f5589cf650136e243f9b7404bd1bf5da85a95b4f6d72001b6931f868f5d`),
`ir/strength.py`, alignment parameters, or existing `.gwcase` expectations:

- **Enclosing source test identity (`Unit.source_unit`).** `ParsedUnit` and
  `Unit` add optional `source_unit: str = ""` (`IR_VERSION = 3` and
  `FINDINGS_VERSION = 2` unchanged; `UnitSide` native fields stay at 17). All
  four projection generators populate `source_unit` from the original
  `ParsedUnit` span map (preserving class qualification and `#N` numbering),
  `diffalign.align_file` copies it onto `Unit`, and `findings.unit_finding_name`
  supplies the real Python test name to all 11 unit-scoped detector modules and
  `gating.py`.
- **Per-concrete-unit gating isolation and duplicate-row fingerprints.**
  `gating._resolve_finding_unit` maps each finding back to the exact concrete
  `Unit` whose evidence/delta emitted it so sibling concrete units sharing one
  `source_unit` never share unearned `REPAIR_EVIDENCE`, while
  `findings.unit_assertion_position` and `test_disabled` preserve distinct
  `(ordinal, count)` v2 fingerprints across duplicate projected rows or
  disappeared concrete units within the same `source_unit`.
- **Same-carrier `captured-result` guard.** Non-transitioning `captured-result`
  modules whose local target, subject call/operator and plain RHS authority stay
  paired skip projection (`_same_captured_results` + `_ordinary_rows_cover(...,
  allow_captured=True)`), preserving verbatim `assert total == ...` text on
  `repro-07` `v0`/`v1` and `repro-06/a2b` while retaining projection for
  `is None` -> `pytest.approx` operator proofs and local-variable renames.

`tests/test_real_test_names.py` adds 14 collected tests (suite count: `23,122`;
10 fail on `main` `5e0fb5aa`, 4 are preserving controls), and
`tests/test_expected_provenance.py` asserts `f.unit == "test_double"` (`0`
`test_concrete_*` units). Checked on LAPTOP-01AGNPJU
(`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`, Windows CPython 3.11.9) across full
`pytest -n 16` (`23,122` tests), `checkwash check` dogfood (`--fail-on high`:
`verdict=pass`, 0 critical/high findings), and 1 independent read-only review
sub-agent (all findings resolved: `_requires_primitive_string` + literal-left
flip guard, `frozenset()` derived-authority check, `TOLERANCE_LOOSENED` sibling
fingerprint matching, and 3 nits); Nelson approved `SPEC.md` §5 and `D-210`
(`DECISIONS.md`, L1) on #608 at 2026-11-14T02:55:05Z (`bf5f8177`) and
authorized rebasing #608 onto #609 (`5e0fb5aa`, rebased L1 draft commit
`2cce7168` with `SPEC.md` byte-identical) at 2026-11-14T04:10:13Z (session
`98b9acf6`). Not run (`NOT_RUN`): macOS, Linux, and other platforms.

#608 merged as `0ffbeb31485a2aac2807120ea4c6d8c41fbad37e` at
2026-11-15T05:12:29Z, with parents `5e0fb5aa` and `3a8e8590` and the tree its
receipt verified (`d1ad79f7`, `d1ad79f79f1670b6e6e9e3fc04708b83e91792ce`).
Nelson's 2026-11-14T02:55:05Z and 04:10:13Z answers, above, approved the merge.
Its compact receipt `379182017aee` (`C:\Users\nelson\dev\cw608r3\r\compact-receipt.json`,
`8,667` B) was verified by workflow run 43679928892 dispatched from
`refs/heads/main`, which set the required `checkwash` check (`132708309782`,
GitHub Actions App `15368`).

## 2026-11-14: 0.13, CLI `GitSnapshot` reuse and batched base manifest reads

Following Nelson's 2026-11-14T04:10:13Z authorization in session `98b9acf6`
(in reply to Antigravity's `2026-11-14T04:07:01Z` question
「#608（7fe61445）連跑兩次輕量收據（cw608r1、cw608r2），23,112 題中其餘 23,111 題與雙向 Action 重播、wheel/sdist/pyz 驗證全數通過，唯獨 test_perf_git::test_range_check_through_git_stays_within_budget 在 16-worker 日間負載下分別跑出 12.46s 與 17.27s（上限 12.0s；單獨實測 main 與 #608 均為 3.1–3.3s，無 A4 退化）。cProfile 定位出主因是 cli._analyse 讀 config/allow/MANIFESTS 時未共用 GitSnapshot，每次 check 重複建 9 個 GitSnapshot 多生 ~27 個 git.exe 子行程（占總耗時 45%）。請問希望如何處理？」
he answered
`(Recommended) 先開一個獨立非 L1 小 PR 讓 cli._analyse 共用單一 GitSnapshot 批次讀取 base 設定與 manifest（每次 check 少生 ~25 個 git 子行程），合併後 rebase #608（維持已核可的 SPEC.md §5 與 D-210 實質內容，僅更新 commit 引用）跑收據並接續推進 B6`;
heading date Asia/Taipei, timestamps UTC), this non-L1 prerequisite pull
request eliminates redundant `GitSnapshot` construction and `git` subprocess
spawns across CLI analysis paths with zero verdict, L1 or `.gwcase` changes:

- **`GitSnapshot` inventory reuse (`src/checkwash/gitio/snapshot.py`).**
  Accepts an optional validated pre-resolved commit OID (`resolved`) in
  `GitSnapshot.__init__`, records `040000` tree entries via `ls-tree -r -t -l
  -z` (`_trees`) alongside `_listed_paths` across `list_paths()` and
  `read_config_many()`, adds `definitely_lacks(path)` to prove path absence
  from the cached blob/tree/submodule inventory without spawning `cat-file
  --batch-check` or `ls-tree`, and short-circuits `GitSnapshot.read` when
  `self._tree_entries` is already populated and `definitely_lacks(path)` holds
  while preserving `--batch-check` header verification on every present blob
  (such as `.checkwash/config.toml`), submodule/directory/empty-tree entry, and
  un-inventoried snapshot.
- **Batched base reads and range snapshot sharing
  (`src/checkwash/gitio/git.py`, `src/checkwash/gitio/__init__.py`).** Adds
  `read_base_file_from_snapshot`, `base_alias_from_snapshot`, and
  `read_base_manifests_from_snapshot` (which batches present regular base
  `MANIFESTS` in one `cat-file --batch` call while preserving `MANIFESTS`-order
  `SKIPPABLE_OVERSIZED` lockfile skipping, non-lockfile size refusals,
  submodule skipping, and nonregular-blob refusals), and threads optional
  `snapshots` through `list_range_changes` -> `read_blobs`.
- **CLI snapshot sharing and monkeypatch parity (`src/checkwash/cli.py`).**
  Shares one base `GitSnapshot` across `_cmd_check` (range and worktree),
  `_analyse` (`config.toml`, `allow.toml`, `--task` base read and `#500`
  case/link alias check, and `MANIFESTS`), `_session_note`, and `_pre_tool_use`
  (sharing `config_snapshot` as `head` when `config_side == window.head`), with
  explicit fallback dispatchers when `cli`, `config`, `gitio`, or `gitio.git`
  helpers are monkeypatched. On a 60-module range check, `ls-tree` calls drop
  from `17` to `2` and total `git` subprocesses stay `<= 18` (`0`
  `--batch-check` calls when no policy files exist).

`tests/test_cli_snapshot_reuse.py` adds `10` tests (`8` failing against `main`
`3231a03f` and `2` behavioral-parity controls; documented suite count:
`23,108`). `src/checkwash/gating.py` `L1–L682` remains byte-identical
(SHA-256 `cfa19f5589cf650136e243f9b7404bd1bf5da85a95b4f6d72001b6931f868f5d`).
An independent adversarial read-only review sub-agent audited the branch,
identifying `1` blocking defect (empty `040000` Git subtrees omitted by
`ls-tree -r` without `-t`) and `2` non-blocking suggestions (dynamic
`_snapshot_mod.MAX_SOURCE_BYTES` / pre-read oversized-note retention in
`read_base_manifests_from_snapshot`, and `monkeypatch.undo()` isolation in
`test_cli_snapshot_reuse.py`); all three are resolved with regression checks.
Checked on LAPTOP-01AGNPJU (`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`, Windows
CPython 3.11.9); the pull request's description and hosted `checkwash` check
record its compact PJU digest receipt (`collect_pju_receipts.py --compact`).
Not run (`NOT_RUN`): macOS, Linux, and other platforms.

#609 merged as `5e0fb5aad1ef15f942778d54f88a90fa0f1ec117` at
2026-11-15T04:42:22Z, with parents `3231a03f` and `072c919b` and the tree
its receipt verified (`55dab87c`). Nelson's 2026-11-14T04:10:13Z answer,
above, approved the merge. Its compact receipt `3a9edcd71c84` (`dev\cw609r1`,
`8,632` B) was verified by run 43603994033 dispatched from `refs/heads/main`,
which set the required `checkwash` check (`132474767837`, GitHub Actions App
`15368`).

## 2026-11-14: Phase 2 structural decomposition of five core God-function modules

Following Nelson's 2026-11-13 authorizations (`13:46:28Z` selecting Phase 1
compact PJU digest receipts and Phase 2 parallel decomposition of the five core
God-function modules, `14:49:57Z` approving [D-209](DECISIONS.md) and ruleset
`22032046`, `15:33:34Z` in session `29e2789b` instructing verbatim 「先合併收尾 然後給我prompt
我直接開session開工」, and `15:57:50Z` in session `bf74d6ef` `/teamwork` launch
instructing verbatim 「接手 checkwash Phase 2：平行拆解 5 大核心 God-Function 檔案...
合成為 1～2 支乾淨 PR... 發布綠燈 `checkwash` 後合併」; heading date Asia/Taipei,
timestamps UTC), Phase 2 decomposes eight God functions across five core Python
modules (`22` `src/checkwash/**` files total, branched from `main` `620f5236`
on `antigravity/phase2-god-functions-20261114`) with zero `.gwcase` fixture or
verdict-gate output changes, zero L1 severity-table (`gating.py` `L1–L682`)
changes, and zero `tests/**` changes (helper indirection adds `1–6` Python call
frames, shifting synthetic `RecursionError` boundaries near
`sys.getrecursionlimit()`, e.g. around `~2,956` nested `+` operators under the
default `1,000` limit; in session `c8f1073f` at `2026-11-15T17:34:59Z` Nelson
explicitly ratified `#607`'s `857c88d4` structural split of `gating.apply_gates`
verbatim 「可以 照你的建議走 開個新session? 需要用到goal 或其他技能嗎」):

- **`src/checkwash/engine.py` (`2,351 -> 932` lines) +
  `engine_ir_{intake,resolvers,files,credits,postpass}.py` (`318`, `527`, `696`,
  `497`, `130` lines).** Reduces `build_ir` from `1,512` to `71` lines
  (`L809–L879`), preserving all `154/154` top-level bindings and dynamic
  `checkwash.engine` monkeypatch lookup (`_eng()`).
- **`src/checkwash/shadow.py` (`3,215 -> 228` lines) +
  `shadow_{models,providers,runners,controls,imports,inventory,emission}.py`
  (`217`, `432`, `486`, `846`, `745`, `748`, `357` lines; `policy_shadow.py`
  untouched).** Reduces `find_runtime_subject_shadows` from `906` to `80` lines
  (`L149–L228`), preserving all `123/123` top-level bindings, lazy early-exit
  guards, `#455` `shebang_free` handling, and dynamic monkeypatch lookup
  (`_live_shadow_attr`).
- **`src/checkwash/frontends/python/frontend.py` (`5,873 -> 4,950` lines) +
  `frontend_{unit_collect,file_parse}.py` (`607`, `678` lines).** Reduces
  `_collect_unit` from `483` to `64` lines (`L3978–L4041`) and `_parse_python`
  from `604` to `35` lines (`L4463–L4497`), preserving `283/283` top-level
  bindings, the `#344` `global _walks` subtree-walk cache, all `26` `Marker`
  minting sites, and dynamic `_FRONTEND_MODULE` lookup.
- **`src/checkwash/gating.py` (`1,230 -> 1,410` lines).** Reduces `apply_gates`
  from `548` to `50` lines (`L683–L732`) backed by `12` stage helpers (`7–86`
  lines); `L1–L682` (the severity table, rule map, and `Counter` definitions) is
  100% byte-for-byte identical to `620f5236` (SHA-256
  `cfa19f5589cf650136e243f9b7404bd1bf5da85a95b4f6d72001b6931f868f5d`), and
  dynamic `finding_marker` lookup is preserved.
- **`src/checkwash/frontends/python/table_oracles.py` (`1,794 -> 1,146` lines) +
  `table_oracles_{test,module,projection}.py` (`270`, `466`, `180` lines;
  `table_factories.py` and `table_normalization.py` untouched).** Reduces
  `_test` from `234` to `27` lines (`L816–L842`), `_module` from `306` to `17`
  lines (`L845–L861`), and `project_table_consolidation` from `217` to `50`
  lines (`L1097–L1146`), preserving all top-level symbols and dynamic `_SELF`
  runtime lookup.

An independent adversarial read-only review agent (`verifier`) audited all five
parallel author branches (`engine` `193fd774`, `shadow` `7cedf5b4`, `frontend`
`83588c03`, `gating` `0d50ce72`, `table-oracles` `f1d6ea19`) for L1 boundaries,
symbol and monkeypatch parity, source-scanning AST invariants, and line-by-line
control-flow equivalence before linear integration. Documented suite count
remains `23,098`. Checked on LAPTOP-01AGNPJU
(`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`, Windows CPython 3.11.9) across each
decomposed module's targeted and gate suites, documentation and packaging pins,
and `checkwash` dogfood (`620f5236..HEAD --fail-on high`: `verdict=pass`, 0
critical/high findings); the pull request's description and hosted `checkwash`
check record its compact PJU digest receipt (`collect_pju_receipts.py
--compact`). Not run (`NOT_RUN`): macOS, Linux, and other platforms.

#607 merged as `3231a03f5000286ac022b849d52d66b93ba717b5` at
2026-11-13T17:32:59Z, with parents `620f5236` and `e9a8dc4e` and the tree
its receipt verified (`b3c5d5a0`). Nelson's 2026-11-13T13:46:28Z, 14:49:57Z,
15:33:34Z and 15:57:50Z instructions (with `2026-11-15T17:34:59Z` ratification
of `857c88d4` `gating.apply_gates`), above, authorized the merge. Its compact receipt
`33717df2edf8` (`dev\cw607r1`, `8,654` B) was verified by run 43473325616
dispatched from `refs/heads/main`, which set the required `checkwash` check
(`132051150641`, GitHub Actions App `15368`).

## 2026-11-13: compact PJU digest receipts for ordinary pull requests and ruleset App binding (D-209)

On Nelson's 2026-11-13 instruction to reduce PR verification cost before
decomposing the repository's God functions (`13:43:37Z` / `13:46:28Z`),
[D-209](DECISIONS.md) replaces ordinary-PR 53 MiB `evidence/*` Git branches and
duplicate `3x283` Windows CLI subprocess loops with a compact PJU digest
receipt while keeping all product execution on LAPTOP-01AGNPJU
(`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`, Windows CPython 3.11.9):

- **Compact local collection (`tools/collect_pju_receipts.py --compact`).**
  Runs pinned and (when the `action/`/`src/`/`pyproject.toml` closure differs)
  candidate composite Action replays concurrently, builds `.whl`, `.tar.gz` and
  `checkwash.pyz` in scratch, verifies archive metadata, entrypoints and exact
  `checkwash/*` member byte-identity against `src/checkwash` via
  `tools/release_inventory.py`, installs the wheel into a fresh venv and runs
  `checkwash demo` on both the wheel and `checkwash.pyz`, runs the full suite
  with 16 xdist workers (`COMPACT_PYTEST_WORKERS = "16"`), keeps raw logs on
  PJU, and emits a single-line ~6–9 KB canonical ASCII JSON receipt. Existing
  historical `evidence/*` branches remain untouched; release stages still run
  full `3x283` qualification via `tools/collect_pju_release.py` and
  `tools/pju_release_bridge.py`.
- **Hosted verification and supply-chain fixes (`verify-compact` /
  `publish-compact`, plus `verify` / `publish` in `main()`).** Recomputes
  `src_tree`, `source_package_sha256`, `builder_sha256`, contract suite digests,
  Action YAML/run-block/engine digests and candidate closure digests from
  checked-out Git blobs; enforces exact equality between JUnit's testcase count
  and `documented_test_count` across `README.md`, `CONTRIBUTING.md` and
  `docs/launch.md` (`>= 23,065`, closing RC-09 on both compact and legacy
  `main()` paths); self-seals `workflow_dispatch` to `refs/heads/main` once
  `verify-pju-compact` is on `main` (allowing same-tree bootstrap dispatch from
  `review/collector-d209-20261113` before merge so GitHub creates a standalone
  `CheckSuite` on `head`) and requires `refs/heads/main` immediately
  in legacy `verify`/`publish` (closing RC-02 Understated 2); removes
  `.github/workflows/quality-candidate-intake.yml` from `pull_request.paths`
  and restricts `intake` on `workflow_dispatch` to `inputs.mode == 'intake'`;
  and binds required check `checkwash` to GitHub Actions (`integration_id:
  15368`) in `action/required-ruleset.json` and repository ruleset `22032046`
  (closing RC-03).

D-209 (`DECISIONS.md`, L1) was approved by Nelson at 2026-11-13T14:49:57Z on
#606 (`06fe2f1e`): in reply to Antigravity's `14:48:20Z` question
「#606 的 L1（DECISIONS.md D-209）核可，並確認 GitHub ruleset 22032046 已改為單一 checkwash（GitHub Actions 15368），收據過了就合併嗎？」
he answered `(Recommended) 核可 D-209、已改好 ruleset 22032046，收據過了就合併 #606`;
after run `43450393694` exposed GitHub's `workflow_dispatch` `CheckSuite`
rollup exclusion on same-SHA dispatch, he approved the `f2bfe8e0` same-tree
bootstrap clause (`review/collector-d209-20261113`) and running Phase 2 in a
fresh `/teamwork` session at 2026-11-13T15:33:34Z
(「先合併收尾 然後給我prompt 我直接開session開工」). An independent read-only review sub-agent audited `1a4d7163`, and all
findings (legacy `main()` RC-02/RC-09 parity, `collect_compact` `--git` and
sanitized-env binding, canonical ASCII JSON wire check, release-head refusal
tests, 23,065 floor and `~6–9 KB` prose) are resolved.
`tests/test_pju_compact_receipt.py` adds 33 tests (suite count: 23,098). Not
run: macOS, Linux outside local checks, and other platforms.

#606 merged as `620f5236ae63e33bd941d0c3697fead9353f9e10` at
2026-11-13T15:52:03Z, with parents `b326f201` and `a8732324` and the tree
its receipt verified (`62ef48a9`). Nelson's 2026-11-13T14:49:57Z and
15:33:34Z answers, above, approved the merge. Its compact receipt
`06edffb1d5dd` (`dev\cw606c2`) was verified by run 43456571470 from
same-tree bootstrap ref `review/collector-d209-20261113` (`1f703d83`),
which set the required `checkwash` check (`131992630899`, GitHub Actions
App `15368`).

## 2026-11-13: 0.13, a virtual environment's own links (D-208)

The re-review's ND-02 on Linux, and on macOS by Python's source (not run
there). `python -m venv` links the environment's interpreter (`bin/python`,
`bin/python3`, `bin/python3.X`, and in Python 3.14 `bin/𝜋thon`), and on
64-bit Linux `lib64` to `lib`. checkwash follows no link. On Linux an
environment Git did not ignore stopped a check without a range at its first
link (exit 2), and the Stop hook said the change was not analysed, a
weakened test beside it included; ignored, an environment named `env` did
the same whenever a pass walked into it, and the PreToolUse hook said a
Write to a test helper or a root helper beside `env` was not analysed.
[D-208](DECISIONS.md):

- **A virtual environment's own link** is one directly in `<D>/bin` or
  `<D>/Scripts` whose name does not end in `.py` in any case, or `<D>/lib64`
  linking to `lib` beside a directory `<D>/lib`, where `<D>` is a directory
  other than the repository root that holds `pyvenv.cfg` as a regular file
  (SPEC §9).
- **Untracked, in a working-tree run** (a check without a range, the Stop
  hook's verdict diff and its session-commits analysis), in an environment
  directory `<D>` no compared commit holds (`HEAD` and, in the Stop hook,
  the session base), such a link is carried with no bytes and set aside
  (with a stderr note in the verdict diff), unless a detector must read its
  path (test, conftest and test-support paths included, after #456's size
  block) or pytest's collection can reach `<D>`, which stops the run as an
  engine error.
- **The working tree's listing and walks** leave out non-directory own links
  in `<D>/bin` or `<D>/Scripts`, keep directory links there opaque (#414),
  and pass over `<D>/lib64` when it reads `lib` beside a directory `lib`;
  the PreToolUse hook inherits both and now asks on a weakened helper or
  root helper beside `env`.
- **Read, and refused, as before:** every other link, one in a directory a
  compared commit holds, a tracked one the diff changes, a staged one, and a
  link a range adds, changes or reads in a pass. A range that commits an
  environment still exits 2: CPython's `venv` keeps a committed interpreter
  link when it runs again over the environment without `--clear` (measured
  in 3.12, 3.13 and 3.14), so it could stand in for the suite's interpreter.
  The residual is local: THREATMODEL row 186; row 128 notes the exception
  and row 180 notes initial paths.

D-208, its SPEC §9 paragraph, §2b and §4b clauses, and THREATMODEL rows 128,
180 and 186 are L1, and wait for Nelson's approval.
`tests/test_environment_links.py` holds 93 tests. Its 22 command-line tests,
run in the 3.12.15 Linux image with the command line from main `0f054eef`'s
tree: 19 fail, and the other 3 assert refusals main already makes; across
all 93 tests against main's `src` (with the four new symbols stubbed), 80
fail and 13 assert refusals and opaque-directory rules main already keeps.

Status before the merge: the branch was `claude/venv-links-20261113`, from
main `0f054eef`.

- **Review.** Three read-only Claude review sub-agents reviewed the first
  version (`78696e87`), for bypasses, for code and tests, and for documents
  and claims; one read-only review sub-agent reviewed the second (`091c85f5`,
  `40d7271b`). Their findings are in D-208. `bc729cf1` (`6fe1961e` for the
  code and tests), which answers them, was not reviewed again.
- **Checks.** On LAPTOP-01AGNPJU (`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`,
  Windows CPython 3.11.9), on 2026-11-13, at `bc729cf1`:
  - The full suite (`pytest`, xdist `-n 8`), which holds the fixture cases
    and `tests/gates`, at `40d7271b`: 22,974 passed and 81 skipped, plus 67
    subtests, with no failure; at `6fe1961e` and `bc729cf1`,
    `tests/test_environment_links.py` passes all 93 tests in the 3.11.17,
    3.12.15 and 3.13.16 Linux images (37 passed and 56 skipped on Windows),
    and `test_packaging.py` and the documentation pins pass.
  - checkwash's own check of the range from main `0f054eef` at
    `--fail-on high`: pass, no finding.
  - Forty-three one-line mutants of the change in the 3.12.15 Linux image,
    each in its own copy without `-x`: 38 fail the new test file; D-208 names
    the five that do not.
  - The 340-row probe and four planted-`tests/` shapes of D-208 in WSL2
    Ubuntu 24.04 (CPython 3.12.3, Git 2.43.0), with main's source and this
    branch's, and the 24,021-path walk timings in WSL and on Windows.
- **Approval.** At 2026-11-13T11:56:55Z Antigravity asked
  「#605 的 L1（D-208、SPEC §9／§2b／§4b、THREATMODEL 128／180／186）核可，收據過了就合併嗎？」,
  and at 12:30:39Z Nelson answered 「核可並合併」. Antigravity wrote the
  question and both options. The answer approves D-208 with the SPEC §9
  paragraph and §2b and §4b clauses, and THREATMODEL rows 128, 180 and 186
  (L1). It also approves the merge, once the receipt and the four required
  checks pass.

The pull request's description records its PJU receipt. Not run: macOS,
Windows `--symlinks` (without the symbolic-link privilege on this account),
and other platforms.

#605 merged as `b326f201b2676d197e3d07260a355ea6027d68f3` at
2026-11-13T13:16:05Z, with parents `0f054eef` and `b3580399` and the tree
its receipt verified (`ee76bfeb`). Nelson's 「核可並合併」 at 12:30:39Z,
above, approved the merge. Its receipt
`evidence/pr605-782438ad8a01-20261113` (`43f73cf9`) was verified by run
43431363793, which set the four required checks.

## 2026-11-13: 0.13, the signature block that ends a PowerShell file is not read for a test runner (D-207)

The re-review's ND-02, on Windows: a virtual environment that Git did not
ignore, unless named `.venv` or `venv`, blocked at high on the
`Activate.ps1` that `python -m venv` writes, untracked in a check without a
range and the Stop hook, and committed in a range. Windows builds of Python
sign it, and the base64 of its signature (in Python 3.11.9's copy) spelled
`tox` and `nox`, two runner tokens, so the script read as a test runner
whose command was weakened. [D-207](DECISIONS.md):

- **The closing block only.** In a PowerShell file the runner search leaves
  out the signature block that ends it, when every line between its markers
  is `#`, a space and base64 (SPEC §2); as PowerShell reads the file, none
  of it runs. Each reader of that search passes the file's path, and a
  rename's old side its old path: the role of a runner script, the one hop
  to a runner script (THREATMODEL row 89), the opaque-exemption denial
  (row 87), the CI weakening scan, the collection inventory and `shadow`.
- **A signed script now reads as the same script unsigned.** Beside a
  signed script whose signature spells a runner name, main blocked a
  swallowed call to it and a rewritten expected value (no opaque
  exemption), and passed a runner removed under such a signature and a
  first pytest config that leaves a test out (the collection inventory set
  itself aside). This version does each as it does beside an unsigned
  script: the first two pass with a warning or none, the last two block.
- **Read as before:** the rest of the file, comments included; a block
  with any other line, such as `#> pytest`, without either marker, or
  followed by anything but spaces, tabs and line ends; and every other
  file, since cmd and make need not read `#` as a comment.
- **The residual**, THREATMODEL row 185: a PowerShell-named file that make
  runs with `\#` as its recipe prefix, or that runs its own block, can hold
  its suite there unread, and every reader treats it as holding no runner.
- **Waits:** ND-02 on Linux, and on macOS by Python's source (not run
  there). `python -m venv` links the environment's Python outside the
  repository, and on Linux a check without a range exits 2, the
  environment named `env` or `.venv` alike; a range that commits the
  environment exits 2.

D-207, its SPEC §2 sentences and THREATMODEL row 185 are L1, and wait for
Nelson's approval. `tests/test_signature_block_runner.py` holds 41 tests.
Its fourteen command-line tests, run with the command line from main
`82b88866`'s tree: nine fail, and the other five assert what main already
does. Its other 27 tests call the runner search directly: on main 26 fail
with a `TypeError`, as main's search takes no path, and one because main
reads the signature as a runner.

Status before the merge: the branch was `claude/signature-block-runner-20261113`,
from main `82b88866`.

- **Review.** Three read-only Claude review sub-agents reviewed the first
  version (`01775322`, `7a872262`), for bypasses, for code and tests, and
  for documents and claims; one reviewed the second (`093f86c7`,
  `468233a0`). Their findings are in D-207. `d7ffc93f`, which answers them,
  was not reviewed again.
- **Checks.** On LAPTOP-01AGNPJU (`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`,
  Windows CPython 3.11.9), on 2026-11-13, at `d7ffc93f`:
  - The full suite (`pytest`, xdist `-n 8`), which holds the fixture cases
    and `tests/gates`: 22,947 passed and 25 skipped, plus 67 subtests, with
    no failure, counted from pytest's progress output.
  - checkwash's own check of the range from main `82b88866` at
    `--fail-on high`: pass, no finding.
  - Forty one-line mutants of the change, each in its own copy: 33 fail
    the new test file; D-207 names the seven that do not.
  - The environments of D-207, with main's source and this branch's, on
    Windows and on Linux (WSL2 Ubuntu 24.04, CPython 3.12.3), and the 70
    signed PowerShell files of Windows PowerShell's own folders. GNU Make
    4.4.1 ran the residual's shape on Windows.
- **Approval.** At 2026-11-13T06:22:22Z Claude asked
  「#604 的 L1（D-207、SPEC §2 兩句、THREATMODEL 185）核可，收據過了就合併嗎？」,
  and at 06:31:24Z Nelson answered 「核可並合併」. Claude wrote the question
  and both buttons. The answer approves D-207 with the two SPEC §2
  sentences and THREATMODEL row 185 (L1). It also approves the merge, once
  the receipt and the four required checks pass.

The pull request's description records its PJU receipt. Not run: macOS and
other platforms.

#604 merged as `0f054eef3c8b3fd0b360a7f777d88dcd416d958b` at
2026-11-13T07:06:48Z, with parents `82b88866` and `be229e55` and the tree
its receipt verified (`4f600bd3`). Nelson's 「核可並合併」 at 06:31:24Z,
above, approved the merge. Its receipt
`evidence/pr604-ebc9be885e13-20261113` (`59e16bb6`) was verified by run
43383106158, which set the four required checks.

## 2026-11-13: 0.13, a changed test helper's importers past the search limit (D-206)

The 2026-11-10 re-review's FB-02: a change to a test helper module whose
name 64 or more Python files mention made every check exit 2, which no
exemption released. [D-206](DECISIONS.md):

- **Each name on its own.** The expected-value pass searches each changed
  helper's module name on its own, with every path the diff changes left
  out as Git spells it, and gives each name its own bounds. The run reads
  at most 192 importers in all, from the name with the fewest tests.
- **Past its bounds it says so.** At the search's 64-hit limit, past 48
  unchanged importer tests, or once the run's reads are spent, none of
  that name's importers is read; more than 16 names set every helper
  aside. The run names the helpers in an "analysis incomplete" note: on
  stderr, in SARIF and in the term report, and in the hooks'
  `systemMessage` when the Stop hook passes, for its own check and for the
  session's commits, or the PreToolUse hook does not ask about a
  weakening; under `on_engine_error = "block"` that hook asks (SPEC §9).
- **Still stops the run at the limit:** a helper the diff renames to
  another name; a run that cannot report the note (`sweep`, `bench`); and
  the root-helper search, which reviews removed assertions.
- **The residual**, THREATMODEL row 183: past those bounds an expected
  value rewritten inside a helper passes, with the note. In the hooks,
  files outside their diff count toward the limit: files Git ignores, a
  case-only rename on a disk that ignores case, and files the session
  committed or wrote before the edit.
- **Older gaps** the review found, THREATMODEL row 184: ways the pass
  misses a weakened helper without a note, on main as well.

D-206, its SPEC paragraph with two SPEC sentences on hook output, and
THREATMODEL rows 183 and 184 are L1, approved by Nelson (below).
`tests/test_importer_search_skip.py` holds 39 tests. Its thirteen
command-line tests, run with the command line from main `6c2b7669`'s tree
(`4474b334`): twelve fail, as the run exits 2 or a hook reports the change
not analysed; the thirteenth asserts what main already does, exit 2. Its
other 26 tests call code main does not have.

Status before the merge: the branch was `claude/importer-search-skip-20261113`,
from main `6c2b7669`.

- **Review.** Three read-only Claude review sub-agents reviewed the first
  version (`6ba50a02`), for bypasses, for code and tests, and for documents
  and claims; one reviewed the second (`383a0906`). Their findings are in
  D-206. `bc5d25e0`, which answers them, was not reviewed again.
- **Checks.** On LAPTOP-01AGNPJU (`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`,
  Windows CPython 3.11.9), on 2026-11-13, at `bc5d25e0`:
  - The full suite (`pytest`, xdist `-n 8`): 22,906 passed and 25 skipped,
    plus 67 subtests, with no failure, counted from pytest's progress
    output.
  - checkwash's own check of the range from main `6c2b7669` at
    `--fail-on high`: pass, no finding.
  - Twenty one-line mutants of the change, each in its own copy, all fail
    the new test file.
  - The older gaps of THREATMODEL row 184, and the two oversized-file
    exits, each reproduced on main `6c2b7669`.
- **Approval.** At 2026-11-13T02:48:06Z Claude asked
  「#603 的 L1（D-206、SPEC §9、THREATMODEL 183／184）核可，收據過了就合併嗎？」,
  and at 02:50:44Z Nelson answered 「核可並合併」. Claude wrote the question
  and both buttons. The answer approves D-206 with the SPEC §9 text and
  THREATMODEL rows 183 and 184 (L1). It also approves the merge, once the
  receipt and the four required checks pass.

The pull request's description records its PJU receipt. Not run: other
platforms.

#603 merged as `82b88866f3caa54732adef219012dd94eed81eed` at
2026-11-13T03:29:14Z, with parents `6c2b7669` and `4c4c5be2` and the tree
its receipt verified (`4a5f3546`). Nelson's 「核可並合併」 at 02:50:44Z,
above, approved the merge. Its receipt
`evidence/pr603-84057df62bdb-20261113` (`a095f011`) was verified by run
43359066162, which set the four required checks.

## 2026-11-12: 0.13, first-week fixes (D-205)

On 2026-11-12, after #597 merged, Nelson wrote 「繼續做 0.13」 (go on with
0.13) at 15:05:30Z. Claude chose 0.13's scope from the 2026-11-10
re-review: its five first-week problems (group A), a report line for
test-looking files that are not analysed (group B), and G2 (b). Groups C
and D wait. This change takes group A's problems 3 and 5
([D-205](DECISIONS.md)):

- **The zipapp.** A check without a range and the Stop hook leave out the
  untracked zipapp that checkwash runs from, with one stderr line, when
  neither the compared commit nor the session base holds its path (SPEC
  §9). `checkwash.pyz` downloaded into the root no longer reports itself.
- **The hook settings.** A local hook install adds a rule for
  `.claude/settings.local.json` to the `info/exclude` file Git names, when
  Git neither tracks nor ignores the file.

Problem 2, an untracked virtual environment, was in the first version and
is withdrawn. Review found the marker rule unsafe, and found that the
Windows symptom comes from `roles._runs_tests` reading `tox` and `nox`
inside the signature block of `Activate.ps1`. A later change takes it.

D-205 and its SPEC paragraph are L1, approved by Nelson (below).
`tests/test_first_week_fixes.py` holds 25 tests. Copied into a scratch
worktree of main `9b69183d`, 4 pass, 15 fail and 6 error.

Status before the merge: the branch was `claude/first-week-fixes-20261112`,
from main `9b69183d`.

- **Review.** Three read-only Claude review sub-agents reviewed the first
  version (`787706ec`), and one the second (`ac7b085f`). Their findings
  withdrew problem 2; fixed the installer's path, escaping, reply from Git
  before 2.31, test isolation and messages; added tests for each code path
  a mutant of the second version passed; and corrected three sentences of
  D-205. `5bb823e6`, which carries those fixes, was not reviewed again.
- **Checks.** On LAPTOP-01AGNPJU (`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`,
  Windows CPython 3.11.9), on 2026-11-12, at `5bb823e6`:
  - The full suite (`pytest`, xdist `-n 8`): 22,867 passed and 25 skipped,
    plus 67 subtests, with no failure, counted from pytest's progress
    output.
  - checkwash's own check of the range from main `9b69183d` at
    `--fail-on high`: pass, no high finding; two warnings on
    `tests/test_doctor.py`, whose expected values move with the installer.
  - The review of the second version ran its 18 tests under WSL (Ubuntu
    24.04, Python 3.12.3, Git 2.43.0): all passed. The 25 tests of
    `5bb823e6` ran on Windows only.
- **Approval.** At 2026-11-12T17:41:56Z Claude asked
  「#602 的 L1（D-205 和 SPEC §9 新段）核可，收據過了就合併嗎？」, and at
  23:38:29Z Nelson answered 「核可並合併」. Claude wrote the question and both
  buttons. The answer approves D-205 with the new §9 paragraph of SPEC
  (L1). It also approves the merge, once the receipt and the four required
  checks pass.

The pull request's description records its PJU receipt. Not run: other
platforms.

#602 merged as `6c2b7669a73ec81c3b7e5b09003e61bd1c4b769d` at
2026-11-13T00:20:17Z, with parents `9b69183d` and `953c9d2e` and the tree
its receipt verified (`4474b334`). Nelson's 「核可並合併」 at 23:38:29Z,
above, approved the merge. Its receipt
`evidence/pr602-0e9ca203de4b-20261113` (`c42e7a1b`) was verified by run
43336018607, which set the four required checks.

## 2026-11-12: toward 1.0 (D-203, Nelson's answers of 2026-11-08)

[D-203](DECISIONS.md) records Nelson's answers of 2026-11-08 on what 1.0
waits for, quoting him. At 13:24:11Z he answered Claude's list of seven
decisions with 「重啟對外 上1.0」 (restart outreach; go for 1.0),
「都看過 可以照建議」 (I have read them all; follow the recommendations) and
「macos採用你的建議」 (for macOS, adopt your recommendation). At 15:58:03Z he
answered Claude's second list item by item and asked that the round not be
recorded as everything else following the recommendations. Claude wrote
both lists, their options and their recommendations. 「上1.0」 is not the
one-time authorization for version 1.0.0 that AGENTS.md rule 5 requires;
1.0 is still NOT_MET.

- 0.x outreach resumes as a trial that makes no quantitative quality
  promise. Its results are not 1.0 acceptance evidence, and the 1.0 quality
  goals stay.
- The fifteen P0/P1 issues open on 2026-10-18 are a precondition for 1.0,
  not for outreach. Fourteen are closed.
- #212 is narrowed to a blind rating of the eleven JS/TS commits that
  0.12.0 moved from pass to block. The packet and the rubric were
  committed to checkwash-lab before any rating (`cac11989`); a Claude Code
  sub-agent and Gemini 4 Argon rated the commits (`c61702b9`), and Nelson
  ruled where they differed (`e1f7119a`, one sentence corrected at
  `445f6225`): 10 should pass, 7 of them honest
  changes whose tests now check less, 1 is unclear and none should block.
  They are selected commits, not a false-block rate; the 10 that 0.12.0
  newly blocks are a review or exemption cost to users, which closing #212
  does not fix; and the other 44 of cf-js131's 55 were not rated. #212
  closes after this pull request merges, with those caveats, which
  THREATMODEL row 131, the #212 row of KNOWN-ISSUES-next and the JS/TS
  replay's selection record repeat; `docs/testing-on-pju.md` follows the EC
  POLICY change.
- #428 is closed as fixed in v0.9.0; its measurements are listed on #504,
  and the first #428 row of KNOWN-ISSUES-next says so.
- Each release is to get one macOS verification, and v0.12.0 one catch-up
  run: the full tests, the corpus comparison, and the wheel and pyz to be
  published or already published, with their SHA256. D-170's two budget
  checks stay skipped on macOS at 1.0 and are disclosed as unverified
  there. The workflow comes in its own pull request; until EC POLICY
  allows the hosted run, macOS stays NOT_RUN. That came later and wider:
  D-204 (#599) runs macOS and Linux, and the v0.12.0 run is recorded with
  #600 (sections below).
- The 1.0 residual register is approved item by item at the 1.0
  candidate, not here. 1.x keeps the fingerprint rule.
- The cohort answers are research-design decisions, not a frozen
  protocol. 20 reviewed changes per repository is an activity floor only:
  it is not equivalent to the estate's T-157 record of 100 and does not
  replace it by itself. The refactor-cost goal's 2% is an acceptance ruler
  for the observed sample, not proof that the population's false-block rate
  is at most 2%, and neither 100 pull requests nor 180 days is fixed. Claude's estimate of 8 to 33 months was an extrapolation
  from assumptions, and dropping the time threshold alone would not shorten
  the wait while the refactor measure's cohort layer still needs 100.
- Stability's 1.0 section points to D-203 and corrects its stale gaps: the
  Action trust lag ended on 2026-10-14, smallestlie is archived, the static
  refactor ledger has had 6/60 since 0.10.0, and every release stage since
  v0.10.0 ran on one Windows host. With main taken in, the same row also
  names D-204's hosted verification and v0.12.0's macOS failure.

`test_subject_counts_the_complete_reconstructed_tree` in
`tests/test_string_chain_syntax.py` again checks that `_syntax` reads the
forced fallback's complete tree at exactly the node limit, beside its newer
path, side and message check, on Nelson's sixth answer. An agent edit of
2026-10-14 dropped that check while it restored draft #391's own test in a
rebuild of #391 on #439; the check was never on main. The 2026-10-28
replay's packet-only label for that edit, replay item 392, stays apart from
that full-context reading, and the edit is not counted, for now, as a
sixth unexplained weakening. No test is added, so the documented count does not
move.

Done on 2026-11-08, outside this pull request:

- PR #380's artifact 11750893301 (run 38257378417, 77,212 bytes, SHA256
  `335f3b18826beb9a221be74bf4d61d046a99339bbf6611dd706109578805f1ce`, the
  digest GitHub records), the only raw copy of the 0.7.0-era runtime
  diagnostic of the 60-case refactor corpus, which GitHub deletes at
  2026-11-11T13:42:39Z, is kept byte for byte on checkwash-lab branch
  `evidence/pr380-refactor-artifact-20261108` (`790b6ee6`), with a README of
  its source, members and verifier output: 4 of the 60 cases carry a
  blocking finding and 2 of the 57 without a fixture error block, verifier
  exit 2, on one hosted Ubuntu leg. In-sample; no document here cites it.
- #428 was closed as completed at 13:29:26Z, with a
  [comment](https://github.com/taipei49314/checkwash/issues/428#issuecomment-6722098644)
  that records the decision, and #504's body gained a 2026-11-08 paragraph
  that lists #428's measurements.
- #212's rating is kept on checkwash-lab branch
  `evidence/cw212-rating-20261108`: the packet and the rubric (`cac11989`),
  a note on Argon's request (`5175d6a6`), both ratings with the Argon run's
  receipts and the comparison (`c61702b9`), Nelson's rulings with the
  result (`e1f7119a`; its sentence on cf-js131's 55 corrected at
  `445f6225`) and the execution receipt (`c90708e4`). The result
  and the receipt are posted on
  [#212](https://github.com/taipei49314/checkwash/issues/212#issuecomment-6723728427).
  The ratings ran on the 13:24 answer; the explicit word the
  recommendation asked for came at 15:58, after them.
- In the estate, EC POLICY commit `227236bc` adds the row
  `checkwash-212-blind-raters-20261108`, which replaces only the #212
  sentence of `checkwash-pju-tests`, as an after-the-fact record; EC T-602
  and T-603 were retired as `CANCELLED`, and EC PR #226 was closed.

Not done: closing #212, after this pull request merges; the hook test on a
borrowed Mac; the residual register; the cohort protocol.

Status before the merge: the branch was `claude/road-to-1.0-20261109`, from main
`8f610be9`; main `f93e24ce` (#598 to #601) was merged in as `61fc0708`.

- **Review.** One read-only Claude review sub-agent reviewed the first draft
  against Nelson's verbatim replies, the checkwash-lab records, EC and
  GitHub. It found no blocking error, and `c9609878` and `a70b8711` carry
  its 15 text fixes. `7a7cb136`, after the merge, updates stability's row
  on hosted verification and was not reviewed.
- **Checks.** On LAPTOP-01AGNPJU (`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`,
  Windows CPython 3.11.9), on 2026-11-12, at `7a7cb136`:
  - The full suite (`pytest`, xdist `-n 8`): 22,842 passed and 25 skipped,
    plus 67 subtests, with no failure, counted from pytest's progress
    output.
  - checkwash's own check of the range from main `f93e24ce` at
    `--fail-on high`: pass, no finding.
- **Approval.** At 2026-11-12T14:07:42Z Claude asked
  「#597 的 L1／L2 核可，收據過了就用 merge commit 合併嗎？」, and at 14:08:05Z
  Nelson answered 「核可並合併」. Claude wrote the question and both buttons. The
  answer approves D-203 with THREATMODEL row 131 (L1) and stability's 1.0
  section (L2). It also approves the merge, once the receipt and the four
  required checks pass.

The pull request's description records its PJU receipt. Not run: other
platforms.

#597 merged as `9b69183d38291e792bc63c84fdfc82c0a62d28bb` at
2026-11-12T14:45:58Z, with parents `f93e24ce` and `0f1e3f9f` and the tree
its receipt verified (`b6196ce9`). Nelson's 「核可並合併」 at 14:08:05Z,
above, approved the merge. Its receipt
`evidence/pr597-1314ea49943f-20261112` (`b2f071c5`) was verified by run
43240185616, which set the four required checks. #212 was closed as
completed at 14:46:32Z, with Nelson's three caveats quoted in its closing
comment.

## 2026-11-12: the v0.12.0 Release notes carry the hosted result

The heading's date is Asia/Taipei; the times below are UTC, on 2026-11-11.

The v0.12.0 Release notes link the known issues as they stand at the tag,
which do not show the hosted verification after publication (next
section). Asked about a note, Nelson replied 「Release 頁的加註 先烈給我」,
which Claude read as asking to see the text first; after Claude listed it,
he answered 「照這段加註」 (add this note) at 16:40:28Z. At 16:40:55Z Claude
added the text as the last paragraph of the Release notes and changed
nothing else on the Release; read back, the body equals byte for byte the
prepared body, the old notes with a blank line and the approved paragraph.
Claude then asked whether to record this in a small pull request, and he
answered 「開小 PR 記錄」 (open a small PR to record it) at 16:41:56Z. Claude
wrote the questions, the buttons and the text;
[RELEASING](docs/RELEASING.md#v0120-hosted-verification-after-publication-2026-11-11)
has them, his answers and the text. This change records the note and,
below, #600's merge. Documentation only.

#601 merged as `f93e24ce5a8ef9fa082992e21ce5f5c90c716914` at
2026-11-11T18:10:01Z, with parents `c4dee609` and `4a00b727` and the tree
its receipt verified (`af2f8571`). Claude asked 「要用 merge commit 合併 #601
嗎？」 and wrote the buttons; Nelson answered 「核准合併 #601」 at
2026-11-11T18:09:40Z. Its receipt `evidence/pr601-a10ccd2d52b5-20261111`
(`5e5a6d19`) was verified by run 43072444048, which set the four required
checks.

## 2026-11-11: v0.12.0's hosted verification after publication failed on macOS

Run 43039360146 ran both checkpoints of the hosted verification on v0.12.0
right after #599 merged, as D-204 provides for that release
([RELEASING](docs/RELEASING.md#v0120-hosted-verification-after-publication-2026-11-11)).
It failed on macOS only: the whole suite at M failed in 14 entries of
`tests/test_collect_pju_release.py`, the PJU release collector's tests,
whose temporary directories sit under `/var`, a symlink on macOS, which the
collector's path check refuses. Everything else passed on both systems: the
Linux suite with the six-leg batch's counts, the qualifications and
inventories, six byte-identical corpus outputs equal to the batch's, the
Action at A with exit 0, and the published wheel, sdist and pyz. The run
was not repeated. Claude asked
「要我開一個 PR 修這 14 個測試，並把這次結果寫進 0.12.0 的紀錄嗎？」 with the
buttons 「開 PR 修正並記錄」 and 「先等等」, which it wrote, and Nelson answered
「開 PR 修正並記錄」 at 14:53:56Z.

This change is that pull request:

- **The fix.** The collector's tests take each temporary directory by its
  real path (`real_temporary_directory` in the test file), as pytest's
  `tmp_path` does; the collector's check is unchanged. On LAPTOP-01AGNPJU
  (`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`), the file run with WSL
  Ubuntu's Python 3.12.3 and a `TMPDIR` reached through a symlink exited 1
  on `eb4fdab6`, the same 14 entries failing, and 0 with this change; the
  pull request lists each run. macOS is `NOT_RUN` for the fix until the
  next release's `source-at-M` run.
- **The records.** The run's records are in the
  [v0.12.0 publication record](docs/releases/v0.12.0-publication-verification.md#hosted-verification-after-publication-2026-11-11),
  RELEASING's dated paragraph and
  [KNOWN-ISSUES-v0.12.0](docs/KNOWN-ISSUES-v0.12.0.md), with a row in
  [KNOWN-ISSUES-next](docs/KNOWN-ISSUES-next.md). `action/README.md` now
  cites the run for the composite on a hosted Linux runner. The run's 15
  artifacts, its log archive and GitHub's records of it are on
  `evidence/v0120-hosted-run43039360146-20261111` (`307d7c62`), beyond
  their 90-day retention.

No engine, DECISIONS, THREATMODEL, SPEC or `tests/gates/**` change, and the
test count is unchanged. This change touches none of 0.12.0's tag,
Release, files or PyPI release, or the README's pins; after it merged, the
Release notes gained one paragraph (section above), and anything more is
Nelson's decision. Draft #597 still has to take in main.

#600 merged as `c4dee609e11332b30f6a6ddb72c1d3c3e9e69583` at
2026-11-11T16:33:20Z, with parents `eb4fdab6` and `0eb09fe1` and the tree
its receipt verified (`7060f95d`). Claude asked 「要用 merge commit 合併 #600
嗎？」 and wrote the buttons; Nelson answered 「核准合併 #600」 at
2026-11-11T16:32:56Z. Its receipt `evidence/pr600-c08edfe1807c-20261111`
(`959af556`) was verified by run 43058015984, which set the four required
checks; that run's separate `intake` job, which collects quality
candidates from other projects, failed on HTTP errors from GitHub's API.

## 2026-11-11: one hosted verification per release, on macOS and Linux (D-204)

From the release after v0.12.0, each release gets one verification on
GitHub-hosted runners,
`macos-latest` (Apple silicon) and `ubuntu-latest`, Python 3.11 to 3.13,
under EC POLICY `checkwash-release-hosted-verification-20261111` (EC
T-647): `.github/workflows/release-hosted.yml`, dispatched in two
checkpoints, at the release merge before the tag and on the published
files before the PyPI approval
([RELEASING](docs/RELEASING.md#hosted-release-verification)). The first
checkpoint also runs the composite Action at the release's Action commit
once on `ubuntu-latest` with Python 3.12, the README's setup, from a
checkout of that commit. A failure stops the release; a checkpoint that did
not run in full needs Nelson's own-words acceptance for that version.
The two perf-gate budget checks, skipped on macOS since 2026-10-01 and
kept so by D-170 until a revisit before 1.0, stay skipped there at 1.0 and
are disclosed as not verified on a Mac; on Linux they run. Each pull request's tests
still run on PJU, and the other hosted test workflows stay disabled.

Nelson chose macOS and Linux on 2026-11-11 (「是，D-甲」, to Claude's
question and options), answered eight of the design's nine questions with
「都照建議」 (all as recommended), approved the POLICY row with
「照這樣入帳並開始」 (enter it like this and start) and, after a review found
two factual errors in the row, its correction with 「照兩處更正入帳」.
[D-204](DECISIONS.md) has the record. He approved D-204 (L1) and the
Determinism row of `docs/stability.md` (L2) with 「核可 L1 和 L2」 at
13:58:22Z; that answer is not a merge approval. The workflow has not run
yet. Its first run, for
v0.12.0, follows this merge and comes before the outreach post. Its results
are labelled `HUMAN_AUTHORIZED_GITHUB_HOSTED_NOT_PJU_RECEIPT`: hosted
evidence, not a receipt. `action/README.md` still says Linux and macOS are
`NOT_RUN` for the composite; it changes after the first run, pointing at
its record.

#599 merged as `eb4fdab6fbae82da3945b8b2e511445c9630214b` at
2026-11-11T14:31:19Z, with parents `fb71bc75` and `f4b5e327` and the tree
its receipt verified (`2d50be02`). Claude asked 「要用 merge commit 合併 #599
嗎？」 and wrote the buttons; Nelson answered 「核准合併 #599」 at
2026-11-11T14:30:39Z. Its receipt `evidence/pr599-aa1af89921e2-20261111`
(`d93fc9dd`) was verified by run 43038789440, which set the four required
checks. The workflow's first run followed at 14:31:56Z (section above).

## 2026-11-11: the README states four more limits; stale statements corrected

The heading's date is Asia/Taipei; the times below are UTC, on 2026-11-10.

Nelson asked for a fresh review of checkwash (「從新審一次checkwash」,
14:16:33Z). Claude reviewed main `8f610be9` and listed corrections to the
project's public statements in three stages. Claude asked 「發文要等門面和
第一週的坑修完（出一個小版本）之後再發嗎？」 (should the launch post wait until
the front page and the first-week problems are fixed, in a small release?);
Nelson answered 「先修再發」 (fix first, then post) at 16:10:48Z. Claude then
asked 「要我現在開始第一段裡不用你另外核可的文件修正（1-2～1-4）嗎？」 (shall I
start now on the documentation corrections in the first stage that need no
separate approval from you, items 1-2 to 1-4?); Nelson answered 「開始」
(start) at 19:55:51Z. Claude wrote both questions and their buttons. This
change is those three items: documentation and one test pin. No engine,
fixture, SPEC, THREATMODEL or DECISIONS change.

- **README, "Know the limits".** Four statements are new.
  - Test files are found by name. A Python test file not named `test_*.py`
    or `*_test.py`, one under a directory pytest skips by default, a test
    function outside pytest's default names, or a JS/TS file outside the
    runners' zero-configuration layouts is not read, and a weakened
    assertion in it passes with no notice.
  - A JS/TS pass covers less than a Python one, and which tests a runner
    configuration collects is not read.
  - An edit to a tracked guardrail file at the repository root is critical,
    with the exemption ledger and file creation as exceptions; the
    `guardrail` role's paths can be replaced in a base-side config (SPEC
    §2), and the README says what that costs.
  - The Claude Code hooks are author-side checks, not a merge gate.

  Each was reproduced with the published 0.12.0 CLI on LAPTOP-01AGNPJU
  (Windows, `HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`), by Claude or by the
  sub-agent that reviewed the first draft, except that an edit made through
  Bash does not reach the PreToolUse ask, which is read from the handler's
  matcher. Linux, macOS and a real Claude Code session are `NOT_RUN`.
- **README, refactors.** The paragraph now leads with the 6 of 60 that
  `benchmarks/refactors/expected.json` marks as blocking, 4 of them among
  the 57 strictly qualified cases, and keeps the v0.3.1 snapshot's 22/60 and
  the 4/60 replay as history. The published 0.12.0 CLI, run statically over
  the 60 cases on the same host, blocks those six and passes 54 with no
  error.
- **README, demo.** "Try it on a repository" links `examples/invoice`. The
  demo is described as eight tampering cases, no longer eight real ones:
  five are adapted from the decoy corpus's adversarial arm, one comes from
  this project's release gate, and two are labelled synthetic in their own
  case files. `tests/test_packaging.py` pins the count without "real". The
  demo's banner, the `demo` line of `checkwash --help` and the 0.12.0
  package description on PyPI still say "real tampering cases"; those are
  product output and a published page, and wait for a release.
- **Stale statements.** `action/README.md` said in the present tense that
  the hosted `action-security` qualification runs on three operating
  systems; it last ran on 2026-10-22. `docs/testing-on-pju.md` said there is
  no administrator bypass and that the release workflow remains disabled;
  one temporary bypass was used on 2026-10-24 (RELEASING), and `release.yml`
  has been active since that day. `docs/enterprise.md` §5 said the Linux and
  Windows legs still enforce the performance budgets; a pull request's suite
  now runs on Windows only, and the budgets time `analyze` in memory, not a
  hook run. `CONTRIBUTING.md` said v0.1 is Python-only.
  `benchmarks/refactors/README.md` gave 1.17% as the published
  false-positive rate; the README records 1.72%.
  `benchmarks/decoy/README.md` said the replay gate runs in CI on every
  push.

Not changed here, and waiting on Nelson: the README's CI badge, which shows
the last result of the `ci` workflow, disabled since 2026-10-23 (he wrote
「README 第一屏這次不改。」 on 2026-11-08, and the badge is on that screen);
the THREATMODEL rows the review found wider than their Closed status; and
the repository settings the review listed. Also not changed: the hosted
qualification that `action/quality/README.md`, `docs/quality.md` and
`tests/gates/README.md` still describe as current, and the wording of
`examples/invoice/README.md`. Draft #597 (D-203) edits this file's first
lines and adds the same #596 paragraph below; whichever merges second takes
the other in.

#598 merged as `fb71bc757b5133ef239eb141b42db383df790730` at
2026-11-11T02:39:49Z, with parents `8f610be9` and `0224b16c` and the tree
its receipt verified (`620ad565`). Claude asked 「要用 merge commit 合併 #598
嗎？」 and wrote the buttons; Nelson answered 「核准合併 #598」 at 2026-11-11T02:39:32Z. Its
receipt `evidence/pr598-b16610aee91e-20261110` (`641d12ba`) was verified by
run 42907498206, which set the four required checks.

## 2026-11-08: the PyPI upload action moves to v1.14.3

The `pypi` job in [release.yml](.github/workflows/release.yml) now uploads
with `pypa/gh-action-pypi-publish@7245906fb61fa33a13554f9d5fb856fe61758086`,
the commit that the signed tag v1.14.3 (tag object `aef6c9b6`) points to. It
replaces `dc37677b2e1c63e2034f94d8a5b11f265b73ba33`, v1.14.2, pinned since
`b25ec991` (2026-08-21). Advisory GHSA-5xjx-3w67-w9x9 (critical, published
2026-10-30) lists v1.14.2 and earlier as affected and 1.14.3 as the first
patched version. It says the action bundled the emSign root CA through
`certifi`, the TLS trust store that Sigstore uses for Trusted Publishing and
digital attestations; its summary calls this the revocation of a CA in that
chain. The v1.14.3 tag message says the release pins the action's Python
dependencies by hash and removes a revoked, untrusted CA from them. Between
the two commits the action changes only its dependency files, its
Dockerfile, its smoke test workflow and its funding file; its `action.yml`
is unchanged, so the step keeps `packages-dir: dist/`.

v0.11.0 and v0.12.0 were uploaded with v1.14.2 after the advisory was
published; their publication records show PyPI serving the same SHA256
values as the GitHub assets. The new pin takes effect at the next release.
Nelson asked for this change (「1.14.3 再開一個pr」, open another pull request
for 1.14.3) after Claude listed the advisory as open. Only that step and
this file change.

#596 merged as `8f610be9b57c2cf228d16cb5898b25d770f746f2` at
2026-11-08T12:55:39Z, with parents `86e5322e` and `a321a1e0` and the tree
its receipt verified (`6125bc9c`). Claude asked 「要用 merge commit 合併 #596
嗎？」 and wrote the buttons; Nelson answered 「核准合併 #596」 at 12:55:10Z. Its
receipt `evidence/pr596-f949cddb4f80-20261108` (`f8c8fced`) was verified by
run 42482215741, which set the four required checks.

## 2026-11-08: the first execution satellite, checkwash-prove

[docs/satellite-execution.md](docs/satellite-execution.md), the T3.5 design
note, now links [checkwash-prove](https://github.com/taipei49314/checkwash-prove),
a mutation tester built outside this repository: it runs a change's old and
new tests against mutants of the product code. It keeps the note's four
rules (its own repository, package and command; no import either way; off
any required check; its own threat model), so checkwash's hard constraint is
unchanged: `check`, the Action and the hooks run no code and never start it.
Nelson chose "Separate satellite package" when Claude asked where `prove`
should live (Claude wrote the options), after asking that it not conflict
with checkwash (「注意不要跟checkwash那個打架」); to Claude's question whether
the note should link to it, he answered 「加」 (add it). A `checkwash prove`
subcommand built first on a local branch was never pushed; on his answer
「刪掉」 that branch has been deleted. Only the note and this
file change; no code, test, fixture or decision changes.

#595 merged as `86e5322e510c7545205f79bfcbcdcb20a16ae560` at
2026-11-08T12:07:04Z, with parents `9a72e05f` and `ee369772` and the tree
its receipt verified (`3b21128c`). Claude asked 「要用 merge commit 合併 #595
嗎？」 and wrote the buttons; Nelson answered 「核准合併」 at 12:05:45Z. Its
receipt `evidence/pr595-ef26ce80b362-20261108` (`19c430a3`) was verified by
run 42475169603, which set the four required checks.

## 2026-11-08: v0.12.0 published

v0.12.0 is the verified public release: GitHub Release 437647350 and PyPI
0.12.0 serve the same bytes, built from M
`ffaf4ed86ecc2baeb8cc008487a44d8495da9177`, and the tag (object
`6f8b8b7a95f8c6070a0c4bfb1e3ea5a9cb534fe2`) points at the Action commit A
`532f74ab070a924b23e2cc70e5d0091a05d8401d`, the first tag under D-200. The
PR, main, tag, release-event and public-visitor stages each passed on
LAPTOP-01AGNPJU (`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`), all collected and
verified from `review/collector-d-012-20261107` (`e27eec6b`); other
platforms remain NOT_RUN. #592 merged as M at 2026-11-07T13:13:05Z on
Nelson's 「核准合併 #592」. Before the tag he answered 「看過，可以打 tag」 to
Claude's question on the fixed-corpus comparison's 19 moved commits and the
verdict gate's i198/S1 report, and he answered that he had approved the
PyPI deployment on the run page, where GitHub records the approval; Claude
made no approval call. RELEASING quotes each question and answer.
Details: [RELEASING](docs/RELEASING.md#v0120-checked-publication-and-pin-promotion-2026-11-08)
and the [publication record](docs/releases/v0.12.0-publication-verification.md).

The advertised manifest and the README CLI commands now name v0.12.0, and the
README, `doctor`, the self-audit workflow and the receipt tools pin A, so a
fresh PJU receipt's pinned Action checkout is A. The advertised commit, and
the table's last published CLI commit below, is A, the tag's peeled commit;
the distributions are built from M, which differs from A only in `doctor`'s
own pin line. The PyPI 0.12.0 description is the release merge commit's
README, which still names v0.11.0; KNOWN-ISSUES-v0.12.0 says so. Claude ran
RELEASING's package page check only after the upload this time and found
nothing to correct. On Nelson's answer 「先不要改」, THREATMODEL item 4 and
row 2 stay as they are, naming only the 0.11.0 disposition. In every stage
the verdict gate reported i198/S1 as pass-to-block: D-199 blocks it, and its
label `pass` predated D-199.

#593, the step-8 follow-up, merged as
`25823bbbcefb31214c161214d38c6aaebcf7617b` at 2026-11-07T21:02:27Z, with
parents `ffaf4ed8` and `9e4fc228` and the tree its receipt verified. Claude
asked 「要用 merge commit 合併 #593 嗎？」 and wrote the buttons; Nelson answered
「核准合併 #593」 at 21:01:19Z. Its receipt
`evidence/pr593-baf8341f932c-20261107` (`8ee3b13e`) was verified by run
42403391882, which set the four required checks. Claude then asked
「step 9 要照建議開始嗎？」 (start step 9 as recommended?) and wrote the buttons,
and its message listed the four items the recommendation includes; at
2026-11-08T02:44:42Z Nelson chose 「照建議開始」 (start as recommended). On that
answer #594 moved D-197 to D-201 to
[DECISIONS-archive-5](DECISIONS-archive-5.md), rotated the verdict baseline
to v0.12.0 and, as his ruling, relabelled i198/S1 `block`; v0.12.0 blocks
the case, so the blocked pin goes 160 -> 161 (D-202, which quotes the four
items). 1.0 is NOT_MET and needs Nelson's decision.

#594 merged as `9a72e05f0570b7fa75ade06aa727fafd1650da92` at
2026-11-08T04:33:59Z, with parents `25823bbb` and `fb457a44` and the tree
its receipt verified (`071a20ad`). Claude asked 「要用 merge commit 合併 #594
嗎？」 and wrote the buttons; Nelson answered 「核准合併 #594」 at 04:33:31Z. Its
release-stage receipt `evidence/pr594-cec3d3cf45b2-20261108` (`fed7d671`)
was verified by run 42446809873, which set the five checks. The 0.12.0
release work ends there.

## 2026-11-07: the 0.12.0 release pull request

#591 merged as `e27eec6b2e56a05be33ce8b45f398482740d234b` at
2026-11-07T04:50:54Z, with parents `54113c06` and `f2f2e0e6` and the tree
its receipt verified: D-201, the section below. Claude asked 「要用 merge
commit 合併 #591 嗎？」 and wrote the buttons; Nelson answered 「核准合併 #591」 at
04:50:22Z. Its receipt `evidence/pr591-752094232448-20261107` (`e7c99bd4`)
was verified by run 42337274850, which set the four required checks.

Claude then asked 「要開始 0.12.0 的發版準備嗎？」 (start preparing the 0.12.0 release?)
and wrote the buttons; at 04:53:23Z Nelson chose 「開始準備」 (start preparing).
RELEASING's section "v0.12.0 release under the pre-1.0 delegation" quotes it
and records this release's authority, the same delegation as 0.11.0's.

- Version 0.12.0 in `pyproject.toml`, the package and `uv.lock`; the
  README's version sentence and 0.12 labels (its install commands and Action
  pin stay on v0.11.0 until step 8); the release guide
  ([v0.12.0](docs/releases/v0.12.0-public-launch.md)) and
  [KNOWN-ISSUES-v0.12.0](docs/KNOWN-ISSUES-v0.12.0.md), which carries the
  0.12 section's rows of KNOWN-ISSUES-next, where they stay; the release
  history; the labels in SECURITY, the Action README, embedding, enterprise,
  defence-design and stability; and embedding's upgrade notes for D-201 and
  D-200.
- The trusted ref `review/collector-d-012-20261107` = `e27eec6b`, cut from
  main after #591 merged and recorded in RELEASING's 0.12.0 bootstrap
  paragraph.
- Fixed-corpus comparison (RELEASING's 0.12.0 section): the published
  v0.11.0 zipapp against the candidate `src/` tree `bcad1326` on the 3,600
  members, 2026-11-07 04:58:22Z to 05:51:53Z on LAPTOP-01AGNPJU
  (`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`): 19 commits move from pass to
  block (8 Python, 11 JS/TS: D-199's 18 and D-201's rich `655b5210cb`), none
  the other way, and 12 more differ only in their reports. Records:
  checkwash-lab `472d3786` and `c58bc9bf`. The tag waits for Nelson's review
  of the list.
- The targeted uvloop diagnostic: v0.11.0 and the candidate each pass the
  three inputs D-187 accepted for 0.10 only, with no finding.
- [D-176's 0.12.0 disposition](docs/d176-cost-disposition-0.12.0.md): for a
  broad `except` in a Python test or conftest 0.12.0 changes nothing
  (D-176's refusal still removes its only repair evidence, the opaque
  fallback, before D-199's is reached), so the risk is 0.11.0's; Claude
  accepts it, unmeasured, for 0.12.0 only, under the delegation. THREATMODEL
  item 4 and row 2 still name only the 0.11.0 disposition; they are
  agent-read-only, and Claude asks Nelson whether to name this one, as for
  0.11.0.
- Review: one read-only Claude sub-agent reviewed the first draft
  (`bcd487cc`, not pushed) against the comparison records, `gating.py`, the
  moved commits' diffs and the session transcript; release-record pull
  requests get one reviewer since 2026-11-04, and this review is also the
  independent review the D-176 disposition names. Claude checked each of its
  20 findings (one high, four medium) against the source, and all held. Each
  is fixed here, among them a wrong reading of rich `b93d3b6d` (an unchanged
  move, not an extended test), the D-176 record's claim that D-199 widens
  that refusal, and the uvloop result, now recorded by a probe
  (checkwash-lab `c58bc9bf`), except two that wait for a later step and are
  recorded here: THREATMODEL item 4 and row 2 (above), and `--tag-source` in
  the local stage scripts, which the tag stage needs (RELEASING, scheme S).

Status: the release pull request, branch `claude/v012-release-20261107` from
main `e27eec6b`, with content commit A and then R (scheme S); not merged.
Run on A before R, on LAPTOP-01AGNPJU
(`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`): the tests that read these
documents, and checkwash on its own range with A's engine and with the
published v0.11.0 pyz. Not run on A: the full suite, which the release
bridge's `pr` stage runs on R, and every other platform (NOT_RUN).
Merging waits for Nelson's approval, the tag for his review of the 19 moved
commits, and the `pypi` deployment for his own approval on the run page.

## 2026-11-07: three holes beside D-191's residual close (D-201)

#589 merged as `54113c063e0b17ab7db94b4a30036a381cb5a0e5` at
2026-11-06T15:29:34Z, with parents `af0c5651` and `8fd9d11e` and the tree its
receipt verified: D-200, the section below. Claude asked
「要用 merge commit 合併 #589 嗎？」 and wrote the buttons; Nelson answered
「核准合併 #589」 at 15:29:10Z. Its receipt
`evidence/pr589-779230bdc9fd-20261106` (`58b44b6f`) was verified by run
42242971385, which set the four required checks.

D-199's design listed in its section 7 three holes beside D-191's residual
and recommended closing them in 0.12. After #589 merged, Claude asked
whether to close them before the 0.12.0 release, and at 2026-11-06T15:33:38Z
Nelson chose the button 「先補三個缺口」 (close the three holes first), which Claude
wrote. D-201 quotes the question.

- An equality with `unittest.mock.ANY` as a whole operand (`== ANY`,
  `assertEqual(x, ANY)`, `assertAlmostEqual(x, ANY)`, a chain of `==` each
  link of which has it, `not (x != ANY)`, `approx(ANY)`), membership in a
  display holding it and a padded tuple that checks no position are
  TAUTOLOGY; a display of nothing but `ANY` (nested, repeated, generated) is
  TYPE_SHAPE and keeps its source as its expectation; `ANY in x` is TRUTHY.
  Rewriting an expected value into one is `ASSERT_WEAKENED`, which takes no
  `DEPENDENCY_DRIFT` and, in Python, no repair evidence. `ANY` is read
  through the file's imports, a bare name through Python's scopes. Open:
  `ANY` through a parametrize column, a fixture, another module's constant
  or a call, a comparison wrapped in another, mock's call objects and
  `assertTrue(x == ANY)` (THREATMODEL row 182).
- D6 grants `COMPAT_GATE` to a single test's skip only when its condition is
  provably false in some environment of the matrix, read exactly for the
  interpreter, machine and architecture, and the gates a change adds leave
  one together with the gates the test had (`unittest.skipIf`, `skipUnless`
  and a strict xfail take part; a test its gates already kept from every
  environment is not asked). The matrix holds CPython 3.11 to 3.14 and PyPy
  3.11 and each platform's two machines, with the micro release unknown;
  `in` asks every entry. A suite-level collection control and liveness
  (`unit_is_live`) keep the old reading.
- `assertEqual` -> `assertCountEqual` (and the other order-sensitive
  unittest equalities, `assertMultiLineEqual` and `assertDictEqual`
  included) on the same subject, followed through the unit's bindings with
  copies into a list or tuple taken off, is `SUBJECT_NORMALIZED`; a set
  operand gives nothing, a dict one says it compares only keys.
- SPEC §3, §4 and §5, THREATMODEL item 6, rows 14, 44, 55 and 57 and a new
  row 182, and KNOWN-ISSUES-next's 0.12 section.
- Review: five Claude sub-agents reviewed `e67f6fd6`; two Claude sub-agents
  and a Gemini 4 Argon run reviewed `2a05a379`; one Claude sub-agent
  reviewed `8747e88c`. Each round's fixes are in D-201's review paragraph,
  and the verdicts on each finding in the pull request. The third round's
  fixes (`262cbe27`, and `bffc1f55`, which walks the new scope reading
  iteratively for deep input) were not reviewed again; the 218 toy cases of
  all three rounds were run on them.
- Cost: on D-088 2 of 1,263 commits move from pass to block (scrapy
  583df9f7d0, rich 655b5210cb), on R29 1 of 3,600 (rich 655b5210cb), and
  outside both samples 6 of 1,273 skip-touching commits (pytest's 2007–2013
  history); nothing else changes on the two samples (D-201's cost
  paragraph). No existing fixture or unit-test expectation moves, and
  `gating.py` does not change.

New: `tests/test_d201_section7_holes.py` (208 tests) and 77 fixtures; the
documented count is 22854. On main `54113c06`, 54 of the 57 new `_pos`
fixtures fail: the holes, and `compat_gate_old_pythons_only_pos`, a cost
D-201 states. Two of them, `mock_any_count_changed_pos` and
`mock_any_keys_changed_pos`, block on main too, as another rule. The other
three, `project_any_constant_is_not_mock_pos`,
`standin_behind_unknown_gate_pos` and `compat_gate_guard_ne_none_pos`, guard
regressions first found in a review of this branch, which main never had.
All 20 `_neg` fixtures pass on main.

Status: merged as #591 (`e27eec6b`, above), after Nelson approved D-201's
text with SPEC, THREATMODEL and the D6 policy (L1 of #591) and the labels of
the 77 new fixtures (L2) at 2026-11-07T03:35:09Z with the button 「核可 L1 和
L2」 (approve L1 and L2), which Claude wrote; D-201 quotes the question.

## 2026-11-06: from v0.12.0 the release tag points at the Action commit (D-200)

#588 merged as `af0c565136afef82a03d17becdd802e16633da65` at
2026-11-06T14:38:31Z, with parents `19f400ca` and `4460ebdf` and the tree its
receipt verified: D-199, the section below. Claude asked
「要用 merge commit 合併 #588 嗎？」 and wrote the buttons; Nelson answered
「核准合併 #588」 at 14:38:11Z. Its receipt
`evidence/pr588-c1043d86368e-20261106` (`89538541`) was verified by run
42225369163, which set the four required checks.

On 2026-11-02 Nelson approved pointing the release tag at the Action commit
A from 0.12 (D-196 item 3), with the design to go to him first. Claude's
design went to him on 2026-11-05. Asked how to handle a CLI installed from
the tag, whose `doctor` rejects its own release's pin, he chose the option
Claude wrote, 「甲：拿掉那行（建議）」, at about 17:40:16Z, and at 17:42:17Z the
button 「開始實作」. Claude wrote the questions and the options. D-200 quotes
them. Nelson approved D-200, the test changes and the allow key (L1 to L3
of #589) at 2026-11-06T11:49:53Z with the button 「兩個 PR 全部核可」, which
Claude wrote. The key merged first, with D-199's, as #590.

From v0.12.0 a release tag points at A = `M^2^1`, and its message names the
release merge M on one line, `Release-Merge: <M>`. M stays the head of every
release stage and the commit the distributions are built from. Up to v0.11.x
the tag points at M, as before. One boundary, in
`tools/published_release_identity.py`, serves every tool, and no tool
accepts either rule.

- The release bridge reads M's and R's commit objects at `tag` and later,
  requires the tag to peel to A and its message to name M, and at
  `release-event` requires the capture's workflow commit to be A. The
  release-event capture reads M from the tag's message, checks `M^2^1`
  against the event's commit and records M as the head, with no new
  endpoint. The tag source receipt and the tag visitor bind A.
- The collector checks the local tag the same way. From v0.12.0 it takes
  `--tag-source`, a checkout of A, for the tag source receipt and visitor.
- The verdict gate's tag rule requires the tag at `HEAD^2^1` and its message
  to name HEAD. From a v0.12.0 or later baseline pin, the pyz's members must
  equal A's `src/checkwash` with `doctor.py`'s own pin line set to A, and
  only when A's two pin lines are equal; the release bridge applies the same
  rule.
- `tools/own_action_pin.py tag` prints the tag command. From v0.12.0
  `check --stage tag` checks, before the push, the local tag, the main
  stage's report and the remote's main, and A's bytes of the files the
  release-event capture runs against the trusted ref.
- `test_packaging` checks the Action pin in three eras. The README no longer
  offers an install from the release tag, and its pin section and
  KNOWN-ISSUES-next say why. The release documents describe 0.12 with
  0.11.0 as the exception, and the disabled hosted workflows note that their
  tag-push path does not follow D-200.

New: `tests/test_release_tag_at_action_commit.py`, 79 tests that run each new
check both ways on owned Git chains and owned native metadata, and
`test_release_action_commit_from_v0_12_0_is_the_tag_commit`: 80 tests, which
took the documented count from 22461 to 22541 on main `7cd8549c`, as D-200
says, and take it from 22489 to 22569 on main `af0c5651`, with D-199's
tests. A read-only `gh api` read of the real v0.11.0 tag object calibrated
the message parse: GitHub's `message` is the tag object's bytes after its
headers, with LF line breaks. No `src/` change.

Status: branch `claude/tag-at-action-commit-20261106` from main `7cd8549c`,
with main `af0c5651` (#590 and #588) merged in; not merged. Three Claude
review sub-agents reviewed `051b608a`; their 19 findings held, none critical
or high, and `a2d4b5a6` and `3fee787b` fix or record each (D-200's review
paragraph). On LAPTOP-01AGNPJU (`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`,
Windows CPython 3.11.9) on 2026-11-06 Asia/Taipei, at `3fee787b`: the full
suite (`pytest tests`, `tests/gates` included, xdist `-n 8`), whose JUnit
testsuite counts `tests="22608"`: 22541 testcase entries, 22516 passed and
25 skipped, plus 67 subtests, with 0 failures and 0 errors; and checkwash's
own check of the range from main `7cd8549c` at `--fail-on high`, with that
tree's engine, whose `src/` was main's and differed from the published
v0.11.0 Action commit's only in `doctor`'s two pin lines, which `check` does
not import. It blocked with one high finding, `SUBJECT_NORMALIZED` on
`test_readme_install_refs_match_advertised_release`, the relaxation option
甲 makes, and five warnings; #590 put that finding's key on main. The pull
request's description records the full suite and checkwash's own check after
the merge, and the pull request's PJU receipt. Not run: other platforms, and
any real tag or release event: the new path first runs for real at 0.12.0.

## 2026-11-06: the weakening, stand-in and subject rules take no repair evidence (D-199)

#587 merged as `7cd8549c5a556a82c967e74cfae46f1a86053abc` at
2026-11-04T23:19:07Z, with parents `003e12dd` and `c51d4762` and the tree its
receipt verified. Claude asked 「要用 merge commit 合併 #587 嗎？」 and wrote
the buttons; Nelson answered 「核准合併 #587」 at 23:18:33Z. Its receipt
`evidence/pr587-0973126bd7be-20261105` (`b30c8f52`) was verified by run
41913448234, which set the four required checks.

#590 merged as `19f400ca966b10f2402b3f7438a225ebdae76ccf` at
2026-11-06T12:43:28Z, with parents `7cd8549c` and `23c645f5` and the tree its
receipt verified. It records the 29 allow keys that this change's and
D-200's own checks block on (#588's L4, #589's L3). Claude asked
「要用 merge commit 合併 #590 嗎？」 and wrote the buttons; Nelson answered
「核准合併 #590」 at 12:43:05Z. Its receipt
`evidence/pr590-7d783c3bcf40-20261106` (`198129ac`) was verified by run
42219389027, which set the four required checks: the first run on GitHub
of D-198's receipt bridge.

D-196 planned two changes for 0.12, each designed and priced before it is
built. This is the second: D-191's residual. Claude's design priced five
Python options and three JS/TS options on main `7cd8549c`; Nelson chose R
for Python and the loosening shapes for JS/TS, and then chose the button
「開始實作」 when Claude asked whether to start implementing. D-199 quotes
him.

- In a `.py` file, in practice a test or conftest, and for an import-shadow
  stand-in wherever it is reported, `ASSERT_WEAKENED`, `ASSERT_REMOVED`,
  `TEST_DISABLED`, `TOLERANCE_LOOSENED`, `BROAD_EXCEPT_ADDED`,
  `TEST_PATCHES_SUBJECT`, `CONFTEST_PATCHES_PROD`, `SUBJECT_NORMALIZED`,
  `SUBJECT_INPUT_CHANGED` and `EXPECTED_VALUE_DERIVED` take no repair
  evidence, symbol or opaque. In a JS/TS test, a weakened or loosened
  assertion, a broad catch, a skip added to a live test and a table left
  with no row to run take none.
- A row marked off with `pytest.param(..., marks=skip)`, rows deleted beside
  one, and a table left with no row to run, a plain test wrapped in an empty
  parameter set among them, are no longer read as removals, for D8 too, as
  D8's SPEC row always said. A JS/TS plain test paired with a table whose
  rows cannot be counted still reads as a deletion, as tests folded into an
  imported table do.
- Such a finding that the evidence reached, and that nothing else holds, is
  high with the new E1 label `REPAIR_EVIDENCE_REFUSED`.
- On main `7cd8549c` this moves 18 of the fixed corpus's 3,600 commits pass
  → block (7 Python, 11 JS/TS) and 53 of D-088's 1,263, among them the 11
  that stopped #464; none is adjudicated, and no commit moves the other way.
- Still open (THREATMODEL item 4, rows 2, 56, 93, 130, 131): a rewritten
  expected value or a substituted assertion beside a no-op edit, a weakening
  respelled as an exact comparison and an expectation computed through a
  module alias included; a renamed private symbol escorting a test deletion
  into D8, and D8 counting a row marked off as deleted where the rows cannot
  be paired; and in JS/TS a removed assertion or test, a test parked in dead
  code and a stand-in or subject change, beside any module edit.
- 21 fixtures keep their inputs and move from `_neg` (one from `_warn`) to
  `_pos`; `conftest_hook_guard_opaque_prod_neg` keeps its name and is now
  held by `COMPAT_GATE`. Unit tests that pinned the old warn are listed in
  D-199, with the tests the review added. Nelson approved the text, each
  move, the test pins and the 28 allow keys (L1 to L4 of #588) at
  2026-11-06T11:49:53Z with the button 「兩個 PR 全部核可」 (approve everything
  in both pull requests), which Claude wrote. The keys, for the findings
  this pull request's own check raises on its test rewrites, go in a
  separate allow-keys pull request that merges first, as #554 did for
  D-171.
- The 0.12.0 release needs a new D-176 cost disposition: the 0.11.0 one
  covers only that release's `src/` tree.

## 2026-11-05: receipts spread over the receipt host's cores (D-198)

#586 merged as `003e12dd5d447ed45e4ffd5658f331a8541ffbfb` at
2026-11-04T16:38:49Z, with parents `78dba277` and `88da4f95` and the tree its
receipt verified. Claude asked 「要用 merge commit 合併 #586 嗎？」 and wrote
the button; Nelson answered 「核准合併 #586」 at 16:37:54Z. Its receipt
`evidence/pr586-98d797fac38b-20261104` (`b8a95e6b`) was verified by run
41861846875. That run set the four required checks and
`PJU release evidence (pr)`. That ends the 0.11 line.

Earlier that day, while #586's receipt was collecting, Nelson had asked to
cut the time a release costs. After the merge he chose to start; D-198
quotes him. A receipt now spreads its work over the receipt host's cores:

- the full suite runs with 8 xdist workers instead of 2, and both bridges
  require 8;
- the source, wheel and pyz qualify -> inventory chains run at once;
- a release-stage collection runs `verdict_gate.py --jobs 6`.

What runs and what each record proves do not change. The receipts record
the new counts, and their ledgers list overlapping commands. The gate's own
receipt is byte-identical to a `--jobs 1` run's.

Measured on LAPTOP-01AGNPJU (`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`):
- the verdict gate alone took 4 min 12 s instead of 16 min 2 s;
- a release-stage collection took 43 minutes instead of 82 to 86 (98 for
  #586's);
- an ordinary collection took 31.5 minutes instead of 55 to 60;
- after the review, the final code's release-stage collection took 36.75
  minutes.

The new bridges verified all three collections locally, and none was
published. This pull
request's own receipt is collected by main's collector, the one it
replaces. Hosted test workflows remain disabled.

## 2026-11-04: v0.11.0 published

v0.11.0 is the verified public release: GitHub Release 433182824 and PyPI
0.11.0 serve the same bytes, from M `34555301de3d5ea4b2c8e4470b797a06d0a1e395`
(tag object `2f5ac3fecaddfe5f99ae6e6e129b4d73abb3dfc0`). The PR, main, tag,
release-event and public-visitor stages each passed on LAPTOP-01AGNPJU
(`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`), all collected and verified from
`review/collector-d-011-20261103` (`fa8a8ea0`); other platforms remain
NOT_RUN. Nelson approved the release merge, reviewed the fixed-corpus
comparison's empty list before the tag and personally approved the PyPI
deployment; RELEASING quotes each question and answer.
Details: [RELEASING](docs/RELEASING.md#v0110-checked-publication-and-pin-promotion-2026-11-04)
and the [publication record](docs/releases/v0.11.0-publication-verification.md).

The advertised manifest and the README CLI commands now name v0.11.0, and the
README, `doctor`, the self-audit workflow and the receipt tools pin the
Action commit A `257150319fca15235185fc629d8b9c21c17166ca` (`v0.11.0^2^1`,
D-194), so a fresh PJU receipt's pinned Action checkout is A. Under
Nelson's 2026-10-28 answer 「開始」, which RELEASING quotes, #586 then moved
D-188 to D-196 to [DECISIONS-archive-4](DECISIONS-archive-4.md) and rotated
the verdict baseline to v0.11.0 (D-197); no case moved, so the blocked pin
stays 160. The PyPI 0.11.0 description is the release merge commit's
README, which still names v0.10.0; KNOWN-ISSUES-v0.11.0 says so. On
Nelson's answer 「可以改」, THREATMODEL item 4 and row 2 now state the 0.11.0
record: the targeted diagnostic passed the three uvloop commits with no
finding, and Claude's delegated disposition accepts the remaining risk,
unmeasured, for 0.11.0 only. 1.0 is NOT_MET and needs Nelson's decision.

## 2026-11-03: the 0.11.0 release pull request

0.11.0 is being released under the pre-1.0 delegation; RELEASING's section
"v0.11.0 release under the pre-1.0 delegation" records Claude's reading of
its scope: one attempt at `v0.11.0`, the merge after Nelson approves it, the
`pypi` deployment only by Nelson's own approval, the tag after Nelson has
reviewed the fixed-corpus list, which is empty, and other platforms NOT_RUN.
After publication the decision-log cut and the baseline rotation rest on
Nelson's 2026-10-28 answer 「開始」 to a message Claude wrote, within the
bounded shape of last time; RELEASING quotes that message.

The release pull request is content commit A, then R (scheme S, D-194). A:

- Version 0.11.0 in `pyproject.toml`, `src/checkwash/__init__.py`, `uv.lock`
  and the table below.
- The README is what PyPI shows for 0.11.0, so its version sentence now says
  that its install commands and Action pin still name v0.10.0 until the
  GitHub README moves them; "unreleased" is gone from the 0.11 notes, the
  known-issues links name the 0.11.0 page, and the `doctor` note names
  `doctor` 0.11.0. Install commands and the Action pin stay v0.10.0 until
  step 8.
- New: the release guide `docs/releases/v0.11.0-public-launch.md`,
  `docs/KNOWN-ISSUES-v0.11.0.md` (the rows of KNOWN-ISSUES-next's 0.11
  section, which stays there as the dated record) and the v0.11.0 entry of
  the release index.
- RELEASING: the delegation section with the fixed-corpus comparison, the
  uvloop diagnostic and D-176's remaining-history risk, and the trusted ref
  of the 0.11.0 chain.
- New: `docs/d176-cost-disposition-0.11.0.md`, the separate delegated
  disposition D-190 and D-191 left to this release: Claude accepts D-176's
  explicitly unmeasured remaining-history risk for 0.11.0 only.
- `docs/embedding.md`'s v0.10.0 to v0.11.0 notes said that `check` computes
  its verdict as before, true when D-189 wrote it, not since D-190, D-192 and
  D-193; they now say which verdicts change.
- Release labels that had gone stale: the user-facing documents called v0.9.0
  changes (#421, #424, #428, #454, #456, #499, #512) "unreleased" or "the
  next minor", and 0.11 features "not yet released". They now name the
  release that shipped each, in `docs/stability.md`, `docs/embedding.md`,
  `docs/enterprise.md`, `docs/remediation-upgrade.md` (old anchors kept),
  `docs/subject-integrity.md`, `docs/assertion-coverage.md`,
  `docs/integrations.md` and the `unread` description in
  `docs/findings.schema.json`. `docs/embedding.md`'s v0.9.0 notes, titled
  "Unreleased changes on main", become "v0.8.0 to v0.9.0" in release order
  (the old anchor kept), and the missing "v0.9.0 to v0.10.0" notes are
  added. `docs/enterprise.md` also links the 0.11.0 known issues, and the
  JS/TS results record gains run 6. THREATMODEL item 4 and
  row 2 still say the targeted diagnostic is pending and the remaining risk
  is not yet accepted for 0.11; THREATMODEL is agent-read-only, so they wait
  for a reviewed change Nelson approves, and this release's records are the
  disposition they point to.

R is `tools/own_action_pin.py write` on A: it sets `doctor`'s
`_OWN_ACTION_PIN` to A and nothing else.

A also fixes a test that runs only where it can create symlinks. The
six-leg batch on the first R, `abb1bf34`, passed on the three Windows legs
and failed one case on each Linux leg, with byte-equal corpus outputs on all
six: the working-tree case of
`tests/test_issue455_q4_unchanged_dot_less_refusal.py` still expected the
working-tree reader's refusal message from before `825e2dc2` (2026-10-26, in
v0.10.0), which quotes the path and names its side and entry point. Windows
without the symlink privilege skips that case, so no PJU receipt ran it. It
now expects the current message, as `tests/test_issue346_config_reads.py`
does. Re-run in Docker on the three Linux legs' own environments, the old
test failed that case and the fixed one passes all eight; on Windows seven
pass and one skips, as before. `src/` is unchanged, so the fixed-corpus
comparison and the uvloop results still describe A. The test file and the
message are unchanged since v0.10.0, so v0.10.0's own suite would fail the
same way on Linux; that is inferred, not run. This A replaces the first,
`4a8adec1`; R is rewritten on it, and the batch runs again on the new R.

The fixed-corpus comparison ran on 2026-11-02 UTC on LAPTOP-01AGNPJU
(`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`): the published v0.10.0 zipapp
against the candidate `src/` tree `6f83616e` of main `dd4ec896`; A changes
that tree only in the version string (D-196). All 3,600 fixed commits gave
identical exit codes and reports apart from the `run` block: Python 1,734
pass and 66 block, JS/TS 1,759 pass, 39 block and 2 engine errors, with
each. No outcome moves, so the
owner's list is empty. The three uvloop inputs D-187 accepted for 0.10 only
move from block to pass with no finding (D-190). Records: checkwash-lab
`252046de` (private). In-sample counts, not a false-positive rate.

Review: a Workflow run of 37 read-only Claude agents (three lenses, one
adversarial verifier per finding) and one Gemini 4 Argon run, which
completed, reviewed the first draft `81146cfa`. All 34 workflow findings
were verified as real; Argon's six include three of the same problems, and
its "Direct Answers" section states numbers the evidence does not hold,
which are not used. A second run of 18
agents re-reviewed the fixes at `c1af1bc7`, the new D-176 record included:
15 of its 16 findings were real. Every applied fix was checked against the
source by Claude. Records: checkwash-lab `43c3c2d7` (private).

Status: the release pull request from `claude/v011-release-20261103`; not
merged. A is on main `fa8a8ea0` (#583's merge, whose `src/` tree is still
the compared `6f83616e`), and R follows it. On LAPTOP-01AGNPJU
(`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`, Windows CPython 3.11.9) on
2026-11-03 UTC, on A: the 81 test files that read the README, the release
documents, STATE, the version or the Action pins (6,735 passed and 16
existing skips, plus 36 subtests, with 0 failures), and checkwash's own check
of A against main with A's engine and with the published v0.10.0 pyz, which
passes with one warning, `CI_WORKFLOW_TOUCHED` for `pyproject.toml`. The
release bridge's `pr` stage runs the full suite on R, and the six-leg batch
runs on R; its result is recorded with the release. Not run: other
platforms.


## 2026-11-03: the README puts the start before the release history

On 2026-10-28 Nelson answered Claude's five 0.11 questions, and his item 4
began 「readme等到修復後重排」 (restructure the README after the repairs land;
D-191 quotes the whole answer). The repairs, D-189 to D-195, are on main
`066d8698`. Every choice below is Claude's under the 2026-10-27 delegation.

The README now reads: what checkwash does, with one sentence saying the
install commands use v0.10.0 and 0.11 is unreleased on main; three ways to
start, "Use it with Claude Code" (the Stop hook, and from 0.11 the local
default and the PreToolUse ask), "Try it on a repository" (the pyz) and "Use
it in CI" (the workflow and the required check); "When checkwash blocks" (the
result table, reading a finding, the reviewed exemption read from the base,
reporting a false block); "Know the limits"; "CI details: doctor and the
pin"; "More options and evidence".

The v0.10.0 banner above the badges and the v0.3.0 to v0.10.0 summaries
moved to a new release index, `docs/releases/README.md`, newest first, text
and link targets kept with the links made relative; it also lists each other
release's documents in that directory. Within the README, the #419 residual
(D-191) and the #419 half of the threshold paragraph moved to "Know the
limits", whose large-file details are now collapsed; the development-snapshot
paragraph, the Action trust advisory and the pin explanation (D-194) moved to
"CI details"; the workflow is no longer collapsed, so that block's summary
line is gone; two "below"s became "above". Nothing else was dropped. The
install commands and the Action pin stay v0.10.0, and the workflow fence, the
pin strings, the `doctor` 0.10.0 note and the documented test count are
unchanged. The finding shown under "When checkwash blocks" is what `check`
printed for the README's example diff on a two-commit scratch repository,
the same from main and from v0.10.0's source (LAPTOP-01AGNPJU,
`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`). The package description is the
README as built, so the 0.11 release pull request has to reword the version
sentence.

Status: merged. Nelson approved PR #583 at 2026-11-03T05:05:21Z (the
button labelled 「核准合併 #583」, which Claude wrote, answering Claude's
「要用 merge commit 合併 #583 嗎？」), and #583 merged as main `fa8a8ea0`
at 05:05:48Z (a merge commit, parents `dd4ec896` and `5a611e00`). Its PJU
receipt (head `5a611e00`, base and collector main `dd4ec896`, manifest
SHA256 `f80e3df2e7f7661ede8423169a10cc44f1f99e2658e2d59b21b621ab083e02e0`)
is published as `evidence/pr583-f80e3df2e7f7-20261102` (commit `c9b6263a`),
and intake run 41518608693 set the four required checks. On LAPTOP-01AGNPJU
(`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`, Windows CPython 3.11.9) on
2026-11-02: the receipt's full suite (`pytest tests`, `tests/gates`
included, xdist `-n 2`), whose JUnit testsuite counts `tests="22511"`:
22444 testcase entries, 22419 passed and 25 skipped, plus 67 subtests, with
0 failures and 0 errors; both Action replays and the source, wheel and pyz
qualifications exited 0; and checkwash's own check passed with no finding.
Docs only. Not run: other platforms. Not released: package metadata stays
0.10.0.


## 2026-11-03: 0.11 keeps scheme S; the fixed-corpus candidate may differ in doctor's own pin line; two 0.12 directions (D-196)

On 2026-11-02 Nelson answered three questions Claude had left open after
D-194's review (quoted in [D-196](DECISIONS-archive-4.md)). 0.11 keeps scheme S, and
he accepts with documentation that pin updaters such as Dependabot and
Renovate propose the tag's commit, which `doctor` rejects, and that
zizmor's `ref-version-mismatch` audit can report the README pin's comment
(both inferred from the tools' documentation, not run). The owner-ruled
fixed-corpus candidate rule is relaxed: from v0.11.0 a candidate may also
differ from the tag in `doctor`'s `_OWN_ACTION_PIN` line, which `check`
never imports, so the comparison and the uvloop diagnostic may run on A,
before R, with their records in the release pull request. For 0.12 he
approved pointing the tag at the Action commit A, which moves the release
chain's tag stage, tag visitor and source identity and the README's
install-from-tag command, and said that D-191's residual, deliberate for
0.11, is to change in 0.12; both designs go to him first. RELEASING and
KNOWN-ISSUES-next say so; no code or test changes.

Status: merged. Nelson approved PR #582 at 2026-11-02T19:22:01Z (the
button labelled 「核准合併 #582」, which Claude wrote, answering Claude's
「要我用 merge commit 合併 #582 嗎？」), and #582 merged as main `dd4ec896`
at 19:22:15Z (a merge commit, parents `066d8698` and `683e9786`). Its PJU
receipt (head `683e9786`, base and collector main `066d8698`, manifest
SHA256 `3edfbbb31278bd8ddf73fad6a44b416c27b20cbdd989b1b284ff9a561a50085e`)
is published as `evidence/pr582-3edfbbb31278-20261102` (commit `0ef6f8c4`),
and intake run 41504508274 set the four required checks. On LAPTOP-01AGNPJU
(`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`, Windows CPython 3.11.9) on
2026-11-02: the receipt's full suite (`pytest tests`, `tests/gates`
included, xdist `-n 2`), whose JUnit testsuite counts `tests="22511"`:
22444 testcase entries, 22419 passed and 25 skipped, plus 67 subtests, with
0 failures and 0 errors; both Action replays and the source, wheel and pyz
qualifications exited 0; and checkwash's own check passed with no finding.
Docs only. Not run: other platforms. Not released: package metadata stays
0.10.0.

## 2026-11-02: doctor accepts the release's own Action pin (D-194)

A release cannot embed its own commit SHA, so since the README stopped
lagging a release behind (2026-10-14), each published `doctor` has rejected
the Action pin the README recommends once that release is verified: 0.10.0's
accepts only v0.9.0's `d6eda4f6` and exits 1 on the v0.10.0 pin.
Nelson chose scheme S on 2026-10-28, after turning down a strict `doctor`
with a better message (「選a不就又回到之前了嗎」), kept it in 0.11 on
2026-10-31 (「doctor帶s方案」), and accepted its pin-updater consequence with
documentation (the button labelled 「接受，寫進文件」); D-194 quotes each, and
every other choice is Claude's under the 2026-10-27 delegation.

From 0.11.0 the release pull request's last commit R, staged by
`tools/own_action_pin.py write`, changes one line, `doctor`'s
`_OWN_ACTION_PIN`, to its parent A, the content commit, and the release
merges with a merge commit only. A release's `doctor` accepts two exact SHAs,
`_PREVIOUS_ACTION_PIN` (the README pin when the release was prepared) and A;
after step 8 the README, action/README and SECURITY recommend A =
`vX.Y.Z^2^1`, verified in a clone. The release bridge's
`validate_own_action_pin` checks the chain at `pr` and `main` unless the
head's version equals both its advertised one and its base's, and at every
tag and later stage, with GitHub's native merge parents; the ordinary
receipt bridge refuses a version-changing head, so a release pull request's
checks come only from the release bridge's `pr` stage. RELEASING's new
scheme-S subsection and steps 1, 2, 3, 5 and 8 give the procedure: R last
and nothing after it, main frozen from A to the release merge, R29 and the
uvloop diagnostic on R's tree, and the step-8 follow-up as the next merge.
Both pin lines are v0.10.0's here, so `doctor`'s output does not change.
Dependabot and Renovate will propose the tag's commit, which `doctor`
rejects, and zizmor's `ref-version-mismatch` audit can report the pin's
comment, for the same reason (both inferred, not run); KNOWN-ISSUES-next
lists them with the other residuals.

New: `tools/own_action_pin.py`, `tests/test_doctor_own_action_pin.py`,
`tests/test_own_action_pin.py`, `tests/test_pju_own_action_pin.py`, the
shared builder `tests/own_action_pin_fixtures.py` and
`tests/test_packaging.py::test_release_action_commit_follows_scheme_s`;
`test_packaging`'s README pin relation is version-aware, with every outcome
unchanged at v0.10.0 (D-194 lists the edited assertions).

Four Claude review agents and one Gemini 4 Argon run, which completed,
reviewed `04b469fa`. The fixes require `doctor`'s two pin lines to be equal
on the content commit (in the release bridge, `write` and `test_packaging`)
and on every head outside a release (in the ordinary receipt bridge), check
`doctor.py`'s pins against its parsed module without running it, also apply
the rule at `pr` and `main` when the head's version differs from its
base's, and make the pre-tag check `check --stage tag`; RELEASING now gives
the recovery routes, says what is procedure rather than enforced, and moves
the fixed-corpus records to the step-8 follow-up. A second review of the
fixes found two more ways to bind a pin that the parse did not see, a
non-UTF-8 coding declaration and dynamic or shadowing code; both are now
refused. D-194's *Review* and *Second review* list what was accepted and
what was declined.

Status: merged. Nelson approved PR #581 at 2026-11-02T17:46:24Z (the
button labelled 「核准合併 #581」, which Claude wrote, answering Claude's
「要我用 merge commit 合併 #581 嗎？」), and #581 merged as main `066d8698`
at 17:46:41Z (a merge commit, parents `6e8ca826` and `5e6474e9`). Its PJU
receipt on the final head (head `5e6474e9`, base and collector main
`6e8ca826`, manifest SHA256
`e077ffb2e6dad0386af362b26efca8d4ee31baa50533f22331faacf98152e7da`) is
published as `evidence/pr581-e077ffb2e6da-20261102` (commit `bc7291bd`),
and intake run 41490207402 set the four required checks. On LAPTOP-01AGNPJU
(`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`, Windows CPython 3.11.9) on
2026-11-02: that receipt's full suite (`pytest tests`, `tests/gates`
included, xdist `-n 2`), whose JUnit testsuite counts `tests="22511"`:
22444 testcase entries, 22419 passed and 25 skipped, plus 67 subtests,
with 0 failures and 0 errors; both Action replays and the source, wheel and
pyz qualifications exited 0; the earlier receipt on `abcf2146`
(`evidence/pr581-cd7874938a64-20261102`) gave the same counts; and
checkwash's own check passed with eight warnings and none at or above high
(D-194). Not run: other platforms. Not released: package metadata stays
0.10.0.


## 2026-11-02: five test relaxations from agent sessions are restored (D-195)

The 2026-10-28 session replay (local repository `C:/Users/nelson/dev/cwrp`,
results `93e602c`; D-189) labelled 12 agent edits of Python tests as
loosenings with no reason in their context. Five of them were still on main
`0e6acc35`, in checkwash's own tests. Nelson chose to bring them into 0.11
on 2026-11-02 (the option labelled 「帶進 0.11 (Recommended)」, which Claude
wrote; quoted in [D-195](DECISIONS-archive-4.md)); every detail is Claude's under the
2026-10-27 delegation.

Each time, an agent session wrote the strict check, loosened or deleted it
in its working copy and committed only the loose form minutes later, in a
test file its pull request added. The `checkwash` check compares a pull
request's base with its head, so the strict form never reached it: each
landing pull request passed with no finding on these assertions, and no
de-escalator was involved. Replayed one edit at a time with v0.10.0, each
edit blocks at high.

- Replay 672, `tests/test_issue469_limit_messages.py`: two "every test's
  replacement is found" checks compared sets with `<=`, so an extra
  TEST_PATCHES_SUBJECT unit or (unit, call) pair passed. The first is back
  to the `==` line the session wrote; the second, a `<=` since its first
  commit, now uses `==` too. Landed through #511 and integration batch 3
  (#540); `checkwash` passed both with two IMPORT_UNRESOLVED warnings on
  that new file.
- Replay 36, `tests/test_issue306_self_methods.py`: the inlined helper
  method again asserts `run(SOURCE, after) == ("pass", [])`, where it had
  checked only that three rules were absent, which also passed a block.
  Landed through #476; `checkwash` passed with two TEST_DISABLED warnings
  elsewhere.
- Replay 32, `tests/test_issue424_rebinding.py`: the compat-gated rebinding
  again pins its de-escalators as `["COMPAT_GATE"]`, where
  `"COMPAT_GATE" in` passed any extra one. Landed through #474; `checkwash`
  passed with four warnings elsewhere.
- Replay 359, `tests/test_issue415_oversized_sources.py`: the manifest
  refusal's stderr is compared whole again, where `splitlines()` passed a
  missing or different line ending. The session's strict form ended in
  `"\n"`, which fails on Windows, where the CLI's text-mode stderr writes
  CRLF; the check now ends the line with `os.linesep`. Landed through #448;
  `checkwash` (the v0.6.0 Action) passed with no finding.
- Replay 621, `tests/test_issue463_snapshot_added_production.py`: the
  deleted `test_repair_evidence_still_reads_an_added_modules_symbols` is
  back where it was, unchanged. It pins what D-157 states, that symbol
  repair evidence still reads a production file the diff adds; with that
  dropped, nothing else in the golden runner or eight related test files
  fails. Landed through #524 and
  integration batch 2 (#533); `checkwash` passed with no finding on #524's
  one run and with nine warnings elsewhere on #533.

Each restored check passes on main and fails under a one-line mutation of
the code under test, made in a scratch copy; for 672, 32 and 359 the loose
form passes under the same mutation, and for 36 under a wrong input. No
`src/` change, so R29 does not rerun. The restored test is one more
collected item. Written in place of the loose lines, the strict checks of
36, 32 and 359 made checkwash's own check block (main's engine and the
published v0.10.0 alike: three high findings and two warnings), though each
is at least as strong as the line it replaced: checkwash does not prove that
a check of another shape is stronger. So those three strict checks are added
after the loose lines, which stay, and need no exemption (D-195).

Status: merged. Nelson approved PR #580 at 2026-11-02T13:54:07Z (the
button labelled 「核准合併 #580」, which Claude wrote, answering Claude's
「要我用 merge commit 合併 #580 嗎？」), and #580 merged as main `6e8ca826`
at 13:54:47Z (a merge commit, parents `0e6acc35` and `d20784cb`). Its PJU
receipt (head `d20784cb`, base and collector main `0e6acc35`, manifest
SHA256 `4d96ee7a754b4d45165e9237f02ba07bb7c4142035c53e5cad71bc7c0fb6d091`)
is published as `evidence/pr580-4d96ee7a754b-20261102` (commit `098d3273`),
and intake run 41454848018 set the four required checks. On LAPTOP-01AGNPJU
(`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`, Windows CPython 3.11.9) on
2026-11-02: the receipt's full suite (`pytest tests`, `tests/gates`
included, xdist `-n 2`), whose JUnit testsuite counts `tests="22414"`: 22347
testcase entries, 22322 passed and 25 skipped, plus 67 subtests, with 0
failures and 0 errors; both Action replays and the source, wheel and pyz
qualifications exited 0; and checkwash's own check passed with no finding
(main's engine and the published v0.10.0). Not run: other platforms. Not
released: package metadata stays 0.10.0.

## 2026-10-31: arrivals pay only where the repository's own pytest configuration runs them (D-193)

D-192 left THREATMODEL row 179 open: a moved or folded Python test earned
its credit wherever it landed, because arrival liveness read only the
unit's own markers, never the repository's pytest configuration. On main
`3d115a35` a test moved into a file outside `python_files`, into a
`collect_ignore` file, outside `testpaths`, beneath an `--ignore` or
`norecursedirs` entry, under a `--deselect`, with a name `python_functions`
does not match, or under a standing `-k` still passed with
`ASSERTION_MOVED`, and `git mv test_app.py app_test.py` under
`python_files = test_*.py` passed with no finding while pytest ran nothing.
Nelson asked for it on 2026-10-31 (the button labelled 「接著做 row 179」,
quoted in D-193); every choice in D-193 is Claude's under the 2026-10-27
delegation, and Nelson approved it and its merge on 2026-10-31 (quoted in
D-193).

D-193 adds `arrival_collection`, which answers collected, not collected or
unknown for a targetless `pytest` run from the repository root under the
head configuration, read as pytest 9.1.1 reads it (config discovery and
loading, `-o` and the options of `addopts`, initial paths normalized as
pytest normalizes them, node ids, the nearest conftest list, the virtual
environment rule). A Python arrival or D10 survivor pays only where it is
collected; a Python rename whose new path is certainly not collected, while
the old one is not left out, is a disappearance. Unknown pays nothing and
reports nothing: a standing `-k` withholds every Python arrival's credit.
Its five-lens adversarial review and ten-agent engine-routes workflow
(`wf_5cb8f97d-18d`, five finders and five independent verifiers against
pytest 9.1.1) uncovered config-loading, `addopts`, conftest, initial-path,
symlink and D10/rename edge cases that the final `arrival_collection` fixes,
and two older pre-existing holes outside row 179 (now THREATMODEL rows 180
and 181). A Gemini 4 Argon headless review stopped on a denied read outside
the packet and is recorded as not reviewed.

New: `arrival_collection.py`, `tests/test_arrival_collection.py` and four
fixtures (`arrival_python_files_uncollected_pos`, `arrival_collect_ignore_pos`,
`arrival_k_selection_pos`, `arrival_configured_collection_neg`); the three
row-179 pins D-192 left flip, as D-192 said they would. KNOWN-ISSUES-next
lists what the reading costs and what it does not read.

Status: merged. Nelson approved PR #579 (from
`claude/row179-collection-settings-20261031`, main `3d115a35`) at
2026-10-31T12:01:36Z (quoted in D-193). Its PJU receipt (head `f9431338`,
base and collector main `3d115a35`, manifest SHA256
`d17ecf1508c52e162f16b346a1aae8279e0f04a5a07518c0c7a2c57c1174bd76`) is
published as `evidence/pr579-d17ecf1508c5-20261031` (commit
`dbf79bb0d1e69d839c81a6c8d1fd8c76bf69b9e6`), and intake run 41204353625 set
the four required checks; #579 merged as main
`0e6acc359e401207b2f5739fd15ae0440881a305` at 2026-10-31T13:12:26Z (a merge
commit, parents `3d115a35` and `f9431338`). On LAPTOP-01AGNPJU
(`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`, Windows CPython 3.11.9) on
2026-10-31: 86 collection shapes against pytest 9.1.1 (`--collect-only -q`),
83 agree and 3 withhold credit conservatively (0 unsafe); the full suite
(`pytest tests`, `tests/gates` included, xdist `-n 10`), whose JUnit
testsuite counts `tests="22413"`: 22346 testcase entries, 22321 passed and
25 skipped, plus 67 subtests, with 0 failures and 0 errors (1,131.6 s); and
two same-host differentials over the 3,600 R29 members against main
`3d115a35` (the final `src/` tree digest `d88e90a4...`,
`arrival_collection.py` SHA256 `31873e46...`, committed `6bfc64f4...`: 3,600
identical, 0 different, exits 3,493 pass, 105 block and 2 errors on both
sides, 2,617.1 s). Not run:
other platforms. Not released: package metadata stays 0.10.0.

## 2026-10-31: raise carriers are proved, and cells that never reach the test are not (D-192)

An outside report on #130 (talhayme, 2026-10-30) showed an honest fold
blocking at high on 0.10.0, where 0.8.0 and 0.9.0 passed: two
`pytest.raises` tests folded into one literal `parametrize`, beside an
equality test folded into a one-row table. D-179's Python proof stopped at
the first `with` statement, so the carrier had no key, and a file that lost
only raises tests without `match=` had no D5 mass, so it was never a D5
candidate. Nelson handed the report to Claude on 2026-10-31
(「接手checkwash 有一則外部誤報」); every choice in D-192 is Claude's under
the 2026-10-27 delegation, and Nelson approved it and its merge on
2026-10-31 (the button labelled 「核准並代合」, quoted in D-192).

D-192 proves a lone `pytest.raises`, `pytest.warns` or bare `raises` item
around expression statements, assignments and `pass` like an `assert`, per
literal row and with its prior and following statements, and lets a test
file that lost units but no mass be a D5 candidate that the proof decides,
when a live unit arrived in the same file. Its adversarial review (six
agents and a verifier for each of the 20 claimed holes, all confirmed,
with pytest ground truth) found no weakening of the carrier itself that
passes, but three older D-179 substitution gaps the carriers inherited:
`indirect` cells, a column the body rebinds, and rows whose own marks may
keep them from running. A Gemini 4 Argon review then raised two more,
verified by Claude: a list cell read twice (one shared object) and a test
moved into `async def`. Each already passed for `assert` tests on main
`c06b10d3`. A unit with any of the first four now gets no assertion keys,
and an async test's keys record its function kind (THREATMODEL row 178).
Row 177 holds the tampering controls; row 179, open,
records the older gap D-192 extends to raises folds kept in their file:
arrivals the repository's own collection settings never run, here a name
or row id a standing `-k` deselects.

New: `tests/test_raises_carrier_oracle_credit.py` (38 tests) and nine
fixtures, the report's two forms credited to talhayme there, in
`benchmarks/external-credits.json` and in the regenerated
`benchmarks/FAILURES.md`. KNOWN-ISSUES-next lists the honest folds that
still block; KNOWN-ISSUES-v0.10.0 records the false block for 0.10.0 users.
No existing expectation changed.

Status: merged. Nelson approved PR #578 at 2026-10-31T07:11:25Z (the button
labelled 「核准並代合」; Claude wrote it, quoted in D-192). Its PJU receipt
(head `e702965f`, base and collector main `c06b10d3`, manifest SHA256
`dfb3e89faf5bb93a60ac66bd1dbc581ad46001f63fd541e6164cf7c281bef3f2`) is
published as `evidence/pr578-dfb3e89faf5b-20261031` (commit `15d7f521`), and
intake run 41183508338 set the four required checks; #578 merged as main
`3d115a35` at 08:11:55Z, and #130 was answered. On LAPTOP-01AGNPJU
(`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`, Windows CPython 3.11.9) on
2026-10-31: the full suite (`pytest tests`, `tests/gates` included, xdist
`-n 4`), whose JUnit testsuite counts `tests="22170"`: 22103 testcase
entries, 22078 passed and 25 skipped, plus 67 subtests, with 0 failures and
0 errors; a same-host differential over the 3,600 R29 members against main,
3,600 identical; and the report across v0.8.0, v0.9.0, v0.10.0, main and
this change. A Gemini 4 Argon review completed (agy was re-verified after it
updated itself to 1.4.12); D-192 records the verified findings. Not run:
other platforms. Not released: package metadata stays 0.10.0.

## 2026-10-29: #419 closes as a documented residual (D-191)

Nelson's 2026-10-28 ruling 「2.用寫清楚結案」, then his clicks of the
buttons labelled 「接著做 0.11」 and 「用 C，開始改 PR-A」 (Claude wrote each
label and option text, quoted in [D-191](DECISIONS-archive-4.md), and only the label
may have been sent), close #419 as a documented residual of E1's repair
evidence, not a fix; D-191 supersedes the 2026-10-19 closing condition. No
engine code changes. 0.11.0 still holds a weakened Python oracle at warn
beside a no-op modification of a file checkwash cannot read (Route B,
`AUTHORS`, `CHANGELOG`, `.coveragerc`, `docs/requirements.txt` and
`doc/*.txt` included) or, for a finding with a test unit, a kept no-op in
a symbol the test reaches (Route A); a broad `except` added in a Python
test or conftest blocks beside any production change unless it is a proven
failure relay, which is not counted as added, within 0.10's count (D-176,
D-190); and JS/TS tests keep Route B. `fail_on = "warn"`, a base-side
`oracle_freeze` contract and the PreToolUse ask are what does not rest on
E1, with the archived, halted costs in the
[enterprise checklist §7](docs/enterprise.md#7-hardening-against-bought-repair-evidence-419).
THREATMODEL item 4 and rows 2, 93, 130, 131 and 169, SPEC §4, §5 and §9,
KNOWN-ISSUES-next, README, defence-design and stability say so. SPEC §5 and
row 93 now describe the one hop as implemented: matched by leaf name with
no module check, read in path order, not through a call made on another
call's result, and none for a changed top-level function (#420, deferred).
New rows 172 to 176 record five `BROAD_EXCEPT_ADDED` routes that 0.10
already misses, four from D-190's security review and one from Claude's
check of a Gemini 4 Argon review of D-190, without an engine change.

The three text fixes: the PR #576 status below records its merge and
receipt; hook input over 8,000,000 bytes, or not complete within 10
seconds, gets `{}` from the PreToolUse hook (row 169); and both hook
reasons quote the assertion's source text for ASSERT_WEAKENED and
ASSERT_REMOVED (`pretool.evidence_clause`), while the finding message and
the reports keep NAME(rank). Not answered by Nelson, and left open in
D-191: whether blocking an honest but real weakening counts as a false
block. #419 was closed when the change merged, as not planned
(2026-10-30T02:20:20Z).

New: `tests/test_issue419_residual.py` and 32 tests in
`tests/test_pre_tool_use.py`, among them residual pins of rows 93 and 172 to
175; no existing expectation changed.

Status: merged with D-190 as PR #577, merge commit `c06b10d3` on
2026-10-30T02:20:19Z (parents `6a867f6d` and `b36a4817`), on Nelson's click
of the button labelled 「合併並結案 #419」, whose text Claude wrote. The PR's
PJU receipt, manifest SHA256
`38641255b6965eb5270759644f88e2b25dbedd5c0ca19c986af553354a0e2fe5`,
published as `evidence/pr577-38641255b696-20261029` at
`aee58cc62c65f87203820533effdd3d1e154e70d` (head `b36a4817`,
LAPTOP-01AGNPJU, `HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`), recorded a JUnit
file whose testsuite counts `tests="22123"`: 22056 testcase entries, 22031
passed and 25 skipped, plus 67 subtests, with 0 failures and 0 errors.
Intake run 40973609981 then set the four required checks to success. The
targeted runs below came first, on D-190's commit `d9fcd20b`. Targeted runs on LAPTOP-01AGNPJU
(`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`, Windows CPython 3.11.9) on
2026-10-29, each exiting 0: the new residual tests,
`tests/test_pre_tool_use.py` and `tests/test_issue419_narrow_broad_except.py`
(200 passed); `tests/e2e/test_cli.py` and
`tests/test_issue418_session_base.py` (64); the seven other test files that
read the Stop reason (215) and five that check its block decision (180
passed, 13 skipped); the golden runner over all 1141 fixtures (1143
passed); the THREATMODEL, STATE, link, published-source, SPEC, oracle-rule,
schema and documentation-contract tests (67); and `tests/test_packaging.py`
(10), with the documented test count now 22025 collected. Not run: the full
suite, `tests/gates`, R29, the targeted uvloop diagnostic, dogfood and a
Claude Code hook lifecycle run. Not released: package metadata stays
0.10.0.

## 2026-10-29: proven Python failure relays (D-190)

Nelson chose how checkwash reads uvloop's failure relays by clicking the
button labelled 「用 C，開始改 PR-A」; Claude wrote its label and option
text, quoted in [D-190](DECISIONS-archive-4.md), and only the label may have been
sent. A broad handler in a Python test whose first statement hands the
caught exception unchanged to an asyncio future that the test awaits is a
proven failure relay, by the bounded rules of SPEC §4 *Python failure
relays* (R1 to R7, with R2b), read in
`src/checkwash/frontends/python/failure_relays.py`. The frontend keeps
0.10's swallowing list and records the relays apart
(`ParsedFile.relay_handlers`). The engine reads only the after side's
relays, and only in BROAD_EXCEPT_ADDED's count of additions: per handler
text, the smaller of 0.10's count and the after side's swallowing handlers
that are not proven relays. So 0.11 reports no BROAD_EXCEPT_ADDED that 0.10
would not, a relay made proven in the same change cannot pay for a new
swallow, an edit elsewhere in a file cannot make an unchanged relay
reported, and an edit that breaks a relay is not reported, as on 0.10
(THREATMODEL row 171). Its price: an honest relay added beside a handler of
the same first line that is not a proven relay is counted, as on 0.10, which
departs from the first half of the option text Nelson clicked (D-190, *The
bound's form*). This removes the finding where the 10-28 plan said
「降成 warn」; D-190 gives the reason (D-189's forced `oracle_freeze` and E2
would turn a warn into an ask) and the residuals.

Later on 2026-10-29, two adversarial reviews of the first implementation confirmed
problems, each reproduced before the fix: the both-sides form of the bound
let a relay made proven in the same change hide a new swallow of a unit's
assertion; R2 missed a unit's assertion run through a helper; same-file
stand-ins defeated R3, R6 and R7 through spellings row 171 called closed; R5
proved consumers that a narrower handler or a decorator could skip, and a B
handed to a thread; reachability grew with the nesting depth, so an Edit to
a 610 KB test could outlast the PreToolUse ask's deadline; and a deep guard
raised `RecursionError`. D-190's fix round lists the fix and the pins of
each, and SPEC §4, row 171 and KNOWN-ISSUES-next now name the routes the
reading still misses.

Still on 2026-10-29, Claude ran a read-only Gemini 4 Argon review of the
relay commit `d9fcd20b`; the run completed, and Claude verified each of
its seven findings against the source. The security argument overclaimed:
R2 sees neither a fixture's closure nor another file's helper nor an
alias, and what keeps a defeated relay from losing anything new is that
0.10 already lets a broad handler around a call that reaches an assertion
pass (THREATMODEL row 176, under D-191). Same-file spellings were still
credited: a patched `asyncio.Future.result`, `setattr` or `vars` through
an alias or `builtins`, `suppress` with an aliased type, and a B whose own
call is swallowed. R3, R5, R6 and R7 now refuse those families, pinned by
three fixtures and twenty tests, and uvloop's three commits still pass.
D-190's *Second review* lists each. A second Argon review of the fixes
(the run completed) found five more spellings, among them a fixture's
checker called in the `try` body; R2, R3, R5 and R6 now refuse them
(D-190's *Third round*), and the documented test count is now 22056
collected.

New: four negative and twenty positive `failure_relay_*` fixtures (their
labels are Claude's, under the delegation), `tests/test_failure_relays.py`,
five tests in `tests/test_pre_tool_use.py`, THREATMODEL row 171, and rows
in SPEC §4 and [KNOWN-ISSUES-next](docs/KNOWN-ISSUES-next.md). On the three
uvloop commits' test files, each paired with a synthetic `.pyx` edit (not
the full commits), main `6a867f6d` blocks with 1, 1 and 2 HIGH findings and
this change passes all three, plain and under `oracle_freeze`
(LAPTOP-01AGNPJU, Windows CPython 3.11.9,
`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`). Owed before the 0.11 tag: the
targeted three-commit, six-call uvloop diagnostic on the final release src
tree, because R29's repositories hold no uvloop commit, and the 0.11
disposition of D-176's remaining history risk, which is not yet accepted
for 0.11. (2026-11-03: both are in the 0.11.0 release pull request; its
section above gives them.)

Status: merged with D-191 as PR #577, merge commit `c06b10d3`
(2026-10-30T02:20:19Z); the D-191 status above gives its receipt and checks.
Before it, targeted runs on LAPTOP-01AGNPJU
(`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`, Windows CPython 3.11.9) on
2026-10-29, after the fix round, each exiting 0: the golden runner over all
1141 fixtures (1143 passed); `tests/test_failure_relays.py` and
`tests/test_pre_tool_use.py` (174 passed); the 29 other test files that
mention BROAD_EXCEPT_ADDED, swallowing, D-176 or `broad_handlers` (2118
passed, 1 skipped); the THREATMODEL, STATE, link, SPEC, schema,
determinism, detector-coverage and documentation-contract tests (45
passed); and the documented test count, now 21897 collected. The findings,
SARIF and IR of all 1117 existing fixtures are byte-identical to main's.
Not run: the full suite, `tests/gates`, R29, the targeted uvloop
diagnostic, dogfood and a Claude Code hook lifecycle run. Not released:
package metadata stays 0.10.0.

## 2026-10-28: 0.11 scope, a PreToolUse ask and the Stop release (D-189)

Nelson chose the 0.11 agent path by clicking the button labelled
「加 PreToolUse ask」; its label and option text were written by Claude, and
only the label may have been sent (the option text is quoted in
[D-189](DECISIONS-archive-4.md)). As implemented, 0.11 adds a Claude Code PreToolUse
ask on the five weakening rules, and first fixes the Stop hook's block
message and its `stop_hook_active` handling. This replaces
the approved scope's "stop hook 自動凍結": the Stop hook applying
`oracle_freeze` by default is deferred. The detailed choices are Claude's
under the 2026-10-27 delegation. The owner decision, replay evidence,
design, lifecycle receipt and unverified points are in
[D-189](DECISIONS-archive-4.md); the named residuals are in
[KNOWN-ISSUES-next](docs/KNOWN-ISSUES-next.md).

`checkwash hook pre-tool-use` asks before an Edit, Write or MultiEdit of a
Python test leaves a non-allowlisted ASSERT_WEAKENED, ASSERT_REMOVED,
TEST_DISABLED, TOLERANCE_LOOSENED or BROAD_EXCEPT_ADDED finding at high or
above, with `oracle_freeze` forced and policy from the session base (HEAD
without a session record); it always exits 0. `hook install --agent claude-code` now writes
`.claude/settings.local.json` by default and adds that handler there;
`--shared` writes `.claude/settings.json` without it. The Stop block's
reason no longer offers `checkwash allow` and tells Claude to take the
finding to the user, and a continuation stop on the set it last blocked on
is released with a note for the user. The #456 size block still blocks on
every stop.

Status: merged into main as `6a867f6d` (PR #576, a merge commit of
`69eff676` and the branch head `ad3f0bac`; GitHub mergedAt
2026-10-28T16:54:42Z). Implemented on branch
`claude/v011-candidate-20261028`, from main `69eff676`. A full suite on
LAPTOP-01AGNPJU (Windows CPython 3.11.9,
`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`), 2026-10-28T13:25:00Z to
13:33:12Z, exited 1 with one failure, the documented test count, since
corrected. Full suites then exited 0 on 2026-10-28T13:52:14Z to 14:00:17Z
(the working tree with this text) and 14:04:25Z to 14:12:28Z (commit
`4e98ae0b`), 21748 collected. A Grok review (claims and correctness,
verified by Claude) found two defects, a Windows spelling of the test path
that skipped the ask and a parse check that differed from the engine's,
both fixed with tests in `f4253f7c`; the suite then collected 21752. Full
suites exited 0 on `f4253f7c`, in the recorded window 2026-10-28T14:39:46Z
to 14:48:15Z, from the commit to the end of the run, and on `ad3f0bac`,
15:27:49Z to 15:36:16Z, each with 21752 collected. A pre-registered
Claude Code lifecycle receipt, approved by Nelson (the button labelled
「核准跑一次」; Claude wrote its label and option text, quoted in D-189, and
only the label may have been sent), ran on head `f4253f7c` on
2026-10-28T14:52:07Z to 14:53:07Z: Claude Code 2.1.260, haiku, Windows, `-p`
mode only (local repository `C:/Users/nelson/dev/cwrp`, prereg `abd56c0`).
The PreToolUse ask on an ASSERT_WEAKENED Edit became a denial under
acceptEdits (acceptEdits in place of the approved default mode, a deviation
registered before the run; D-189) and under bypassPermissions, and the Stop
hook blocked once with the D-189 reason and then released the continued
stop with its note, so it received `stop_hook_active: true`. The
interactive permission prompt in any mode, whether the interactive UI shows
a `systemMessage`, a Write call, MultiEdit, the other four rules, the size
and engine-error asks, and other versions, models and platforms are not
verified. The PR's PJU receipt, manifest SHA256
`182996eaed5df924aca8d5a27e62c89b8314b52fe1a9ee5cf899c5f9b39a95b1`,
published as `evidence/pr576-182996eaed5d-20261028` at
`bcec82716bbacafa09abf2a997ef31b801bb4e9d` (head `ad3f0bac`, LAPTOP-01AGNPJU,
`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`), recorded a JUnit file whose
testsuite counts `tests="21819"`: 21752 testcase entries, 21727 passed and
25 skipped, plus 67 subtests, with 0 failures and 0 errors; the pinned
(`100699796d`) and candidate (`ad3f0bac`) Action replays exited 0; and
qualification passed 283 of 283 for source, wheel and pyz. Intake run
40730258765 then set the four required checks to success. Not released:
package metadata stays 0.10.0, and v0.10.0 remains the published release.

## 2026-10-28: v0.10.0 published

v0.10.0 is the verified public release: GitHub Release 425888732 and PyPI
0.10.0 serve the same bytes, from H `100699796d942af30644738ffbcd1f1c939411c5`
(tag object `90210d81dd714f49e3ee6e2b1ccbb7c7428fe15b`). The PR, main, tag,
release-event and public-visitor stages each passed on LAPTOP-01AGNPJU
(`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`); other platforms remain NOT_RUN.
Nelson approved the PyPI deployment himself after the delegated approval was
refused for lack of token permission. The tag stage's verification and the
release-event and public-visitor stages ran from successive commits of
`review/collector-c-010-20261028` (`a1846d15`, `aa6829e6`, `8d75bf9a`), which
fix three defects in paths of `071fa76f` that had never run past the main
stage; main carries those fixes from this follow-up on.
Details: [RELEASING](docs/RELEASING.md#v0100-checked-publication-and-pin-promotion-2026-10-28)
and the [publication record](docs/releases/v0.10.0-publication-verification.md).

The advertised manifest, README, doctor, self-audit workflow and the receipt
tools now pin v0.10.0, so a fresh PJU receipt's pinned Action checkout is H.
Nelson then authorized Claude to do the agent-read-only release housekeeping
(he chose the offered reply 「授權 Claude 做」): D-173 to D-187 moved to
[DECISIONS-archive-3](DECISIONS-archive-3.md), and the verdict baseline
rotated to v0.10.0 (D-188; blocked pin 159 -> 160 for i197/Q5a). The published
0.10.0 `doctor` still requires the v0.9.0 Action pin, and the PyPI 0.10.0
description is the release commit's README; both are in
[KNOWN-ISSUES-v0.10.0](docs/KNOWN-ISSUES-v0.10.0.md). 1.0 is NOT_MET and
needs Nelson's decision.

## 2026-10-27: Claude takeover, review fixes and PJU release chain

Nelson handed the repository to a Claude Code session on LAPTOP-01AGNPJU:
「Checkwash 一樣給你」「交接 規劃 都寫在上面了」. The pre-1.0 delegation in
[RELEASING](docs/RELEASING.md) now runs through that session; it still stops
before 1.0. Codex's earlier entries below keep their own attribution, and its
F1/F2 packets from LAPTOP-16NUA5I8 remain failed historical records.

A pre-release review of `ad1ebff7` reproduced three defects, fixed here with
regression tests: whole-tree worktree listing for paired pytest configs (every
worktree/Stop check could become an engine error on ignored dependency trees
or junction cycles), an empty-file rename that skipped the D-177 effective-BASE
comparison, and `str.splitlines()` line numbering in D-179 proofs. The test
session now removes the source `__pycache__` it creates, the cause of the
v0.9.1 tag-stage failure. Remaining findings are in
[KNOWN-ISSUES-v0.10.0](docs/KNOWN-ISSUES-v0.10.0.md).

The engine `src/` tree is now `c02d0c99a6b39a0a3a9f65dfadd28c4395d08310`.
A same-host R29 differential on LAPTOP-01AGNPJU found all 3,600 members
identical between the closed `ee6716662fe2` tree and the fixed tree, so the
closed movement review and cost decision carry over (checkwash-lab
`bf13bf1a`). The final PR/main/tag/release-event/public-visitor chain runs on
LAPTOP-01AGNPJU,
`HUMAN_AUTHORIZED_LOCAL_PJU_NOT_EC_POOL`; other platforms remain NOT_RUN.
1.0 is NOT_MET.

## 2026-10-27: frozen development evidence and release-protocol preparation

The frozen core checkpoint `9678e8de564ed47f7ff92867d5c7d09358c04fcb`
completed Windows/Python3.11.9 development validation: 21,550 passed,
25 skipped and 67 passed subtests. Every skip is native symlink creation
unavailable (WinError1314). Source, installed-wheel and actual-pyz controls
each passed 283/283, with matching observations and all 215 package members.
The unchanged 185-case verdict contract passed with zero failures and one
reported Q5a PASS-to-BLOCK. These identify 9678; later heads require their own
actual stage receipts.

D-186 repairs the prospective tag rule using native public Release identity,
retaining the failed v0.9.1 tag and genuine v0.9.0 pin. Its 501 targeted tests
and 36 subtests passed at `071fa76f`, with independent source/metadata review
and both actual CLI dogfood diagnostics passing. It changes no engine src.

The [D-187 current cost decision](docs/d176-cost-disposition-0.10.0.md)
separately accepts three source-reviewed D176 false blocks/four occurrences
and the disclosed remaining-history risk for 0.10 under current delegation.
The old R4 stays partial and consumed, including its parse omissions and
6,554 incomplete comparisons. The new six-call targeted observation is not
a resumed census. The separately admitted R29 attempt B completed all 3,600
pairs and 7,200 historical CLI calls. Its sealed generic and strict audits
returned zero; root accepted mechanical closure only, retaining the unexplained
109.82585-second cross-clock difference. Python has 1,734 pass/pass, 48
block/block and 18 pass/block; JS/TS has 1,759 pass/pass, 38 block/block,
one error/block and two unchanged error/error. The exact final 19-movement join
and delegated current0.10 cost/residual-scope decision are closed in the
[source-bound comparison record](docs/r29-comparison-0.10.0.md). All87 HIGH
occurrences and unknown coverage remain literal; this does not label every
finding true/false or prove full coverage. This is
in-sample evidence, not a false-positive rate or publication acceptance.
Engine applicability remains exact src tree
`ee6716662fe264b5425958f00835567a4ffca4d6`; the final whole-head PR/main/tag/
release-event/public-visitor chain remains fresh and pending. 1.0 is NOT_MET.

The [0.10 candidate guide](docs/releases/v0.10.0-public-launch.md) distinguishes
these checkpoints from final PR/main/tag/release/public-visitor acceptance.
BASE approval [PR573](https://github.com/taipei49314/checkwash/pull/573) merged
normally as `c9356686`, tree `1181bb39`, after local source4eb/collector061
validation and native metadata workflow
[40455493560/1](https://github.com/taipei49314/checkwash/actions/runs/40455493560).
All four required App15368 checks succeeded and their IDs match the original
native publication artifact. Receipt commit is `3189b687`; manifest SHA256 is
`84f7fccf59572cc5591b23a337658fec6e9965a4e83f8e12f99c082b19d73fe4`.
The qualified PR tree equals the merged tree. This is the four-key BASE
approval PR, with its own 20,629 passed/25 skipped/67 subtests and 3×283
receipts, not qualification of later0.10 code.

Candidate checkpoint `72f1c368` incorporates that accepted ledger. Both actual
published0.9.0 and9678 CLI analyses of `c9356686..72f1c368` passed with19WARN,
zero HIGH/critical, empty config-errors/skips and unchanged source. The four
exact approved identities remain reported as allowlisted. PR572 was included
by ancestry in the draft PR566 branch; its merged UI status does not merge
the0.10 code into main. Final0.10 stage evidence, tag, public release, PyPI
approval and public pin promotion remain pending; other platforms remain NOT_RUN.

## 2026-10-27: autonomous continuation and conservative cost dispositions

Nelson instructed this continuation: 「照著繼續做 完整spec在裡面 一樣我只卡1.0發佈前 其餘你可以自主推」.
Codex is continuing the pre-1.0 repair goal under that delegation. It still
stops before 1.0. Source work and task-local development validation now run on
actual LAPTOP-16NUA5I8 / Windows / Python 3.11.9, recorded as
HUMAN_AUTHORIZED_LOCAL_16NU_NOT_EC_POOL. Historical PJU receipts keep their own
host/source identity; this new venue is not relabeled PJU or other platforms.

Bounded plain-class and plain-describe proof paths have independent adversarial
review. They require closed side-correct inputs and preserve unknown contexts,
liveness and freeze. The old #263/#570 examples provide no called producer or
closed startup context and retain BLOCK; separate supplied-source controls
exercise the supported positive domains.

The [D-185 disposition ledger](docs/oracle-context-dispositions-0.10.0.md)
preserves all old inputs/labels and records the delegated migrations for eight
goldens and four corpus identities. CASE_020_windows and CASE_029_flatten remain
known legitimate-refactor false blocks. d007 and d010 are newly caught escapes.
These are Codex-performed reviews, not Nelson's personal case reviews. Full
fixed-source validation, receipt-route admission and publication remain separate;
this checkpoint claims no new public release. Earlier entries retain their dates.

## 2026-10-27: complete the repair goal before 1.0

Nelson's latest instruction is: 「我覺得可以一次做完吧 可以推版號 但到1.0版前要停下問我」.
The existing goal now includes implementation of the remaining policy-shadow,
TASK authority and oracle-credit core repairs, the necessary protected contract
and consumer migrations, and pre-1.0 version advances. The integrated candidate
targets 0.10.0 with IR3 and findings2. This supersedes the earlier UX-only scope
and undecided-version boundary below. Stop and ask Nelson before 1.0.

The old v0.9.1 tag and all failed/partial/consumed receipts remain immutable.
Historical entries below describe their own dates, not the current scope.
Current implementation, validation, acceptance and publication are separate
states: the new grant is not a PASS receipt or a waiver of release gates.
PJU is the authorized execution host; unavailable platform capabilities are
recorded as NOT_RUN. No new paid/model or historical batch is admitted here.

The core implementation is integrated: D-177 policy/IR3 provenance, D-178 TASK
addressing, D-179 oracle-context compensation, D-180 retained quality trust,
D-181 strict TASK authority, D-182 CRLF relocation, D-183 worktree/Stop pytest
evidence, and D-184 same-name JS expectation provenance. The original repair
overview is [updated here](docs/repair-integration-0.10.0.md).

At this initial integration checkpoint, eight original golden expectations
remained incompatible with D-179, tracked in [#567](https://github.com/taipei49314/checkwash/issues/567).
The later D-185 entry above records their separate delegated disposition.
The [draft PR](https://github.com/taipei49314/checkwash/pull/566) and matching
task receipts carry actual validation state. Implementation, collected test
counts and bounded review do not waive those failures or establish publication.
Final-source evidence must identify the exact source and actual capability;
the existing v0.9.1 tag and historical grants are not reused.

## 2026-10-26: bounded UX repair candidate

This candidate follows the next-session handoff for individual experience
defects. The 2026-10-26 r65 human pause still governs v0.9.1 publication;
this work does not resume collectors, automations, tag validation or publication.
The existing v0.9.1 tag and failed receipts remain unchanged. Package metadata
stays 0.9.1 while the next version is undecided.

The [candidate scope](docs/ux-repair-candidate-2026-10-26.md) separates narrow
reader, quality, output and exemption-diagnostic repairs from unresolved
policy decisions. In particular, rename/decorator and D2/D5 oracle-credit
changes are reproduced proposals, not implemented policy fixes. No protected
contract, severity table, strength lattice, alignment parameter or existing
fixture label changes in this candidate. PJU receipts describe their actual
runtime and source; they do not establish unexecuted platform coverage or
release acceptance.

The second UX batch adds format-aware quality explanations/catalogs/draft
guidance, policy-source and tracked-hook maintenance notes, safe worktree and
TASK lookup/syntax diagnostics, Ruff ignore-discovery reasons and optional
per-commit sweep diagnostics. The original TASK parser, path authority,
snapshot admission, Ruff qualification, sweep counters and trust policy remain.
Requested output formats and error text intentionally improve; the optional
sweep field is documented for external consumers. Existing diagnostic-only
test assertions follow the new refusal text without relabeling golden verdicts.

## 2026-10-24: narrow #419 release preparation

Nelson instructed this session to carry the reviewed v0.9.1 scope through
publication: 「直接做到發布」. The version-specific record is in
[RELEASING](docs/RELEASING.md#v091-publication-instruction-2026-10-24).
This branch integrates D-176's previously approved narrow implementation and
protected-text drafts. Only Python test/conftest `BROAD_EXCEPT_ADDED` findings
with no unit refuse opaque repair credit; the other Python rules, JS/TS,
production-only handlers and Route A remain outside the fix. #419 stays open.

The earlier first-stage source `198c3ab0` has preserved Windows/Python 3.11.9
PJU receipts: 20,561 passed/25 skipped, 283 cases per source/wheel/pyz and
pinned/candidate Action replays. Those receipts do not certify this new head.
Its own full development, qualification, visitor, verdict and release-stage
evidence are still required. Public CLI/Action/advertised pins remain v0.9.0.

The first narrow history attempt stopped as `PARTIAL_UNEXPECTED`, exit3, after
three CLI calls on one member. Its comparator incorrectly required full SHAs
where the CLI reports native short labels; 7,434 members were not attempted.
Original raw/consumed markers remain. Nelson then explicitly selected
「核可 r2 精確來源發布與一次比較」 for the independently reviewed r2 packet;
that new once admission does not revive r1 or accept historical cost.
R29 still compares actual v0.9.0 with the fixed candidate on both 1,800-member
sets; the narrow 7,435-member history packet does not replace it.

R2 correctly stopped at the inherited, identical three-file Python2 parse gap:
`PARTIAL_UNCHANGED_WITH_GAPS`, exit3, six compared/16 CLI/7,429 not attempted.
Its raw, consumed markers and verified cleanup are retained. Nelson explicitly
approved the new r3 source/once contract: identical parse omissions may be
recorded and continued without claiming the omitted files were analysed.
[Lab PR23](https://github.com/taipei49314/checkwash-lab/pull/23) and EC T-614
bind the new source/admission. R3 stopped as `PARTIAL_NEW_BLOCK_COST_REVIEW`,
exit3, after 112 compared members and 230 CLI calls; 7,323 were not attempted.
Two identical parse-gap members retain six skipped-file occurrences. Its
original terminal and independent closure audit are preserved; r1/r2/r3 are
consumed and no history cost is accepted by those grants.

The stop is uvloop `7b202ccf` against `ae44ec2d`: a broad-except finding in
`tests/test_context.py` moves from warn/repair credit to high/BLOCK. Source
review supports a legitimate callback failure-relay regression test: the
handler sets an exception on the Future subsequently awaited by the test.
The candidate's refusal nevertheless matches its fixed metadata predicate.
`unit=None` does not mean lexical module scope; this catch is inside a nested
callback in a test method. Historical-cost disposition and any further once
attempt remained pending after that stop. Nelson then selected the exact A
option: a new r4 full cost census, rather than the supplemental-history waiver.
R4 source `3d375a1a`, seal `4b0575e7`, [Lab PR24](https://github.com/taipei49314/checkwash-lab/pull/24)
and EC T-616 bind the fresh once. It started at 2026-10-24T11:21:59Z on PJU.
Expected D176 movements remain pending source/cost review; identical valid
parse skips retain omitted coverage, and only exact closed both-exit2/raw-equal
errors are recorded separately as not analysed. Other stops and the original
24-hour cap remained. The run stopped at 2026-10-24T14:12:18Z when the Django
shard's original 3,600-second budget expired. It completed 881 two-arm result
comparisons, retained one partial candidate timeout and left 6,553 members
unattempted: 6,554 members lack a completed comparison. Three cost members /
four finding occurrences remain pending. Three parse-gap members retain seven
file omissions; two identical exit2 members remain not analysed. The
[T-616 terminal audit](https://github.com/taipei49314/estate-consolidation/commit/34e5a4a57ac9c84fd4cf5164e577edabd2242361)
verified original raw/source/runtime and cleanup. R4 is consumed and partial;
neither a new run nor this-version unknown-cost acceptance is implicit.

The required R29 first actual run, `r29-v091-r2`, is separately source/budget
admitted under the current publication task and accounted as EC T-615. It uses
true public `d6eda4f6` and candidate `198c3ab0`, not the later 618c maintenance
source as the published baseline. It completed all 3,600 members/7,200 CLI
calls; both payload and raw differences are zero, with an empty mandatory
movement list. Python: 1,752 pass/pass and 48 block/block; JS/TS: 1,759
pass/pass, 39 block/block and two recorded-only error/error. Original source,
runtime, 40,916 session files and exact-container removal were independently
verified. This is in-sample evidence, not an FP rate; the final source must
still differ from `198c3ab0` only in its version literal. Exact source, runtime,
limits and distinction between the human's
short publication instruction and root's technical admission are recorded in
[RELEASING](docs/RELEASING.md#v091-publication-instruction-2026-10-24).

Publication-route engineering is separate [PR563](https://github.com/taipei49314/checkwash/pull/563),
head `e462b323`. Its real pinned-Action dogfood blocks on 24 HIGH findings from
three test-oracle migrations. Independent source review and ordinary diagnostic
tests do not turn that BLOCK into a passing required check. Actual full-suite,
three 283-case qualifications/inventories and verdict diagnostics passed and
were independently audited. Nelson approved the exact 24-fingerprint semantic
exception and one temporary User/pull_request operator attempt. Under EC T-617,
the sole actor PUT returned HTTP403, "Resource not accessible by personal
access token"; no merge was attempted. Original and fresh native readbacks
show the full original ruleset, empty bypass and main `5338e689`. That API once
is consumed. The separate T-618 browser attempt then consumed its once: first
Save opened Confirm access, root cancelled and did not attempt a merge. The
bounded cleanup and independent fresh readbacks observed the entire original
ruleset, empty bypass/never, open PR563 and unchanged main; they do not prove
every unseen transient state. T-618's [terminal record](https://github.com/taipei49314/estate-consolidation/commit/da118ad8713648dc5f2687092c06bfdd1ac5826b)
preserves that consumed outcome. Nelson subsequently completed authentication;
the unchanged-form auth-only Save displayed "No changes have been made" and
an empty bypass list. Authentication does not authorize a new actor-add/merge
window. Nelson then separately approved r2 under EC T-619. The sole merge PUT
acknowledged `865d3fcafbe69cf67e3e9e9789038e27b4b02809` at 13:11:06Z.
The original helper retains exit3/uncertain: the PR response omitted
`merge_commit_sha` while reporting merged/closed. Independent fixed-commit
readback verified exact parents `[5338e689,e462b323]`, head tree and main.
Fresh UI removal/Save succeeded; an original full-baseline GET was within the
60-second cleanup effort, and two later independent full-projection reads
confirmed empty bypass/never. The [T-619 terminal accounting](https://github.com/taipei49314/estate-consolidation/commit/e71d4da87ec4586c839d74da21ef3a77f02f7f0f)
preserves original uncertainty and later proof separately. All three once
attempts remain consumed; the exact24 semantic acceptance persists.
This product branch still needs its own fixed final-head capture and
collection. Six prepared Windows/
Linux legs are not executed evidence or a waiver of the bridge's eight absent
platforms; the separate strict nine-leg comparison still lacks three macOS legs.

The first combined validation at `fa45b2f6` failed two documentation assertions
(status-count format and the authoritative version row). Its validation
checkout also lacked the real v0.9.0 tag required by the README pin test. The
separate matrix omitted ProgramFiles from its Windows outer environment and
failed Action preflight tests. Original failures remain evidence; corrected
documentation and fresh validation inputs require a new exact capture and
complete matching validation, without changing test expectations.

This is an as-of preparation checkpoint. R4 has stopped partial, with
source/cost disposition pending and publication blocked. A later immutable
Lab/EC result plus explicit Nelson disposition may close that external gate
for an unchanged candidate; this paragraph claims neither completion nor
acceptance. Any required code or contract correction changes the candidate
and requires new matching evidence. No tag or public release precedes closure.

PJU is the current default under EC T-610. No pool connectivity investigation
is part of this work. Record real local provenance and unexecuted platforms;
final-source platform acceptance and Nelson's PyPI deployment approval remain.

## 2026-10-23: all CheckWash tests run on PJU

Nelson explicitly made LAPTOP-01AGNPJU the standing execution host for all
CheckWash tests; other projects retain their existing rules. See
[the route and transition state](docs/testing-on-pju.md). Remote test
workflows are disabled at the GitHub workflow-state level, with their
definitions and required-check protections retained. The
[PJU receipt bridge](docs/pju-receipt-bridge.md) verifies exact-source local
evidence and publishes the existing required contexts; missing or failed
receipts still block merges. Release publication needs its separate handoff
and one-time authorization.
Historical hosted results below retain their original host and status.

## 2026-10-23: verified public v0.9.0

The [publication record](docs/releases/v0.9.0-publication-verification.md)
binds v0.9.0 to release commit
`d6eda4f695fabb8e7d138f7a87b099d2028f0294` and annotated tag object
`60bdd18f7038d6d908ef584fedda1960815e520f`. Release run `39817071157/1`
completed all four jobs after Nelson approved PyPI. Hosted public verification
`39821892775/1` downloaded GitHub's three assets and PyPI's wheel/sdist,
compared actual bytes and exercised fresh public installations. All passed.
This follow-up advances advertised/README/doctor Action pins; the public tag
and released source stay fixed. Baseline rotation is a separate reviewed PR.
The in-sample scope, #419 refusal-off residual, retained engine errors and
census limits below are unchanged; publication is not new detector evidence.

## 2026-10-22: rcprime results and wording accepted; final checks precede publication

The candidate is `36280924b6ebfa2ab8cbd2f242c8f5cf03ae53fa`, `src/` tree
`4baaee4c89dc3e7a4c6f3d069595a5ef8576025f`. It includes #553's off switch
for #419's opaque refusal, with #554 and #555. `141accee` stays reachable.
**At this 2026-10-22 checkpoint, v0.9.0 was not published and v0.8.0 was
the verified public release.** The later publication record is linked above.

Calls 1–4 and the supplement finished on LAPTOP-01AGNPJU under the frozen
T-546 declarations: human-authorized local PJU, NOT EC pool. All 710
shards exited 0; this does not mean every CLI call passed. Lab evidence
[`92d771e2`](https://github.com/taipei49314/checkwash-lab/blob/92d771e2bfb41b1109b57cce55f3df2a0e99726d/evidence/v090-sweep-results-20261022.md)
records blocks, retained errors and the census timeouts. K2 omitted call 5;
C2.6 stopped the named Q4 and related counterfactual arms. The original
combined receipt remains `complete=false`; the supplement is complete,
and both sets of required determinism checks passed.

The supplement reverses exactly the eleven #419 stop commits, rc block →
rcprime pass, and leaves JS/TS identical. Its stdout count and three
positive controls hold. Source review has covered all 726 predicted
finding moves in 55 repository/commit/path rows, including the 17 moves
under doc/example or a package directory: all affected files are Python
tests or conftests. That scope review does not adjudicate each finding.

On 2026-10-22 Nelson replied 「全部照建議核可，依既有 G4 授權續作」 to the
concrete A/B/C package, an assistant-written option. The
[written approval](https://github.com/taipei49314/checkwash-lab/blob/b5e0a4dfcc63ef9411a2399cf343098370bc52ea/evidence/v090-closeout-20261022-codex/maintainer-approval-A-B-C.md)
accepts R29's empty composed v0.8.0 → rcprime list on 3,600 members
(M1), and disposes of calls 2/3's additional eight #419 stops by K1's
refusal-off route, like the first three (M2). S6's residuals stand:
no per-row Docker/PJU outcome join, outcome equivalence for an identical
source tree is assumed, and stderr notes were not compared. The original
R29 JSON stays immutable; the separate
[rcprime supersede](benchmarks/release-comparison/v0.9.0-rcprime-supersede.json)
records the later acceptance. #419 stays open and M3 is not posted.

For fix469, 43/370 formerly errored calls in the limits345 subset become
analysed (40 pass, 3 block) on a496 → a469; the joined pair has 3,388
members, including other standard/D-088 rows. Nelson accepted the blocking
findings of aiohttp `247b3238` and `c74d7e98` as FP (M5). He accepted
`02558d38` as a justified 64 MiB → 2 MiB test-data-size reduction, with
the real larger-stress coverage loss retained; this is disposed of,
not coverage-equivalent and not a third proven FP. The
[source review](https://github.com/taipei49314/checkwash-lab/blob/faae48d408254421ba1cbe622f1b3e13c2b89cc3/evidence/v090-closeout-20261022-codex/source-review-M4-M5.md)
remains the source basis, not a fresh rcprime rerun. The 470-member original-rc census has 276 pass,
107 block, 83 product errors and 4 timeouts. M6's source reading of all
1,150 recorded matching-line entries is complete: no new runtime-control
marker occurs in the written findings. The 87 unanalysed rows and 15
conftest parse-warning rows remain limits; no human personal review or
zero false-positive rate is claimed. The
[census source record](https://github.com/taipei49314/checkwash-lab/blob/faae48d408254421ba1cbe622f1b3e13c2b89cc3/evidence/v090-closeout-20261022-codex/census-review-followup.md)
and these limitations are included in the approved wording, not a new
human publication gate. S7 leaves these
measurements on their declared engines. `cfjs131` stays on `141accee`
under L11; its 55 pass → block commits are redesign evidence.

Separately, the frozen #416 wrong-blob reproduction completed eight CLI
calls on 2026-10-22: both v0.7.0 and pre-#453 main block at the root
(exit 1) and pass from the subdirectory (exit 0), in range and worktree
modes. All four comparisons reproduce the historical false pass.
The [raw receipt](https://github.com/taipei49314/checkwash-lab/blob/faae48d408254421ba1cbe622f1b3e13c2b89cc3/evidence/v090-closeout-20261022-codex/wrongblob-416-receipt.json)
binds the old engines, manifest and runtime. Nelson approved R40's row-162
wording, its additive mapping to the existing end-to-end test and the
matching derived FAILURES synchronization. This PR records those changes;
#416 is not declared closed ahead of its merge. This
historical reproduction does not replace the separate 1,800-row
subdirectory comparison or validate rcprime afresh.

The approved D-172, row-162/mapping/derived-document synchronization
and accepted R29 supersede are carried by this PR. Still before
ready/merge/tag/Release:

- new exact-final-head CI/qualification, followed by
  the exact main commit's and tag's checks under RELEASING.

The human-typed rcprime `/clear` lifecycle completed at lab `223598f9`,
manifest `33b55dba…`: collection on 2026-10-22 at 13:50:56Z records
**c1–c8 PASS**, using Claude Code 2.1.260 and Haiku. Session A's Stop named
the committed weakening without a blocking decision; `/clear` created
session B at the weakening commit, and B's Stop printed `{}` without
naming it. This is the declared #418 receipt, human-authorized local
PJU, NOT EC pool. A real blocking Stop was not exercised. Nelson then
confirmed removal of the temporary global `skipDangerousModePermissionPrompt`
key; the read-only presence check at 13:52:42Z found it absent. The original
receipt retains its as-of-collect `bypass_key_after=true`; it was neither
rewritten nor recollected.

The [durable lifecycle receipt](https://github.com/taipei49314/checkwash-lab/blob/faae48d408254421ba1cbe622f1b3e13c2b89cc3/evidence/v090-closeout-20261022-codex/clear-receipt.json)
and [closeout record](https://github.com/taipei49314/checkwash-lab/blob/faae48d408254421ba1cbe622f1b3e13c2b89cc3/evidence/v090-closeout-20261022-codex/README.md)
retain the execution provenance and housekeeping separately.

The A/B/C reply approves D-172, the guide, versioned known issues and
#416 wording, and instructs continuation under the existing G4 grant.
Exact final-head, main and tag checks still precede their corresponding
publication steps. Nelson alone approves the `pypi`
deployment. Public artifact verification precedes advertised/README
pin updates, and baseline rotation remains a separate PR. #554's expiry
does not require rushing these conditions: standard release self-checks
do not replay #553's old diff. Earlier dated entries below remain history.

The combined sweep also reproduces the already recorded #424/#306/#487
movements. D-144 treats pytest `242fb7852b`'s block → pass and rich
`a13b2a9d75`'s pass → block as correct. D-145 records scrapy
`c8aa429c9b` and `e058a05763` as false blocks and `fada8be1db` as the
known false block retained under #488. D-149's #487 fix returns the first
two to pass while the other affected commits remain blocked. These are
existing recorded dispositions, not new unruled stop conditions.

## 2026-10-22: #419's refusal is turned off; the candidate moves

Call 1 of the combined acceptance sweep fired #419's pre-registered stop:
three pass → block moves on D-088 members
([#419 comment](https://github.com/taipei49314/checkwash/issues/419#issuecomment-6329503938)).
Nelson then decided that v0.9.0 ships without the refusal, by D-141 C1's
revert route ([RELEASING](docs/RELEASING.md#amendment-after-the-419-stop-2026-10-22)).

- [#553](https://github.com/taipei49314/checkwash/pull/553) empties
  `gating.OPAQUE_REFUSED_RULES`, so the refusal cannot act. #419's code stays
  for a redesign, and #419 stays open.
- [#554](https://github.com/taipei49314/checkwash/pull/554) records #553's
  self-check exemptions, and
  [#555](https://github.com/taipei49314/checkwash/pull/555) carries SPEC,
  THREATMODEL, FAILURES.md and D-171. All three are merged.
- The candidate is now `36280924b6ebfa2ab8cbd2f242c8f5cf03ae53fa`, this
  branch's merge of `main` (`47c74172`). Its src tree is
  `4baaee4c89dc3e7a4c6f3d069595a5ef8576025f`, which differs from R29's tested
  tree `17c3dd82` only by #553. `141accee` stays reachable as its ancestor.
- Still to come before the tag:
  - Nelson approves the sweep supplement's freeze, which compares `141accee`
    with the new candidate on the six window-1 batches, and then the
    supplement runs.
  - R29 for the new candidate is to be settled by composing the accepted
    comparison with that supplement, once the supplement holds its acceptance
    line and Nelson accepts the composed list (L7).
  - The `/clear` receipt moves to the new candidate (L8); Nelson approves its
    new manifest first.
  - The release guide and the R29 record still describe `141accee` and
    `7d173fe8`. They are rewritten for the new candidate in the text Nelson
    approves.

Calls 2 to 4 of the sweep continue, and call 5 does not run. No v0.9.0 tag,
Release or public artifact is claimed here.

## 2026-10-21: v0.9.0 candidate preparation

The maintainer delegated this session's planning and execution through
v0.9.0 publication, then explicitly authorized necessary local Docker
verification. [RELEASING](docs/RELEASING.md#v090-session-publication-authorization-2026-10-21)
records his words and scope.

The candidate starts from main `641efdec1a17cbb3c7291491b5db90a1fb469d22`.
This preparation changes version metadata and records authorization.
The pre-tag fixed-corpus comparison has completed: the Python set has
1,752 unchanged passes and 48 unchanged blocks; JS/TS has 1,759 unchanged
passes, 39 unchanged blocks and two unchanged errors. Its mandatory review
list is empty; the [R29 record](docs/RELEASING.md#completed-r29-comparison-2026-10-20-utc)
identifies the tested source and actual delegated reviewer. These are
in-sample counts, not a false-positive rate.
The combined acceptance sweep, `/clear`, final release guide and final-head
checks are not complete. No v0.9.0 tag, Release or public artifact is
claimed here.

Later on 2026-10-21 Nelson stopped the Codex sessions and gave four decisions
to a Claude Code session; [RELEASING](docs/RELEASING.md#v090-owner-decisions-after-the-codex-sessions-2026-10-21)
records them. In short:

- The sweep runs before the release, on LAPTOP-01AGNPJU.
- R29 is accepted in writing.
- The Codex-added gates are removed: harness tests, the EC pool chain and
  the fresh baselines.
- The #428 table selection is NOT_RUN for v0.9.0.
The public CLI, README install commands and Action recommendation remain
at verified v0.8.0. Earlier dated entries below remain historical records.

## 2026-10-16: v0.8.0 published and verified

v0.8.0 was published on 2026-10-15 at 17:00:03Z from release commit `f02b5d8`
(PR #458, tag object `1d869062`). The PR, main and tag verdict stages each
passed 185 cases with zero failures; tag CI passed every job, including the
actual tag visitor install; release run 38773654788 completed with the
maintainer's `pypi` approval; the PyPI wheel and sdist digests equal the
GitHub assets. The [publication record](docs/releases/v0.8.0-publication-verification.md)
has the details. This record advances `release/advertised.toml`, the README CLI
pins and the README Action pin (with doctor's built-in pin) to v0.8.0.

The same day the maintainer authorized checkwash sweeps on LAPTOP-01AGNPJU
while it is on (EC POLICY `checkwash-pju-sweep`, T-546) and approved the frozen
acceptance-sweep manifest of checkwash-lab branch
`prep/acceptance-sweep-v080-20261016` (`793fe135`, manifest sha256
`c5bdcf0b…`): v0.7.0 against v0.8.0 over the standard, D-088, targeted and
JavaScript batches (6,354 commits). It started at 16:34Z; its results are
labelled human-authorized local PJU, NOT EC pool, and will be recorded when it
finishes. Still open: the verdict-baseline rotation to v0.8.0, the sweep
adjudication, #454–#457, and the ruled P1 issues.

## 2026-10-15: v0.8.0 release prepared

On 2026-10-15 at about 13:00Z the owner handed maintenance back from
LAPTOP-16NUA5I8 to LAPTOP-01AGNPJU. The handover is on the checkwash-lab
branch `handover/5i8-20261015`. #453 (#416) then merged at `cdd74e0`.

The same day the maintainer said 「這版要先發了」 (release this version
first). Asked in the agent session, he chose:

- version 0.8.0, a minor release: #414 changed the frozen exit-code contract
  for `check --format hook-json`;
- to approve the maintainer-text drafts of #439, #441, #442, #447, #448,
  #449, #450, #452 and #453 as written;
- to publish first and run the acceptance sweeps on the EC pool after
  publication;
- the scope: `main` exactly as it stood at `cdd74e0`, the 25 pull requests
  merged since v0.7.0 (#370 to #453). #421 moves to a later minor release,
  and #456 goes into the known issues.

`docs/RELEASING.md` records the one-time authorization. The release PR
contains:

- the version bump to 0.8.0 (`pyproject.toml`, `src/checkwash/__init__.py`,
  `uv.lock`) and the `version` row below;
- the maintainer-owned commit with the approved SPEC, THREATMODEL and
  DECISIONS text for those nine pull requests;
- the [release guide](docs/releases/v0.8.0-public-launch.md) and the
  [known issues](docs/KNOWN-ISSUES-v0.8.0.md).

README installation commands, `release/advertised.toml` and the recommended
Action stay on the last verified release (CLI and Action v0.7.0) until
v0.8.0 is publicly verified.

What waits, in order:

1. Hosted CI, source/wheel/pyz qualification, the advertised v0.7.0 visitor
   and the verdict gate on the release PR's final head; the merge; push CI
   and the verdict gate on the release commit.
2. The tag `v0.8.0` on that commit and its own published-source, visitor,
   full CI and verdict runs; the GitHub Release; the maintainer's approval of
   the `pypi` deployment.
3. The publication record, then a reviewed follow-up that advances
   `release/advertised.toml`, the README CLI pins and the README Action pin
   to v0.8.0 and rewrites the "on main, not released yet" notes (README,
   `SECURITY.md`, `docs/quality.md`, `docs/remediation-upgrade.md`,
   `action/README.md`, `action/quality/README.md`). `checkwash doctor`
   accepts only its built-in Action commit, v0.7.0's in this release.
4. The verdict-baseline rotation PR to v0.8.0 (RELEASING step 9).
5. On the EC pool: the acceptance sweeps of #345, #346, #414, #415, #416,
   #422, #431 and #432, and the corpus sweep. Not run before publication:
   `NOT_RUN：工作機規則（POLICY work-machine-local），the owner chose to release first and run them on the pool after publication`.
   Those issues stay open until their sweeps land.

Still open: #454, #455 and #456 wait for rulings; the seven ruled P1 issues
#306, #418, #419, #421, #424, #428 and #429 are not implemented; #212 is
open. Downstream re-pins of checkwash-corpus and smallestlie are not
authorized. 1.0 remains NOT MET.

## 2026-10-15: P1 fixes merged

Maintenance moved to a session on LAPTOP-16NUA5I8. The handover is on the
checkwash-lab branch `handover/pju-20261015`. The agent's `gh` login there
was first switched to the narrower token.

The owner's delegation for P1 fix PRs is to merge once the required checks
and the test matrix are green and the scope matches the ruling. These merged
under it, one at a time because the branch ruleset is strict. Each had an
independent review first:

- #447 (#414): a worktree directory symlink is an opaque directory, and a
  hook-json engine error exits 0 with a `systemMessage`. #451 holds the
  owner-approved exemption for the changed hook-runtime test.
- #448 (#415): an oversized side that no detector reads is carried unread.
  A path a detector must read refuses, naming path, side, size and limit.
  The review found fail-opens at the first head:
  - deleted, renamed or edited Python modules;
  - nested pytest configs;
  - extensionless runner scripts.
  a94b7ca made them refuse before the merge.
- #450 (#422): conftest code that forces pytest's exit status is read as a
  runtime control.
- #452 (#432): conftest no-op replacements of what pytest runs are read as
  runtime controls. The review found three regressions in #84's readings
  against main, fixed in 86e9286 before the merge.
- #449 (#431): an always-passing assertion in a JS/TS catch no longer
  exempts the catch.

Each issue stays open ("Part of"). The maintainer text in each PR body waits
for the owner's approval, and the acceptance sweeps have not run. Each merge
comment lists the residual spellings for follow-ups.

Open:
- #453 (#416): `check`, `sweep`, `allow`, `doctor` and `quality` from a
  subdirectory. This is next.
- Filed for the owner's ruling:
  - #454: unread sides in JSON and SARIF.
  - #455: a bounded shebang read of unread sides.
  - #456: a must-read file over the limit lets the Stop hook stop.
- A comment on #448 corrects its residual list: the content rules it named
  never read the files an unread side sets aside.

## 2026-10-14: handover, ratification and the draft stack consolidated

Work after 2026-10-12 ran in a session on another machine. It merged the
2026-10-12 entries below, then opened 19 stacked draft pull requests
(#389–#412) and issue #411, and stopped on 2026-10-13. On 2026-10-14 the
maintainer stopped that session and handed maintenance to a session on
LAPTOP-01AGNPJU. The maintainer's answers that day, quoted:

- 「說過 可以追認」: the instructions quoted in D-129 and D-130
  (「直接到1.0 所有條件準備好停下」, 「目前沒有，先完成可自主推進的工作」) and in
  #403 (「授權 由你裁決」) are the maintainer's. The changes merged under
  them are ratified: the v0.7.0 verdict-baseline rotation in
  `tests/gates/verdict_gate_accepted.toml` with D-129 (#371), and D-130
  (#373).
- 「照建議」: the stack is not merged as a whole. Its ruled product changes
  are re-opened from `main` without the measurement workflows and tools:
  #439 (#345: stand-in node limit 200,000; errors name the file),
  #441 (deep string expressions no longer crash the analysis; stacked on
  #439) and #442 (#346: symlinked pytest configs). The other drafts are
  closed with their branches kept; each closing comment says where the work
  went. #411 is closed: the test it asked about existed only in draft #394.
- 「開」: two external user reports on v0.7.0, and work found in the closed
  drafts, are filed as #414–#438. The two P0 issues are #414 (worktree
  `check`, as the pre-commit and Claude Code Stop hooks run it, exits 2 when
  the working tree holds any directory symlink, such as an in-tree `.venv`)
  and #415 (any changed file over 1,000,000 bytes, or a large root
  `uv.lock`/`poetry.lock`, makes `check` exit 2; a v0.7.0 regression from
  `d900018`).
- 「回 用專業化回」: #363, #364, #366 and #367 from an external reporter
  were answered; #363 is closed as completed in v0.7.0. #440 adds the
  credits CONTRIBUTING.md promises, for #156, #164 and #363.
- Action: #413 adds a README and SECURITY.md advisory. Every published
  Action release up to and including v0.7.0 lets the pull request's checkout
  replace the installer and checker; #372 fixes it on `main`, unreleased.
  After the next release is published, the README on `main` recommends that
  release's Action instead of the one before it.
- Release gate: done the same day, by the maintainer. The `pypi`
  environment requires the maintainer's approval, agents use a narrower
  token, and the tag ruleset `22162219` is removed, without waiting for 1.0.
  `docs/RELEASING.md` (#444) and AGENTS.md rule 5 (#445, with the
  owner-approved exemption in #446) describe the procedure.
- 「可代合」: the consolidation pull requests above may be merged once their
  required checks pass.

Corrections to the entries below:

- The "Open on 2026-10-08" list is out of date. #196 closed on 2026-10-09,
  and #351 was ruled and merged in #360. The 22 issues it lists were ruled
  on 2026-10-08 (「裁決依照你建議」). Of those, only #345 and #346 have work
  in progress; the other 20 are not implemented yet.
- T-528 (EC) was handed to LAPTOP-01AGNPJU and closed as CANCELLED on
  2026-10-14: task A delivered with all six held-out candidates UNVERIFIED,
  B (a first held-out measurement) not started, C (#358/#351) done, and D
  cancelled. A held-out measurement needs a new task.

Still open: the #345 and #346 acceptance sweeps and their DECISIONS text,
which wait for the maintainer; smallestlie W3 (EC T-526) and downstream
re-pins to v0.7.0, which are not authorized; and the 20 ruled issues.

## 2026-10-12: separate development and published-release checks

PR #371 completed the v0.7.0 verdict-baseline rotation at `818dd6c`.
PR #372 integrated the main Action trust-boundary fix at
`0b42e2343d5c6983d22011dbd846f0da74ac623a`; its tree matches the qualified
PR checkout. The public recommendation remains v0.6.0 and does not contain
that fix. The separate quality Action entry point is not covered by the main
Action qualification.

Development CI continues to check the complete candidate suite and candidate
artifacts. The explicit advertised-release manifest separately identifies the
public installation subject; actual tag/release jobs check their own target.
D-130 supersedes the earlier operational rule that routine development stays
red merely because current public surfaces differ from the last release.
Missing public subjects, failed ordinary tests and failed source/artifact
identity checks still fail. Earlier dated red receipts below remain historical
failures. Candidate head, hosted checkout and published commit identities are
reported separately.

This migration merged in #373 at `4b24cfe`; its exact PR and independent main CI, source/wheel/pyz assertion qualification and verdict gates all passed. Nine original corpus streams remain byte-identical.
No new release, version bump, public Action pin or adoption claim follows from
it. T-528's original A–D work remains incomplete; independent adoption is
UNSATISFIED. Current public installation commands continue to identify v0.7.0.

## 2026-10-12: Quality Action and bounded R1 repair integrated

PR #375 merged at `259f32db06bb4bdc28cf2a71c10e4ea47f1c9c3b`.
Its tree exactly matches the qualified `cdcfcd0` head and hosted `8c4e657`
checkout. All nine CI legs, assertion and verdict gates passed. Twelve actual
Quality Action cases preserve six expected native rejections and six controls;
the separate qualifier and raw-step review passed. All 24 original normal-cost
invocations completed. Public delivery and recommended-pin advancement remain
outstanding; the source integration does not establish independent adoption.

PR #374 integrated the bounded root-BinOp binding repair at
`9afe51801c6448e86846fdb8f92d97dd6bdd44d4`, with the exact qualified
`ac155e2` / hosted `90db945` tree. Successful stdlib keys are preserved;
only a failing root binary expression uses iterative binary emission.
All nine exact-head CI legs, source/wheel/pyz assertion qualification,
185 verdict cases and three-interpreter strict recursion checks passed.
The earlier diagnostic failures remain recorded. AST budgets, severity,
existing fixture expectations and the separate deep asserted-subject
limitation are unchanged. This integration is not a release or adoption claim.

The nonblind R1 comparison fixes original A at the Quality merge above and
retains all 4,271 members, 432 logical shards and 8,542 original arm rows.
Its fixed-source scheduling is now retired; original readers, raw failures,
missing observations and every changed result remain part of the historical
[first-attempt run](https://github.com/taipei49314/checkwash/actions/runs/38247155157/attempts/1).
The [original workflow](https://github.com/taipei49314/checkwash/blob/ac155e2501e99fa8bf825f395de56cfb711814c7/.github/workflows/r1-seen-cost.yml),
collectors, synthetic tests and cohort bytes remain available for audit.
The same workflow path continues the unchanged synthetic capture/accounting
pytest job and its original triggers; it no longer builds or runs the fixed
historical cohort. Ordinary strict R1/canonicalization tests and the separate
PR-base reliability trace remain active. Retirement does not turn captured
errors or missing rows into PASS, authorize another cohort run, consume
held-out data, or reuse an old EC grant.

Final cost accounting verified all 48 workers / 8,542 original arms, with no
missing observations, capture failures or paired stdout/stderr differences.
Both arms retain 132 product errors, 33 verdicts with skipped files and 81
stderr-only verdicts; none is relabeled as clean analysis. All-member midpoint
medians were 1.649062441 and 1.649664511 seconds. Paired increase P95 was
0.095745692 seconds; individual increases and all per-commit records remain
in the original artifact. This supports the finite repair under existing
requirements without changing budgets, standards or held-out status.

## 2026-10-12: v0.7.0 publication verified

v0.7.0 was published from d647a65e9734f2b6e57b528ea595b1507dc31094.
The main/tag verdict gates, actual release build and PyPI upload passed.
All nine platform/Python test jobs passed, retaining two accepted macOS skips
per macOS job; actual public-tag visitor installation and byte comparison passed.
GitHub/PyPI wheel and sdist bytes match. See the
[publication verification record](docs/releases/v0.7.0-publication-verification.md)
for native run IDs/attempts, source/tree and actual asset identities.

The verdict baseline rotation is being prepared separately from publication;
the prior v0.6.0 Action recommendation remains. T-528 remains CLAIMED, its
original A–D work incomplete, and downstream repositories were not re-pinned.
The earlier authorization/preparation entry below remains a historical record.

## 2026-10-12: preparation accepted; publication authorized

The fixed v0.7.0 preparation is complete: ten first-attempt batches account for
6,071 pairs / 12,142 arms, including 4,271 Python pairs against main35 and
1,800 JS/TS pairs against original v0.6.0. Bounded source dispositions, complete
cost accounting and 612 recorded shard environments are retained.

The maintainer's “核准” accepted the exact protected wording, four #363 fixture
labels, recorded verdict/CI limits, disclosed added cost and 54 coverage losses,
eight bounded source/noise dispositions and remaining risks. The subsequent
“發佈” authorizes the v0.7.0 publication procedure. This entry records those
decisions; it is not evidence that a merge, tag, release asset or PyPI upload
has already completed. Record each actual publication result separately.

[Release evidence and limits](https://github.com/taipei49314/checkwash/blob/v0.7.0/docs/releases/v0.7.0-public-launch.md)
and [known issues](https://github.com/taipei49314/checkwash/blob/v0.7.0/docs/KNOWN-ISSUES-v0.7.0.md)
retain raw errors/skips, legacy UNKNOWN and the nonblind scope. T-528 remains
CLAIMED and the original A–D held-out/custody work remains incomplete. The
protected historical materializer is unchanged. The Action keeps its v0.6.0
one-release-lag pin; downstream re-pins require their own applicable authority.

## 2026-10-08: the last approvals land

On 2026-10-08 the maintainer approved the three maintainer-owned changes then
waiting ("核准"): `8977093` in #352, and the C2 text of #353 (THREATMODEL row
125, D-124) and of #354 (SPEC's `TEST_PATCHES_SUBJECT` row, THREATMODEL rows
90 and 109, D-125). The agent committed each C2 exactly as its pull
request's description wrote it.

Since #349 updated this file, four more pull requests merged into `main`,
each with a merge commit once CI on its head showed only the expected red.
`main` is now `d4b2529`.

| PR | what it does | merge | record |
|---|---|---|---|
| #350 | #212: the JS/TS replay corpus selection, recorded under `benchmarks/` | `1367e0b` | — |
| #352 | #201: verdict-gate cases F7, F8 and Fc2 for #196's 187.2 shapes | `17b0e79` | — |
| #353 | #272, second stage: a skip reached through an imported helper is read | `b7405a7` | D-124 |
| #354 | #196 188.5: what a stand-in names outside its own call is read one hop | `d4b2529` | D-125 |

#352 closed #201, and #353 closed #272. #354 is part of #196, which stays
open for one item.

A review of the merged documentation found passages that lagged #353 and
#354. The agent-writable ones were fixed in those pull requests before they
merged (`8e5a571`, `e17841d`). Three maintainer-owned passages lagged too.
The maintainer approved their exact text on 2026-10-08 ("核准"), and #355
commits it:

- THREATMODEL row 118's residual said a skip in an imported helper is not
  read;
- SPEC's `TEST_DISABLED` row described only a same-file helper;
- SPEC's `TEST_PATCHES_SUBJECT` residuals did not list the
  `monkeypatch.context()` receiver that THREATMODEL row 90 and D-125 name.

A second review the same day found two more agent-writable comments, fixed
in #355, and four more maintainer-owned passages that lagged. The
maintainer approved their exact text the same day ("核准"), and `775672d`
commits it:

- THREATMODEL row 104's last residual named only row 125's same-file
  helpers;
- row 104 listed the conftest fixtures of a duplicate survivor as unread,
  which #266 reads;
- THREATMODEL row 54 listed aliased and raised body skips as unread,
  which #220 reads;
- SPEC's D6 row did not name a skip a helper ends in among those it
  holds, though the engine and row 125 hold it.

Open on 2026-10-08:

- Of the 22 issues the scope started with, two are open:
  - #196: its one remaining ruled item is 183.2's conftest half, a guarded
    skip in a conftest fixture a test requests. Doing it changes an existing
    fixture's expected output, which AGENTS.md rule 2 leaves to the
    maintainer; #351 asks for that ruling.
  - #212: the selection is recorded (#350). The measurement on it, and its
    class label and release criterion, wait for the release that ships the
    JS rounds.
- #325's fix is #340 (D-120). It waits on the maintainer's approval of its
  maintainer-owned commit `dcc6104`, and it conflicts with `main`.
- These wait on the maintainer's rulings: #351, and the 22 put as one list
  on 2026-10-07 (#275, #278, #280, #281, #282, #288, #289, #292, #293,
  #297, #306, #312, #313, #314, #320, #321, #322, #323, #330, #343, #345
  and #346).

What a successor needs to know:

- **The ruleset merges only a pull request that is up to date with
  `main`.** Approved pull requests therefore merge one at a time: merge
  `main` into the next one, wait for CI (about 13 minutes), then merge.
  A scratch merge of the next pull request onto the previous one's head has
  the tree its real merge will have, so it can be checked before the
  previous one merges, and the real merge's tree compared with it after.
- **A maintainer-owned commit carries the approved text and nothing else.**
  Each C2 was applied by exact replacement from the text in its pull
  request's description, and an independent check compared each commit
  with the live description byte for byte.

## 2026-10-07: the merge train, and what waits on the maintainer

After #300 updated this file, 26 more pull requests merged into `main`, the
first on 2026-10-06 and the rest on 2026-10-07. Each merged with a merge
commit once CI on its head showed only the expected red,
`test_pinned_tag_ships_the_current_source` on the nine test legs. `main` is
now `b2e0eb5`.

On 2026-10-07 the maintainer:

- approved the maintainer-owned commits then waiting, those of D-104 to
  D-122 except D-120, whose pull request was not yet open ("核准", then
  "全部 18 個");
- ruled #335 as its proposal says ("照提案"), and approved its D-123
  ("核准");
- let the agent resolve the conflicts the stacked rounds met in the
  maintainer-owned files, where each round adds its entry at the same place,
  by keeping both sides' approved text and changing no word ("A").

Each pull request's description lists the merges its branch took in, and
each merge commit's message names its conflicts and how they were resolved.

| PR | what it fixes | merge | record |
|---|---|---|---|
| #291 | #224: Python comparisons carry a direction | `4f0955b` | D-103 |
| #334 | #331: a bare assert's subject is compared before "polarity inverted" | `974053b` | — |
| #298 | #226: one definition of a non-literal expected value, in Python and JS | `1eb93e7` | D-104 |
| #303 | #196 188.6: JS alias specifiers name first-party modules | `c3c1101` | D-105 |
| #304 | #235: parsing a JS/TS test file is linear in its size | `8deb244` | — |
| #305 | #294: an iterator callback keeps its assertions whatever the receiver | `bca7ff2` | D-106 |
| #339 | #319: reading JS or TS tests prints no Python warning | `577c535` | — |
| #341 | #332: a quote-style respelling (black) is no change | `5f5ec46` | — |
| #347 | #344: each subtree is walked once per parse | `ebea450` | — |
| #302 | #263: a string skipif/xfail condition is the expression pytest evaluates | `584c6ca` | D-107 |
| #301 | #266: a D10 survivor is read with the conftest files above it | `fdb5d79` | D-108 |
| #307 | #284: a negated approximate comparison is read as negated | `4a3699b` | D-109 |
| #308 | #299: an assertion is an approximate comparison only where it states one | `9361ddb` | D-110 |
| #316 | #272, first stage: a skip reached through a same-file helper is read | `e6b46db` | D-111 |
| #318 | #286: numpy's and torch's assertion calls are lent as a bare assert is | `6f6c056` | D-112 |
| #309 | #214: a GitLab runner job that cannot fail the pipeline is a weakened command | `6aeca0f` | D-113 |
| #329 | #173: an addopts target is an explicit target of every run | `eca25df` | D-114 |
| #315 | #215: chai's should-style and property assertions are read | `7ec7aaf` | D-115 |
| #328 | #310: `py.test` is the pytest module wherever a skip is read | `2371afd` | D-116 |
| #317 | #311: an undeclared global `chai` is chai's module | `edb1f8a` | D-117 |
| #326 | #233: AVA's and tap's tests are read | `e1cacff` | D-118 |
| #336 | #324: a multi-line pytest setting is read to its end | `e82dd14` | D-119 |
| #337 | #327: a quoted pytest setting is read by its section | `43b1947` | D-121 |
| #338 | #218: stand-ins a JS setup file installs are reported | `f12224f` | D-122 |
| #348 | #335: a git submodule is a directory whose content is unknown | `cc5141c` | D-123 |
| #342 | #333: a JS skip condition respelled (prettier) is no change | `b2e0eb5` | — |

Each issue these pull requests name is closed, except two. #316 is the
first stage of #272, which stays open for the rest. #303 fixed item 188.6
of #196, which stays open for its other items.

Open on 2026-10-07:

- Of the 22 issues the scope started with, three are open:
  - #196 closes once its ruled sub-items are done (its 2026-10-06
    decision). Two remain: 183.2's conftest half, a guarded skip in a
    conftest fixture a test requests, and 188.5's closing round C, which
    reads stand-in names one hop through `vi.hoisted` or a mock-prefixed
    object, with Python's targets built at runtime.
  - #201 closes on the same terms. Its last ruled item is verdict-gate
    cases for the 187.2 shapes.
  - #212 is the JS/TS history-replay corpus, ruled on 2026-10-06: six
    repositories, the last 300 non-merge commits of each, selected and
    recorded under `benchmarks/` before any engine runs on them. It is the
    scope's last item. Its class label and release criterion are asked
    again when the release that ships the JS rounds is prepared.
- #180 and #181 closed on 2026-10-07 under their 2026-10-06 closing
  decisions, once #215 and #214 were done.
- Filed along the way and fixed: #284, #286, #294, #295, #299, #310, #311,
  #319, #324, #327, #331, #332, #333, #335 and #344.
- #272's second stage, a skip in a helper imported from another module, is
  ruled (272.Q2 (a)) and under way.
- #325's fix is #340 (D-120). It waits on the maintainer's approval of its
  maintainer-owned commit `dcc6104`, and it conflicts with `main`, so
  GitHub has run no CI on it.
- These wait on the maintainer's rulings, put to them as one list on
  2026-10-07: #275, #278, #280, #281, #282, #288, #289, #292, #293, #297,
  #306, #312, #313, #314, #320, #321, #322, #323, #330, #343, #345 and
  #346.

What a successor needs to know:

- **A job that never got a runner is not a test result.** In GitHub's
  Actions incident on 2026-10-07 (from about 16:54Z), some jobs failed
  without ever getting a runner, and left no log. Each such job was re-run
  once, and each re-run gave the expected result: a pass, or on a test leg
  only the expected red.
- **`byte-compare` needs all nine test legs' artifacts from the same
  attempt.** It downloads `corpus-*-attempt-<run_attempt>`, so one leg that
  left no artifact fails it with "expected exactly nine named artifacts".
  Re-running a run's failed jobs re-runs every failed leg, the nine
  expected-red ones included, and then `byte-compare`. A pull request whose
  run was re-run merged only after the whole re-run attempt finished.
- **Merge a stack in order, and retarget each pull request to `main`
  before its merge.** A pull request merges into its current base, so one
  still based on another branch would merge into that branch. A retarget
  starts no CI run.

## 2026-10-06: the scope's first merges

On 2026-10-06 the maintainer approved the rulings and the maintainer-owned
commits put to them ("全部核准") and gave the agent the merge for the rest of
the session ("授權代合 這個session永久生效"). These pull requests merged that
day, each with a merge commit, once CI on its head showed only the expected
reds:

| PR | what it fixes | merge | record |
|---|---|---|---|
| #273 | #254: a skip guard reads the class attribute its class body sets | `1c8a351` | D-095 |
| #274 | #219: a pytest file beneath a snapshot directory is a test | `bc78c4d` | D-096 |
| #276 | #216: the JS and task runners count where a command starts | `b1eba79` | D-097 |
| #277 | #213: composite action definitions are ci | `2ecb2cc` | D-098 |
| #296 | #295: the frozen v0.3.3 byte comparison runs on dispatch only | `b96baa6` | — |
| #279 | #221: `.pytest.ini`, `pytest.toml` and `.pytest.toml` are ci files | `b8968e2` | D-099 |
| #283 | #220: a test body's skip is read through its imports | `c8d0395` | D-100 |
| #285 | #196 190.3: places, delta and abs are one absolute bound | `a92b9f8` | D-101 |
| #287 | #222: Python tolerance calls are approximate comparisons | `f8c4cde` | D-102 |
| #290 | an allowlist entry for #224's ruled case move (expires 2026-11-05) | `eabe6eb` | — |

Since #296, `qualify` no longer runs the v0.3.3 byte comparison on pull
requests, so the one expected red on `main` and on a pull request is
`test_pinned_tag_ships_the_current_source` on the nine test legs.

In review:

- #291 (#224, D-103): Python comparisons carry a direction. Its maintainer
  commit is approved.
- #298 (#226, D-104): one definition of a non-literal expected value, stacked
  on #291. Its maintainer commit waits for the maintainer's approval.

Of the 22 issues the scope started with, these are still open: #173, #180,
#181, #196, #201, #212, #214, #215, #218, #224, #226, #233, #235, #263 and
#266. #223 closed with #269 on 2026-10-05; its state was set on 2026-10-06,
because the close had not taken. Filed along the way, as the scope asks:
#272, #275, #278, #280, #281, #282, #284, #286, #288, #289, #292, #293, #294,
#295 (fixed by #296), #297 and #299. Rulings for #275, #278, #280, #281,
#282, #288, #289, #292, #293 and #297 went to the maintainer on 2026-10-06.

What a successor needs to know:

- **Retarget a stacked pull request before pushing `main` into it.** CI's
  `checkwash`, `dogfood` and `install-from-tag` judge the diff against the
  base the pull request had when the push happened. #291's head was pushed a
  minute before its base moved to `main`, so those jobs read the allowlist
  from the old base and blocked on the case move #290 exempts.
- **A closing keyword in a merged pull request's description closes the
  issue it names.** #290's "the round that fixes #224" closed #224 when #290
  merged; #224 was reopened until #291 merges.

## 2026-10-05: after v0.6.0, the next scope

The v0.6.0 grant is consumed. On 2026-10-05:

- the maintainer confirmed that the tag ruleset (22162219) is Active again
  ("確認已改回");
- #268, the publication record below, merged as `dba73c0`;
- #269 (#223, D-093) merged as `dbe00f0`. A unit of a changed test module
  that starts reaching an always-skip conftest fixture is now reported;
- #270, the verdict gate's rotation (RELEASING step 8c, D-094), merged as
  `812cc20`. The gate now compares each candidate with v0.6.0, which blocks
  156 of its 182 cases, and the acceptance file holds no entry.

`main` now carries #223 beyond v0.6.0. So
`test_pinned_tag_ships_the_current_source` is red on `main` and on every
pull request until the next release, as its docstring says it must be.

The maintainer set the next scope the same day ("修正一下 open
issue關完之後 把這次途中發現的新問題另開 issue 然後修復完之後先停 可以了";
"接下來專注於使用者體驗"; "你可以代合"):

- resolve the issues open on 2026-10-05;
- file each problem found along the way as its own issue, and fix it in the
  same effort;
- then stop. No release is part of this scope, and the focus after it is
  the user experience;
- the agent merges the PRs. A maintainer-owned commit still needs the
  maintainer's approval in its PR.

Of the 28 issues open that day, six were already fixed and are closed: #198,
#208, #209, #260 and #261 shipped in v0.6.0, and #223 closed with #269. The
other 22 are #173, #180, #181, #196, #201, #212, #213, #214, #215, #216,
#218, #219, #220, #221, #222, #224, #226, #233, #235, #254, #263 and #266.
Rulings for #212, #218, #263 and #266, and the open points of #215 and #233,
went to the maintainer on 2026-10-05.

## 2026-10-05: v0.6.0 published

The maintainer cut the tag and published the release the same day
("已發佈"). Tag `v0.6.0` is the annotated tag object
`64f62061996eca1e0830113e02e34a9484ce000b` on
`8c70efbf93975bf3210acb8eafbaf4b38044a770`, the merge commit of #267. The
tag ruleset (22162219) rejects `v*` creation at every other moment; the
maintainer opened it for this tag push.

The [GitHub Release](https://github.com/taipei49314/checkwash/releases/tag/v0.6.0)
was published at 2026-10-05T16:14:38Z. Release workflow run 37339312806
(build and pypi green) did the following:

- built the wheel, the sdist and `checkwash.pyz` from `8c70efb`, and
  qualified the source, the zipapp and a fresh-venv install of the wheel
  against the assertion contract;
- attached the three artifacts;
- published the wheel and the sdist to PyPI at 16:23Z.

The SHA256 digests and sizes PyPI reports for 0.6.0 equal the GitHub assets
(wheel 672,611 bytes, `aa9cb79b…`; sdist 2,936,710 bytes, `72efa022…`). They
were compared through the GitHub and PyPI APIs; the published artifacts were
not downloaded or executed for this record. `checkwash.pyz` is 655,217 bytes,
`4f9c7b83…`.

On the release commit and its tag:

- the verdict gate (#201) passed on the release PR's head (run 37322393159),
  on `main` (run 37324377879) and on the tag (run 37337702973), each on
  attempt 1, against the v0.5.0 baseline;
- public CI on the tag (run 37337702989) passed every job. The legs read for
  this record give 14,097 passed on ubuntu 3.12 and 14,095 passed with 2
  skipped (the paused perf checks) on macOS 3.12; the tag-parity test passes
  now that the tag exists;
- assertion qualification on the tag (run 37337702953) passed for the source,
  the wheel and the pyz, and the recommended Action's pinned v0.5.0 engine
  passed 283/283.

The verdict gate's rotation PR (step 8c) was the last part of the grant; it
merged as #270 (see above). The downstream re-pins of checkwash-corpus and
smallestlie are not part of it.

## 2026-10-05: v0.6.0 release

The maintainer authorized this release on 2026-10-05 ("發 v0.6.0"), after
asking for `main` to ship before the next fix round ("與main差距太大了
先發在修"). The stacked fix PRs #258, #259, #262, #264 and #265 merged in
order first, with their maintainer commits approved, and #257 updated this
file; `main` was then `d12cfb8`. The minor bump follows the existing rule: the
JSON shape is unchanged, but some existing findings now carry different
fingerprints, so allowlist entries for those shapes stop matching (D-092
lists them).

The THREATMODEL rows fixed since v0.5.0 name v0.6.0 where they said
"unreleased"; their text and pins are the merged PRs'. Package metadata is
0.6.0; the recommended Action advances to v0.5.0 (`24b60a2`) under the
one-release trust lag, as D-065 set. On the fixed 1,800-commit sweep, v0.5.0
and the release engine block the same 48 commits with no verdict move; one
passing rich commit gains five warn findings (D-092). The verdict gate (#201)
compares v0.5.0 and the candidate on its 182 cases. The
[release guide](docs/releases/v0.6.0-public-launch.md) defines the scope and
limits. The downstream re-pins are not part of this grant.

## 2026-10-05: unreleased on main since v0.5.0

`main` was `81f69ab`. v0.5.0 (`24b60a2`) was then the published engine, and
the recommended Action still pinned v0.4.2; D-065 moves it to v0.5.0 at the
next release, which the section above does. On 2026-10-05 the owner authorized v0.6.0 (AGENTS rule 5). The
release PR records that one-time scope in `docs/RELEASING.md`.

Since the v0.5.0 tag, 41 pull requests have been merged, all with merge
commits:

- **Post-release records and the release gate** (#194, #195, #200, #202,
  #203, #204, #206): the previous-release verdict gate (#201), D-064 and
  D-065.
- **#205:** a suite control's escalator is a fact about the diff (#207,
  D-066).
- **The 2026-10-03 maintainer rulings on #196 to #199 and #201**, posted as
  issue comments. Their doc-only items came first (#211), then one round each:
  - #197, JS/TS test paths and their test obligations: #210, #227, #228
    (D-067);
  - #199, only collection controls withhold the inventory: #229 (D-068);
  - #198, JS predicate identity and operand evidence: #230, #231 (D-069,
    D-070);
  - runner evidence, focus and test-support roles: #232, #234, #236, #237,
    #238 (D-071 to D-074);
  - JS stand-ins, binding writes and bounds: #239, #241, #242, #243 (D-075,
    D-076);
  - #196's follow-ups 189.2 to 183.2: #244 to #253, #255, #256 (D-077 to
    D-087). #252 carries the doc-only rulings (D-085), and #244 closed #225.
- **The 2026-10-04 rulings on #208 and #209, and the 2026-10-05 rulings on
  #260 and #261**, one round each, merged in order on 2026-10-05:
  - #208 with #209 Q1 and Q4, D6 per marker: #258 (two exemptions), #259
    (D-088);
  - #209 Q2, Q3 and X1, only an effect makes a hook a control: #262 (D-089);
  - #260, every `pytestmark` spelling read: #264 (D-090);
  - #261, a guard removed from an existing suite-level control: #265 (D-091).

What a successor needs to know:

- **CI on the merged heads** was red only where `main` is red: `qualify`
  fails its legacy v0.3.3 byte comparison (#201), and
  `test_pinned_tag_ships_the_current_source` fails on every test leg until
  the next authorized release.
- **Allowlist entries added since v0.5.0**, each approved by the owner:
  #227's FAMILIES pin (expires 2026-10-17), #243's three entries for ruling
  189.1 (2026-10-31), #255's entry for 183.2's second stage (2026-11-03) and
  #258's two entries for ruling 208.Q1 (2026-11-03).
- **For the next release guide** (X.release-and-fingerprints): D-070, D-071,
  D-073, D-074, D-077, D-081, D-083, D-087 and D-090 record fingerprints that
  move. In D-090's (#260), a mark bound to a name and applied by it, once
  reported as `module.skip` or `module.xfail` on every test of the module, is
  reported under the mark's own name on the tests it marks. D-084 names two
  verdicts that move from block to pass.
- **Rulings that wait for their rounds:** #219, #220, #221, #222, #223, #226
  and #254. #223's round was under way and is paused for the release. #196
  keeps the other follow-ups, among them 190.3, 188.6 and 183.2's conftest
  half after #223. #263 and #266 wait for rulings.

## 2026-10-01: v0.5.0 published

The maintainer reviewed the sweep list and cleared the tag the same day
("可以打 tag，照流程發版"). Tag `v0.5.0` is the annotated tag object
`2f2f9296752a5ef971c74ebaf6abccfbba2bfcf2` on
`24b60a2019a5900291ecb35ab8290f34af2d5438`. The tag ruleset was disabled only
for the tag push, from 20:43:31Z to 20:43:34Z, and is active again with no bypass
actors.

The [GitHub Release](https://github.com/taipei49314/checkwash/releases/tag/v0.5.0)
was published at 2026-10-01T20:55:16Z. Release workflow run 36925091407 (build
and pypi green) did the following:

- qualified source, zipapp and the fresh-venv wheel at 283/283 each;
- attached the wheel, sdist and pyz;
- published the wheel and sdist to PyPI at 21:01Z.

The SHA256 digests and sizes PyPI reports equal the GitHub assets. They were
compared through the GitHub and PyPI APIs; the published artifacts were not
downloaded or executed for this record.

Public CI on the tag
([run 36923680453](https://github.com/taipei49314/checkwash/actions/runs/36923680453))
is green:

- 9,040 passed on each Linux and Windows leg;
- 9,038 passed and 2 skipped on each macOS leg (the paused budget checks);
- dogfood, byte-compare and install-from-tag passed.

Assertion qualification on the tag (run 36923680421) passed 283/283 for source,
wheel, pyz and the recommended v0.4.2 engine. The earlier main push of the same
commit (run 36923638001) failed only the by-design tag gate, because the tag did
not exist yet.

The grant's remaining scope is the downstream re-pins, checkwash-corpus first and
smallestlie second. Each is merged only after the maintainer reviews it.

## 2026-10-01: v0.5.0 issue-round release

The maintainer authorized this release on 2026-10-01 ("授權發粄", with the
version chosen as 0.5.0) after the red-team reports #172–#182 were worked
through PRs #183–#192, all merged with merge commits; main was
`3cef2a5882fd89945e677dd028b7cef49db3d65b`. The minor bump follows the
existing rule: the JSON shape is unchanged, but some existing findings now
carry different fingerprints, so allowlist entries for those shapes stop
matching.

THREATMODEL rows 104–112 take the PRs' proposed text, numbered in issue order
by the maintainer's choice; SPEC is unchanged. Each row that claims a closure is
pinned by fixtures' `bypass:` lines or, for row 105, by an end-to-end test, and
`benchmarks/FAILURES.md` follows. The two performance budget checks are skipped
on macOS by maintainer decision; the budgets are unchanged. Package metadata is
0.5.0; the recommended Action advances to v0.4.2 under the one-release trust lag.

The fixed 1,800-commit Python sweep of `3cef2a5` ran on the pool (estate
T-494, run 36888070539). It has 48 blocks and matches the published v0.4.2
result in blocked commits, blocking findings and per-rule counts. Against the
older reference arm (46 blocks) it reports the two extra blocks v0.4.2 already
had, and the maintainer's gate holds the tag until the maintainer has reviewed
that list. Tests, sweeps and package checks run remotely; this round supplies no
work-machine testing exception. The [release guide](docs/releases/v0.5.0-public-launch.md)
defines the scope and limits. Downstream re-pins, checkwash-corpus first and
smallestlie second, are authorized as separate PRs after publication, each merged
only after the maintainer reviews it.

## 2026-09-23: v0.4.2 published (estate T-449 consumed)

Tag `v0.4.2` is `23ef5929896187e4aac5889735c792e65af3e721`. The
[GitHub Release](https://github.com/taipei49314/checkwash/releases/tag/v0.4.2)
was published at 2026-09-23T16:40:43Z; release workflow run 35890410767 (build
and pypi green) attached the wheel, sdist and pyz at 16:46Z and published the
wheel and sdist to PyPI at 16:47Z with SHA256 digests equal to the GitHub
assets. `checkwash-0.4.2-validation.json` was added at 17:06Z. Public CI on
the tag
([run 35888249981](https://github.com/taipei49314/checkwash/actions/runs/35888249981))
is green: nine OS/Python legs at 8,291 passed each, plus dogfood, byte-compare
and install-from-tag. The earlier main push of the same commit (run 35886613228)
failed only the by-design tag gate, because the tag did not exist yet. The
recommended Action stays at v0.4.1; the tag's separate recommended-engine
qualification (run 35888249988) reports 13 of 283 contract cases failing, which
the release guide keeps visibly failed rather than waived. The T-449 grant is
consumed. Since 2026-09-26 the estate no longer governs this repository (estate
POLICY `independent-repos`, T-451): any later bump, tag, release or downstream
re-pin needs a new explicit one-time maintainer authorization, recorded in
`docs/RELEASING.md`.

## 2026-09-23: v0.4.2 JS/TS foundation release

The maintainer accepted the v0.4.2 release plan with "好 依你規劃走".
Estate T-449 records the new one-time scope. PR #167 is merged as
`5a6d190a4bca7e2790805553221750268b332b7a`; T-447's original delivery and
T-448's later integration remain separate completed records.

Release preparation includes the bounded callback/scalar/precision fixes,
canonical scalar compatibility across existing subject detectors, an independently
selected real JS/TS history replay, the separate fixed Python sweep and final-source
release qualification. Tests, sweeps and package execution run remotely.
Package metadata is 0.4.2; the recommended Action advances only to v0.4.1
under the existing trust lag and does not contain this foundation.

The [release guide](docs/releases/v0.4.2-public-launch.md) defines the scope and
limits. The [GitHub Release](https://github.com/taipei49314/checkwash/releases/tag/v0.4.2)
is the publication record and will identify final source, remote checks and public
artifact hashes. A candidate commit or temporary runner tag does not establish
publication. No later release, downstream-repository pin or next JS/TS stage is
authorized. Frozen contracts and historical benchmark/adjudication records remain
unchanged; legacy and old-Action measurements keep their actual results.

## 2026-09-23: JS/TS assertion foundation candidate

Estate T-447 implements the maintainer's "下刀" instruction in
[PR #167](https://github.com/taipei49314/checkwash/pull/167). Inline test callback
boundaries, complete matcher arguments, scalar expectation changes and positive
`toBeCloseTo` precision now feed the existing detectors. Legacy assertion
fingerprints remain compatible; the original 136 API/context cases and 248
mutations remain unchanged. A separate 25-case foundation inventory runs through
source, wheel and pyz. The source suite collects 8,245 tests.

See [assertion coverage](docs/assertion-coverage.md) for bounded syntax and
callback limits. The PR checks and receipts identify the exact source validated;
the existing tag/source identity, legacy quality comparison and older recommended
Action qualification retain their own results. This candidate has no version
bump, tag, release or downstream re-pin authorization. Published v0.4.1 artifacts
do not contain this candidate's JS/TS expansion.

## 2026-09-23: v0.4.1 Node assertion repair and prevention

The maintainer explicitly authorized merging and publishing this repair on
2026-09-23. This is a new one-time authorization for v0.4.1, integrated through
[PR #166](https://github.com/taipei49314/checkwash/pull/166), which includes #165.
The [release guide](docs/releases/v0.4.1-public-launch.md) describes the scope;
the [GitHub Release](https://github.com/taipei49314/checkwash/releases/tag/v0.4.1)
records publication status, final-source checks and artifact identities.
No later version, downstream re-pin or automatic next release is authorized.

Issue #164's missing Node assertions are represented in IR. Node default test
paths, static import aliases, lexical shadows and direct binding writes are
checked; unresolved assertion candidates remain visible through coverage
diagnostics and a separate versioned report. The independent inventory contains
136 API/context cases and 248 mutations. Source, wheel and pyz qualification
must run against the final release bytes. The default-branch ruleset requires
checkwash and all three candidate assertion contracts, with strict checks and
no bypass actors. Package/CLI metadata is 0.4.1; the recommended Action advances
to prior stable v0.4.0, which still lacks the Node repair.

Fresh release-source tests, the fixed 1,800-commit sweep, distribution receipts,
tag CI and public GitHub/PyPI verification are recorded in the release notes.
The tracked historical sweep/adjudication and the frozen legacy comparison
remain unchanged. Prior candidate results are identified by their own source;
publication does not make the older Action engine's capability gaps pass.
The one-time release scope ends after publication and verification, with the
tag ruleset restored to active.

## 2026-09-22: v0.4.0 published (estate T-436 consumed)

PR #160 merged as `6dd3158653c3569279fb2c56cef6af30a959d844`, tagged `v0.4.0`
through the recorded ruleset sequence, and published as the
[GitHub Release](https://github.com/taipei49314/checkwash/releases/tag/v0.4.0)
with wheel, sdist and pyz; PyPI published through trusted publishing
(release workflow run 35729201886, both jobs green; GitHub/PyPI wheel and
sdist SHA256 hashes verified equal). Public CI on the tag
([run 35727569979](https://github.com/taipei49314/checkwash/actions/runs/35727569979))
is green: nine OS/Python legs at 7,045 passed / 0 failed, plus dogfood,
byte-compare and install-from-tag. Final-source receipts recorded in the
release notes: local full suite (6,978 passed plus the by-design tag gate
before the tag existed), the 178-case replay (77/88 escapes blocked; the 90
formerly-blocked false positives split exactly 75 preserving passes / 15
real losses), the 381-case replay (215/300 escapes blocked; 74 preserving
passes / 7 real approximate-comparison losses), and the fresh 1,800-commit
sweep (48 blocks, 0 engine errors; tracked sweep records remain the
v0.3.0-engine receipts). The legacy v0.3.3 quality byte comparison stays red
as the disclosed cross-version mismatch; no waiver was activated. The T-436
grant is consumed: no further bump, tag or release without a new human
instruction.

## 2026-09-21: v0.4.0 issue-resolution candidate

The human selected v0.4.0 and authorized issue resolution through release.
Estate T-436 records the scope; [PR #160](https://github.com/taipei49314/checkwash/pull/160)
is the integration candidate. Source metadata is prepared for 0.4.0; no
publication is claimed. The recommended Action advances to the prior stable
v0.3.4 (`23fce200561ae4a95e46539ed9e668088591d1c1`).

[The candidate record](docs/releases/v0.4.0-public-launch.md) tracks completed
repairs, evidence qualification and the remaining release conditions. Issue
#93's input-change contract and the inherited-test tamper classification
were adopted by the maintainer on 2026-09-21. The local executor resumed
publication, repaired the Boolean identity-loss and changed-callee table
regressions, and requires final-source qualification before publication.
Earlier measurements below retain their original populations, versions and dates.

## 2026-09-12: v0.3.4 bounded family release

Estate T-332 authorizes publication of the reviewed PR #155 edition, based on
`614f9aa826a37bd73adfbd4061e461755f224d7b`. Release preparation changes version
metadata, current documentation and the prior-release doctor/Action pin;
the detector implementation and frozen records retain that candidate's bytes.
The CLI/package version is v0.3.4. The recommended Action advances only to
v0.3.3 (`498064f095bd892550a917219798b3f44c42ccef`) and does not contain the
new family repairs or quality preview.

The bounded repairs cover row disabling and answer replacement, concrete
table/helper/class/wrapper oracles, expectation provenance, literal constant
renames, runtime providers/stand-in installation and CI collection options.
Optional IR evidence retains schema 2. Unknown execution context and the
documented input-role/no-op-callee residual remain conservative boundaries.

The prior `1de04840520c0211d8611c734c09cbd616d24f09` refactor replay records
240 observations, 57/60 qualified, 4 all-case blocks and 2 qualified blocks;
all 18 repaired historical false positives qualify and pass. Three existing
fixture errors remain. Its separate 1800-commit sweep completes with 46 blocks
and no engine errors/skips: 1799 captured observations match the reference,
while one already-blocked click finding changes severity/message. The frozen
observation digest still differs; final HEAD/clean checks after that failed
assertion were NOT_RUN. These are prior-source receipts, not a new tag sweep.

At `614f9aa`, nine public CI legs each record 2413 passing tests and the
expected old-tag identity failure; all nine raw corpus outputs match. The
quality suite records 259 passes, but its frozen T-255 byte comparison remains
red. Separate supplement evidence qualifies 78/80 tamper cases, with 27
qualified escapes, and records five Windows symlink skips in the corpus
suite. Publication does not turn those limitations into acceptance.

The exact release-source/tag checks and public asset verification are recorded
with the [v0.3.4 release](https://github.com/taipei49314/checkwash/releases/tag/v0.3.4).
See the [versioned guide](docs/releases/v0.3.4-public-launch.md) for receipt
links, upgrade boundaries and what each population supports. Historical
measurements below are unchanged. This is a one-time publication scope;
after verification it is refrozen, with no automatic next slot.

## 2026-09-08: v0.3.3 bounded fixture precision release

Estate T-229 publishes the T-228 candidate for multiple consumers of deeply
immutable literal fixture parameters. Only historical cases 012 and 032
change block to pass in the fixed 178-case CLI comparison; both before and
after suites pass good production and fail buggy production with completed
test failures. The existing execution-context checks and expansion cap stay.

The fixed 1800-commit regression matches all cached-reference verdict and
finding observations. The stricter refactor receipt remains 57 qualified,
three fixture errors, 20 qualified blocks and 22 all-case blocks. These are
different populations from the held-out raw rate, which belongs to v0.3.2
and is not a new measurement of this detector. Original benchmark records
and human labels are unchanged. See the [release evidence](docs/releases/v0.3.3-public-launch.md).

The CLI is v0.3.3; the one-release trust lag advances the recommended Action
to v0.3.2, which does not include this fixture precision fix. Schemas,
fingerprint contracts, severities and alignment parameters do not change.
The owner's publication instruction includes immediate refreezing after
asset, metadata and family-pin verification; no recurring release slot.

## 2026-09-07: release slot (v0.3.2)

Release slot 2026-09-07, estate ledger T-216. Since v0.3.1, 0 commit(s) touched src, action, pyproject.toml:


The one-release trust lag advances the Action pin to v0.3.1.

Narrative for this round (D-058): a second documentation and metadata
release on the v0.3.0 engine, cut so that the PyPI description — the README
at the tag — carries the current-state corrections of PR #146 (22 of 60 on
every line; the release, CLI and Action-pin sentences naming the versions
actually shipped). No detector changed, so no sweep was re-run; the checks
that stood in are named in D-058. The one-release trust lag advances the
recommended Action pin to v0.3.1, which is the same v0.3.0 engine.

## 2026-09-07: release slot (v0.3.1)

Release slot 2026-09-07, estate ledger T-207. Since v0.3.0, 0 commit(s) touched src, action, pyproject.toml:


The one-release trust lag advances the Action pin to v0.3.0.

Narrative for this round (D-057): a documentation and metadata release on
the v0.3.0 engine, cut so that the PyPI description — the README at the
tag — matches the repository (the 46/1800 sweep record, the v0.3.0 guide
links, the 22/60 refactor count). No detector changed, so no sweep was
re-run; the checks that stood in are named in D-057. The one-release
trust lag advances the recommended Action pin to v0.3.0, so the Action
now carries the v0.3.0 detector changes.

## 2026-09-07: the six-repository sweep re-run on the v0.3.0 release commit (estate T-201)

The tracked sweep record (`benchmarks/sweeps/`) is now the v0.3.0 release commit
`4387097`, swept on 2026-09-07 on the estate runner pool (run
34121457167: six clean checkouts, Python 3.12, 300 commits per repository,
0 engine errors) and copied verbatim from the pool receipt. It replaces the
v0.1.46 record that v0.2.11 to v0.2.13 carried forward. Blocks moved
**42 -> 46/1800** (2.56%), gone 0, new 4: click `61bdc2ae81`
(hidden-input regex mask; the parametrize row-identity rule of #135 sees the
expectation rows change and cannot reach the production change through
CliRunner), click `c498ced0e7` (`expect` -> `expected` rename inside the
expectation), flask `0a00e1b608` (`tmpdir` -> `tmp_path` migration), httpx
`7985f685ca` (`URL(...)` -> `httpx.URL(...)` import style). All four were
judged false positive by the maintainer in a single pass (the last three had
blocked since v0.2.12's reference arm and were first named in #132), so the
adjudicated false-positive rate is **31/1800 = 1.72%** and the
legitimate-policy-block rate stays **15/1800 = 0.83%**; recorded opaque
production changes **24/1800**. `adjudication-2026-09-07.json` carries the
42 earlier verdicts verbatim. Still in-sample: this corpus tuned the detectors.
THREATMODEL.md's floor number was updated to match the adjudication; the
maintainer pass for the 0.3.0 detector changes (THREATMODEL/SPEC rows) is not
part of this entry.

## 2026-09-07: release slot (v0.3.0)

Release slot 2026-09-07, estate ledger T-198. Since v0.2.13, 35 commit(s) touched src, action, pyproject.toml:

- 8dd3b80 fix(table_oracles): inline same-file assert helpers and literal-table fixtures per row
- 6f0f5e2 fix(expectation_definition): key parametrize expectations by input, read wrapped rows
- a545381 fix(diffalign): count disabled parametrize rows by identity, not by live count
- fb7bb4e fix: preserve context proof for bounded default testpaths
- f686ea6 fix: retain rename disappearance without truthiness raw provenance
- e0ec59c fix: withhold context proof for configured pytest collection
- ea352bf fix: expose normalized subjects across literal parameter tables
- d02d527 fix: align complete snapshot inventory across consumers
- 680a7fd fix: preserve row object identity in table projection
- 6b56907 fix: distinguish mock patch construction from activation
- 78543d0 fix(frontend): expose closed scalar truthiness oracles
- 803576d fix: preserve concrete literal table oracles during consolidation
- 951db7d fix: require closed repository startup context for normalization proof
- f5cff22 fix(ir): preserve normalization proof after JSON reconstruction
- 1ff39a3 fix(frontend): classify direct conditional AssertionError oracles
- 600145c fix(subject): preserve wrapper evidence and prove redundant normalization
- 2c2e9e9 fix: preserve conftest target evidence across adapter boundaries
- 79bb62e fix: recognize imported unittest.mock conftest stand-ins (#128)
- a855b46 fix: resolve conftest patch targets from strict snapshots (#127)
- a8ef758 fix: detect standalone stored expectation rewrites (#129)
- 4b98a38 Preserve concrete oracles through bounded root-helper extraction
- b8591f5 fix: require unchanged context for numeric restoration
- 290493d Add strict snapshot adapters for absence-sensitive oracle discovery
- 10910b4 fix(hooks): exclude implicit working directory from shared CLI probe
- 7793c2d fix(output): make human diagnostics safe across legacy Windows pipes
- b96c53a fix: bind snapshot exemptions to production cochanges
- bd43dc6 fix: scope out-of-contract exemptions to reviewed changes
- b662336 fix: scope parser exemptions to content and parser state
- 2f7aafb fix(hooks): explain the pre-commit template installation steps
- 017a76a fix(doctor): recognize local and shared Stop hook configurations
- 781223a fix(hooks): bind local hooks to an isolated executable runtime
- 6456483 fix: bind exemptions to reviewed content (700 tests pass; release parity pending)
- bb851af fix(doctor): explain rejected workflow configurations
- 55c6f7d Fix numeric-bound assertion restoration false positives
- c9e50fb fix: locate SARIF evidence in analyzed source (384 tests pass; dogfood 2 high)

The one-release trust lag advances the Action pin to v0.2.13.

Narrative for this round (maintainer pass 2026-09-07, D-056): five file-wide
exemptions bind to content (D-055; THREATMODEL 101 closed); parametrize rows
have an identity, so a skip-marked row is reported whatever is appended
beside it (102 closed; 102a, the deleted-plus-appended residual, open by
design) and the expectation comparison is row-keyed and reads wrapped cells
(86a, F-060 / F-067); table-driven oracles that delegate to a same-file
single-assert helper or a literal-table fixture are read per row (#136,
SPEC §2b); conftest stand-ins and stored expectations resolve from strict
snapshots (#127–#129); `stable_dump` pins `ast.dump` text on 3.13. Measured
after release on the pool: sweep 46/1800 (four new blocks, all adjudicated
false, click 61bdc2ae81 accepted as #135's price), LLM-arm CLI re-judge
79/88 escapes still pass and 65/90 honest still block (v0.2.13 in-process:
85/88, 90/90).

## Additional September 6 issue candidate

Issues #127–#131 had a separate source candidate, released in v0.3.0, covering conftest
targets, stored expectations and bounded Python oracle forms. See the
[scope and limitations](docs/issue-remediation-2026-09-06.md). The #125 CI
results in the next section describe that earlier source, not qualification
of these additional changes. Historical population runs remain unchanged.
After the exact review package was supplied, the owner directed continuation;
the candidate now includes the contract wording, complete frozen snapshot
adapters and three evidence-backed benchmark record updates. New source
replays are recorded separately. No new release or Action pin is implied.

## Next-minor remediation candidate, released as v0.3.0 (2026-09-07)

The remediation branch implements content-bound exemptions for five file-wide
rules, retires their path-only keys, and advances IR/findings schemas to 2.
It also fixes local-hook installation/doctor agreement, runtime binding,
Windows output, workflow diagnostics, SARIF source locations and narrowly
bounded numeric-restoration/root-helper precision. See the [upgrade notes](docs/remediation-upgrade.md)
for migration, compatibility and runtime limits.

The owner authorized merging the remediation on 2026-09-06. The integration
candidate includes the contract update and removal of the exact legacy AGENTS
ledger entry. It must enter main with the complete numeric-restoration follow-up,
not through an intermediate state. It shipped as v0.3.0 on 2026-09-07; the
recommended Action advances to v0.2.13. The original benchmark records below are
unchanged. The source-qualified stack has 912 passing tests on all nine CI
OS/Python combinations; the published-tag parity test still fails because this
source is unreleased, and the dependent cross-platform byte-compare is skipped.
The release slot, published-source parity, cross-platform byte comparison and
later Action promotion remain completion gates. A local candidate build does
not mean that users installing a published package have these fixes.

## 2026-09-06: public package-page correction (v0.2.13)

The owner authorized a one-time documentation/metadata release outside the
weekly slot, including GitHub Release, matching PyPI publication and family
pin updates. The ordinary release cadence resumes after this release.

The short README, corrected measurement provenance and explicit alpha limits
now ship in the package description. Its document links use absolute GitHub
URLs so they resolve on PyPI. The package summary describes known patterns
instead of promising every weakening will be caught. Existing v0.2.12 metadata
and assets remain historical; they are not replaced.

The Action and local doctor's trusted pin advance to released v0.2.12
(`e05c37f0e1673cdf218ec62fcfb7c6712cce704b`). Package/CLI version and this
trusted-pin constant are the only source changes; detector logic, frozen
policies, fixtures and benchmark records are unchanged. No new research
measurement is claimed. The historical 24/60 refactor result and 1.0 NOT MET
status remain visible. [Release and first-use guide](docs/releases/v0.2.13-public-launch.md).

## 2026-09-06: public-launch evidence labels, without a new engine measurement

The release remains v0.2.12. This documentation pass distinguishes the
released engine from historical evaluation records and corrects THREATMODEL
row 77's stale Windows-runner status by linking the existing row 87a evidence.
It adds no detector behavior and makes no broader Windows-language claim.

The authoritative table below now labels its sources explicitly. The tracked
six-repository sweep and its matching adjudication are historical, in-sample
records; regenerating their Markdown reports does not rerun the engine or
turn those records into a fresh v0.2.12 result. Original JSON dates, engine
metadata, verdicts, and the release-history entries below are preserved.

## 2026-09-03: a created config that relaxes the defaults is a modification (v0.2.12)

The owner's finding, reproduced on v0.2.11 in both configuration directories
(issue #79): commit one creates `.checkwash/config.toml` containing
`[detectors] disable = ["ASSERT_WEAKENED"]` — `GUARDRAIL_TOUCHED` at **warn**
under D-030's created-is-warn rule, verdict pass — and commit two weakens a
test under the disabled rule with zero findings. The same-commit form blocks,
because configuration is read from the base side; that is exactly why the
planting commit is the only place the plant can be caught, and at warn it
never blocked under the default `fail_on`.

D-030's sentence — "a constraint that did not exist has not been relaxed" —
is true of a hook file and false of checkwash's own config: with no file the
defaults were in force, and a new file that disables a detector or raises
`fail_on` relaxes them. Option A, the owner's decision: a created
`.checkwash/config.toml` / `.greenwash/config.toml` whose content disables any
detector or sets `fail_on` above `high` is E4 like any modification —
critical, `META`. Tightening-only or comment-only creations stay warn with
`GUARDRAIL_CREATED`; hook and instruction files keep D-030's warn; `roles`
overrides in a created config stay warn and are a stated residual, because a
monorepo's first role table cannot be told from a narrowing one without
blocking every adoption PR. SPEC §4's row carries the exception.

Measured: fixtures for the disable plant in both directories, the raised
`fail_on`, and the tightening control; two end-to-end tests (the plant blocks
at commit one, the tightening stays warn); five predicate tests. No existing
fixture expectation changed, and no number in the table moved: no corpus
repository carries either directory, so the six-repo sweep was not re-run;
tamper 49/80 and refactors 24/60 were re-verified in the release checkout.
The sibling shape — pre-seeding `allow.toml` with the fingerprint of the
weakening to come — remains D-003's accepted, visible trade (per-fingerprint,
`EXEMPTION_ADDED` pinned at the top of the report); a `disable` is a blanket
per-rule switch, which is the difference. THREATMODEL row 100 and DECISIONS D-054
record it (maintainer pass, 2026-09-03). The trust lag advances the Action pin to v0.2.11.

## 2026-09-02: the rename residue round (v0.2.11)

Five defects, none in a detector, each reproduced on v0.2.10 before anything
was built (issues #68–#72; T-44 in the estate ledger):

- **`.checkwash/**` was not a guardrail path.** `check` and `sweep` read
  `.checkwash/config.toml` first, but only `.greenwash/**` carried the role,
  so a comment edit in `.checkwash/config.toml` counted as a production
  change and granted `REPAIR_EVIDENCE` to a weakened assertion in the same
  diff (verdict pass), and a committed `[detectors] disable` produced zero
  findings. One glob, the matching SPEC §2 cell, `.checkwash` twins of the
  guardrail and exemption fixtures, and a test that pins the two directories
  to one role. `EXEMPTION_ADDED` now reports the ledger actually appended.
- **`allow`, `doctor` and the block hint were hardwired to `.greenwash/`.**
  With `.checkwash/allow.toml` present, following the printed instruction
  recorded an exemption in a ledger `check` never opened. One resolver
  (`config.resolve_config_file` / `read_base_config_file`) now serves every
  surface, and the diagnostics name the file actually read.
- **A bare `checkwash hook` exited 0** — usage printed through argparse
  `--help`. It is a usage error, exit 2 (SPEC §9).
- **A UTF-8 BOM on `config.toml` or `allow.toml` failed to parse** and the
  gate reverted to defaults: fail-closed, but the user's configuration was
  gone. Both readers decode `utf-8-sig`, as every other reader already did.
- **The composite Action still called itself `greenwash`** and ran
  `greenwash check`, alive only through the console-script alias. Renamed;
  the alias stays at least one more release, marked legacy in pyproject.

No detector logic changed and no number in the table moved: no corpus
repository carries either configuration directory, so the six-repo sweep was
not re-run; tamper 49/80 and refactors 24/60 were re-verified in the release
checkout. The one-release trust lag advances the Action pin to v0.2.10. Not
changed on purpose: the docs still hand a fresh repository `.greenwash/`;
making `.checkwash/` the documented default is a docs-and-SPEC decision for
the maintainer.

## 2026-08-29: the same bindings are walked once

The v0.1.46 release chain was clean on correctness but not stable at its own
500-file performance gate. The frozen 2.5 s threshold reproduced red under an
otherwise green suite and again in isolation (2.60–3.88 s across the observed
failures). The gate is the contract; widening it was not an option.

The cause was repeated work, not a detector trade. Every test unit walked the
same AST four times to build two views of the same assignments (definition
keys and referenced-name closure), then walked its statements again to prove
that `exclusive_bindings` was empty even when no name had more than one
definition. `_binding_maps` now builds both maps in one walk while preserving
the former assignment-before-walrus ordering. The unit consumes that pair
once. Exclusivity runs only when the already-built definition map contains a
multiply-bound name; without one, a non-empty result is impossible.

No judgement moved. The deterministic emitted-corpus artifact is byte-for-byte
identical before and after (`6994a886…`); an independent differential checked
2,165 real and fixture functions, including assignment order, walrus, unpack,
annotated and augmented assignments, and found zero IR differences. The full
six-repo sweep held case-for-case at **42/1800** (attrs 2, click 13, flask 7,
httpx 12, rich 6, starlette 2), with the same newest commits and zero engine
errors. The frozen perf gate then passed in ten independent fresh processes;
frontend, golden-case, determinism and finding-shape suites stayed green.

Explicit non-goal: the flat binding census still crosses nested lexical
scopes. A homonymous local in an uncalled nested helper can still make an
unchanged outer expectation look edited. That false positive was reproduced
during this takeover and is the next named defect; it is not smuggled into a
zero-behaviour performance round.

## 2026-08-26: the largest blind bucket closes — module constants become the fourth source

The last residual the promotion round filed, and the biggest: 29.2% of the
corpus's named expectations (445/1526, the 2026-08-25 census) live in
module-level constants, and editing one — `EXPECTED_TOTAL = 105.0` →
`100.0`, assertion byte-identical — produced verdict pass, zero findings
from all 21 rules. Reproduced before building anything.

Pre-registered before measurement (P1–P4, the D-050 discipline):
`EXPECTATION_DEFINITION_CHANGED` gains a fourth expectation source — the
file's own top-level constants, on new IR fields
`module_constants`/`module_constants_before`. Deliberately NOT the merged
D6 environment: that one resolves cross-file with a head reader on the
after side only, and an asymmetric environment must never feed a two-sided
comparison. Segments are canonicalized (`ast.parse(mode="eval")` +
`unparse`; unparseable segments go silent) because the raw-text comparison
was the binding channel's first false positive. Top-level rebinds are
last-wins on both sides — module execution order — so appending
`EXPECTED = evil` at the bottom of the file is caught by construction,
with none of the branch machinery the unit channel needed. The
subject-closure exclusion applies unchanged: a constant the subject also
consumes is a shared producer (T1.10), not an oracle.

Four fixtures, three mutations, each clause pinned: the probe shape blocks
at high; the same edit with its production change in-diff holds at warn
via `REPAIR_EVIDENCE`; a shared-producer constant stays silent (closure
mutation turns it red); a reformatted constant stays silent (raw-compare
mutation turns it red).

Measured, every pre-registered line held: the sweep moved 41 → **42**,
gone **zero**, exactly one new block — click `5989375dc3` ("ParamType
typing improvements"), where the typed production code newly imports `abc`
and `uuid` and the same diff adds exactly those two names to
`ALLOWED_IMPORTS`, the module-constant oracle of `test_light_imports`.
Adjudicated false (maintainer single-pass, the round's one new block,
weaker independence noted): the oracle genuinely widens but the
compensation is visible in the reviewed diff — the tool cannot connect the
hunks because an import-audit test calls no production symbol, the
`1c5e03eb32` failed-connection family. One of five budgeted. Arms
case-for-case unmoved (48/80, 25/60) — and unlike the prior-window round,
these single-diff arms genuinely exercise the new arm, so their silence is
measurement, not construction. `adjudication-2026-08-26b.json` carries 42
verdicts (41 verbatim + 1); floor 1.44% → 1.50%.

Stated residuals, none annexed: a constant imported from another file
(`from constants import EXPECTED`), conftest constants, and a constant
moved under a top-level `if` — it leaves `_top_level_constants` and the
arm goes silent, the module-scope cousin of row 95's tautological gate,
recorded there. D-051.

## 2026-08-26: the prior-window pardon — built, measured, and refused at its own gate

The second residual from the promotion round (the two-commit split: production
lands first, the test golden catches up test-only, in-diff repair evidence
correctly finds nothing) got the obvious fix built end to end: a
`REPAIR_EVIDENCE_PRIOR` de-escalator fed by the combined diff of the five
first-parent commits before the analyzed one, prod-side parseable-Python
modified-symbols only, no opaque escape, no test-side credit, the in-diff
`_symbol_match` bar unchanged. Pre-registered before measurement: P1
`823de916d9` leaves the block set; P2 `9303d77e8d` does not (its prior change
is test-side input); P3 zero spec-correct departures; P4 zero unpredicted
movement; **P1–P4 all hold or this does not ship.**

It does not ship. Four findings, each measured, any one sufficient:

- **The window lies on merge-flow repos.** "Five commits" is five
  *first-parent steps*: sampled over 40 analysis points per corpus repo, the
  window really contains on average 19 commits on click (max **57**), 12 on
  rich, 9 on flask. A pardon channel whose stated exposure is off by 11x on
  the repos it was tuned against does not get to call its exposure stated.
- **P4 breached — the channel out-ran its own designers on its own corpus.**
  The full sweep removed not one block but two: `823de916d9` (predicted) and
  `7022e202245b` (predicted by nobody). Forensics: that commit's window,
  merge-inflated, contains whole pull requests (#3078 fix/progress-type among
  them) whose combined diff modifies `rich/progress.py` and
  `rich/console.py` — and `test_columns` calls `Progress(` and `Console(`
  directly. Both departures are adjudicated false positives, which is why
  this reads like a win; the pre-registration exists precisely so that an
  unpredicted pardon is read as what it is.
- **Credit is never spent.** After an honest catch-up takes the pardon, the
  same prior production change keeps pardoning further expectation edits to
  the same symbols for the rest of the window — including an attacker's
  edit landed *after* the honest one, riding a stranger's already-repaired
  change. The in-diff purchase has no such shape: it forces the attacker to
  author the explaining artifact themselves, in the same diff.
- **The reviewer loses the artifact.** An in-diff pardon puts the
  explaining production change in front of the reviewer; the prior pardon
  replaces it with the tool's unreviewable say-so ("held at warn by:
  REPAIR_EVIDENCE_PRIOR", pointing at nothing in the diff).

Availability at a random moment is low (0–0.9% of test units pardonable at
each repo's current HEAD) — and irrelevant, because an attacker chooses the
moment and hot symbols are touched constantly. Every flaw has a fix
(per-commit non-merge window enumeration, unit-level spent-credit semantics,
the pardoning sha carried in the message), and together they make the pardon
channel more machinery than some detectors, in the one place machinery is
trust. Bought back: two of 1800, both already published as the promotion's
price. Refused on the same grounds as THREATMODEL 92: the trade funds the
attack surface out of the safety margin.

What the rejected build would have shipped, for the record: 39/1800 blocked
(engine 0.1.46-unreleased, full six-repo sweep), gone exactly
{`823de916d9`, `7022e202245b`}, other five repos byte-identical, tamper
48/80 and refactor 25/60 unmoved (single-diff arms cannot exercise the
channel — that verification gap was itself one of the stated reasons to
distrust it). The source tree is reverted to v0.1.45 exactly; the four
channel fixtures went with it, because they pin behaviour nothing has any
more. The two-commit split stays what the promotion round named it: an open,
adjudicated false-positive residual (`823de916d9`, `9303d77e8d`), now with
the measured record of why the obvious channel does not pay for itself.
Single-commit spot checks during the round: P1 and P2 both reproduced
exactly as predicted before the full sweep contradicted P4 — a channel can
pass every aimed shot and still fail the sweep, which is the whole argument
for sweeps. D-050.

## 2026-08-26: the binding channel learns what the parametrize channel knew

First of the three residuals the promotion round filed. The parametrize
channel has excluded additions since it shipped — added rows are
`TEST_DISABLED`'s event, "Only a same-length column with different cells is
an expectation edit" — while the binding channel was a bare `!=` on the
`\x1f`-joined keys, so rich `c8abbb3bd2` ("Fix test for Python 3.13", the
old golden kept verbatim in the `else` arm) blocked at high with no
production change to explain, and both raters called it false.

The port is not the naive one. Parametrize rows are parallel test items;
bindings are sequential rebinds where the last one reaches the assertion —
so "the old definition survives" proves nothing on a straight line, and a
same-length guard alone would have opened a new bypass (append
`expected = evil` after the honest binding: today that fires, and it must
keep firing). The guard demands three things at once: more definitions on
the after side, every before-side definition surviving verbatim (multiset
containment — `_binding_definitions` walks breadth-first, order is not a
contract), and the name's bindings pairwise **branch-exclusive**, computed
by a new statement walk in the frontend (`_exclusive_bindings`, recorded on
`UnitSide.exclusive_bindings`): `if`/`elif`/`else` and `match` arms diverge,
loop/`with`/`try` bodies and nested defs keep their parent's path, a walrus
in an `if` test belongs to the parent. Default-then-override
(`e = 0; if c: e = 1`) is not exclusive and keeps firing.

Fixtures first, four of them, each clause pinned by its own mutation:
gated_alternative_neg (the c8abbb3 shape) and its mirror spelling —
silencing only the observed arm order would have been fitting the guard to
one commit; sequential_rebind_pos red under mutation A (exclusivity clause
dropped); branches_replaced_pos red under mutation B (containment dropped);
both negs red under mutation C (guard removed). Restored: all four green.

Measured: rich 7→6, gone exactly `c8abbb3bd2`, extra zero; the other five
repos byte-identical block sets; sweep total 42→41 = 2.28%; tamper 48/80
and refactor 25/60 case-for-case unmoved. Adjudication rolls to
`adjudication-2026-08-26.json` (41 verdicts, the dropped block leaving the
population the same way v0.1.3–v0.1.5's did). Floor 1.50%→1.44%.

The honest residual is named where it lives: the guard reads branch
*structure*, not branch *truth*, so a tautological gate
(`if sys.version_info >= (3, 0):`) walks through it — THREATMODEL row 95,
open by design, priced at the level of the cheaper silences row 86a already
lists. D-049.

## 2026-08-25: #86a promoted — and the promotion audited its own premise first

The round that executed #36's promotion began by re-measuring it, and the
recorded premise failed twice:

- **STATE's "+4" was measured on the wrong engine.** Every stored promotion
  driver in the corpus scratch (`_promote86a*.py`) hard-codes
  `sys.path.insert(0, r"C:\Users\G713RW\greenwash\src")` — a v0.1.42 clone
  eighteen commits behind the shipping tree — and reads its `benchmarks/sweeps`
  as baseline; the editable install resolving to this tree is silently
  shadowed. On v0.1.43 the promotion costs **+5** (37→42, all rich, gone 0).
  The fifth, rich `7022e202245b`, was walked commit-by-commit across the
  eighteen: it starts blocking at **A6** — its only manifest edit is a blank
  line in `pyproject.toml`, exactly the no-dependency manifest change A6
  stopped crediting. Intended effect, not collateral; D-046 (first suspected
  via a stale `D-038` comment pointer in gating, now corrected) is exonerated
  by measurement — alignment 0 before and after, no leaf hit to adjudicate.
- **"A one-line `ORACLE_RULES` add" was false.** The detector emitted the
  tree's only sub-`warn` severity, so a credited finding would have sat below
  `fail_on="warn"` — silently contradicting SPEC §4's first sentence and
  D-002 — and gating carried a non-oracle credit branch whose comment
  promised the rule "stays info and outside ORACLE_RULES". Three edits, all
  in this round: membership, base `info`→`warn`, dead branch deleted.

Adjudication of the five new blocks (two blind raters each, distinct lenses,
1–1 splits reconciled, dissents preserved in
`benchmarks/adjudication-2026-08-25.json`): **five false, zero defensible.**
With exactly five new blocks the §A1 "more than five judged false" line
cannot arithmetically fail, so it is met but did not discriminate; the
promotion's incremental precision on honest history is **0/5**, published as
the price of making the definition-edit attack gate at all. THREATMODEL 86a
flips to **Partly closed v0.1.44** with the reproduced residuals in the row
(55.5% visible surface, module constants 29.2% blind, one-token
assertion-line evasions, closure poisoning, alpha/unit renames, purchasable
repair evidence). `ORACLE_RULES` — the set that decides what can block —
had no machine pin at all (`grep ORACLE_RULES tests/` was empty), which is
how SPEC drifted unwatched; `tests/test_oracle_rules_pinned.py` now freezes
membership, requires every member to exist, and forbids a member's §4 row
from claiming it cannot gate. Mutation-verified: pulling the membership line
turns exactly 11 fixtures red; reverting base severity alone turns exactly
the 4 negs red; pulling one member turns the pin test red.
`expectation_definition_repaired_neg` now pins its `REPAIR_EVIDENCE` credit —
unpinned, the first mutation passed on a broken promotion (10 red, not 11),
a verifier blind to its own object inside the check built to prevent that.

Gates: full suite green (466 tests; was 463 — the three pins above);
promoted sweep regenerated into benchmarks/sweeps (six repos, engine
0.1.44); arms/tamper/refactor corpora untouched by the rule change: the
detector fires identically, only its severity path moved. Residuals filed,
each its own round, none annexed here: the c8abbb3-shape binding-channel
length guard (the parametrize channel already excludes added-alternative
events; the binding channel is a bare `!=` on `\x1f`-joined keys), the
two-commit split (prod lands first, test catches up — no cross-commit
repair credit exists), and the module-constant blind bucket.

## 2026-08-19: B2 — THREATMODEL, SPEC and DECISIONS for the whole round

Frozen-zone package, maintainer-approved (D-046/D-047):

- **THREATMODEL**: rows 4, 15, 20, 21, 25, 35, 46 amended with the audit
  round's re-closures and their fixtures; row 86i (the unittest→bare
  modernisation false positive) flipped **Open → Closed v0.1.43**; new rows
  **93** (alpha-rename fingerprint evidence — open, narrowed) and **94**
  (root-import PACKAGE_REPAIR sibling — open by design, the httpx shape).
  FAILURES.md regenerated: 110 bypasses, 24 not closed.
- **SPEC §5 D7**: the frozen text said "landed ≥ PATTERN"; the code, the
  four pinning fixtures and row 13 all said EXACT_VALUE. The text was the
  odd one out and now states the implemented behaviour (D-047). No code
  change; the stale gating comment corrected in the same round.
- Nine fixtures gained `bypass:` pins so every re-closure claim is backed by
  the map `test_threatmodel_pinned` enforces.

Gates: 463 tests all green; arms/tamper/refactor corpora unchanged;
dogfood clean.

## 2026-08-19: B1 — a root import reaches every sibling, and that is not evidence

Frozen-zone change (gating.py), maintainer-approved, D-046. A root-level
import (`from app import billing`) reaches every module in the package at
alignment depth 1 — exactly as much as two unrelated siblings share — so the
leaf-name fallback in `_symbol_match` let `app.util::calculate` pay for a
weakened test of `app.billing.calculate` with one dead edit: bypass #35
reopened through its own closure (audit probe reproduced as verdict pass,
now block at high on the same scratch repo).

A leaf hit now needs ≥2 aligned components, or a dotted call whose first
component is the changed module's leaf (the honest root-import shape keeps
its credit). Full-qual matches, the `imports is None` fallback, PACKAGE_REPAIR
and the src-layout behaviour are unchanged — the audit's X4 shape
(root import + sibling symbol feeding package evidence) is the httpx case
PACKAGE_REPAIR exists for and is filed as a THREATMODEL row, not closed.
Residual: aliased root imports lose clause (b); visible at warn.

Gates: 463 tests all green (was 461); arms/tamper/refactor corpora
unchanged; dogfood clean. Fixtures: root_import_sibling_sameleaf_pos,
root_import_same_module_neg; FAILURES.md regenerated (row 35 carries both
new pins).

## 2026-08-19: A9 — anchors and warnings

- **The 180-day cap anchored at the ledger's own `created`.** A hand-edited
  base-side entry with `created = "2030-01-01"` / `expires = "2030-06-01"` —
  a 151-day window that does not even start for years — was honoured today
  (audit 2026-08-19, reproduced as `allowlisted=True` → verdict pass), which
  is precisely the hand-edited-ledger scenario bypass #39's read-side
  enforcement exists for. `_entry_state` is now the one implementation both
  consumers share (the doctor summary and the gate can never disagree), and
  the anchor is `min(created, today)`. Pinned by
  allowlist_future_created_pos alongside the existing over_cap fixture;
  FAILURES.md regenerated (row 39 now carries both pins).
- **Value-level config problems were silently ignored.** Only TOML *parse*
  failures produced a diagnostic; `on_engine_error = "Block"` (capital B),
  `fail_on = 5`, a non-list `roles` entry or an unknown role name all fell
  through to defaults with `config_errors: []` — and the on_engine_error
  typo reverts in the loosening direction. `load_config` now returns
  warnings for rejected values, threaded into stderr and `config_errors`
  (and the term report) but never fatal: the one value a warning can
  concern must not become the engine error it describes. Pinned by e2e
  test_config_value_warning_is_visible_not_fatal.

Gates: 461 tests all green (was 459); arms/tamper/refactor corpora
unchanged; dogfood clean.

## 2026-08-19: A8 — the two places git's answers were trusted unquoted

- **grep_head_paths** ran `git grep -l -F` without `-z`: with the default
  `core.quotepath`, every non-ASCII path came back C-quoted
  (`"tests/test_\346\213\267\350\262\235.py"`), failed the role filter
  downstream, and the duplicate-survivor search never found CJK-named
  copies — the D10 DUPLICATE_REMAINS credit was lost and an honest dedup
  deletion blocked at high. `-z` keeps the `rev:path` record shape,
  NUL-terminates it, and returns path bytes verbatim (format verified
  against the real binary before parsing). The same defence
  `diff --name-status -z` and `status --porcelain -z` already apply
  elsewhere; pinned by an e2e test with a real `tests/test_拷貝.py`.
- **read_blobs** writes one protocol request per spec
  (`{rev}:{path}\n`); a path containing a newline becomes two requests, and
  git's extra `<fragment> missing` response is consumed as the next spec's
  header — when the response count happens to realign, the loop completes
  with wrong assignments and no fallback: an existing file's blob reads as
  None and its weakenings vanish silently. Verified at protocol level with
  the real binary (Git-for-Windows refuses such paths outright, so the
  entry arrives in Linux-authored trees and then breaks Windows analyses of
  the same diff). Specs containing a newline are now rejected as missing
  before the request is built — the file stays visible as unreadable
  rather than poisoning its neighbours.

Gates: 459 tests all green (was 458); arms/tamper/refactor corpora
unchanged; dogfood clean. New e2e:
test_cjk_named_duplicate_survivor_gets_credit.

## 2026-08-19: A7 — no crash for two tokens, no claim without proof

- **sNaN.** `Decimal("sNaN")` constructs and raises InvalidOperation on
  *comparison*, which sat outside `_one_loosened`'s guarded constructors —
  `rel=1e-9` → `rel=sNaN` was an engine error (exit 2) for a two-token edit,
  a cheap denial of any verdict. Signaling NaNs now fall under the same
  "no guess, no noise" contract as unparseable literals (fixture:
  tolerance_snan_neg, zero findings, no crash).
- **One untrue message.** A cross-form polarity difference —
  `== 105.0` becoming `is not None` — was reported as "the test now proves
  the opposite", which it does not: the replacement is not the negation of
  the old assertion, and SPEC §4 forbids exactly that class of unearned
  claim. The message now says form and polarity both changed and equivalence
  cannot be verified; the verdict and severity path are untouched (the
  finding still blocks). Same-form inversions (`==` → `!=`) keep the
  proves-the-opposite wording, which is true for them.

Gates: 458 tests all green (was 457); arms/tamper/refactor corpora
unchanged; dogfood clean. The message change is unpinnable by .gwcase
(expectations match rule/severity, not prose) — this paragraph is the
record.

## 2026-08-19: A6 — a manifest edit that changes no dependency earns nothing

`_deps_differ` compared bytes after stripping own-`version =` lines, so a
comment appended to requirements.txt or a swap of pyproject.toml's
`name`/`version` lines — no dependency touched — granted D9
DEPENDENCY_DRIFT to an expectation rewrite riding along in the same diff
(audit 2026-08-19, both shapes reproduced as verdict pass; rows 57/84c
accept the credit only for "a real manifest change").

`parse_manifest_pins` (deps.py) extracts the `(distribution, pin)` set for
all four manifest families — PEP 621 arrays with optional-dependencies,
poetry tables including dict constraints, poetry/uv lock stanzas pairing
`name` with `version`, requirements lines with inline comments stripped —
and `_deps_differ` compares sets: reorder-invisible, comment-blind, real
specifier changes still differ. Neither side parsing to a single pin falls
back to the old byte comparison rather than declaring an exotic manifest
inert. Also removed: the second, identical `_deps_differ` definition that
had been living later in ci.py since the byte era (only the second one
executed; harmless but a divergent-edit hazard).

Gates: 457 tests all green (was 455); arms/tamper/refactor corpora
unchanged; dogfood clean. Fixtures: deps_comment_only_neg, deps_reorder_neg
(the pyproject shape additionally reports the expected CI_WORKFLOW_TOUCHED
warn — the file is ci-role whatever the edit).

## 2026-08-19: A5 — padding whose subject is a freshly bound literal

`data = [1, 2, 3]; assert data == [1, 2, 3]` — the subject is a bare Name,
so triviality called it state and the lattice called it EXACT_STRUCT(100):
full oracle mass. Deleting the failing test and adding that one line kept
verdict pass through D5 RESTRUCTURED (audit probe, reproduced twice). The
bare-dialect member of the padding family (rows 20/25/46); A1 closed the
unittest spelling, this closes the other.

`_vacuous_bound_asserts` marks `assert name == <literal>` when the same
statement list binds `name` to a structurally identical literal earlier and
**nothing between mentions the name** — `process(data); assert data == ...`
is a genuine oracle over `process` and keeps its mass (direction pinned by
the negative fixture). Outer bindings are invisible to inner blocks (fails
toward real). The pass runs once per unit; the 500-file perf budget holds.

Gates: 455 tests all green (was 453); arms/tamper/refactor corpora
unchanged; dogfood clean. Fixtures: bare_literal_bound_pad_pos,
bare_bound_then_used_neg. Residual: a binding reached through an if-branch
window or a comprehension is not tracked — stated, not chased.

## 2026-08-19: A4 — a cosmetic edit no longer changes a symbol's fingerprint

Repair evidence equated "the called symbol's AST changed" with "its
behaviour changed", and an attacker controls both sides of the diff. Four
one-line purchases of REPAIR_EVIDENCE for any oracle cheat, all reproduced
with the real CLI before the fix (THREATMODEL row 4 reopened): an added
return annotation, a non-leading string statement (docstring stripping only
reads body[0], and the strip happens first, which renumbered the noise to
the docstring slot — caught by the fixture on the second cut), a value-less
`x: int`, and a dead literal binding inside the function body.

`_normalize_for_fingerprint` runs on production parses only, after the
docstring strip: parameter/return annotations cleared (functions and
lambdas), every remaining string-constant statement dropped, value-less
annotated assignments dropped, and — inside function bodies only, with a
`global`/`nonlocal` guard, and only when a drop candidate exists — a
literal assignment to a name the function never reads. Module- and
class-level constants are untouched on purpose: `TAX = 0.05` in billing.py
is read by the test, and dropping it would deny honest repair evidence
(pinned by evidence_real_fix_still_counts_neg).

Deliberate residual: alpha-renames (`total` → `subtotal`) still flip the
fingerprint. Normalising them needs scope analysis greenwash does not have,
and a wrong normalisation silently disables evidence for genuine
rename-driven API changes. Row to be filed in the THREATMODEL round.

Gates: 453 tests all green (was 449); perf budgets hold (the dead-binding
check is lazy — one cheap pass unless a candidate exists); arms/tamper/
refactor corpora unchanged; dogfood clean. Fixtures:
evidence_annotation_neg, evidence_string_stmt_neg, evidence_dead_local_neg,
evidence_real_fix_still_counts_neg.

## 2026-08-19: A3 — the middle term of a chained comparison exists now

`assert 0 < score < 60` recorded the LEFT literal as the subject and the
last comparator as the whole expectation; the middle term — the actual
subject — was recorded nowhere, so rewriting the lower bound
(`0` → `-1000000`, the over-penalty bug now passes) moved only the subject
text and produced zero findings (audit 2026-08-19, reproduced with the real
CLI; the unchained spelling of the same edit blocked at high).

A chain with exactly one non-literal operand now records that operand as
the subject and the tuple of literal bounds as the expectation, compared by
canonical value — moving any single bound is an expectation rewrite
(EXPECTED_VALUE_CHANGED), and formatting is not a change (pinned by the
negative fixture). Strength stays BOUND via the first operator, as before.
Residual: a chain with two non-literal operands (`x < y < 60`) keeps the old
subject selection — its lower bound is still invisible.

Gates: 449 tests all green (was 447); arms/tamper/refactor corpora
unchanged; dogfood clean. Fixtures: chained_bound_rewrite_pos,
chained_reformat_neg.

## 2026-08-19: A2 — a tolerance that appears, and an expectation approx hides

Two silent-pass defects in the approx family, both from the 2026-08-19
external audit and reproduced with the real CLI before the fix:

- **The appearing tolerance.** diffalign compares epsilons only when both
  sides have one, so `pytest.approx(105.0)` → `pytest.approx(105.0, rel=0.5)`
  — five orders of magnitude of new slack over the implicit default — and
  the unittest spelling `assertAlmostEqual(x, 105.0)` →
  `assertAlmostEqual(x, 105.0, places=0)` produced nothing at all.
  `_approx_epsilon` now records pytest's implicit default (`rel=1e-06`,
  keyed form so the detector's per-kind parse agrees), and the unittest
  classifier records `places=7`. Every one-sided event became two-sided;
  tightening to the default reads equal and stays quiet (direction pinned
  by a negative fixture). The dead branch in tolerance_loosened ("a
  tolerance that did not exist before is new slack") is reachable through
  the multi-key path as before — the appearance itself is now the more
  precise signal.
- **The hidden expected literal.** The approx classification discarded
  left/right literals, so `approx(105.0)` → `approx(100.0)` — the row-15
  cheat wearing approx — was invisible to EXPECTED_VALUE_CHANGED (strength
  APPROX on both sides, nothing else to see). The approx argument is now
  recorded as the expected literal.

The `_approx_epsilon` docstring claimed the default-recording behaviour two
releases ago ("record it so approx(42) -> approx(7) is a value change, not
silence") while the code returned `(None, None)` — this round ships what the
comment promised.

Gates: 447 tests all green (was 443); recorded arms, tamper and refactor
corpora unchanged; dogfood clean. Fixtures: approx_tolerance_added_pos,
approx_expected_rewrite_pos, almost_places_added_pos,
approx_default_tightened_neg. Residual: a default recorded for `rel` only —
`abs`-only edits against the implicit 1e-12 are still one-sided in the
multi-key path, which classifies them as new slack (the fail-toward-flagging
side).

## 2026-08-19: A1 — the unittest classifier grows the bare path's twins

Four defects, one root: every consistency feature built on the bare-assert
path existed without its unittest twin, and the corpus contains zero
`self.assert*` assertions (THREATMODEL 86b), so nothing could surface the
divergence. Found by an external read-only audit (2026-08-19), every claim
reproduced with the real CLI before this fix:

- **literal-first TAUTOLOGY.** The self-comparison check read `seg(args[1])`
  against `seg(args[1])`, so every `assertEqual(expected, actual)` — the
  canonical unittest order — rated TAUTOLOGY(10) and the lattice was inert on
  it: `assertEqual(105.0, total)` weakened to `assertTrue(total)` produced
  zero findings. Now compares the post-flip subject against the post-flip
  expectation, identity ops stripped, same as bare.
- **None-family polarity.** assertIsNone sat in `_NEGATED_UNITTEST` while
  bare `is None` is positive, so a spelling conversion was reported as
  "the test now proves the opposite" and a genuine cross-dialect inversion
  did not fire. Polarity now follows the bare lattice, and
  `assertIs(x, None)`/`assertIsNot(x, None)` normalise to the dedicated
  spellings before classification.
- **trivial never computed.** `Assertion.trivial` defaulted False on the
  unittest path, so `self.assertEqual(str(1), "1")` counted as oracle mass
  and reopened the padding family (rows 20/25/46) in this dialect.
  `_Classified.trivial` now carries it from the classifier.
- **len() shape by operand order and dialect.** The len→TYPE_SHAPE rule read
  the pre-flip left operand and had no unittest twin, so
  `assertEqual(len(x), 2)` (90) → `assert len(x) == 2` (50) blocked a
  routine modernisation at high. The rule now reads the post-flip subject in
  both dialects.

Gates: 443 tests, all green (was 437); recorded arms, tamper and refactor
corpora unchanged — no existing fixture flipped; dogfood clean. New
fixtures: unittest_literal_first_pos, unittest_isnone_true_inversion_pos,
unittest_trivial_pad_pos, unittest_isnone_spelling_neg,
unittest_len_modernize_neg, bare_len_operand_flip_neg. Stated residual: the
`_is_unfalsifiable` enumerations (empty-needle membership, `len(x) >= 0`)
still have no unittest spelling — the audited defects are closed, the wider
enumeration parity is not annexed here.

## 2026-08-18: T1.11 — do not invert a literal membership needle

T1.10 swapped whenever the haystack was `result.output`. That is right
when both sides are names (`expected in result.output`). It is wrong
when the needle is already a literal: the classifier flipped, and
swapping again reports `result` after `invoke(main)` → `invoke(httpx.main)`.

Swap only if `right_literal` is absent and `right_depends_on` is
non-empty. Fixture `expectation_definition_literal_needle_neg` first.
T1.10 fixtures and the #86a pos case stay.

Hypothetical promotion on the same 6×300 pins: **37→41, +4, gone 0**.
httpx `78d381` / `933551` silent. Remaining extras are the four rich
commits (`1c5e03e`, `823de91`, `9303d77`, `c8abbb3`). That is the
§A1 handful. **#86a stays info** — promotion is a maintainer edit of
`ORACLE_RULES` / SPEC, still #36's gate.

## 2026-08-18: T1.10 — producer rewrites are not expectation edits

`EXPECTATION_DEFINITION_CHANGED` was naming the wrong local on test-only
setup diffs: `result` after `runner.invoke` moved, `C` after factory
kwargs moved, `auth` after `DigestAuth` → `httpx.DigestAuth`. The
assertion line was untouched and the needle / compared values had not
moved.

Two stated filters, fixtures first (#41):

- Membership whose haystack is an Attribute/Subscript (`result.output`)
  treats that side as the subject. `assert x in allowed` (bare Name)
  still fires when `allowed` changes.
- A moved binding that appears in the resolved subject-name closure is
  a shared producer, not an oracle. #86a pos fixture still fires.

Named extras re-checked: httpx `7985f68`, attrs `6e51cb7`, click
`efd4daf` / `bb2a1d9` go silent. rich goldens `823de91` / `9303d77` /
`c8abbb3` and the motivating `1c5e03e` still report. **#86a stays
info.** Promotion remains #36's gate.

## 2026-08-18: T1.9 remaining credit — PACKAGE_REPAIR marks this rule

Helper hop + D9 already shipped in v0.1.34. D-037 named a second
defensible credit: the existing PACKAGE_REPAIR shape (test imports a
package in which a *modified existing* symbol lives; not "any prod
file", not top-level-package equality). That mark now applies to
`EXPECTATION_DEFINITION_CHANGED` at info. The oracle-path
`package_only` / D9 tuples include the rule so promotion stays a
one-line `ORACLE_RULES` add. Fixtures written first from the httpx
URL-parser shape, not from the thirteen SHAs.

Hypothetical promotion on the same 6x300 windows: **37→45, +8**.
Previous T1.9 promotion was +13. Five of the six prod+test extras
are now credited (attrs `bde3f58`, click `029bbed` / `19fd4d6` /
`4e4c7a6`, rich `e9b0e19`). Remaining extras, all named:

- attrs `6e51cb7` — test-only `hash=` → `unsafe_hash=`
- click `efd4daf` — test-only parametrize expansion
- click `bb2a1d9` — test-only parametrize column reshape
- httpx `7985f68` — test-only `Response` → `httpx.Response`
- rich `1c5e03e` — the original motivating commit; helper calls
  `Console.print`, changed symbol is `Table._get_padding_width`
  (sibling module; T1.9 one-hop does not name it)
- rich `823de91` / `9303d77` / `c8abbb3` — test-only golden /
  3.13 repr updates

Eight is still past the §A1 handful (ΔFP ≤ 5). **#86a stays info,
outside `ORACLE_RULES`.** Threshold does not move. Issue #36 stays
the promotion gate.

## 2026-08-15 (v0.1.42): the downloadable CLI now carries its verdict

The release zipapp now propagates the CLI's process contract: clean is exit 0,
a blocking term/JSON/SARIF result is exit 1, and an input or engine error is
exit 2. The hook-JSON protocol deliberately remains exit 0 and carries its
block decision in JSON. The release workflow qualifies the built pyz across
all of those paths; the qualifier uses explicit failures rather than bare
assertions.

`greenwash doctor` no longer infers a load-bearing gate from workflow text. It
reports healthy only for the documented, unconditional pull-request workflow:
the exact checkout/setup/Greenwash commit pins, exact checkout inputs, literal
runner, three steps, a tracked regular workflow blob, and the `greenwash`
status context required by the shipped ruleset. Unsupported or ambiguous YAML
is incomplete and exits 1. Because a commit cannot contain its own SHA,
v0.1.42 deliberately trusts the already published v0.1.41 Action commit; that
pin advances one release later.

Terminal and hook-JSON finding counts now use the active `fail_on` threshold
and exclude allowlisted findings. These are delivery and diagnostic fixes, not
detector changes; the measured corpus and authority boundaries are unchanged.

## 2026-08-15 (v0.1.41): leftover user-path bugs

`greenwash chek` now errors (`unknown command`, hint `check`) instead of
being judged as a range. `action/README.md` no longer embeds a stale
SHA — copy the pin from the root README. Launch copy-paste install
lines point at this tag, not v0.1.12.

## 2026-08-15: required-check snippet was six releases behind

README's hash-pinned Action was still `v0.1.34` while install/pre-commit
said `v0.1.40`. `releases/latest` still pointed at the v0.1.39 pyz
because no GitHub Release was cut for the v0.1.40 tag. Snippet SHA is
now `70f1bb64` (v0.1.40); a packaging gate fails if it drifts from
the advertised tag again.

## 2026-08-15: T3.5 satellite is a note, not a package

`docs/satellite-execution.md` is the T3.5 acceptance: execution /
mutation stays off `check`. No sibling package was created. A test
fails if a `mutate`/`mutation`/`rerun` module appears under
`src/greenwash/`. **#86a stays info; #36 stays open.** ROADMAP
section 10 checkboxes now match the closed issues.

## 2026-08-15 (v0.1.40): T3.2 / T3.3 / T3.4 / T3.6

- **T3.2** `greenwash bench` reproduces what this checkout can
  (demo + decoy/tamper/refactor pins) and fails closed when the six
  sweep clones are missing. `--local` skips that requirement.
  `--run-sweep` re-runs the 1800-commit window only when every pin
  is present. Points at `benchmarks/README.md`. Exit 0/2, never 1.
- **T3.3** `benchmarks/compare/prepare.py` materializes arm-b / arm-a;
  `run.py` now exits 2 and names a missing path. COMPARISON.md keeps
  the 2026-07-31 numbers and the Python-only caveat.
- **T3.4** quarterly review in `docs/cheat-cadence.md`. FAILURES has
  a generated External credits table from
  `benchmarks/external-credits.json` (empty = none yet).
- **T3.6** `docs/process-windows.md`: single-diff tools miss
  multi-PR laundering (L0-C). Recommend `BASE...HEAD` plus optional
  sweep. No claim that the engine closed L0-C.
- **#86a stays info; #36 stays open.** T3.5 satellite not started.

## 2026-08-15 (v0.1.39): T2.2, T1.8, T3.1

- **T2.2** `comment-pr: true` on the Action posts a PR review comment
  per high finding. Engine stays offline. Missing write permission
  soft-fails. Caller needs `pull-requests: write`.
- **T1.8 / #54** `_mark_weakened_guards` now also compares *changed*
  guard text: discriminating → always-true fires `TEST_DISABLED`.
  Guard text is still not in the fingerprint, so allowlists survive
  an honest rewrite of a still-discriminating condition. No DECISIONS
  migration (identity unchanged). **#86a stays info; #36 stays open.**
- **T3.1** picked the JS/TS oracle front, not the monorepo opaque
  rewrite. `*.test.js` / `*.spec.ts` (etc.) are scanned for
  `test`/`it` + `expect().matcher()`. Matcher weakenings and
  `test.skip` reuse the existing detectors. Production `.js`/`.ts` is
  not parsed. The six-repo Python corpus cannot measure this; fixtures
  are the measurement. Written here because DECISIONS.md is
  maintainer-only.

## 2026-08-15 (v0.1.38): T2.7 diagnostic term lines

High findings print `why high:` (the escalator that actually fired) and
`no de-escalator applied` when none did. Next step stays the allow
instruction. Credits that did not fire are not listed — that would be
the COLLECTION_CONTROL_UNEXPLAINED class of claim.

## 2026-08-15: T2.5 / T2.6 CI hardness

Default `pytest` still runs `tests/gates/test_perf.py` (1.0s / 2.5s
budgets); `test_perf_gate_is_in_default_collection` fails if that file
or those names disappear, or if addopts grows `--ignore`/`-k`. CI and
release `uses:` are hash-pinned; checkouts set
`persist-credentials: false`. RELEASING.md states the pyz recipe is
source-reproducible, not bit-identical across CPython versions.

## 2026-08-15 (v0.1.37): T2.3 allow workflow, T2.4 machine contract

`docs/enterprise.md` is the one-page path: required check, SARIF, allow
(reason + 180-day cap, base-side commit), CODEOWNERS. `doctor` always
states the cap and counts active / expired / over-cap entries. Term
footer prints `allow_cap=180d`. `docs/stability.md` lists frozen
`--format json` keys and when `FINDINGS_VERSION` / `IR_VERSION` bump.

## 2026-08-15 (v0.1.36): T2.1 SARIF 2.1.0

`greenwash check --format sarif` emits a GitHub code-scanning subset:
version 2.1.0, rule ids are greenwash rule ids, severity maps
info→note / warn→warning / high|critical→error. Allowlisted findings
are omitted. No timestamps; two runs are byte-identical. Location
`startLine` is 1 until the IR carries a line — span offset is kept on
the region. Exit codes unchanged (SPEC §9). Not a native-findings
schema bump.

## 2026-08-15: T0.4 documented `gh` required-check command

README step 2 now has a reproducible command:
`gh api repos/OWNER/REPO/rulesets --method POST --input action/required-ruleset.json`.
The payload requires context `greenwash` (the job name in the snippet) on
`~DEFAULT_BRANCH` and does not replace other rulesets. Linked from
action/README and integrations.md. `doctor` still cannot see protection;
it names the same command. Bumped to v0.1.35 so tag-parity covers the
new `action/` files and the doctor pointer. T0 P0+P1 items are now all
landed.

## 2026-08-15: T0.2 Action snippet re-checked on zizmor 1.29.0

The README workflow already had `permissions: contents: read` and
`persist-credentials: false`. Those two highs from the pydantic
integration are gone. What remained under zizmor 1.29 blanket policy
was `unpinned-uses` on `@v4` and `@v0.1.34`. The documented snippet
is now hash-pinned (checkout v4.4.0, setup-python v5.6.0, greenwash
v0.1.34) and locally 0 high / 0 medium. `action/action.yml` is
unchanged: changing it without a new tag fails tag-parity.
`template-injection` on `${{ inputs.* }}` inside the composite `run`
block is the next release, not this snippet check.

## 2026-08-15 (v0.1.34): 1800-commit sweep, #86a not promoted

Same six windows as the committed v0.1.27 sweeps. At `info`, the
block set is unchanged: **37/1800**, no SHA added or removed. Opaque
24/1800. `EXPECTATION_DEFINITION_CHANGED` findings stayed info
(51 total; attrs 5→7, the others identical). T1.9's marks did not
move a verdict — they were not supposed to.

Hypothetical promotion (rule added to `ORACLE_RULES`, D9's
`dep_drift` tuple widened to include it, source otherwise untouched)
is **37→50, +13 extra blocks**. That is past the §A1 handful and past
the original +12 that kept the rule at `info`. Threshold does not
move because the credits exist.

| repo | info blocks | promoted | extra |
|---|---|---|---|
| attrs | 2 | 4 | +2 |
| click | 12 | 17 | +5 |
| flask | 7 | 7 | 0 |
| httpx | 12 | 13 | +1 |
| rich | 2 | 7 | +5 |
| starlette | 2 | 2 | 0 |

Of the two T1.9 motivating commits: starlette `100f05a66b` stays
unblocked (D9 fires). rich `1c5e03eb32` still escalates to high —
the helper hop does not credit that commit when the rule is an
oracle. The other twelve extras are listed on issue #36. #86a stays
visible and non-blocking.

## 2026-08-15 (v0.1.34): T1.9 credits, not a promotion

One hop of repair evidence through a same-file helper the unit invokes
(`FileIR.helper_calls`). TEST_DISABLED does not take that hop — a deleted
test plus a rewritten prod body is still the local-rewrite escort.
`EXPECTATION_DEFINITION_CHANGED` stays at `info` and outside `ORACLE_RULES`.
D9 / symbol repair can now *mark* it (`DEPENDENCY_DRIFT` / `REPAIR_EVIDENCE`)
without escalating. Fixtures written first. 1800-commit sweep and promotion
are not in this commit.

## 2026-08-15 (v0.1.33): E6 — same_expr for ASSERT_WEAKENED

`subject_changed` uses `ir.astutil.same_expr`, the same compare SUBSTITUTED
uses. Extra parens are not a subject change; wrapping the subject is.
MILD_WEAKENING follows the field. Fixtures: mild_weaken_reformat_neg,
mild_weaken_subject_changed_pos.

## 2026-08-15 (v0.1.32): E5 — engine/gating split

Zero-behavior extract. `roles.py`, `ci.py`, `evidence.py`, `compat.py`,
`change.py` hold the helpers; `engine.py` and `gating.py` orchestrate.
Public imports (`FileChange`, `analyze`, `apply_gates`) unchanged. No SPEC
policy change.

## 2026-08-15 (v0.1.31): E4 — unittest DERIVED + unpack/walrus

`_classify_unittest_call` fills left_names / right_names with the same
literal-side flip as bare assert. `_local_bindings` and `_binding_definitions`
record tuple/list unpacks and walrus names. Subscript/attribute/`for`/`with`
targets are still out (not local expectation bindings). THREATMODEL 86b/86g
rows stay for the human to close. Sweep has no unittest power (0 of 140,509).

## 2026-08-15 (v0.1.30): E3 — REGISTRY ⊆ RULE_ORDER

Added TEST_FILE_UNPARSEABLE, CONFTEST_PATCHES_PROD, TEST_PATCHES_SUBJECT to
RULE_ORDER. Sort rank only; verdicts unchanged. Test fails if a registry
rule is missing from the order.

## 2026-08-15 (v0.1.29): E2 — TEST_DISABLED shape

`test_disabled` writes `Finding.shape`. `_prod_removal_shape` reads that
field only. Message text can change without breaking PROD_SYMBOL_REMOVED.
Zero detector/fixture expectation change.

## 2026-08-15 (v0.1.28): E1 — one dotted_name

Zero-behavior extract. `frontend._dotted` and `gating._dotted_name` were the
same Name/Attribute walk; both now alias `ir.astutil.dotted_name`.
`expr_wraps` / `same_expr` were already shared (review 2026-08-11 Issue 7).
No detector, gate, or fixture expectation changed.

## 2026-08-13 (v0.1.27): A5-x — the two cross-file channels the corpora actually contain

Import channel (`from helpers import f`, same-directory sibling, parsed from
change bytes so loop order cannot matter) and fixture channel (requested by
parameter name, same file or same-dir conftest; autouse only from a touched
conftest; **a fixture nobody requests contributes nothing**, which is what
newly blocks the drop-the-autouse attack, tamper 040).

Numbers: attacks **48/80** (arm 1 hits 20/40), refactor FPs **25/60**. Six
pre-registered predictions: five held, CASE_019 falsified and kept as
falsified — its teardown assert turns out to be membership-for-equality, the
lattice-weaker family 92 keeps deliberately. One line corrected by the
disguised arm itself: the EXACT_STRUCT→EXACT_VALUE extraction decline must
require a **bare** `== expected` (the wide version excused `sorted(expected)`
and three attacks walked through; reverted the same hour).

The sweep moved for the first time since v0.1.15: **36 → 37**, one new block,
flask `c2705ffd` ("merge app and request context") — an equivalent-rewrite
false positive the fixture channel made visible, single-adjudicated and
marked in the file, ΔFP 1 of the budgeted 5. Its first form was worse: one
conftest edit fanned out to twenty-four findings before inherited-pair deltas
were deduped to one per origin. D-045.

## 2026-08-13 (v0.1.26): reachable assertions — both numbers moved together

The A5 round (#37). `UnitSide.assertions` stops meaning *the `assert`
statements written inside this function* and starts meaning **the assertions
this unit executes**: its own, minus those in nested scopes nothing invokes,
plus those of same-file helpers it actually calls — where *calls* means
invocation, not mention (`callable(assert_sum)` names the oracle without
running it), and construction is not invocation (`partial` binds; a
`@contextmanager` runs only under `with`).

Four corpora, one table:

| | v0.1.25 | v0.1.26 |
|---|---|---|
| informed attacks blocked (arm 1) | 12/40 | **19/40** |
| disguised-extraction attacks blocked (arm 2, new) | — | **28/40** |
| honest refactors falsely blocked (arm 1) | 20/30 | **17/30** |
| faithful extractions falsely blocked (arm 2, new) | — | 16/30 |

The acceptance test was that both sides move together, and they did. The
disguised arm is the important control: `ASSERT_SUBSTITUTED` now declines any
pair that crosses the unit-body boundary (extraction moves the *slot*, not the
assertion), and the arm proves that declining gives nothing away — the
weakening extractions still block as `ASSERT_WEAKENED`, 25 of the 28.

The measured residue is named, not averaged: cross-file helpers (bounded,
next), unit-identity changes (THREATMODEL 92's other half), semantic
subversion and computed zero-runs (execution-only — THREATMODEL 91a, where
every remaining escape now lives), and one refused trade — a shared assertion
that is lattice-weaker than the concrete ones it replaced stays a finding,
because that identical transition is what catches the disguised arm.

Three of my own numbers were corrected by measurement on the way (the P2
ranking, "12–16", then "10" — issue #37 carries all three), which is the
round's second lesson: every estimate this project has published without a
harness behind it has been wrong.

## 2026-08-13: 20 of 30 honest refactors are blocked — and 1.17% never said so

A second corpus, built to target one shape the sweep corpus almost never
performs: **moving where a test's assertions live.** Extract a check into a
helper, merge two tests, push the oracle into a fixture's teardown, swap `==`
for `pytest.approx`.

Every case ships production **twice**, correct and buggy, and four pytest runs
must agree that both the before and after suites still catch the bug. Only then
is greenwash asked. A block is therefore a false positive by construction —
nothing to adjudicate, nothing to argue about.

**greenwash blocks 20 of 30.**

The published false-positive rate is 21/1800 = 1.17%. That number is honest
about what it measured and it does not predict this, because those six
libraries rarely restructure test helpers — the identical zero-power trap that
nearly shipped `TEST_PATCHES_SUBJECT` on a meaningless zero the same day. Two
corpora, two questions, and neither substitutes for the other.

**And it is the same defect as the escapes below, seen from the other side.**
`ASSERT_REMOVED` fires on 8 of them because the assertion moved somewhere the IR
does not follow; 28 of 40 attacks get through for exactly that reason. A5 is
therefore not a recall change that risks precision — it is the shared cause of
both numbers, and `benchmarks/refactors/` is what will say whether fixing it is
a net improvement. THREATMODEL 92.

## 2026-08-13: 12 of 40 — the informed arm

An overnight informed-adversarial run produced 40 tampering cases against a
description of every rule in this tool. Each was verified mechanically before
being counted: production byte-identical on both sides, `pytest` red on the
before side and green on the after side. **greenwash blocks twelve. Twenty-eight
escape.**

They are one root cause. The IR knows an oracle only when it is a syntactic
`assert`, a curated unittest method, or a `pytest.raises`. `assert_sum(add(2, 3), 5)`
is a **call** — the unit records zero assertions — so stopping the call removes
nothing, weakens nothing, and a replacement `assert callable(assert_sum)`
registers as an assertion *added*. By the strength lattice the test got
stronger.

This is `docs/defence-design.md` **A5**, ranked there as **P2, "partial by
nature"**. That ranking was wrong, and it was wrong on the basis of no
measurement. It is the top of the next round.

Read `benchmarks/tamper/README.md` for the families and the caveats — chiefly
that 12/40 bounds an attacker who has read the rules, not ordinary agent
behaviour, where 0 of 12 real agents touched a test at all. Both numbers are
now in the README; neither replaces the other. THREATMODEL 91.

## 2026-08-13 (v0.1.25): the corpus could not test this rule, and said so

T1.4 / THREATMODEL 90 — patching the code under test **from inside the test**,
which `CONFTEST_PATCHES_PROD` never saw because it reads conftest files only.
Ranked #2 of the attacks left open after P0.

The number to not misread: the sweep moved **36 → 36** blocks, and
`TEST_PATCHES_SUBJECT` fired **zero** times on 1800 commits. A ΔFP of zero for a
rule that never ran is not a false-positive measurement, and shipping it as one
would have been this project's own recurring defect — a check that cannot see
its subject reporting success — for the fifth time in three days.

What the instrumented run *did* measure, and what this ships on:

| across the same 1800 commits | |
|---|---|
| unit-sides carrying a patch | 735 |
| …in a unit the diff created | 38 |
| newly added patches in a unit that already existed | **1** (denied at the hygiene filter) |

Humans write the mock together with the test. The precondition's base rate
bounds the blast radius at 0.06pp — twenty times inside the 0.3pp the roadmap
fixed in advance — and the pre-registered severity decision is honoured against
that, not against an FP count this corpus cannot produce.

Same probe caught the rule's own hole before release: `result = f(x)` /
`assert result == 105.3` hides the patched attribute from the assertion, and is
the *more* natural way to write the attack. Reach resolves one hop now.

Two claim-drift defects fixed on the way: five `.gwcase` fixtures had lost all
their metadata to a BOM while still passing, and SPEC §4 — the file that calls
itself frozen — had twenty rows under the sentence "All fourteen are live".
Both now have gates. D-043.

## The 2026-08-07 sixth round (v0.1.13): fixing what the field found

`docs/integrations.md` listed eleven defects and fixed none — fixing them
inside the commit that reports them is how a report stops being trustworthy.
This round fixes four, each reproduced by hand before anything was designed.

**E6 was a one-sided scan and it blocked the ecosystem's most ordinary
commit.** Deleting `setup.cfg` and adding `pyproject.toml` with a
byte-identical `testpaths` reported "test command weakened" at **high** — and
so did configuring pytest for the first time in a repository that had none.
Every line of a newly added file is an added line, and the scan had no view of
the base side at all. The fix is a distinction the token list never made: a
**swallow** discards an exit code and introducing one anywhere is a weakening;
a **narrowing** restricts which tests run, and restating one narrows nothing.
Narrowings now count only when the diff introduces them — absent from the
base-side ci surface, in a file that existed. Residual, stated rather than
hidden: a migration that also narrows, in one commit, is warn instead of high.

**Creating a guardrail file is not relaxing one.** Running `greenwash hook
install --agent claude-code` and committing the result produced a **critical**
block on greenwash's own installer output. Created guardrail files are warn;
relaxing one that existed stays critical.

**The remediation printed on every finding did not work as printed.** Run
`greenwash allow`, re-run check, get the identical block — because the
allowlist is read base-side so an agent cannot exempt itself mid-diff. Right
design, half a sentence. It now says the file has to be committed. Evidence
lines are bounded at 160 characters in the same change; `SUPPRESSION_ADDED` on
a generated module printed a 1400-character regex twice.

**A perf gate that goes through git.** The old gate calls `analyze()` with
in-memory changes, so it never saw that a range diff spawned two `git show`
processes per modified file — 241 subprocesses and 9.1 s on one pydantic
commit, 58% of wall clock. Blobs are read in one `git cat-file --batch` now.
A 120-file commit went **15.81 s → 5.91 s**, 244 git processes → 11; a 34-file
commit 3.68 s → 2.17 s. Sixty consecutive jinja commits produce byte-identical
JSON under both readers, so this is I/O, not judgement.

The new gate was checked the only way a gate is worth anything: it fails on
the old code, at "601 git processes for 300 changed files". The first version
of that check passed on both, because a src-layout editable install quietly
resolved the old worktree's import to the new code. Green because it did not
run is the failure this project keeps repeating, and this time it was caught
before it was written down rather than after.

`sweep` also now states in its own output that it excludes merge commits —
on jinja, the merge of a blocked PR blocked identically and never appeared in
the sweep, so one defect was counted once where a merge gate hits it twice.

**Corpus: 35 blocked before, the same 35 after, in all six repositories, with
zero finding deltas.** This is also the first *full* sweep since v0.1.10 — the
committed JSONs were stamped 0.1.10, because v0.1.11 and v0.1.12 shipped on
targeted checks and a bounding argument rather than fifteen minutes of
sweeping. That argument is now measured and it held exactly: opaque exemptions
fell 32 → 25 (1.39%), the seven that v0.1.12's row 78/79/80 tightenings should
have removed, **and not one verdict moved** — which is what "disabling the
exemption entirely moves the block set by zero, so no subset can cost more"
predicted. A bound that turns out to be tight is worth more than a bound that
was never checked.

## v0.1.16 — a file that runs the tests is not unreadable production code

The maintainer supplied an informed-adversary report against v0.1.15. Eight of
its ten items were already recorded here; what it added was a taxonomy —
*leave the visible oracle, buy `warn`, hit an identity or enumeration
boundary* — which is adopted in `docs/defence-design.md` because it predicts
where the next hole will be. The report is vendored verbatim under
`docs/redteam/`.

Its section 6 was tested rather than believed. Eleven cases, each weakening a
real assertion **and** the test runner with no production change. **Four
passed**: `common.mak`, `Makefile.include`, `Justfile`, `ci/justfile`.

The report rates that P2. It is P0, and the reason is the part neither the
report nor the previous rounds had measured: an unrecognised runner file is
not merely invisible. It is classified `prod`, cannot be parsed, sets
`prod_opaque_change`, and the `ASSERT_WEAKENED` beside it drops from high to
warn. **The file whose entire purpose is running the tests bought the
exemption meant for production code greenwash cannot read** — an unrecognised
runner filename was strictly better for an attacker than a recognised one.

Fixed in two layers, and the second is the one that matters. Widening the
shape list (`.mak`, `Makefile*` prefixes, every justfile spelling — the role
globs use `fnmatchcase` on purpose, so case variants are listed rather than
folded) closes the four measured spellings and will always be four spellings
behind the ecosystem. So: **a changed file whose own content invokes a test
runner no longer grants the opaque exemption at all**, whatever it is called.
No shape check, so it does not inherit the enumeration it exists to backstop.
A Makefile that builds a C extension has no runner token, stays production and
keeps its full repair-evidence weight; two negative fixtures pin that.

`.ps1`/`.bat`/`.cmd` were already reclassified to `ci`, so they bought nothing
— but the token table was shell/YAML-shaped and their weakening was simply
invisible. Suffix-keyed swallow tokens now cover them, plus two-sided checks
for the dialects with no `set -e`: `$LASTEXITCODE` and `errorlevel` no longer
inspected. Those two are the robust half, because they do not depend on
spotting an added token. `|| echo`, `|| printf`, `; true` and
`if ! CMD; then :; fi` join the sh table.

All eleven cases block. Corpus: **36 → 36 blocks, no verdict moved in either
direction**, zero engine errors, and the opaque exemption fell 25 → 24 — one
commit lost a blanket it did not need, which is the same result every opaque
narrowing has produced here and for the same reason: on six pure-Python
repositories the blanket is granted often and load-bearing never. Recall
unchanged across every arm.

## 2026-08-09 — verifying v0.1.14, and finding it closes less than it says

v0.1.14 was released and then put through an adversarial verification pass:
seven independent read-only probes, each required to reproduce with the real
CLI, each finding then handed to a separate agent whose job was to *refute* it.
32 candidate findings, 23 surviving refutation, 8 rejected. Two probes did not
complete (a verifier and the completeness critic hit a quota limit), so **this
list is not known to be exhaustive** — the "what did we not test" question has
no answer yet.

Three results matter more than the count.

**The classifier refactor was clean.** The extraction of the comparison-operator
chain into `_classify_compare_op` was the change most likely to have broken
something silently — the first attempt at it was mangled and reverted. A
differential test over the corpus's test files, running v0.1.13 and v0.1.14
side by side under isolated `PYTHONPATH`, found **no divergence** in form,
strength, subject, expectation, tolerance or polarity. Determinism and the
zero-dependency claim also survived, and fingerprint stability held across 240
real commits, so recorded allowlist entries still match.

**`ASSERT_SUBSTITUTED` closes less than v0.1.14 claimed.** Move the compared
values into locals and the same attack passes: `right_literal` and
`right_value` are `None` for every non-literal expectation, so the rule's "both
halves must have moved" test reads `None == None` and skips. Had the
2026-08-08 incident diff bound `0` to a local first, v0.1.14 would have passed
it too. Row 84b is downgraded to *partly closed*; row 86c has the shape. The
published release notes were amended rather than quietly corrected.

**And a blind spot older and larger than anything v0.1.14 fixed.** A
`unittest.TestCase` subclass not named `Test*` — `class BillingTests(...)` — is
collected and run by pytest but produces **zero IR units**, so all 19 detectors
are inert on it. `assertEqual(total, 105.0)` becoming `assertTrue(total > 0)`
passes clean. SPEC §2 stated that pytest never collects such classes; that is
false, and the implementation was built on it. Row 86.

Two of the project's own ledgers were also blind to their newest entries:
`benchmarks/FAILURES.md` and the "every Closed row is pinned" gate both parsed
row numbers with `isdigit()`, which silently dropped every lettered row —
including 84a and 84b, the two rows v0.1.14 exists for. Fixing the parser
immediately proved the second point: neither row had a fixture pinning it at
all. A ledger that quietly excludes rows is worse than no ledger.

The full list of 23 is in THREATMODEL rows 86–86i plus the rows already there;
what got fixed in this round is below.

## v0.1.14 — closing the escape, and finding out the first fix was the wrong one

The round started from the finding at the end of the previous section: an
assertion replaced by a different one of equal strength, greenwash silent.
It produced two rules, and the gap between them is the part worth keeping.

`EXPECTED_VALUE_DERIVED` came first, built from the six-line reduction. It
fires when an expectation stops being a literal and starts resolving —
through the unit's own assignments — to a name the subject also uses.
`expected = sum(items)` against `invoice_total(items, 0.05)` shares `items`,
so the test is computing the answer from the data it feeds the code. A
literal replaced by a *named constant*, or moved into a `parametrize` case,
shares nothing and stays quiet. That distinction is the entire rule; without
it the shape is indistinguishable from an ordinary cleanup.

**Then it was run against the actual incident diff and did not fire.** The
reduction had simplified away the thing that made the original invisible: in
the real diff the subject changed too, and `EXPECTED_VALUE_DERIVED`
deliberately defers a changed subject to `SUBJECT_NORMALIZED`, which requires
containment and declines. Closing a threat-model row against a reduction and
never re-checking the original would have shipped a rule that closed nothing.

The real mechanism turned out to be in alignment, not in any detector.
Assertions pair in three stages — identical text, then (form, subject), then
**span order** for the leftovers. The fallback paired
`assert exists.returncode == 0` with `assert pinned == {tag}` because both
were leftovers of compatible strength, and the delta reported
`strength_change: 0` with an empty `assertions_removed`. An assertion was
deleted and the IR said nothing changed; every oracle rule read that and
correctly declined. `ASSERT_SUBSTITUTED` is the first rule keyed on *how a
pair was formed* rather than on what it contains — `AssertionPair` now records
whether it came from the guess.

The fallback stage stays. It carries its own scar (pairing a classifiable
assertion with an unclassifiable one used to suppress `ASSERT_REMOVED`
outright) and it is right often enough to keep. It is simply a guess, and now
it is labelled as one.

Four false positives were caught before release, none of them by review.

The existing `raises_match_fold_neg` fixture went red immediately: folding an
excinfo substring assert into `pytest.raises(match=)` has no subject on the
`match=` side, and blocking a *preserved* oracle at high was the new rule's
first mistake. Both sides must carry a subject now.

The corpus found the rest. flask's two `bump werkzeug 2.3.7` commits rewrote
`rv.data == b"127.0.0.1"` into `flask.g.remote_addr == "127.0.0.1"` because
the dependency's API moved under them; D9 `DEPENDENCY_DRIFT` credited only the
rewritten literal, so the same edit was warn under one rule and high under the
other, and D9 now covers both (row 84c).

Then the full sweep moved exactly two verdicts, both new blocks, both false
positives, and they turned out to be the same one. attrs `31e02869da` put an
expected message behind a `sys.version_info` branch; click `0480a56579`
parametrized `assert "FOO:[42.0]" in result.output` into six cases. In each an
expected **literal** became a non-literal — and that is what decides which
side is the subject, because `assert 3 == calc()` puts the expectation on the
left. The two sides swapped roles, and a rule looking for "both halves
changed" found both halves changed. The guard is that the new expectation
depends on a name from the old subject; residual as row 84d, deliberately
loose in the attacker's favour rather than blocking every compat gate in the
ecosystem.

**And the D9 widening was still too cheap, which the same check caught.** With
`ASSERT_SUBSTITUTED` credited by `DEPENDENCY_DRIFT`, the incident diff that
motivated this whole round dropped from high to warn — it bumps
`version = "0.1.13"` in `pyproject.toml`, and the manifest signal was true for
*any* edit to a manifest. Nearly every release commit contains one. A project's
own version declaration is not a dependency, so it is now dropped from the
comparison, and a fixture pins it (D-034). The lesson is cheap to state and
was not cheap to find: **the regression check for a round is the thing that
motivated the round**, re-run after every change, not once at the end.

Verification: the incident diff that v0.1.13 passed blocks at high on this
build, naming the substitution. All recorded arms replay unchanged — classic
12/12 blocked and 0/12 false blocks, probe waves 6/6 and 2/2 with 0 false
blocks, informed arm 2 blocked and 1 out-of-scope pass.

**Corpus cost: 35 blocks → 35 blocks. No verdict moved in either direction**,
opaque exemption unchanged at 25/1800, zero engine errors. What did change is
the finding count on commits that were already blocked: `ASSERT_SUBSTITUTED`
contributes 4 warns on flask, 1 on attrs, and 28 high plus 5 warn on httpx.

Those 28 deserve naming rather than hiding behind an unchanged block rate.
They land on three httpx commits that were **already blocked and already
adjudicated false positives** — the "drop private imports, rewrite the tests
onto the public API" cluster that dominates httpx's FP list. So the rule costs
nothing in verdicts, and it is at the same time most likely to fire on exactly
the family that already produces this corpus's false positives. That is a
property worth watching, not a result to celebrate.

`EXPECTED_VALUE_DERIVED` fires **zero times across all 1800 commits** — the
same profile `SUBJECT_NORMALIZED` had when it shipped. It closes a shape the
informed arm produced and human history does not contain.

## Concurrent agents, 2026-08-08 — and a gate that got quieter

Another agent pushed to `main` while this release was being prepared: a README
restructure, a version bump to the same 0.1.13, a `closure/` branch and two
release-candidate documents. The merge kept their work — the above-the-fold
rewrite is what ships, and their fix to the dogfood-job check (split on the
next top-level key rather than a hardcoded job name) is a real improvement.

One change was reverted. `test_pinned_tag_ships_the_current_source` had gained
a pre-tag escape hatch: when the advertised tag does not exist, check
something weaker and *return*. Its own assertion message says why that is not
allowed — "bumping the version used to make this gate return early and pass,
which is the same 'green because it did not run' failure the gate exists to
prevent". The circularity is an ordering property, not a gate property, so
`docs/RELEASING.md` now writes the order down: bump, commit, **tag**, verify,
push. See D-031.

**greenwash passed that diff**, and that is the part worth carrying forward.
Two `CI_WORKFLOW_TOUCHED` warns and nothing else — the gate weakening produced
no finding of any severity. The removed assertion was *paired* with the added
one; both are `EXACT_VALUE`, so the lattice saw no weakening;
`EXPECTED_VALUE_CHANGED` needs both expected sides to be literals and the new
one is not; `SUBJECT_NORMALIZED` needs containment and this replaced the
subject outright. Reduced to six lines, the shape takes a suite from
`1 failed` to `1 passed` with the expectation rewritten as an inline copy of
the bug, and greenwash says *no known tampering pattern detected*.

That is THREATMODEL row 84's third shape, found by the informed arm on
2026-08-07 and published open, arriving unprompted in this repository's own
gate file the next day. It is row 84a, and it is the first item of the next
round.

## The 2026-08-07 fifth round (v0.1.12): closing the audit, with two designs rejected

The v0.1.11 audit left ten bypasses open. Five are closed here; the rest are
open on purpose, and two proposed fixes were designed, adversarially reviewed
and **thrown away** — which is the part of this round worth reading.

**Closed, each reproduced by hand first.** Row 82: a `conftest.py` absent at
base was never inspected at all — one new file with `collect_ignore =
["test_billing.py"]` took a suite from `1 failed` to `no tests ran` with zero
findings of any severity. Added units carry no delta and TEST_DISABLED needs
one. Scoped to conftest, because a brand-new *test* file born
`@pytest.mark.xfail` is a bug repro and must stay silent — measured, not
assumed. Rows 78, 79, 80: the opaque exemption now needs a *modification of
pre-existing production* — not a deletion, not a path this diff invented by
renaming a doc onto it, and not opacity this diff manufactured by breaking a
file's syntax. Row 76, partly: `set -o errexit` is errexit.

**And the second shipped false positive.** That last one was not only a
bypass. Moving errexit from the shebang to the long form — `#!/bin/sh -e`
becoming `set -o errexit`, a change that makes a script *stricter* — was
blocking at high with the message "a failing command no longer fails the
script", over a script measured still exiting 1 on a failing test. v0.1.7
passes the same diff. Refusing to read a spelling is not the same as that
spelling being absent, and printing the second when you mean the first is a
false statement in a blocking message. That is two shipped false positives
found by adversarial review in one day, both stated in the tool's own voice.

**Two designs rejected after review**, and this is the useful half. A bounded
shell parser (statement lexing, errexit tracing, five weakening classes) was
designed and killed: its decline set is attacker-chosen and published, so one
`eval ""` disarms every rule in it, and it created three reproduced false
positives on the way. A data-file repair credit with base-side reads was
killed as unimplementable as specified. A third design's fix for row 75 was
overridden twice — the author's version created a second role source that
would have let the SPEC role table drift from `role_of` while its pin still
passed, and the skeptic's version made `docs/CLAUDE.md` guardrail-critical.
What shipped instead is a three-name glob for what `just` itself documents.

**Corpus cost: nothing, and provably.** The opaque tightenings are bounded by
today's earlier experiment — disabling that exemption *entirely* moved the
block set by zero commits, so no subset of it can cost more. Zero corpus
commits add a conftest; zero use long-form errexit; zero use the runner
filenames added. Every check is targeted rather than a fifteen-minute sweep,
and each is named in D-029.

**Still open, deliberately**: rows 75 and 77 (filename and shell-dialect
enumerations, honestly labelled as such), the rest of 76, 81, 83 and 84, and
a false positive older than any of them — pytest's own documented `--runslow`
recipe blocks at high, on v0.1.8 as well as today. The discriminator exists
(the recipe *marks* items so the run reports skips; the cheat *removes* them
so it reports nothing) but needs the hook's body in the IR.

## The 2026-08-07 fourth round (v0.1.11): audited, and one of the findings is ours

Three releases shipped today, so an adversarial audit was pointed at *those
three only*, every claim required to be reproduced with the real CLI. It came
back with **ten bypasses and four false positives, all reproduced** — rows
75-84 and D-028. Start with the one that is a regression this project shipped
this afternoon.

**greenwash was blocking an honest pull request.** Closing row 70 made
`collect_ignore.append(...)` visible for the first time; row 72 then stopped
repair evidence excusing a collection control; D6's compat-token filter
recognises interpreter and OS gates and nothing else. Together they blocked a
PR that **adds** a backend, **adds its own tests**, and gates them on
`find_spec("redis")` — net tests disabled zero — while printing
`NO_PROD_CHANGE_IN_DIFF` over a diff that changed three production files.
v0.1.8 passes the same diff with no findings, so the regression is dated and
owned. Fixed two ways: a collection control refuses repair evidence only when
it is **unguarded**, and the compat-token filter is skipped for
`collect_ignore` specifically, because for a suite-level control the guard is
the justification rather than an excuse. The probe-arm escape is unguarded
and still blocks. The escalator now says `COLLECTION_CONTROL_UNEXPLAINED`
when evidence exists and is deliberately refused, because the old wording was
a false sentence in a blocking message.

**The opaque blanket is granted 32 times and load-bearing zero times.** The
corpus was re-swept with THREATMODEL #4's exemption disabled outright:
**35 blocked before, 35 after, in all six repositories.** Not one of 1800
human commits passes because greenwash cannot read a file. That is not
permission to delete it — six pure-Python projects are exactly where it would
not do work, and a C extension or a template engine is where it would — but
the number this file has called its largest hole is an *incidence*, and its
load-bearing share on the only evidence anyone has is zero.

**Ten bypasses are open and not being smoothed over**, including three more
ways to manufacture an "already production" unreadable change (78-80) and the
two identity gaps that make row 71 a fix for the new-marker case only
(81-82). The project's own review found none of them.

## The 2026-08-07 third round (v0.1.10): SUBJECT_NORMALIZED

v0.1.9 published row 74 open, because closing it needed a detector and
half-building one inside a correction round is how the mistake before it
happened. This round builds it.

The escape, from the informed arm's `percent_encode`:

    assert encode_path("café") == "caf%C3%A9"
    assert encode_path("café").replace("%e9", "%C3%A9") == "caf%C3%A9"

The expected literal is untouched, the form is still an exact comparison and
the strength lattice reads the same `EXACT_VALUE` on both sides — so
`EXPECTED_VALUE_CHANGED` stays quiet, `ASSERT_WEAKENED` stays quiet, and the
oracle is gone anyway, because the wrong answer is laundered on its way to the
comparison.

`SUBJECT_NORMALIZED` fires when an aligned assertion keeps its form, strength
**and** expected value while the asserted subject gains a wrapper *around its
old self*. Structural containment, compared on the parsed expression, so
spelling and spacing are irrelevant; a subject replaced outright is a
different test rather than a laundered one and earns nothing. Base severity
warn, escalating through repair evidence like every other oracle rule —
because wrapping the subject is completely routine when production changed
under it (`sorted(...)` the day a function stops guaranteeing order,
`.strip()` the day it stops trimming). What it reports is not "this is a
cheat" but "the thing under test was transformed and nothing in the diff says
why".

## The 2026-08-07 second round (v0.1.9): the correction, and the arm that reads the source

**Start with the correction, because the rest of the round came out of it.**
v0.1.8 shipped a sentence in THREATMODEL row 68 and four other files saying
the obvious narrowing "was checked against the corpus and would have blocked
attrs bb45938ab9". It was not checked against the corpus. bb45938ab9 sits
outside the swept window and has no parent in the corpus clone, so greenwash
has never analysed it and could not. It came out of a path-filtered
`git log -300 <pin> -- <path>`, where the limit applies after path filtering
and reaches back past the sweep boundary — the same mistake made twice in one
round, since it also produced a phantom "httpx touches its runner script"
result. Corpus membership is checked against the real rev-list window now.

Chasing the wrong citation closed three bypasses (D-026):

- **Row 70.** The in-corpus commit of that shape is attrs 61e8179545, and
  checking it properly showed greenwash reported *no collection-control
  finding at all*: only `collect_ignore = [...]` was recorded, so the
  idiomatic spelling — initialise empty, then `extend`, which is what attrs
  writes — was invisible. One unguarded line dropped a whole test file from
  collection and produced nothing. Every statement that puts a path into
  `collect_ignore` counts now, an empty initialiser does not, and each
  carries its enclosing `if` for D6 to evaluate.
- **Row 71.** The laundering route that fix had to be built against: markers
  deduplicate by name, so one honest version gate could have covered any
  number of unconditional drops. The recorded guard is the weakest of them.
- **Row 72.** With 70 closed, the narrowing v0.1.8 rejected could be
  evaluated, and it survives: a production change never makes it correct to
  stop *collecting* tests, so repair evidence no longer explains a
  suite-level collection control. A compatibility gate still does — which is
  exactly what keeps attrs 61e8179545 at warn. The rejected fix was right,
  and it had been rejected on a citation that did not hold.

**The informed arm ran for the first time**, and it is the honest condition
for a public tool: the agent got the complete source, spec, decision log and
threat model, and could run `greenwash check` against its own diff until it
passed. Conditions before the score — **three of six tasks were refused by
the agent provider's safety filter**, so the sample is three. All three
reached a green suite past v0.1.8.

- `rounding` rewrote production to use banker's rounding and never touched a
  test. Not a bypass: THREATMODEL #1, out of scope by design. Also the
  cheapest route an informed adversary has, and worth saying out loud.
- `retry_count` read the opaque-change branch in `engine.py` and wrote a
  three-line `retry_policy.json` that nothing imports, purely to be
  unreadable, escorting two rewritten expectations. **Row 73, closed**: the
  exemption now needs a change to something that was already production.
- `percent_encode` normalised the *subject* instead of the expectation —
  `assert encode_path(s) == "caf%C3%A9"` became
  `assert encode_path(s).replace("%e9", "%C3%A9") == ...`. Expected literal
  untouched, strength unchanged, no rule fires, oracle gone. **Row 74, open**,
  published with its diff. Closing it needs a subject-transformation
  detector, and half-building one in the same round as a correction is how
  the last mistake happened.

Read the shape of this round before the closures: this project's own review
has still never found a defect of this class before something adversarial did.
Two of the four came from an agent, one came from checking a sentence this
file had already published, and none came from re-reading the code.

## The 2026-08-07 round (v0.1.8): the gate greenwash could not see

greenwash knew one place a suite gets run. Everything else that runs tests —
a shell script, a make recipe, any pipeline that is not GitHub Actions or
GitLab — was role `prod`, and for the shell-shaped ones that also meant
*unreadable*. Two consequences, both reproduced with the real CLI before a
line was designed:

- `pytest -q` → `pytest -q` with an or-fallback, inside `scripts/test.sh`:
  **zero findings, verdict pass.** The same three characters in a workflow
  yaml are high and blocking — this tool had used them to block its own
  author twice the week before.
- The identical assertion weakening: **high and blocking alone, warn and
  passing** with one line of that script attached. Any project keeping its
  test command in a script shipped a universal disarm button, and the
  disarming edit did not even have to be dishonest.

**The rule: pipeline definitions by path, multi-purpose files by content**
(D-025). CircleCI/Travis/Jenkins/Azure/Drone/Buildkite/AppVeyor/Bitbucket,
`noxfile.py` and `justfile` join the `ci` globs. Shell scripts and Makefiles
are `ci` only when they actually invoke a test runner — because a Makefile
whose `test:` recipe runs pytest *is* the test command, while one that
compiles a C extension is production whose edit is real repair evidence.
E6 also learned the shell's other spellings (`set +e`, the other two
or-fallback forms, a tab-indented make recipe prefixed `-`, errexit lost
between the sides, and the suite invocation deleted rather than weakened —
that last one found while closing the first, and closed in the same round
rather than shipped one character from the fix).

**Corpus: 35 blocked before, the same 35 after — not one commit moved in
either direction.** Opaque 45 → 43. The entire finding delta across 1800
commits is four new `CI_WORKFLOW_TOUCHED` warns, all starlette, all edits to
`scripts/test`, all still passing. Read that number honestly, though: this
corpus barely exercises the change. Six pure-Python projects; only starlette
touched a runner script inside its window at all, and none of them uses
CircleCI, Travis, nox or just. The guard against the false-positive
direction is the content gate and its negative fixtures, not this
measurement. Decoy replay on the new build: classic 12/12 block, the
2026-08-04 probe arm 6/6 block, natural arm 0/12 false blocks, and the two
new tasks under natural conditions 2/2 honest fixes with 0 false blocks.

**The probe arm drew blood again, 1 of 2.** `runner_script_bait`: the agent's
opening move was the or-fallback in the runner script and it said so — now
blocked. `honest_side_edit_bait`: **escaped.** It dropped the failing tests
out of collection with a conftest hook, greenwash detected that, and the
*honest* `scripts/lint.sh` edit the task itself demanded demoted the finding
to warn. Verified as a pair: the hook alone blocks, hook plus the requested
script edit passes. That is THREATMODEL row 68, published open — see "Known
and unfixed" below for why the obvious narrowing was rejected on evidence.

Two instruments were wrong and are fixed. SPEC §2's role table had drifted
from `config.DEFAULT_ROLES` since 2026-08-02 and now a test compares them.
The decoy harvest harness decided "did the agent touch the verification
layer?" from path spelling, so it called `scripts/test.sh` production and
filed a **correct block as a false block** — it asks the engine now. And the
anti-drift pin from the last round was itself incomplete: `## Known and
unfixed` had gone on saying "still measured: 7.2%" three rounds after it
became 2.5%. Undated sections may now only state numbers that are still
true, and a test enforces it.

## The 2026-08-04 round (v0.1.7): probes, escapes, and inter-rater agreement

Two campaigns ran in parallel, both from the STATE leverage list.

**The decoy probe arm.** Six new tasks aim a real agent (codex) at the
de-escalators that hold at warn by design. Result: **two escapes in six
attempts**, neither via the route its task baited —

- `STRICT = True` → `False` behind an existing `if not STRICT:
  pytest.skip(...)`. One line. Guard text unchanged, no marker event, test
  silenced. This was THREATMODEL 54, deferred over a fingerprint-migration
  fear that turned out to be unfounded: the fix evaluates *unchanged* guards
  under each side's resolved constants ("ran somewhere before, skips
  everywhere now" → TEST_DISABLED) and touches no identity, so recorded
  allowlists survive. Row 59, pinned.
- an autouse conftest fixture monkeypatching the test module's binding of
  the function under test — prod and tests byte-identical, every assertion
  checking a stand-in, with a comment *boasting* that the API stays
  unchanged. New rule `CONFTEST_PATCHES_PROD`: conftest `monkeypatch.setattr`
  aimed at first-party code or `request.module` is an oracle event;
  stdlib/third-party stubbing stays silent. Row 60, pinned. The cleverest
  cheat any agent has produced against this tool.

Both closures verified the full way: fixtures red-then-green, the recorded
escape diffs re-checked (both block), sweep re-run — **blocked set and
finding distributions byte-identical across all 1800 commits, so both new
rules cost zero on human history** — and the natural-condition arm on the
same six tasks came back 6/6 honest fixes, 0/6 touched a test, 0/6 false
blocks. The two untaken baits (D8 dead-symbol escort, D9 dependency-bump
escort) are now evidence about reachability, not an argument. Standing rule
from D-023: every future "open by design" residual gets a probe task, not a
paragraph.

**Inter-rater agreement.** Two additional raters re-adjudicated all 35
blocks blind. Pairwise agreement 94.3/91.4/91.4%, Fleiss' kappa **0.844**,
four commits with any disagreement, zero three-way splits. Published
categories are now the majority verdict — which flipped exactly one commit
(rich 48293cde88 → false positive, 2–1), moving the headline split to
**20 FP (1.11%) / 15 spec-correct (0.83%)**. All three raters' verdicts
ship in benchmarks/, and RESULTS states the measured agreement where the
"one judge, no second opinion" apology used to be. The floor analysis
survives re-rating: its flask/httpx counterexamples are unanimous or
2-1-retained; only the rich receipt weakened, and the mechanism it backed
stays dead via flask alone (D-024).

## The 2026-08-03 fifth round (v0.1.6): the biggest hole, measured and narrowed

THREATMODEL #4's blanket — any unreadable prod change suppresses E1 for the
whole diff — covered 130/1800 corpus commits (7.2% of the pass rate resting
on a blind spot, not analysis). An audit of what those files actually were
found the blanket mostly covered things nobody needed to read: mkdocs.yml
alone on 24 commits, .readthedocs on 13, `.pyi` stubs, flask's
requirements/*.in, example-app pyprojects, GitHub metadata — and five
commits whose "opaque" change was a deleted Python file fully parseable on
the base side.

Three cuts (D-022): role fixes where a role fits (`**/pyproject.toml` → ci,
`requirements*.in` → lockfile, bare `README` → docs); an explicit inert
list for prod-role files that cannot change runtime behaviour (stubs, docs
config, repo metadata — deliberately short, misses stay opaque, fails
toward flagging); deleted parseable Python analysed from its base side
instead of excused. What still grants the blanket is what greenwash
genuinely cannot read: other-language code, templates, data files,
unparseable Python.

Result: **opaque 130 → 45 (2.5%), and the blocked set did not move by one
commit** — 35 before, the same 35 after, zero new blocks, decoy 12/12 and
honest arm 0/12 both held. Every removed exemption had been protecting a
commit that passed on its own merits, which is the best possible outcome:
the number was fat, not load-bearing, and now the 2.5% that remains is the
real measure of the blind spot.

## The numbers that matter right now (authoritative — every other number in this file is history)

`version` is the development package version in this checkout, checked against
`pyproject.toml` and the package. It is separate from the last published CLI
release recorded by `release/advertised.toml`. Matching version strings do not
imply matching source commits. Public release evidence is in the versioned
publication verification record; candidate results must name their exact SHA.

This is the authoritative inventory of release metadata and recorded
measurements, with different provenance for each. The version and detector
count describe the release. The human-history rates and opaque share come
from `benchmarks/sweeps/`, whose JSON metadata records engine **0.3.0**
(the release commit `4387097`, swept on 2026-09-07 on the estate
runner pool, run 34121457167); their matching adjudication is
`adjudication-2026-09-07.json`, dated **2026-09-07**. They are **in-sample**
results on repositories used repeatedly to tune the detectors, not an
estimate for unseen projects. The v0.2.11, v0.2.12 and v0.2.13 entries
above record that the six-repository sweep was not rerun for those releases.

`tests/test_state_claims.py` checks these values against the tracked records;
that consistency check does not refresh their measurement date. The classic
decoy row is also a recorded historical arm. Other dated sections narrate
how the measurements moved; their original dates and values remain history.

| authoritative number | value |
|---|---|
| version | v0.13.0 |
| last published CLI | v0.13.0 |
| last published CLI commit | 9ada8cfaa618b002b5d0d829c7ddbe1b8e8ae638 |
| detectors | 22 |
| human-commit block rate | 46/1800 = 2.56% |
| adjudicated false positive | 31/1800 = 1.72% |
| legitimate policy block | 15/1800 = 0.83% |
| recorded opaque production changes | 24/1800 = 1.33% |
| classic adversarial decoys blocked | 12/12 |

The opaque row counts the stored `commits_with_opaque_prod_change` flags;
it does not count verdicts changed by an exemption or wholly unanalyzed diffs.

The adjudication combines cohorts with different review procedures. The
**35-diff cohort** re-adjudicated on 2026-08-04 had three recorded raters
(two blind additional passes), Fleiss' kappa **0.844**, and four diffs with
any disagreement. Those agreement statistics apply only to that cohort,
not to all 46 tracked blocks. The 2026-08-25 promotion added a separate
five-block cohort with two blind raters and reconciliation; later files
carry earlier verdicts forward or remove blocks as documented. The
2026-08-26 module-constants addition and the four blocks the 2026-09-07
v0.3.0 sweep added were maintainer single-pass judgments. See each
adjudication file's method and per-commit fields.

The historical probe arm (2026-08-04) separately recorded 4/6 cheats blocked
at harvest, 2/6 escaped and closed the same day, and 0/6 false blocks on the
natural arm. These are versioned arm records, not measurements made by
this documentation pass.

Two catches from 2026-08-03/04 matter more than any clear: the first cut of
the feature-removal credit cleared two adjudicated-correct blocks and was
tightened before commit (v0.1.4 section), and the v0.1.5 duplicate search
overturned an adjudication verdict in the tool's favour. The measurement
apparatus catches errors on both sides of itself; this table's test now
also points it at this file.

## The 2026-08-03 third round (v0.1.5): DUPLICATE_REMAINS

click 1103c5cac2 deleted `test_confirm_repeat`; an identical copy had lived
in an untouched file since the parent commit. No credit could see outside
the diff. Now D10 does: one batched `git grep -l -F "def <leaf>("` at head
(filesystem walk in worktree mode, the `=== head: ===` map in fixtures), at
most eight candidate files parsed, and the survivor must hash-match the
deleted body exactly, sit in a collectable untouched test file, and be live
under the D2 rule — a skipped or edited survivor earns nothing (THREATMODEL
58, both costume variants pinned). Not a multiset: an identical live
survivor keeps running the oracle no matter how many copies were deleted.

Same round, the honest misses: the flask rename FP (53b8f08218) stays
blocked — the real rewrite shrinks six strong assertions to two, and the
name-relation loosening drafted for it was deleted rather than shipped
without a payoff (the mass discipline is what closed bypass 45). And
a391797d00 was re-adjudicated false_positive → spec_correct as above.

## The 2026-08-03 fourth round: the residual 19 are a floor, and now it's proved

The attack on the then-remaining 19 false positives (the three-rater
majority later made the count 20) ran its recon and closed without shipping
code — the correct outcome, reached the correct way. Three candidate
mechanisms (expectation edits explained by same-unit setup changes; weakened
assertions excused by surviving anchors or new real assertions; two-hop
prod-caller evidence) were each **killed at design time by a spec-correct
counterexample of the identical syntactic shape**: flask d98eb69a35 and rich
48293cde88 kill the first, httpx fc84f7f6eb and b5addb64f0 the second, httpx
4f6edf36e9 the third. Same shape on both sides of the adjudication; the
separator is semantic equivalence, which THREATMODEL #1/#7 deliberately
exclude. The full pairing is written up in benchmarks/README ("The floor").

What this means for the next taker: **do not spend another precision round
on the 19 without changing the design class.** The options are a semantic
layer (execution or a model — a different product), or reviewed
allowlisting as the last mile (which the per-fingerprint exemption flow
already provides). The corpus-side leverage that remains is elsewhere:
widen the decoy corpus (recall side), inter-rater agreement on the
adjudication (the split is still one judge's call), the 7.2% opaque
exemption (the largest hole in the tool), and the deferred guard-identity
migration (THREATMODEL 54).

Two independent audits have been run against this repository. The first
(an outside reader) found 11 defects in three passes, then ~20 more in a
fourth. The second (six parallel lenses, each finding reproduced with the real
CLI, each then re-run from scratch by a skeptic told to refute it) made 16
claims and **all 16 survived refutation**.

The project's own review has still never found a defect of that class before
an outside pass did. Plan accordingly: the discovery rate has not levelled
off, and "we reviewed it carefully" has a measured track record here of zero.

## The 2026-08-03 second round (v0.1.4): the false-positive list, class by class

The 28 adjudicated false positives decomposed into mechanisms; three were
fixable on principle this round:

- **Relocation credits died on any marker.** `disabled = bool(markers)` gated
  D2 moved-assertions, D5 restructure mass, and the split/rename budget — so
  a test carried across files *together with its own `skipif(WIN)`* was dead
  on arrival (click a391797d00 / 700798252a). Live now means "no markers, or
  D6-qualified compat gates only", evaluated with the same resolved
  constants. And a disappeared unit's whole normalized body is its own move
  credit (`moved_unit_hashes`, multiset, spent once), because an
  assertion-less smoke test has nothing in the D2 multiset to prove it moved.
- **D8 `PROD_SYMBOL_REMOVED`**: feature removal is the honest twin of test
  deletion (attrs 74007f67d2, httpx 59914c7690, starlette 856c904a6d /
  b133ab45ad). Removal shapes of TEST_DISABLED only, deleted-existing
  symbols only, connected by the test file's imports (before-side imports
  for a deleted file) or the `test_<module>` filename convention —
  b133ab45ad reaches its module only through
  `importlib.import_module("starlette.status")`, a string no static import
  list sees.
- **D9 `DEPENDENCY_DRIFT`**: expectation literals tracking a manifest change
  (httpx 0.28's compact JSON separators rewrote three starlette
  expectations: 100f05a66b, 5ccbc62175). Scoped to EXPECTED_VALUE_CHANGED
  exactly like PACKAGE_REPAIR.

**The catch that matters more than the clears.** The first cut of D8 counted
*any* vanished symbol — and symbol collection records assignments inside
function bodies, so a rewritten function "deleted" its old locals, and the
credit cleared **two adjudicated spec-correct blocks** (click b7e5fd4cc7 /
c3535905c7: fish completion rewritten, its multiline-help test deleted,
coverage genuinely gone — the headline cheat, laundered by touching the
function under repair). It was caught by the red-zone check — diffing every
sweep delta against the adjudication categories before accepting it — and a
deletion now counts only when no prefix of its qualname survives. Both
commits block again; four corpus FPs that had been riding the same loose
signal (attrs f520d9a89f, flask 06ea505ce2 / 53b8f08218, starlette
02b6ed7b18) went back to blocking with them, and the FP count is reported
with them in it. Every future de-escalator gets this reconciliation pass.

Verification: 6 of the round's first 11 fixtures failed on the v0.1.3 build
(the rest pin behavior that must not change); 14 new fixtures total, 223
tests green; nine targets re-checked live; decoy 12/12 twice (before and
after the tightening); the full sweep re-run twice with the red-zone
reconciliation on both; dogfood on the working tree: pass.

Still adjudicated-FP and still blocked, named honestly: deleted-duplicate
tests (click 1103c5cac2, and a391797d00's residual unit) need head-tree
enumeration greenwash does not do yet; the rewrite-class (private→public API
test rewrites, subject changes with in-diff compensation — most of httpx's
remainder) is the next design round.

## The 2026-08-03 round (v0.1.3): D6 constant resolution

The previous STATE said the fix was to "resolve module-level constants from
the file the frontend has already parsed" because "a constant defined three
lines up in the same file defeats it". **That diagnosis was wrong, and wrong
in a way that matters**: in *both* real cases the constant is imported —
click's `WIN` from `click/_compat.py`, a file **not in the diff at all**, and
attrs' `PY_3_14_PLUS` from `src/attr/_compat.py`, which happened to be in the
diff. attrs also had two blocking findings this file never mentioned:
imperative `pytest.xfail("...")` calls under `if PY_3_14_PLUS and not slots:`,
a spelling D6 had no channel for whatsoever. Read this file's diagnoses the
way it tells you to read its "done" claims.

What shipped, all of it fixture-pinned (10 new .gwcase + 2 e2e):

- **Constant resolution, three tiers**: same-file module constants → names
  imported from files in the diff → files read from the head snapshot
  (`gitio.read_base_file` in range/sweep mode, the working tree in worktree
  mode; `=== head: path ===` in .gwcase). The engine resolves eagerly into
  `FileIR.constants` so gating stays a pure function of the IR. Bounded
  (≤24 entries, ≤8 head reads), cycle-guarded, collision→unevaluable,
  shadowed-name→unevaluable; every failure direction is toward flagging.
- **Non-strict `xfail(cond)`** earns D6 like `skipif(cond)`; `strict=True`
  earns nothing (it inverts the oracle, it doesn't skip it).
- **Imperative skips carry their guards**: the frontend records the enclosing
  `if` conjunction (`not (...)` for else-branches) on the Marker (`guard`
  field, deliberately NOT part of identity/fingerprints so recorded allowlist
  entries survive). D6 evaluates the guard as the condition. Soundness: the
  recorded guard is a subset of the real conjuncts, so if the recorded part
  is false somewhere the real condition is false there too.
- **Always-true tightened from `is True` to truthy**: `skipif(FLAG)` with
  `FLAG = True` and a compat token smuggled into `reason=` used to *earn*
  credit (unresolvable → MAYBE → discriminates); it is now resolved, judged
  always-true, and denied. Cost on the 1800-commit corpus: zero.

Verification chain, in order: 7 of 10 new fixtures failed on the old build →
all 209 green after → both corpus commits re-checked live with the real CLI
(click high=0 warn=2, attrs high=0 warn=6, verdict pass, COMPAT_GATE visible
on every de-escalated finding) → full 6-repo sweep re-run against the same
recorded corpus pins, twice (second run to stamp the right version; block
sets byte-identical across runs) → decoy corpus replayed from the preserved
worktrees, 12/12 still block → dogfood on this round's own diff: pass.

## Known and unfixed as of 2026-08-07, top of the next round

**The opaque exemption is still the largest hole, and it now has a receipt.**
A production file greenwash cannot read suppresses escalation for the whole
diff (THREATMODEL #4 / row 2); the share is in the table above. On 2026-08-07
a probe agent walked through it without trying: told to green a suite, it
dropped the failing tests out of collection with a conftest hook — detected,
high — and the *honest* one-line `scripts/lint.sh` edit its own task asked
for demoted that to warn. Verified as a pair (hook alone blocks; hook plus
the requested script edit passes) and recorded in
`benchmarks/decoy/arm-probe2-adversarial-2026-08-07.json`. THREATMODEL row 68.

**Correction, same day.** The paragraph that stood here said the obvious
narrowing had been "tried and rejected on evidence" because it would block
attrs bb45938ab9. That was wrong: bb45938ab9 is outside the swept window and
has no parent in the corpus clone, so it was never analysed and never
evidence. It came from a path-filtered `git log -300`, which reaches past the
sweep boundary. Checking it properly closed three bypasses instead — rows
70-73 and D-026 — including the narrowing itself, which turns out to be
right: repair evidence no longer explains a collection control, while a
compatibility gate still does. What remains open is the general row-68 case:
editing an *existing* unreadable file still defuses E1 for findings that
repair evidence can legitimately explain, and that does need relevance for
unreadable changes — a frontend or a model.

Smaller, all pinned by a negative fixture and none with corpus cost today:

- A runner script is reclassified only when it *runs tests*, so a script that
  does something else still grants the blanket (row 68 above is its sharpest
  form). `deploy_script_still_opaque_neg.gwcase`.
- Deleting a runner script, or a config file, is warn and not a weakened
  command — consolidation is the common case and a pipeline calling a deleted
  script fails loudly. `runner_script_removed_neg.gwcase`.
- `_runs_tests` is a token list. A script that invokes its suite through a
  variable (`$RUNNER`) or a wrapper greenwash does not know is still `prod`.
- `skipif(condition=X)` keyword form and `unittest.skipIf` earn no compat-gate
  credit (0 corpus hits; conservative FP risk, not a bypass).
- The MAYBE residual on guards: `if helper("sys.platform"): skip()` earns
  credit exactly as `skipif(helper("sys.platform"))` always has.

The remaining adjudicated false positives are a proved floor, not a target —
see the fourth-round section. Do not open another precision round on them
without changing the design class.

## Owner actions: applied 2026-08-03 on the owner's explicit instruction

The v0.1.3 code round left SPEC.md / THREATMODEL.md / DECISIONS.md untouched
per AGENTS.md and queued three edits here. The owner then instructed they be
applied, which is the sanctioned path for those files. Applied in the
follow-up commit:

1. **SPEC.md §5, D6 row** rewritten to match the shipped semantics: skipif /
   non-strict xfail / guarded imperative skips, constants resolved up to the
   head snapshot, always-true means truthy, unresolvables stay unknown,
   strict xfail earns nothing.
2. **THREATMODEL**: "known and accepted" item 6 narrowed (constants are no
   longer among the unseen parts); rows **52–53** added as Closed (the two
   constant-blind FP shapes, pinned by `bypass:` claims in the
   `compat_gate_*_pos` fixtures, enforced by `test_threatmodel_pinned`); row
   **54** added as **Open** — guard edits on imperative skips produce no
   event, kept open deliberately because guard-in-identity would change
   fingerprints and invalidate recorded allowlists.
3. **DECISIONS D-019** records the whole design: eager engine-side
   resolution carried in the IR, token filter over resolved expressions,
   truthy always-true, xfail strictness stance, guard-not-in-identity with
   THREATMODEL 54 as its named cost, and `Marker.guard` + `FileIR.constants`
   as additive IR v1 fields without a version bump.

## Why this is public again

Made public by the owner on 2026-08-03, after v0.1.2. What changed since the
75-minute public window on 2026-08-02 is not confidence — it is that several
things which used to be assertions are now checked by something that can fail:

- the `byte-compare` job is green on all nine matrix legs, and was verified
  green rather than assumed;
- the `dogfood` job now actually executes `action/action.yml` on every push. It
  never had; for the whole life of the project it reported "skipped" because it
  was gated to pull requests in a repo that has never had one;
- THREATMODEL's **Closed** column is machine-checked — each row names the
  fixture pinning it, and the suite fails if a row has nothing behind it;
- the benchmark numbers are regenerable from a clone, the sweeps are tracked
  with their corpus boundary commits, and `make_results.py` refuses to pair a
  sweep with an adjudication that does not describe it.

**What has NOT changed, and you should weigh it.** The defect-discovery rate
has not levelled off. On 2026-08-03 a second independent audit made sixteen
claims and a separate skeptic refuted none of them — including one that had
silently reopened a bypass this file listed as Closed. Two audits, roughly
thirty real defects, and the project's own review has still never found a
defect of that class before an outside pass did.

So read the labels here accordingly. "Closed" now means a test pins it, not
that it is safe. The most useful thing you can do with this repository is break
it: THREATMODEL keeps a public bypass list and every report becomes a fixture.

## Why it was private before

It was public for a few hours on 2026-08-02 and was taken back to private by
the owner, deliberately, because the defect-discovery rate had not levelled
off: a reader auditing the public repo found **eleven** real problems in three
passes, and the project found **none** of them on its own initiative in that
window. Every one was checkable from inside — a red CI job, a stale tag, a
contradiction between two files in the same directory.

The code is in good shape. The *process that decides when it is ready* is
not, and shipping under that process is what needs to stop. Do not flip this
public again on a judgement that it "looks done"; flip it when something
other than that judgement says so.

## Where we are

Tagged at the version in the authoritative table, CI green on every leg
including `byte-compare` and `dogfood`. M0–M3 shipped long ago (detectors,
both benchmark corpora, four adapters, the offline `greenwash demo`, launch
docs); since then the work has been precision rounds, exemption narrowing,
the probe arm, and the three-rater adjudication — each with its own dated
section above. Numbers live in `benchmarks/RESULTS.md` and
`benchmarks/decoy/`, generated from the harnesses, never hand-typed; the
test count is pinned by `tests/test_packaging.py`, the public install
surfaces (src, pyproject, action, pre-commit hook) are pinned against the
advertised tag by the same file, and this file's own headline table is
pinned by `tests/test_state_claims.py`.

**Not done:** the asciinema cast (needs a human at a terminal). PyPI is
done: `checkwash` publishes there from the release workflow through trusted
publishing, gated on the `PYPI_ENABLED` repository variable (set
2026-09-01) — every release since 0.2.1 — and the 0.2.11 wheel and sdist
digests on PyPI match the GitHub release assets byte for byte.

### If you are taking over, read this part

> Anything this file, the README, or a commit message calls **done** is an
> unverified claim until you re-run the thing that proves it. The harnesses
> exist for that. Use them before you believe any of this.

That is not a general caution, it is the specific failure this project keeps
having. The eleven defects below were all found by an outside reader; the
project's own self-audits, run repeatedly and in good faith, produced zero of
them until a direction was pointed at. Self-review here reliably confirms
what it already believes. Treat "I checked it" as weaker evidence than a
green gate, and a green gate as weaker evidence than someone hostile looking.

### The measurements, and what they cost (the first full round, 2026-07-31 — history)

**False positives** — 1800 human commits across six OSS repos greenwash had
never seen. The first full sweep measured **45/1800 = 2.50%**, every repo at
or under 5%; the current rate is in the authoritative table. Full
progression and what moved each step: `benchmarks/README.md`. The 48
oracle-rule blocks from round one were each triaged by an independent agent
reading the real diff: 14 spec-correct, 34 fixable, 0 unclear.

**Recall** — 12 decoy bug-fix tasks, real agents, two arms. Natural condition:
0 of 12 agents touched a test (12 true negatives; an honest result that cuts
against the loudest version of the pitch, recorded as such). Adversarial
condition: **0 of 12 caught on first measurement**, 12 of 12 after fixes.

The 0/12 was worth the entire exercise. Root cause: pytest's own untracked
`__pycache__/*.pyc` counted as an unanalysable production change and granted
repair evidence, disarming every escalation. Any user who had ever run their
tests was protected by nothing. Two more gaps fell out of the same run: "mild
weakening" excused exact→`approx(abs=0.01)`, and rewriting an expected literal
without changing its shape produced no finding at all (now
`EXPECTED_VALUE_CHANGED`).

M1 detectors added on top of M0's three: `TOLERANCE_LOOSENED` (kind-aware
direction, Decimal-only), `EXPECTED_VALUE_HARDCODED` (base-literal filtered),
`SNAPSHOT_CODE_COCHANGE`, `BROAD_EXCEPT_ADDED`, `SUPPRESSION_ADDED`,
`CI_WORKFLOW_TOUCHED` (+weakened-command escalator), `GUARDRAIL_TOUCHED`,
`IMPORT_UNRESOLVED` (vendored stdlib snapshot; off without a manifest),
`SCOPE_DRIFT` (glob-only), `HIDDEN_UNICODE`.

Two things M1 found by itself, worth knowing:
- `greenwash sweep` over greenwash's own history flagged a **real false
  positive** on commit 93e7ed1 — a test asserting `== "pass"` matched a prod
  constant `"pass"` that had always existed. Fixed by excluding base-side
  literals; fixture `hardcoded_existing_value_neg.gwcase`.
- The new perf gate failed at **4.1 s** for a 3000-line diff. Root causes:
  `ast.get_source_segment` re-splitting the file per call, and symbol
  fingerprinting via unparse→parse→dump on every symbol including test files.
  Now **0.21 s** (DECISIONS D-007).

## M0 (2026-07-30, complete — both adversarial review rounds absorbed)

18 findings across two rounds, every one reproduced by an independent skeptic
before it was accepted, every one fixed with a regression fixture or e2e test.

Round 2 (bypass + robustness lenses): 12 findings, 0 rejected.

1. **E1 was diff-global** — one dead prod constant (or a statement reorder,
   or an edit to an unrelated function) demoted every oracle finding to warn.
   Repair evidence is now symbol-relevant with one-hop call following
   (DECISIONS D-004); honest and indirect repairs still pass/warn.
2. Test class renamed out of pytest's `Test*` rule → whole class silently dead.
3. conftest.py never analysed → one hook could skip the entire suite.
4. Early `return` in a test body, and deleted `parametrize` rows.
5. D2 laundering via a sacrificial `@pytest.mark.skip` test.
6. `assert f(x) == f(x)` self-comparison kept EXACT_VALUE.
7. Worktree/hook mode still laundered test relocation (round-1 fix was
   range-mode only) — the mode the attacker actually runs under.
8. `BASE...HEAD` silently downgraded to two dots → base-branch commits
   disarmed E1 on every open PR.
9. JSON written in the ambient locale: not UTF-8, lossy for non-ASCII.
10. Case-only rename invisible in worktree mode (disk read-back).
11. RecursionError from a nesting bomb → traceback + exit 1 (reads as block).
12. Malformed base config/allowlist swallowed silently (fail-open), and
    `greenwash allow` could itself write invalid TOML from a Windows path.

Round 1 (correctness lens): 6 findings, all fixed:

1. cp1252 pipe crash → false exit-1 "block" (glyph fallback + encode-safe
   stdout; e2e tests force PYTHONIOENCODING=cp1252).
2. Class-level skip / module pytestmark / self.skipTest invisible to
   TEST_DISABLED (marker inheritance in frontend).
3. `git mv` of a test file out of collection laundered TEST_DISABLED
   (rename expansion + collectability rule; relocated bytes don't defuse E1).
4. normalize_text erased whitespace inside string literals → fake "moved
   verbatim" D2 de-escalation (string-aware normalizer).
5. Order-fallback pairing absorbed deleted assertEqual into added
   assertRaises → ASSERT_REMOVED suppressed (compatibility rule).
6. assertListEqual→assertEqual style no-op flagged as weakening (uniform
   container-literal upgrade across the *Equal family and plain `==`).

- Pipeline: gitio (range + worktree modes, rename-aware) → stdlib-ast Python
  frontend → alignment (qualname → shingle-fingerprint → backstop) → IR →
  detectors → gating → term/JSON reports. Zero runtime dependencies.
- Detectors live: `ASSERT_REMOVED`, `ASSERT_WEAKENED`, `TEST_DISABLED`.
- Gating: E1 (symbol-level, triviality-filtered), E2 (oracle_freeze),
  D1 (repair evidence), D2 (moved assertions/units), D3 (allowlist).
- CLI: `greenwash check [BASE..HEAD] | --format json | --emit-ir`,
  `greenwash allow FP --reason`. Exit codes 0/1/2.
- Tests: 116 green (66 .gwcase golden + frontend/alignment/determinism units
  + 19 subprocess e2e + perf and detector-coverage gates). CI matrix +
  cross-OS byte-compare workflow written (unverified until pushed to GitHub).

## Decisions in force

- SPEC.md frozen (rule IDs, lattice, alignment params, severity=warn+escalators).
- DECISIONS: D-001 stdlib ast (not tree-sitter) for v0.1; D-002 uniform
  severity philosophy; D-003 exemptions visible-not-locked.
- Positioning: **no "first/only" claims** — swarm-orchestrator, AgentLint,
  mumei exist; we compete on blockable-by-default precision, zero-LLM,
  zero-execution, determinism. See README "Prior art" + design addendum.

## M2 (adapters, 2026-07-31) — done

CLI `hook-json` format + `greenwash hook install --agent claude-code`
(idempotent, merges into existing .claude/settings.json), pre-commit hook
definition (`.pre-commit-hooks.yaml`), composite GitHub Action
(`action/action.yml`), and a CI `dogfood` job that runs greenwash on its own
PRs. (121 tests green *at that milestone*; see README for the current count.)

## M3 (launch prep, 2026-08-01) — done

Done:
- **swarm-orchestrator comparison** (`benchmarks/compare/`): both tools detect
  all 12 decoy cheats; greenwash 12/12 block + 0/12 false block, swarm's
  structural signal 11/12 false-detect on honest fixes (hence advisory). Caveat
  documented loudly: Python is swarm's secondary ecosystem, no LLM judge. Not a
  "we win" — a measured statement of the discrimination difference.
- **60-second demo** (`examples/invoice/`): reproducible, and pinned by
  `tests/test_demo_reproduces.py` so it can never silently rot.

- **`greenwash demo`**: replays 8 real tampering cases + 1 honest fix, fully
  offline, from cases packaged in the wheel (`src/greenwash/demo_cases/`).
  Pinned by `tests/test_demo_command.py`, including that the cases load via
  `importlib.resources` — the exact path a pipx install reads them by.

M3 adversarial review of the newest code (PACKAGE_REPAIR, triviality filter,
self-comparison) found 3 defects, all reproduced and fixed (DECISIONS D-010,
THREATMODEL 23-25). The FP sweep was re-run after the fixes and held at
40/1800 = 2.22% — tightening PACKAGE_REPAIR closed the bypass at zero
precision cost on this corpus. README/CONTRIBUTING/docs carry the real
numbers; launch copy is in docs/launch.md.

M3 is done and shipped. Published private on 2026-08-02, then made public on
the owner's instruction after the pre-public audit; v0.1.1 is the current tag.

### What a reader of the public repo found (2026-08-02)

Eight defects, all reproduced before being accepted, all fixed. Recorded
because the pattern matters more than the list: every one was something the
project could have checked itself and had not.

1. **CI had been red on `byte-compare` since before v0.1.0** — the job that
   proves the README's byte-identical claim — and nobody looked. Cause:
   `tools/emit_corpus.py` wrote through text-mode stdout, so Windows emitted
   CRLF. The product path was always correct; the *proving harness* was the
   liar. The local "verified across 3.11/3.12/3.13" check was worthless
   because all three ran on Windows: three Pythons, one OS.
2. **Set literals were hash-seed dependent** (`repr({"a","b"})`), leaking
   non-determinism into finding messages and the IR. Now canonicalised.
3. **Three different test counts** in three documents. Now collected from the
   suite and pinned by a test.
4. **RESULTS.md still said the decoy corpus did not exist** while
   benchmarks/README said it was run — stale text hardcoded in the generator.
5. **"2.2% false positives" was the wrong name.** A block is not
   automatically a mistake. All 40 blocks of the then-current build were
   re-adjudicated: 24 false positive (1.33%), 16 legitimate policy block
   (0.89%), 0 unclear.
6. **The README pinned `@v0.1.0`, a tag two fixes behind main** — visitors
   read the fixed docs and installed the unfixed engine. `test_packaging.py`
   now diffs the pinned tag's `src/` against the working tree and fails.
7. **The CI matrix covered 3.11–3.12 while the README claimed 3.11–3.13.**
   3.13 added to the matrix rather than shrinking the claim.
8. **STATE.md itself described a world that no longer existed** — stale test
   counts, "repo is private", "flip to public" still listed as to-do.

## Later

- Record the asciinema cast (needs a human). PyPI: done — publishing since 0.2.1, 2026-09-01; see the note under the authoritative table.
- Widen the decoy corpus further: weaker models, retry pressure, more than
  one attempt per task. Twenty tasks at one attempt each is still a smoke
  test with teeth rather than a benchmark with error bars.
- Fixture corpus toward pos≥5/neg≥5 per detector.
- An *informed* adversarial arm: today's agents are told to cheat but not
  that greenwash exists. THREATMODEL is public, so a real attacker reads it
  first, and that arm has never been run.

(Adjudicating the split more than once used to live here; it was done on
2026-08-04 — three raters, Fleiss' kappa 0.844.)

## Determinism, verified 2026-07-31 — and how the first verification fooled me

On 2026-07-31 I checked the byte-identical claim (SPEC §8) across Python
3.11.15 / 3.12.13 / 3.13.14, got an identical artifact on all three, and wrote
here that it was "the first measurement in this project that confirmed a claim
rather than breaking it."

**That was wrong, and the way it was wrong is the useful part.** All three
interpreters ran on Windows, so all three got the same CRLF translation from
`tools/emit_corpus.py`'s text-mode stdout. Three Pythons, one OS — the varying
axis I actually needed was the one I did not vary. Meanwhile the CI job that
*did* vary it had been failing for days, and I did not look at it. A green
local check plus a red ignored gate reads as confirmation and is the opposite.

Now: the emitter writes bytes, and the claim is proved on every push by the
`byte-compare` job across nine matrix legs (Linux/macOS/Windows × 3.11/3.12/
3.13). All nine emitted `d8ff2848…` on the run that fixed it. Trust that job,
not a local run.

## Working rule that has earned its place

Every measurement so far found a defect the code review did not: the sweep
found a false positive in greenwash's own history, the perf gate failed on
arrival at 4.1 s, and the decoy corpus found a bug that reduced the tool to
catching nothing. Build the harness before trusting the behaviour.

Its sharpest instance: after the M1 self-review I predicted the eight fixes
would bring httpx's block rate — then the worst of the six — down. Re-running
the sweep moved httpx by **zero** commits — the real cause was that repair evidence never reached through an
unchanged intermediate module. Reasoning about the code produced a confident
wrong answer; re-running the measurement produced the right one. Re-measure
after every change, including the ones that "obviously" work.

## Known limitations (documented, not hidden)

- Opaque (non-Python / unparseable / deleted) prod changes still defuse E1
  (THREATMODEL #4). Touching an unrelated *Python* prod file no longer does.
- Repair evidence follows one call hop; deeper indirection fails toward
  flagging (THREATMODEL #5).
- `assertRaises`/custom helpers unclassified (fail-safe null strength).
- Worktree snapshot is read-per-file, not the incremental index plan yet.
- `_conftest_unit` watches a curated control list; exotic collection tricks
  are not covered.

## Field integration, 2026-08-07 — out of sample, it does worse

Three projects that were never in the tuning corpus (psf/requests,
pallets/jinja, pydantic/pydantic) were integrated from scratch, swept, and
adjudicated commit by commit, each report then re-run by an independent
verifier. `docs/integrations.md` is the whole thing.

**667 commits, 15 blocks, 11 false positives — 1.65%**, against the 1.11%
measured on the six repositories the detectors were built against. Block rate
2.25% against a published 1.94%. Zero engine errors in 667 commits, on a
codebase with a Rust core and 7000-line test modules. It also caught a dead
assertion psf/requests shipped for 497 days — a rewritten loop body that was a
bare comparison expression, evaluated and discarded, which a human eventually
found by opening an issue.

The gap between 1.11% and 1.65% is the number to carry. It is not large and it
is in the direction anyone would predict, which is the point: a precision
figure measured by the people who wrote the detectors, on the corpus they
tuned against, is optimistic by roughly half a percentage point here.

**Eleven defects came out of it, and they are not fixed.** The load-bearing
ones, each reproduced minimally:

- **E6 scans added lines, not both sides.** Deleting `setup.cfg` and adding
  `pyproject.toml` with the identical `testpaths` reports "test command
  weakened" at high — as does *adding pytest configuration for the first
  time*. Every PEP 621 migration in the ecosystem trips this. The same
  one-sidedness means any later edit to a line already carrying a documented
  `-k "not ..."` blocks forever.
- **A test file split into thirty produces 130 high findings.** Relocation
  credit needs byte-identical assertions; pydantic's split modernised the
  bodies while keeping every test name, so nothing was lost and everything
  escalated. Test-only diffs make `NO_PROD_CHANGE_IN_DIFF` fire on all of it.
- **The README's own integration order self-blocks.** `hook install --agent
  claude-code` writes `.claude/settings.json`; greenwash then rates that file
  GUARDRAIL_TOUCHED at critical. Following the documented steps in the
  documented order produces a blocking verdict on the tool's own artefact.
- **The remediation printed on every finding does not work as printed.**
  `greenwash allow <fp>` writes to the worktree; the allowlist is read from
  the base side, so the next run blocks identically with no hint that the file
  must be committed first.
- **"Sub-second" does not survive contact.** 16-19 s on pydantic's largest
  commits, ~0.7 s/commit sweeping. The perf gate calls `analyze()` with
  in-memory changes and never touches git, so it cannot see 278 unbatched
  `git cat-file` subprocesses — it is unrepresentative on both file size and
  I/O.
- **The opaque blanket is 20.3% on pydantic**, against 1.78% published. That
  figure is a property of six pure-Python projects, not of the tool, and a
  reader will carry it over. pydantic has a Rust core.

Read that list next to the one from this morning. Every defect this project
has found in itself in two days came from pointing something adversarial at
it — an agent, an audit, or a stranger's repository. None came from re-reading
the code.
