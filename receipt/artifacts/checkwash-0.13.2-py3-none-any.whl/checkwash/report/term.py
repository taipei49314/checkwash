"""Terminal report rendering. Colors honour NO_COLOR and non-tty output."""

from __future__ import annotations

from collections import Counter
from collections.abc import Iterable
import os
import sys

from checkwash.allowlist import MAX_EXPIRY_DAYS
from checkwash.change import UnreadSide
from checkwash.config import SEVERITY_ORDER
from checkwash.findings import Finding
from checkwash.ir.model import IR
from checkwash.report.context import ReportContext
from checkwash.report.unread import sorted_unread
from checkwash.report.textio import unicode_decoration
from checkwash.unanalysed_test_files import unanalysed_test_note

_SEV_COLOR = {"critical": "35", "high": "31", "warn": "33", "info": "36"}
_REVIEW_HINTS = {
    "TEST_PATCHES_SUBJECT": "Check which implementation the assertion calls and restore the production subject.",
    "ASSERT_WEAKENED": "Restore the assertion that checks the intended behavior.",
    "EXPECTED_VALUE_CHANGED": "Check the new expected value against the intended behavior.",
    "GUARDRAIL_TOUCHED": "Review the guardrail change with its owner.",
}


def _use_color(stream) -> bool:
    if os.environ.get("NO_COLOR"):
        return False
    return hasattr(stream, "isatty") and stream.isatty()


def _symbols(stream) -> dict[str, str]:
    """Unicode glyphs only when the stream encoding can carry them.

    Piped output on legacy-locale Windows is cp1252; writing '✓' there raised
    UnicodeEncodeError and turned a clean diff into exit 1 (confirmed
    red-team crash). ASCII fallback keeps the exit-code contract intact.
    """
    if not unicode_decoration(stream):
        return {"pass": "OK", "block": "X", "warn": "!", "dash": "-", "ellipsis": "..."}
    return {"pass": "✓", "block": "✗", "warn": "⚠", "dash": "—", "ellipsis": "…"}


# One line of evidence, bounded. SUPPRESSION_ADDED on a generated module
# printed a ~1400-character unicode regex twice — once in the message and
# once as evidence — and buried every other finding on the screen.
_EVIDENCE_WIDTH = 160


def _evidence(text: str | None, ellipsis: str = "…") -> str:
    if not text:
        return ""
    first = text.splitlines()[0]
    return first if len(first) <= _EVIDENCE_WIDTH else first[: _EVIDENCE_WIDTH - len(ellipsis)] + ellipsis


def _c(code: str, text: str, color: bool) -> str:
    return f"\x1b[{code}m{text}\x1b[0m" if color else text


def render(
    ir: IR,
    findings: list[Finding],
    verdict: str,
    fail_on: str,
    stream=None,
    errors: list[str] | None = None,
    ledger_path: str = ".greenwash/allow.toml",
    context: ReportContext | None = None,
    unread: Iterable[UnreadSide] = (),
    reviewed_on_branch: dict[str, str] | None = None,
) -> str:
    stream = stream or sys.stdout
    color = _use_color(stream)
    sym = _symbols(stream)
    lines: list[str] = []

    visible = [f for f in findings if not f.allowlisted]
    suppressed = [f for f in findings if f.allowlisted]
    blocking = verdict == "block"
    coverage_gaps = context.coverage_gaps if context is not None else []
    importer_gaps = context.importer_gaps if context is not None else []
    unanalysed_test_files = context.unanalysed_test_files if context is not None else []
    unread_sides = sorted_unread(unread)

    if not visible and not suppressed:
        head = "checkwash: no known tampering pattern detected"
        # A pass that did not read a changed file must not look like one
        # that read every file (#454): an unread side switches the head as a
        # coverage gap does, and so do importers left unread (D-206) and
        # changed test-shaped files outside the parse gates (B6). With
        # findings the head is unchanged.
        if coverage_gaps or importer_gaps or unanalysed_test_files or unread_sides:
            head = "checkwash: analysis incomplete; no known tampering pattern detected"
            lines.append(_c("33", sym["warn"] + " " + head, color))
        else:
            lines.append(_c("32", sym["pass"] + " " + head, color))
    elif not visible:
        lines.append(_c("32", f"{sym['pass']} checkwash: pass ({len(suppressed)} allowlisted)", color))
    else:
        threshold = SEVERITY_ORDER[fail_on]
        n_at_or_above = sum(
            1 for f in visible if SEVERITY_ORDER[f.severity] >= threshold
        )
        if blocking:
            head = (
                f"checkwash: {n_at_or_above} finding(s) at or above {fail_on} "
                f"{sym['dash']} blocking"
            )
            lines.append(_c("31", sym["block"] + " " + head, color))
        else:
            head = f"checkwash: {len(visible)} finding(s), none at or above {fail_on}"
            lines.append(_c("33", sym["warn"] + " " + head, color))
    lines.append("")

    def assertion_edit(f):
        if f.rule in {"ASSERT_WEAKENED", "EXPECTED_VALUE_CHANGED"} and f.before and f.after:
            return (f.path, f.unit, f.before.span, f.after.span, f.before.text, f.after.text)
        return None

    edits = Counter(key for f in visible if (key := assertion_edit(f)) is not None)
    for f in visible:
        sev = _c(_SEV_COLOR.get(f.severity, "0"), f.severity.upper(), color)
        where = f"{f.path} :: {f.unit}" if f.unit else f.path
        lines.append(f"{f.rule}   {sev}   {where}")
        local = (context.local_definitions.get((f.path, f.unit, f.after.span))
                 if context and f.rule == "TEST_PATCHES_SUBJECT" and f.unit and f.after else None)
        if local:
            name, target = local
            lines.append(f"  This test calls its own {name} function. Remove the local definition so the assertion checks the imported {target} again.")
        else:
            lines.append(f"  {f.message}")
        edit = assertion_edit(f)
        if edit and edits[edit] > 1:
            lines.append(f"  This assertion has {edits[edit]} findings. Each has its own fingerprint.")
            del edits[edit]
        if f.rule == "TEST_DISABLED" and "PROD_SYMBOL_REMOVED" in f.deescalators:
            lines.append("  A production symbol was removed too. If the test and function were renamed, compare the replacement test's assertions.")
        if blocking and f.severity in ("high", "critical") and not local:
            advice = _REVIEW_HINTS.get(f.rule)
            if advice:
                lines.append(f"  {advice}")
        if f.rule == "CI_WORKFLOW_TOUCHED" and f.path.rsplit("/", 1)[-1] in {"pyproject.toml", "setup.cfg", "tox.ini"}:
            lines.append("  To compare declared coverage, Ruff or mypy requirements, run checkwash quality on the same range.")
        if f.escalators:
            label = f"why {f.severity}" if f.severity in ("high", "critical") else "escalators"
            lines.append(f"  {label}: {', '.join(f.escalators)}")
        if f.deescalators:
            lines.append(f"  held at {f.severity} by: {', '.join(f.deescalators)}")
        elif f.severity in ("high", "critical"):
            # Say only what did not happen. Listing credits that did not
            # fire as if they should have is the COLLECTION_CONTROL_UNEXPLAINED
            # class of lie.
            lines.append("  no de-escalator applied")
        if f.before is not None:
            lines.append(f"  before  {_evidence(f.before.text, sym['ellipsis'])}")
        if f.after is not None:
            lines.append(f"  after   {_evidence(f.after.text, sym['ellipsis'])}")
        if reviewed_on_branch and f.fingerprint in reviewed_on_branch:
            branch = reviewed_on_branch[f.fingerprint]
            lines.append(f"  next: an active exemption for {f.fingerprint} exists on {branch!r}.")
            lines.append(f"    Update this branch by merging or rebasing onto {branch!r}, then run the check again.")
        elif f.severity in ("high", "critical"):
            if local:
                lines.append("  If the replacement is intentional, record a reviewed exemption:")
            else:
                lines.append("  next: fix the code, or record a reviewed exemption:")
            lines.append(f'    checkwash allow "{f.fingerprint}" --reason "..."')
            # The allowlist is read from the *base* side, so an agent cannot
            # exempt itself inside the diff under review. Correct, and it made
            # the printed instruction look broken: run it, re-run check, get
            # the identical block, with nothing saying why (field integration
            # 2026-08-07). The reader of a blocking report is exactly the
            # person who needs the second half of the sentence.
            lines.append(f"    then commit {ledger_path} {sym['dash']} it is read from the base side")
        lines.append("")

    for message in errors or []:
        lines.append(_c("33", "! " + message, color))
    for gap in coverage_gaps:
        lines.append(_c("33", "! " + gap.message(), color))
    for gap in importer_gaps:
        lines.append(_c("33", "! " + gap, color))
    if unanalysed_test_files:
        lines.append(_c("33", "! " + unanalysed_test_note(unanalysed_test_files), color))
    for side in unread_sides:
        lines.append(_c("33", "! " + side.note(), color))
    if ir.skipped_files:
        lines.append(f"skipped (unparseable): {', '.join(ir.skipped_files)}")
    if suppressed:
        lines.append(
            f"allowlisted findings: {len(suppressed)} "
            f"(see {ledger_path}; expiry cap {MAX_EXPIRY_DAYS} days; "
            "takes effect after commit)"
        )
    counts = {"critical": 0, "high": 0, "warn": 0, "info": 0}
    for f in visible:
        counts[f.severity] += 1
    lines.append(
        "summary: "
        + " ".join(f"{k}={v}" for k, v in counts.items())
        + f" verdict={verdict} allow_cap={MAX_EXPIRY_DAYS}d"
    )
    return "\n".join(lines) + "\n"
