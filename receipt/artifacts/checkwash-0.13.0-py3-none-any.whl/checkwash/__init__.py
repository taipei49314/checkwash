"""checkwash: a deterministic, zero-LLM detector for diffs that tamper with the verification layer."""

__version__ = "0.13.0"

IR_VERSION = 3
FINDINGS_VERSION = 2
