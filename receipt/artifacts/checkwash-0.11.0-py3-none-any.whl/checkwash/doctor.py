"""`checkwash doctor` — conservatively prove a load-bearing CI gate."""

from __future__ import annotations

import datetime
import json
import os
import re
import stat
import subprocess
from dataclasses import dataclass
from pathlib import Path

from checkwash.config import CONFIG_DIRS, resolve_config_file
from checkwash.allowlist import MAX_EXPIRY_DAYS, fingerprint_diagnostics, load_allowlist, namespace_diagnostics, summarize_allowlist
from checkwash.hooks import HookInstallError, has_pre_tool_use_hook, has_session_start_hook, has_stop_hook, stop_reads_hook_input
from checkwash.report.textio import write_text


@dataclass
class Note:
    level: str  # "ok" | "warn" | "problem" | "info"
    title: str
    detail: str


_EVENT = "pull_request"
_BANNED = {"if", "continue-on-error", "env", "defaults", "strategy", "container"}
_ACTION = "taipei49314/checkwash/action"
# Scheme S (D-194). The Action pin the README recommended when this release was
# prepared; RELEASING step 8 moves it with the README after publication.
_PREVIOUS_ACTION_PIN = "100699796d942af30644738ffbcd1f1c939411c5"
# This release's own Action commit. Only a release PR's last commit changes the
# next line, to that commit's parent (tools/own_action_pin.py), and the release
# bridge verifies it. The release tools read both lines in exactly this shape.
_OWN_ACTION_PIN = "257150319fca15235185fc629d8b9c21c17166ca"
_PINS = {
    "actions/checkout": "3d3c42e5aac5ba805825da76410c181273ba90b1",
    "actions/setup-python": "5fda3b95a4ea91299a34e894583c3862153e4b97",
    # The pin the README and the self-audit workflow use.
    _ACTION: _PREVIOUS_ACTION_PIN,
}
# The exact commits each step may use; nothing is read from the network.
_ACCEPTED = {owner: (pin,) for owner, pin in _PINS.items()}
_ACCEPTED[_ACTION] = tuple(dict.fromkeys((_PREVIOUS_ACTION_PIN, _OWN_ACTION_PIN)))
# Each step's accepted `with:` mappings, and how a reason spells them. The
# Python versions are the ones pyproject.toml and action/README.md support,
# each as an exact double-quoted string (#436).
_PYTHONS = ('"3.11"', '"3.12"', '"3.13"')
_WITH = {
    "actions/checkout": [{"fetch-depth": "0", "persist-credentials": "false"}],
    "actions/setup-python": [{"python-version": version} for version in _PYTHONS],
}
_WITH_TEXT = {
    "actions/checkout": "fetch-depth: 0, persist-credentials: false",
    "actions/setup-python": "python-version: " + ", ".join(_PYTHONS[:-1]) + " or " + _PYTHONS[-1],
}


def _read(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ""


def _decode_workflow(data: bytes) -> str | None:
    try:
        text = data.decode("utf-8-sig")
    except UnicodeDecodeError:
        return None
    # A narrow YAML-printable subset. NEL, LS, and PS are valid YAML line
    # breaks, but supporting them would require another parsing grammar.
    for char in text:
        codepoint = ord(char)
        if char in "\t\n\r" or 0x20 <= codepoint <= 0x7E:
            continue
        if (
            0xA0 <= codepoint <= 0xD7FF
            or 0xE000 <= codepoint <= 0xFFFD
            or 0x10000 <= codepoint <= 0x10FFFF
        ) and codepoint not in {0x2028, 0x2029}:
            continue
        return None
    return text


def _without_comment(line: str) -> str:
    quote = ""
    escaped = False
    for index, char in enumerate(line):
        if quote == '"' and char == "\\" and not escaped:
            escaped = True
            continue
        if char in "\"'" and not escaped:
            if not quote:
                quote = char
            elif quote == char:
                quote = ""
        if char == "#" and not quote and (index == 0 or line[index - 1] in " \t"):
            return line[:index].rstrip(" ")
        escaped = False
    return line.rstrip(" ")


def _lines(text: str) -> list[str]:
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    return [clean for line in text.split("\n") if (clean := _without_comment(line)).strip(" ")]


def _indent(line: str) -> int:
    return len(line) - len(line.lstrip(" "))


def _mapping(line: str, indent: int) -> tuple[str, str] | None:
    match = re.fullmatch(rf" {{{indent}}}([A-Za-z_][A-Za-z0-9_-]*):(?: +(.*))?", line)
    return (match.group(1), match.group(2) or "") if match else None


def _unfiltered_event(lines: list[str], on_index: int, on_value: str) -> bool:
    if on_value:
        match = re.fullmatch(r"\[ *([A-Za-z_]+) *\]", on_value)
        return bool(match and match.group(1) == _EVENT)
    end = next((i for i in range(on_index + 1, len(lines)) if _indent(lines[i]) == 0), len(lines))
    if end != on_index + 2:
        return False
    item = _mapping(lines[on_index + 1], 2)
    return bool(item and item[0] == _EVENT and not item[1])


def _event_issue(lines: list[str], on_index: int, on_value: str) -> str:
    """Name the trigger doctor proves when the workflow's differs (#436)."""
    if on_value:
        found = "on: " + (on_value if len(on_value) <= 60 else on_value[:57] + "...")
    else:
        end = next((i for i in range(on_index + 1, len(lines)) if _indent(lines[i]) == 0), len(lines))
        body = lines[on_index + 1:end]
        events = [item[0] for line in body if (item := _mapping(line, 2))]
        found = "an on: block with " + (", ".join(events) or "no event")
        if any(_indent(line) > 2 for line in body) or any(
            item[1] for line in body if (item := _mapping(line, 2))
        ):
            found += " and event filters"
    return (
        "unsupported or ambiguous workflow shape: doctor proves only on: [pull_request] "
        f"or an on: block holding one unfiltered pull_request:, found {found}"
    )


def _step(lines: list[str]) -> tuple[dict[str, str], dict[str, str]] | None:
    first = re.fullmatch(r"      - ([a-z][a-z0-9-]*):(?: +(.*))?", lines[0])
    if not first:
        return None
    props = {first.group(1): first.group(2) or ""}
    with_values: dict[str, str] = {}
    in_with = first.group(1) == "with" and not props["with"]
    for line in lines[1:]:
        indent = _indent(line)
        item = _mapping(line, indent)
        if indent == 8 and item:
            if item[0] in props:
                return None
            props[item[0]] = item[1]
            in_with = item[0] == "with" and not item[1]
        elif indent == 10 and item and in_with:
            if item[0] in with_values:
                return None
            with_values[item[0]] = item[1]
        else:
            return None
    return props, with_values


def _plain_chain(root: Path, relative: str | Path) -> bool:
    relative = Path(relative)
    if relative.is_absolute() or ".." in relative.parts:
        return False
    current = root
    for part in relative.parts:
        try:
            with os.scandir(current) as entries:
                matches = [entry.name for entry in entries if entry.name.casefold() == part.casefold()]
            if matches != [part]:
                return False
            current /= matches[0]
            info = current.lstat()
        except OSError:
            return False
        if current.is_symlink() or (
            getattr(info, "st_file_attributes", 0)
            & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0)
        ):
            return False
    return True


def _regular_bytes(path: Path) -> bytes | None:
    descriptor = -1
    flags = os.O_RDONLY | getattr(os, "O_BINARY", 0) | getattr(os, "O_NOFOLLOW", 0)
    try:
        descriptor = os.open(path, flags)
        if not stat.S_ISREG(os.fstat(descriptor).st_mode):
            return None
        with os.fdopen(descriptor, "rb") as handle:
            descriptor = -1
            return handle.read()
    except OSError:
        return None
    finally:
        if descriptor >= 0:
            os.close(descriptor)


# Seconds each of doctor's Git queries may take. `main()` passes it to the
# repository-root lookup too, with stdin closed as here (#500).
QUERY_TIMEOUT = 5


def discovery_env() -> dict[str, str]:
    """`_git_query`'s sanitized Git environment without its discovery ceiling.

    `checkwash doctor` finds the repository root with it (#416). With the
    caller's environment, GIT_DIR could name a different repository from the
    one doctor's own queries then see at that root.
    """
    env = {key: value for key, value in os.environ.items() if not key.upper().startswith("GIT_")}
    env.update({
        "GIT_CONFIG_GLOBAL": os.devnull,
        "GIT_CONFIG_NOSYSTEM": "1",
        "GIT_DISCOVERY_ACROSS_FILESYSTEM": "0",
        "GIT_NO_LAZY_FETCH": "1",
        "GIT_OPTIONAL_LOCKS": "0",
        "GIT_TERMINAL_PROMPT": "0",
        "GCM_INTERACTIVE": "Never",
    })
    return env


def _git_query(root: Path, *args: str) -> subprocess.CompletedProcess[bytes] | None:
    env = discovery_env()
    env["GIT_CEILING_DIRECTORIES"] = str(root.parent.resolve())
    try:
        result = subprocess.run(
            [
                "git", "--no-optional-locks", "--no-replace-objects",
                "-c", "core.fsmonitor=false",
                "--literal-pathspecs", *args,
            ],
            cwd=root,
            env=env,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            timeout=QUERY_TIMEOUT,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    return result


def _tracked_blob(root: Path, relative: str | Path) -> tuple[bytes | None, str]:
    relative = Path(relative)
    if relative.is_absolute() or ".." in relative.parts:
        return None, "not a repository-relative path"
    requested = relative.as_posix()
    try:
        encoded = requested.encode("utf-8")
    except UnicodeEncodeError:
        return None, "path cannot be encoded as UTF-8"
    result = _git_query(root, "ls-files", "--stage", "-z", "--", requested)
    if result is None:
        return None, "Git index could not be inspected"
    if result.returncode:
        return None, "Git index is unavailable; run doctor from a Git repository"
    if not result.stdout:
        return None, f"untracked workflow; review it, then git add -- {requested} (a commit is not required)"
    records = result.stdout.split(b"\0")
    if result.returncode or len(records) != 2 or records[1]:
        return None, "multiple or unmerged index entries; resolve the index before retrying"
    header, separator, actual = records[0].partition(b"\t")
    fields = header.split(b" ")
    if not (
        separator
        and actual == encoded
        and len(fields) == 3
        and fields[0] in {b"100644", b"100755"}
        and re.fullmatch(rb"[0-9a-f]{40}|[0-9a-f]{64}", fields[1])
        and fields[2] == b"0"
    ):
        return None, "index entry is not a regular, stage-0 file with the exact path"
    oid = fields[1].decode("ascii")
    blob = _git_query(root, "cat-file", "blob", oid)
    worktree = _regular_bytes(root / relative)
    if blob is None or blob.returncode or worktree is None:
        return None, "indexed blob or regular worktree file could not be read"
    normalized_blob = blob.stdout.replace(b"\r\n", b"\n").replace(b"\r", b"\n")
    normalized_worktree = worktree.replace(b"\r\n", b"\n").replace(b"\r", b"\n")
    if worktree != blob.stdout and normalized_worktree != normalized_blob:
        return None, f"index and worktree differ (including intent-to-add); review, then git add -- {requested}"
    return blob.stdout, ""


def _refs(owner: str) -> tuple[str, ...]:
    return tuple(f"{owner}@{pin}" for pin in _ACCEPTED[owner])


def _uses(props: dict[str, str], owner: str) -> bool:
    return set(props) == {"uses", "with"} and props["uses"] in _refs(owner)


def _accepted_text(owner: str) -> str:
    pins = _ACCEPTED[owner]
    if len(pins) == 1:
        return "requires " + pins[0]
    return (f"accepts {pins[0]} (the Action recommended before this release) "
            f"or {pins[1]} (this release's Action)")


def _pin_issue(props: dict[str, str], owner: str) -> str:
    """Explain a parsed ref mismatch without relaxing the trusted chain."""
    actual = props.get("uses", "")
    prefix = owner + "@"
    if not actual.startswith(prefix):
        return f"expected {' or '.join(_refs(owner))}; found {actual or '(no uses)'}"
    ref = actual[len(prefix):]
    kind = "unsupported SHA" if re.fullmatch(r"[0-9a-fA-F]{40}|[0-9a-fA-F]{64}", ref) else "tag or non-SHA ref"
    return f"{owner}: {kind} {ref}; this CLI {_accepted_text(owner)}"


def _with_issue(props: dict[str, str], with_values: dict[str, str], owner: str) -> str | None:
    """Name the `with:` values doctor proves when only they differ (#436).

    None when the step also carries keys other than `uses` and `with`, or an
    inline `with:` value, which the generic text still covers.
    """
    if set(props) - {"uses", "with"} or props.get("with"):
        return None

    found = ", ".join(f"{key}: {value}" for key, value in with_values.items()) or "nothing"
    return f"{owner}: doctor proves only with {_WITH_TEXT[owner]}, found {found}"


def _healthy_job(body: list[str], reasons: list[str]) -> bool:
    job_items: list[tuple[int, str, str]] = []
    for index, line in enumerate(body[1:], 1):
        if _indent(line) == 4:
            item = _mapping(line, 4)
            if item is None or item[0] in _BANNED or any(old[1] == item[0] for old in job_items):
                return False
            job_items.append((index, item[0], item[1]))
        elif _indent(line) < 6:
            return False
    if job_items != [
        (1, "runs-on", "ubuntu-latest"), (2, "steps", "")
    ]:
        return False
    step_lines = body[job_items[1][0] + 1:]
    starts = [i for i, line in enumerate(step_lines) if _indent(line) == 6]
    if starts[:1] != [0] or len(starts) != 3 or any(
        not step_lines[i].startswith("      - ") for i in starts
    ):
        return False
    parsed = []
    for pos, start in enumerate(starts):
        end = starts[pos + 1] if pos + 1 < len(starts) else len(step_lines)
        value = _step(step_lines[start:end])
        if value is None:
            return False
        parsed.append(value)
    checkout, setup, gate = parsed
    for (props, with_values), owner in ((checkout, "actions/checkout"), (setup, "actions/setup-python")):
        if _uses(props, owner) and with_values in _WITH[owner]:
            continue
        if props.get("uses") not in _refs(owner):
            reasons.append(_pin_issue(props, owner))
        elif (issue := _with_issue(props, with_values, owner)) is not None:
            reasons.append(issue)
        return False
    props, with_values = gate
    pinned = props.get("uses") in _refs(_ACTION)
    remote = set(props) == {"uses"} and not with_values and pinned
    if not pinned:
        reasons.append(_pin_issue(props, _ACTION))
    return remote


def _workflow(data: bytes, reasons: list[str]) -> tuple[list[str], bool]:
    text = _decode_workflow(data)
    if text is None:
        reasons.append("workflow is not supported UTF-8/YAML text")
        return [], True
    lines = _lines(text)
    blob = "\n".join(lines)
    candidate = ("checkwash" in blob.lower() or "greenwash" in blob.lower()
                 or "uses: ./action" in blob)
    if not lines or any("\t" in line for line in lines) or re.search(
        r"(^|[ \t])<<:|(^|[ \t])[*&][A-Za-z_]", blob
    ):
        return [], candidate
    top: list[tuple[int, str, str]] = []
    for index, line in enumerate(lines):
        if _indent(line) == 0:
            item = _mapping(line, 0)
            if item is None or any(old[1] == item[0] for old in top):
                return [], candidate
            top.append((index, item[0], item[1]))
    keys = [key for _, key, _ in top]
    if keys not in (["on", "permissions", "jobs"], ["name", "on", "permissions", "jobs"]):
        return [], candidate
    if _BANNED.intersection(keys):
        return [], candidate
    on = [item for item in top if item[1] == "on"]
    jobs = [item for item in top if item[1] == "jobs"]
    if len(on) != 1 or len(jobs) != 1 or jobs[0][2]:
        return [], candidate
    if not _unfiltered_event(lines, on[0][0], on[0][2]):
        reasons.append(_event_issue(lines, on[0][0], on[0][2]))
        return [], candidate
    permissions = next(item for item in top if item[1] == "permissions")
    name_offset = 1 if keys[0] == "name" else 0
    if top[0][0] != 0 or (name_offset and (
        not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9 ._-]*", top[0][2]) or on[0][0] != 1
    )):
        return [], candidate
    expected_permission = on[0][0] + (1 if on[0][2] else 2)
    if permissions[0] != expected_permission:
        return [], candidate
    permission_end = next(
        (i for i in range(permissions[0] + 1, len(lines)) if _indent(lines[i]) == 0), len(lines)
    )
    if (permissions[2] or permission_end != permissions[0] + 2
            or lines[permissions[0] + 1] != "  contents: read"):
        return [], candidate
    end = next((i for i in range(jobs[0][0] + 1, len(lines)) if _indent(lines[i]) == 0), len(lines))
    starts: list[tuple[int, str]] = []
    for index in range(jobs[0][0] + 1, end):
        if _indent(lines[index]) == 2:
            item = _mapping(lines[index], 2)
            if item is None or item[1] or any(name == item[0] for _, name in starts):
                return [], candidate
            starts.append((index, item[0]))
        elif _indent(lines[index]) < 4:
            return [], candidate
    if starts not in ([(jobs[0][0] + 1, "checkwash")], [(jobs[0][0] + 1, "greenwash")]):
        return [], candidate
    healthy = []
    for pos, (start, name) in enumerate(starts):
        stop = starts[pos + 1][0] if pos + 1 < len(starts) else end
        if _healthy_job(lines[start:stop], reasons):
            healthy.append(name)
    return healthy, candidate


def _workflow_gates(root: Path) -> tuple[list[tuple[str, str]], list[str]]:
    gates, incomplete = [], []
    directory = root / ".github" / "workflows"
    if not directory.is_dir():
        return gates, incomplete
    if not _plain_chain(root, ".github/workflows"):
        return gates, [".github/workflows (linked path)"]
    for path in sorted(p for p in directory.iterdir() if p.is_file() and p.suffix in {".yml", ".yaml"}):
        relative = path.relative_to(root)
        blob, issue = _tracked_blob(root, relative) if _plain_chain(root, relative) else (
            None, "linked, nonregular, or case-mismatched workflow path"
        )
        if blob is None:
            incomplete.append(f"{relative.as_posix()}: {issue}")
            continue
        reasons: list[str] = []
        names, candidate = _workflow(blob, reasons)
        rel = path.relative_to(root).as_posix()
        gates.extend((rel, name) for name in names)
        if candidate and not names:
            incomplete.append(f"{rel}: " + ("; ".join(reasons) or "unsupported or ambiguous workflow shape"))
    return gates, incomplete


def collect(root: Path) -> list[Note]:
    notes: list[Note] = []
    jobs, incomplete = _workflow_gates(root)
    hook_paths = []
    session_paths = []
    input_paths = []
    pre_tool_paths = []
    hook_issues = []
    for relative in (".claude/settings.json", ".claude/settings.local.json"):
        path = root / relative
        if not path.exists():
            continue
        try:
            settings = json.loads(path.read_text(encoding="utf-8-sig"))
            if has_stop_hook(settings):
                hook_paths.append(relative)
            if has_session_start_hook(settings):
                session_paths.append(relative)
            if stop_reads_hook_input(settings):
                input_paths.append(relative)
            # Last, so a malformed PreToolUse block still leaves the Stop
            # findings above in place (D-189).
            if has_pre_tool_use_hook(settings):
                pre_tool_paths.append(relative)
        except (OSError, ValueError, HookInstallError) as exc:
            hook_issues.append(f"{relative}: {exc}")
    any_hook_paths = [p for p in (".claude/settings.json", ".claude/settings.local.json")
                      if p in hook_paths or p in pre_tool_paths]
    precommit_blob = _read(root / ".pre-commit-config.yaml")
    precommit_installed = "checkwash" in precommit_blob or "greenwash" in precommit_blob

    if jobs:
        detail = ", ".join(f"{path} :: {job}" for path, job in jobs)
        notes.append(Note("ok", f"{len(jobs)} CI job(s) invoke checkwash", detail))
        notes.append(Note("ok", "at least one checkwash gate runs unconditionally", detail))
    elif incomplete:
        notes.append(Note(
            "warn", "workflow analysis incomplete",
            "No exact supported gate was proven. " + "; ".join(incomplete) + ". "
            "Use the three-step, hash-pinned workflow under \"Use it in CI\" in the README; "
            "direct run steps are never trusted.",
        ))
    else:
        events = " or ".join(name for name, paths in (("Stop", hook_paths), ("PreToolUse", pre_tool_paths)) if paths)
        where = [name for name, present in (
            (f"a Claude Code {events} hook configuration in " + ", ".join(any_hook_paths), bool(any_hook_paths)),
            ("pre-commit configuration", precommit_installed),
        ) if present]
        if where:
            notes.append(Note(
                "problem", "checkwash is configured locally but not in CI",
                "Found " + " and ".join(where) + ", and no exact supported workflow under "
                ".github/workflows. A local hook can be skipped and cannot stop someone else's merge.",
            ))

        else:
            notes.append(Note(
                "problem", "no checkwash gate found",
                "The checkwash command runs, but no exact supported workflow invokes checkwash "
                "and no local hook was found, so nothing blocks a merge yet. Copy the workflow "
                "under \"Use it in CI\" in the README and require its checkwash status check.",
            ))

    if any_hook_paths:
        verify = " and ".join(name for name, paths in (("Stop", hook_paths), ("PreToolUse", pre_tool_paths)) if paths)
        notes.append(Note(
            "info", "local hook configuration is not runtime verification",
            "Found " + ", ".join(any_hook_paths) + ". Doctor does not execute Claude or evaluate "
            f"its complete managed/global settings. Verify the {verify} event in your Claude runtime."
            + (" The PreToolUse ask on an ASSERT_WEAKENED Edit became a denial in a -p run under "
               "bypassPermissions (Claude Code 2.1.260, haiku, Windows); the interactive prompt is "
               "not verified in any mode."
               if pre_tool_paths else ""),
        ))
        tracked = _git_query(root, "ls-files", "-z", "--", *any_hook_paths)
        indexed_paths = tracked.stdout.split(b"\0") if tracked is not None and not tracked.returncode else []
        tracked_hooks = [path for path in any_hook_paths if path.encode("utf-8") in indexed_paths]
        if tracked_hooks:
            notes.append(Note(
                "info", "hook maintenance can change tracked guardrails",
                "Found tracked checkwash hook settings: " + ", ".join(tracked_hooks) + ". "
                "Installing or reinstalling the hook can modify these tracked guardrail files. "
                "Inspect `git diff` before committing and use the existing BASE/review process "
                "for the change. Doctor does not exempt hook maintenance from guardrail checks.",
            ))
        missing = [part for part, absent in (
            ("no `checkwash hook session-start` handler", not session_paths),
            ("no Stop handler that passes its hook input (`--hook-input stdin`)", not input_paths),
        ) if absent]
        if missing and hook_paths:
            notes.append(Note(
                "info", "the Stop hook cannot see what a session commits",
                "Found " + " and ".join(missing) + ", so the Stop hook checks the working tree "
                "against HEAD only, and work committed during a session is not analysed there. "
                "Run `checkwash hook install --agent claude-code` again (`--local`, the default, for "
                ".claude/settings.local.json; `--shared` for .claude/settings.json) to install both (#418).",
            ))
        if hook_paths and not pre_tool_paths or pre_tool_paths and not hook_paths:
            notes.append(Note(
                "info", "the PreToolUse ask and the Stop hook are not both configured",
                ("Found a Stop hook and no `checkwash hook pre-tool-use` handler, so nothing asks before an "
                 "Edit or Write weakens a test; `checkwash hook install --agent claude-code --local` adds it to "
                 ".claude/settings.local.json (D-189)." if hook_paths else
                 "Found a `checkwash hook pre-tool-use` handler and no Stop hook, so edits made any other "
                 "way, through Bash for one, are not checked before the session stops."),
            ))
    if hook_issues:
        notes.append(Note("info", "local hook configuration could not be read", "; ".join(hook_issues)))

    notes.append(Note(
        "info", "checkwash cannot tell whether the check is *required*",
        "Branch protection lives behind GitHub API token scopes this tool does not ask for. "
        "A green job that is not a required status check does not prevent a merge. Make the "
        "job's status check required; \"Use it in CI\" in the README gives the steps and this "
        "command: gh api repos/OWNER/REPO/rulesets --method POST --input action/required-ruleset.json",
    ))
    notes.append(Note(
        "info", "checkwash cannot block when it does not run",
        "A change that deletes or disables the checkwash job disarms it in the same diff. "
        "Protect the workflow file with code owners or required review on .github/**.",
    ))
    cfg_rel = resolve_config_file(str(root), "config.toml")
    allow_rel = resolve_config_file(str(root), "allow.toml")
    cfg = root.joinpath(*cfg_rel.split("/"))
    allow = root.joinpath(*allow_rel.split("/"))
    notes.append(Note(
        "info", "configuration is read from the BASE side of the diff",
        f"config: {'present (' + cfg_rel + ')' if cfg.exists() else 'absent (defaults)'}; "
        f"allowlist: {'present (' + allow_rel + ')' if allow.exists() else 'absent'}. A new allowlist entry "
        "takes effect on the next diff and must be committed.",
    ))
    for name in ("config.toml", "allow.toml"):
        present = [f"{directory}/{name}" for directory in CONFIG_DIRS
                   if root.joinpath(directory, name).is_file()]
        if len(present) > 1:
            notes.append(Note(
                "info", "policy file precedence in this working tree",
                f"For {name}, {present[0]} takes precedence over {', '.join(present[1:])}. "
                "Precedence is per filename. Review both files before migrating or editing "
                "a shadowed policy. Doctor describes the working tree; check reads the "
                "reviewed BASE, whose files may differ.",
            ))
    ledger_data = allow.read_bytes() if allow.exists() else None
    ledger = summarize_allowlist(ledger_data, datetime.date.today(), path=allow_rel)
    if ledger.parse_error:
        notes.append(Note("warn", "allow.toml could not be parsed; no exemptions are active", ledger.parse_error))
    else:
        detail = (
            f"{ledger.entries} entries in {allow_rel}; {ledger.active} active today, "
            f"{ledger.expired} expired, {ledger.over_cap} over the {MAX_EXPIRY_DAYS}-day cap (ignored on read), "
            f"{ledger.retired} retired fingerprint(s), {ledger.invalid} invalid entry/entries."
            " Active counts describe key/expiry eligibility; a matching finding is still required."
            if ledger.present else
            f"no allow.toml yet. `checkwash allow` writes one; expiry is capped at "
            f"{MAX_EXPIRY_DAYS} days. Commit it and put `{allow_rel.split('/')[0]}/` in CODEOWNERS."
        )
        notes.append(Note("info", f"allowlist expiry is capped at {MAX_EXPIRY_DAYS} days", detail))
        if ledger.retired or ledger.invalid:
            entries, _error = load_allowlist(ledger_data, path=allow_rel)
            notes.append(Note(
                "warn", "retired or invalid exemptions are ignored",
                f"{allow_rel}: " + "; ".join(fingerprint_diagnostics(entries))
                + ". Re-run the intended diff and review a new content-bound fingerprint; "
                "old approvals cannot be migrated without reviewing the actual change.",
            ))
        if ledger.present:
            entries, _error = load_allowlist(ledger_data, path=allow_rel)
            for message in namespace_diagnostics(entries):
                notes.append(Note("warn", "unrecognized or wrong-ledger exemption namespace", message))
    notes.append(Note(
        "info", "use a three-dot range for pull requests",
        "`checkwash check BASE...HEAD` resolves through the merge base. A two-dot range drags "
        "in base-branch commits; a single range cannot see a wash split across PRs.",
    ))
    return notes


_SYMBOL = {"ok": "OK  ", "warn": "WARN", "problem": "FAIL", "info": "note"}


def run(root: str = ".", stream=None) -> int:
    """Print the report. 0 when nothing is wrong, 1 when something is."""
    import sys

    stream = stream or sys.stdout
    def w(text):
        write_text(text, stream)

    notes = collect(Path(root))
    for note in notes:
        w(f"{_SYMBOL[note.level]}  {note.title}\n")
        for line in _wrap(note.detail):
            w(f"      {line}\n")
        w("\n")
    problems = [n for n in notes if n.level == "problem"]
    warns = [n for n in notes if n.level == "warn"]
    w(
        f"summary: {len(problems)} problem(s), {len(warns)} warning(s). "
        "checkwash cannot verify branch protection; see the note above.\n"
    )
    return 1 if problems or warns else 0


def _wrap(text: str, width: int = 76) -> list[str]:
    words, lines, current = text.split(), [], ""
    for word in words:
        if current and len(current) + 1 + len(word) > width:
            lines.append(current)
            current = word
        else:
            current = f"{current} {word}".strip()
    if current:
        lines.append(current)
    return lines
