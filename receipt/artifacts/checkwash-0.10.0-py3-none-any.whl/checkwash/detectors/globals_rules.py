"""Detectors driven purely by DiffGlobals: one small pure function each.

SNAPSHOT_CODE_COCHANGE, BROAD_EXCEPT_ADDED, SUPPRESSION_ADDED,
CI_WORKFLOW_TOUCHED, GUARDRAIL_TOUCHED, EXEMPTION_ADDED, IMPORT_UNRESOLVED,
SCOPE_DRIFT, HIDDEN_UNICODE.
"""

from __future__ import annotations

from checkwash.change import EngineError
from checkwash.ci_control_flow import became_unanalysable
from checkwash.findings import (
    Evidence,
    Finding,
    change_identity,
    make_change_fingerprint,
    make_fingerprint,
)
from checkwash.ir.model import IR


def detect_snapshot_cochange(ir: IR) -> list[Finding]:
    g = ir.globals
    if not g.snapshot_files_changed or not g.prod_files_changed or g.test_logic_changed:
        return []
    files = {file.path: file for file in ir.files}
    for path in sorted(set(g.snapshot_files_changed) | set(g.prod_files_changed)):
        if path not in files:
            raise EngineError(f"SNAPSHOT_CODE_COCHANGE/{path}: missing file evidence")
    production = [change_identity(files[path]) for path in sorted(set(g.prod_files_changed))]
    return [
        Finding(
            rule="SNAPSHOT_CODE_COCHANGE",
            severity="warn",
            message=(
                f"snapshot/golden file changed together with prod code "
                f"({', '.join(g.prod_files_changed[:3])}) and no test logic changed"
            ),
            path=path,
            unit=None,
            fingerprint=make_change_fingerprint(
                "SNAPSHOT_CODE_COCHANGE", files[path],
                {"production_changes": production, "test_logic_changed": g.test_logic_changed},
            ),
        )
        for path in g.snapshot_files_changed
    ]


def detect_broad_except(ir: IR) -> list[Finding]:
    return [
        Finding(
            rule="BROAD_EXCEPT_ADDED",
            severity="warn",
            message=f"broad exception handler added ({text})",
            path=path,
            unit=None,
            after=Evidence(text=text, span=(0, 0)),
            fingerprint=make_fingerprint("BROAD_EXCEPT_ADDED", path, None, text),
        )
        for path, text in ir.globals.broad_excepts_added
    ]


def detect_unparseable_test(ir: IR) -> list[Finding]:
    """A test file checkwash could not parse is a test file it did not check.

    Silence here made the verdict depend on the analysing interpreter's
    grammar version, which contradicts the cross-version determinism claim.
    A file that parsed on the base side and stopped parsing on the head side
    is the suspicious transition and carries no de-escalation.
    """
    files = {file.path: file for file in ir.files}
    findings = []
    for path, was_parseable in ir.globals.unparseable_tests:
        if path not in files:
            raise EngineError(f"TEST_FILE_UNPARSEABLE/{path}: missing file evidence")
        findings.append(
            Finding(
                rule="TEST_FILE_UNPARSEABLE",
                severity="warn",
                message=(
                    f"{path}: test file could not be parsed, so none of its oracles were checked"
                    + (" — it parsed before this diff" if was_parseable else "")
                ),
                path=path,
                unit=None,
                after=Evidence(text=path, span=(0, 0)),
                fingerprint=make_change_fingerprint(
                    "TEST_FILE_UNPARSEABLE", files[path], {"was_parseable": was_parseable},
                ),
            )
        )
    return findings


def detect_suppression(ir: IR) -> list[Finding]:
    findings = []
    for entry in ir.globals.suppressions_added:
        path, _, text = entry.partition(":")
        findings.append(
            Finding(
                rule="SUPPRESSION_ADDED",
                severity="warn",
                message=f"lint/type suppression added ({text})",
                path=path,
                unit=None,
                after=Evidence(text=text, span=(0, 0)),
                fingerprint=make_fingerprint("SUPPRESSION_ADDED", path, None, text),
            )
        )
    return findings


def detect_ci_touched(ir: IR) -> list[Finding]:
    files = {file.path: file for file in ir.files}
    reasons_by_path: dict[str, list[str]] = {}
    for path, line in ir.globals.ci_weakening_lines:
        reasons_by_path.setdefault(path, []).append(line)
    findings = []
    for path in ir.globals.ci_files_changed:
        if path not in files:
            raise EngineError(f"CI_WORKFLOW_TOUCHED/{path}: missing file evidence")
        reasons = reasons_by_path.get(path, [])
        # A file the reader can no longer read at head has no weakened command
        # to name, so its reason is not labelled one (#196 191.3).
        weakened = [line for line in reasons if not became_unanalysable(line)]
        shown = weakened[0] if weakened else reasons[0] if reasons else None
        findings.append(
            Finding(
                rule="CI_WORKFLOW_TOUCHED",
                severity="warn",
                message=(
                    "CI configuration changed"
                    + (f"; test command weakened: {shown}" if weakened else f"; {shown}" if reasons else "")
                ),
                path=path,
                unit=None,
                after=Evidence(text=shown, span=(0, 0)) if shown is not None else None,
                fingerprint=make_change_fingerprint(
                    "CI_WORKFLOW_TOUCHED", files[path], {"weakening_lines": sorted(reasons)},
                ),
            )
        )
    return findings


def detect_conftest_prod_patch(ir: IR) -> list[Finding]:
    """A conftest fixture that swaps first-party code out from under the suite.

    Every assertion then runs against the stand-in while production and test
    files stay byte-identical — the escape a real agent found on the decoy
    probe arm (2026-08-04). Stubbing stdlib or third-party dependencies is
    normal hygiene and is not reported.
    """
    # The presence scan and the installation trace can both prove the same
    # act (e.g. an unconditional setattr); their evidence texts differ only
    # in whitespace. One finding per act.
    seen = set()
    findings = []
    for path, text in ir.globals.conftest_prod_patches:
        key = (path, "".join(text.split()))
        if key in seen:
            continue
        seen.add(key)
        findings.append(
            Finding(
                rule="CONFTEST_PATCHES_PROD",
                severity="warn",  # gating escalates without a prod change to explain it
                message=(
                    f"conftest fixture patches code under test ({text}) — "
                    f"assertions then check the replacement, not the product"
                ),
                path=path,
                unit=None,
                after=Evidence(text=text, span=(0, 0)),
                fingerprint=make_fingerprint("CONFTEST_PATCHES_PROD", path, None, text),
            )
        )
    return findings


def _guardrail_message(ir: IR, path: str) -> str:
    shadow = ir.globals.policy_shadows.get(path)
    if shadow is not None:
        descriptions = {
            "config_relaxation": "relaxes the effective BASE policy",
            "config_uncomparable": "changes policy whose nonweakening cannot be established",
            "config_nonweakening": "preserves or tightens the effective BASE policy",
            "allow_rewrite": "rewrites or revokes the effective BASE exemption ledger",
        }
        return (f"guardrail file created ({path}) shadows {shadow['base_path']}: "
                + descriptions[shadow["kind"]])
    if path in ir.globals.guardrail_configs_created_loosening:
        return (
            f"guardrail file created ({path}) with a detector disabled or fail_on raised"
            " — a config that did not exist was the defaults, and this relaxes them"
        )
    verb = "created" if path in ir.globals.guardrail_files_created else "changed"
    return f"guardrail file {verb} ({path}) — agent constraints are part of the oracle"


def detect_guardrail(ir: IR) -> list[Finding]:
    files = {file.path: file for file in ir.files}
    for path in ir.globals.guardrail_files_changed:
        if path not in files:
            raise EngineError(f"GUARDRAIL_TOUCHED/{path}: missing file evidence")
    findings = [
        Finding(
            rule="GUARDRAIL_TOUCHED",
            severity="warn",  # gating E4 raises to critical
            message=_guardrail_message(ir, path),
            path=path,
            unit=None,
            fingerprint=make_change_fingerprint(
                "GUARDRAIL_TOUCHED", files[path],
                {
                    "created": path in ir.globals.guardrail_files_created,
                    "created_loosening": path in ir.globals.guardrail_configs_created_loosening,
                    **({"policy_shadow": ir.globals.policy_shadows[path]} if path in ir.globals.policy_shadows else {}),
                },
            ),
        )
        for path in ir.globals.guardrail_files_changed
    ]
    findings.extend(
        Finding(
            rule="EXEMPTION_ADDED",
            severity="warn",
            message=f"this diff exempts itself: {fingerprint} — review the reason",
            path=ir.globals.exemption_ledger_path,
            unit=None,
            after=Evidence(text=fingerprint, span=(0, 0)),
            fingerprint=make_fingerprint("EXEMPTION_ADDED", ir.globals.exemption_ledger_path, None, fingerprint),
        )
        for fingerprint in ir.globals.exemptions_added
    )
    return findings


def detect_import_unresolved(ir: IR) -> list[Finding]:
    return [
        Finding(
            rule="IMPORT_UNRESOLVED",
            severity="warn",
            message=(
                f"new import '{module}' resolves against neither the stdlib, the repo, "
                "nor declared dependencies (hallucination fingerprint)"
            ),
            path=path,
            unit=None,
            after=Evidence(text=f"import {module}", span=(0, 0)),
            fingerprint=make_fingerprint("IMPORT_UNRESOLVED", path, None, module),
        )
        for path, module in ir.globals.unresolved_imports
    ]


def detect_scope_drift(ir: IR) -> list[Finding]:
    files = {file.path: file for file in ir.files}
    for path, _role in ir.globals.scope_drift:
        if path not in files:
            raise EngineError(f"SCOPE_DRIFT/{path}: missing file evidence")
    role_weight = {"prod": "prod", "ci": "ci", "guardrail": "guardrail"}
    return [
        Finding(
            rule="SCOPE_DRIFT",
            severity="warn",
            message=(
                f"changed file is outside the task's declared scope "
                f"(role: {role_weight.get(role, role)})"
            ),
            path=path,
            unit=None,
            fingerprint=make_change_fingerprint(
                "SCOPE_DRIFT", files[path],
                {"scope_allow": sorted(set(ir.globals.scope_allow)), "role": role},
            ),
        )
        for path, role in ir.globals.scope_drift
    ]


def detect_hidden_unicode(ir: IR) -> list[Finding]:
    return [
        Finding(
            rule="HIDDEN_UNICODE",
            severity="warn",  # gating raises to high
            message=f"invisible/direction-control character {codepoint} in changed line",
            path=path,
            unit=None,
            after=Evidence(text=line, span=(0, 0)),
            fingerprint=make_fingerprint("HIDDEN_UNICODE", path, None, f"{codepoint}:{line}"),
        )
        for path, codepoint, line in ir.globals.hidden_unicode
    ]
