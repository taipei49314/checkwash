"""Pipeline orchestration: FileChange list → IR → findings → verdict.

Source-agnostic: gitio and the .gwcase runner both produce FileChange lists,
so fixtures exercise the exact same pipeline the CLI runs.

Role / CI / evidence helpers live in checkwash.roles, .ci, .evidence (E5).
"""

from __future__ import annotations

import ast
import datetime
import hashlib
import re
from collections import Counter
from collections.abc import Callable
from dataclasses import replace

from checkwash.allowlist import AllowEntry
from checkwash.change import EngineError, FileChange, UnreadSide
from checkwash.opaque import opaque_error, split_inventory
from checkwash.ci import (
    _ci_base_surface,
    _deps_differ,
    _is_ci_workflow,
    _runs_tests,
    _scan_ci_weakening,
)
from checkwash.ci_control_flow import holds_runner_site
from checkwash.config import Config
from checkwash.policy_shadow import config_transition, shadow_baseline
from checkwash.oracle_credit import mark_contexts
from checkwash.collection_inventory import _runner as _collection_runner, collection_inventory_changes, collection_sources, opaque_reached
from checkwash.conftest_context import ConftestContext
from checkwash.contract import Contract
from checkwash.deps import MANIFESTS
from checkwash.detectors import REGISTRY
from checkwash.evidence import (
    _MAX_DUP_READS,
    _gate_constants,
    _mark_weakened_guards,
    _module_of,
    _record_callers,
    _scope_match,
    _suppression_texts,
)
from checkwash.findings import Finding
from checkwash.frontends.javascript.frontend import parse_javascript
from checkwash.frontends.javascript.module_mocks import _EXTENSIONS as _JS_EXTENSIONS, module_mock_events
from checkwash.frontends.javascript.setup_files import is_carrier, listed_setup_files, setup_file_events
from checkwash.frontends.javascript.paths import is_js_test_file, is_js_test_path
from checkwash.frontends.javascript.runners import (
    collected,
    collection_continues,
    focus_is_file_scoped,
    focus_is_innermost,
    may_be_evidenced_test_path,
    runner_evidence,
)
from checkwash.frontends.python.frontend import (
    ParsedFile,
    conftest_patch_targets,
    normalize_source,
    parse_conftest_level,
    parse_python,
)
from checkwash.frontends.python.binding_canonical import binding_key as _binding_key
from checkwash.frontends.python.helper_skips import HelperModule
from checkwash.frontends.python.setup_skip_controls import ConftestLevel, unreadable_level
from checkwash.frontends.python.root_oracles import project_root_oracles, root_caller_unchanged, root_imports, transparent_root_helpers
from checkwash.frontends.python.normalization import mark_normalization_equivalence
from checkwash.frontends.python.param_input_identity import mark_param_input_identity
from checkwash.frontends.python.table_normalization import mark_table_normalization
from checkwash.frontends.python.table_oracles import project_table_consolidation
from checkwash.frontends.python.classic_raises import mark_classic_exception_removal
from checkwash.frontends.python.empty_parameter_sets import mark_empty_parameter_introduction
from checkwash.frontends.python.neutralizing_aliases import mark_neutralizing_aliases
from checkwash.frontends.python.class_exception_aliases import mark_class_exception_aliases
from checkwash.frontends.python.function_exception_aliases import mark_function_exception_aliases
from checkwash.frontends.python.manual_unittest_suites import project_manual_unittest_suites
from checkwash.frontends.python.type_comparison_oracles import mark_type_comparisons
from checkwash.frontends.python.builtin_normalization_oracles import mark_builtin_normalizations
from checkwash.frontends.python.literal_all_oracles import mark_literal_all
from checkwash.frontends.python.empty_length_guards import mark_empty_length_guards
from checkwash.frontends.python.truthiness_oracles import project_truthiness_oracles
from checkwash.frontends.python.standin_installations import installation_events
from checkwash.frontends.python.subject_replacements import subject_replacement_events
from checkwash.frontends.python.callable_fixture_subjects import callable_fixture_subject_events
from checkwash.frontends.python.local_parameter_implementations import local_parameter_implementation_events
from checkwash.frontends.python.fixture_local_implementations import fixture_local_implementation_events
from checkwash.frontends.python.parametrized_string_standins import parametrized_string_standin_events
from checkwash.shadow import _PYTEST_CONFIGS, find_runtime_subject_shadows
from checkwash.frontends.python.expected_provenance import importer_changes as expected_importer_changes, mark_expected_provenance
from checkwash.frontends.javascript.expected_provenance import mark_js_expected_provenance
from checkwash.gating import apply_gates, unit_is_live
from checkwash.arrival_collection import arrival_collector
from checkwash.ir.astutil import same_expr
from checkwash.ir.diffalign import align_file
from checkwash.ir.markers import parse_text
from checkwash.ir.model import IR, ChangeEvidence, DiffGlobals, Marker, judged_as_test, normalize_text
from checkwash.pyenv import known_baseline
from checkwash.report.context import ReportContext
from checkwash.roles import (
    _MAX_ORACLE_READS,
    _added_lines,
    _is_inert,
    _is_runner_script,
    _mentions_test_runner,
    _one_hop_runners,
    _runner_shape,
    _shell_shebang,
    _test_command_manifest,
    _test_commands_changed,
    collectable,
    is_artifact,
    is_test_support_path,
)

__all__ = [
    "EngineError",
    "FileChange",
    "analyze",
    "build_ir",
    "collectable",
    "is_artifact",
    "run_detectors",
    "_is_runner_script",
]


# Roles whose files are supervised for their own sake. Moving a file out of
# one of these is itself the event, not a neutral relocation.
_SUPERVISED_ROLES = frozenset({"guardrail", "ci", "test", "conftest", "snapshot"})

# SPEC section 2 resolves these roles before `test`, and a JS runner's default
# layout does not outrank them. Jest collects every file beneath `__tests__/`,
# but `__tests__/__snapshots__/out.js` is a stored expectation and
# `.claude/hooks/__tests__/guard.js` an agent constraint; making them only
# tests switched off EXPECTED_VALUE_CHANGED and GUARDRAIL_TOUCHED (#175
# review). Such a file keeps that public role and carries test obligations
# beside it: making it only that role switched off every test rule instead,
# so a weakened `.github/workflows/x.test.ts` passed at warn (#197). A
# collectable Python path does the same: `tests/golden/test_x.py` is a
# snapshot and is judged as a test beside it (#219).
_ROLES_BEFORE_TEST = frozenset({"guardrail", "ci", "snapshot", "lockfile", "conftest"})

# The conftest files a diff's test modules sit below, read from the head
# snapshot (#223). The stand-in context's limits: past them the run is an
# engine error, never a chain cut short.
_MAX_CHAIN_READS = 4096
_MAX_CHAIN_BYTES = 64_000_000


def _js_test(path: str, role: str, *sides: bytes | None) -> bool:
    """Does this JS/TS test file take the public role `test`?

    A path whose role resolved to one of `_ROLES_BEFORE_TEST` keeps that role
    and carries test obligations beside it instead (#197). The JS parse gate
    and rename expansion read `is_js_test_file` itself, which no role
    withdraws.
    """
    return role not in _ROLES_BEFORE_TEST and is_js_test_file(path, *sides)


def _scope_role(role: str, table_role: str, *sides: ParsedFile | None) -> str:
    """The role E7 judges an out-of-scope file by (#196 186.8).

    A test role read from the path alone gives way to the SPEC §2 table role
    unless the file declares a test on either side. With nothing to judge, no
    test rule reads the file, so its test role must not disarm E7 either.
    Every other rule keeps the test role, and no production credit comes back.
    """
    if role != table_role and not any(side is not None and side.declares_tests for side in sides):
        return table_role
    return role


def _innermost_focus(data: bytes, manifest):
    """Is this side's runner proven to run only the innermost focus? Asked
    only when the side holds focus, so the manifest stays unread otherwise
    (#196 187.2)."""
    return lambda: focus_is_innermost(runner_evidence(data, manifest))


def _base_root_file(changes: list[FileChange], root_reader, name: str,
                    set_aside: list[FileChange] | tuple[FileChange, ...] = ()):
    """A reader of one root file as the base side holds it.

    In the diff, its before side. Otherwise the head snapshot holds it
    unchanged, so that is the base side too (#196 186.7). Read once, and only
    when asked. A change set aside unread (#415) is in the diff as well: a
    readable before side is the base, and an unread one refuses, naming it,
    rather than taking the head bytes for the base.
    """
    read: list[bytes | None] = []

    def base() -> bytes | None:
        if not read:
            for change in (*changes, *set_aside):
                paths = (change.path.replace("\\", "/"), (change.old_path or "").replace("\\", "/"))
                if name in paths:
                    unread = _base_unread(change)
                    if unread is not None:
                        raise unread.refusal()
                    read.append(change.before)
                    break
            else:
                read.append(root_reader(name) if root_reader is not None else None)
        return read[0]

    return base


def _base_manifest(changes: list[FileChange], root_reader,
                   set_aside: list[FileChange] | tuple[FileChange, ...] = ()):
    """A reader of the base side's root package.json, for runner evidence,
    read only when a JS test file names no runner itself."""
    return _base_root_file(changes, root_reader, "package.json", set_aside)


def _base_unread(change: FileChange) -> UnreadSide | None:
    """The change's base side, when it was over the limit and not read (#415)."""
    if not change.unread or change.before is not None or change.status == "added":
        return None
    return next((side for side in change.unread if side.side == "base"), change.unread[0])


def _shebang_side(path: str, sides: tuple[bytes | None, ...],
                  unread: tuple[UnreadSide, ...]) -> UnreadSide | None:
    """The first unread side whose prefix gives `path` runner shape (#455).

    `_shell_shebang` reads only the first line within a side's first
    SHEBANG_PREFIX_BYTES bytes, and an unread side's prefix is those bytes,
    verified against the blob's object identity for a Git side. So a prefix
    answers exactly as the whole side would. The path exclusions are
    `_runner_shape`'s: a Python file, or a JS/TS test file judged on the
    readable sides, is never a runner by shape. A side whose prefix was not
    read answers nothing here.
    """
    if path.endswith(".py") or is_js_test_file(path, *sides):
        return None
    return next((side for side in unread if side.prefix is not None and _shell_shebang(side.prefix)), None)


def _detector_must_read(path: str, config: Config, change: FileChange,
                        scope_allow: list[str], listed_setup=None) -> bool:
    """Must a detector read this path's content (#415)?

    The runtime-provider pass reads every Python module the diff adds,
    deletes, renames or edits, whatever its role, because any of them can
    change which provider a test's import resolves to, and every pytest
    configuration at any depth for the search order it sets. It also reads
    a CI file, a file shaped like a runner script and a file with no dot in
    its name (for a shebang) as controls that can reorder that search, and
    the one-hop scan follows `./build/test.sh` from a changed script into
    whatever it names. None of these skips generated output, so neither does
    this. A runner-shaped file can be promoted to CI by what it says, which
    an unread side does not show. A shell shebang on an unread side is read
    from the side's prefix (#455), so it gives runner shape whatever the
    path's suffix, as it would at any size, and a shebang is the only shape
    a file with no extension has: such a file refuses only when a side's
    prefix was not read. Collection reads any file under the root
    `scripts/` directory, unless generated, for the pytest runs a root
    config governs (#196 184.3).

    Past those, generated output is skipped whatever its role. The test
    rules parse JS/TS test files, the guardrail rules read their files, a
    manifest naming the test command is promoted to CI by what it says, and
    EXPECTED_VALUE_CHANGED and SCOPE_DRIFT bind a stored expectation or an
    out-of-scope file to the digests of its content. A JS setup file the
    runner loads before every test file is read for the stand-ins it
    installs (#218): a named one, or one the base side's root package.json
    lists (`listed_setup` reads those, only when asked). Everything else
    (images, data, lockfiles, documentation, non-Python production sources)
    feeds only repair evidence, which an unread side never earns.
    """
    base = path.rsplit("/", 1)[-1]
    if path.endswith(".py") or base in _PYTEST_CONFIGS:
        return True
    sides = (change.before, change.after)
    role = config.role_of(path)
    if (role == "ci" or _runner_shape(path, *sides) or _shebang_side(path, sides, change.unread) is not None
            or _collection_runner(path)):
        return True
    # A shell shebang is the only runner shape an extensionless file has
    # (`scripts/test`, THREATMODEL 62). Each unread side's prefix answers
    # that question as the whole side would, so the file is judged like any
    # other unread path; only a side whose prefix was not read (a Git side
    # over the stream ceiling) still hides a shebang, and refuses (#455).
    if "." not in base.lstrip(".") and any(side.prefix is None for side in change.unread):
        return True
    if is_artifact(path):
        return False
    if role in ("guardrail", "snapshot"):
        return True
    if is_js_test_path(path) or may_be_evidenced_test_path(path):
        return True
    if _test_command_manifest(path) is not None:
        return True
    if is_carrier(path, frozenset()):
        return True
    if listed_setup is not None and path.endswith(_JS_EXTENSIONS) and is_carrier(path, listed_setup()):
        return True
    return bool(scope_allow) and not any(_scope_match(path, glob) for glob in scope_allow)


def _set_aside_unread(changes: list[FileChange], config: Config, scope_allow: list[str],
                      root_reader=None) -> tuple[list[FileChange], list[FileChange]]:
    """(readable changes, changes carried unread) (#415).

    A change with a side over the source byte limit holds no bytes for that
    side. If a detector must read either of its paths, the run refuses,
    naming path, side, size and limit; a side whose prefix holds the shell
    shebang is the side named (#455). Otherwise the whole change is set
    aside before any pass: no detector reads it and it earns no repair
    evidence, neither as an opaque change nor as changed symbols (#419). An
    unread side's prefix only ever answers the shebang question.

    The setup files the base package.json lists are asked last: package.json
    must be read itself, so by then it is readable in the diff or unchanged.
    """
    readable = [change for change in changes if not change.unread]
    unread = [change for change in changes if change.unread]

    def paths(change: FileChange) -> list[str]:
        return sorted({change.path.replace("\\", "/"), (change.old_path or change.path).replace("\\", "/")})

    for change in unread:
        if any(_detector_must_read(path, config, change, scope_allow) for path in paths(change)):
            raise _refused_side(change, paths(change)).refusal()
    listed: list[frozenset[str]] = []

    def listed_setup() -> frozenset[str]:
        if not listed:
            listed.append(listed_setup_files(_base_manifest(readable, root_reader)()))
        return listed[0]

    for change in unread:
        if any(_detector_must_read(path, config, change, scope_allow, listed_setup) for path in paths(change)):
            raise _refused_side(change, paths(change)).refusal()
    return readable, unread


def _refused_side(change: FileChange, paths: list[str]) -> UnreadSide:
    """The side a size refusal of `change` names (#415, #455).

    An unread side whose prefix holds a shell shebang that gives one of the
    change's paths runner shape, so the side that holds the shebang is
    named; otherwise the first unread side, as before.
    """
    sides = (change.before, change.after)
    for path in paths:
        side = _shebang_side(path, sides, change.unread)
        if side is not None:
            return side
    return change.unread[0]


def _shebang_free(unread_changes: list[FileChange]) -> frozenset[str]:
    """The paths of set-aside changes no side of which holds a shell shebang (#455).

    A readable side is known whole and an unread side by its prefix, which
    answers `_shell_shebang` as the whole side would; a side without a
    prefix is not known, so its change is left out. The runtime-provider
    pass skips such a path where it would read a dot-less path for a
    shebang: none is there, so the path holds no runner invocation on either
    side, and reading it would refuse, since its head bytes are not its base
    side.
    """
    free: set[str] = set()
    for change in unread_changes:
        if any(side.prefix is None or _shell_shebang(side.prefix) for side in change.unread):
            continue
        if _shell_shebang(change.before) or _shell_shebang(change.after):
            continue
        free.update(path.replace("\\", "/") for path in (change.path, change.old_path) if path)
    return frozenset(free)


def _guard_unread_reads(reader, unread_changes: list[FileChange], *, batch: bool = False):
    """`reader`, refusing a path set aside unread (#415).

    The readers serve the head snapshot for a path the diff does not hold,
    for both sides: a path absent from the changes is unchanged. A path set
    aside unread did change and has a side nobody read, so a reader that
    reaches for it refuses, naming that side, instead of handing over head
    bytes as the base side or bytes the limit kept out.
    """
    if reader is None or not unread_changes:
        return reader
    set_aside: dict[str, UnreadSide] = {}
    for change in unread_changes:
        for path in (change.path, change.old_path):
            if path:
                key = path.replace("\\", "/")
                named = [side for side in change.unread if side.path.replace("\\", "/") == key]
                set_aside.setdefault(key, (named or list(change.unread))[0])

    def refuse(path) -> None:
        if isinstance(path, str):
            side = set_aside.get(path.replace("\\", "/"))
            if side is not None:
                raise side.refusal()

    if batch:
        def read_many(paths):
            paths = list(paths)
            for path in paths:
                refuse(path)
            return reader(paths)
        return read_many

    def read(path, *args, **kwargs):
        refuse(path)
        return reader(path, *args, **kwargs)
    return read


def _change_evidence(change: FileChange, rename_destinations: dict[str, str]) -> ChangeEvidence:
    """Retain content identities only; canonicalize CRLF without erasing bytes."""
    return ChangeEvidence(
        before_sha256=(hashlib.sha256(change.before.replace(b"\r\n", b"\n")).hexdigest()
                       if change.before is not None else None),
        after_sha256=(hashlib.sha256(change.after.replace(b"\r\n", b"\n")).hexdigest()
                      if change.after is not None else None),
        old_path=change.old_path.replace("\\", "/") if change.old_path else None,
        rename_to=(rename_destinations.get(change.path.replace("\\", "/"))
                   if change.status == "deleted" else None),
    )


def _expand_renames(changes: list[FileChange], config: Config,
                    manifest: Callable[[], bytes | None] | None = None,
                    python_excludes: Callable[[str], bool] | None = None) -> list[FileChange]:
    """A rename that moves a test file out of collection is a disappearance.

    git's rename folding would otherwise analyse only the new path: `git mv
    tests/test_x.py attic/legacy.py` (R100) erased every unit from analysis
    with zero findings (confirmed red-team bypass). The added half is marked
    synthetic so relocated bytes don't count as a "non-trivial prod change"
    and defuse E1.

    pytest's default patterns judged a Python path alone, so `git mv
    test_app.py app_test.py` under `python_files = test_*.py` kept every unit
    aligned and silent while pytest stopped running them. A Python path the
    head's own configuration certainly leaves out, where it would collect the
    old path, has left collection too (`python_excludes`, D-193); an unknown
    configuration keeps the default reading.
    """
    expanded: list[FileChange] = []
    for change in changes:
        old = (change.old_path or "").replace("\\", "/")
        new = change.path.replace("\\", "/")
        if old and old != new:
            old_role = config.role_of(old)
            new_role = config.role_of(new)
            # Collection continuity ignores roles: a runner that collected
            # the old path collects the new one whatever role that path holds,
            # and the destination is judged as a test either way (#197 Q2).
            # A JS file's runner is the one its base side or the base
            # manifest proves; without that proof the rows form a union. The
            # runners match case-sensitively, so continuity does too (#196
            # 186.7, 186.3; `frontends/javascript/runners.py`).
            if is_js_test_file(old, change.before):
                old_test = True
                new_test = collection_continues(old, new, runner_evidence(change.before, manifest))
            else:
                # A Python test file is a collectable one, whatever its role
                # (219.Q1): pytest still collects `tests/golden/test_x.py`.
                old_test = collectable(old)
                new_test = is_js_test_file(new, change.after) or collectable(new)
                if (old_test and new_test and python_excludes is not None and not is_js_test_file(new, change.after)
                        and python_excludes(new) and not python_excludes(old)):
                    new_test = False
            # Moving a file out of a supervised role is a way of escaping
            # supervision: `git mv AGENTS.md docs/AGENTS.old` or a workflow
            # out of .github/workflows/ silenced the guardrail and CI rules
            # entirely. Any such rename is expanded so the old path is still
            # judged under the role it had.
            escaped = old_role in _SUPERVISED_ROLES and new_role != old_role
            if (old_test and not new_test) or escaped:
                expanded.append(FileChange(old, "deleted", change.before, None))
                expanded.append(
                    FileChange(new, "added", None, change.after, synthetic="renamed_from_test")
                )
                continue
        expanded.append(change)
    return expanded

# Invisible / direction-control characters (SPEC: HIDDEN_UNICODE).
_HIDDEN_CODEPOINTS = frozenset(
    [0x200B, 0x200C, 0x200D, 0x200E, 0x200F, 0x00AD]
    + list(range(0x202A, 0x202F))
    + list(range(0x2066, 0x206A))
    + [0xFEFF]
)


def _decode(data: bytes | None) -> str:
    if not data:
        return ""
    return data.decode("utf-8-sig", errors="replace").replace("\r\n", "\n").replace("\r", "\n")


def _added_lines(before: bytes | None, after: bytes | None) -> list[str]:
    b = Counter(_decode(before).split("\n"))
    lines = []
    for line in _decode(after).split("\n"):
        if b[line] > 0:
            b[line] -= 1
        else:
            lines.append(line)
    return lines


def _scan_hidden_unicode(g: DiffGlobals, path: str, before: bytes | None, after: bytes | None) -> None:
    # Source files only. Data fixtures legitimately contain bidi/zero-width
    # characters (URL-parser test vectors), and binary blobs decode into
    # garbage that matches by accident — both confirmed on the FP sweep.
    if not path.endswith(".py"):
        return
    if after is None or len(after) > 1_000_000 or b"\x00" in after:
        return
    for line in _added_lines(before, after):
        hit = next((ch for ch in line if ord(ch) in _HIDDEN_CODEPOINTS), None)
        if hit is not None:
            escaped = "".join(
                f"\\u{ord(c):04x}" if ord(c) in _HIDDEN_CODEPOINTS else c for c in line
            )
            g.hidden_unicode.append((path, f"U+{ord(hit):04X}", escaped.strip()[:200]))

_OWN_CONFIG_PATHS = (".checkwash/config.toml", ".greenwash/config.toml")


def _created_config_loosens(after: bytes | None) -> bool:
    """A checkwash config that did not exist was the defaults. A new one that
    disables a detector or raises `fail_on` above the default relaxes them:
    the two-commit plant of issue #79 (create the config at warn, weaken the
    test on the next diff under the disabled rule). Such a creation is E4 like
    any modification. A file that only tightens, or only comments, is not; an
    unparseable one is not either — the defaults stay in force and the parse
    error surfaces on the next diff. `roles` overrides are a stated residual:
    a monorepo's first role table cannot be told from a narrowing one."""
    from checkwash.config import SEVERITY_ORDER, load_config

    cfg, err, _warnings = load_config(after)
    if err:
        return False
    if cfg.disabled_detectors:
        return True
    return SEVERITY_ORDER[cfg.fail_on] > SEVERITY_ORDER["high"]


def _classify_allowlist_change(before: bytes | None, after: bytes | None) -> list[str] | None:
    """Fingerprints of appended entries if the change is append-only and
    schema-valid, else None (→ guardrail critical). SPEC §6 / DECISIONS D-003."""
    from checkwash.allowlist import load_allowlist

    before_entries, before_err = load_allowlist(before)
    after_entries, after_err = load_allowlist(after)
    if before_err or after_err:
        return None
    if after is None or len(after_entries) < len(before_entries):
        return None
    if after_entries[: len(before_entries)] != before_entries:
        return None
    return [e.fingerprint for e in after_entries[len(before_entries) :]]


def _canonical_constants(raw: dict[str, str]) -> dict[str, str]:
    """Top-level constant name -> canonical defining expression.

    `_top_level_constants` records raw source segments — right for D6, which
    resolves and evaluates them, wrong for a two-sided comparison, where a
    reformat would read as a change (the binding channel's first false
    positive, solved there with `ast.unparse`; same medicine here). A segment
    that does not parse as an expression is skipped: the arm goes silent on
    it rather than comparing bytes it cannot normalize.
    """
    out: dict[str, str] = {}
    for name, seg in raw.items():
        tree = parse_text(seg, mode="eval")
        if tree is None:
            continue
        try:
            if isinstance(tree, ast.Expression) and isinstance(tree.body, ast.BinOp):
                out[name] = _binding_key(tree.body)
            else:
                out[name] = ast.unparse(tree)
        except ValueError:
            continue
    return out


def _native_assertion_context(
    data: bytes | None, parsed: ParsedFile | None,
) -> tuple[tuple[str, ...], tuple[str, ...]] | None:
    """Exact surrounding source, with proven native bare-assert spans cut out.

    A raises/with assertion may span executable setup code; inherited asserts
    can point into a helper. Neither is safe to mask. Unknown/overlapping spans
    decline the proof rather than guessing where assertion code ends.
    """
    if data is None or parsed is None or not parsed.parse_ok:
        return None
    source = normalize_source(data)
    spans = []
    for unit in parsed.units:
        for assertion in unit.side.assertions:
            text = assertion.text
            if assertion.inherited or not (
                text.startswith("assert") and len(text) > 6
                and (text[6].isspace() or text[6] == "(")
            ):
                continue
            if (
                not isinstance(assertion.span, tuple) or len(assertion.span) != 2
                or any(type(value) is not int for value in assertion.span)
            ):
                return None
            start, end = assertion.span
            if not 0 <= start < end <= len(source) or source[start:end] != text:
                return None
            spans.append((start, end))
    if not spans:
        return None
    parts = []
    assertions = []
    cursor = 0
    for start, end in sorted(spans):
        if start < cursor:
            return None
        parts.append(source[cursor:start])
        assertions.append(source[start:end])
        cursor = end
    parts.append(source[cursor:])
    return tuple(parts), tuple(assertions)


def _root_importer_changes(changes, config, head_reader, head_searcher, path_lister=None):
    """Read unchanged callers of changed root helpers, once and within caps.

    A file absent from the real diff has the same bytes on both snapshots.
    Its inherited oracle can still change when a root helper changes. The
    existing snapshot search/reader APIs supply data; no repository code runs.
    Unlike a missing refactor credit, an incomplete reverse search could miss
    a removed oracle, so unavailable/exhausted discovery is an engine error.
    """
    modules = {}
    real_paths = {p.replace("\\", "/") for c in changes for p in (c.path, c.old_path) if p}
    for change in changes:
        path = change.path.replace("\\", "/")
        old_path = (change.old_path or "").replace("\\", "/")
        if (old_path and old_path != path and "/" not in old_path and old_path.endswith(".py")
                and change.before is not None and config.role_of(old_path) in ("test", "conftest")
                and transparent_root_helpers(change.before)):
            raise EngineError("root assertion helper renames are outside bounded importer analysis")
        if ("/" in path or not path.endswith(".py") or not path[:-3].isidentifier() or change.before is None
                or change.before == change.after or config.role_of(path) not in ("test", "conftest")):
            continue
        names = transparent_root_helpers(change.before)
        if names:
            modules[path[:-3]] = set(names)
    if not modules:
        return [], 0, set()
    if head_reader is None or head_searcher is None:
        raise EngineError("changed root assertion helpers require snapshot importer search")
    if len(modules) > _MAX_ORACLE_READS:
        raise EngineError("root assertion helper search exceeds the module budget")
    # The search reads no submodule; an importer inside one pytest can collect
    # is unknown (#335).
    if path_lister is not None:
        paths, opaque = split_inventory(path_lister())
        if opaque:
            sources = {path: head_reader(path) for path in collection_sources(
                path for path in paths if isinstance(path, str))}
            reached = opaque_reached(opaque, {p: s for p, s in sources.items() if isinstance(s, bytes)}, changes)
            if reached is not None:
                raise opaque_error(reached, "pytest's collection can reach it")
    candidates = sorted({p.replace("\\", "/") for p in head_searcher(sorted(modules))})
    # The existing grep returns at most 64 hits. Exactly 64 can be a truncated
    # set; never call that a complete review of removed helper assertions.
    if len(candidates) >= 64:
        raise EngineError("root assertion helper importer search may be truncated")
    discovered = []
    reads = 0
    for candidate in candidates:
        path = candidate.replace("\\", "/")
        # An importer is a test module pytest collects, whatever role its path
        # holds: `tests/golden/test_x.py` is one (#219, ruling 219.Q1).
        if (path in real_paths or not path.endswith(".py") or is_artifact(path)
                or not collectable(path)):
            continue
        if path.startswith("/") or ":" in path or any(p in ("", ".", "..") for p in path.split("/")):
            raise EngineError("root assertion helper search returned an invalid repository path")
        if reads >= min(_MAX_DUP_READS, _MAX_ORACLE_READS):
            raise EngineError("root assertion helper importer search exceeds the read budget")
        data = head_reader(path)
        reads += 1
        if data is None:
            raise EngineError(f"root assertion helper importer snapshot is unavailable: {path}")
        try:
            imports = root_imports(data)
        except (SyntaxError, ValueError, MemoryError, RecursionError):
            continue
        if any(module in modules and original in modules[module] for module, original in imports.values()):
            discovered.append(FileChange(path=path, status="modified", before=data, after=data,
                                         synthetic="root_helper_importer"))
    return discovered, reads, set(modules)


def build_ir(
    changes: list[FileChange],
    config: Config,
    base_label: str,
    head_label: str,
    scope_allow: list[str] | None = None,
    known_modules: set[str] | None = None,
    self_modules: set[str] | None = None,
    head_reader=None,
    head_searcher=None,
    report_context: ReportContext | None = None,
    root_reader=None,
    root_searcher=None,
    root_path_lister=None,
    root_batch_reader=None,
    pytest_configs=None,
    policy_base=None,
) -> IR:
    changes, unread_changes = _set_aside_unread(changes, config, scope_allow or [], root_reader)
    # Absent from `changes`, a set-aside path would read as unchanged (#415).
    root_reader = _guard_unread_reads(root_reader, unread_changes)
    head_reader = _guard_unread_reads(head_reader, unread_changes)
    root_batch_reader = _guard_unread_reads(root_batch_reader, unread_changes, batch=True)
    importer_changes, importer_reads, reviewed_root_modules = _root_importer_changes(
        changes, config, root_reader, root_searcher, root_path_lister)
    changes = [*changes, *importer_changes]
    changes = [*changes, *expected_importer_changes(changes, config, root_reader, root_searcher, reviewed_root_modules)]
    g = DiffGlobals()
    g.scope_allow = sorted(scope_allow or [])
    # Someone else's code = declared, minus the project's own name, minus the
    # repo's own top-level directories. Without the subtractions this set
    # contains the package under test and the first-party check inverts.
    if known_modules is not None:
        repo_roots = {
            part[:-3] if part.endswith(".py") else part
            for change in (*changes, *unread_changes)
            for part in change.path.replace("\\", "/").split("/")
        }
        g.third_party_roots = tuple(
            sorted(set(known_modules) - set(self_modules or ()) - repo_roots - known_baseline())
        )
    ir = IR(base=base_label, head=head_label, globals=g)
    config_evidence = pytest_configs.prepare() if pytest_configs is not None else None
    shadow_hits = find_runtime_subject_shadows(
        changes, config, g.third_party_roots,
        head_path_lister=root_path_lister,
        head_batch_reader=root_batch_reader,
        include_equivalent=True,
        config_evidence=config_evidence,
        shebang_free=_shebang_free(unread_changes),
    )
    if config_evidence is not None:
        reported_hits = []
        for hit in shadow_hits:
            controls = set(hit.control_paths)
            finding_path = hit.finding_path
            contexts = []
            for logical in sorted(controls & config_evidence.changes.keys()):
                reported = config_evidence.reported_change(logical, changes)
                if reported is not None:
                    physical, context = reported
                    controls.add(physical.path)
                    contexts.append(context)
                    if finding_path == logical:
                        finding_path = physical.path
            reported_hits.append(replace(hit, finding_path=finding_path,
                                         trigger="; ".join([hit.trigger, *contexts]),
                                         control_paths=tuple(sorted(controls))))
        shadow_hits = reported_hits
    g.runtime_subject_shadows = [
        (hit.finding_path, hit.module, hit.before_provider, hit.after_provider,
         hit.test_path, hit.trigger)
        for hit in shadow_hits if hit.reportable
    ]
    shadow_evidence_paths = {
        path for hit in shadow_hits
        for path in (hit.after_provider, *hit.after_chain, *hit.related_evidence_paths,
                     *hit.control_paths, hit.trigger)
    }
    removed_texts: Counter[str] = Counter()
    added_texts: Counter[str] = Counter()
    base_literals: set[str] = set()
    # After-side parses, kept so skip-condition constants imported from
    # another file in the same diff resolve without re-reading anything.
    after_by_path: dict[str, ParsedFile] = {}
    before_by_path: dict[str, ParsedFile] = {}
    # Imports already present on the base side are presumed resolvable:
    # only NEW imports can be hallucinated.
    resolvable: set[str] | None = None
    if known_modules is not None:
        resolvable = set(known_modules)
        for change in changes:
            for part in change.path.replace("\\", "/").split("/"):
                resolvable.add(part[:-3] if part.endswith(".py") else part)

    # Computed once, before anything is judged: E6 needs to know what the
    # ci surface already said, not just what this diff added to it.
    one_hop = _one_hop_runners(changes, config, head_reader)
    ci_base = _ci_base_surface(changes, config, one_hop)
    collection_events = collection_inventory_changes(
        changes, config, path_lister=root_path_lister, batch_reader=root_batch_reader,
        config_evidence=config_evidence,
    )
    config_report_changes = {}
    for path, reason in collection_events:
        reported = config_evidence.reported_change(path, changes) if config_evidence is not None else None
        if reported is not None:
            physical, context = reported
            path = physical.path
            reason = reason + "; " + context
            config_report_changes[path] = physical
            shadow_evidence_paths.add(path)
            if physical.old_path:
                shadow_evidence_paths.add(physical.old_path)
        g.ci_weakening_lines.append((path, reason))

    # Cross-file oracle resolution (A5-x) parses helper files straight from
    # the change bytes, memoised — never from the loop's parse cache, so it
    # cannot depend on the order sorted() happens to visit paths in.
    raw_by_path: dict[str, tuple[bytes | None, bytes | None]] = {
        c.path.replace("\\", "/"): (c.before, c.after) for c in changes
    }
    conftest_context = ConftestContext(changes, root_reader)

    # The conftest files above each changed test module, per side (#223):
    # every `conftest.py` from the module's directory up to the repository
    # root, nearest first. A file the diff changes is read on its own side;
    # any other is the same on both, read once from the head snapshot. A
    # level that cannot be read or parsed ends the chain: what it defines is
    # unknown, and it could override any name beyond it.
    chain_sides: dict[str, tuple[bytes | None, bytes | None]] = {}
    for c in changes:
        cpath = c.path.replace("\\", "/")
        old = (c.old_path or cpath).replace("\\", "/")
        if old != cpath:
            chain_sides[old] = (c.before, None)
            chain_sides[cpath] = (None, c.after)
        else:
            chain_sides[cpath] = (c.before, c.after)
    chain_levels: dict[tuple[str, int], object] = {}
    chain_sources: dict[tuple[str, int], bytes | None] = {}
    chain_reads = [0, 0]
    unknown = object()
    mark_config_cache: dict[tuple[str, int], bool] = {}

    def _config_may_load_marks(directory: str, side: int) -> bool:
        """Explicit plugin configuration defeats a known static mark set.

        Read snapshot bytes only, cached per directory/side under the same
        resource limits as conftest. No plugin or configuration executes.
        Ambient entry-point plugins and command-line environment remain
        outside this repository snapshot's visibility.
        """
        key = (directory, side)
        if key in mark_config_cache:
            return mark_config_cache[key]
        found = False
        for name in ("pytest.ini", ".pytest.ini", "pytest.toml", ".pytest.toml",
                     "pyproject.toml", "tox.ini", "setup.cfg"):
            cpath = f"{directory}/{name}" if directory else name
            if cpath in chain_sides:
                data = chain_sides[cpath][side]
            elif root_reader is None:
                found = True
                break
            else:
                if chain_reads[0] >= _MAX_CHAIN_READS:
                    raise EngineError("conftest chain exceeds the source read limit")
                chain_reads[0] += 1
                data = root_reader(cpath)
                if data is not None and not isinstance(data, bytes):
                    raise EngineError("conftest chain strict snapshot returned invalid source bytes")
                if data is not None:
                    chain_reads[1] += len(data)
                    if chain_reads[1] > _MAX_CHAIN_BYTES:
                        raise EngineError("conftest chain exceeds the source byte limit")
                    if report_context is not None:
                        report_context.snapshot(cpath, 0, data)
                        report_context.snapshot(cpath, 1, data)
            if data and (re.search(rb"(?<![\w-])-p(?:\s|[A-Za-z_])", data)
                         or b"PYTEST_PLUGINS" in data or b"pytest11" in data):
                found = True
        mark_config_cache[key] = found
        return found

    def _chain_level(cpath: str, side: int):
        """`cpath`'s level on `side`: a ConftestLevel, None when absent, `unknown` when unknowable."""
        key = (cpath, side if cpath in chain_sides else -1)
        if key in chain_levels:
            return chain_levels[key]
        if cpath in chain_sides:
            data = chain_sides[cpath][side]
        elif root_reader is None:
            chain_levels[key] = unknown
            return unknown
        else:
            if chain_reads[0] >= _MAX_CHAIN_READS:
                raise EngineError("conftest chain exceeds the source read limit")
            chain_reads[0] += 1
            data = root_reader(cpath)
            if data is not None and not isinstance(data, bytes):
                raise EngineError("conftest chain strict snapshot returned invalid source bytes")
            if data is not None:
                chain_reads[1] += len(data)
                if chain_reads[1] > _MAX_CHAIN_BYTES:
                    raise EngineError("conftest chain exceeds the source byte limit")
                if report_context is not None:
                    report_context.snapshot(cpath, 0, data)
                    report_context.snapshot(cpath, 1, data)
        chain_sources[key] = data
        level = None if data is None else parse_conftest_level(data, cpath)
        chain_levels[key] = unknown if data is not None and level is None else level
        return chain_levels[key]

    def _conftest_chain(tpath: str, side: int, test_source: bytes) -> tuple:
        levels = []
        directories = []
        directory = tpath.rpartition("/")[0]
        while True:
            directories.append(directory)
            cpath = f"{directory}/conftest.py" if directory else "conftest.py"
            level = _chain_level(cpath, side)
            if level is unknown:
                # What it defines is unknown, and so are the marks it may add
                # to a test (#358).
                levels.append(unreadable_level(cpath))
                break
            if level is not None:
                levels.append(level)
            if not directory:
                break
            directory = directory.rpartition("/")[0]
        reads_own_marks = b"request" in test_source and any(
            word in test_source for word in (b"marker", b"keywords"))
        reads_own_marks |= any(
            outcome and outcome[2] and "request" in outcome[2]
            and ("marker" in outcome[2] or "keywords" in outcome[2])
            for level in levels for _requested, _autouse, outcome in level.fixtures.values()
        )
        # Unrelated test/helper reads keep their existing source-read
        # contract and budget. Configuration matters only to this reading.
        if reads_own_marks and any(_config_may_load_marks(d, side) for d in directories):
            # This context changes only the mark reading: it neither
            # supplies fixtures nor cuts off the fixture lookup chain.
            levels.append(ConftestLevel("<plugin-configuration>", {}, frozenset(), False, adds_marks=True))
        return tuple(levels)

    # The modules a test module imports a helper from (#272, second stage),
    # resolved as an imported assertion helper's module is
    # (`_merge_crossfile_oracles`: a dotted module from the root, a dotless
    # one beside the test) and read as the conftest chain is: a file the diff
    # changes on its own side, any other once from the strict head snapshot,
    # within the same limits. Only a test or conftest module is read.
    helper_modules: dict[tuple[str, int], HelperModule | None] = {}

    def _helper_module(mpath: str, side: int) -> HelperModule | None:
        key = (mpath, side if mpath in chain_sides else -1)
        if key in helper_modules:
            return helper_modules[key]
        data = None
        if config.role_of(mpath) in ("test", "conftest"):
            if mpath in chain_sides:
                data = chain_sides[mpath][side]
            elif root_reader is not None:
                if chain_reads[0] >= _MAX_CHAIN_READS:
                    raise EngineError("imported helper modules exceed the source read limit")
                chain_reads[0] += 1
                data = root_reader(mpath)
                if data is not None and not isinstance(data, bytes):
                    raise EngineError("imported helper strict snapshot returned invalid source bytes")
                if data is not None:
                    chain_reads[1] += len(data)
                    if chain_reads[1] > _MAX_CHAIN_BYTES:
                        raise EngineError("imported helper modules exceed the source byte limit")
                    if report_context is not None:
                        report_context.snapshot(mpath, 0, data)
                        report_context.snapshot(mpath, 1, data)
        helper_modules[key] = HelperModule(data, mpath) if data is not None else None
        return helper_modules[key]

    def _imported_helpers(tpath: str, side: int):
        """`(module, original) -> outcomes` for the test module at `tpath` on `side`."""
        tdir = tpath.rpartition("/")[0]

        def resolve(module: str, original: str) -> tuple:
            if "." in module:
                mpath = module.replace(".", "/") + ".py"
            else:
                mpath = f"{tdir}/{module}.py" if tdir else f"{module}.py"
            helper = _helper_module(mpath, side)
            return helper.outcomes(original) if helper is not None else ()

        return resolve

    oracle_memo: dict[tuple[str, int], ParsedFile | None] = {}
    oracle_sources: dict[tuple[str, int], bytes | None] = {}
    strict_oracle_sources: set[tuple[str, int]] = set()
    root_import_memo: dict[tuple[str, int], dict] = {}
    root_projection_memo: dict[tuple[str, int, str], dict] = {}
    oracle_head_reads = [importer_reads]

    def _oracle_file(opath: str, side: int, *, strict=False, absence_only=False) -> ParsedFile | None:
        """A test/conftest module parsed for its oracle carriers, or None.

        side 0 = base, 1 = head. A file outside the diff is identical on both
        sides, so one memo entry — and one head read — serves base and head
        alike. The entry used to be keyed per side, which let the before pass
        drain the shared read budget and the after pass resolve the same
        helper to nothing: every inherited assert became a phantom
        ASSERT_REMOVED on any edit to the importing file, black's trio being
        16 of 74 field-run blocks (R1). A file *added* by the diff has no
        base half, which is what makes an extraction's before side resolve
        to nothing — correctly, so in-diff files keep their per-side halves.

        Oracle reads skip production roles. Strict absence probes must still
        read them: a production-role package can shadow a test-role module.
        """
        in_diff = opath in raw_by_path
        key = (opath, side if in_diff else -1)
        if key in oracle_memo and (not strict or key in strict_oracle_sources):
            return oracle_memo[key]
        parsed: ParsedFile | None = None
        oracle_role = config.role_of(opath) in ("test", "conftest")
        if not oracle_role and not (strict and absence_only):
            oracle_memo[key] = None
            return None
        if in_diff:
            data = raw_by_path[opath][side]
        elif (root_reader if strict else head_reader) is not None and oracle_head_reads[0] < _MAX_ORACLE_READS:
            oracle_head_reads[0] += 1
            data = (root_reader if strict else head_reader)(opath)
        else:
            data = None
            # Exhausting the read budget is unknown, not an absent sibling.
            oracle_memo[key] = None
            return None
        oracle_sources[key] = data
        if strict or in_diff:
            strict_oracle_sources.add(key)
        if data is not None and oracle_role:
            if report_context is not None:
                report_context.snapshot(opath, side, data)
                if not in_diff:
                    report_context.snapshot(opath, 1 - side, data)
            parsed = parse_python(
                data, collect_tests=True, conftest=opath.endswith("conftest.py")
            )
            if not parsed.parse_ok:
                parsed = None
        oracle_memo[key] = parsed
        return parsed

    def _merge_crossfile_oracles(tpath: str, parsed: ParsedFile, side: int) -> None:
        """Fold imported-helper and requested-fixture asserts into each unit.

        Two channels, both pre-registered in docs/defence-design.md A5-x:
        a unit-invoked name bound by a top-level `from M import f` whose module
        is a same-directory test/conftest sibling contributes f's own asserts;
        a fixture the unit requests by parameter name (same file or same-dir
        conftest) contributes everything lexically inside it. A fixture nobody
        requests contributes nothing — moving the oracle into one stays a
        removal. Each side resolves independently, so a helper added by the
        diff has no base half and an extraction's before side stays bare.

        Autouse fixtures from a head-only conftest are skipped on purpose:
        both sides would receive identical asserts, no rule could see a delta,
        and every unit in the file would grow oracle mass it did nothing to
        earn. An autouse fixture in a conftest *the diff touches* can differ
        between sides, so those are applied.
        """
        if parsed is None or not parsed.parse_ok or not parsed.units:
            return
        tdir = tpath.rsplit("/", 1)[0] if "/" in tpath else ""
        conftest_path = f"{tdir}/conftest.py" if tdir else "conftest.py"

        for unit in parsed.units:
            uside = unit.side
            extra = []

            def inherit(assertions, source_path):
                extra.extend(assertions)
                if report_context is not None:
                    for assertion in assertions:
                        report_context.bind(tpath, side, assertion, source_path)

            requested = list(uside.params)
            conftest = None
            if requested and any(p not in parsed.fixture_asserts for p in requested):
                conftest = _oracle_file(conftest_path, side)
            for p in requested:
                found = parsed.fixture_asserts.get(p)
                source_path = tpath
                if found is None and conftest is not None:
                    found = conftest.fixture_asserts.get(p)
                    source_path = conftest_path
                if found:
                    inherit(found, source_path)
            for name in parsed.autouse_fixtures:
                if name not in requested:
                    inherit(parsed.fixture_asserts.get(name, ()), tpath)
            if conftest_path in raw_by_path and conftest_path != tpath:
                c = _oracle_file(conftest_path, side)
                if c is not None:
                    for name in c.autouse_fixtures:
                        if name not in requested:
                            inherit(c.fixture_asserts.get(name, ()), conftest_path)
            for n in sorted(set(uside.invoked) & set(parsed.from_imports)):
                module, orig = parsed.from_imports[n]
                if "." in module:
                    candidate = module.replace(".", "/") + ".py"
                else:
                    candidate = f"{tdir}/{module}.py" if tdir else f"{module}.py"
                root = f"{module}.py"
                if (root_reader is not None and "." not in module and tdir
                        and config.role_of(root) in ("test", "conftest")):
                    # Keep absolute versus .relative identity, which the
                    # legacy sibling map intentionally collapses. Only this
                    # new root channel needs the stricter binding contract.
                    import_key = (tpath, side)
                    source = raw_by_path[tpath][side]
                    if import_key not in root_import_memo:
                        root_import_memo[import_key] = root_imports(source)
                    if root_import_memo[import_key].get(n) == (module, orig):
                        _oracle_file(root, side, strict=True)
                        root_key = (root, side if root in raw_by_path else -1)
                        if root_key not in strict_oracle_sources:
                            continue
                        root_source = oracle_sources[root_key]
                        if root_source is not None:
                            # A present (even unparseable) sibling makes the
                            # runtime import target ambiguous; do not guess.
                            alternatives = (candidate, f"{module}/__init__.py", f"{tdir}/{module}/__init__.py")
                            alternative_keys = []
                            for alternative in alternatives:
                                _oracle_file(alternative, side, strict=True, absence_only=True)
                                alternative_keys.append((alternative, side if alternative in raw_by_path else -1))
                            unknown = any(key not in strict_oracle_sources for key in alternative_keys)
                            present = any(oracle_sources.get(key) is not None for key in alternative_keys)
                            if unknown and module in reviewed_root_modules:
                                raise EngineError("root assertion helper resolution exceeds the snapshot read budget")
                            if present and module in reviewed_root_modules:
                                raise EngineError("changed root assertion helper has an ambiguous sibling import")
                            if unknown or present:
                                continue
                            projection_key = (tpath, side, n)
                            if projection_key not in root_projection_memo:
                                root_projection_memo[projection_key] = (
                                    project_root_oracles(source, root_source, n, orig)
                                    if oracle_memo[root_key] is not None else {}
                                )
                            projected = root_projection_memo[projection_key].get(unit.qualname, ())
                            if side == 1 and raw_by_path[tpath][0] is not None:
                                if not root_caller_unchanged(raw_by_path[tpath][0], source, module, n, orig, unit.qualname):
                                    projected = []
                            if side == 1 and tpath in before_by_path:
                                prior = next((u for u in before_by_path[tpath].units if u.qualname == unit.qualname), None)
                                if prior is not None:
                                    # This credit preserves an existing oracle;
                                    # replacing its subject with another call
                                    # is not the extraction being recognized.
                                    projected = [a for a in projected if any(
                                        same_expr(a.left, b.left) for b in prior.side.assertions
                                    )]
                            # Projection text and span describe the concrete
                            # call in this test, not the helper definition.
                            inherit(projected, tpath)
                            continue
                helper = _oracle_file(candidate, side)
                if helper is not None:
                    inherit(helper.helper_asserts.get(orig, ()), candidate)
            if extra:
                uside.assertions.extend(replace(a) for a in extra)
                for i, a in enumerate(uside.assertions):
                    a.id = f"a{i}"

    rename_destinations = {
        c.old_path.replace("\\", "/"): c.path.replace("\\", "/")
        for c in changes if c.old_path
    }
    # What pytest collects at head (D-193, THREATMODEL row 179). A path the
    # diff changes is read on its head side, a rename's source is gone, any
    # other path is read from the strict snapshot, and nothing is read until
    # a rename or an arrival asks. Without a snapshot nothing is known: no
    # rename is judged by it and no arrival pays.
    head_sides: dict[str, set] = {}
    for change in changes:
        path = change.path.replace("\\", "/")
        head_sides.setdefault(path, set()).add(change.after)
        old = (change.old_path or path).replace("\\", "/")
        if old != path:
            head_sides.setdefault(old, set())

    def _head_source(candidate):
        if candidate in head_sides:
            if len(head_sides[candidate]) > 1:
                raise ValueError("conflicting head sides of a changed path")
            return next(iter(head_sides[candidate]), None)
        if (candidate, -1) in chain_sources:
            return chain_sources[(candidate, -1)]  # a conftest the chain reader already read
        try:
            return root_reader(candidate)
        except EngineError:
            # pytest follows a root config that is a link; the config
            # evidence reads it the same way, where the snapshot refuses it.
            if config_evidence is None or "/" in candidate or candidate not in _PYTEST_CONFIGS:
                raise
            return config_evidence.sources("after", [candidate])[candidate]

    def _head_many(candidates):
        candidates = list(dict.fromkeys(candidates))
        rest = [candidate for candidate in candidates
                if candidate not in head_sides and (candidate, -1) not in chain_sources]
        found = {}
        if rest and root_batch_reader is not None:
            try:
                found = dict(root_batch_reader(rest))
            except EngineError:
                found = {}  # one refused path refuses a batch: each is read alone
        return {candidate: found[candidate] if candidate in found else _head_source(candidate)
                for candidate in candidates}

    def _head_paths():
        listed = root_path_lister()
        selected = {path for path in split_inventory(listed)[0] if isinstance(path, str)}
        for candidate in head_sides:
            selected.discard(candidate)
            if _head_source(candidate) is not None:
                selected.add(candidate)
        return [*sorted(selected), *(path for path in listed if isinstance(path, str) and path.endswith("/"))]

    head_collection = []

    def python_collection():
        if not head_collection:
            head_collection.append(
                arrival_collector(_head_source, _head_paths if root_path_lister is not None else None, _head_many)
                if root_reader is not None else None)
        return head_collection[0]

    def python_excludes(path):
        collection_ = python_collection()
        return collection_ is not None and collection_.excludes(path)

    manifest = _base_manifest(changes, root_reader, unread_changes)
    expanded_changes = sorted(_expand_renames(changes, config, manifest, python_excludes), key=lambda c: c.path)
    # The runner each JS test file is judged under at head, for D2 liveness.
    js_head_runners: dict[str, frozenset[str] | None] = {}
    # An unread co-change could redefine a callee too (#415).
    single_context_change = sum(not is_artifact(c.path) for c in (*changes, *unread_changes)) == 1
    for change in expanded_changes:
        path = change.path.replace("\\", "/")
        if is_artifact(path):
            continue  # generated output is not evidence of anything
        role = config.role_of(path)
        if role == "prod" and (
            _is_runner_script(path, change.before, change.after) or path in one_hop
            or _test_commands_changed(path, change.before, change.after)
        ):
            # The test command lives wherever the project keeps it. As prod
            # this file was unreadable, which meant editing it both hid a
            # weakened command *and* granted the whole diff the THREATMODEL #4
            # opaque exemption — one line of `scripts/test.sh` turned a
            # blocking assertion weakening into a warn (probe 2026-08-07).
            # A package manifest keeps it in a string value: `scripts.test`
            # going from `node --test` to `node --test || true` did the same
            # from package.json (issue #174). Only an edit to that command
            # moves the manifest; a dependency bump stays production.
            role = "ci"
        is_python = path.endswith(".py")
        # The role the SPEC §2 table (and runner promotion) gives the path,
        # before any test role read from the path alone. E7 judges by it when
        # that path-only test role finds no test to judge (#196 186.8).
        table_role = role
        # A JS/TS test path is parsed and judged as a test whatever its role.
        # The role decides only which other rules it also answers to (#197).
        is_js_test = is_js_test_file(path, change.before, change.after)
        if _js_test(path, role, change.before, change.after):
            role = "test"
        elif role == "prod" and is_test_support_path(path):
            # Data, mocks and helpers beneath a test-support directory serve
            # tests: never production evidence, never the opaque exemption
            # (#217). E7 still reads their table role (_scope_role).
            role = "test"
        # So is a Python file pytest's default collection runs: one predicate,
        # `collectable`, for its obligations and its rename continuity, so
        # `tests/golden/test_x.py` keeps the snapshot role and is judged as a
        # test beside it (#219, ruling 219.Q1).
        test_obligations = (is_js_test or (is_python and collectable(path))) and role != "test"
        judged_test = role == "test" or test_obligations

        before_parsed: ParsedFile | None = None
        after_parsed: ParsedFile | None = None
        if is_python:
            is_conftest = role == "conftest"
            collect = is_conftest or (judged_test and collectable(path))
            # A test module the diff changes also reaches the conftest
            # fixtures above it, each side from where the module sat on that
            # side (#223). An importer the engine adds unchanged, a root
            # helper's or an expected value's, is not one (D-093 7).
            reaches_chain = collect and not is_conftest and change.synthetic not in (
                "root_helper_importer", "expected_provenance_importer")
            if change.before is not None:
                before_path = (change.old_path or path).replace("\\", "/")
                before_parsed = parse_python(
                    change.before, collect_tests=collect, conftest=is_conftest,
                    chain=_conftest_chain(before_path, 0, change.before) if reaches_chain else (),
                    imported=_imported_helpers(before_path, 0) if reaches_chain else None,
                )
            if change.after is not None:
                after_parsed = parse_python(
                    change.after, collect_tests=collect, conftest=is_conftest,
                    chain=_conftest_chain(path, 1, change.after) if reaches_chain else (),
                    imported=_imported_helpers(path, 1) if reaches_chain else None,
                )
        elif is_js_test:
            # Each side is judged under its own runner's focus rule.
            if change.before is not None:
                before_parsed = parse_javascript(change.before, _innermost_focus(change.before, manifest))
            if change.after is not None:
                after_parsed = parse_javascript(change.after, _innermost_focus(change.after, manifest))

        if (is_python and judged_test and collect
                and change.status == "modified" and change.old_path is None
                and before_parsed is not None and after_parsed is not None):
            before_parsed, after_parsed = mark_classic_exception_removal(
                change.before, change.after, before_parsed, after_parsed,
                path=path, root_reader=root_reader, root_searcher=root_searcher, changes=changes,
            )
            before_parsed, after_parsed = mark_empty_parameter_introduction(
                change.before, change.after, before_parsed, after_parsed,
                path=path, root_reader=root_reader, root_searcher=root_searcher, changes=changes,
            )
            before_parsed, after_parsed = mark_neutralizing_aliases(
                change.before, change.after, before_parsed, after_parsed,
                path=path, root_reader=root_reader, root_searcher=root_searcher, changes=changes,
            )
            before_parsed, after_parsed = mark_empty_length_guards(
                change.before, change.after, before_parsed, after_parsed,
                path=path, root_reader=root_reader, root_searcher=root_searcher, changes=changes,
            )
            before_parsed, after_parsed = mark_class_exception_aliases(
                change.before, change.after, before_parsed, after_parsed,
                path=path, root_reader=root_reader, root_searcher=root_searcher, changes=changes,
            )
            before_parsed, after_parsed = mark_function_exception_aliases(
                change.before, change.after, before_parsed, after_parsed,
                path=path, root_reader=root_reader, root_searcher=root_searcher, changes=changes,
            )
            before_parsed, after_parsed = mark_type_comparisons(
                change.before, change.after, before_parsed, after_parsed,
                path=path, root_reader=root_reader, root_searcher=root_searcher, changes=changes,
            )
            before_parsed, after_parsed = mark_builtin_normalizations(
                change.before, change.after, before_parsed, after_parsed,
                path=path, root_reader=root_reader, root_searcher=root_searcher, changes=changes,
            )
            before_parsed, after_parsed = mark_literal_all(
                change.before, change.after, before_parsed, after_parsed,
                path=path, root_reader=root_reader, root_searcher=root_searcher, changes=changes,
            )
            before_parsed, after_parsed = project_manual_unittest_suites(
                change.before, change.after, before_parsed, after_parsed,
                path=path, root_reader=root_reader, root_searcher=root_searcher, changes=changes,
            )
            before_parsed, after_parsed = project_table_consolidation(
                change.before, change.after, before_parsed, after_parsed,
                path=path, root_reader=root_reader, root_searcher=root_searcher, changes=changes,
            )

        if report_context is not None:
            if is_js_test:
                report_context.javascript_coverage(path, 0, change.before, before_parsed)
                report_context.javascript_coverage(path, 1, change.after, after_parsed)
            if is_python or is_js_test:
                report_context.snapshot(path, 0, change.before)
                report_context.snapshot(path, 1, change.after)
            report_context.parsed(path, 0, before_parsed)
            report_context.parsed(path, 1, after_parsed)

        if after_parsed is not None and after_parsed.parse_ok:
            after_by_path[path] = after_parsed
        if before_parsed is not None and before_parsed.parse_ok:
            before_by_path[path] = before_parsed

        native_context_unchanged = False
        if (
            single_context_change and change.old_path is None
            and is_python and (judged_test or role == "conftest")
        ):
            before_context = _native_assertion_context(change.before, before_parsed)
            after_context = _native_assertion_context(change.after, after_parsed)
            native_context_unchanged = (
                before_context is not None and after_context is not None
                and before_context[0] == after_context[0]
                # Another rewritten assert can change the next assertion's
                # input through a call's side effect. This narrow proof permits
                # only one rewritten native assertion in the whole file.
                and sum(b != a for b, a in zip(before_context[1], after_context[1])) <= 1
            )

        if is_python and judged_test and collect:
            project_truthiness_oracles(path, before_parsed, after_parsed, raw_by_path, root_reader, root_searcher)
            if before_parsed is not None:
                _merge_crossfile_oracles(path, before_parsed, 0)
            if after_parsed is not None:
                _merge_crossfile_oracles(path, after_parsed, 1)

        file_ir = align_file(path, role, change.status, before_parsed, after_parsed)
        file_ir.test_obligations = test_obligations
        file_ir.native_assertion_context_unchanged = native_context_unchanged
        if is_js_test and change.after is not None:
            head_runners = runner_evidence(change.after, manifest)
            js_head_runners[path] = head_runners
            # Focus this diff adds to a file that had none. Jest and Vitest
            # keep it in the file; Mocha and Jasmine apply it to the whole
            # suite, so unless the runner is proven to be one of the first two,
            # every test outside this file stops (#196 187.4). A move out of
            # collection is reported as a removal instead.
            focus = after_parsed.focus if after_parsed is not None and after_parsed.parse_ok else None
            had_focus = before_parsed is not None and before_parsed.focus is not None
            if (focus is not None and not had_focus and change.synthetic != "renamed_from_test"
                    and not focus_is_file_scoped(head_runners)):
                file_ir.suite_focus_added = Marker(name="test.focused", text=focus.text, span=focus.span)
        if (judged_test or role == "conftest") and path.endswith(".py"):
            from checkwash.frontends.python.constant_renames import literal_constant_renames
            file_ir.module_constant_renames = literal_constant_renames(change.before, change.after)
        if role in ("ci", "guardrail"):
            file_ir.change_evidence = _change_evidence(change, rename_destinations)
        parsed_for_helpers = after_parsed if after_parsed and after_parsed.parse_ok else before_parsed
        if parsed_for_helpers is not None and parsed_for_helpers.parse_ok:
            file_ir.helper_calls = dict(parsed_for_helpers.helper_calls)
        ir.files.append(file_ir)
        if is_python and not file_ir.parse_ok:
            ir.skipped_files.append(path)
            # A test file checkwash cannot parse is a test file checkwash did
            # not check. Reporting it only in `skipped_files` made the verdict
            # depend on the analysing interpreter's grammar: source using
            # newer-than-analyzer syntax was silently dropped and the run
            # passed, while the same diff blocked on a newer Python (reader
            # audit 2026-08-02). Now it is a finding, and one that escalates
            # when the file used to parse.
            if (judged_test or role == "conftest") and change.status != "deleted":
                was_parseable = before_parsed is not None and before_parsed.parse_ok
                g.unparseable_tests.append((path, was_parseable))
                file_ir.change_evidence = _change_evidence(change, rename_destinations)

        if (judged_test or role == "conftest") and after_parsed and after_parsed.parse_ok:
            g.test_file_imports[path] = list(after_parsed.imports)
        elif (
            (judged_test or role == "conftest")
            and after_parsed is None
            and before_parsed
            and before_parsed.parse_ok
        ):
            # A deleted test file's units are judged against what that file
            # imported when it existed — without this, PROD_SYMBOL_REMOVED
            # could never connect a deleted test file to the feature removal
            # that explains it (starlette b133ab45ad deletes both halves).
            g.test_file_imports[path] = list(before_parsed.imports)
        if judged_test or role == "conftest":
            for unit in file_ir.units:
                if unit.before is None or unit.after is None:
                    g.test_logic_changed = True
                elif unit.delta is not None:
                    # `assertion_pairs` holds every matched pair, changed or
                    # not, so testing it for emptiness marked a comment-only
                    # edit as a logic change and silently switched off
                    # SNAPSHOT_CODE_COCHANGE (reader audit 2026-08-02). Only
                    # pairs whose text actually differs count.
                    b_by_id = {a.id: a for a in unit.before.assertions}
                    a_by_id = {a.id: a for a in unit.after.assertions}
                    edited = any(
                        (b := b_by_id.get(p.before_id)) is not None
                        and (a := a_by_id.get(p.after_id)) is not None
                        and normalize_text(b.text) != normalize_text(a.text)
                        for p in unit.delta.assertion_pairs
                    )
                    if edited or (
                        unit.delta.assertions_removed
                        or unit.delta.assertions_added
                        or unit.delta.markers_added
                        or unit.delta.param_cases_removed
                    ):
                        g.test_logic_changed = True

        if change.synthetic not in ("root_helper_importer", "expected_provenance_importer") and g.scope_allow and not any(
            _scope_match(path, glob) for glob in g.scope_allow
        ):
            g.scope_drift.append((path, _scope_role(role, table_role, before_parsed, after_parsed)))
            if file_ir.change_evidence is None:
                file_ir.change_evidence = _change_evidence(change, rename_destinations)

        if judged_test or role in ("conftest", "prod", "ci", "guardrail"):
            _scan_hidden_unicode(g, path, change.before, change.after)

        if path in MANIFESTS and _deps_differ(change.before, change.after, path):
            g.dependency_manifest_changed = True

        if role == "conftest" and change.after is not None:
            before_patches = (
                set(conftest_patch_targets(change.before, module_exists=lambda module: conftest_context.contains(module, 0), module_name=_module_of(path)))
                if change.before is not None
                else set()
            )
            for text in conftest_patch_targets(change.after, module_exists=lambda module: conftest_context.contains(module, 1), module_name=_module_of(path)):
                if text not in before_patches:
                    g.conftest_prod_patches.append((path, text))

        if change.synthetic == "renamed_from_test":
            # Relocated test bytes are not production behaviour change; they
            # must not defuse E1 nor feed prod symbol/literal/import globals.
            pass
        elif role == "prod":
            g.prod_files_changed.append(path)
            package = _module_of(path)
            if path in shadow_evidence_paths:
                # Provider copies and controls changed what the oracle runs;
                # they are not repairs for this or another weakened oracle.
                pass
            elif is_python and before_parsed and after_parsed and before_parsed.parse_ok and after_parsed.parse_ok:
                for q in sorted(set(before_parsed.symbols) | set(after_parsed.symbols)):
                    if before_parsed.symbols.get(q) != after_parsed.symbols.get(q):
                        g.prod_symbols_changed.append(f"{_module_of(path)}::{q}")
                        # A deletion counts as feature removal only when its
                        # enclosing scope is gone too. Symbol collection
                        # records assignments inside functions, so a rewritten
                        # function "deletes" its old locals — and that let a
                        # body rewrite escort a test deletion into the D8
                        # credit (click b7e5fd4cc7, adjudicated spec-correct,
                        # cleared by the first cut of this rule). A surviving
                        # prefix means internal rewrite, not removal.
                        if q in before_parsed.symbols and q not in after_parsed.symbols:
                            parts = q.split(".")
                            prefixes = (".".join(parts[:i]) for i in range(1, len(parts)))
                            if not any(p in after_parsed.symbols for p in prefixes):
                                g.prod_symbols_deleted.append(f"{_module_of(path)}::{q}")
                        # PACKAGE_REPAIR credit requires a MODIFIED existing
                        # symbol in the package — a real behaviour change. A
                        # newly added dead function or a comment does not
                        # count, or it reopens bypass #4 for
                        # EXPECTED_VALUE_CHANGED (confirmed red-team finding).
                        if q in before_parsed.symbols and q in after_parsed.symbols:
                            g.prod_packages.append(package)
                _record_callers(g, after_parsed, g.prod_symbols_changed)
                g.new_literals_in_prod.extend(sorted(after_parsed.literals - before_parsed.literals))
            elif is_python and change.status == "added" and after_parsed and after_parsed.parse_ok:
                # A brand-new prod file is all new symbols; nothing "modified"
                # in it explains editing an existing test's expectation.
                new_symbols = [f"{_module_of(path)}::{q}" for q in sorted(after_parsed.symbols)]
                g.prod_symbols_changed.extend(new_symbols)
                # The file-scoped EXPECTED_VALUE_CHANGED does not count them as
                # an implementation change (#463 Q1 (a)); every other reader of
                # `prod_symbols_changed` still does. A deleted file (below)
                # keeps counting for both.
                g.prod_symbols_in_added_files.extend(new_symbols)
                _record_callers(g, after_parsed, g.prod_symbols_changed)
                g.new_literals_in_prod.extend(sorted(after_parsed.literals))
            elif (
                is_python
                and change.status == "deleted"
                and before_parsed is not None
                and before_parsed.parse_ok
            ):
                # A deleted Python file is fully analysable from its base
                # side: every symbol in it changed, and every one is gone.
                # It used to fall into the opaque blanket, which handed a
                # diff-wide exemption to five corpus commits whose deletion
                # was perfectly readable. Symbol-level evidence and D8 now
                # judge it like any other change.
                for q in sorted(before_parsed.symbols):
                    g.prod_symbols_changed.append(f"{_module_of(path)}::{q}")
                    g.prod_symbols_deleted.append(f"{_module_of(path)}::{q}")
            elif is_artifact(path):
                # Generated output: no evidence either way, and crediting it
                # would let any build artifact disarm the gate.
                pass
            elif _is_inert(path):
                # Docs config, stubs, repo metadata: changes no runtime
                # behaviour, so it is neither evidence nor opaque.
                pass
            else:
                # Other-language code, templates, data files, or a Python
                # parse failure: checkwash cannot tell repair from decoy
                # here, so it conservatively suppresses E1 (THREATMODEL #4).
                #
                # But it must be a *change to something that was already
                # production*. Told to defeat this tool and handed its source,
                # an agent read this branch and wrote a three-line
                # `retry_policy.json` that nothing imports, purely to be
                # unreadable, and both rewritten expectations passed
                # (informed arm 2026-08-07). A file that did not exist before
                # cannot be the repair of behaviour that did — and if a new
                # file genuinely implements a fix, the Python that reaches it
                # changed too and supplies the evidence itself.
                # v0.1.10 spelled that as "was there a byte on the base
                # side", which is weaker than the argument in three ways an
                # audit then reproduced (rows 78-80). The exemption needs a
                # *modification of something that was already production*:
                #
                #  - not a deletion. `git rm` of an unread data file bought
                #    the exemption for a whole diff, and row 73's own
                #    reasoning applies to removals word for word.
                #  - the base-side path must have been production too. Rename
                #    folding keeps the old blob as `before` while the role
                #    comes from the new path, so `docs/rules.md` renamed to
                #    `app/rules.csv` counted as pre-existing production the
                #    diff had in fact just invented. Data beneath a
                #    test-support directory was not production either (#217).
                #  - not opacity this diff created. A prod `.py` that parsed
                #    at base and does not parse at head is reported as
                #    `skipped (unparseable)` in the same report; rewarding it
                #    is rewarding the agent for breaking the reader.
                #
                # The cost of all three is bounded and known: re-sweeping the
                # 1800-commit corpus with this exemption disabled *entirely*
                # moved the block set by zero commits in all six repositories,
                # so no subset of it can cost more than nothing here. That
                # figure is from the corpus and engine of its day; #419's
                # refusal (another subset) is priced by its own pre-registered
                # sweep, not by this note.
                old_path = (change.old_path or path).replace("\\", "/")
                self_inflicted = (
                    is_python
                    and before_parsed is not None
                    and before_parsed.parse_ok
                    and (after_parsed is None or not after_parsed.parse_ok)
                )
                if (
                    change.before
                    and change.after
                    and change.before != change.after
                    and config.role_of(old_path) == "prod"
                    and not is_test_support_path(old_path)
                    and not self_inflicted
                    # 4. A file that runs the test suite is not unreadable
                    #    production code, whatever it is called. Without this,
                    #    an unrecognised runner filename was strictly better
                    #    for an attacker than a recognised one: it hid its own
                    #    weakening *and* disarmed every oracle rule in the diff
                    #    (THREATMODEL 87, measured 2026-08-11).
                    and not _mentions_test_runner(change)
                ):
                    g.prod_opaque_change = True
        elif role == "guardrail":
            shadow = shadow_baseline(change, policy_base)
            if path in (".checkwash/allow.toml", ".greenwash/allow.toml"):
                before_policy = shadow[0] if shadow is not None else change.before
                appended = _classify_allowlist_change(before_policy, change.after)
                if shadow is not None:
                    g.policy_shadows[path] = {
                        **shadow[1], "kind": "allow_append" if appended is not None else "allow_rewrite",
                    }
                if appended is not None:
                    g.exemptions_added.extend(appended)
                    g.exemption_ledger_path = path
                else:
                    g.guardrail_files_changed.append(path)
            else:
                g.guardrail_files_changed.append(path)
                if shadow is not None:
                    g.policy_shadows[path] = {
                        **shadow[1], "kind": config_transition(shadow[0], change.after),
                    }
            if not change.before:
                g.guardrail_files_created.append(path)
                if shadow is None and path in _OWN_CONFIG_PATHS and _created_config_loosens(change.after):
                    g.guardrail_configs_created_loosening.append(path)
        elif role == "ci" and test_obligations:
            # A JS/TS test kept in a CI directory is test code, and the test
            # rules judge its lines. Read as shell, a line naming the runner
            # beside `|| true` would be a weakened command (#197 Q5). The edit
            # still surfaces as CI_WORKFLOW_TOUCHED at warn.
            g.ci_files_changed.append(path)
        elif role == "ci":
            g.ci_files_changed.append(path)
            if change.status == "deleted" and _is_ci_workflow(path) and (
                    _runs_tests(change.before) or holds_runner_site(path, change.before)):
                # Deleting or relocating a workflow removes the gate outright,
                # which is at least as strong a signal as weakening a command
                # inside it — but only if that workflow ran the tests. Firing
                # on any removal blocked commits that dropped a lint-only
                # workflow (reader audit 2026-08-02, attrs 20734d9 dropping
                # pinact.yml). A removed non-test workflow still surfaces as
                # CI_WORKFLOW_TOUCHED at warn: visible, not blocking.
                g.ci_weakening_lines.append((path, "workflow file removed"))
            _scan_ci_weakening(g, path, change.before, change.after, ci_base)
        elif role == "snapshot":
            g.snapshot_files_changed.append(path)
            # Standalone stored-oracle rewrites need both content digests too.
            # This remains valid when no production file appears in the diff.
            if change.status == "modified":
                file_ir.change_evidence = _change_evidence(change, rename_destinations)

        if is_python and before_parsed is not None and before_parsed.parse_ok:
            base_literals.update(before_parsed.literals)

        if is_python:
            before_sup = _suppression_texts(before_parsed)
            after_sup = _suppression_texts(after_parsed)
            for text, count in (after_sup - before_sup).items():
                g.suppressions_added.extend([f"{path}:{text}"] * count)
            if (
                before_parsed is not None
                and after_parsed is not None
                and before_parsed.parse_ok
                and after_parsed.parse_ok
            ):
                added_imports = sorted(set(after_parsed.imports) - set(before_parsed.imports))
            elif change.status == "added" and after_parsed is not None and after_parsed.parse_ok:
                added_imports = sorted(set(after_parsed.imports))
            else:
                added_imports = []
            for module in added_imports:
                g.imports_added.append(f"{path}:{module}")
                if resolvable is not None and module.split(".", 1)[0] not in resolvable:
                    g.unresolved_imports.append((path, module))
        if is_python or is_js_test:
            # A test file is judged on handlers that actually swallow an
            # oracle; production code on every broad handler added, because
            # there the cheat is silencing the error instead of fixing it.
            def _handlers(parsed: ParsedFile | None) -> tuple[str, ...]:
                if parsed is None or not parsed.parse_ok:
                    return ()
                if judged_test or role == "conftest":
                    return parsed.swallowing_handlers
                return parsed.broad_handlers

            before_broad = Counter(_handlers(before_parsed))
            after_broad = Counter(_handlers(after_parsed))
            added = after_broad - before_broad
            after_relays = Counter(
                after_parsed.relay_handlers
                if after_parsed is not None and after_parsed.parse_ok and (judged_test or role == "conftest")
                else ()
            )
            if added and after_relays:
                # A proven failure relay is not a swallow (D-190), but only
                # as far as 0.10 counts, and never on the before side's
                # word: per handler text, the additions are the smaller of
                # 0.10's count and the after side's swallowing handlers that
                # are not proven relays. So no change reports one that 0.10
                # would not, and a relay made proven in the same change
                # cannot offset a new swallow of the same text, which the
                # before side's handlers would otherwise account for; an
                # edit elsewhere that makes an unchanged relay unread
                # reports nothing, and a broken relay is not reported, as
                # on 0.10 (THREATMODEL row 171).
                added &= after_broad - after_relays
            for text, count in sorted(added.items()):
                g.broad_excepts_added.extend([(path, text)] * count)

    g.base_literals = sorted(base_literals)
    # packages with >=1 genuinely modified symbol; deliberately NOT every
    # package with any prod change (see PACKAGE_REPAIR credit above).
    g.prod_packages = sorted(set(g.prod_packages))
    g.suppressions_added.sort()
    g.imports_added.sort()
    g.unresolved_imports.sort()
    g.broad_excepts_added.sort()
    g.ci_weakening_lines.sort()
    g.hidden_unicode.sort()
    g.scope_drift.sort()
    g.exemptions_added.sort()

    if g.snapshot_files_changed and g.prod_files_changed and not g.test_logic_changed:
        # This event includes every production co-change, including opaque
        # files. Hash companions only when the snapshot detector can fire.
        paths = set(g.snapshot_files_changed) | set(g.prod_files_changed)
        selected_changes = {
            c.path.replace("\\", "/"): c for c in expanded_changes
            if c.path.replace("\\", "/") in paths
        }
        for file in ir.files:
            if file.path in paths and file.change_evidence is None:
                file.change_evidence = _change_evidence(selected_changes[file.path], rename_destinations)

    # D6 constant environments, resolved here so gating stays a pure function
    # of the IR: same-file constants first, then names imported from files in
    # this diff, then from the head snapshot (click's `from click._compat
    # import WIN`, where _compat.py is not in the diff at all — FP sweep).
    for file in ir.files:
        parsed = after_by_path.get(file.path)
        if (judged_as_test(file) or file.role == "conftest") and parsed is not None:
            file.constants = _gate_constants(parsed, after_by_path, head_reader)
            file.fixture_defs = dict(parsed.fixture_defs)
            file.module_constants = _canonical_constants(parsed.constants)
            before = before_by_path.get(file.path)
            if before is not None:
                file.constants_before = _gate_constants(before, before_by_path, None)
                file.fixture_defs_before = dict(before.fixture_defs)
                file.module_constants_before = _canonical_constants(before.constants)
                _mark_weakened_guards(file)

    relocation_sources = {change.path.replace("\\", "/"): (change.before, change.after) for change in expanded_changes}
    relocation_initializers = {}
    relocation_context_sources = {}
    relocation_context_bytes = 0
    relocation_context_unknown = object()
    relocation_context_inventory = {}
    relocation_context_paths = {}
    relocation_side_observations = {}
    rename_sources = {(change.old_path or change.path).replace("\\", "/") for change in changes
                      if change.old_path and change.old_path.replace("\\", "/") != change.path.replace("\\", "/")}
    for change in changes:
        path = change.path.replace("\\", "/")
        old = (change.old_path or path).replace("\\", "/")
        if old != path:
            observations = ((old, 0, change.before, False), (path, 1, change.after, False),
                            (path, 0, None, True), (old, 1, None, True))
        else:
            # An added record can describe a recreated rename source. Its
            # missing local before field does not erase the rename's bytes.
            inferred = change.status == "added" and path in rename_sources and change.before is None
            observations = ((path, 0, change.before, inferred), (path, 1, change.after, False))
        for candidate, side, data, inferred in observations:
            relocation_side_observations.setdefault((candidate, side), []).append((data, inferred))

    def _relocation_observed_source(candidate, side):
        observations = relocation_side_observations[(candidate, side)]
        actual = [data for data, inferred in observations if not inferred]
        if not actual:
            return None
        value = actual[0]
        if any(data != value for data in actual[1:]):
            raise ValueError("conflicting optional oracle-context source observations")
        return value

    def _relocation_context_source(candidate, side):
        """Optional proof reads use their actual side; unchanged paths use HEAD."""
        nonlocal relocation_context_bytes
        if (not isinstance(candidate, str) or not candidate or "\\" in candidate or ":" in candidate
                or "\0" in candidate or any(part in {"", ".", ".."} for part in candidate.split("/"))):
            raise ValueError("invalid optional oracle-context source path")
        if root_reader is None:
            raise ValueError("optional oracle context requires a strict snapshot")
        changed = (candidate, side) in relocation_side_observations
        key = (candidate, side if changed else -1)
        if key not in relocation_context_sources:
            if len(relocation_context_sources) >= 256:
                raise ValueError("optional oracle-context source read budget exhausted")
            # Charge attempts before calling an external reader. A refused,
            # invalid or oversized path remains unknown and is never reread.
            relocation_context_sources[key] = relocation_context_unknown
            if relocation_context_bytes >= 2 * 1024 * 1024:
                raise ValueError("optional oracle-context source byte budget exhausted")
            data = _relocation_observed_source(candidate, side) if changed else root_reader(candidate)
            if data is not None and not isinstance(data, bytes):
                raise ValueError("optional oracle-context source is unknown or too large")
            if data is not None:
                relocation_context_bytes += len(data)
                if len(data) > 65536:
                    raise ValueError("optional oracle-context source is unknown or too large")
                if relocation_context_bytes > 2 * 1024 * 1024:
                    raise ValueError("optional oracle-context source byte budget exhausted")
                if report_context is not None:
                    for recorded_side in ((0, 1) if key[1] == -1 else (side,)):
                        report_context.snapshot(candidate, recorded_side, data)
            relocation_context_sources[key] = data
        if relocation_context_sources[key] is relocation_context_unknown:
            raise ValueError("optional oracle-context source remains unknown")
        return relocation_context_sources[key]

    def _relocation_context_search(needles, side):
        """Reconstruct the complete nonempty Python inventory on the actual side."""
        if needles != [""] or root_searcher is None:
            raise ValueError("optional oracle context requires a strict source inventory")
        if side not in relocation_context_inventory:
            relocation_context_inventory[side] = relocation_context_unknown
            if -1 not in relocation_context_inventory:
                # Reserve the failed state before discovery: a failure must
                # not repeatedly invoke an external snapshot searcher.
                relocation_context_inventory[-1] = relocation_context_unknown
                paths = root_searcher([""])
                if not isinstance(paths, (list, tuple)) or len(paths) >= 64:
                    raise ValueError("optional oracle-context inventory is unknown or too large")
                normalized = set()
                for candidate in paths:
                    if not isinstance(candidate, str):
                        raise ValueError("invalid optional oracle-context inventory path")
                    candidate = candidate.replace("\\", "/")
                    if (not candidate.endswith(".py") or ":" in candidate or "\0" in candidate
                            or any(part in {"", ".", ".."} or any(ord(c) < 32 for c in part)
                                   for part in candidate.split("/")) or candidate in normalized):
                        raise ValueError("invalid optional oracle-context inventory path")
                    normalized.add(candidate)
                relocation_context_inventory[-1] = frozenset(normalized)
            paths = relocation_context_inventory[-1]
            if paths is relocation_context_unknown:
                raise ValueError("optional oracle-context inventory remains unknown")
            selected = set(paths)
            # HEAD discovery alone is never BASE authority. Observed source
            # records account for additions, deletions and both rename ends;
            # conflicts withhold this optional proof independently of order.
            changed_paths = {candidate for candidate, observed_side in relocation_side_observations
                             if observed_side == side and candidate.endswith(".py")}
            for candidate in sorted(changed_paths):
                data = _relocation_context_source(candidate, side)
                selected.discard(candidate)
                if data:
                    selected.add(candidate)
            if len(selected) >= 64:
                raise ValueError("optional oracle-context inventory is too large")
            relocation_context_inventory[side] = tuple(sorted(selected))
        if relocation_context_inventory[side] is relocation_context_unknown:
            raise ValueError("optional oracle-context inventory remains unknown")
        return list(relocation_context_inventory[side])

    def _relocation_context_path_list(side):
        """Complete side-correct entry names also cover non-Python aliases."""
        if root_path_lister is None:
            raise ValueError("optional oracle context requires complete path metadata")
        if side not in relocation_context_paths:
            relocation_context_paths[side] = relocation_context_unknown
            if -1 not in relocation_context_paths:
                relocation_context_paths[-1] = relocation_context_unknown
                paths = root_path_lister()
                if not isinstance(paths, (list, tuple)) or len(paths) > 512:
                    raise ValueError("optional oracle-context path metadata is unknown or too large")
                normalized = set()
                for candidate in paths:
                    if not isinstance(candidate, str):
                        raise ValueError("invalid optional oracle-context metadata path")
                    candidate = candidate.replace("\\", "/")
                    if (":" in candidate or any(part in {"", ".", ".."} or any(ord(c) < 32 for c in part)
                                                for part in candidate.split("/")) or candidate in normalized):
                        raise ValueError("invalid optional oracle-context metadata path")
                    normalized.add(candidate)
                relocation_context_paths[-1] = frozenset(normalized)
            paths = relocation_context_paths[-1]
            if paths is relocation_context_unknown:
                raise ValueError("optional oracle-context path metadata remains unknown")
            selected = set(paths)
            for candidate, observed_side in sorted(relocation_side_observations):
                if observed_side != side:
                    continue
                data = _relocation_observed_source(candidate, side)
                if data is not None and not isinstance(data, bytes):
                    raise ValueError("optional oracle-context entry presence is unknown")
                selected.discard(candidate)
                if data is not None:  # Empty files still exist in the complete entry inventory.
                    selected.add(candidate)
            if len(selected) > 512:
                raise ValueError("optional oracle-context path metadata is too large")
            relocation_context_paths[side] = tuple(sorted(selected))
        if relocation_context_paths[side] is relocation_context_unknown:
            raise ValueError("optional oracle-context path metadata remains unknown")
        return list(relocation_context_paths[side])

    def _relocation_startup(path, side, data):
        if data is None:
            return None
        proof = []
        for level in _conftest_chain(path, side, data):
            if level.star or level.adds_marks:
                return None
            source = chain_sources.get((level.path, side if level.path in chain_sides else -1))
            if source is None or b"request" in source:
                return None
            proof.append((level.path, hashlib.sha256(source.replace(b"\r\n", b"\n")).hexdigest()))
        # Importing the test package executes each ancestor initializer
        # before the unit. Equal conftest chains alone cannot prove equality.
        parts = path.split("/")[:-1]
        if len(parts) > 16 or root_reader is None:
            return None
        for depth in range(len(parts), -1, -1):
            initializer = "/".join([*parts[:depth], "__init__.py"])
            key = (initializer, side if initializer in relocation_sources else -1)
            if key not in relocation_initializers:
                if len(relocation_initializers) >= 64:
                    return None
                if initializer in relocation_sources:
                    source = relocation_sources[initializer][side]
                else:
                    try:
                        source = root_reader(initializer)
                    except (EngineError, OSError, ValueError, TypeError):
                        return None
                if source is not None and (not isinstance(source, bytes) or len(source) > 65536):
                    return None
                relocation_initializers[key] = source
                if source is not None and report_context is not None:
                    for recorded_side in ((0, 1) if key[1] == -1 else (side,)):
                        report_context.snapshot(initializer, recorded_side, source)
            source = relocation_initializers[key]
            if source:
                proof.append((initializer, hashlib.sha256(source.replace(b"\r\n", b"\n")).hexdigest()))
        return repr(proof)

    # Context proofs supplement (never replace) source admission/liveness.
    # Unknown startup context cannot establish oracle equivalence.
    for file in ir.files:
        needed = {unit.qualname for unit in file.units if unit.before is None or unit.after is None
                  or (unit.delta is not None and (unit.delta.assertions_removed or unit.delta.assertions_added))}
        if not needed:
            continue
        sources = relocation_sources.get(file.path, (None, None))
        for side_index, field in enumerate(("before", "after")):
            data = sources[side_index]
            sides = [(unit.qualname, getattr(unit, field)) for unit in file.units
                     if getattr(unit, field) is not None]
            startup = _relocation_startup(file.path, side_index, data) if file.language == "python" else ""
            mark_contexts(data, sides, file.path, file.language, startup_known=startup is not None,
                          startup=startup, needed=needed,
                          source_reader=(lambda candidate, side=side_index: _relocation_context_source(candidate, side))
                          if root_reader is not None else None,
                          source_searcher=(lambda needles, side=side_index: _relocation_context_search(needles, side))
                          if root_searcher is not None else None,
                          source_path_lister=(lambda side=side_index: _relocation_context_path_list(side))
                          if root_path_lister is not None else None)

    # A Python arrival pays only where the head's own pytest configuration
    # certainly collects it (D-193); without a snapshot there is no proof to
    # spend either.
    def python_collected(path, qualname, source):
        collection_ = python_collection()
        return collection_ is not None and collection_(path, qualname, source)

    # Move credits, counted after the constant environments exist because
    # liveness now consults them. Assertions (and whole units) landing in a
    # unit that does not run never count as "moved" — a sacrificial
    # @pytest.mark.skip test must not buy D2 de-escalation for real deletions
    # (confirmed red-team finding) — but a unit carried across files together
    # with its own compat gate is not dead, it is relocated (FP sweep, click
    # a391797d00 / 700798252a).
    removed_units: Counter[str] = Counter()
    added_units: Counter[str] = Counter()
    # Only an arrival or its added assertions can pay (oracle_credit.
    # arrival_credits), and only for a disappeared unit or a removed
    # assertion, so nothing is read unless both are there.
    payable = any(unit.before is not None and (unit.after is None or (
        unit.delta is not None and unit.delta.assertions_removed)) for file in ir.files for unit in file.units)
    for file in ir.files:
        constants = file.constants
        # A unit that reappears in a JS file its runner does not collect does
        # not run there, so it is not live (#196 186.7).
        js_collected = file.path not in js_head_runners or collected(file.path, js_head_runners[file.path])
        python_test = payable and file.language == "python" and judged_as_test(file)
        for unit in file.units:
            live_after = unit.after is not None and js_collected and unit_is_live(unit.after, constants)
            if live_after and python_test and (unit.before is None or (
                    unit.delta is not None and unit.delta.assertions_added)):
                live_after = python_collected(file.path, unit.qualname,
                                              relocation_sources.get(file.path, (None, None))[1])
            if unit.after is not None and not live_after:
                unit.after.oracle_context = ""
                unit.after.oracle_assertion_contexts = {}
            if unit.delta is not None and unit.before is not None and unit.after is not None:
                b_by_id = {a.id: a for a in unit.before.assertions}
                a_by_id = {a.id: a for a in unit.after.assertions}
                for aid in unit.delta.assertions_removed:
                    if aid in b_by_id:
                        removed_texts[normalize_text(b_by_id[aid].text)] += 1
                if live_after:
                    for aid in unit.delta.assertions_added:
                        # An assertion reached through a helper method earns
                        # no credit for another finding (306 Sub-Q11).
                        if aid in a_by_id and a_by_id[aid].via is None:
                            added_texts[normalize_text(a_by_id[aid].text)] += 1
            elif unit.before is not None and unit.after is None:
                for a in unit.before.assertions:
                    # ... nor adds a requirement to a disappeared unit's.
                    if a.via is None:
                        removed_texts[normalize_text(a.text)] += 1
                if unit.before.body_hash:
                    removed_units[unit.before.body_hash] += 1
            elif unit.after is not None and unit.before is None:
                if live_after:
                    for a in unit.after.assertions:
                        if a.via is None:
                            added_texts[normalize_text(a.text)] += 1
                    if unit.after.body_hash:
                        added_units[unit.after.body_hash] += 1

    # Multiset, not set (SPEC §7): deleting the same assertion from two tests
    # while adding one copy elsewhere must leave one deletion unexplained.
    # `set(a) & set(b)` credited both (confirmed bypass). Only as many
    # removals as there are additions may be called "moved". Units spend the
    # same way through their body hashes.
    moved = removed_texts & added_texts  # Counter intersection = min of counts
    g.moved_assertion_texts = sorted(moved.elements())
    g.moved_unit_hashes = sorted((removed_units & added_units).elements())

    # Duplicate survivors: a disappeared unit whose identical live body still
    # exists at head in a file this diff never touched. The needle search is
    # one batched call (git grep in range mode); only matching files are read
    # and parsed, capped. Deleting one of two identical copies leaves the
    # oracle running — the attack shapes (survivor skipped, survivor edited)
    # fail the liveness and hash checks and earn nothing. A survivor reaches
    # the conftest fixtures above it at head, as a changed module does, so
    # one that an always-skip fixture skips is not live either (#266).
    if head_searcher is not None and head_reader is not None:
        wanted: set[str] = set()
        needles: set[str] = set()
        for file in ir.files:
            if not judged_as_test(file) and file.role != "conftest":
                continue
            for unit in file.units:
                if unit.before is not None and unit.after is None and unit.before.body_hash:
                    h = unit.before.oracle_context
                    if not h:
                        continue
                    if any(u.before is None and u.after is not None and u.after.oracle_context == h
                           for candidate in ir.files for u in candidate.units):
                        continue  # relocated within the diff; D2 covers it
                    wanted.add(h)
                    leaf = unit.qualname.rsplit(".", 1)[-1].split("#", 1)[0]
                    needles.add(f"def {leaf}(")
        if wanted:
            diff_paths = {f.path for f in ir.files}
            candidates = sorted(
                p.replace("\\", "/")
                for p in head_searcher(sorted(needles))
                if p.replace("\\", "/") not in diff_paths
                and p.endswith(".py")
                # A copy pytest still collects keeps running, whatever role
                # its path holds (#219, ruling 219.Q1).
                and collectable(p.replace("\\", "/"))
            )
            found: set[str] = set()
            for path in candidates[:_MAX_DUP_READS]:
                data = head_reader(path)
                if data is None:
                    continue
                parsed = parse_python(
                    data, collect_tests=True, chain=_conftest_chain(path, 1, data), imported=_imported_helpers(path, 1)
                )
                if not parsed.parse_ok:
                    continue
                consts = _gate_constants(parsed, after_by_path, head_reader)
                startup = _relocation_startup(path, 1, data)
                mark_contexts(data, [(pu.qualname, pu.side) for pu in parsed.units], path, "python",
                              startup_known=startup is not None, startup=startup,
                              source_reader=(lambda candidate: _relocation_context_source(candidate, 1))
                              if root_reader is not None else None,
                              source_searcher=(lambda needles: _relocation_context_search(needles, 1))
                              if root_searcher is not None else None,
                              source_path_lister=(lambda: _relocation_context_path_list(1))
                              if root_path_lister is not None else None)
                for pu in parsed.units:
                    if (pu.side.oracle_context in wanted and unit_is_live(pu.side, consts)
                            and python_collected(path, pu.qualname, data)):
                        found.add(pu.side.oracle_context)
            g.duplicate_unit_hashes = sorted(found)
    for path, unit, target, text, span in installation_events(
        ir, changes, config, root_reader=root_reader, root_searcher=root_searcher, root_path_lister=root_path_lister,
    ):
        if unit is None:
            if (path, text) not in g.conftest_prod_patches:
                g.conftest_prod_patches.append((path, text))
        else:
            g.subject_installations.append((path, unit, target, text, span))
    for event in subject_replacement_events(ir, changes, root_reader=root_reader,
                                          root_searcher=root_searcher, root_path_lister=root_path_lister):
        if event not in g.subject_installations:
            g.subject_installations.append(event)
    for event in callable_fixture_subject_events(ir, changes, root_reader=root_reader, root_searcher=root_searcher):
        if event not in g.subject_installations:
            g.subject_installations.append(event)
    for event in local_parameter_implementation_events(ir, changes, root_reader=root_reader, root_searcher=root_searcher):
        if event not in g.subject_installations:
            g.subject_installations.append(event)
    for event in fixture_local_implementation_events(ir, changes, root_reader=root_reader, root_searcher=root_searcher):
        if event not in g.subject_installations:
            g.subject_installations.append(event)
    for event in parametrized_string_standin_events(ir, changes, root_reader=root_reader, root_searcher=root_searcher):
        if event not in g.subject_installations:
            g.subject_installations.append(event)
    # The JavaScript spelling: a newly installed first-party module mock or
    # replacing spy that an existing JS unit's own assertions read (#177).
    # An alias resolves through the base side's root tsconfig.json (#196 188.6).
    read_tsconfig = _base_root_file(changes, root_reader, "tsconfig.json", unread_changes)
    for event in module_mock_events(ir, changes, read_tsconfig):
        if event not in g.subject_installations:
            g.subject_installations.append(event)
    # The same stand-in installed from a setup file the runner loads before
    # every test file, judged as a conftest patch is: no unit (#218).
    for event in setup_file_events(changes, _base_manifest(changes, root_reader, unread_changes), read_tsconfig):
        if event not in g.subject_installations:
            g.subject_installations.append(event)
    mark_table_normalization(ir, raw_by_path, root_reader, root_searcher)
    mark_param_input_identity(ir, raw_by_path, root_reader)
    mark_normalization_equivalence(ir, raw_by_path, root_reader, root_searcher)
    mark_expected_provenance(ir, raw_by_path, root_reader, config.role_of, report_context,
                             {path: data for (path, side), data in oracle_sources.items()
                              if side == -1 and (path, side) in strict_oracle_sources}, root_searcher)
    # The JavaScript port of the same channel (#226).
    mark_js_expected_provenance(ir, raw_by_path)
    # Report the changed regular target, with explicit logical-config
    # context in the reason. Its existing FileIR is genuine raw-diff source;
    # no synthetic regular FileIR or target span is attached to a link.
    files_by_path = {file.path: file for file in ir.files}
    for path, change in sorted(config_report_changes.items()):
        if path not in files_by_path:
            raise EngineError(f"pytest config physical change has no file evidence: path={path!r}")
        if files_by_path[path].status != change.status:
            raise EngineError(f"pytest config physical change has incompatible file evidence: path={path!r}")
        files_by_path[path].change_evidence = _change_evidence(change, rename_destinations)
        if path not in g.ci_files_changed:
            g.ci_files_changed.append(path)
    return ir


def run_detectors(ir: IR, config: Config) -> list[Finding]:
    findings: list[Finding] = []
    for rule, detect in REGISTRY.items():
        if rule in config.disabled_detectors:
            continue
        findings.extend(detect(ir))
    findings.sort(key=lambda f: f.sort_key())
    return findings


def analyze(
    changes: list[FileChange],
    config: Config,
    contract: Contract,
    allow_entries: list[AllowEntry],
    today: datetime.date,
    base_label: str = "base",
    head_label: str = "head",
    known_modules: set[str] | None = None,
    self_modules: set[str] | None = None,
    head_reader=None,
    head_searcher=None,
    report_context: ReportContext | None = None,
    root_reader=None,
    root_searcher=None,
    root_path_lister=None,
    root_batch_reader=None,
    pytest_configs=None,
    policy_base=None,
) -> tuple[IR, list[Finding], str]:
    ir = build_ir(
        changes,
        config,
        base_label,
        head_label,
        scope_allow=contract.scope_allow,
        known_modules=known_modules,
        self_modules=self_modules,
        head_reader=head_reader,
        head_searcher=head_searcher,
        report_context=report_context,
        root_reader=root_reader,
        root_searcher=root_searcher,
        root_path_lister=root_path_lister,
        root_batch_reader=root_batch_reader,
        pytest_configs=pytest_configs,
        policy_base=policy_base,
    )
    findings = run_detectors(ir, config)
    verdict = apply_gates(ir, findings, contract, config, allow_entries, today)
    return ir, findings, verdict
