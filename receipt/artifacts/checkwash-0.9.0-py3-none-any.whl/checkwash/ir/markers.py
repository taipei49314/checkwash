"""Parsing helpers over Marker source text, shared by the engine and gating.

A Marker's `text` is the decorator or call source as written; its optional
`guard` is the enclosing-if conjunction the frontend recorded. Both sides of
D6 need the same reading of them: the engine to decide which names it must
resolve, gating to evaluate the condition. Every parse failure degrades to
None — an unreadable condition stays unevaluable and earns nothing.

`parse_text` is how shared code parses text that may not be Python (#319).
"""

from __future__ import annotations

import ast
import warnings


def marker_call(text: str) -> ast.Call | None:
    """The marker's Call node, or None when the text is not a call."""
    src = text.strip()
    if src.startswith("@"):
        src = src[1:]
    node = parse_expr(src)
    return node if isinstance(node, ast.Call) else None


def parse_text(text: str, mode: str = "exec") -> ast.AST | None:
    """`ast.parse` of text that may not be Python, without its warnings; None if it fails.

    Shared code reads assertion texts, subjects and whole sources with Python's
    parser, and some of them are JavaScript or TypeScript. The tokenizer warns
    on such text (`0.invalid` is an invalid decimal literal, `'\\d'` an
    invalid escape) before the parse fails, and the warning reached stderr
    naming no file and no line of the user's code (#319).
    """
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        try:
            return ast.parse(text, mode=mode)
        except (SyntaxError, RecursionError, ValueError, TypeError, MemoryError):
            return None


def parse_expr(text: str) -> ast.AST | None:
    # Wrapped in parens so multi-line sources (a guard recorded from a
    # multi-line `if`) parse without continuation errors.
    tree = parse_text(f"({text})", mode="eval")
    return tree.body if tree is not None else None


def mark_condition(call: ast.Call) -> ast.AST | None:
    """The condition a `skipif` or `xfail` mark's first argument holds (#263).

    pytest compiles a string condition as an expression and evaluates that,
    so `skipif("sys.platform == 'win32'")` holds the condition `sys.platform
    == 'win32'`, not a string that is truthy everywhere. A string that does
    not compile as one is None: pytest reports an error for it, and it earns
    nothing. Any other argument is the condition itself, and a call with none
    has none.
    """
    if not call.args:
        return None
    condition = call.args[0]
    if isinstance(condition, ast.Constant) and isinstance(condition.value, str):
        try:
            return ast.parse(condition.value, mode="eval").body
        except (SyntaxError, RecursionError, ValueError, MemoryError):
            return None
    return condition


def is_string_condition(call: ast.Call) -> bool:
    """Is the mark's condition a string, which pytest evaluates in its own namespace?"""
    return bool(call.args) and isinstance(call.args[0], ast.Constant) and isinstance(call.args[0].value, str)


def bare_names(node: ast.AST) -> set[str]:
    """Every ast.Name id in the expression (attribute roots included)."""
    return {n.id for n in ast.walk(node) if isinstance(n, ast.Name)}


# Imperative body skips whose recorded `if` guard is their condition, as D6
# reads them (compat._GATE_CALLS without the conftest control): each native
# skip or xfail a test body calls or raises, by the one name the frontend
# gives its object (`setup_skip_controls.BODY_MARKERS`, #220), save
# `importorskip`, whose condition is what is installed.
# tests/test_issue220_body_skip_aliases.py holds the two lists together.
GUARDED_SKIP_CALLS = frozenset({
    "pytest.skip", "pytest.xfail", "self.skipTest",
    "pytest.skip.Exception", "pytest.xfail.Exception", "unittest.SkipTest",
})


# The pytest marks a `pytestmark` binding can carry a guard for: its path
# condition, which D6 reads as it reads a body skip's (#260 Q2).
GUARDED_MARKS = frozenset({"pytest.mark.skip", "pytest.mark.skipif", "pytest.mark.xfail"})


def is_guarded_mark(name: str) -> bool:
    """Is this a pytest skip or xfail mark, whose `pytestmark` binding may carry a guard?"""
    return name.split("(", 1)[0] in GUARDED_MARKS


def is_setup_skip(name: str) -> bool:
    """A skip or xfail in the setup a unit runs: a fixture it reaches or xunit setup (#172, #223)."""
    return name.startswith("setup.")


def is_helper_skip(name: str) -> bool:
    """A skip or xfail a helper the unit or its setup calls ends in, same-file or imported (#272)."""
    return name.startswith("helper.")


# The marker a Python test def or class carries when a later binding of its
# name may replace it (#424, `frontends/python/rebindings.py`). Its guard is
# the condition that binding runs under, and None when no condition D6 can
# read says when: a loop body, a conditional binder, a `match` case, mid-way
# through a `try` body. A binding that certainly replaces it leaves no unit.
REBOUND = "collection.rebound"


def is_rebound(name: str) -> bool:
    """A later binding of the test's name that may replace it (#424)."""
    return name == REBOUND


def is_guarded_skip(name: str) -> bool:
    """Does this marker's recorded guard say when it fires?

    The body skips D6 reads, a skip in the setup a unit runs, whose guard
    is the condition its setup callback reaches it under (#196 183.2), one
    a helper ends in, whose guard is the condition its call reaches it
    under (#272), and a later binding of the test's name, whose guard is
    the condition that binding runs under (#424).
    """
    return name in GUARDED_SKIP_CALLS or is_setup_skip(name) or is_helper_skip(name) or is_rebound(name)


def skip_condition(marker, side) -> str | None:
    """What a body skip ran under on one side, as far as the IR records it.

    Its recorded `if` guard first. A skip with none that sits inside an
    `except` block runs only when that block catches, so the block's first
    line stands for its condition: `try: import numpy` / `except
    ImportError:` / `pytest.skip(...)` is an optional-dependency gate, not an
    unconditional kill. None when neither holds, so nothing the IR records
    keeps the skip from firing. Loop bodies and `match` cases record no
    condition (#196 183.2). A setup skip's guard already holds its `except`
    blocks, and its evidence lies in a fixture or callback outside the unit,
    which no handler of the unit encloses. So does a rebinding's: it is a
    statement after the test, never inside it (#424).
    """
    if marker.guard:
        return marker.guard
    if is_setup_skip(marker.name) or is_helper_skip(marker.name) or is_rebound(marker.name):
        # These spans belong to a callback/helper, possibly in another
        # file. Equal offsets do not mean the unit's handler encloses it.
        return None
    start, end = marker.span
    inside = [h for h in side.handlers if h.span[0] <= start and end <= h.span[1]]
    if not inside:
        return None
    return min(inside, key=lambda h: h.span[1] - h.span[0]).text
