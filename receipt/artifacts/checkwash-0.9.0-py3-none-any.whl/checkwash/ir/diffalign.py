"""Two-sided semantic-unit alignment (SPEC §7 — parameters frozen).

Order of operations:
1. exact qualname pairing
2. structural-fingerprint pairing (k=5 shingles, Jaccard >= 0.8, greedy by
   descending score, ties by ascending before-span start)
3. leftovers are removed/added units

Assertion pairing inside a matched unit:
1. exact normalized-text multiset matches; in Python, then the same parsed
   statement, so a quote or line respelled (black) pairs (#332)
2. (form, normalized left operand) key, in span order
3. leftovers: span-order fallback; in Python, among a unit's own
   assertions, an old assertion first takes a leftover that checks the same
   subject, written out or through one plain local binding (#434 A)
4. Python, own assertions: a bare `pytest.raises(E)` still unpaired takes an
   unused `pytest.raises(E, match=...)` of the same callee, expected types
   and other keywords (#434 B)

A marker is added when no marker on the other side has its identity; in
Python, a condition that parses the same is the same identity (#332), and in
JavaScript, a condition that reads the same once its formatting is taken out
(#333).

A fallback pair whose two halves record different subjects and different
expected literals does not compare its tolerances (#196 189.2). A tolerance
change takes the new side's kind; an old bare value of another kind is keyed
with its own (#196 190.3).
"""

from __future__ import annotations

import ast
from collections import Counter
from decimal import Decimal, InvalidOperation

from checkwash.frontends.javascript.literals import comparable_operand
from checkwash.frontends.python.frontend import ParsedFile, ParsedUnit
from checkwash.ir.astutil import same_expr, same_raises_check, stable_dump
from checkwash.ir.markers import is_helper_skip, is_setup_skip, parse_text
from checkwash.ir.model import (
    AssertionPair,
    FileIR,
    ParamTable,
    Unit,
    UnitDelta,
    UnitSide,
    normalize_text,
    param_tables,
)
from checkwash.ir.subjects import subject_key

JACCARD_THRESHOLD = 0.8  # frozen, SPEC §7
MAX_UNPAIRED = 64  # frozen, SPEC §7


# The effect of each body skip `GUARDED_SKIP_CALLS` names (#220's one name
# per object), for a skip moved into a helper or out of one (#272).
_BODY_SKIP_EFFECTS = {
    "pytest.skip": "skip", "self.skipTest": "skip", "pytest.skip.Exception": "skip",
    "unittest.SkipTest": "skip", "pytest.xfail": "xfail", "pytest.xfail.Exception": "xfail",
}


def _skip_effect(name: str) -> str | None:
    if is_helper_skip(name) or is_setup_skip(name):
        return name.rsplit(".", 1)[1]
    return _BODY_SKIP_EFFECTS.get(name)


def _moved_skip(old, new) -> bool:
    """Is `new` the skip `old` was, moved into a helper the test calls or out of one (#272)?

    A helper's marker is named for the helper, so a skip carried from the
    test's body or the setup it runs into a helper it calls, out of one, or
    into a renamed one, changes its name and nothing else. The effect must be
    the same, and the old skip must have fired at least as often:
    unconditionally (no guard), or under the same condition, whose meaning
    `evidence._mark_weakened_guards` still compares across the diff. A skip
    respelled in place, the body to the body, is not this (#281).
    """
    if not (is_helper_skip(old.name) or is_helper_skip(new.name)):
        return False
    if _skip_effect(old.name) != _skip_effect(new.name):
        return False
    return old.guard is None or same_expr(old.guard, new.guard)


def _jaccard(a: frozenset, b: frozenset) -> float:
    if not a and not b:
        return 1.0
    union = len(a | b)
    if union == 0:
        return 0.0
    return len(a & b) / union


def _parsed_key(text: str) -> str | None:
    """A Python statement as parsed, or None: quotes and line breaks spelled
    another way (black's `'x'` -> `"x"`) read the same (#332)."""
    tree = parse_text(text.strip())
    return stable_dump(tree) if tree is not None else None


_JS_CONDITIONAL = "test.skipIf("


def _marker_key(marker, python: bool) -> object:
    """A marker's identity, its condition as parsed in Python (#332), or with
    its formatting taken out in JavaScript (#333).

    The identity is the marker's name and the normalized text of its condition
    (`pytest.mark.skipif(sys.platform=='win32')`,
    `test.skipIf(process.platform==='win32')`), and normalized text keeps
    quote characters as written, so a condition respelled `"win32"` (black,
    prettier) was a marker removed and another added. The name stays the
    reported identity.
    """
    if python and "(" in marker.name:
        tree = parse_text(marker.text.strip().removeprefix("@"), mode="eval")
        if tree is not None and isinstance(tree.body, ast.Call) and tree.body.args:
            return marker.name.split("(", 1)[0], stable_dump(tree.body.args[0])
    if not python and marker.name.startswith(_JS_CONDITIONAL) and marker.name.endswith(")"):
        return _JS_CONDITIONAL, comparable_operand(marker.name[len(_JS_CONDITIONAL):-1])
    return marker.name


def _pair_assertions(before: ParsedUnit, after: ParsedUnit, python: bool = False) -> UnitDelta:
    # A unit's own assertions pair exactly as they always have. Those it
    # reaches through a helper method (`via`, #306) are a detection-only
    # overlay (306 Sub-Q11): they pair afterwards, among themselves and with
    # the after side's own assertions left unpaired.
    b_own = [b for b in before.side.assertions if b.via is None]
    a_own = [a for a in after.side.assertions if a.via is None]
    pairs, removed, added = _match_assertions(b_own, a_own, python, own=True)
    b_via = [b for b in before.side.assertions if b.via is not None]
    a_via = [a for a in after.side.assertions if a.via is not None]
    if b_via or a_via:
        rest = sorted(a_via + added, key=lambda x: x.span)
        via_pairs, via_removed, added = _match_assertions(b_via, rest, python)
        pairs += via_pairs
        removed += via_removed
    return _delta(before, after, pairs, removed, added, python)


def _compatible(b, a) -> bool:
    """May the order fallback pair these two? Both strengths known, or one form."""
    return (b.strength is not None and a.strength is not None) or b.form == a.form


def _subject_partner(b, leftovers: list, used: list[bool], keys: list) -> int | None:
    """The leftover an old assertion takes first in the order fallback (#434 A), or None.

    A compatible, unused leftover that checks the old assertion's subject
    (`ir.subjects.same_subject`, through each leftover's `subject_key` in
    `keys`): written out, or through one plain local binding, read in the
    same context. Among those, the same form comes first, then at least the
    old strength, then span order. None when no leftover checks that
    subject, and the fallback keeps today's rule.
    """
    key = subject_key(b)
    if key is None:
        return None
    best = None
    best_rank = None
    for j, a in enumerate(leftovers):
        if used[j] or keys[j] != key or not _compatible(b, a):
            continue
        weaker = b.strength is not None and (a.strength is None or a.strength < b.strength)
        rank = (a.form != b.form, weaker)
        if best_rank is None or rank < best_rank:
            best, best_rank = j, rank
    return best


def _raises_partner(b, leftovers: list, used: list[bool]) -> int | None:
    """The unused `match=` call a removed bare raises call pairs with (#434 B), or None."""
    if b.form != "raises":
        return None
    for j, a in enumerate(leftovers):
        if not used[j] and a.form == "pattern" and same_raises_check(b.text, a.text):
            return j
    return None


def _match_assertions(
    b_asserts: list, a_asserts: list, python: bool, own: bool = False
) -> tuple[list, list, list]:
    """(pairs, removed, added) for two lists of assertions: the staged matching below.

    `own`: these are a unit's own assertions, not those it reaches through a
    helper method (`via`), so the two Python passes of #434 apply.
    """
    b_asserts = list(b_asserts)
    a_asserts = list(a_asserts)
    pairs: list[tuple] = []  # (before, after, from_order_fallback)

    # 0. exact (normalized text, reaching context) matches (multiset).
    # Identical texts used to pair FIFO in source order, so inserting a new
    # case mid-function shifted every later pairing by one: the untouched
    # assertion paired with the inserted twin and their reaching definitions
    # disagreed (R1, sympy's repeated-oracle shape). `reaching_sig` carries
    # the direct names' reaching context — same-file inherited copies carry
    # their call site's, which is how N copies of one helper assert match
    # their own site's twin (issue #55); assertions without one ("" — the
    # cross-file and fixture-channel inherited ones) behave exactly as
    # before.
    a_by_ctx: dict[tuple[str, str], list] = {}
    for a in a_asserts:
        a_by_ctx.setdefault((normalize_text(a.text), a.reaching_sig), []).append(a)
    b_ctx_rest = []
    for b in b_asserts:
        bucket = a_by_ctx.get((normalize_text(b.text), b.reaching_sig))
        if bucket:
            pairs.append((b, bucket.pop(0), False))
        else:
            b_ctx_rest.append(b)
    b_asserts = b_ctx_rest
    a_asserts = [a for bucket in a_by_ctx.values() for a in bucket]
    a_asserts.sort(key=lambda x: x.span)

    # 1. exact normalized-text matches (multiset)
    a_by_text: dict[str, list] = {}
    for a in a_asserts:
        a_by_text.setdefault(normalize_text(a.text), []).append(a)
    b_rest = []
    for b in b_asserts:
        bucket = a_by_text.get(normalize_text(b.text))
        if bucket:
            pairs.append((b, bucket.pop(0), False))
        else:
            b_rest.append(b)
    a_rest = [a for bucket in a_by_text.values() for a in bucket]
    a_rest.sort(key=lambda x: x.span)

    # 1b. Python: the same statement parsed (multiset). Normalized text keeps
    # quote characters as written, so black's respelling matched nothing
    # above, and every bare assert of a unit, which records no subject, then
    # shared one key below and paired in span order: a test's own check with
    # the one its conftest fixture lends it, read as a flipped polarity
    # (flask 025589ee, #332).
    if python:
        a_by_tree: dict[str, list] = {}
        a_kept = []
        for a in a_rest:
            key = _parsed_key(a.text)
            if key is None:
                a_kept.append(a)
            else:
                a_by_tree.setdefault(key, []).append(a)
        b_rest_tree = []
        for b in b_rest:
            key = _parsed_key(b.text)
            bucket = a_by_tree.get(key) if key is not None else None
            if bucket:
                pairs.append((b, bucket.pop(0), False))
            else:
                b_rest_tree.append(b)
        b_rest = b_rest_tree
        a_rest = a_kept + [a for bucket in a_by_tree.values() for a in bucket]
        a_rest.sort(key=lambda x: x.span)

    # 2. (form, left) key
    a_by_key: dict[tuple, list] = {}
    for a in a_rest:
        a_by_key.setdefault((a.form, normalize_text(a.left or "")), []).append(a)
    b_rest2 = []
    for b in b_rest:
        bucket = a_by_key.get((b.form, normalize_text(b.left or "")))
        if bucket:
            pairs.append((b, bucket.pop(0), False))
        else:
            b_rest2.append(b)
    a_rest2 = [a for bucket in a_by_key.values() for a in bucket]
    a_rest2.sort(key=lambda x: x.span)

    # 3. order fallback — but never absorb a classifiable assertion into an
    # unclassifiable one (or vice versa): pairing assertEqual with an added
    # assertRaises would yield strength_change=None and silently suppress
    # ASSERT_REMOVED (confirmed red-team finding). A fallback pair requires
    # either both strengths known, or an identical form.
    #
    # In Python, an own old assertion first takes a leftover that checks its
    # subject (#434 A, ruling 2026-10-16). Span order alone gave
    # `assert area(4, 5) == 20.0` the `isinstance(result, float)` precondition
    # written above its rewrite `assert result == 20.0`, and that blocked as a
    # weakening, while the two lines swapped passed. The pair stays a fallback
    # pair, so every rule reads it as it reads the swapped order's. Old
    # assertions are still taken in span order; one with no such leftover
    # left keeps today's rule. With one leftover the two rules agree, so the
    # subjects are read only when there are two or more.
    subject_first = python and own
    keys = [subject_key(a) for a in a_rest2] if subject_first and b_rest2 and len(a_rest2) > 1 else None
    used = [False] * len(a_rest2)
    removed = []
    for b in b_rest2:
        idx = _subject_partner(b, a_rest2, used, keys) if keys is not None else None
        if idx is None:
            for j, a in enumerate(a_rest2):
                if used[j]:
                    continue
                if _compatible(b, a):
                    idx = j
                    break
        if idx is None:
            removed.append(b)
        else:
            used[idx] = True
            pairs.append((b, a_rest2[idx], True))

    # 4. Python, own assertions: a bare `pytest.raises(E)` the fallback could
    # not pair takes an unused `pytest.raises(E, match=...)` of the same
    # callee, the same expected types and the same other keywords (#434 B).
    # The fallback refuses a pair of an unknown strength with another form,
    # so adding `match=` read as the bare call removed. This runs after the
    # fallback: where an excinfo assert folded into `match=` took the new
    # call there, the bare call stays removed (`raises_match_fold_neg`), and
    # ASSERT_REMOVED says the raise is still checked. The pair records no
    # strength change, which every pair rule skips.
    if subject_first and removed:
        kept = []
        for b in removed:
            idx = _raises_partner(b, a_rest2, used)
            if idx is None:
                kept.append(b)
            else:
                used[idx] = True
                pairs.append((b, a_rest2[idx], False))
        removed = kept
    added = [a for j, a in enumerate(a_rest2) if not used[j]]
    return pairs, removed, added


def _delta(before: ParsedUnit, after: ParsedUnit, pairs: list, removed: list, added: list, python: bool) -> UnitDelta:
    pairs.sort(key=lambda p: p[0].span)
    assertion_pairs = []
    tolerance_changes: list[tuple[str, str]] = []
    for b, a, fallback in pairs:
        change = None
        if b.strength is not None and a.strength is not None:
            change = a.strength - b.strength
        assertion_pairs.append(
            AssertionPair(
                before_id=b.id, after_id=a.id, strength_change=change, fallback=fallback
            )
        )
        recorded = tolerance_change(b, a, fallback, change)
        if recorded is not None:
            tolerance_changes.append(recorded)

    # A marker is kept when its identity is on the base side (#332); one that
    # is not is matched against the base's leftovers as a skip moved into or
    # out of a helper (#272).
    pool = [(_marker_key(b, python), b) for b in before.side.markers]
    unmatched = []
    for m in after.side.markers:
        key = _marker_key(m, python)
        kept = next((entry for entry in pool if entry[0] == key), None)
        if kept is not None:
            pool.remove(kept)
        else:
            unmatched.append(m)
    markers_added = []
    markers_moved = []
    for m in unmatched:
        moved_from = next((entry for entry in pool if _moved_skip(entry[1], m)), None)
        if moved_from is not None:
            pool.remove(moved_from)
            markers_moved.append((moved_from[1].name, m.name))
        else:
            markers_added.append(m.name)

    b_handler_texts = {normalize_text(h.text) for h in before.side.handlers}
    handlers_widened = [
        h.text
        for h in after.side.handlers
        if h.is_broad and normalize_text(h.text) not in b_handler_texts
    ]

    before_cases = before.side.param_cases
    after_cases = after.side.param_cases
    # A JS/TS `.each`/`.for` table whose rows cannot be counted (#428). Only
    # the JS frontend sets the flag, so no Python reading moves.
    before_unknown = getattr(before.side, "param_rows_unknown", False)
    after_unknown = getattr(after.side, "param_rows_unknown", False)
    param_removed = 0
    if before_unknown or after_unknown:
        # Between two tables the count rule stays silent when either side
        # is unknown (428.Q1b). A plain test, which runs once, paired with
        # such a table is that one test item lost, as it is beside a table
        # of no rows below (428.Q2a); a table that becomes a plain test with
        # its rows unknown loses nothing countable.
        if before_cases is None and not before_unknown:
            param_removed = 1
    elif not python and before_cases is None and after_cases == 0:
        # A plain JS/TS test, one item, paired with a table of no rows: the
        # JS counterpart of Python's empty-parameter-set rule (428.Q2a,
        # `frontends/python/empty_parameter_sets.py`). A Python test with no
        # count can still be parametrized by a hook, so Python keeps its
        # two-sided proof instead.
        param_removed = 1
    elif before_cases is not None and after_cases is not None and after_cases < before_cases:
        param_removed = before_cases - after_cases
    elif before_cases is not None and after_cases is None:
        param_removed = before_cases - 1
    # The count above is satisfied by any edit that keeps the total; row
    # identity is a floor on it, never a ceiling (see `_param_rows_lost`).
    param_disabled = 0
    identity = _param_rows_lost(before.side, after.side)
    if identity is not None:
        lost, disabled_only = identity
        param_removed = max(param_removed, lost)
        param_disabled = min(disabled_only, param_removed)

    return UnitDelta(
        assertion_pairs=assertion_pairs,
        assertions_removed=[b.id for b in sorted(removed, key=lambda x: x.span)],
        assertions_added=[a.id for a in sorted(added, key=lambda x: x.span)],
        markers_added=markers_added,
        markers_moved=markers_moved,
        handlers_widened=handlers_widened,
        tolerance_changes=tolerance_changes,
        param_cases_removed=max(0, param_removed),
        param_cases_disabled=max(0, param_disabled),
    )


def _rows_lost(before: ParamTable, after: ParamTable) -> tuple[int, int, int]:
    """(live rows before, rows deleted, rows no longer running) for one table.

    A row's identity is its cell texts, read through `pytest.param`, so
    marking a row does not change it. Of the rows that ran before:

    - one still present but marked off is disabled -- the count rule cannot
      see it, and it is the whole finding;
    - one gone from the table entirely is a deletion *or* an edit, and the
      rows alone cannot tell those apart. An edit belongs to
      `EXPECTATION_DEFINITION_CHANGED`, so the residual is left to the count
      rule's arithmetic (`vanished - arrived`): an edit brings a replacement
      row with it and nets to zero, a deletion does not. That is also why a
      deleted row *plus* an unrelated appended row stays silent here -- a
      documented residual, not an accident.
    """
    live_before = Counter(r for r, d in zip(before.rows, before.disabled) if not d)
    live_after = Counter(r for r, d in zip(after.rows, after.disabled) if not d)
    dead_after = Counter(r for r, d in zip(after.rows, after.disabled) if d)
    still = live_before & live_after
    left = live_before - still
    marked = left & dead_after
    vanished = sum((left - marked).values())
    arrived = sum((live_after - still).values())
    deleted = max(0, vanished - arrived)
    return sum(live_before.values()), deleted, sum(marked.values()) + deleted


def _product(values) -> int:
    total = 1
    for v in values:
        total *= v
    return total


def _param_rows_lost(
    before_side: UnitSide, after_side: UnitSide
) -> tuple[int, int] | None:
    """Parametrized test items that ran before and do not run after, counted
    by row *identity* rather than by how many rows are left.

    `param_cases` is a count of live rows, so the arithmetic that reads it
    (`before - after`) is satisfied by any edit that keeps the total: wrap one
    row in `pytest.param(..., marks=pytest.mark.skip)` and append another, and
    a disabled test item is reported as no event at all (F-063 -- the same
    "count, not identity" mistake the column string makes for expectations in
    F-060). Appending a row is not a reason to stop reporting the row that
    stopped running.

    Returns `(lost, disabled_only)`: the number of *original* test items
    that no longer run, and how many of those are lost to marks alone (no
    deleted row involved). Stacked decorators multiply into test items, so
    both are computed on counts per table rather than by expanding the
    cross product: with `b_i` live rows before, `v_i` deleted and `l_i` no
    longer running in table `i`, the items that ran before are `prod(b_i)`,
    the ones that still run `prod(b_i - l_i)`, and the ones that would still
    run if only the deletions had happened `prod(b_i - v_i)`. Two tables of
    two rows that each skip one row and append one lose 3 of their 4 items,
    not 2 and not 4.

    None -- and the caller keeps the count rule -- when the before side has
    no readable tables, or when any of them cannot be paired with exactly one
    after table binding the same argnames (a renamed or added column, the
    same argnames bound twice, a table the frontend could not read). Pairing
    on anything weaker would report rows as lost on nothing better than
    decorator order. Extra tables on the after side do not block the
    pairing: a new decorator multiplies the original items but does not
    change whether their rows still run.
    """
    b_tables = param_tables(before_side)
    if not b_tables:
        return None
    a_by_names: dict[tuple[str, ...], list[ParamTable]] = {}
    for t in param_tables(after_side):
        a_by_names.setdefault(t.names, []).append(t)
    seen: set[tuple[str, ...]] = set()
    per_table: list[tuple[int, int, int]] = []
    for b in b_tables:
        partners = a_by_names.get(b.names, [])
        if b.names in seen or len(partners) != 1:
            return None
        seen.add(b.names)
        per_table.append(_rows_lost(b, partners[0]))
    original = _product(b for b, _, _ in per_table)
    without_deletions = _product(b - deleted for b, deleted, _ in per_table)
    surviving = _product(b - lost for b, _, lost in per_table)
    return original - surviving, without_deletions - surviving


def tolerance_change(b, a, fallback: bool, change: int | None) -> tuple[str, str, str] | None:
    """The (kind, before, after) tolerance change a paired assertion records, or None.

    Alignment records the changes and TOLERANCE_LOOSENED finds each one's
    pair with this same reading (#421), so neither can drift from the other.
    """
    # A fallback pair is paired by position, not identity. When both
    # halves moved, the subject and the expected literal alike, the old
    # check is gone and another holds its slot: EXPECTED_VALUE_CHANGED
    # reports this pair on the same conditions, usually beside
    # ASSERT_SUBSTITUTED, and the slack of the new check is no widening
    # of the old one's. `abs(a - 1) < 0.01` deleted beside an added
    # `abs(b - 2) < 1` is such a pair, and `abs(x - c) < eps` read as
    # `abs=eps` makes them commoner (#196 189.2). A subject that moved
    # alone is still compared: `t = total()` hoisted above
    # `assertAlmostEqual(t, 78.75, delta=1e12)` is the old check
    # widened, and so is any rename. A side with no recorded subject (a
    # bare `pytest.approx` comparison) or no literal is compared too.
    if (
        fallback
        and change is not None
        and change >= 0
        and b.left is not None
        and a.left is not None
        and not same_expr(b.left, a.left)
        and b.right_value is not None
        and a.right_value is not None
        and b.right_value != a.right_value
    ):
        return None
    if b.epsilon is None or a.epsilon is None:
        return None
    kind = a.epsilon_kind or b.epsilon_kind or "abs"
    old = b.epsilon
    # A change takes the new side's kind, and a bare value reads as
    # that kind. A bare value of another kind is keyed with its own
    # (#196 190.3): `places=2` -> `delta=10` is not "delta=2 ->
    # delta=10", and `places=7` -> `delta=7` is no value left alone.
    if "=" not in old and b.epsilon_kind not in (None, kind):
        old = f"{b.epsilon_kind}={old}"
    if old == a.epsilon:
        return None
    try:
        respelled = old == b.epsilon and Decimal(a.epsilon) == Decimal(b.epsilon)
    except InvalidOperation:
        respelled = False
    return None if respelled else (kind, old, a.epsilon)


def align_file(
    path: str,
    role: str,
    status: str,
    before: ParsedFile | None,
    after: ParsedFile | None,
    max_unpaired: int = MAX_UNPAIRED,
) -> FileIR:
    parse_ok = (before is None or before.parse_ok) and (after is None or after.parse_ok)
    b_units = list(before.units) if before and before.parse_ok else []
    a_units = list(after.units) if after and after.parse_ok else []

    units: list[Unit] = []
    alignment = "full"

    # Names are not unique (for example Jest tests in separate describe
    # blocks). Preserve every occurrence, matching unchanged bodies first
    # within a same-name group before pairing remaining occurrences in order.
    a_by_name: dict[str, list[ParsedUnit]] = {}
    b_by_name: dict[str, list[ParsedUnit]] = {}
    for a in a_units:
        a_by_name.setdefault(a.qualname, []).append(a)
    for b in b_units:
        b_by_name.setdefault(b.qualname, []).append(b)
    paired_b: list[tuple[ParsedUnit, ParsedUnit, str]] = []
    b_unpaired: list[ParsedUnit] = []
    for name, before_group in b_by_name.items():
        after_group = a_by_name.get(name, [])
        unmatched = []
        for b in before_group:
            exact = next((i for i, a in enumerate(after_group)
                          if b.side.body_hash and b.side.body_hash == a.side.body_hash), None)
            if exact is not None:
                paired_b.append((b, after_group.pop(exact), "by_name"))
            else:
                unmatched.append(b)
        for b in unmatched:
            if after_group:
                paired_b.append((b, after_group.pop(0), "by_name"))
            else:
                b_unpaired.append(b)
    a_unpaired = sorted((a for group in a_by_name.values() for a in group), key=lambda u: u.span)

    if b_unpaired and a_unpaired:
        if len(b_unpaired) > max_unpaired or len(a_unpaired) > max_unpaired:
            alignment = "degraded"
        else:
            candidates = []
            for b in b_unpaired:
                for a in a_unpaired:
                    score = _jaccard(b.shingles, a.shingles)
                    if score >= JACCARD_THRESHOLD:
                        candidates.append((-score, b.span[0], a.span[0], b, a))
            candidates.sort(key=lambda c: (c[0], c[1], c[2]))
            used_b: set[int] = set()
            used_a: set[int] = set()
            for _neg, _bs, _as, b, a in candidates:
                if id(b) in used_b or id(a) in used_a:
                    continue
                used_b.add(id(b))
                used_a.add(id(a))
                paired_b.append((b, a, "by_fingerprint"))
            b_unpaired = [b for b in b_unpaired if id(b) not in used_b]
            a_unpaired = [a for a in a_unpaired if id(a) not in used_a]

    for b, a, how in paired_b:
        units.append(
            Unit(
                kind="test_function",
                qualname=a.qualname,
                match=how,
                before=b.side,
                after=a.side,
                delta=_pair_assertions(b, a, python=path.endswith(".py")),
            )
        )
    for b in b_unpaired:
        units.append(
            Unit(kind="test_function", qualname=b.qualname, match=None, before=b.side, after=None, delta=None)
        )
    for a in a_unpaired:
        # A conftest that did not exist at base brings every control it
        # carries, and those controls act on tests that *do* exist. Added
        # units get no delta, and TEST_DISABLED needs one, so this was the
        # one place the marker pipeline never looked: a new `conftest.py`
        # containing `collect_ignore = ["test_billing.py"]` took a failing
        # suite to "no tests ran" and produced no finding of any severity
        # (row 82, reproduced 2026-08-07).
        #
        # Scoped to conftest deliberately. A brand-new *test* file born with
        # `@pytest.mark.xfail` is a bug repro, the most ordinary commit in
        # test-driven work, and it stays silent — measured, not assumed.
        added_controls = (
            before is None
            and role == "conftest"
            and a.qualname == "<suite>"
            and bool(a.side.markers)
        )
        units.append(
            Unit(
                kind="test_function",
                qualname=a.qualname,
                match=None,
                before=None,
                after=a.side,
                delta=(
                    UnitDelta(markers_added=[m.name for m in a.side.markers])
                    if added_controls
                    else None
                ),
            )
        )

    units.sort(key=lambda u: ((u.before or u.after).span, u.qualname))
    language = "python" if path.endswith(".py") else "unknown"
    return FileIR(
        path=path,
        language=language,
        role=role,
        status=status,
        units=units,
        alignment=alignment,
        parse_ok=parse_ok,
    )
