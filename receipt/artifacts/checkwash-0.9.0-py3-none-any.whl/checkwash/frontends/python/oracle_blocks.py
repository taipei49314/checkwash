"""Keep a complete string-oracle block through scalar helper extraction.

The accepted block evaluates the imported subject once, then asserts its
length, string prefix and exact string value. Every assertion stays in the
projected body. Helper arguments are literal scalars; only len(str/bytes)
and max(literal integers) are folded, with unshadowed builtin names. The
caller additionally proves closed pure imported source and compares all
auxiliary checks. This is not general multi-statement helper inlining.
"""

import ast
import copy


IMPLICIT_ENTRY_NAMES = {"setup_module", "teardown_module", "setup_function", "teardown_function",
                        "setup_class", "teardown_class", "setup_method", "teardown_method", "setup", "teardown",
                        "setUpModule", "tearDownModule", "setUpClass", "tearDownClass", "setUp", "tearDown",
                        "pytestmark"}


def _args(node):
    if not isinstance(node, ast.FunctionDef):
        return None
    args = node.args
    if (node.decorator_list or node.returns or getattr(node, 'type_params', ()) or args.posonlyargs
            or args.kwonlyargs or args.defaults or args.vararg or args.kwarg
            or any(arg.annotation for arg in args.args)):
        return None
    return [arg.arg for arg in args.args]


def _scalar(node):
    try:
        return type(ast.literal_eval(node)) in (type(None), bool, int, float, str, bytes)
    except (ValueError, SyntaxError, TypeError, MemoryError, RecursionError):
        return False


class _Bindings(ast.NodeTransformer):
    def __init__(self, values):
        self.values = values

    def visit_Name(self, node):
        return copy.deepcopy(self.values.get(node.id, node))


class _LiteralBuiltins(ast.NodeTransformer):
    def visit_Call(self, node):
        node = self.generic_visit(node)
        if not isinstance(node.func, ast.Name) or node.keywords:
            return node
        if (node.func.id == 'len' and len(node.args) == 1 and isinstance(node.args[0], ast.Constant)
                and type(node.args[0].value) in (str, bytes)):
            return ast.copy_location(ast.Constant(value=len(node.args[0].value)), node)
        if (node.func.id == 'max' and 1 < len(node.args) <= 64
                and all(isinstance(arg, ast.Constant) and type(arg.value) is int for arg in node.args)):
            return ast.copy_location(ast.Constant(value=max(arg.value for arg in node.args)), node)
        return node


def _dictionary_field_block(function):
    """Retain every checked field as a primitive dictionary expectation.

    Matching a later complete dictionary oracle can strengthen the old field
    checks, but it cannot drop or rewrite one without an expectation change.
    Custom mappings need their original dispatch and receive no projection.
    """
    if not 3 <= len(function.body) <= 9:
        return None
    assignment, *checks = function.body
    if (not isinstance(assignment, ast.Assign) or len(assignment.targets) != 1
            or not isinstance(assignment.targets[0], ast.Name) or not isinstance(assignment.value, ast.Call)
            or not all(isinstance(check, ast.Assert) and check.msg is None for check in checks)):
        return None
    local = assignment.targets[0].id
    keys, values, seen = [], [], set()
    for check in checks:
        compare = check.test
        if (not isinstance(compare, ast.Compare) or len(compare.ops) != 1 or not isinstance(compare.ops[0], ast.Eq)
                or not isinstance(compare.left, ast.Subscript) or not isinstance(compare.left.value, ast.Name)
                or compare.left.value.id != local or not isinstance(compare.left.slice, ast.Constant)
                or type(compare.left.slice.value) is not str or compare.left.slice.value in seen
                or not _scalar(compare.comparators[0])):
            return None
        seen.add(compare.left.slice.value)
        keys.append(copy.deepcopy(compare.left.slice))
        values.append(copy.deepcopy(compare.comparators[0]))
    if any(isinstance(node, ast.Name) and node.id == local for node in ast.walk(assignment.value)):
        return None
    primary = ast.copy_location(ast.Assert(test=ast.Compare(left=copy.deepcopy(assignment.value), ops=[ast.Eq()],
        comparators=[ast.Dict(keys=keys, values=values)]), msg=None), checks[-1])
    primary._requires_primitive_string = True
    primary._partial_dictionary_fields = True
    return primary, None


def _implied_membership_block(function):
    """Literal membership checks entailed by the final primitive string value.

    The caller must prove primitive, side-effect-free production results.
    A custom equality or containment implementation cannot earn this credit.
    """
    if not 3 <= len(function.body) <= 6:
        return None
    assignment, *checks = function.body
    if (not isinstance(assignment, ast.Assign) or len(assignment.targets) != 1
            or not isinstance(assignment.targets[0], ast.Name) or not isinstance(assignment.value, ast.Call)
            or not all(isinstance(check, ast.Assert) and check.msg is None for check in checks)):
        return None
    local = assignment.targets[0].id
    exact = checks[-1].test
    if (not isinstance(exact, ast.Compare) or len(exact.ops) != 1 or not isinstance(exact.ops[0], ast.Eq)
            or not isinstance(exact.left, ast.Name) or exact.left.id != local
            or not isinstance(exact.comparators[0], ast.Constant) or type(exact.comparators[0].value) is not str
            or any(isinstance(node, ast.Name) and node.id == local for node in ast.walk(assignment.value))):
        return None
    expected = exact.comparators[0].value
    for check in checks[:-1]:
        compare = check.test
        if (not isinstance(compare, ast.Compare) or len(compare.ops) != 1
                or not isinstance(compare.ops[0], (ast.In, ast.NotIn))
                or not isinstance(compare.left, ast.Constant) or type(compare.left.value) is not str
                or not isinstance(compare.comparators[0], ast.Name) or compare.comparators[0].id != local):
            return None
        holds = compare.left.value in expected
        if holds != isinstance(compare.ops[0], ast.In):
            return None
    primary = copy.deepcopy(checks[-1])
    primary.test.left = copy.deepcopy(assignment.value)
    primary._requires_primitive_string = True
    return primary, None


def string_block(function):
    """One subject call, length/prefix checks, then the exact string oracle."""
    # Literal string messages have no deferred calls or formatting effects.
    # Normalize only these diagnostics before comparing complete auxiliary
    # bodies; every checked expression and expected value stays intact.
    if any(isinstance(node, ast.Assert) and isinstance(node.msg, ast.Constant)
           and type(node.msg.value) is str for node in function.body):
        function = copy.deepcopy(function)
        for node in function.body:
            if isinstance(node, ast.Assert) and isinstance(node.msg, ast.Constant) and type(node.msg.value) is str:
                node.msg = None
    dictionary = _dictionary_field_block(function)
    if dictionary is not None:
        return dictionary
    implied = _implied_membership_block(function)
    if implied is not None:
        return implied
    if len(function.body) != 4:
        return None
    assignment, length, prefix, exact = function.body
    if (not isinstance(assignment, ast.Assign) or len(assignment.targets) != 1
            or not isinstance(assignment.targets[0], ast.Name) or not isinstance(assignment.value, ast.Call)
            or not all(isinstance(node, ast.Assert) and node.msg is None for node in (length, prefix, exact))):
        return None
    local = assignment.targets[0].id
    a, b, c = length.test, prefix.test, exact.test
    if not (isinstance(a, ast.Compare) and len(a.ops) == 1 and isinstance(a.ops[0], ast.Eq)
            and isinstance(a.left, ast.Call) and isinstance(a.left.func, ast.Name) and a.left.func.id == 'len'
            and len(a.left.args) == 1 and not a.left.keywords and isinstance(a.left.args[0], ast.Name)
            and a.left.args[0].id == local and isinstance(a.comparators[0], ast.Constant)
            and type(a.comparators[0].value) is int):
        return None
    if not (isinstance(b, ast.Call) and isinstance(b.func, ast.Attribute) and b.func.attr == 'startswith'
            and isinstance(b.func.value, ast.Name) and b.func.value.id == local
            and len(b.args) == 1 and not b.keywords and isinstance(b.args[0], ast.Constant)
            and type(b.args[0].value) is str):
        return None
    if not (isinstance(c, ast.Compare) and len(c.ops) == 1 and isinstance(c.ops[0], ast.Eq)
            and isinstance(c.left, ast.Name) and c.left.id == local
            and isinstance(c.comparators[0], ast.Constant) and type(c.comparators[0].value) is str):
        return None
    if any(isinstance(node, ast.Name) and node.id == local for node in ast.walk(assignment.value)):
        return None
    primary = copy.deepcopy(exact)
    primary.test.left = copy.deepcopy(assignment.value)
    canonical = _Bindings({local: ast.Name(id='_oracle_result', ctx=ast.Load())}).visit(copy.deepcopy(function))
    canonical.body[0].targets[0].ctx = ast.Store()
    return primary, canonical.body


def expand_string_blocks(tree):
    candidates = {node.name: node for node in tree.body if isinstance(node, ast.FunctionDef)
                  and not node.name.startswith(('test', 'pytest_')) and node.name not in IMPLICIT_ENTRY_NAMES
                  and _args(node) is not None and len(node.body) == 4}
    if not candidates and not any(isinstance(node, ast.FunctionDef) and len(node.body) == 4 for node in tree.body):
        return set()
    for name in candidates:
        count = sum(isinstance(item, (ast.FunctionDef, ast.ClassDef)) and item.name == name
                    or isinstance(item, ast.Name) and isinstance(item.ctx, ast.Store) and item.id == name
                    or isinstance(item, ast.arg) and item.arg == name
                    or isinstance(item, ast.alias) and (item.asname or item.name.split('.')[0]) == name
                    for item in ast.walk(tree))
        if count != 1:
            return None
    if any((isinstance(node, ast.Name) and isinstance(node.ctx, ast.Store) and node.id in {'len', 'max'})
           or (isinstance(node, ast.arg) and node.arg in {'len', 'max'})
           or (isinstance(node, (ast.FunctionDef, ast.ClassDef)) and node.name in {'len', 'max'})
           or (isinstance(node, ast.alias) and (node.asname or node.name.split('.')[0]) in {'len', 'max'})
           for node in ast.walk(tree)):
        return None
    result, expanded, used = [], set(), set()
    for node in tree.body:
        if isinstance(node, ast.FunctionDef) and node.name in candidates:
            continue
        if isinstance(node, ast.FunctionDef) and node.name.startswith('test') and _args(node) == []:
            if len(node.body) == 1 and isinstance(node.body[0], ast.Expr) and isinstance(node.body[0].value, ast.Call):
                call = node.body[0].value
                if isinstance(call.func, ast.Name) and call.func.id in candidates:
                    helper = candidates[call.func.id]
                    parameters = _args(helper)
                    if (call.keywords or len(call.args) != len(parameters) or len(set(parameters)) != len(parameters)
                            or not all(_scalar(arg) for arg in call.args)
                            or any(isinstance(item, ast.Name) and isinstance(item.ctx, ast.Store) and item.id in parameters
                                   for item in ast.walk(helper))):
                        return None
                    body = _Bindings(dict(zip(parameters, call.args))).visit(copy.deepcopy(helper)).body
                    node.body = body
                    used.add(call.func.id)
            node = _LiteralBuiltins().visit(node)
            if string_block(node) is not None:
                expanded.add(node.name)
        if any(isinstance(item, ast.Name) and item.id in candidates for item in ast.walk(node)):
            return None
        result.append(node)
    if used != candidates.keys():
        return None
    tree.body = result
    return expanded
