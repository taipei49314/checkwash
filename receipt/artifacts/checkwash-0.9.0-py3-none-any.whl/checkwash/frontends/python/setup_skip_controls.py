"""Native pytest setup callbacks that skip a collected test.

Only an unconditional native skip/xfail supplies this evidence: a call to
`pytest.skip`/`pytest.xfail` (or `self.skipTest`), or a raise of the exception
they raise or of unittest's `SkipTest`, with plain arguments, as a statement
every run of the callback executes before it can return, raise or hand control
to the test. Unknown module execution, decorators, bindings, control flow and
hook signatures do not establish that the setup callback suppresses a test.

That one reading (`callback_outcome`) is shared by every path a unit's setup
runs through (issue #172): the closed `pytest_runtest_setup` hook proof below,
conftest fixtures as suite-level runtime controls (`fixture_setup_controls`),
and a test module's own fixtures and xunit setup callbacks as markers on the
units that reach them (`SetupScope`, `setup_outcomes`).

A guarded skip is not this evidence: its guard is its justification, and an
environment condition is not something a source reading can settle. A unit's
setup still records it, with that guard (`setup_outcome`, #196 183.2), so it
is judged as a guarded skip in a test body is: in its own module's fixtures
and xunit setup, and in the conftest fixtures it reaches (`ConftestLevel`,
#223), whose guard is first closed over the conftest's names (`ConftestGuard`,
#351). The `<suite>` control reads only the unconditional outcome.
"""
from __future__ import annotations

import ast
from dataclasses import dataclass, field

from checkwash.ir.astutil import dotted_name


def _body(statements):
    return [statement for statement in statements if not (
        isinstance(statement, ast.Expr) and isinstance(statement.value, ast.Constant)
        and type(statement.value.value) is str)]


def _resolve(node, bindings):
    name = dotted_name(node)
    if not name:
        return None
    first, dot, rest = name.partition('.')
    target = bindings.get(first)
    return _pytest_name(target + dot + rest) if target else None


def _pytest_name(name):
    """`name` with the py library's `py.test` read as the pytest module it is (#310).

    py 1.11.0 maps its `test` attribute to `pytest` and binds
    `sys.modules['py.test'] = pytest`, so `py.test.skip` is `pytest.skip`
    itself, one object under one name as `_pytest.outcomes`' are (#220).
    """
    return 'pytest' + name[len('py.test'):] if name == 'py.test' or name.startswith('py.test.') else name


def _decorator(node, bindings, target, keywords):
    if not isinstance(node, ast.Call):
        return _resolve(node, bindings) == target and target == 'pytest.fixture'
    return (_resolve(node.func, bindings) == target and not node.args
            and len({kw.arg for kw in node.keywords}) == len(node.keywords)
            and all(kw.arg in keywords and isinstance(kw.value, ast.Constant)
                    and type(kw.value.value) is bool for kw in node.keywords))


# Native calls that end setup in a skip or xfail outcome, and the exceptions
# those calls raise. pytest's unittest plugin reports unittest's SkipTest as a
# skip wherever it is raised, so raising it is the same act spelled through
# the standard library. Twisted's trial exports that same class as its own
# `SkipTest` (#220). `importorskip` is deliberately absent: whether it skips
# depends on what is installed, which no reading of the source decides.
_OUTCOME_CALLS = {
    'pytest.skip': 'skip', 'pytest.xfail': 'xfail', 'self.skipTest': 'skip',
    '_pytest.outcomes.skip': 'skip', '_pytest.outcomes.xfail': 'xfail',
}
_OUTCOME_RAISES = {
    'pytest.skip.Exception': 'skip', 'pytest.xfail.Exception': 'xfail',
    '_pytest.outcomes.Skipped': 'skip', '_pytest.outcomes.XFailed': 'xfail',
    'unittest.SkipTest': 'skip', 'unittest.case.SkipTest': 'skip',
    'twisted.trial.unittest.SkipTest': 'skip',
}
_OUTCOME_KEYWORDS = frozenset({'reason', 'msg', 'allow_module_level'})
_NATIVE_MODULES = frozenset({'pytest', '_pytest', '_pytest.outcomes', 'unittest', 'unittest.case',
                             'twisted', 'twisted.trial', 'twisted.trial.unittest', 'py', 'py.test'})
# An argument that calls, awaits, yields, binds or unpacks runs code before
# the outcome, and that code could leave first.
_IMPURE = (ast.Call, ast.Await, ast.Yield, ast.YieldFrom, ast.NamedExpr, ast.Lambda, ast.Starred)
_SCOPES = (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef, ast.Lambda)
_LEAVES = (ast.Return, ast.Raise, ast.Yield, ast.YieldFrom)


def _plain(call):
    """At most a reason and the known flags, computed without running code."""
    values = [*call.args, *(keyword.value for keyword in call.keywords)]
    return (len(call.args) <= 1
            and all(keyword.arg in _OUTCOME_KEYWORDS for keyword in call.keywords)
            and len({keyword.arg for keyword in call.keywords}) == len(call.keywords)
            and not any(isinstance(node, _IMPURE) for value in values for node in ast.walk(value)))


def outcome_call(node, bindings):
    """'skip' or 'xfail' when `node` is a native outcome call with plain arguments."""
    if not isinstance(node, ast.Call) or not _plain(node):
        return None
    return _OUTCOME_CALLS.get(_resolve(node.func, bindings))


# A test body ends in the same outcomes, read through the same bindings, and
# the frontend's literal spellings are retired (#220). The body keeps
# `importorskip` (220.Q1): a test that starts calling it no longer runs
# wherever the module is missing.
_BODY_CALLS = {**_OUTCOME_CALLS, 'pytest.importorskip': 'skip'}
BODY_OUTCOMES = frozenset(_BODY_CALLS) | frozenset(_OUTCOME_RAISES)
# One object, one name. pytest's outcomes live in `_pytest.outcomes`, and
# trial's SkipTest is unittest's, so a skip respelled through another module
# that holds the same object is the skip the test already had, not a new one.
_SAME_OBJECT = {
    '_pytest.outcomes.skip': 'pytest.skip', '_pytest.outcomes.xfail': 'pytest.xfail',
    '_pytest.outcomes.Skipped': 'pytest.skip.Exception', '_pytest.outcomes.XFailed': 'pytest.xfail.Exception',
    'unittest.case.SkipTest': 'unittest.SkipTest', 'twisted.trial.unittest.SkipTest': 'unittest.SkipTest',
}
# The names a body skip's marker carries.
BODY_MARKERS = frozenset(_SAME_OBJECT.get(name, name) for name in BODY_OUTCOMES)


def _spelled(node, bindings):
    """`node`'s dotted name read through `bindings`, or its own spelling when its root is unbound.

    A bound root resolves to its binding, and to nothing when that is not a
    native module. An unbound root keeps its spelling, as the literal set read
    it: `pytest.skip` written without an import still names pytest's skip.
    """
    name = dotted_name(node)
    if not name:
        return None
    first, dot, rest = name.partition('.')
    if first not in bindings:
        return name
    target = bindings[first]
    return _pytest_name(target + dot + rest) if target else None


def body_outcome(node, bindings):
    """The canonical name of the native outcome a test body's call or raise spells, or None.

    Unlike setup's proof, any arguments count: a skip that computes its reason
    still ends the test, or the test errors first.
    """
    if isinstance(node, ast.Call):
        name = _spelled(node.func, bindings)
        return _SAME_OBJECT.get(name, name) if name in _BODY_CALLS else None
    if isinstance(node, ast.Raise) and node.exc is not None:
        raised = node.exc.func if isinstance(node.exc, ast.Call) else node.exc
        name = _spelled(raised, bindings)
        return _SAME_OBJECT.get(name, name) if name in _OUTCOME_RAISES else None
    return None


def body_bindings(function, bindings, *, method):
    """What a test function's names resolve to: the module's bindings, shadowed by its own.

    In a method the first parameter is the instance, so `self.skipTest`
    resolves. An import inside the test binds as one at module level does: a
    local `import pytest` is still pytest, as the literal spelling read it.
    """
    local = _local(function, bindings, method)
    for node in _executed(function.body):
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            local.update(_import_pairs(node) or ())
    return local


def _outcome(statement, bindings):
    """(effect, evidence) when this statement itself ends setup in an outcome."""
    if isinstance(statement, ast.Raise):
        raised = statement.exc
        if isinstance(raised, ast.Call) and _plain(raised):
            raised = raised.func
        # `from None` only hides the context: nothing runs and the outcome
        # propagates unchanged. Any other cause is an expression evaluated
        # first, which could raise instead, so it stays unproved.
        if raised is None or statement.cause is not None and not (
                isinstance(statement.cause, ast.Constant) and statement.cause.value is None):
            return None
        effect = _OUTCOME_RAISES.get(_resolve(raised, bindings))
        return (effect, statement) if effect else None
    if isinstance(statement, (ast.Expr, ast.Return, ast.Assign, ast.AnnAssign)):
        effect = outcome_call(statement.value, bindings)
        return (effect, statement.value) if effect else None
    return None


def _executed(nodes):
    """Every node these run, without entering nested function or class bodies."""
    stack = [node for node in nodes if not isinstance(node, _SCOPES)]
    while stack:
        node = stack.pop()
        yield node
        stack.extend(child for child in ast.iter_child_nodes(node) if not isinstance(child, _SCOPES))


def _may_leave(statements):
    """Can control return, raise or hand over to the test inside these?"""
    return any(isinstance(node, _LEAVES) for node in _executed(statements))


def _generator(function):
    return any(isinstance(node, (ast.Yield, ast.YieldFrom)) for node in _executed(function.body))


def _fold(test, attrs=None):
    """A branch test's truth, None for unknown.

    `attrs` is a (class attribute lookup, receiver names) pair: a setup
    callback's guard that reads `self.<attr>` is folded with the value its
    class body sets (#254), as a test body's guard is.
    """
    # Imported late: the frontend imports this module.
    from .frontend import _static_truth

    if attrs is not None:
        from .class_attributes import substitute

        test = substitute(test, *attrs)
    return _static_truth(test)


def _reached(statements, bindings):
    """(the first outcome every run reaches or None, whether later code may not run)."""
    for statement in statements:
        found = _outcome(statement, bindings)
        if found is not None:
            return found, True
        branch = None
        if isinstance(statement, ast.If):
            truth = _fold(statement.test)
            if truth is not None:
                branch = statement.body if truth else statement.orelse
        elif isinstance(statement, ast.Try) and not statement.handlers and not _may_leave(statement.finalbody):
            # No handler can catch the outcome and no `finally` can return
            # over it, so the body runs as straight-line code.
            branch = statement.body + statement.finalbody
        if branch is not None:
            found, stopped = _reached(branch, bindings)
            if found is not None or stopped:
                return found, True
        elif _may_leave([statement]):
            return None, True
    return None, False


def _names(nodes, *, mutated=False):
    """Names these statements bind; with `mutated`, also roots of assigned attributes."""
    names = set()
    stack = list(nodes)
    while stack:
        node = stack.pop()
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            names.add(node.name)
            continue
        if isinstance(node, ast.Lambda):
            continue
        if isinstance(node, (ast.Name, ast.Attribute, ast.Subscript)) and isinstance(node.ctx, (ast.Store, ast.Del)):
            root = node
            while isinstance(root, (ast.Attribute, ast.Subscript)):
                root = root.value
            if isinstance(root, ast.Name) and (root is node or mutated):
                names.add(root.id)
        elif isinstance(node, ast.alias):
            names.add(node.asname or node.name.split('.')[0])
        elif isinstance(node, (ast.ExceptHandler, ast.MatchAs, ast.MatchStar)) and node.name:
            names.add(node.name)
        elif isinstance(node, ast.MatchMapping) and node.rest:
            names.add(node.rest)
        elif isinstance(node, (ast.Global, ast.Nonlocal)):
            names.update(node.names)
        stack.extend(ast.iter_child_nodes(node))
    return names


def _local(function, bindings, receiver):
    args = function.args
    positional = [*args.posonlyargs, *args.args]
    params = [arg.arg for arg in (*positional, *args.kwonlyargs, args.vararg, args.kwarg) if arg is not None]
    stored = _names(function.body)
    local = {**bindings, **dict.fromkeys([*params, *sorted(stored)])}
    if receiver and positional and positional[0].arg not in stored:
        local[positional[0].arg] = 'self'
    return local


def callback_outcome(function, bindings, *, receiver=False):
    """(effect, evidence) for the first native outcome every call of `function` reaches.

    `bindings` maps module names to native dotted targets (None for anything
    else). A name the callback binds anywhere is local to its whole body, so
    it shadows the module binding. `receiver` reads the first positional
    parameter as the instance, which is how `self.skipTest` resolves.
    """
    return _reached(_body(function.body), _local(function, bindings, receiver))[0]


# How a walk over statements ends: every path ends there (in an outcome, or by
# leaving), control falls through to what follows, or some path may leave
# under a condition the walk does not follow.
_ENDS, _FALLS, _STOPS = 'ends', 'falls', 'stops'


def _handler_condition(try_statement, handler):
    # Imported late: the frontend imports this module.
    from .frontend import _handler_guard

    return _handler_guard(try_statement, handler)


def _guarded(statements, bindings, conds, sites, condition, attrs=None):
    """Walk `statements` under the path condition `conds`, a tuple of source texts.

    Appends (effect, evidence, conds) for each native outcome a run reaches
    whenever its path condition holds, and returns how the walk ends and
    whether some path left without an outcome. The path condition is the one
    guard definition of #196 183.2: each enclosing `if` test, `not (...)` for
    an `else` branch and for the code after a branch that always ends, and an
    `except` block's own condition (`_handler_guard`, as a conftest's
    `collect_ignore` records it). A path this reading cannot follow ends the
    walk rather than widening a guard: code after a branch that may leave
    without always leaving, and any other compound statement that may leave.
    Loop, `with` and `match` bodies and a `try` body are not read for
    outcomes, as `callback_outcome` does not read them.
    """
    left = False
    for statement in statements:
        found = _outcome(statement, bindings)
        if found is not None:
            sites.append((*found, conds))
            return _ENDS, left
        if isinstance(statement, ast.If):
            truth = _fold(statement.test, attrs)
            if truth is not None:
                state, leaves = _guarded(statement.body if truth else statement.orelse,
                                         bindings, conds, sites, condition, attrs)
                left |= leaves
                if state != _FALLS or leaves:
                    return state if state != _FALLS else _STOPS, left
                continue
            test = condition(statement.test)
            body, body_left = _guarded(statement.body, bindings, (*conds, test), sites, condition, attrs)
            orelse, orelse_left = _guarded(statement.orelse, bindings, (*conds, f'not ({test})'), sites,
                                           condition, attrs)
            left |= body_left or orelse_left
            if _STOPS in (body, orelse):
                return _STOPS, left
            if body == orelse == _ENDS:
                return _ENDS, left
            if body == _ENDS and not orelse_left:
                conds = (*conds, f'not ({test})')
            elif orelse == _ENDS and not body_left:
                conds = (*conds, test)
            elif body_left or orelse_left:
                return _STOPS, left
            continue
        if isinstance(statement, ast.Try) and not statement.handlers and not _may_leave(statement.finalbody):
            state, leaves = _guarded(statement.body + statement.finalbody, bindings, conds, sites, condition, attrs)
            left |= leaves
            if state != _FALLS or leaves:
                return state if state != _FALLS else _STOPS, left
            continue
        if isinstance(statement, ast.Try):
            if _may_leave([*statement.body, *statement.orelse, *statement.finalbody]):
                return _STOPS, left
            for handler in statement.handlers:
                state, leaves = _guarded(handler.body, bindings, (*conds, _handler_condition(statement, handler)),
                                         sites, condition, attrs)
                if state == _STOPS or leaves:
                    return _STOPS, left or leaves
            continue
        if isinstance(statement, (ast.Return, ast.Raise)) or (
                isinstance(statement, ast.Expr) and isinstance(statement.value, (ast.Yield, ast.YieldFrom))):
            return _ENDS, True
        if _may_leave([statement]):
            return _STOPS, left
    return _FALLS, left


def _expression(text):
    try:
        return ast.parse(text, mode='eval').body
    except SyntaxError:
        return None


def _conjunction(conds):
    """`conds` joined with `and`, or None for none.

    A test written across lines inside parentheses keeps them, and a conjunct
    that would bind more loosely than `and` is wrapped. An `except` block's
    condition that is not an expression stays as written: the guard then
    earns nothing that needs it parsed, and still counts as a condition.
    """
    parts = []
    for cond in conds:
        node = _expression(cond)
        if node is None and _expression(f'({cond})') is not None:
            cond, node = f'({cond})', _expression(f'({cond})')
        loose = isinstance(node, (ast.BoolOp, ast.IfExp, ast.Lambda, ast.NamedExpr))
        parts.append(f'({cond})' if len(conds) > 1 and loose else cond)
    return ' and '.join(parts) or None


class Guard(str):
    """A setup outcome's guard text, with the paths it joins (#358).

    `paths` holds (effect, evidence, conditions) for each outcome the setup
    reaches under a condition, so a unit can read a condition on its own
    marks before they are joined (`own_marks.resolve`). It compares and
    hashes as its text.
    """

    def __new__(cls, text, paths):
        guard = super().__new__(cls, text)
        guard.paths = paths
        return guard


def setup_outcome(function, bindings, *, receiver=False, condition=ast.unparse, attrs=None, per_test=False):
    """(effect, evidence, guard) for the outcome a unit's setup callback ends in, or None.

    guard None: every call reaches it, read exactly as `callback_outcome`
    reads it. Otherwise each outcome a call reaches whenever its path
    condition holds counts (`_guarded`), and the guard is the disjunction of
    those conditions (#196 183.2), so two branches that between them cover
    every run read as the unconditional skip they are wherever the guard can
    be evaluated. The first such outcome names the effect and is the evidence.
    `condition` gives an expression's source text. `attrs` resolves the
    class attributes a method's guards read through its receiver (#254).
    `per_test`: the callback is a fixture whose `request` is the test's own
    (`_test_request`), so its guard keeps the paths it joins (`Guard`).
    """
    local = _local(function, bindings, receiver)
    body = _body(function.body)
    if attrs is not None:
        from .class_attributes import receivers

        names = receivers(function)
        attrs = (attrs, names) if names else None
    found = _reached(body, local)[0]
    if found is not None:
        return (*found, None)
    sites = []
    _guarded(body, local, (), sites, condition, attrs)
    if not sites:
        return None
    effect, evidence, _conds = sites[0]
    clauses = [_conjunction(conds) for _effect, _evidence, conds in sites]
    if None in clauses:
        return effect, evidence, None
    text = clauses[0] if len(clauses) == 1 else ' or '.join(f'({c})' for c in clauses)
    return effect, evidence, Guard(text, tuple(sites)) if per_test else text


def module_bindings(tree, *, mutated=True):
    """Each module name's final top-level binding: a native dotted target, or None.

    Setup callbacks run after the module has executed, so the last binding is
    the one they see. A name any other statement binds, or with `mutated`
    whose attributes it assigns, resolves to nothing. A test body's skip reads
    the bindings without `mutated` (#220): `unittest.TestCase.maxDiff = None`
    leaves `raise unittest.SkipTest` a skip, as the literal spelling was.
    """
    bindings = {}
    for statement in tree.body:
        if isinstance(statement, ast.Import):
            for alias in statement.names:
                local = alias.asname or alias.name.split('.')[0]
                target = alias.name if alias.asname else local
                bindings[local] = target if target in _NATIVE_MODULES else None
        elif isinstance(statement, ast.ImportFrom) and statement.module and not statement.level:
            native = statement.module in _NATIVE_MODULES
            for alias in statement.names:
                if alias.name != '*':
                    bindings[alias.asname or alias.name] = f'{statement.module}.{alias.name}' if native else None
        else:
            bindings.update(dict.fromkeys(sorted(_names([statement], mutated=mutated))))
    return bindings


def _import_pairs(node):
    """(name, native dotted target or None) for each name an import binds; None for a star import."""
    if isinstance(node, ast.Import):
        pairs = []
        for alias in node.names:
            local = alias.asname or alias.name.split('.')[0]
            target = alias.name if alias.asname else local
            pairs.append((local, target if target in _NATIVE_MODULES else None))
        return pairs
    if any(alias.name == '*' for alias in node.names):
        return None
    native = not node.level and node.module in _NATIVE_MODULES
    return [(alias.asname or alias.name, f'{node.module}.{alias.name}' if native else None) for alias in node.names]


def setup_skip_controls(tree):
    from .callable_fixture_expectations import _parameters

    bindings, functions = {}, []
    for node in _body(tree.body):
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            # Each name an import binds, to a native module or to nothing this
            # proof reads: `import sys` or `import unittest` beside the hook no
            # longer ends it (#220, #199 H2). A star import binds names it
            # does not say.
            pairs = _import_pairs(node)
            if pairs is None:
                return
        elif isinstance(node, ast.FunctionDef) and _parameters(node) is not None:
            if node.name in bindings or node.name.startswith('__'):
                return
            bindings[node.name] = None
            functions.append((node, dict(bindings)))
            continue
        else:
            return
        for name, target in pairs:
            if name.startswith('__') or name in bindings and bindings[name] != target:
                return
            bindings[name] = target
    result = None
    for function, declared in functions:
        # Later rebinding of the provider would change a global lookup.
        if any(bindings.get(name) != target for name, target in declared.items() if target):
            return
        body = _body(function.body)
        if function.name != 'pytest_runtest_setup':
            if (function.name.startswith('pytest_') or _parameters(function) != []
                    or len(function.decorator_list) != 1
                    or not _decorator(function.decorator_list[0], declared, 'pytest.fixture', {'autouse'})
                    or len(body) != 1 or not isinstance(body[0], ast.Expr)
                    or not isinstance(body[0].value, ast.Yield) or body[0].value.value is not None):
                return
            continue
        if (_parameters(function) not in ([], ['item']) or len(function.decorator_list) > 1
                or any(not _decorator(dec, declared, 'pytest.hookimpl', {'tryfirst', 'trylast'})
                       for dec in function.decorator_list)
                or _generator(function)):
            return
        # The one shared reading of "this callback always ends in an outcome".
        outcome = callback_outcome(function, declared)
        if outcome is None:
            return
        result = ('conftest.runtime.pytest_runtest_setup.' + outcome[0], outcome[1])
    if result is not None:
        yield result


# xunit setup that pytest calls itself, and the units each one runs for.
_MODULE_SETUP = {'setup_module': 'all', 'setUpModule': 'all', 'setup_function': 'functions'}
_CLASS_SETUP = {'setup_class': 'methods', 'setUpClass': 'methods', 'setup_method': 'methods', 'setUp': 'methods'}
# unittest's own callbacks: only a unittest.TestCase runs them. On a plain
# class pytest calls setup_class and setup_method alone.
_UNITTEST_SETUP = frozenset({'setUpClass', 'setUp'})


def _fixture(function, bindings):
    """(registered name, autouse) for a plain native fixture definition, else None."""
    if not isinstance(function, (ast.FunctionDef, ast.AsyncFunctionDef)) or len(function.decorator_list) != 1:
        return None
    decorator = function.decorator_list[0]
    call = decorator if isinstance(decorator, ast.Call) else None
    target = _resolve(call.func if call is not None else decorator, bindings)
    if target != 'pytest.fixture' or call is not None and call.args:
        return None
    name, autouse = function.name, False
    for keyword in call.keywords if call is not None else ():
        value = keyword.value.value if isinstance(keyword.value, ast.Constant) else None
        if (keyword.arg is None or keyword.arg == 'autouse' and type(value) is not bool
                or keyword.arg == 'name' and type(value) is not str):
            return None
        if keyword.arg == 'autouse':
            autouse = value
        elif keyword.arg == 'name':
            name = value
    return name, autouse


def _test_request(function):
    """Is `request` in this fixture the requesting test's own, its `node` the test item (#358)?

    It is in a fixture of the default function scope (no `scope`, or the
    literal "function") that takes `request` and never rebinds it. A wider
    scope's `request.node` is a class, module, package or session, whose
    marks and keywords are not the test's.
    """
    decorator = function.decorator_list[0]
    for keyword in decorator.keywords if isinstance(decorator, ast.Call) else ():
        if keyword.arg == 'scope' and not (isinstance(keyword.value, ast.Constant) and keyword.value.value == 'function'):
            return False
    args = function.args
    if 'request' not in {arg.arg for arg in (*args.posonlyargs, *args.args, *args.kwonlyargs)}:
        return False
    return 'request' not in _names(function.body)


def _plain_binding(statement, bindings):
    """Does this final binding of a name show every fixture it holds?

    A class or an undecorated def holds none, and a plain native fixture is
    read. An import, an assignment, a decorated def read as no plain fixture,
    or a def under an `if` or `try` may hold one this reading does not see.
    """
    if isinstance(statement, ast.ClassDef):
        return True
    return isinstance(statement, (ast.FunctionDef, ast.AsyncFunctionDef)) and (
        not statement.decorator_list or _fixture(statement, bindings) is not None)


def _requests(function, *, receiver):
    """Fixture names a callback or a test asks pytest for: arguments without defaults."""
    args = function.args
    positional = [*args.posonlyargs, *args.args]
    names = [arg.arg for arg in positional[:len(positional) - len(args.defaults)]]
    if receiver:
        names = names[1:]
    names += [arg.arg for arg, default in zip(args.kwonlyargs, args.kw_defaults) if default is None]
    return frozenset(names) - {'request'}


def _usefixtures(marks, bindings):
    """Names that literal `pytest.mark.usefixtures(...)` marks among these request."""
    return {argument.value for mark in marks
            if isinstance(mark, ast.Call) and _resolve(mark.func, bindings) == 'pytest.mark.usefixtures'
            for argument in mark.args
            if isinstance(argument, ast.Constant) and type(argument.value) is str}


def _pytestmark(body):
    marks = []
    for statement in body:
        if isinstance(statement, ast.Assign) and any(
                isinstance(target, ast.Name) and target.id == 'pytestmark' for target in statement.targets):
            value = statement.value
            marks.extend(value.elts if isinstance(value, (ast.List, ast.Tuple)) else [value])
    return marks


def _strings(node):
    if isinstance(node, ast.Constant) and type(node.value) is str:
        return [item.strip() for item in node.value.split(',') if item.strip()]
    if isinstance(node, (ast.List, ast.Tuple)) and all(
            isinstance(item, ast.Constant) and type(item.value) is str for item in node.elts):
        return [item.value for item in node.elts]
    return None


def _direct_arguments(marks, bindings):
    """Argnames these `parametrize` marks supply directly: no fixture runs for them."""
    names = set()
    for mark in marks:
        if not (isinstance(mark, ast.Call) and mark.args
                and _resolve(mark.func, bindings) == 'pytest.mark.parametrize'):
            continue
        argnames = _strings(mark.args[0]) or []
        indirect = next((keyword.value for keyword in mark.keywords if keyword.arg == 'indirect'), None)
        if indirect is None or isinstance(indirect, ast.Constant) and indirect.value is False:
            names.update(argnames)
        elif isinstance(indirect, (ast.List, ast.Tuple)) and _strings(indirect) is not None:
            names.update(set(argnames) - set(_strings(indirect)))
    return names


class SetupScope:
    """The setup providers one module or class body defines (issue #172).

    `fixtures`: registered name -> (requested names, autouse, outcome or None).
    `implicit`: xunit callback name -> (units it runs for, outcome or None).
    An outcome is `setup_outcome`'s (effect, evidence, guard).
    `usefixtures`: names marks request for every unit in scope. `direct`:
    argnames a class or module `parametrize` supplies to every unit in scope.
    Only a name's final binding provides anything: pytest reads the finished
    namespace. `bases` is the class's base list, None when unknown.
    `condition` gives a guard's source text.
    `opaque`: names whose final binding may hold a fixture this reading does
    not see (`_plain_binding`). `star`: a star import, which may bring any
    name. Either keeps a request from falling through to a conftest (#223).
    `helpers` reads what the helpers a provider calls end in, same-file or
    imported (`helper_skips.HelperOutcomes`, #272): `fixture_helpers` and
    `implicit_helpers` map each provider to those outcomes. In a class body,
    `methods` is (key, follow) for the class running the test: a provider's
    calls through its instance run the methods `follow` resolves, and what
    they end in joins its helpers' (#306, `HelperOutcomes.method_calls`).
    """

    def __init__(self, body, bindings, *, in_class=False, marks=(), bases=None, condition=ast.unparse,
                 attrs=None, helpers=None, methods=None):
        self.bindings = bindings
        self.fixtures = {}
        self.implicit = {}
        self.fixture_helpers = {}
        self.implicit_helpers = {}
        scope_marks = [*marks, *_pytestmark(body)]
        self.usefixtures = frozenset(_usefixtures(scope_marks, bindings))
        self.direct = frozenset(_direct_arguments(scope_marks, bindings))
        last = {}
        for statement in body:
            for name in _names([statement]):
                last[name] = statement
        self.opaque = frozenset(name for name, statement in last.items() if not _plain_binding(statement, bindings))
        self.star = any(isinstance(statement, ast.ImportFrom) and any(alias.name == '*' for alias in statement.names)
                        for statement in body)
        callbacks = _CLASS_SETUP if in_class else _MODULE_SETUP
        if (in_class and bases is not None and 'object' not in bindings
                and all(isinstance(base, ast.Name) and base.id == 'object' for base in bases)):
            # Only unittest runs setUp/setUpClass, and a class with no base but
            # `object` is no TestCase. The classes scoped here are the
            # collecting class, the classes enclosing it and a wholly same-file
            # hierarchy (`inherited_tests`): none makes a TestCase inherit this body.
            callbacks = {name: applies for name, applies in callbacks.items() if name not in _UNITTEST_SETUP}
        for statement in body:
            if (not isinstance(statement, (ast.FunctionDef, ast.AsyncFunctionDef))
                    or last.get(statement.name) is not statement):
                continue
            fixture = _fixture(statement, bindings)
            if fixture is not None:
                name, autouse = fixture
                self.fixtures[name] = (_requests(statement, receiver=in_class), autouse,
                                       setup_outcome(statement, bindings, receiver=in_class, condition=condition,
                                                     attrs=attrs if in_class else None,
                                                     per_test=_test_request(statement)))
                if helpers is not None:
                    self.fixture_helpers[name] = helpers.of_scope(statement, bindings, method=in_class)
                    if in_class and methods is not None:
                        self.fixture_helpers[name] = self.fixture_helpers[name] + helpers.method_calls(
                            statement, bindings, methods[0], attrs=attrs, follow=methods[1])
            elif statement.name in callbacks:
                decorators = statement.decorator_list
                plain = (isinstance(statement, ast.FunctionDef) and not _generator(statement)
                         and (not decorators or len(decorators) == 1 and isinstance(decorators[0], ast.Name)
                              and decorators[0].id in {'classmethod', 'staticmethod'}
                              and decorators[0].id not in bindings))
                outcome = (setup_outcome(statement, bindings, receiver=in_class and not decorators,
                                         condition=condition, attrs=attrs if in_class else None)
                           if plain else None)
                self.implicit[statement.name] = (callbacks[statement.name], outcome)
                if helpers is not None:
                    self.implicit_helpers[statement.name] = (
                        helpers.of_scope(statement, bindings, method=in_class and not decorators) if plain else [])
                    if plain and in_class and not decorators and methods is not None:
                        self.implicit_helpers[statement.name] = self.implicit_helpers[statement.name] + (
                            helpers.method_calls(statement, bindings, methods[0], attrs=attrs, follow=methods[1]))
        module_setup = last.get('setUpModule')
        if (not in_class and isinstance(module_setup, (ast.FunctionDef, ast.AsyncFunctionDef))
                and not module_setup.decorator_list):
            # pytest calls only the first of setUpModule and setup_module it
            # finds, so a plain setUpModule leaves setup_module unused.
            self.implicit.pop('setup_module', None)
            self.implicit_helpers.pop('setup_module', None)


@dataclass(frozen=True)
class ConftestLevel:
    """One `conftest.py` as a test module below its directory sees it (#223).

    `fixtures`, `opaque` and `star` are its module `SetupScope`'s, except
    that an outcome's evidence is a (source text, span) pair in this file,
    and a guarded outcome's guard is closed over the conftest's own names
    (`ConftestGuard`, #351). `path` is the conftest's own.
    """
    path: str
    fixtures: dict
    opaque: frozenset
    star: bool
    # May it add a mark a static reading of a test does not see (#358)?
    adds_marks: bool = False
    # Fixture name -> (dotted callee, modules) of the call it returns or
    # yields, resolved through this conftest's own imports, for each fixture
    # that has one (`fixture_producers.producer`, #471). A test that requests
    # the fixture by parameter reaches it one level deep.
    producers: dict = field(default_factory=dict)


def unreadable_level(path):
    """The level a conftest that cannot be read stands for: it ends the chain (#223) and its marks are unknown."""
    return ConftestLevel(path, {}, frozenset(), True, adds_marks=True)


# The receivers whose value the D6 evaluator reads (`compat._eval_condition`):
# `PLAT.startswith("win")` evaluates `PLAT`, `sys.platform.startswith(...)`
# reads `sys.platform` by its spelling.
_EVALUATED_METHODS = frozenset({'startswith', 'endswith', 'lower', 'upper'})
# How far one guard's constants are followed: the evaluator's own depth (16),
# at most as many constants as a test module's environment holds (24), and a
# bound on the text they expand to.
_CLOSE_DEPTH, _CLOSE_CONSTANTS, _CLOSE_TEXT = 16, 24, 4096
# Total constructed closure text per conftest, shared by all conditions.
# Hitting a budget keeps the outcome with an unparseable unknown guard;
# it never drops the skip or qualifies it as a compatibility gate.
_CLOSE_TOTAL = 65536


def _value_names(node):
    """Each name D6 may read as a value in `node`.

    A call's target and an attribute chain's root are read by their spelling
    (`os.environ.get(...)`, `sys.platform`, `system()`) or not at all, so they
    stay as written; so does everything inside an f-string, which the
    evaluator does not read. A call's arguments count: the evaluator reads
    them for a string method, and the compat-token search reads every name
    the guard holds through the test module's constants.
    """
    found = []

    def visit(node):
        if isinstance(node, ast.Name):
            if isinstance(node.ctx, ast.Load):
                found.append(node)
            return
        if isinstance(node, ast.JoinedStr):
            return
        if isinstance(node, ast.Call):
            func = node.func
            if isinstance(func, ast.Attribute) and func.attr in _EVALUATED_METHODS:
                visit(func.value)
            elif not isinstance(func, ast.Name):
                visit(func)
            for child in (*node.args, *(keyword.value for keyword in node.keywords)):
                visit(child)
            return
        if isinstance(node, ast.Attribute):
            root = node.value
            while isinstance(root, ast.Attribute):
                root = root.value
            if not isinstance(root, ast.Name):
                visit(root)
            return
        for child in ast.iter_child_nodes(node):
            visit(child)

    visit(node)
    return found


class ConftestGuard:
    """A conftest fixture's guard, closed over the conftest's names (#351, 183.2's conftest half).

    D6 evaluates a marker's guard with the test module's constants, but a
    conftest guard is written in the conftest's names: a `WIN` or `ON_CI` both
    files define would be judged by the test module's value. So before the
    guard is recorded:

    1. a name the conftest binds as a top-level constant is replaced by its
       defining expression, closed the same way, as far as the evaluator
       follows a constant; a name an import also binds is ambiguous, as
       `_gate_constants` treats it, and is not replaced;
    2. any other name the evaluator reads as a value becomes
       `conftest.<name>`, which it reads as unknown and never resolves
       through the test module; call targets and attribute roots stay;
    3. so a name imported from another module is not followed: a gate
       spelled through one is judged with that part unknown.

    A name the fixture binds itself (a parameter, an assignment) is its own
    local, never the conftest's constant. Called with an `if` test inside one
    of the conftest's top-level functions, as `setup_outcome`'s `condition`.
    """

    # Imported helpers reuse the same closure with the fixed "helper" prefix.
    # Never derive this from a file/module name: D6 also searches guard text.
    _prefix = 'conftest'

    def __init__(self, tree, text_of, span_of):
        self._text_of, self._span_of = text_of, span_of
        self._remaining = _CLOSE_TOTAL
        self._segments = {}
        imported = set()
        constants = {}
        for statement in tree.body:
            if isinstance(statement, (ast.Import, ast.ImportFrom)):
                imported.update(alias.asname or alias.name.split('.')[0] for alias in statement.names)
            elif isinstance(statement, ast.Assign):
                constants.update((target.id, statement.value) for target in statement.targets
                                 if isinstance(target, ast.Name))
            elif (isinstance(statement, ast.AnnAssign) and statement.value is not None
                  and isinstance(statement.target, ast.Name)):
                constants[statement.target.id] = statement.value
        self._constants = {name: value for name, value in constants.items() if name not in imported}
        self._locals = {}
        for statement in tree.body:
            if isinstance(statement, (ast.FunctionDef, ast.AsyncFunctionDef)):
                args = statement.args
                bound = frozenset(_names(statement.body)) | frozenset(
                    arg.arg for arg in (*args.posonlyargs, *args.args, *args.kwonlyargs, args.vararg, args.kwarg)
                    if arg is not None)
                for node in ast.walk(statement):
                    if isinstance(node, ast.Name):
                        self._locals[id(node)] = bound

    def __call__(self, node):
        budget = [_CLOSE_CONSTANTS]
        try:
            return self._close(node, frozenset(), budget)
        except _ClosureBudget:
            return f'{self._prefix}.<unreadable>'

    def _close(self, node, resolving, budget):
        if self._remaining <= 0:
            raise _ClosureBudget
        key = id(node)
        if key not in self._segments:
            start, end = self._span_of(node)
            if end - start > min(_CLOSE_TEXT, self._remaining):
                raise _ClosureBudget
            self._segments[key] = (self._text_of(node), start, end)
        text, start, end = self._segments[key]
        self._remaining -= len(text or '')
        names = _value_names(node)
        if not names:
            return text or ast.unparse(node)
        spans = [self._span_of(name) for name in names]
        if not text or end - start != len(text) or any(not start <= s <= e <= end for s, e in spans):
            # No source to splice the names into (never a node this file's
            # parser built): the guard is recorded as unknown, and earns nothing.
            return f'{self._prefix}.<unreadable>'
        pieces, last, size = [], start, 0
        for name, (s, e) in sorted(zip(names, spans), key=lambda pair: pair[1]):
            literal = text[last - start:s - start]
            replacement = self._name(name, resolving, budget)
            size += len(literal) + len(replacement)
            if size > _CLOSE_TEXT or len(replacement) > self._remaining:
                raise _ClosureBudget
            self._remaining -= len(replacement)
            pieces.extend((literal, replacement))
            last = e
        if size + end - last > _CLOSE_TEXT:
            raise _ClosureBudget
        pieces.append(text[last - start:])
        return ''.join(pieces)

    def _name(self, node, resolving, budget):
        name = node.id
        value = self._constants.get(name)
        if (value is not None and name not in self._locals.get(id(node), ()) and name not in resolving
                and len(resolving) < _CLOSE_DEPTH and budget[0] > 0):
            budget[0] -= 1
            closed = self._close(value, resolving | {name}, budget)
            if len(closed) <= _CLOSE_TEXT:
                return f'({closed})'
        return f'{self._prefix}.{name}'


class _ClosureBudget(Exception):
    """An internal bounded-closure stop, converted to an unknown guard."""


def conftest_level(path, tree, text_of, span_of):
    """`path`'s `ConftestLevel`, read from its parsed module `tree`.

    `text_of` and `span_of` give a node's source text and span in that file.
    A guarded outcome keeps its guard, closed over the conftest's names, and
    is judged on the unit as a guarded skip in its own setup is (#351).
    Each fixture's producer is read through the conftest's own imports
    (#471).
    """
    from .fixture_producers import ProducerScope, import_modules
    from .own_marks import adds_marks

    bindings = module_bindings(tree)
    scope = SetupScope(tree.body, bindings, condition=ConftestGuard(tree, text_of, span_of))
    fixtures = {}
    for name, (requested, autouse, outcome) in scope.fixtures.items():
        if outcome is not None:
            effect, evidence, guard = outcome
            if isinstance(guard, Guard):
                guard = Guard(str(guard), tuple(
                    (kind, (text_of(site), span_of(site)), conds)
                    for kind, site, conds in guard.paths
                ))
            outcome = (effect, (text_of(evidence), span_of(evidence)), guard)
        fixtures[name] = (requested, autouse, outcome)
    made = ProducerScope(tree.body, bindings, import_modules(tree)).producers
    producers = {name: made[name] for name in sorted(made) if made[name] is not None}
    return ConftestLevel(path, fixtures, scope.opaque, scope.star, adds_marks=adds_marks(tree),
                         producers=producers)


def setup_outcomes(scopes, function, *, method, chain=()):
    """(provider, effect, evidence, guard, origin) for every outcome this unit's setup reaches.

    `scopes` runs from the module to the innermost enclosing class, and
    `chain` holds the conftest files above the module, nearest first. The
    unit reaches what its arguments name, what `usefixtures` names, the
    autouse fixtures in scope, what those request in turn, and the xunit
    setup pytest runs for it; a name that `parametrize` on the unit, its
    class or its module supplies directly runs no fixture anywhere in that
    closure.

    A request resolves as pytest resolves it for this test (#223): the
    nearest scope that defines the name wins, the test module's own
    definitions before every conftest, and a fixture that requests its own
    name reaches the next definition outward. A name bound in a way this
    reading does not follow may hold a fixture there (`SetupScope.opaque`,
    `star`), so the request stops before any conftest beyond it.
    `origin` is the conftest's path for an outcome found there, None for
    one in the test module, whose evidence is a node.
    """
    implicit, applying, visited, levels, own = _setup_reach(scopes, function, method=method, chain=chain)
    found = {}
    for name in applying:
        outcome = implicit[name][1]
        if outcome is not None:
            found[name] = (*outcome, None)
    for name, index in visited:
        outcome = levels[index].fixtures[name][2]
        if outcome is not None:
            found.setdefault(name, (*outcome, levels[index].path if index >= own else None))
    return [(name, *found[name]) for name in sorted(found)]


def setup_helper_outcomes(scopes, function, *, method, chain=()):
    """(helper, effect, evidence, guard) for what the helpers this unit's setup calls end in (#272).

    The providers are the ones `setup_outcomes` reads: the xunit setup pytest
    runs for the unit, and every fixture it reaches in the test module. A
    conftest's fixtures call helpers in another file, which this does not
    follow.
    """
    _implicit, applying, visited, levels, own = _setup_reach(scopes, function, method=method, chain=chain)
    helpers = {}
    for scope in scopes:
        helpers.update(scope.implicit_helpers)
    found = []
    for name in applying:
        found.extend(helpers.get(name, ()))
    for name, index in visited:
        if index < own:
            found.extend(levels[index].fixture_helpers.get(name, ()))
    return found


def _setup_reach(scopes, function, *, method, chain=()):
    """What a unit's setup runs, as `setup_outcomes` resolves it.

    (the xunit callbacks in scope by name, with what each applies to and its
    outcome; the names of those that apply to this unit, sorted; each fixture
    it reaches as (name, level index), in the order they are reached; the
    levels, nearest first; how many of them are the test module's own).
    """
    bindings = scopes[0].bindings
    static = any(isinstance(mark, ast.Name) and mark.id == 'staticmethod' for mark in function.decorator_list)
    wanted = set(_requests(function, receiver=method and not static))
    wanted |= _usefixtures(function.decorator_list, bindings)
    direct = _direct_arguments(function.decorator_list, bindings)
    implicit = {}
    for scope in scopes:
        implicit.update(scope.implicit)
        wanted |= scope.usefixtures
        direct |= scope.direct
    # Nearest first: the innermost class to the module, then each conftest.
    levels = [*reversed(scopes), *chain]
    own = len(scopes)
    for level in levels:
        wanted |= {name for name, fixture in level.fixtures.items() if fixture[1]}
    wanted -= direct
    applying = [name for name in sorted(implicit)
                if implicit[name][0] == 'all' or (implicit[name][0] == 'methods') == method]

    def resolve(name, start):
        for index in range(start, len(levels)):
            if name in levels[index].fixtures:
                return index
            if index == own - 1 and any(name in level.opaque or level.star for level in levels[start:own]):
                return None
            if index >= own and (name in levels[index].opaque or levels[index].star):
                return None
        return None

    queue, seen = [], set()

    def request(name, start):
        index = resolve(name, start) if name not in direct else None
        # A directly parametrized name replaces its fixture for every request
        # in the closure, not only the unit's own.
        if index is not None and (name, index) not in seen:
            seen.add((name, index))
            queue.append((name, index))

    for name in sorted(wanted):
        request(name, 0)
    visited = []
    while queue:
        name, index = queue.pop(0)
        visited.append((name, index))
        requested = levels[index].fixtures[name][0]
        for other in sorted(requested):
            request(other, index + 1 if other == name else 0)
    return implicit, applying, visited, levels, own


def fixture_setup_controls(tree):
    """Conftest fixtures whose setup always ends in a skip or xfail outcome.

    Any test under the conftest's directory can request them, so each one is
    a suite-level runtime control, named per fixture: another such fixture in
    a conftest that already had one is still an event (THREATMODEL 81's
    lesson). A test module the diff changes resolves its own requests to it
    (`setup_outcomes`, #223), but the others may live anywhere under the
    directory, outside the diff, so the fixture is reported here whoever
    requests it (ruling 196.183.1). A guarded one is no suite-level control:
    it is judged on the units of a changed test module that reach it (#351).
    """
    fixtures = SetupScope(tree.body, module_bindings(tree)).fixtures
    for name in sorted(fixtures):
        outcome = fixtures[name][2]
        if outcome is not None and outcome[2] is None:
            yield f'conftest.runtime.fixture.{name}.{outcome[0]}', outcome[1]
