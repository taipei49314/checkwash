"""Claude command hooks: portable shared CLI or an isolated local runtime.

Exec-form handlers require Claude Code's command/args support. Qualification
records name the runtime tested; writing settings is not a Stop lifecycle test.

The installer writes two managed handlers (#418): a Stop handler that checks
the working tree and the session's commits, and a SessionStart handler, in a
group of its own, that records where each session starts.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
import shlex
import stat
import subprocess
import sys
import tempfile

import checkwash
from checkwash import __version__


_CHECK_ARGS = ["check", "--format", "hook-json", "--hook-input", "stdin"]
# The managed Stop handler before #418. It stays managed, so an install
# replaces it, and a custom handler is still recognized by this prefix.
_LEGACY_CHECK_ARGS = ["check", "--format", "hook-json"]
_SESSION_ARGS = ["hook", "session-start"]
_LEGACY_COMMANDS = {
    "checkwash check --format hook-json",
    "greenwash check --format hook-json",
}
# A constant program and a separate data argument keep paths out of Python and
# shell syntax. -I excludes cwd, PYTHONPATH and user site packages. The selected
# package origin is checked before calling it; a repo's checkwash.py cannot win.
_BOOTSTRAP = """# checkwash managed hook v1
import json, os, runpy, sys
binding = json.loads(sys.argv.pop(1))
if binding["kind"] == "zipapp":
    runpy.run_path(binding["path"], run_name="__main__")
else:
    sys.path.insert(0, binding["path"])
    import checkwash
    if os.path.realpath(checkwash.__file__) != binding["origin"]:
        raise SystemExit("checkwash hook: selected package origin changed; reinstall the hook")
    from checkwash.cli import main
    raise SystemExit(main())
"""


class HookInstallError(ValueError):
    pass


def _local_binding() -> dict[str, str]:
    archive = getattr(checkwash.__loader__, "archive", None)
    if archive:
        return {"kind": "zipapp", "path": str(Path(archive).resolve())}
    origin = Path(checkwash.__file__).resolve()
    return {"kind": "package", "path": str(origin.parent.parent), "origin": str(origin)}


def _probe(command: str, args: list[str]) -> None:
    try:
        # Never run a version probe from the user's repository. Local handlers
        # are isolated as well, so their later cwd can safely be the project.
        with tempfile.TemporaryDirectory(prefix="checkwash-probe-") as cwd:
            result = subprocess.run(
                [command, *args], cwd=cwd, stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=10,
                check=False,
            )
    except (OSError, subprocess.SubprocessError) as exc:
        raise HookInstallError(f"cannot execute the selected checkwash runtime: {exc}") from exc
    if result.returncode or result.stdout.decode("utf-8", "replace").strip() != f"checkwash {__version__}":
        raise HookInstallError(
            f"selected runtime did not report checkwash {__version__}; "
            "install that CLI version or use --local to bind this installation"
        )


def _shared_executable() -> str | None:
    """Search explicit absolute PATH entries, never Windows' implicit cwd.

    Python 3.11 shutil.which prepends the current directory on Windows even
    when a PATH argument is supplied. Joining an absolute entry ourselves also
    excludes empty, relative and drive-relative entries. The final portable
    hook still depends on the PATH used by each teammate's Claude runtime.
    """
    filename = "checkwash.exe" if os.name == "nt" else "checkwash"
    for entry in os.environ.get("PATH", "").split(os.pathsep):
        directory = Path(entry)
        if not entry or not directory.is_absolute():
            continue
        candidate = directory / filename
        if candidate.is_file() and os.access(candidate, os.F_OK | os.X_OK):
            return str(candidate)
    return None


def build_handler(local: bool) -> dict:
    """The managed Stop handler, after a version probe of its runtime."""
    if local:
        command = os.path.abspath(sys.executable)
        args = ["-I", "-c", _BOOTSTRAP, json.dumps(_local_binding(), sort_keys=True), *_CHECK_ARGS]
        _probe(command, [*args[:-len(_CHECK_ARGS)], "--version"])
        return {"type": "command", "command": command, "args": args}
    executable = _shared_executable()
    if executable is None:
        raise HookInstallError(
            "shared settings require an installed checkwash CLI on PATH; "
            "install the CLI or use --local for this Python/zipapp installation"
        )
    _probe(executable, ["--version"])
    return {"type": "command", "command": "checkwash", "args": list(_CHECK_ARGS)}


def session_handler(stop: dict) -> dict:
    """The managed SessionStart handler on the same runtime as `stop` (#418)."""
    return {**stop, "args": [*stop["args"][:-len(_CHECK_ARGS)], *_SESSION_ARGS]}


def is_managed_handler(handler: object) -> bool:
    """Only exact installer shapes are eligible for replacement, not custom hooks."""
    if isinstance(handler, dict) and handler.get("type") == "command" and set(handler) == {"type", "command"}:
        return handler["command"] in _LEGACY_COMMANDS
    return _managed_shape(handler, (_CHECK_ARGS, _LEGACY_CHECK_ARGS))


def is_managed_session_handler(handler: object) -> bool:
    """The installer's SessionStart shapes, shared or local (#418)."""
    return _managed_shape(handler, (_SESSION_ARGS,))


def _managed_shape(handler: object, tails: tuple[list[str], ...]) -> bool:
    if not isinstance(handler, dict) or handler.get("type") != "command":
        return False
    if set(handler) != {"type", "command", "args"}:
        return False
    args = handler["args"]
    if handler["command"] == "checkwash" and args in tails:
        return True
    if not isinstance(handler["command"], str) or not isinstance(args, list):
        return False
    if args[:3] != ["-I", "-c", _BOOTSTRAP] or not any(
        len(args) == 4 + len(tail) and args[4:] == tail for tail in tails
    ):
        return False
    try:
        binding = json.loads(args[3])
    except (TypeError, ValueError):
        return False
    return isinstance(binding, dict) and (
        set(binding) == {"kind", "path"} and binding.get("kind") == "zipapp"
        or set(binding) == {"kind", "path", "origin"} and binding.get("kind") == "package"
    ) and all(isinstance(value, str) for value in binding.values())


def stop_handlers(settings: object) -> list[dict]:
    """Validate the layers we must merge; leave unrelated settings untouched."""
    return _event_handlers(settings, "Stop")


def session_start_handlers(settings: object) -> list[dict]:
    return _event_handlers(settings, "SessionStart")


def _event_handlers(settings: object, event: str) -> list[dict]:
    if not isinstance(settings, dict):
        raise HookInstallError("settings must be a JSON object")
    hooks = settings.get("hooks", {})
    if not isinstance(hooks, dict):
        raise HookInstallError("settings.hooks must be an object")
    groups = hooks.get(event, [])
    if not isinstance(groups, list):
        raise HookInstallError(f"settings.hooks.{event} must be an array")
    handlers = []
    for entry in groups:
        if not isinstance(entry, dict) or not isinstance(entry.get("hooks"), list):
            raise HookInstallError(f"each {event} group must contain a hooks array")
        if not all(isinstance(handler, dict) for handler in entry["hooks"]):
            raise HookInstallError(f"each {event} handler must be an object")
        for handler in entry["hooks"]:
            if not isinstance(handler.get("type"), str):
                raise HookInstallError(f"each {event} handler must have a string type")
            if handler["type"] == "command" and (
                not isinstance(handler.get("command"), str)
                or "args" in handler and (
                    not isinstance(handler["args"], list)
                    or not all(isinstance(arg, str) for arg in handler["args"])
                )
            ):
                raise HookInstallError("command hooks require a string command and string args")
        handlers.extend(entry["hooks"])
    return handlers


def has_stop_hook(settings: object) -> bool:
    """Recognize configuration only; never execute it or infer effective policy."""
    return _has_hook(stop_handlers(settings), is_managed_handler, _LEGACY_CHECK_ARGS)


def has_session_start_hook(settings: object) -> bool:
    """A managed or custom `checkwash hook session-start` handler (#418)."""
    return _has_hook(session_start_handlers(settings), is_managed_session_handler, _SESSION_ARGS)


def stop_reads_hook_input(settings: object) -> bool:
    """A Stop handler that hands checkwash its hook input (#418)."""
    for handler in stop_handlers(settings):
        if handler.get("type") != "command":
            continue
        shape = {key: handler[key] for key in ("type", "command", "args") if key in handler}
        if _managed_shape(shape, (_CHECK_ARGS,)):
            return True
        words = _checkwash_words(handler)
        if words and words[1:4] == _LEGACY_CHECK_ARGS and any(
            words[i:i + 2] == ["--hook-input", "stdin"] for i in range(4, len(words))
        ):
            return True
    return False


def _checkwash_words(handler: dict) -> list[str] | None:
    """A command handler's words when it runs a checkwash executable, else None."""
    if "args" in handler:
        words = [handler["command"], *handler["args"]]
    else:
        try:
            words = shlex.split(handler["command"])
        except ValueError:
            return None
    if not words:
        return None
    name = words[0].replace("\\", "/").rsplit("/", 1)[-1]
    return words if name in {"checkwash", "checkwash.exe", "greenwash", "greenwash.exe"} else None


def _has_hook(handlers: list[dict], managed, prefix: list[str]) -> bool:
    for handler in handlers:
        if handler.get("type") != "command":
            continue
        shape = {key: handler[key] for key in ("type", "command", "args") if key in handler}
        if managed(shape):
            return True
        words = _checkwash_words(handler)
        if words and words[1:1 + len(prefix)] == prefix:
            return True
    return False


def install_claude(repo: str, local: bool) -> str:
    path = Path(repo) / ".claude" / ("settings.local.json" if local else "settings.json")
    if any(p.is_symlink() or p.exists() and (
        getattr(p.lstat(), "st_file_attributes", 0) & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0)
    ) for p in (path, path.parent)):
        raise HookInstallError(f"{path} is linked; not touching it")
    original = path.read_bytes() if path.exists() else None
    try:
        settings = json.loads(original.decode("utf-8-sig")) if original is not None else {}
    except (ValueError, UnicodeError) as exc:
        raise HookInstallError(f"{path} is not valid UTF-8 JSON; not touching it") from exc
    stop_handlers(settings)
    session_start_handlers(settings)
    handler = build_handler(local)
    hooks = settings.setdefault("hooks", {})
    merged = [
        _merge(hooks.setdefault("Stop", []), handler, is_managed_handler),
        _merge(hooks.setdefault("SessionStart", []), session_handler(handler), is_managed_session_handler),
    ]
    unchanged = all(same for same, _ in merged)
    matches = any(found for _, found in merged)
    data = (json.dumps(settings, indent=2, sort_keys=True) + "\n").encode("utf-8")
    if data != original:
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = None
        try:
            with tempfile.NamedTemporaryFile(dir=path.parent, prefix=".checkwash-", delete=False) as output:
                temporary = Path(output.name)
                output.write(data)
            if (path.read_bytes() if path.exists() else None) != original:
                raise HookInstallError(f"{path} changed during installation; not replacing it")
            os.replace(temporary, path)
        finally:
            if temporary is not None:
                temporary.unlink(missing_ok=True)
    action = "already installed" if unchanged else "updated" if matches else "installed"
    scope = "local runtime is bound to this installation" if local else "shared command requires checkwash on Claude's PATH"
    return (
        f"{action}: Stop hook configuration in {path}\n"
        "A SessionStart hook in the same file records where each session starts, so the Stop "
        "hook also checks what the session commits.\n"
        f"{scope}; version probe passed.\n"
        "Requires Claude Code command/args exec-form support (tested with 2.1.260). "
        "Writing configuration does not verify a Claude Stop event.\n"
    )


def _merge(groups: list, handler: dict, managed) -> tuple[bool, bool]:
    """Put `handler` in place of the managed ones in `groups`.

    Only unfiltered installer groups are managed. User matchers, timeouts,
    async flags and other custom handler fields remain exactly as configured.
    Returns (unchanged, whether a managed handler was there).
    """
    matches = [
        (entry, old) for entry in groups if set(entry) == {"hooks"}
        for old in entry["hooks"] if managed(old)
    ]
    unchanged = len(matches) == 1 and matches[0][1] == handler
    if not unchanged:
        for entry, old in matches:
            entry["hooks"].remove(old)
        if matches:
            matches[0][0]["hooks"].append(handler)
        else:
            groups.append({"hooks": [handler]})
    return unchanged, bool(matches)
